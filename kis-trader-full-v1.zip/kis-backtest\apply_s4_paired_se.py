#!/usr/bin/env python3
"""
apply_s4_paired_se.py -- measure S4's noise floor in S4's own tool.

PRE-REGISTERED: claude/PREREG_20260920_S4_readjudication.md. Read it first; the
decision rule is fixed there and is not repeated here.

WHY HERE AND NOT paired_bootstrap.py
The two tools do not measure the same book. trail_8cell clips SIGNALS to a
window before run() and pins the partial constants; paired_bootstrap passes all
signals and clips EQUITY afterwards, leaving the partial at module defaults.
Clipping signals changes which trades exist; clipping equity only trims the
curve. E10 phase 1 reports 225 trades where S4 reports 200. So a trail arm added
to paired_bootstrap would measure a different book and its floor would not apply
to S4's deltas.

Here, the arms, windows, config and partial constants are S4's BY CONSTRUCTION.

WHAT IT ADDS
--paired-se turns on a moving-block paired bootstrap between the CONTROL and
every other arm, on the full-window run the script already performs. OFF by
default, so a plain invocation is byte-identical to S4's.

THE FLOOR IT REPLACES, for reference -- this script's own line:

    se = 1.95 / math.sqrt(max(n, 1))

single-arm, on an ASSUMED per-trade sd of 1.95 that was never measured, with
n=200 (full window) while the deltas it is compared against are per-half cells
of ~100. See the pre-registration addendum.

DUPLICATION, DECLARED
The draw loop mirrors paired_bootstrap.py's. It is copied rather than imported
because that loop lives inline in its main(), and extracting it would touch the
file this design deliberately leaves alone (and FINDING_20260905_AE records an
extraction breaking a block in this repo). Two implementations can drift -- the
S13 problem -- so the copy carries a POSITIVE CONTROL that pins its pairing:
CONTROL vs CONTROL must give a paired SE of exactly 0.0.

    python apply_s4_paired_se.py --verify
    python apply_s4_paired_se.py
    python apply_s4_paired_se.py --revert
"""
from __future__ import annotations

import argparse
import os
import sys
import tempfile

F = "trail_8cell.py"
SENTINEL = "def _paired_se_block"

# --------------------------------------------------------------------------
# edit 1 -- the argparse flags
# --------------------------------------------------------------------------
ARGS_OLD = '''    ap.add_argument("--metric", default="expectancy_R_weighted")
'''
ARGS_NEW = '''    ap.add_argument("--metric", default="expectancy_R_weighted")
    # --- S4 re-adjudication 2026-09-20 --- OFF by default, so a plain run is
    # byte-identical to the one that produced RESULT_20260828_S4_trail_null.
    ap.add_argument("--paired-se", action="store_true",
                    help="measure the PAIRED SE of the difference vs the "
                         "control, by moving-block bootstrap. The printed "
                         "1.95/sqrt(n) floor is single-arm and assumed; this "
                         "one is paired and measured.")
    ap.add_argument("--block", type=int, default=21,
                    help="--paired-se: block length in trading days")
    ap.add_argument("--draws", type=int, default=2000,
                    help="--paired-se: bootstrap draws")
    ap.add_argument("--bs-seed", type=int, default=12345,
                    help="--paired-se: CHANGES THE NUMBERS. Printed with it.")
'''

# --------------------------------------------------------------------------
# edit 2 -- keep the full-window equity and trades (currently discarded)
# --------------------------------------------------------------------------
KEEP_OLD = '''            _e, _t, st, _d, _g = m.run(prices, full, replace(base, slippage_bps=5.0))
            fullrun[arm] = st
'''
KEEP_NEW = '''            _e, _t, st, _d, _g = m.run(prices, full, replace(base, slippage_bps=5.0))
            fullrun[arm] = st
            # --- S4 re-adjudication --- the curve and the trades were thrown
            # away here. The paired bootstrap needs both; nothing else reads
            # them, so this is inert unless --paired-se is passed.
            fulleq[arm], fulltr[arm] = _e, _t
'''

DECL_OLD = '''    cells, fullrun = {}, {}
'''
DECL_NEW = '''    cells, fullrun = {}, {}
    fulleq, fulltr = {}, {}                  # --- S4 re-adjudication ---
'''

# --------------------------------------------------------------------------
# edit 3 -- the bootstrap itself, and its call site
# --------------------------------------------------------------------------
FN_OLD = '''def main() -> int:
'''
FN_NEW = '''def _metric_of(trades, K, m, np):
    """One metric from a trade list. Only the two trade-based metrics are
    needed: the block draw supplies the calendar, not an equity curve."""
    if not trades:
        return float("nan")
    if K == "expectancy_R_weighted":
        return float(np.mean([m._weighted_r(t) for t in trades]))
    return float(np.mean([t.r_at_exit for t in trades]))


def _paired_se_block(m, np, pd, eqA, trA, eqB, trB, K, block, draws, seed):
    """Moving-block paired bootstrap of (B - A) on metric K.

    Mirrors paired_bootstrap.py's draw loop. Blocks are drawn over the SHARED
    calendar; a trade enters a draw when its exit date is in the drawn days, so
    both arms are scored on exactly the same resampled window. That shared
    window is the whole point -- an unpaired SE of the same two arms is larger
    by the arms' correlation, which for two trails on nearly the same book is
    not small.

    Returns (point, paired_se, unpaired_se, n_days) or None if unpairable.
    """
    a_idx = eqA.dropna().index
    b_idx = eqB.dropna().index
    if not a_idx.equals(b_idx):
        # FAIL CLOSED, as paired_bootstrap does: pairing across different
        # calendars would silently compare different windows.
        return None
    idx = a_idx
    n = len(idx)
    L = max(1, int(block))
    if n <= L:
        return None
    dates = idx.normalize().to_numpy()
    byA, byB = {}, {}
    for t in trA:
        byA.setdefault(pd.Timestamp(t.exit_date).normalize(), []).append(t)
    for t in trB:
        byB.setdefault(pd.Timestamp(t.exit_date).normalize(), []).append(t)

    rng = np.random.default_rng(seed)
    nblocks = int(np.ceil(n / L))
    dif, sa, sb = [], [], []
    for _ in range(int(draws)):
        starts = rng.integers(0, n - L + 1, size=nblocks)
        pos = np.concatenate([np.arange(s, s + L) for s in starts])[:n]
        tA, tB = [], []
        for d in dates[pos]:
            key = pd.Timestamp(d)
            if key in byA:
                tA.extend(byA[key])
            if key in byB:
                tB.extend(byB[key])
        mA = _metric_of(tA, K, m, np)
        mB = _metric_of(tB, K, m, np)
        if mA == mA and mB == mB:               # both defined
            dif.append(mB - mA)
            sa.append(mA)
            sb.append(mB)
    if len(dif) < 2:
        return None
    d = np.asarray(dif, dtype=float)
    se_p = float(d.std(ddof=1))
    se_u = float(np.sqrt(np.asarray(sa).std(ddof=1) ** 2
                         + np.asarray(sb).std(ddof=1) ** 2))
    point = (_metric_of(trB, K, m, np) - _metric_of(trA, K, m, np))
    return point, se_p, se_u, n


def main() -> int:
'''

CALL_OLD = '''    print("=" * 78)
    print("  HOW TO READ IT (Rev 3 sec.4)")
'''
CALL_NEW = '''    if a.paired_se:
        _run_paired_se(m, fulleq, fulltr, K, a)

    print("=" * 78)
    print("  HOW TO READ IT (Rev 3 sec.4)")
'''

REPORT_OLD = '''def _metric_of(trades, K, m, np):
'''
REPORT_NEW = '''def _run_paired_se(m, fulleq, fulltr, K, a):
    """Print the measured paired floor beside the assumed one."""
    import numpy as np
    import pandas as pd
    print("\\n" + "=" * 78)
    print("  PAIRED SE vs %s   (metric: %s)" % (CONTROL, K))
    print("  block=%d draws=%d seed=%d   PRE-REG: "
          "PREREG_20260920_S4_readjudication" % (a.block, a.draws, a.bs_seed))
    print("=" * 78)
    print("  %-10s %10s %10s %10s %8s %s"
          % ("arm", "point", "pairedSE", "unpairSE", "ratio", "|point|/pairedSE"))
    # POSITIVE CONTROL first: the control against ITSELF. Identical trade lists
    # must give a paired difference of exactly 0.0 in every draw. A non-zero
    # here means the pairing is wired wrong and every row below is void.
    ctl = _paired_se_block(m, np, pd, fulleq[CONTROL], fulltr[CONTROL],
                           fulleq[CONTROL], fulltr[CONTROL], K,
                           a.block, a.draws, a.bs_seed)
    if ctl is None or ctl[1] != 0.0 or ctl[0] != 0.0:
        print("  ** POSITIVE CONTROL FAILED: %s vs itself gave point=%s "
              "pairedSE=%s, expected 0.0 / 0.0. The pairing is wrong; "
              "everything below is VOID." % (CONTROL, ctl and ctl[0], ctl and ctl[1]))
        return
    print("  %-10s %10.4f %10.4f %10s %8s  POSITIVE CONTROL ok (exactly 0)"
          % (CONTROL + " vs self", ctl[0], ctl[1], "-", "-"))
    for arm, _k, _s in ARMS:
        if arm == CONTROL:
            continue
        r = _paired_se_block(m, np, pd, fulleq[CONTROL], fulltr[CONTROL],
                             fulleq[arm], fulltr[arm], K,
                             a.block, a.draws, a.bs_seed)
        if r is None:
            print("  %-10s  UNPAIRABLE (different calendars or block too long)"
                  % arm)
            continue
        point, se_p, se_u, ndays = r
        ratio = (se_u / se_p) if se_p > 0 else float("inf")
        z = abs(point) / se_p if se_p > 0 else float("inf")
        print("  %-10s %10.4f %10.4f %10.4f %8.2f %17.2f"
              % (arm, point, se_p, se_u, ratio, z))
    n_ctl = fullrun_trades_hint(fulltr)
    print("  ---")
    print("  the floor this REPLACES: 1.95/sqrt(%d) = %.4f -- single-arm, on an"
          % (n_ctl, 1.95 / max(n_ctl, 1) ** 0.5))
    print("  ASSUMED per-trade sd of 1.95, and n is the FULL window while the")
    print("  8-cell deltas it was compared against are per-half (~n/2).")
    print("  NOTE: point/pairedSE here is a FULL-WINDOW comparison. The 8-cell")
    print("  deltas are half-window; their floor is ~pairedSE * sqrt(2).")


def fullrun_trades_hint(fulltr):
    return len(fulltr.get(CONTROL, []))


def _metric_of(trades, K, m, np):
'''

EDITS = [(ARGS_OLD, ARGS_NEW), (DECL_OLD, DECL_NEW), (KEEP_OLD, KEEP_NEW),
         (FN_OLD, FN_NEW), (REPORT_OLD, REPORT_NEW), (CALL_OLD, CALL_NEW)]


def _read(p=F):
    with open(p, encoding="utf-8") as fh:
        return fh.read()


def _write(text, p=F):
    compile(text, p, "exec")
    d = os.path.dirname(os.path.abspath(p))
    fd, tmp = tempfile.mkstemp(dir=d, suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as fh:
            fh.write(text)
        os.replace(tmp, p)
    except BaseException:
        if os.path.exists(tmp):
            os.unlink(tmp)
        raise


def _ascii_guard():
    for name, txt in [("ARGS", ARGS_NEW), ("DECL", DECL_NEW), ("KEEP", KEEP_NEW),
                      ("FN", FN_NEW), ("REPORT", REPORT_NEW), ("CALL", CALL_NEW)]:
        try:
            txt.encode("ascii")
        except UnicodeEncodeError as e:
            raise SystemExit(f"patch text {name} is not pure ASCII: {e}")


def apply(revert=False):
    if not os.path.isfile(F):
        raise SystemExit(f"missing {F} -- run from the kis-backtest root")
    src = _read()
    hits = sum(1 for _o, new in EDITS if new in src)
    if not revert and hits == len(EDITS):
        raise SystemExit("already applied -- nothing to do")
    if not revert and hits:
        raise SystemExit(f"PARTIAL state: {hits}/{len(EDITS)}. Refusing.")
    if revert and hits == 0:
        raise SystemExit("not applied -- nothing to revert")
    if revert and hits != len(EDITS):
        raise SystemExit(f"PARTIAL state: {hits}/{len(EDITS)}. Refusing.")
    # REVERSE on revert. The FN and REPORT edits NEST -- REPORT_NEW ends with
    # the `def _metric_of` line that FN_NEW introduces -- so reverting forward
    # removes the anchor the later revert needs and leaves a half-patched file.
    # Measured 2026-09-20: forward revert failed with "anchor matched 0 times".
    for old, new in (reversed(EDITS) if revert else EDITS):
        a, b = (new, old) if revert else (old, new)
        n = src.count(a)
        if n != 1:
            raise SystemExit(f"anchor matched {n} times, expected 1:\n"
                             f"---\n{a[:130]}\n---")
        src = src.replace(a, b, 1)
    _write(src)
    print(f"  {'reverted' if revert else 'patched '} {F} ({len(EDITS)} edits)")
    print("REVERTED." if revert else "APPLIED.")


class V:
    def __init__(self):
        self.p = self.f = 0

    def check(self, label, cond, detail=""):
        ok = bool(cond)
        self.p += ok
        self.f += (not ok)
        print(f"  {'PASS' if ok else 'FAIL'}  {label}"
              + (f"   {detail}" if detail and not ok else ""))

    def done(self):
        print(f"\n  {self.p}/{self.p + self.f} checks passed")
        return 0 if self.f == 0 else 1


def verify():
    _ascii_guard()
    v = V()
    src = _read()
    for i, (_o, new) in enumerate(EDITS, 1):
        v.check(f"edit {i}/{len(EDITS)} present exactly once",
                src.count(new) == 1, f"count={src.count(new)}")
    v.check("sentinel present", src.count(SENTINEL) == 1)
    v.check("OFF by default -- the flag is store_true",
            '"--paired-se", action="store_true"' in src)
    v.check("the 1.95 floor line is UNTOUCHED (it is the incumbent, not a bug "
            "to silently fix)", "se = 1.95 / math.sqrt(max(n, 1))" in src)
    try:
        compile(src, F, "exec")
        v.check("compiles", True)
    except SyntaxError as e:
        v.check("compiles", False, str(e))
        return v.done()

    # ---- runtime, on synthetic trades: no bars needed ----
    import numpy as np
    import pandas as pd
    sys.path.insert(0, os.getcwd())
    import types
    mod = types.SimpleNamespace(_weighted_r=lambda t: t.r_at_exit)

    # ONE dict for globals and locals: split them and the exec'd functions get
    # a __globals__ that cannot see their own siblings (_metric_of).
    g = {"__name__": "t8", "argparse": argparse, "os": os, "sys": sys}
    exec(compile(src.split("def main() -> int:")[0], F, "exec"), g)
    pse = g["_paired_se_block"]

    class T:
        def __init__(self, d, r):
            self.exit_date, self.r_at_exit = d, r

    days = pd.bdate_range("2020-01-01", periods=400)
    eq = pd.Series(1.0, index=days)
    rng = np.random.default_rng(7)
    dA = list(rng.choice(days, 200, replace=False))
    trA = [T(d, float(rng.normal(0.3, 2.0))) for d in dA]
    trB = [T(t.exit_date, t.r_at_exit + 0.05) for t in trA]   # same book, +0.05

    # POSITIVE CONTROL 1: an arm against ITSELF must be exactly zero.
    r = pse(mod, np, pd, eq, trA, eq, trA, "expectancy_R", 21, 300, 1)
    v.check("POSITIVE CONTROL identical arms -> point 0.0 and pairedSE 0.0",
            r is not None and r[0] == 0.0 and r[1] == 0.0, str(r and r[:2]))

    # POSITIVE CONTROL 2: a CONSTANT shift must be recovered exactly, with a
    # paired SE of 0 -- this is what "paired" means and what a broken pairing
    # would get wrong.
    r = pse(mod, np, pd, eq, trA, eq, trB, "expectancy_R", 21, 300, 1)
    v.check("POSITIVE CONTROL a +0.05 constant shift is recovered exactly",
            r is not None and abs(r[0] - 0.05) < 1e-12, str(r and r[0]))
    # A shifted COPY is not the same object, so the draw differences carry
    # float error (~1e-17) where identical arms give exact 0. Tolerance here,
    # exact zero for the identical-arm control above -- they are different
    # claims and only one of them can be exact.
    v.check("...and its paired SE is ~0 while the UNPAIRED SE is not",
            r is not None and r[1] < 1e-12 and r[2] > 0.0, str(r and r[1:3]))

    # FAIL CLOSED on mismatched calendars.
    r = pse(mod, np, pd, eq, trA, eq.iloc[:-5], trA, "expectancy_R", 21, 50, 1)
    v.check("different calendars -> None (fails closed, never a silent pair)",
            r is None, str(r))
    # and on a block longer than the window.
    r = pse(mod, np, pd, eq, trA, eq, trB, "expectancy_R", 9999, 50, 1)
    v.check("block longer than the window -> None", r is None, str(r))
    return v.done()


def main(argv=None):
    ap = argparse.ArgumentParser(description="S4 paired-SE patch")
    ap.add_argument("--verify", action="store_true")
    ap.add_argument("--revert", action="store_true")
    a = ap.parse_args(argv)
    _ascii_guard()
    if a.verify:
        return verify()
    apply(revert=a.revert)
    return 0


if __name__ == "__main__":
    sys.exit(main())
