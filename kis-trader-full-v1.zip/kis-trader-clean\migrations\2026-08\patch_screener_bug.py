#!/usr/bin/env python3
"""
patch_screener_bug.py -- fix `return Nones` in sp500_v21._read_finnhub_key().

WHAT IT IS
A one-character typo on the no-Finnhub-key fall-through path:

    return Nones        ->        return None

WHY IT MATTERS
_read_finnhub_key() is called at MODULE SCOPE, via `DATA = DataProxy()`. The
faulty line is only reached when FINNHUB_API_KEY is unset AND finnhub_key.txt is
absent from both the repo root and the cwd — i.e. a freshly provisioned box
before .env is written. On any machine that has a key, the function returns
early and the typo is never evaluated, which is why it survived every run to
date.

On a box without one, `import screeners.sp500_v21` raises

    NameError: name 'Nones' is not defined

and the screener cannot start. The comment directly above that line says a
missing key "keeps the graceful fallback (math floor uses yfinance)" — so the
typo inverts the documented behaviour, turning graceful degradation into a hard
crash at import.

us_small_v21.py has the correct `return None` on the same line of the same
function. The two files disagreed and nothing in the system reported it.

Found by tests/test_screener_harness.py, case S1, on its first run.

Usage:  python patch_screener_bug.py <repo-root>
"""
from __future__ import annotations

import os
import sys


def main(root):
    p = os.path.join(root, "screeners", "sp500_v21.py")
    if not os.path.isfile(p):
        raise SystemExit(f"REFUSING: not found: {p}")

    with open(p, encoding="utf-8") as f:
        s = f.read()

    old = "        except Exception:\n            pass\n    return Nones\n"
    new = "        except Exception:\n            pass\n    return None\n"

    n = s.count(old)
    if n != 1:
        if "    return Nones\n" not in s:
            raise SystemExit("REFUSING: already fixed (no `return Nones` present).")
        raise SystemExit(f"REFUSING: anchor matched {n} times, expected 1")

    with open(p, "w", encoding="utf-8", newline="") as f:
        f.write(s.replace(old, new))
    print("  ok  sp500_v21._read_finnhub_key: `return Nones` -> `return None`")
    print("\nFIXED. Verify with:  python tests/test_screener_harness.py")
    return 0


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("usage: python patch_screener_bug.py <repo-root>")
    sys.exit(main(sys.argv[1]))
