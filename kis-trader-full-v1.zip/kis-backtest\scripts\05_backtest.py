r"""
05_backtest.py -- ONE run at a FULLY STATED configuration.
Reads diag BEFORE stats.

PATCH L: every strategy parameter is a REQUIRED flag. The two usage lines
this docstring used to carry ran rank_mode=rs_only, stall_day=10,
regime_ma=None, sector_cap=2, risk=0.0075 and cap=0.20 -- six parameters
that were never stated -- and are now refused.

PATCH N: this docstring is a RAW string -- its opening triple quote
is prefixed with r, and must stay that way.
It carries Windows paths, and in a normal string `\05` is an OCTAL
escape that silently becomes chr(5) -- corrupting the very command
below -- while `\s` is an invalid escape that is a SyntaxError in a
future Python. Do not drop the leading r.

The frozen set (200 trades, +49.92%, -19.50% DD at 5 bps). ONE LINE:
this project runs PowerShell, where the continuation character is a
backtick, not a backslash, so a wrapped command does not paste.

    python scripts\05_backtest.py --rank-mode vcp_only --threshold 75 --regime-ma 20 --stall-day 252 --sector-cap 2 --risk-pct 0.0085 --max-position-pct 0.25 --signals data\signals_daily.pkl

For what the trader ACTUALLY executes rather than Rev 3, swap two flags:
--regime-ma off --sector-cap 0 (PATCH F / F3, 2026-08-25). Never merge the
two configurations in one comparison.
"""
import pathlib as _pl
import sys as _sys
_sys.path.insert(0, str(_pl.Path(__file__).resolve().parent.parent))
import argparse
import pathlib
import pickle

import pandas as pd

from minervini_backtest import (BacktestConfig, DecisionConfig, load_bars,
                                load_sector_map, run_band)


def load(signals_path="data/signals.pkl", start=None, end=None):
    # --- PATCH S --- was an inline glob, which returns EMPTY WITHOUT ERROR
    # from the wrong cwd. load_bars() refuses at the point of the mistake.
    bars = load_bars()
    prices = {t: d for t, d in bars.items() if t != "^GSPC"}   # benchmark isn't tradable
    # --- PATCH L (L1) --- the regime gate needs the benchmark. BacktestConfig
    # __post_init__ RAISES on regime_ma set with benchmark_close None, which is
    # correct fail-closed behaviour and also means --regime-ma is unusable
    # until ^GSPC is threaded through to the caller.
    bench = bars.get("^GSPC")
    with open(signals_path, "rb") as f:
        blob = pickle.load(f)
    sigs = blob["signals"]
    # Window clipping matters: a daily signal file generated from 2018 is NOT
    # comparable to a weekly one from 2015. Comparing them without clipping
    # conflates scan frequency with the period being tested.
    if start or end:
        lo = pd.Timestamp(start) if start else pd.Timestamp.min
        hi = pd.Timestamp(end) if end else pd.Timestamp.max
        n0 = len(sigs)
        sigs = {d: v for d, v in sigs.items() if lo <= pd.Timestamp(d) <= hi}
        print(f"[load] clipped signals to {lo.date() if start else 'start'}"
              f"..{hi.date() if end else 'end'}: {n0} -> {len(sigs)} date(s)")
    if sigs:
        ds = sorted(sigs)
        print(f"[load] {signals_path}: {len(sigs)} date(s) "
              f"{ds[0].date()}..{ds[-1].date()}, "
              f"{sum(len(v) for v in sigs.values())} candidate(s), "
              f"lag={blob.get('lag', 0)}")
    return prices, sigs, bench, blob


# --- PATCH L (L2) ------------------------------------------------------------
# regime_ma has THREE states and two of them used to collapse into one here:
# a window, OFF, and NOT SUPPLIED. Same parser as 06_sweep.py.
_REGIME_UNSET = object()


def _regime_ma_arg(v):
    """'off' / 'none' / '0' -> None (gate off); otherwise an int >= 2."""
    s = str(v).strip().lower()
    if s in ("off", "none", "0"):
        return None
    try:
        n = int(s)
    except ValueError:
        raise argparse.ArgumentTypeError(
            f"--regime-ma must be an integer >= 2, or off/none/0. Got {v!r}.")
    if n < 2:
        raise argparse.ArgumentTypeError(
            f"--regime-ma must be >= 2 (ExposureConfig refuses less), or "
            f"off/none/0 for no gate. Got {n}.")
    return n


# --- PATCH M --- one line, no shell-specific continuation character.
# PATCH L printed this hint with bash "\\" continuations; pasted into
# PowerShell the backslash is passed through as a literal argument and each
# following line is parsed as a separate command, so the command fails.
_FROZEN_CMD = (
    "python scripts\\05_backtest.py --rank-mode vcp_only --threshold 75 "
    "--regime-ma 20 --stall-day 252 --sector-cap 2 --risk-pct 0.0085 "
    "--max-position-pct 0.25 --signals data\\signals_daily.pkl")


def main():
    ap = argparse.ArgumentParser()
    # Every one of these is REQUIRED. Before PATCH L this script hardcoded
    # rank_mode="rs_only" and silently took stall_day=10, regime_ma=None,
    # sector_cap=2, risk=0.0075 and cap=0.20 -- so a run at "--threshold 75"
    # measured a configuration that was never shipped, and returned +0.04 R
    # against the frozen set's +0.330 R.
    ap.add_argument("--rank-mode", default=None,
                    choices=["rs_only", "vcp_only", "rs_plus_vcp"],
                    help="REQUIRED. Frozen: vcp_only. Was HARDCODED to rs_only.")
    ap.add_argument("--threshold", type=float, default=None,
                    help="REQUIRED. Frozen: 75. The old default was 80, which "
                         "Rev 3 sec.4 measured and REJECTED.")
    ap.add_argument("--regime-ma", type=_regime_ma_arg, default=_REGIME_UNSET,
                    help="REQUIRED. 20 reproduces Rev 3; 'off' is what "
                         "production has run since PATCH F3 (2026-08-25). Was "
                         "never passed at all, so the gate was always OFF.")
    ap.add_argument("--stall-day", type=int, default=None,
                    help="REQUIRED. Frozen: 252. Fell to STALL_DAY=10, measured "
                         "at -0.057 R against +0.330 R at 252.")
    ap.add_argument("--sector-cap", type=int, default=None,
                    help="REQUIRED. Production runs 0 (PATCH F); the vendored "
                         "engine defaults to 2, which is what Rev 3's published "
                         "numbers were produced with.")
    ap.add_argument("--risk-pct", type=float, default=None,
                    help="REQUIRED. Frozen: 0.0085. Vendored default: 0.0075.")
    ap.add_argument("--max-position-pct", type=float, default=None,
                    help="REQUIRED. Frozen: 0.25. Vendored default: 0.20.")
    ap.add_argument("--signals", default=None,
                    help="REQUIRED. data/signals_daily.pkl is every=1 and is "
                         "Rev 3's window natively (2018-01-02..2026-08-07); "
                         "data/signals.pkl is every=5 and starts in 2015.")
    ap.add_argument("--slippage", type=float, default=5.0,
                    help="bps per side. 5.0 is the level Rev 3's published "
                         "expectancy and drawdown both reproduce at.")
    ap.add_argument("--equity", type=float, default=100_000.0)
    ap.add_argument("--start", default=None,
                    help="clip signals to this date onward, for like-for-like "
                         "comparison between files covering different windows")
    ap.add_argument("--end", default=None)
    args = ap.parse_args()

    _FROZEN = {"rank_mode": "vcp_only", "threshold": 75.0, "regime_ma": 20,
               "stall_day": 252, "risk_pct": 0.0085, "max_position_pct": 0.25}
    _missing = []
    if args.rank_mode is None:
        _missing.append("--rank-mode          frozen vcp_only (was hardcoded rs_only)")
    if args.threshold is None:
        _missing.append("--threshold          frozen 75 (old default 80: rejected)")
    if args.regime_ma is _REGIME_UNSET:
        _missing.append("--regime-ma          20 for Rev 3, 'off' for production")
    if args.stall_day is None:
        _missing.append("--stall-day          frozen 252 (fell to 10)")
    if args.sector_cap is None:
        _missing.append("--sector-cap         2 for Rev 3, 0 for production")
    if args.risk_pct is None:
        _missing.append("--risk-pct           frozen 0.0085 (vendored 0.0075)")
    if args.max_position_pct is None:
        _missing.append("--max-position-pct   frozen 0.25 (vendored 0.20)")
    if args.signals is None:
        _missing.append("--signals            data/signals_daily.pkl is Rev 3's")
    if _missing:
        print("[backtest] REFUSING TO RUN. A run whose configuration is not "
              "stated cannot have its numbers labelled.")
        for _m in _missing:
            print("[backtest]   " + _m)
        print("[backtest] The frozen set, fully stated. ONE LINE -- "
              "PowerShell continues lines with a backtick, not a "
              "backslash:")
        print("[backtest]   " + _FROZEN_CMD)
        raise SystemExit(2)
    for _k, _v in (("rank_mode", args.rank_mode), ("threshold", args.threshold),
                   ("regime_ma", args.regime_ma), ("stall_day", args.stall_day),
                   ("risk_pct", args.risk_pct),
                   ("max_position_pct", args.max_position_pct)):
        if _v != _FROZEN[_k]:
            print("[backtest]   NOTE %s=%s is NOT the frozen value (%s). "
                  "Deliberate?" % (_k, _v, _FROZEN[_k]))
    if args.regime_ma is None:
        print("[backtest]   regime_ma=OFF matches PRODUCTION since PATCH F3. "
              "This run does NOT reproduce Rev 3, whose numbers are at 20.")
    elif args.regime_ma == 20:
        print("[backtest]   regime_ma=20 reproduces Rev 3, but production has "
              "run regime_ma=None since PATCH F3. This run measures a "
              "configuration the trader is NOT executing.")
    print("[backtest] config rank_mode=%s threshold=%s regime_ma=%s stall_day=%s "
          "sector_cap=%s risk=%s cap=%s slippage=%sbps"
          % (args.rank_mode, args.threshold, args.regime_ma, args.stall_day,
             args.sector_cap, args.risk_pct, args.max_position_pct,
             args.slippage))

    prices, signals, bench, blob = load(args.signals, args.start, args.end)
    if not signals:
        raise SystemExit("[backtest] no signals in the requested window")
    print("[backtest]   signals every=%s lag=%s generated=%s"
          % (blob.get("every", "ABSENT"), blob.get("lag", "ABSENT"),
             blob.get("generated", "ABSENT")))
    if blob.get("every") not in (1, None):
        print("[backtest]   NOTE every=%s is a rescan every %s trading days, "
              "not daily -- a lower trade count here is a SAMPLING difference, "
              "not a strategy one." % (blob.get("every"), blob.get("every")))
    if args.regime_ma is not None and bench is None:
        raise SystemExit("[backtest] --regime-ma is set but there are no ^GSPC "
                         "bars in data/bars. The gate would pass everything; "
                         "refusing rather than measuring an ungated run.")
    cfg = BacktestConfig(
        rank_mode=args.rank_mode,
        equity_mode="compounding",
        entry_mode="pivot_limit",
        ambiguity_mode="worst",
        vcp_threshold=args.threshold,
        regime_ma=args.regime_ma,
        stall_day=args.stall_day,
        slippage_bps=args.slippage,
        starting_equity=args.equity,
        sector_map=load_sector_map("data/sectors.csv"),
        decision=DecisionConfig(risk_per_trade_pct=args.risk_pct,
                                max_position_pct=args.max_position_pct,
                                sector_cap=args.sector_cap),
        benchmark_close=(bench["Close"] if bench is not None else None),
    )
# --- end PATCH L (L2) --------------------------------------------------------

    out = run_band(prices, signals, cfg)
    worst = out["worst"]
    dg, st = worst["diag"], worst["stats"]

    # ---- DIAGNOSTICS FIRST. If the caps decided everything, the stats are noise.
    print("=" * 66)
    print("DIAGNOSTICS  (read these before the numbers)")
    print("=" * 66)
    print(f"  held_ticker_time_frac : {dg['held_ticker_time_frac']}  "
          f"<- fraction of ticker-time actually invested")
    print(f"  ambiguous_bars        : {dg['ambiguous_bars']}")
    print(f"  eod_open_forced       : {dg['eod_open_forced']}")
    print(f"  partials_taken        : {dg['partials_taken']}")
    print(f"  sector_cap_measured   : {dg['sector_cap_measured']}")
    print(f"  stats window          : {dg['stats_window']} "
          f"({dg['stats_window_years']} years)  <- CAGR/Sharpe use THIS, not the")
    print(f"                          {dg['calendar_sessions']}-session bar calendar")
    print(f"  drops ({dg['drops_total']} total):")
    for k, v in dg["drops_by_reason"].items():
        flag = "   <-- CAPS ARE DECIDING, NOT THE THRESHOLD" \
               if k == "decision_engine" and v > dg["drops_total"] * 0.5 else ""
        print(f"      {v:7} x {k}{flag}")

    print("\n" + "=" * 66)
    print(f"RESULTS  threshold={args.threshold}  slippage={args.slippage}bps")
    print("=" * 66)
    for k in ("num_trades", "num_wins", "num_losses", "win_rate_pct",
              "expectancy_R", "expectancy_pct", "avg_win_pct", "avg_loss_pct",
              "total_return_pct", "cagr_pct", "max_drawdown_pct",
              "sharpe_daily_ann", "end_equity"):
        print(f"  {k:20} {st.get(k)}")
    print(f"  {'exit_reasons':20} {st.get('exit_reasons')}")

    print("\n  INTRABAR BAND (worst .. best) -- decide on the WORST column:")
    for k, v in out["band"].items():
        if isinstance(v, tuple) and len(v) == 2:
            print(f"    {k:20} {v[0]:>10} .. {v[1]:>10}")
        else:
            print(f"    {k:20} {v:>10}")
    if out["band"].get("ambiguous_bars", 0) == 0:
        print("    (band collapses: no bar was intrabar-ambiguous in this run)")

    print("\n" + "=" * 66)
    print("MANDATORY CAVEATS FOR ANY REPORT OF THIS RUN")
    print("=" * 66)
    print("  * Survivorship: today's constituents only -> absolute numbers are an")
    print("    optimistic ceiling. Run 07_survivorship.py to size the hole.")
    print("  * Stage 2 is CUT: this screens a WIDER population than production,")
    print("    so hit rates will not match the live system.")
    print(f"  * {dg['exit_rules']}")
    print("  * FX excluded -- absolute returns are wrong if the account converts")
    print("    KRW->USD per order.")


if __name__ == "__main__":
    main()
