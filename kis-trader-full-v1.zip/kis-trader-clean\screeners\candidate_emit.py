#!/usr/bin/env python3
"""
candidate_emit — screener output -> candidates.csv   (Step 3 / checklist §1.6 wiring)
=====================================================================================

The one bridge between the screener suite and the kistrader entry half. Both US
screeners (`sp500_v21.py --emit-candidates`, `us_small_v21.py --emit-candidates`)
call `emit_candidates()` at the end of a real (non-dry) run with the three data
structures that are alive at the end of main():

    stage3_results  [(ticker, name, report)]      run_stage3_vcp() return value
    passed_stocks   [(t, n, ret, cp, h20, rs, raw)]  Stage-1 survivors (rs = RS Rating)
    stage2_passed   [(ticker, name, catalyst)]     Stage-2 clears (catalyst 0..100)

It maps FINAL names (report present AND Score >= vcp_threshold) into the formal
`Candidate` schema via `screen_contract.candidate_from_report()` and writes the
CSV the pipeline's `arm_today()` reads. Fail-closed philosophy throughout:

  * a name that can't be fully specified is DROPPED WITH A PRINTED REASON,
    never written with faked fields;
  * a missing Latest_Close is passed through as close_known=False (the decision
    engine rejects it explicitly downstream — visible, not silent);
  * a ticker KIS can't trade is dropped here (it could never arm anyway); the
    pipeline's own gate re-checks regardless.

Symbology: the screeners carry yfinance-format tickers (BRK-B); the KIS
tradable universe uses slash format (BRK/B). resolve() is tried on the raw
symbol first, then on a './-' -> '/' normalization; the form that RESOLVED is
what gets written, so the pipeline gate and KIS order placement agree with the
CSV. Every normalization is logged. (Caveat: a slash-format ticker will not be
recognized by the yfinance-based trail/stall providers — those two exit rules
stay dormant for such a name, which the engine already warns about.)

Merge policy (two screeners, one CSV): rows already in the file with the SAME
session_date and a ticker NOT re-emitted by this run are PRESERVED (so sp500
and us_small union into one file); rows from any OTHER date are STALE and
dropped loudly. Re-emitted tickers are replaced by the fresh row. A run with
zero finals still rewrites the file (header + surviving same-date rows), so a
stale CSV never lingers past a real run.
"""
from __future__ import annotations

import datetime as _dt
import os
import re
from typing import Iterable, List, Optional, Tuple

from kistrader.entry.screen_contract import (Candidate, candidate_from_report,
                                             read_candidates, write_candidates,
                                             regime_path_for, write_regime)

__all__ = ["emit_candidates"]


# --------------------------------------------------------------------------
# KIS tradable-universe resolution
# --------------------------------------------------------------------------

def _load_universe():
    """Default universe = the real KIS tradable gate. Imported lazily so the
    module (and its tests) work without the full package/network."""
    try:
        from kistrader.core.kis_tradable_universe import TradableUniverse
    except ImportError as e:
        raise RuntimeError(
            "candidate_emit: cannot import kistrader.core.kis_tradable_universe "
            f"({e}). Run from the repo root with the package installed "
            "(pip install -e .), or pass universe= explicitly."
        ) from e
    u = TradableUniverse()
    u.ensure()
    return u


def _resolve_exchange(universe, ticker: str) -> Tuple[Optional[str], str, bool]:
    """Try resolve() on the raw symbol, then on the KIS slash normalization
    (BRK-B / BRK.B -> BRK/B). Returns (exchange|None, resolved_ticker, normalized?)."""
    t = ticker.strip().upper()
    ex = universe.resolve(t)
    if ex:
        return ex, t, False
    alt = re.sub(r"[.\-]", "/", t)
    if alt != t:
        ex = universe.resolve(alt)
        if ex:
            return ex, alt, True
    return None, t, False


# --------------------------------------------------------------------------
# The emitter
# --------------------------------------------------------------------------

def emit_candidates(*, stage3_results: Iterable[tuple],
                    passed_stocks: Iterable[tuple],
                    stage2_passed: Iterable[tuple],
                    out_path: str,
                    vcp_threshold: float,
                    session_date: Optional[str] = None,
                    universe=None,
                    source: str = "screener",
                    benchmark: str = "^GSPC",
                    # PATCH F4: True means "this caller knows about the regime
                    # gate", which is NOT the same as "a regime was computed".
                    # regime_ma=None is ambiguous on its own -- it means both
                    # "gate deliberately off" and "screener never taught".
                    regime_declared: bool = False,
                    regime_ma: Optional[int] = None,
                    benchmark_close: Optional[float] = None,
                    benchmark_ma: Optional[float] = None,
                    benchmark_bar_date: Optional[str] = None,
                    regime_path: Optional[str] = None,
                    log=print) -> int:
    """Write/merge candidates.csv from one screener run. Returns rows written.

    Never raises on a per-name data problem — drops the name with a printed
    reason instead (one bad name must not abort the batch). Raises only on
    infrastructure failure (universe unavailable, file unwritable)."""
    session_date = (session_date or _dt.date.today().isoformat()).strip()

    # ---- index the stage outputs -------------------------------------------------
    rs_by, name_by = {}, {}
    for row in passed_stocks:
        try:
            t, n, _ret, _cp, _h20, rs, _raw = row
        except (TypeError, ValueError):
            log(f"[emit] WARNING: unexpected passed_stocks row shape {row!r} — skipped")
            continue
        rs_by[str(t).upper()] = rs
        name_by[str(t).upper()] = n

    score_by = {}
    for row in stage2_passed:
        try:
            t, _n, s = row
        except (TypeError, ValueError):
            log(f"[emit] WARNING: unexpected stage2_passed row shape {row!r} — skipped")
            continue
        score_by[str(t).upper()] = s

    # ---- finals: report present AND cleared the VCP bar --------------------------
    finals = []
    for row in stage3_results:
        try:
            t, n, rep = row
        except (TypeError, ValueError):
            log(f"[emit] WARNING: unexpected stage3 row shape {row!r} — skipped")
            continue
        if rep is None:
            continue                                    # fetch/engine failure — not a final
        if rep.get("Score", 0) < vcp_threshold:
            continue                                    # below the bar — not a final
        finals.append((str(t).upper(), n, rep))

    if universe is None and finals:
        universe = _load_universe()

    # ---- build Candidates, fail-closed per name -----------------------------------
    new_by_ticker = {}          # resolved_ticker -> Candidate
    dropped: List[Tuple[str, str]] = []

    for t, n, rep in finals:
        rs = rs_by.get(t)
        if rs is None:
            dropped.append((t, "no RS Rating in Stage-1 output (internal mismatch)"))
            continue
        s2 = score_by.get(t)
        if s2 is None:
            dropped.append((t, "no Stage-2 catalyst score (dry-run leak or internal mismatch)"))
            continue

        ex, resolved, normalized = _resolve_exchange(universe, t)
        if not ex:
            dropped.append((t, "not KIS-tradable (universe.resolve failed, incl. slash form)"))
            continue
        if normalized:
            log(f"[emit] NOTE: {t} resolved as KIS symbol {resolved} ({ex}) — slash "
                f"normalization applied; yfinance-based trail/stall providers will not "
                f"recognize this symbol.")

        c = candidate_from_report(resolved, ex, int(rs), float(s2), rep,
                                  session_date, name=str(n or ""))
        probs = c.problems()
        if probs:
            dropped.append((t, "; ".join(probs)))
            continue
        if not c.close_known:
            log(f"[emit] NOTE: {resolved} has NO Latest_Close in its report — emitted with "
                f"close_known=0; the decision engine will fail closed on it unless "
                f"allow_missing_close is set.")
        if resolved in new_by_ticker:                    # defensive: keep higher VCP
            if c.vcp_score <= new_by_ticker[resolved].vcp_score:
                continue
        new_by_ticker[resolved] = c

    # ---- merge with the existing file (cross-screener union, stale purge) ---------
    kept, stale, malformed = [], 0, 0
    if os.path.exists(out_path):
        def _bad(_row, _why):
            nonlocal malformed
            malformed += 1
        try:
            for old in read_candidates(out_path, on_bad=_bad):
                if old.session_date != session_date:
                    stale += 1
                elif old.ticker in new_by_ticker:
                    pass                                 # replaced by the fresh row
                else:
                    kept.append(old)
        except Exception as e:                           # unreadable file -> rewrite fresh
            log(f"[emit] WARNING: could not read existing {out_path} ({e}) — rewriting fresh.")
            kept, stale, malformed = [], 0, 0

    merged = kept + list(new_by_ticker.values())
    merged.sort(key=lambda c: (-c.vcp_score, c.ticker))
    n_written = write_candidates(out_path, merged)

    # ---- regime provenance sidecar (Phase 3a) ------------------------------------
    # PATCH F4 -- the sidecar is the RECEIPT, not the regime. It carries the
    # session date, who wrote it, the vcp_threshold actually applied and whether
    # this was an --emit-threshold plumbing run. Those protect the trader
    # whether or not a regime is being computed; only the benchmark block is
    # regime-specific, and with the gate off it is simply null.
    #
    # Before F4 this was `if regime_ma is not None`, so turning the gate off
    # (F3) stopped the receipt being written, and F2's "no receipt -> do not
    # arm" rule then blocked the trader permanently. A screener that was never
    # taught the gate still writes nothing, which is the original intent.
    if regime_ma is not None or regime_declared:
        name, _, tail = str(source).partition(" ")
        degraded = None
        if "DEGRADED@" in tail:
            try:
                degraded = float(tail.split("DEGRADED@", 1)[1].split()[0])
            except (IndexError, ValueError):
                degraded = -1.0        # unparseable, but still a degraded run
        rp = regime_path or regime_path_for(out_path)
        doc = write_regime(rp, session_date=session_date, screener=name,
                           vcp_threshold=vcp_threshold, benchmark=benchmark,
                           regime_ma=regime_ma,
                           benchmark_close=benchmark_close,
                           benchmark_ma=benchmark_ma,
                           bar_date=benchmark_bar_date,
                           emitted=n_written, degraded_threshold=degraded,
                           log=log)
        if regime_ma is None:                            # PATCH F4
            log(f"[regime] gate OFF (regime_ma=null) -- handshake receipt "
                f"written for {name} -> {rp}")
        else:
            log(f"[regime] {doc['state']} -- {benchmark} close={benchmark_close} "
                f"ma{regime_ma}={benchmark_ma} bar={benchmark_bar_date} -> {rp}")

    # ---- summary -------------------------------------------------------------------
    log(f"[emit] {source}: {len(finals)} final(s) -> {len(new_by_ticker)} candidate(s) "
        f"emitted for {session_date}; {len(kept)} same-date row(s) preserved from an "
        f"earlier run; {stale} stale row(s) dropped"
        + (f"; {malformed} malformed row(s) ignored" if malformed else "")
        + f". Wrote {n_written} row(s) -> {out_path}")
    for t, why in dropped:
        log(f"[emit]   dropped {t}: {why}")
    return n_written
