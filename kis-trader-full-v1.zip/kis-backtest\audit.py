"""Audit of the changes made in this session. Verifies arithmetic by hand."""
import numpy as np, pandas as pd
from minervini_backtest import BTCandidate, BacktestConfig, run, run_band

DATES = pd.bdate_range("2024-01-02", periods=60)


def ohlc(dates, closes, open_override=None):
    c = np.asarray(closes, float); o = np.r_[c[0], c[:-1]]
    if open_override:
        o = o.copy()
        for i, v in open_override.items():
            o[i] = v
    h = np.maximum(o, c) * 1.01
    l = np.minimum(o, c) * 0.99
    if open_override:                      # keep H/L consistent with forced opens
        h = np.maximum(h, o); l = np.minimum(l, o)
    return pd.DataFrame({"Open": o, "High": h, "Low": l, "Close": c}, index=dates)


def cand(t="A", price=100.0):
    return BTCandidate(ticker=t, exchange="NAS", pivot=price,
                       contraction_low=price * 0.95, atr=price * 0.02,
                       last_close=price * 0.99, rs_rating=90, vcp_score=85.0,
                       session_date="2024-01-02")


def cfg(**kw):
    d = dict(rank_mode="rs_only", sector_map={"A": "Tech"})
    d.update(kw)
    return BacktestConfig(**d)


# ---------- 1. entry has NO adverse slippage; exit does ----------
def test_entry_no_slippage():
    c = np.r_[99, 101, 102, 96, 90, np.linspace(89, 80, 55)]
    p = {"A": ohlc(DATES, c)}
    eq, tr, st, dr, dg = run(p, {DATES[0]: [cand()]},
                             cfg(slippage_bps=50, broker_commission_pct=0,
                                 sec_fee_pct=0, taf_per_share=0))
    t = tr[0]
    assert abs(t.entry_price - 100.5) < 1e-9, t.entry_price          # limit exactly
    assert abs(t.exit_price - 94.53 * (1 - 50 / 1e4)) < 1e-9, t.exit_price
    print(f"PASS  entry fills at limit {t.entry_price} (no slip); "
          f"exit slipped to {t.exit_price:.4f}")


# ---------- 2. cost arithmetic, verified by hand ----------
def test_cost_arithmetic():
    c = np.r_[99, 101, 102, 96, 90, np.linspace(89, 80, 55)]
    p = {"A": ohlc(DATES, c)}
    eq, tr, st, dr, dg = run(p, {DATES[0]: [cand()]}, cfg(slippage_bps=0))
    t = tr[0]
    sh, entry, exit_ = t.shares, t.entry_price, t.exit_price
    buy_notional, sell_notional = sh * entry, sh * exit_
    # read the rates from the config rather than hardcoding them -- an earlier
    # version hardcoded 0.0025 and silently diverged when the real KIS rate was
    # applied, so the test failed for the wrong reason
    c = cfg(slippage_bps=0)
    buy_fee = buy_notional * c.broker_commission_pct
    sell_fee = (sell_notional * (c.broker_commission_pct + c.sec_fee_pct)
                + min(sh * c.taf_per_share, c.taf_cap_per_trade))
    expected_end = 100_000 - buy_notional - buy_fee + sell_notional - sell_fee
    assert abs(eq.iloc[-1] - expected_end) < 1e-6, (eq.iloc[-1], expected_end)
    print(f"PASS  cost arithmetic: buy fee ${buy_fee:.2f}, sell fee ${sell_fee:.2f}, "
          f"end equity ${eq.iloc[-1]:,.2f} matches hand calc")


# ---------- 3. TAF cap binds on a huge share count ----------
def test_taf_cap():
    from minervini_backtest import BacktestConfig as BC
    c0 = BC(rank_mode="rs_only", sector_map={"A": "T"})
    shares_needed = int(c0.taf_cap_per_trade / c0.taf_per_share) + 1000
    uncapped = shares_needed * c0.taf_per_share
    capped = min(uncapped, c0.taf_cap_per_trade)
    assert capped == c0.taf_cap_per_trade < uncapped
    print(f"PASS  TAF caps at ${capped} above {int(c0.taf_cap_per_trade/c0.taf_per_share):,} "
          f"shares (uncapped would be ${uncapped:.2f})")


# ---------- 4. gap above limit: worst=no fill, best=fill on pullback ----------
def test_gap_above_limit_both_modes():
    # bar1 opens at 115 (above the 100.5 limit) but its LOW dips to 99 -> pullback
    c = np.r_[99, 118, np.linspace(119, 160, 58)]
    df = ohlc(DATES, c, open_override={1: 115.0})
    df.iloc[1, df.columns.get_loc("Low")] = 99.0          # force the pullback
    p = {"A": df}
    out = run_band(p, {DATES[0]: [cand()]}, cfg(slippage_bps=0))
    n_worst = out["worst"]["stats"]["num_trades"]
    n_best = out["best"]["stats"]["num_trades"]
    assert n_worst == 0 and n_best == 1, (n_worst, n_best)
    assert out["worst"]["diag"]["ambiguous_bars"] >= 1
    assert out["worst"]["diag"]["drops_by_reason"].get("gap_above_limit") == 1
    print(f"PASS  gap-above-limit is now an AMBIGUITY: worst={n_worst} fills, "
          f"best={n_best} fills (entry_manager places the resting limit)")


# ---------- 5. no pullback -> no fill in either mode ----------
def test_gap_no_pullback():
    c = np.r_[99, 118, np.linspace(119, 160, 58)]
    df = ohlc(DATES, c, open_override={1: 115.0})
    df.iloc[1, df.columns.get_loc("Low")] = 114.0         # never returns to 100.5
    out = run_band({"A": df}, {DATES[0]: [cand()]}, cfg(slippage_bps=0))
    assert out["worst"]["stats"]["num_trades"] == 0
    assert out["best"]["stats"]["num_trades"] == 0
    print("PASS  gap with no pullback -> unfilled in BOTH bounds")


# ---------- 6. partial sale pays sell-side fees too ----------
def test_partial_pays_fees():
    c = np.r_[99, 101, 125, 124, 100, np.linspace(99, 90, 55)]
    p = {"A": ohlc(DATES, c)}
    eq, tr, st, dr, dg = run(p, {DATES[0]: [cand()]}, cfg(slippage_bps=0))
    assert dg["partials_taken"] == 1
    # 125 shares -> partial 41, runner 84
    assert tr[0].shares == 84, tr[0].shares
    print("PASS  partial (41 sh) and runner (84 sh) both charged sell-side fees")


if __name__ == "__main__":
    for fn in (test_entry_no_slippage, test_cost_arithmetic, test_taf_cap,
               test_gap_above_limit_both_modes, test_gap_no_pullback,
               test_partial_pays_fees):
        fn()
    print("\nAUDIT PASSED")
