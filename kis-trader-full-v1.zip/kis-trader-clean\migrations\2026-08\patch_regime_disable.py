#!/usr/bin/env python3
"""
patch_regime_disable.py -- make ExposureConfig(regime_ma=None) actually work.

THE BUG
`regime_ma = None` is the documented one-value disable for the whole regime
phase. exposure_controller.py's docstring calls it "a true no-op ... so the whole
phase is reversible with one value"; the Production Integration Plan calls it the
deployment control; test_e7_regime_gate(f) proves the TRADER honours it.

The SCREENERS did not. `_load_regime_params()` returns ExposureConfig().regime_ma
verbatim, and `_regime_probe` then evaluates `len(closes) < regime_ma`:

    TypeError: '<' not supported between instances of 'int' and 'NoneType'

raised inside main(), so the screener does not run at all. The escape hatch was
the thing that broke.

WHY IT MATTERS FOR THE SOAK
This is the switch you reach for when the benchmark sits below its MA for weeks
and the soak produces no entry-lifecycle data, or when Phase 3 needs rolling back
under time pressure. Both are exactly the moments to not discover a TypeError.

THE FIX
`_regime_probe` returns state "disabled" immediately when regime_ma is None, and
the gate treats "disabled" like "risk_on". Everything downstream already handles
it correctly and needs no change:

  * `_regime_kw` carries regime_ma=None, and emit_candidates only writes the
    sidecar `if regime_ma is not None` -- so no sidecar is produced;
  * the trader's ExposureController.decide() short-circuits to RISK_ON on
    regime_ma=None before it looks at the numbers, so a missing sidecar is
    irrelevant;
  * read_regime(expected_regime_ma=None) means "do not check".

The probe also returns index_df=None, so run_stage3_vcp fetches the benchmark
itself exactly as it did before Phase 3b. That is what "reproduces today's
behaviour exactly" has to mean.

The banner prints REGIME GATE: DISABLED rather than pretending it evaluated
something, so a disabled gate is visible in the run log instead of looking like
a permanently bullish market.

Anchors are asserted; edits are applied bottom-up.

Usage:  python patch_regime_disable.py <repo-root>
"""
from __future__ import annotations

import os
import sys

OLD_HEAD = '''    once per run, not twice."""
    import datetime as _d
'''

NEW_HEAD = '''    once per run, not twice.

    regime_ma=None DISABLES the gate. That is the documented one-value rollback
    for the whole regime phase, so it has to be handled here rather than reaching
    the arithmetic below -- `len(closes) < None` is a TypeError, raised inside
    main(), which stops the screener from running at all. Returning index_df=None
    also hands the benchmark fetch back to run_stage3_vcp, exactly as before
    Phase 3b."""
    import datetime as _d
    if regime_ma is None:
        return ("disabled", None, None, None, None,
                "regime gate DISABLED (regime_ma=None) — scanning without it")
'''

OLD_GATE = '''    if _state != "risk_on":
'''

NEW_GATE = '''    if _state not in ("risk_on", "disabled"):
'''

OLD_BANNER = '''    print(f"REGIME GATE: {_state.upper()} -- {_why}")
'''

NEW_BANNER = '''    print(f"REGIME GATE: {_state.upper()} -- {_why}")
    if _state == "disabled":
        print("  NOTE: no sidecar will be written; the trader must also be "
              "running ExposureConfig(regime_ma=None) or it will fail closed.")
'''

HARNESS = '''def test_regime_gate_can_be_disabled():
    """regime_ma=None is the documented one-value rollback for the whole regime
    phase, and it must not be the thing that breaks.

    Before this fix the screener raised
        TypeError: '<' not supported between instances of 'int' and 'NoneType'
    inside main(), so flipping the switch stopped the screener running at all --
    the escape hatch, unusable at exactly the moment you would reach for it."""
    print("S12 regime_ma=None disables the gate instead of crashing")
    if not _have_pandas():
        check("pandas available", False, "pandas not installed"); return
    sp, us, err = _import_screeners()
    if err:
        check("screeners importable", False, str(err)); return

    for name, mod in (("sp500_v21", sp), ("us_small_v21", us)):
        mod._fetch_history = lambda *a, **k: _bench_frame([100.0] * 30)
        try:
            st, c, m, b, df, why = mod._regime_probe(None, "2026-08-14", 5)
            ok, detail = st == "disabled", f"state={st}"
        except Exception as e:
            ok, detail = False, f"{type(e).__name__}: {e}"
        check(f"{name}: regime_ma=None -> 'disabled', not a crash", ok, detail)
        if ok:
            check(f"{name}: hands the benchmark fetch back to Stage 3",
                  df is None and c is None and m is None, f"{(c, m, df is None)}")
            check(f"{name}: the reason says DISABLED", "DISABLED" in why, why)

    # and main() must SCAN rather than gate
    import tempfile
    cwd, saved_stdout = os.getcwd(), sys.stdout
    try:
        sp, _us, err = _import_screeners()
        if err:
            check("screeners importable", False, str(err)); return
        sp._fetch_history = lambda *a, **k: _bench_frame([100.0] * 30)
        sp._load_regime_params = lambda: (None, 5)
        hit = []

        def _boom(*a, **k):
            hit.append(1)
            raise RuntimeError("scan reached")
        sp.run_parallel_scan = _boom
        sp.calculate_spy_6m_return = _boom
        work = tempfile.mkdtemp()
        os.chdir(work)
        try:
            sp.main(emit_path=os.path.join(work, "candidates.csv"),
                    session_date="2026-08-14")
        except RuntimeError:
            pass
        except Exception as e:
            check("main() survives a disabled gate", False, f"{type(e).__name__}: {e}")
        os.chdir(cwd)
        check("disabled gate does NOT block the scan", bool(hit), f"hit={hit}")
        check("disabled gate writes NO sidecar (the trader must be disabled too)",
              not os.path.exists(os.path.join(work, "regime.json")))
    finally:
        os.chdir(cwd)
        sys.stdout = saved_stdout


'''


def edit(text, old, new, label):
    n = text.count(old)
    if n != 1:
        raise SystemExit(f"REFUSING: anchor for {label} matched {n} times, expected 1")
    print(f"  ok  {label}")
    return text.replace(old, new)


def read(p):
    with open(p, encoding="utf-8") as f:
        return f.read()


def write(p, s):
    with open(p, "w", encoding="utf-8", newline="") as f:
        f.write(s)


def main(root):
    files = [os.path.join(root, "screeners", f)
             for f in ("sp500_v21.py", "us_small_v21.py")]
    th = os.path.join(root, "tests", "test_screener_harness.py")
    for p in files + [th]:
        if not os.path.isfile(p):
            raise SystemExit(f"REFUSING: not found: {p}")
    if any('return ("disabled"' in read(p) for p in files):
        raise SystemExit("REFUSING: already applied.")
    if "_regime_probe" not in read(files[0]):
        raise SystemExit("REFUSING: Phase 3b has not been applied.")

    for p in files:
        print(f"{os.path.basename(p)}  ({p})")
        s = read(p)
        # bottom-up
        s = edit(s, OLD_BANNER, NEW_BANNER, "banner: say DISABLED, and warn about the trader")
        s = edit(s, OLD_GATE, NEW_GATE, "gate: treat 'disabled' like risk_on")
        s = edit(s, OLD_HEAD, NEW_HEAD, "_regime_probe: short-circuit on regime_ma=None")
        write(p, s)

    print(f"test_screener_harness.py  ({th})")
    t = read(th)
    if "test_regime_gate_can_be_disabled" in t:
        raise SystemExit("REFUSING: harness already patched.")
    t = edit(t, "    test_run_log_tee_cannot_kill_a_run()\n",
             "    test_run_log_tee_cannot_kill_a_run()\n"
             "    test_regime_gate_can_be_disabled()\n",
             "register S12 in main()")
    t = edit(t, "def test_screener_harness():", HARNESS + "def test_screener_harness():",
             "insert S12")
    write(th, t)
    print("\nAPPLIED. regime_ma=None now disables the gate in the screeners too.")
    return 0


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("usage: python patch_regime_disable.py <repo-root>")
    sys.exit(main(sys.argv[1]))
