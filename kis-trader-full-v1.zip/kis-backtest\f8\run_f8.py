#!/usr/bin/env python3
"""
F8 -- differential runner.

    python run_f8.py --prod-root C:\\Users\\user\\kis-trader-clean
    python run_f8.py --prod-root ... --tick-path olhc
    python run_f8.py --prod-root ... --harness C:\\...\\kis-backtest\\minervini_backtest.py

With no --harness it runs the PRODUCTION side only and checks it against each
case's stated expectation. That is the reference half of F8: it proves the
fixture drives the real engine and that its expected answers are the engine's
answers, so that when the harness is attached, any disagreement is the harness's.

Exit status: 0 = every check passed, 1 = at least one failed.
"""
from __future__ import annotations

import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from engine_side import EngineExitRunner, load_production, loaded_from   # noqa: E402
import cases as C                                                        # noqa: E402


PASS, FAIL = [], []


def check(name, cond, detail=""):
    (PASS if cond else FAIL).append(name)
    mark = "PASS" if cond else "FAIL"
    print(f"    [{mark}] {name}" + (f"   ({detail})" if detail and not cond else ""))


def approx(a, b, tol=1e-6):
    if a is None or b is None:
        return a is None and b is None
    return abs(float(a) - float(b)) <= tol


def fmt(v, nd=2):
    return "-" if v is None else (f"{v:.{nd}f}" if isinstance(v, float) else str(v))


def run_production(E, case, default_path):
    runner = EngineExitRunner(E, stall_day=case.stall_day,
                              tick_path=case.tick_path or default_path)
    return runner.run(case.bars, entry_price=C.ENTRY, stop_price=C.STOP,
                      shares=case.shares, emas=case.emas)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--prod-root", required=True,
                    help="path to kis-trader-clean (the PRODUCTION repo)")
    ap.add_argument("--harness", default=None,
                    help="path to minervini_backtest.py (omit to run production only)")
    ap.add_argument("--tick-path", default="worst", choices=("worst", "olhc", "ohlc"))
    ap.add_argument("--only", default=None, help="comma-separated case keys")
    args = ap.parse_args()

    E, P = load_production(args.prod_root)

    print("=" * 78)
    print("F8 -- HARNESS EXIT ENGINE vs engine_v2   (differential fixture)")
    print("=" * 78)
    print(f"  production engine_v2 : {loaded_from(E)}")
    print(f"  production providers : {loaded_from(P)}")
    print(f"  harness              : {args.harness or '<not attached -- production side only>'}")
    print(f"  tick_path            : {args.tick_path}")
    print(f"  geometry             : entry {C.ENTRY} stop {C.STOP} risk {C.RISK}/sh "
          f"shares {C.SHARES}  (+3R = {C.ENTRY + 3 * C.RISK})")
    print(f"  engine constants     : R_PARTIAL_MULTIPLE={E.R_PARTIAL_MULTIPLE} "
          f"PARTIAL_FRACTION={E.PARTIAL_FRACTION:.4f} STALL_R_FLOOR={E.STALL_R_FLOOR} "
          f"EMA_LEN={E.EMA_LEN} STALL_DAY(default)={E.STALL_DAY}")
    print("=" * 78)

    harness = None
    if args.harness:
        from harness_side import load_harness_adapter
        harness = load_harness_adapter(args.harness, args.prod_root)
        print(f"  harness adapter      : {harness.describe()}")
        print("=" * 78)

    wanted = set(args.only.split(",")) if args.only else None
    rows = []

    for case in C.ALL:
        if wanted and case.key not in wanted:
            continue
        tag = "" if case.core_eight else "  (extra)"
        print(f"\n[{case.key}] {case.title}   stall_day={case.stall_day}"
              f"{'  tick_path=' + case.tick_path if case.tick_path else ''}{tag}")
        for line in _wrap(case.note, 74):
            print(f"      {line}")

        t = run_production(E, case, args.tick_path)
        print(f"    engine_v2 -> reason={t.exit_reason} bar={t.exit_bar} "
              f"price={fmt(t.exit_price)} R={fmt(t.r_multiple, 4)} "
              f"state={t.final_state} days_held={t.days_held}")
        if t.legs:
            print("      legs: " + "; ".join(
                f"bar{b} {q}sh @ {p:.2f} [{tg}]" for b, q, p, tg in t.legs))
        if t.engine_limits:
            print("      engine limits actually sent: " + "; ".join(
                f"bar{b} {lim:.2f}" for b, lim in t.engine_limits))

        if case.core_eight or case.expect_reason is not None or case.expect_r is not None:
            if case.key != "3b":
                check(f"{case.key}: exit_reason", t.exit_reason == case.expect_reason,
                      f"got {t.exit_reason}, expected {case.expect_reason}")
                check(f"{case.key}: exit_bar", t.exit_bar == case.expect_bar,
                      f"got {t.exit_bar}, expected {case.expect_bar}")
                if case.expect_price is not None or t.exit_price is not None:
                    check(f"{case.key}: exit_price", approx(t.exit_price, case.expect_price, 1e-4),
                          f"got {t.exit_price}, expected {case.expect_price}")
                if case.expect_r is not None:
                    check(f"{case.key}: realised R", approx(t.r_multiple, case.expect_r, 1e-3),
                          f"got {t.r_multiple}, expected {case.expect_r}")

        h = None
        if harness is not None:
            h = harness.run(case)
            print(f"    harness   -> reason={h.exit_reason} bar={h.exit_bar} "
                  f"price={fmt(h.exit_price)} R={fmt(h.r_multiple, 4)}")
            if getattr(h, "note", ""):
                print(f"      note: {h.note}")
            if case.tick_path:
                # A convention probe, not a diff case. The engine side runs a
                # COHERENT intraday path; the harness's 'best' is an explicit
                # BOUND (its own docstring: "neither run is a coherent intraday
                # path"). Comparing them as if they were the same claim would be
                # a category error, so this is reported, never asserted.
                print(f"      BOUND COMPARISON (not an agreement test): engine "
                      f"tick_path={case.tick_path} vs harness ambiguity_mode=best "
                      f"-> {t.key()} vs {h.key()}")
            elif case.differs:
                # a KNOWN, characterised difference: pin the harness's values so
                # the divergence is regression-guarded, not merely tolerated
                print(f"      KNOWN DIFFERENCE: {case.differs}")
                check(f"{case.key}: harness reason pinned", h.exit_reason == case.h_reason,
                      f"got {h.exit_reason}, pinned {case.h_reason}")
                check(f"{case.key}: harness bar pinned", h.exit_bar == case.h_bar,
                      f"got {h.exit_bar}, pinned {case.h_bar}")
                check(f"{case.key}: harness price pinned",
                      approx(h.exit_price, case.h_price, 1e-4),
                      f"got {h.exit_price}, pinned {case.h_price}")
                check(f"{case.key}: harness R pinned",
                      approx(h.r_multiple, case.h_r, 1e-3),
                      f"got {h.r_multiple}, pinned {case.h_r}")
            else:
                check(f"{case.key}: ENGINES AGREE on (reason, bar)", t.key() == h.key(),
                      f"engine {t.key()} vs harness {h.key()}")
                if t.r_multiple is not None and h.r_multiple is not None:
                    check(f"{case.key}: ENGINES AGREE on realised R",
                          approx(t.r_multiple, h.r_multiple, 1e-3),
                          f"engine {t.r_multiple} vs harness {h.r_multiple}")
                hr = getattr(h, "harness_r_at_exit", None)
                if hr is not None and h.r_multiple is not None and not approx(hr, h.r_multiple, 1e-3):
                    print(f"      ACCOUNTING GAP: the harness's own Trade.r_at_exit is "
                          f"{hr:+.3f} (final leg only) vs {h.r_multiple:+.3f} "
                          f"share-weighted -- the +3R partial never enters a Trade record")
            if t.exit_price is not None and h.exit_price is not None:
                same = approx(t.exit_price, h.exit_price, 1e-4)
                print(f"      price: engine {t.exit_price:.4f} vs harness "
                      f"{h.exit_price:.4f}  -> {'same' if same else 'DIFFERENT (reported, not asserted)'}")

        rows.append((case, t, h))

    print("\n" + "=" * 78)
    print("SUMMARY")
    print("=" * 78)
    hdr = f"{'case':<5}{'stall':>6}  {'engine reason':<13}{'bar':>4}{'price':>9}{'R':>8}"
    if harness is not None:
        hdr += f"   {'harness reason':<15}{'bar':>4}{'price':>9}{'R':>8}  agree"
    print(hdr)
    for case, t, h in rows:
        line = (f"{case.key:<5}{case.stall_day:>6}  {str(t.exit_reason):<13}"
                f"{str(t.exit_bar):>4}{fmt(t.exit_price):>9}{fmt(t.r_multiple, 3):>8}")
        if harness is not None and h is not None:
            line += (f"   {str(h.exit_reason):<15}{str(h.exit_bar):>4}"
                     f"{fmt(h.exit_price):>9}{fmt(h.r_multiple, 3):>8}"
                     f"  {'PINNED' if case.differs else ('yes' if t.key() == h.key() else 'NO')}")
        print(line)

    print("=" * 78)
    print(f"PASSED {len(PASS)} / {len(PASS) + len(FAIL)}")
    if FAIL:
        print("FAILED: " + "; ".join(FAIL))
    print("=" * 78)
    return 1 if FAIL else 0


def _wrap(text, width):
    out, line = [], ""
    for w in text.split():
        if len(line) + len(w) + 1 > width:
            out.append(line)
            line = w
        else:
            line = (line + " " + w).strip()
    if line:
        out.append(line)
    return out


if __name__ == "__main__":
    sys.exit(main())
