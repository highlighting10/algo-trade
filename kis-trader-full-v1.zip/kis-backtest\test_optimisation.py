"""Prove the mark-to-market optimisation changes nothing but speed."""
import importlib.util
import pathlib
import sys
import time

import numpy as np
import pandas as pd


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(spec)
    sys.modules[name] = m
    spec.loader.exec_module(m)
    return m


# Build the baseline from the CURRENT file with ONLY the mark-closes loop
# reverted. A frozen snapshot rots: it accumulates every unrelated change made
# since, and starts failing for reasons that have nothing to do with the
# optimisation under test.
_SRC = pathlib.Path("minervini_backtest.py").read_text()
_NEW = '''        for tkr in positions:
            df = prices.get(tkr)
            if df is not None and d in df.index:
                last_close[tkr] = float(df.at[d, "Close"])'''
_OLD = '''        for tkr, df in prices.items():
            if d in df.index:
                last_close[tkr] = float(df.at[d, "Close"])'''
assert _NEW in _SRC, "optimised loop not found -- did the code change?"
pathlib.Path("/tmp/mb_before.py").write_text(_SRC.replace(_NEW, _OLD))
BEFORE = load("/tmp/mb_before.py", "mb_before")
AFTER = load("minervini_backtest.py", "mb_after")

# a universe wide enough that marking-everything actually costs something
D = pd.bdate_range("2020-01-02", periods=1200)
N = 300
rng = np.random.default_rng(5)
PRICES, SECT = {}, {}
secs = ["Tech", "Health", "Energy", "Financials", "Utilities", "Materials"]
for i in range(N):
    t = f"S{i:03d}"
    c = 50 * np.cumprod(1 + rng.normal(0.0005 - i * 1e-6, 0.017, len(D)))
    o = np.r_[c[0], c[:-1]]
    PRICES[t] = pd.DataFrame(
        {"Open": o, "High": np.maximum(o, c) * 1.008,
         "Low": np.minimum(o, c) * 0.992, "Close": c}, index=D)
    SECT[t] = secs[i % len(secs)]


def build_signals(mod):
    sigs = {}
    for k in range(0, len(D) - 30, 10):
        d = D[k]
        row = []
        for i, t in enumerate(list(PRICES)[:60]):
            win = PRICES[t]["Close"].iloc[max(0, k - 20):k + 1]
            px = float(win.max()) if len(win) else 100.0
            row.append(mod.BTCandidate(
                ticker=t, exchange="NAS", pivot=px, contraction_low=px * 0.95,
                atr=px * 0.02, last_close=px * 0.99, rs_rating=99 - i % 30,
                vcp_score=90.0 - (i % 25), session_date=str(d.date())))
        sigs[d] = row
    return sigs


def cfg_for(mod):
    return mod.BacktestConfig(rank_mode="rs_only", equity_mode="compounding",
                              entry_mode="pivot_limit", ambiguity_mode="worst",
                              vcp_threshold=70.0, slippage_bps=5.0,
                              sector_map=SECT, decision=mod.DecisionConfig())


results = {}
for label, mod in (("before", BEFORE), ("after", AFTER)):
    sigs = build_signals(mod)
    t0 = time.time()
    eq, tr, st, dr, dg = mod.run(PRICES, sigs, cfg_for(mod))
    dt = time.time() - t0
    results[label] = (eq, tr, st, dg, dt)
    print(f"{label:7} {dt:7.2f}s   trades={st['num_trades']}  "
          f"end_equity={st['end_equity']}")

(eqb, trb, stb, dgb, tb) = results["before"]
(eqa, tra, sta, dga, ta) = results["after"]

print()
assert stb == sta, "STATS DIFFER"
print("  stats dict           : IDENTICAL")
assert len(trb) == len(tra), "trade count differs"
for x, y in zip(trb, tra):
    assert (x.ticker, x.entry_date, x.exit_date, x.entry_price,
            x.exit_price, x.shares, x.reason) == \
           (y.ticker, y.entry_date, y.exit_date, y.entry_price,
            y.exit_price, y.shares, y.reason), f"trade differs: {x} vs {y}"
print(f"  all {len(trb)} trades      : IDENTICAL (ticker/dates/prices/shares/reason)")
assert eqb.equals(eqa), "equity curve differs"
print("  equity curve         : IDENTICAL")
for k in ("drops_by_reason", "ambiguous_bars", "eod_open_forced",
          "partials_taken", "held_ticker_time_frac"):
    assert dgb[k] == dga[k], f"diag {k} differs: {dgb[k]} vs {dga[k]}"
print("  diagnostics          : IDENTICAL")
print(f"\n  SPEEDUP: {tb/ta:.1f}x  ({tb:.2f}s -> {ta:.2f}s on {N} tickers x {len(D)} sessions)")
print("\nEQUIVALENCE PROVEN")
