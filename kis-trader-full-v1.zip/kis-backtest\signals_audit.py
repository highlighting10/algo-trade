"""signals_audit -- what is in data/signals.pkl, and how was it made?

Run from the kis-backtest root. Unpickling imports minervini_backtest (the
stored objects are BTCandidate), which needs the vendored kistrader that lives
there -- so the working directory matters.
"""
import pickle, sys, collections

def main():
    path = sys.argv[1] if len(sys.argv) > 1 else "data/signals.pkl"
    b = pickle.load(open(path, "rb"))
    sig = b["signals"]
    ds = sorted(sig)
    cand = [c for v in sig.values() for c in v]
    n = len(cand)

    print("=" * 66)
    print("  HOW IT WAS MADE  (04_signals.py records this)")
    print("=" * 66)
    print("  keys         : %s" % list(b))
    print("  every        : %s   <- 1 = daily rescan, 5 = weekly (the default)"
          % b.get("every", "ABSENT"))
    print("  lag          : %s   <- 1 models a yfinance publication delay"
          % b.get("lag", "ABSENT"))
    print("  generated    : %s" % b.get("generated", "ABSENT"))
    print("  scan_dates   : %d" % len(b.get("scan_dates", [])))
    print()
    print("  signal dates : %d   %s .. %s" % (len(ds), ds[0].date(), ds[-1].date()))
    print("  candidates   : %d   (%.1f per signal date)" % (n, n / max(len(ds), 1)))
    print("  distinct tkrs: %d" % len({c.ticker for c in cand}))

    gaps = [(ds[i + 1] - ds[i]).days for i in range(len(ds) - 1)]
    if gaps:
        gaps.sort()
        print("  calendar gap between scans: median %d d, min %d, max %d"
              % (gaps[len(gaps) // 2], gaps[0], gaps[-1]))

    print()
    print("=" * 66)
    print("  SIGNAL DATES PER YEAR   (~252 trading days/yr; every=1 -> ~252)")
    print("=" * 66)
    per = collections.Counter(d.year for d in ds)
    for y in sorted(per):
        print("    %d  %4d dates" % (y, per[y]))

    print()
    print("=" * 66)
    print("  WHERE THE POPULATION GOES  (vcp_score gate)")
    print("=" * 66)
    s = sorted(c.vcp_score for c in cand)
    for t in (55, 60, 65, 70, 75, 80, 85):
        k = sum(1 for x in s if x >= t)
        mark = "   <- FROZEN" if t == 75 else ""
        print("    vcp >= %2d : %7d  (%5.2f%%)%s" % (t, k, 100.0 * k / max(n, 1), mark))
    if s:
        q = lambda p: s[min(int(p * len(s)), len(s) - 1)]
        print("    score p50 %.1f   p90 %.1f   p99 %.1f   max %.1f"
              % (q(.50), q(.90), q(.99), s[-1]))
    print("=" * 66)
    print("  Rev 3 measured 200 trades over 2018-01-02..2026-08-07 at threshold")
    print("  75. If this file yields far fewer, compare 'every' against whatever")
    print("  the Rev 3 run used -- more scan dates means more chances to fill")
    print("  the eight slots, throttled by n_max and the exposure ceiling.")
    print("=" * 66)

main()
