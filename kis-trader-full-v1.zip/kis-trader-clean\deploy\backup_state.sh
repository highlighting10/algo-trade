#!/usr/bin/env bash
set -euo pipefail
cd /home/kis/kis-trader
D=$(date -u +%F)
mkdir -p "$HOME/backups"
./.venv/bin/python - "$D" <<'PY'
import sqlite3, sys, pathlib
src = pathlib.Path.home()/"kis-trader"/"kis_engine_state.db"
if not src.exists():
    print("no state db yet - nothing to back up"); raise SystemExit(0)
dst = pathlib.Path.home()/"backups"/f"state-{sys.argv[1]}.db"
s = sqlite3.connect(str(src)); t = sqlite3.connect(str(dst))
with t: s.backup(t)
t.close(); s.close(); print("backed up ->", dst)
PY
cp -f kistrader_alerts.log "$HOME/backups/alerts-$D.log"      2>/dev/null || true
cp -f regime.json          "$HOME/backups/regime-$D.json"     2>/dev/null || true
cp -f candidates.csv       "$HOME/backups/candidates-$D.csv"  2>/dev/null || true
journalctl -u kistrader --since "24 hours ago" --no-pager > "$HOME/backups/journal-$D.log" 2>/dev/null || true
journalctl -u kistrader-screeners --since "24 hours ago" --no-pager > "$HOME/backups/screener-$D.log" 2>/dev/null || true
# --- PATCH AJ (daily archive) --- fundamentals_archive is gitignored and lived
# on this disk only. A tar, not a recursive copy: each one is a full snapshot, so
# the prune below can delete old ones without losing history, and there is no
# per-file mtime churn against -mtime +14.
tar -czf "$HOME/backups/fundarchive-$D.tgz" fundamentals_archive 2>/dev/null || true
find "$HOME/backups" -type f -mtime +14 -delete
echo "backup complete $D"
