#!/usr/bin/env python3
"""
test_watchdogs.py -- the two processes that watch the loop from OUTSIDE it.

WHY THIS FILE EXISTS
====================
`supervisor.py` and `deadman.py` are complete, careful, and until 2026-09-14 had
never been run. No test module referenced them, they were not in `cli.py`'s test
tuple, and nothing in `kistrader/` imports them -- so by that tuple's own rule
("a suite outside it is a suite nobody runs") they were one step worse: there was
no suite at all.

They are also the two files whose failure is SILENT. A dead-man that does not
alert looks exactly like a healthy system, and a supervisor that does not restart
looks exactly like a loop that never crashed. Those are the last places to rely
on "it looked right when I ran it once".

Everything here is offline: no KIS, no Gemini, no Telegram. `deadman.evaluate`
takes an injected `send`, and the supervisor cases drive `--cmd` with a synthetic
child instead of the real loop.
"""
from __future__ import annotations

import os
import subprocess
import sys
import tempfile
import threading
import time

# Runnable on its own (`python tests\\test_watchdogs.py`), not only through
# `kistrader.cli test` -- which matters because a failure in here needs to be
# reproducible without waiting for the other eleven suites.
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import deadman          # noqa: E402
import supervisor       # noqa: E402

PASS = [0, 0]


def check(name, cond, got=""):
    PASS[1] += 1
    PASS[0] += bool(cond)
    print("  [%s] %s   %s" % ("PASS" if cond else "FAIL", name, got))


class Args:
    """Stand-in for the argparse namespace `evaluate` reads."""

    def __init__(self, file, stale_secs=300, renotify_secs=1800):
        self.file = file
        self.stale_secs = stale_secs
        self.renotify_secs = renotify_secs


def _sent():
    """Collector with deadman's send() signature."""
    out = []

    def send(text):
        out.append(text)
        return True

    return out, send


# ---------------------------------------------------------------------------
# deadman: the file-age primitive
# ---------------------------------------------------------------------------

def t_file_age(tmp):
    print("A  file_age -- the one fact the whole watcher rests on")
    p = os.path.join(tmp, "hb.txt")
    with open(p, "w", encoding="utf-8") as f:
        f.write("x\n")

    age, why = deadman.file_age(p, time.time())
    check("a file that exists reports an age, not a reason",
          age is not None and why == "", "age=%.1fs" % age)
    check("...and the age is measured from mtime, not from now",
          deadman.file_age(p, time.time() + 100)[0] >= 100,
          "%.0fs at now+100" % deadman.file_age(p, time.time() + 100)[0])

    age, why = deadman.file_age(os.path.join(tmp, "nope.txt"), time.time())
    check("a MISSING file is not an age of zero",
          age is None, "age=%s" % age)
    check("...it carries its own reason",
          why == "heartbeat file missing", why)


# ---------------------------------------------------------------------------
# deadman: the alert state machine (rule 4)
# ---------------------------------------------------------------------------

def t_state_machine(tmp):
    print("B  evaluate -- FRESH / STALE / suppressed / RECOVERED")
    p = os.path.join(tmp, "hb2.txt")
    with open(p, "w", encoding="utf-8") as f:
        f.write("x\n")
    a = Args(p, stale_secs=60, renotify_secs=1800)
    st = deadman.load_state(os.path.join(tmp, "missing_state.json"))
    now = time.time()

    out, send = _sent()
    stale, line = deadman.evaluate(a, st, now, send)
    check("a fresh heartbeat is not stale", not stale, line.strip())
    check("...and pushes nothing", out == [], "%d push(es)" % len(out))

    # age the file past the threshold by moving the clock, not by sleeping
    out, send = _sent()
    stale, line = deadman.evaluate(a, st, now + 61, send)
    check("past the threshold it goes STALE", stale, line.strip())
    check("...and pushes exactly once", len(out) == 1, "%d push(es)" % len(out))
    check("...and the push says the process may have died",
          out and "DOWN?" in out[0] and "no in-process alert can fire" in out[0],
          out[0][:60] if out else "")

    out, send = _sent()
    stale, line = deadman.evaluate(a, st, now + 120, send)
    check("still stale inside renotify: no second push",
          stale and out == [], line.strip())

    out, send = _sent()
    stale, line = deadman.evaluate(a, st, now + 61 + 1801, send)
    check("past renotify it re-alerts", stale and len(out) == 1,
          out[0][:52] if out else line.strip())
    check("...and the re-alert says STILL DOWN, not DOWN?",
          out and "STILL DOWN" in out[0], out[0][:52] if out else "")

    # touch the file: FRESH again
    with open(p, "w", encoding="utf-8") as f:
        f.write("y\n")
    out, send = _sent()
    stale, line = deadman.evaluate(a, st, time.time(), send)
    check("a fresh write RECOVERS", not stale, line.strip())
    check("...and says so, so post-alert silence is interpretable",
          len(out) == 1 and "RECOVERED" in out[0], out[0][:52] if out else "")

    # a missing file is stale too, from a clean state
    st2 = {"status": "FRESH", "last_alert_ts": 0.0, "stale_since": 0.0}
    out, send = _sent()
    stale, _ = deadman.evaluate(Args(os.path.join(tmp, "gone.txt")), st2,
                                time.time(), send)
    check("a VANISHED heartbeat file alerts, never passes",
          stale and len(out) == 1 and "missing" in out[0], "")


# ---------------------------------------------------------------------------
# deadman: state persistence, and the dry/live split
# ---------------------------------------------------------------------------

def t_state_file(tmp):
    print("C  state persistence -- and --dry must not touch the live file")
    missing = os.path.join(tmp, "no_such_state.json")
    st = deadman.load_state(missing)
    check("a missing state file loads as FRESH, not as a crash",
          st["status"] == "FRESH", st)
    bad = os.path.join(tmp, "corrupt.json")
    with open(bad, "w", encoding="utf-8") as f:
        f.write("{not json")
    check("a CORRUPT state file also loads as FRESH",
          deadman.load_state(bad)["status"] == "FRESH", "no raise")

    keep = os.path.join(tmp, "s.json")
    deadman.save_state(keep, {"status": "STALE", "last_alert_ts": 1.0,
                              "stale_since": 1.0})
    check("save_state round-trips",
          deadman.load_state(keep)["status"] == "STALE", "STALE")

    check("the two default state names exist and DIFFER",
          deadman.STATE_FILE != deadman.DRY_STATE_FILE,
          "%s vs %s" % (deadman.STATE_FILE, deadman.DRY_STATE_FILE))

    # The real regression: a --dry rehearsal used to write the live state file
    # and consume the FRESH->STALE edge, so the next REAL check suppressed its
    # first DOWN push for up to renotify_secs. Run the actual CLI to prove the
    # rehearsal now lands somewhere else.
    sub = os.path.join(tmp, "dryrun")
    os.makedirs(sub, exist_ok=True)
    env = dict(os.environ)
    env.pop("TG_BOT_TOKEN", None)
    env.pop("TG_CHAT_ID", None)
    rc, txt = _run([sys.executable, os.path.join(_root(), "deadman.py"),
                    "--dry", "--once", "--file", "absent.txt",
                    "--env", "no.env"], sub, 60, env)
    check("a --dry rehearsal against a dead heartbeat exits 1 (stale)",
          rc == 1, "rc=%s  %s" % (rc, _tail(txt, 2)))
    dry = os.path.exists(os.path.join(sub, deadman.DRY_STATE_FILE))
    live = os.path.exists(os.path.join(sub, deadman.STATE_FILE))
    # Its OWN directory, and the state paths are relative so they land in the
    # child's cwd -- the first version checked tmp/ while sharing it with every
    # other case, which made a failure impossible to attribute.
    check("...and writes ONLY the dry state file",
          dry and not live,
          "dry=%s live=%s  files=%s  %s"
          % (dry, live, sorted(os.listdir(sub)), _tail(txt, 2)))


# ---------------------------------------------------------------------------
# deadman: rule 2, fail closed
# ---------------------------------------------------------------------------

def t_fail_closed(tmp):
    print("D  rule 2 -- no credentials, no watch")
    sub = os.path.join(tmp, "failclosed")
    os.makedirs(sub, exist_ok=True)
    env = dict(os.environ)
    env.pop("TG_BOT_TOKEN", None)
    env.pop("TG_CHAT_ID", None)
    rc, txt = _run([sys.executable, os.path.join(_root(), "deadman.py"),
                    "--once", "--file", "absent.txt", "--env", "no.env"],
                   sub, 60, env)
    check("without TG creds it REFUSES to watch (rc 2)", rc == 2,
          "rc=%s  %s" % (rc, _tail(txt, 2)))
    check("...and says why, in the words that make it a rule",
          "false confidence" in txt, _tail(txt, 1))
    check("...and wrote no state (it never watched)",
          not os.path.exists(os.path.join(sub, deadman.STATE_FILE)),
          "files=%s" % sorted(os.listdir(sub)))


# ---------------------------------------------------------------------------
# supervisor
# ---------------------------------------------------------------------------

def _root():
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _run(argv, cwd, timeout, env=None):
    """(rc, output). A timeout returns rc=None and whatever was printed.

    NEVER raises. The first version of this file let subprocess.TimeoutExpired
    escape, and one hung supervisor took down the whole `cli test` run -- every
    suite after it never executed. A watchdog test that can kill the suite is
    worse than no watchdog test."""
    out = os.path.join(cwd, "_run_%d.log" % _run.n)
    _run.n += 1
    with open(out, "wb") as fh:
        p = subprocess.Popen(argv, cwd=cwd, env=env, stdout=fh,
                             stderr=subprocess.STDOUT)
        try:
            rc = p.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            p.kill()
            p.wait(timeout=10)
            rc = None
    with open(out, "rb") as fh:
        return rc, fh.read().decode("utf-8", "replace")


_run.n = 0


def _tail(txt, n=6):
    """Last n non-empty lines, one line, for a failure message."""
    lines = [x.strip() for x in txt.splitlines() if x.strip()]
    return " | ".join(lines[-n:])[:300] if lines else "(no output)"


def _sup(tmp, cmd, *extra, timeout=60):
    return _run([sys.executable, os.path.join(_root(), "supervisor.py"),
                 "--cmd", cmd] + list(extra), tmp, timeout)


def t_supervisor_cmd(tmp):
    print("E  supervisor --cmd -- the interpreter path must survive parsing")
    # sys.executable on Windows is C:\...\python.exe, and shlex.split's POSIX
    # mode treats backslash as an escape: 'C:\Users\x' -> 'C:Usersx'. This case
    # fails outright on Windows if --cmd is parsed POSIX-style.
    sub = os.path.join(tmp, "sup_cmd")
    os.makedirs(sub, exist_ok=True)
    rc, txt = _sup(sub, '%s -c "print(42)"' % sys.executable, "--dry",
                   timeout=60)
    check("--dry exits 0", rc == 0, "rc=%s  %s" % (rc, _tail(txt, 2)))
    check("the interpreter path is not mangled by the parser",
          sys.executable in txt, _tail(txt, 1))

    rc, txt = _sup(sub, '%s -c "print(42)"' % sys.executable,
                   "--backoff-base", "1", "--backoff-cap", "1",
                   "--max-restarts", "1", "--window", "600", timeout=60)
    check("a real child actually RAN (not a spawn failure)",
          "42" in txt and "SPAWN FAILED" not in txt,
          "rc=%s  %s" % (rc, _tail(txt, 4)))


def t_supervisor_storm(tmp):
    print("F  supervisor -- backoff, then the crash-storm guard")
    sub = os.path.join(tmp, "sup_storm")
    os.makedirs(sub, exist_ok=True)
    child = '%s -c "import sys; sys.exit(7)"' % sys.executable
    rc, txt = _sup(sub, child, "--backoff-base", "1", "--backoff-cap", "1",
                   "--max-restarts", "1", "--window", "600", timeout=60)
    check("a child that exits is restarted, not accepted",
          "restarting in" in txt, _tail(txt, 3))
    check("ANY exit counts, including a clean one -- rc=7 is not special",
          "child exited rc=7" in txt, _tail(txt, 3))
    check("more exits than --max-restarts inside the window STOPS it",
          "CRASH STORM" in txt, _tail(txt, 3))
    check("...and it exits 3 so a scheduler can see it gave up",
          rc == 3, "rc=%s  %s" % (rc, _tail(txt, 4)))
    check("...and it names the dead-man as the next line of defence",
          "dead-man" in txt, _tail(txt, 2))


def t_supervisor_stop(tmp):
    print("G  supervisor -- the stop file is a CLEAN shutdown, not a crash")
    sub = os.path.join(tmp, "sup_stop")
    os.makedirs(sub, exist_ok=True)
    child = '%s -c "import time; time.sleep(25)"' % sys.executable
    stop = os.path.join(sub, supervisor.STOP_FILE)

    def touch():
        time.sleep(5.0)
        try:
            with open(stop, "w", encoding="utf-8") as f:
                f.write("stop\n")
        except OSError:
            pass

    th = threading.Thread(target=touch, daemon=True)
    th.start()
    # 45s: the supervisor polls the stop file every 2s, so a healthy run exits
    # ~7s in. A timeout here returns rc=None and the child is killed -- the
    # case FAILS, it does not take the suite with it.
    rc, txt = _sup(sub, child, "--backoff-base", "1", timeout=45)
    th.join(timeout=10)
    check("the stop file shuts the child down", "stop file seen" in txt,
          _tail(txt, 3))
    check("...and exits 0, not a restart loop", rc == 0,
          "rc=%s%s  %s" % (rc, " (TIMED OUT)" if rc is None else "",
                           _tail(txt, 3)))
    check("...and CONSUMES the file, so the next start is not blocked",
          not os.path.exists(stop),
          "files=%s" % sorted(os.listdir(sub)))


def t_redirected_encoding(tmp):
    print("I  redirected output under a non-UTF-8 locale (the cp949 crash)")
    # THE case that was missing. Both watchdogs printed em dashes, and a
    # redirected stream takes its encoding from the locale: on the Korean
    # Windows box that is cp949, which has no U+2014, so every scheduled run
    # died with UnicodeEncodeError on its own first log line -- rc 1, no
    # restart, no alert. It never showed interactively because Python writes to
    # a Windows console through the UTF-16 API.
    #
    # PYTHONIOENCODING reproduces it on ANY platform, which is the point: this
    # check needs no Windows, and its absence is why a Linux run said 38/38
    # while the box said otherwise.
    env = dict(os.environ)
    env["PYTHONIOENCODING"] = "cp949"
    env.pop("TG_BOT_TOKEN", None)
    env.pop("TG_CHAT_ID", None)

    sub = os.path.join(tmp, "enc_sup")
    os.makedirs(sub, exist_ok=True)
    rc, txt = _run([sys.executable, os.path.join(_root(), "supervisor.py"),
                    "--cmd", '%s -c "import sys; sys.exit(7)"' % sys.executable,
                    "--backoff-base", "1", "--backoff-cap", "1",
                    "--max-restarts", "1", "--window", "600"], sub, 60, env)
    check("supervisor survives a cp949 stream and still exits 3",
          rc == 3, "rc=%s  %s" % (rc, _tail(txt, 3)))
    check("...with no UnicodeEncodeError anywhere in its output",
          "UnicodeEncodeError" not in txt, _tail(txt, 2))

    sub = os.path.join(tmp, "enc_dm")
    os.makedirs(sub, exist_ok=True)
    rc, txt = _run([sys.executable, os.path.join(_root(), "deadman.py"),
                    "--dry", "--once", "--file", "absent.txt",
                    "--env", "no.env"], sub, 60, env)
    check("deadman survives a cp949 stream while ALERTING",
          rc == 1 and "UnicodeEncodeError" not in txt,
          "rc=%s  %s" % (rc, _tail(txt, 2)))
    check("...and still wrote its state (it got past the alert)",
          os.path.exists(os.path.join(sub, deadman.DRY_STATE_FILE)),
          "files=%s" % sorted(os.listdir(sub)))


def t_supervisor_constants():
    print("H  supervisor -- an operator Ctrl+C must never look like a crash")
    check("POSIX SIGINT is in the interrupt set",
          -2 in supervisor.INTERRUPT_EXITS, "-2")
    check("Windows STATUS_CONTROL_C_EXIT is there, BOTH signednesses",
          -1073741510 in supervisor.INTERRUPT_EXITS
          and 3221225786 in supervisor.INTERRUPT_EXITS,
          "the unsigned form is what Popen actually returns")
    check("the stop file has a fixed, documented name",
          supervisor.STOP_FILE == "supervisor.stop", supervisor.STOP_FILE)


# ---------------------------------------------------------------------------

def _arg_default(path, opt):
    """The argparse default for `opt`, read from SOURCE.

    The defaults live inside main() as add_argument(default=...), so there is
    nothing importable to read -- same situation, and same tool, as
    param_snapshot.screener_overrides(). FAILS CLOSED: an option the reader
    cannot find comes back None, which fails its check instead of passing.
    """
    import re
    with open(path, encoding="utf-8") as fh:
        src = fh.read()
    m = re.search(r'add_argument\(\s*"' + re.escape(opt) + r'"[^)]*?default=([^,)\s]+)',
                  src)
    return m.group(1) if m else None


def _unit(name):
    with open(os.path.join(_root(), "deploy", name), encoding="utf-8") as fh:
        return fh.read()


def t_watchdog_pins():
    """J -- the constants that decide whether an alert arrives at all.

    Every strategy parameter has a guard. The layer that watches them had
    none. These are not backtest-chosen values; they are what the watchdogs
    were BUILT with, so drift is a stop -- the argument PATCH I made for the
    TR ids, applied to the watchers."""
    print("J  watchdog constants -- and the interaction nobody was watching")
    sup = os.path.join(_root(), "supervisor.py")
    dm = os.path.join(_root(), "deadman.py")

    for opt, want in (("--backoff-base", "65.0"), ("--backoff-cap", "300.0"),
                      ("--healthy-secs", "600.0"), ("--max-restarts", "6"),
                      ("--window", "1800.0")):
        got = _arg_default(sup, opt)
        check("supervisor default %s is %s" % (opt, want), got == want, str(got))
    for opt, want in (("--stale-secs", "300"), ("--interval", "60"),
                      ("--renotify-secs", "1800")):
        got = _arg_default(dm, opt)
        check("deadman default %s is %s" % (opt, want), got == want, str(got))

    check("POSITIVE CONTROL the source reader fails closed on a missing option",
          _arg_default(sup, "--no-such-option") is None,
          str(_arg_default(sup, "--no-such-option")))

    u_trader, u_dead = _unit("kistrader.service"), _unit("kistrader-deadman.service")

    # THE ONE THAT TURNS A PROVEN GUARD INTO A NO-OP.
    # Measured on the box 2026-09-19: the supervisor exits 3 when it gives up
    # after a crash storm, and systemd printed "Deactivated successfully"
    # rather than restarting it. That is SuccessExitStatus=2 3 doing the work.
    # Drop the 3, or flip Restart=always, and the guard still fires in the log
    # and is dead in deployment -- provable only by killing the trader seven
    # times. See RESULT_20260919_crash_storm_proven sec.2.
    check("kistrader.service counts exit 3 as SUCCESS (the guard reaches you)",
          "SuccessExitStatus=2 3" in u_trader,
          [l for l in u_trader.splitlines() if "SuccessExitStatus" in l])
    check("...with Restart=on-failure, so a deliberate give-up is not undone",
          "Restart=on-failure" in u_trader,
          [l for l in u_trader.splitlines() if l.startswith("Restart=")])
    check("the dead-man is Restart=always -- it must OUTLIVE the trader",
          "Restart=always" in u_dead,
          [l for l in u_dead.splitlines() if l.startswith("Restart=")])

    # The deployed arguments, which are where the real values come from. The
    # repo defaults above are NOT what runs for the dead-man.
    check("the deployed dead-man overrides stale to 180 and interval to 60",
          "--stale-secs 180" in u_dead and "--interval 60" in u_dead,
          [l for l in u_dead.splitlines() if "ExecStart=" in l])
    check("the deployed supervisor passes NO policy override, so the "
          "defaults above ARE the live policy",
          not any(f in u_trader for f in ("--backoff", "--healthy-secs",
                                          "--max-restarts", "--window")),
          [l for l in u_trader.splitlines() if "ExecStart=" in l])

    # THE INTERACTION, and the decision that governs it.
    # The backoff caps at 300s; the deployed dead-man calls stale at 180s. So a
    # NORMAL recovery pages the phone -- observed live during the crash-storm
    # run, at a 261s backoff, twelve minutes before anything was wrong.
    #
    # DECIDED 2026-09-19, by the operator, and NOT an oversight: keep 180. The
    # transient pages are WANTED, because a DOWN/RECOVERED pair is a record
    # that a crash happened and the supervisor handled it, which a silent
    # recovery destroys. The rule is:
    #     DOWN then RECOVERED          -> supervisor did its job, no action
    #     DOWN, no RECOVERED in 30 min -> manual check
    # Do NOT "fix" 180 up past the backoff cap. Under a 300s backoff it looks
    # like a misconfiguration and is not one: it is the setting that makes
    # every crash visible. See RESULT_20260919_crash_storm_proven sec.4.
    cap = float(_arg_default(sup, "--backoff-cap"))
    check("DECIDED: the deployed stale threshold sits BELOW the backoff cap",
          180.0 < cap, "180 vs cap %s" % cap)
    # And the collision is in the SHIPPED DEFAULTS too, where the two are
    # exactly equal -- a max backoff would land on the threshold and alert or
    # not on which side of a second the poll falls. The box's 180 makes the
    # overlap wide and consistent instead of marginal.
    check("...and at the shipped defaults the two are EQUAL, which is worse",
          float(_arg_default(dm, "--stale-secs")) == cap,
          "%s vs %s" % (_arg_default(dm, "--stale-secs"), cap))
    # renotify IS the escalation half of the rule above. Verified off
    # `deadman.py --help` on the box; the unit passes no override.
    check("renotify is 1800s, which IS the 30-minute escalation rule",
          _arg_default(dm, "--renotify-secs") == "1800"
          and "--renotify" not in u_dead,
          _arg_default(dm, "--renotify-secs"))
    # Measured on the box: the guard tripped on the SEVENTH exit. --max-restarts
    # is the number of restarts ALLOWED, so the seventh exit is the one nobody
    # answers. The policy line prints it as "6 exits", which is the wrong noun
    # for the number and is what made an earlier estimate of "2 exits in 600s"
    # survive as long as it did.
    check("storm guard allows 6 restarts, so it trips on exit 7 (measured)",
          _arg_default(sup, "--max-restarts") == "6",
          _arg_default(sup, "--max-restarts"))


def main():
    print("=" * 62)
    print("WATCHDOGS -- supervisor.py and deadman.py")
    print("=" * 62)
    # ignore_cleanup_errors: a supervisor that crashes leaves its CHILD running,
    # and on Windows that child still holds the redirected log file open, so
    # rmtree raises PermissionError [WinError 32] and the whole module dies
    # AFTER every check has already passed. Observed 2026-09-14.
    with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmp:
        t_file_age(tmp)
        t_state_machine(tmp)
        t_state_file(tmp)
        t_fail_closed(tmp)
        t_supervisor_cmd(tmp)
        t_supervisor_storm(tmp)
        t_supervisor_stop(tmp)
        t_redirected_encoding(tmp)
        t_supervisor_constants()
    t_watchdog_pins()
    print("=" * 62)
    print("PASSED %d / %d" % (PASS[0], PASS[1]))
    print("=" * 62)
    return 0 if PASS[0] == PASS[1] else 1


if __name__ == "__main__":
    raise SystemExit(main())
