#!/usr/bin/env python3
"""
patch_test_paths.py -- make every suite runnable without PYTHONPATH.

THE SYMPTOM
    python tests\\test_screener_harness.py  ->  0/12, "No module named 'screeners'"
    python -m pytest -q                     ->  86 passed

Not a code failure, and not confined to one suite. pytest puts the repo root on
sys.path via pyproject's `pythonpath = [".", "tests"]`. A direct run does not:
sys.path[0] is tests\\, and neither `kistrader` nor `screeners` resolves from
there unless PYTHONPATH happens to be set in that particular shell.

Measured with PYTHONPATH cleared: SIX of the seven suites fail on a direct run.
Only test_candidate_emit.py survived, because it already resolves the repo root
from __file__.

Why that matters: the direct runs are the ones that print every check name, and
they are what you read when something fails. A gate that works until you open a
new terminal is the failure mode this project keeps closing everywhere else.

THE FIX
The same three lines test_candidate_emit.py already uses, in every suite:
resolve the repo root from __file__, put it and screeners/ on sys.path. No env
var, no shell state, runs from any working directory.

Anchors are asserted; the bootstrap is inserted above each file's first
`from kistrader ...` import.

Usage:  python patch_test_paths.py <repo-root>
"""
from __future__ import annotations

import os
import re
import sys

BOOTSTRAP = '''# Self-locating: `kistrader` and `screeners` are not installed packages
# (pyproject packages.find includes only kistrader*), so a DIRECT run -- where
# sys.path[0] is tests/ -- cannot import either. pytest happens to work because
# pyproject sets pythonpath = [".", "tests"]. Relying on that difference means a
# suite is green under one command and 0/N under the other, in a shell that
# merely forgot an env var.
import os as _os, sys as _sys
_ROOT = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))
for _p in (_ROOT, _os.path.join(_ROOT, "screeners")):
    if _p not in _sys.path:
        _sys.path.insert(0, _p)

'''

TARGETS = ("test_boot_params.py", "test_entry_half.py", "test_exit_state_machine.py",
           "test_pipeline_e2e.py", "test_seed_position.py")


def main(root):
    tests = os.path.join(root, "tests")
    if not os.path.isdir(tests):
        raise SystemExit(f"REFUSING: not found: {tests}")
    done = 0
    for name in TARGETS:
        p = os.path.join(tests, name)
        if not os.path.isfile(p):
            print(f"  -- {name}: not present, skipped")
            continue
        with open(p, encoding="utf-8") as f:
            s = f.read()
        if "_ROOT = _os.path.dirname(" in s:
            print(f"  -- {name}: already self-locating, skipped")
            continue
        m = re.search(r"^from kistrader[^\n]*\n", s, re.M)
        if not m:
            raise SystemExit(f"REFUSING: {name}: no top-level kistrader import to anchor on")
        anchor = m.group(0)
        # the anchor need not be unique in the file; we replace only the FIRST
        # occurrence, which is the one the bootstrap must precede
        s = s[:m.start()] + BOOTSTRAP + s[m.start():]
        with open(p, "w", encoding="utf-8", newline="") as f:
            f.write(s)
        print(f"  ok  {name}: bootstrap inserted above {anchor.strip()[:44]!r}")
        done += 1
    if not done:
        raise SystemExit("REFUSING: nothing to do (all already self-locating).")
    print("\nAPPLIED. Every suite now runs from any directory with no PYTHONPATH.")
    return 0


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("usage: python patch_test_paths.py <repo-root>")
    sys.exit(main(sys.argv[1]))
