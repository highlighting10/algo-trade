# ROADMAP — the rank-weight problem (Rev 3 sec.11 / Problem 2)

**2026-08-22.** Written after F8 closed. Ships with `rank_probe.py`, a runnable
diagnostic that proves the state of this on your machine before anything is
edited.

---

## CORRECTION -- 2026-08-22, after Phase 0 was actually run

**This document's original sec.0 claimed the trap "has already sprung". That was
wrong**, and it was wrong in the way this project most distrusts: inferred from
an absence in an archive rather than measured on the machine. The archive I was
sent had no vendored `kistrader/`; the machine does. Recording the error rather
than editing it away, because what I believed and what measurement showed are
both part of the record.

### What Phase 0 measured

```
git baseline            c8900f5, 69 files            (first rollback point ever)
06_sweep.py line 3      sys.path.insert(0, <repo root>)   -> vendored copy wins
decision_engine live    kis-backtest\kistrader\entry\decision_engine.py
                        rs=2.0  stage2=1.0  vcp=MISSING  (2-weight)
rank_probe              EXIT 0 -- all three modes rank on what they claim
universe                1506 rows / 1506 bar files; sp400 400, sp500 503, sp600 603
                        1 missing (CWEN-A, dual-class), ^GSPC present
RS peer groups          populations_from_universe already splits sp500 | sp400+sp600,
                        matching production's two screener runs exactly
```

### What that changes

| | this doc originally said | measured |
|---|---|---|
| the rank trap | **live** | **LATENT** -- vendored 2-weight engine is correct |
| Rev 3's mode comparison | suspect | **VALID** |
| sizing defaults 0.0075 / 0.20 | a footgun | **LIVE and confirmed** |
| RS peer grouping | unchecked | already correct |

**So the priority inverts.** The rank work is no longer a repair, it is
prevention. The only thing actively capable of producing wrong numbers today is
the sizing default: a sweep that forgets `--risk-pct` and `--max-position-pct`
silently uses pre-migration values.

### Revised phase order -- GUARD FIRST

The original plan put the snapshot guard last, at Phase 4. That was the wrong
order. The guard costs nothing, changes no behaviour, and is the only thing that
makes the latent trap incapable of springing *silently* -- which matters,
because the vendored copy has already gone missing from one archive.

**Phase 1 (new): `harness_snapshot.py`.** Shipped with this document, and proven
against all four states -- vendored engine (exit 0), vendored deleted (exit 1,
names `rs_only`), sizing flags forgotten (exit 1), flags passed (exit 0). Wire
it into the sweep entry points and stamp its one-line output on every result.

**Phase 2 (new): close the sizing footgun.** Either `--require-explicit-sizing`
in every sweep invocation, or correct the vendored defaults to the frozen
0.0085 / 0.25. The first is better: it forces the configuration to be carried
with the number rather than assumed.

**Phase 3 (was Phase 2): the three-weight migration**, now genuinely preventive
and safe to do with the guard already watching. Everything below still applies
-- it describes exactly what happens *if* production's engine is imported, which
is what the guard now prevents happening unnoticed.

---

## 0. THE ORIGINAL ANALYSIS -- still correct about the MECHANISM

Every document so far describes this as *"the harness loads a stale vendored
`decision_engine`; fix it by making it match production."* Measured today, the
opposite is true:

| engine the harness imports | `rs_only` | `vcp_only` | `rs_plus_vcp` | probe |
|---|---|---|---|---|
| **vendored, 2-weight** (what Rev 3 ran) | correct | correct | correct | **exit 0** |
| **production, 3-weight** (what it imports today) | **REVERSED** | correct | **wrong ratio** | **exit 1** |

The vendored copy's two-weight scheme is internally consistent: with
`stage2_score := vcp_score`, `(2,0)` is pure RS, `(0,1)` is pure VCP, `(2,1)` is
2*RS+1*VCP. All three are exactly what their names claim.

Production's engine adds a third term, `vcp_weight`, **defaulting to 1.0**.
`minervini_backtest.run()` line 460 sets only `rs_weight` and `stage2_weight`,
so that 1.0 survives and silently adds a VCP term to every mode.

**The "fix" everyone assumed — delete the vendored copy, or copy production's
over it — is precisely what breaks it.** The brief's trap warning was right.

> **CORRECTED.** This paragraph originally continued *"and the trap has already
> sprung: there is no vendored `kistrader/` in the 2026-08-22 archive, so the
> harness imports production's engine today."* **False.** The archive lacked it;
> the machine has it. Measured 2026-08-22: the vendored 2-weight engine is live
> and `rank_probe` exits 0. The trap is LATENT. The rest of this section remains
> an accurate description of what happens if the vendored copy is ever removed --
> which is exactly what Phase 1's guard now catches.

### What that costs, measured

`rank_probe.py` builds candidate sets where the RS ordering and the VCP ordering
conflict, then runs the real `plan()`.

**Fixture A — wide RS spread (90→65).** `2*RS` dominates the stray VCP term, so
the *order* survives even though the score is contaminated. **This is why it went
unnoticed:** on data like this it looks fine.

**Fixture B — tight RS spread (92→87), the realistic one.** Stage 1 has *already*
filtered to high RS, so real survivors cluster: the RS spread is small while VCP
still varies widely. Here the stray term dominates completely:

```
rs_only   claims: RS only     score reduces to 2.0*RS + 1.0*VCP
  got     : FFF > EEE > DDD > CCC > BBB > AAA
  should be AAA > BBB > CCC > DDD > EEE > FFF
```

**`rs_only` ranks in perfect REVERSE-RS order.** Not degraded — inverted. And it
is worst exactly where real data lives, because Stage 1 guarantees the clustering.

**Fixture C — two names, ratio isolated.** `rs_plus_vcp` reduces to `2*RS+2*VCP`,
a 1:1 ratio wearing a 2:1 name, and picks the wrong name outright.

### What is NOT affected — read this before worrying about the box

- **Production is untouched and correct.** The frozen live config is
  `rs_weight 0.0 / stage2_weight 0.0 / vcp_weight 1.0` — pure `vcp_only`, set
  explicitly, and `param_snapshot` checks it on every boot. This bug lives
  entirely in how the *harness* constructs its config. **No live trade has ever
  been ranked wrongly by it.**
- **`vcp_only` is correct under BOTH engines.** Under production's it becomes
  `2*vcp` — a monotone rescaling, so the ordering is identical. Since `vcp_only`
  is the frozen mode and the mode Rev 3 selected, **the headline result stands.**
- **F8 is unaffected.** It runs `vcp_only` with one candidate per case.

### So the actual exposure is narrow, and worth stating precisely

Only **mode-comparison** numbers are at risk, and only if produced while
production's engine was the one imported. Rev 3 sec.11's *"vcp_only won all four
cost levels by 5.79–8.62 return-%"* was produced with the vendored copy present
(confirmed loaded on 2026-08-20), so **it is valid**. Anything re-run after the
vendored copy disappeared is suspect and must be re-dated.

---

## PHASE 0 — Ground truth. No edits. ~30 minutes.

**0.1 `git init` first.** Still no repository, verified again today. Everything
below edits the file that produced every number in the freeze.

```powershell
cd C:\Users\user\PyCharmMiscProject\kis-backtest
git init
git config user.name "JH"; git config user.email "jh@kistrader.local"

# .gitignore FIRST, as a REAL command. Set-Content -Encoding UTF8 would prepend
# a BOM and git would read the first pattern as a literal BOM + ".venv/".
$gi = @'
.venv/
.idea/
__pycache__/
*.pyc
data/
price_cache/
runs/
*.parquet
*.pkl
*.db
*.zip
'@
$enc = New-Object System.Text.UTF8Encoding($false)
[System.IO.File]::WriteAllText((Join-Path $PWD '.gitignore'), $gi, $enc)

git add -A
git commit -m "Baseline: kis-backtest as it produced PARAMETER_FREEZE Rev 3"
```

> **CORRECTED.** The first version wrote the `.gitignore` line as a COMMENT, so
> `git add -A` tried to stage `data/` and died on `data/bars/CON.parquet` -- a
> Windows reserved device name that directory enumeration lists but git's
> `open()` cannot resolve. The data itself is fine (pandas reads 511 rows); only
> git and PowerShell's FileSystem provider cannot address that name. Standing
> rule 6 says no placeholders, and that was one.
> **Done 2026-08-22: commit `c8900f5`, 69 files.**

**0.2 What does a REAL sweep import?** Run from the harness directory, with no
path tricks — this is the single most important fact and nobody can see it from
sweep output:

```powershell
cd C:\Users\user\PyCharmMiscProject\kis-backtest
python rank\rank_probe.py
```

Record the `decision_engine :` line and the exit code.

> **CORRECTED.** This said *"expect exit 1"*. **Measured: exit 0** -- the path is
> `kis-backtest\kistrader\entry\decision_engine.py`, the vendored 2-weight copy,
> and all three modes are correct. Note also that `python rank\rank_probe.py` puts
> `rank\` on `sys.path[0]`, NOT the repo root, so set
> `$env:PYTHONPATH = (Get-Location).Path` first or the probe answers the wrong
> question. `06_sweep.py` line 3 does the equivalent with an explicit
> `sys.path.insert(0, <repo root>)`.

**0.3 Does the vendored package still exist anywhere?**

```powershell
Get-ChildItem C:\Users\user\PyCharmMiscProject\kis-backtest -Recurse -Filter decision_engine.py |
    Select-Object FullName, Length, LastWriteTime
```

If it is gone, find out **when** — the answer dates which sweep results are
clean. The 08-20 finding recorded it loaded; the 08-22 archive has none.

**0.4 What else imports `kistrader.*`?** Deleting or repointing the vendored
package must not silently change anything else:

```powershell
Select-String -Path *.py,scripts\*.py -Pattern "from kistrader|import kistrader" |
    Select-Object Filename, LineNumber, Line
```

Pay attention to `screen_contract` (the vendored copy is a known stale one,
missing `VCP_SCORE_THRESHOLD`, `write_regime`, `read_regime`,
`REGIME_MAX_BAR_AGE_DAYS`) and `vcp_engine`.

---

## PHASE 1 — Decide which engine is canonical. A decision, not code.

**Recommendation: production's, imported deterministically, with all three
weights set explicitly.**

Why not keep the vendored two-weight copy, given it is currently the *correct*
one? Because its correctness is accidental — it depends on production never
changing, and production already changed once without the harness noticing. Two
copies of the module every ranking, stop and size depends on is sec.12's
stale-copy problem, and this incident is what it looks like when it fires.

Setting all three weights explicitly removes the dependency entirely: the result
no longer depends on which file got imported, which is the only durable fix.

---

## PHASE 2 — The patch. Four edits, ~30 minutes.

**This is a behaviour-PRESERVING refactor.** The three-weight table below
reproduces the vendored two-weight scheme exactly — same scores, not merely the
same ordering. That is what makes Phase 3's acceptance test possible.

**2.1** `minervini_backtest.py:430` — three weights, and say so:

```python
# (rs_weight, stage2_weight, vcp_weight). Stage 2 is CUT in the backtest, so the
# middle slot is always 0.0 and vcp_score now feeds the REAL vcp_weight instead
# of being smuggled in through stage2_score. These reproduce the previous
# two-weight scheme EXACTLY -- same scores, not just the same order.
RANK_WEIGHTS = {
    "rs_only":     (2.0, 0.0, 0.0),
    "vcp_only":    (0.0, 0.0, 1.0),
    "rs_plus_vcp": (2.0, 0.0, 1.0),
}
```

Keep the line-435 assert that refuses a silent fall-through.

**2.2** `line 459` — unpack three:

```python
_rs_w, _s2_w, _vcp_w = RANK_WEIGHTS[cfg.rank_mode]
```

**2.3** `line 460` — set all three, so no default can ever leak in:

```python
engine = DecisionEngine(replace(cfg.decision, rs_weight=_rs_w,
                                stage2_weight=_s2_w, vcp_weight=_vcp_w))
```

**2.4** `line 861` — **delete** the smuggling, now that `vcp_weight` is real:

```python
# DELETE: ordered = [replace(c, stage2_score=float(c.vcp_score)) for c in eligible]
ordered = list(eligible)
```

> Leaving both in is exactly how the double-count happens. Removing one without
> the other silently changes `vcp_only`. They move together or not at all.

**2.5** Add a fail-closed guard near the import, so a restored two-weight engine
stops the run loudly instead of ranking wrongly:

```python
if not hasattr(DecisionConfig(), "vcp_weight"):
    raise ImportError(
        "the imported decision_engine has no vcp_weight -- this harness now sets "
        "all three ranking weights explicitly and cannot express its modes "
        "against a two-weight engine. Point it at production's decision_engine.")
```

---

## PHASE 3 — Verification. This is the phase that matters. 2–4 hours.

**3.1 The probe must go green.** All three fixtures, all three modes:

```powershell
python rank\rank_probe.py          # must print "Every mode ranks on what it claims", exit 0
```

Then **show it able to fail**: revert 2.3 alone (drop `vcp_weight=_vcp_w`),
confirm the probe returns to exit 1, restore. A guard that has never failed is
not known to work.

**3.2 Reproduce Rev 3 EXACTLY.** Because Phase 2 is behaviour-preserving, the
published `vcp_only` numbers must come back **identical** — not close.

```powershell
# whatever the published sweep invocation was; carry --risk-pct and
# --max-position-pct explicitly, per the Rev 3 footgun note
python scripts\06_sweep.py ... --risk-pct 0.0085 --max-position-pct 0.25
```

Match against Rev 3: expectancy +0.330R, payoff 3.20:1, 200/225 trades, the
exit-reason breakdown. **If anything moves, stop.** Either the refactor was not
behaviour-preserving, or the published numbers were not produced the way the
document says. Both are findings; neither is something to paper over.

**3.3 The mode comparison must be re-run.** sec.11's mode ranking is the *only*
result this bug can have touched. With the modes now meaning what they say,
re-run all three and compare against the published table. `vcp_only` should be
unchanged; `rs_only` and `rs_plus_vcp` may move.

**3.4 F8 must still be green** — the rank change must not touch exits, and if it
does, something is wrong:

```powershell
cd f8
python fuzz_f8.py --prod-root C:\Users\user\kis-trader-clean --harness ..\minervini_backtest.py --trials 12000
$LASTEXITCODE     # must still be 0
```

**3.5 Production must be untouched.** `git status` clean in `kis-trader-clean`,
`pytest -q` still 86 passed.

---

## PHASE 4 — Stop it recurring. `harness_snapshot.py`. ~1 hour.

Production has `param_snapshot.py`, which is why a wrong `STALL_DAY` cannot ship
quietly. **The harness has no equivalent, and that is the actual root cause** —
not the weights themselves. The weights were wrong for two days and only a
deliberate probe found it.

Build the mirror image. On every run, print and *enforce*:

```
decision_engine resolved to : <absolute path>
rs / stage2 / vcp weight    : <all three, per mode>
risk_per_trade_pct          : 0.0085   (frozen)
max_position_pct            : 0.25     (frozen)
rank_mode                   : vcp_only
ambiguity_mode              : worst
```

Refuse to run — or stamp every result `DEGRADED` — on any mismatch. Rev 3
sec.10's *"carry the configuration with every number"* becomes enforced rather
than aspirational. This is the piece that would have caught the vendored-copy
disappearance the day it happened.

---

## PHASE 5 — Only now, re-open the threshold question.

Everything the backtest exists to answer — RS ≥ 70? the VCP cutoff? — is a
ranking-and-selection question. Asking it before Phase 3 is answered would be
tuning against a scorer that does not compute what its labels say.

---

## Risk register

| risk | mitigation |
|---|---|
| A restored two-weight engine breaks `replace(..., vcp_weight=...)` | 2.5's guard turns it into a loud ImportError, not a silent misrank |
| Retiring the vendored package changes `screen_contract` under the harness | Phase 0.4 audits imports first; production's copy is strictly newer, but verify rather than assume |
| Rev 3 reproduction needs the original bar cache | `price_cache/` must still exist; check before starting Phase 3 |
| Doing 2.4 without 2.1–2.3 silently changes `vcp_only` | The four edits are one commit, never staged separately |
| pandas 3.0 vs whatever Rev 3 ran on | Unresolved and orthogonal — if 3.2 fails to reproduce, suspect this before the refactor |

---

## Effort

| phase | time | what dominates |
|---|---|---|
| 0 ground truth | 30 min | reading, no edits |
| 1 decision | 15 min | one call |
| 2 patch | 30 min | four small edits |
| 3 verification | 2–4 h | the Rev 3 reproduction |
| 4 snapshot guard | 1 h | writing the enforcement |

**About half a day**, and as the original brief predicted, most of it is
verification rather than editing.

---

## The one-line version

The harness's two-weight ranking was correct; production grew a third weight;
the harness never learned. Set all three explicitly, prove Rev 3 reproduces
bit-for-bit, and give the harness the `param_snapshot` it never had.
