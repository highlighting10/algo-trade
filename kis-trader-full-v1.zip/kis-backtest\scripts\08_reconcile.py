"""
08_reconcile.py -- WHY does positive expectancy_R produce a negative return?

expectancy_R is computed from FILL PRICES, so it carries slippage but NOT broker
commission -- commission is deducted from cash separately. The equity curve
carries both. If commission is large relative to risk, the two can disagree in
sign, which is exactly what threshold 70 shows.

With equal-R sizing, notional = risk$ / risk_pct, so:

    commission in R = round_trip_pct / risk_pct

A tight stop means a big position for the same dollar risk, so commission costs
MORE R. This script measures the actual distribution rather than assuming 6.5%.

Usage:
    python scripts/08_reconcile.py --threshold 70
"""
import pathlib as _pl
import sys as _sys
_sys.path.insert(0, str(_pl.Path(__file__).resolve().parent.parent))

import argparse
import pathlib
import pickle

import numpy as np
import pandas as pd

from minervini_backtest import (BacktestConfig, DecisionConfig, load_sector_map,
                                run)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--threshold", type=float, default=70.0)
    ap.add_argument("--slippage", type=float, default=5.0)
    ap.add_argument("--signals", default="data/signals.pkl")
    args = ap.parse_args()

    bars = {p.stem: pd.read_parquet(p)
            for p in pathlib.Path("data/bars").glob("*.parquet")}
    prices = {t: d for t, d in bars.items() if t != "^GSPC"}
    with open(args.signals, "rb") as f:
        signals = pickle.load(f)["signals"]

    cfg = BacktestConfig(rank_mode="rs_only", equity_mode="compounding",
                         entry_mode="pivot_limit", ambiguity_mode="worst",
                         vcp_threshold=args.threshold, slippage_bps=args.slippage,
                         sector_map=load_sector_map("data/sectors.csv"),
                         decision=DecisionConfig())
    eq, trades, st, dr, dg = run(prices, signals, cfg)
    if not trades:
        raise SystemExit("[reconcile] no trades")

    start, end = float(eq.iloc[0]), float(eq.iloc[-1])
    gross = sum(t.pnl for t in trades)               # runner legs only
    rt = round(cfg.broker_commission_pct * 2 * 1e4, 1)

    # per-trade risk geometry, measured
    risk_pcts, notionals, comms = [], [], []
    for t in trades:
        notional = t.shares * t.entry_price
        notionals.append(notional)
        buy = notional * cfg.broker_commission_pct
        sell_n = t.shares * t.exit_price
        sell = (sell_n * (cfg.broker_commission_pct + cfg.sec_fee_pct)
                + min(t.shares * cfg.taf_per_share, cfg.taf_cap_per_trade))
        comms.append(buy + sell)
        if t.r_at_exit not in (0, None) and t.exit_price != t.entry_price:
            rps = abs((t.exit_price - t.entry_price) / t.r_at_exit)
            if rps > 0:
                risk_pcts.append(rps / t.entry_price)

    rp = np.array(risk_pcts) if risk_pcts else np.array([np.nan])
    comm_total = float(np.sum(comms))
    comm_in_r = (cfg.broker_commission_pct * 2) / rp

    print("=" * 70)
    print(f"RECONCILIATION  threshold={args.threshold} slippage={args.slippage}bps")
    print("=" * 70)
    print(f"  trades                       : {len(trades)}")
    print(f"  expectancy_R (fills only)    : {st['expectancy_R']:+.4f}")
    print(f"  equity {start:,.0f} -> {end:,.0f}   ({st['total_return_pct']:+.2f}%)")
    print()
    print("  WHERE THE MONEY WENT")
    print(f"    sum of trade pnl (runners) : {gross:+,.2f}")
    print(f"    commission + fees paid     : {-comm_total:+,.2f}")
    ppnl = dg.get("partial_pnl", 0.0)
    print(f"    partial-sale profit        : {ppnl:+,.2f}  "
          f"({dg['partials_taken']} partial(s), absent from trade pnl)")
    resid = end - start - gross - ppnl + comm_total
    print(f"    residual (compounding etc) : {resid:+,.2f}")
    print()
    print(f"    GROSS PROFIT before costs  : {gross + ppnl:+,.2f}")
    comm_share = 100 * comm_total / max(gross + ppnl, 1e-9)
    print(f"    commission as % of gross   : {comm_share:.1f}%")
    # Korean overseas-stock capital gains: 22% (20% + 2% local) on annual net
    # gains above the ~2.5M KRW exemption. Applied here as a flat haircut on the
    # final figure -- it is levied yearly on realised gains, so it does NOT
    # compound, and it is uniform across settings so it never changes a ranking.
    net_usd = end - start
    if net_usd > 0:
        print(f"    after 22% KR capital gains  : {net_usd*0.78:+,.2f} "
              f"({100*net_usd*0.78/start/11.6:.2f}%/yr on an 11.6y run)")
    print()
    print("  RISK GEOMETRY (measured, not assumed)")
    print(f"    stop distance  median      : {np.nanmedian(rp)*100:.2f}% of entry")
    print(f"    stop distance  p10 / p90   : {np.nanpercentile(rp,10)*100:.2f}% / "
          f"{np.nanpercentile(rp,90)*100:.2f}%")
    print(f"    position notional median   : {np.median(notionals):,.0f}")
    print()
    print(f"  COMMISSION EXPRESSED IN R   (round trip {rt} bps / stop distance)")
    print(f"    median                     : {np.nanmedian(comm_in_r):.4f} R per trade")
    print(f"    p10 / p90                  : {np.nanpercentile(comm_in_r,10):.4f} / "
          f"{np.nanpercentile(comm_in_r,90):.4f} R")
    net = st["expectancy_R"] - float(np.nanmedian(comm_in_r))
    print()
    print(f"  NET EDGE AFTER COMMISSION    : {st['expectancy_R']:+.4f} "
          f"- {np.nanmedian(comm_in_r):.4f} = {net:+.4f} R per trade")
    print("=" * 70)
    # hold-time, to separate an edge problem from a deployment problem
    holds = [(t.exit_date - t.entry_date).days for t in trades]
    print()
    print("  DEPLOYMENT")
    print(f"    median hold (calendar days): {int(np.median(holds))}")
    print(f"    avg positions held         : {dg['avg_positions_held']} "
          f"of {cfg.decision.n_max} slots")
    print(f"    capacity used              : "
          f"{100*dg['avg_positions_held']/cfg.decision.n_max:.1f}%")
    print(f"    active sessions            : {dg['active_sessions']} "
          f"(bar calendar is {dg['calendar_sessions']}; the excess is history")
    print("                                  before the first signal)")
    print()
    # NOTE:  below uses expectancy_R, which is RUNNER-ONLY and per-share --
    # it excludes partial profits entirely, so it can stay positive while the
    # account loses money. The DOLLAR ratio is the truthful figure.
    if comm_share >= 90:
        print(f"  COMMISSION IS {comm_share:.0f}% OF GROSS PROFIT.")
        print("  This is a COST problem, not a tuning problem. No parameter")
        print("  choice recovers it. The levers are: a lower commission rate,")
        print("  fewer and larger positions, or systematically wider stops")
        print("  (smaller notional per unit of risk).")
        print("  At 0.09% per side instead of 0.25%, commission-in-R would fall")
        print(f"  from {np.nanmedian(comm_in_r):.4f} to "
              f"{(0.0009*2)/np.nanmedian(rp):.4f} R per trade.")
    elif net <= 0:
        print("  COMMISSION CONSUMES THE ENTIRE MEASURED EDGE.")
        print("  No parameter choice fixes this -- it is a cost problem, not a")
        print("  tuning problem. The levers are: fewer/larger positions, wider")
        print("  stops (smaller notional per unit of risk), or a cheaper broker.")
    else:
        print(f"  Edge survives commission at {net:+.4f} R, but the equity curve")
        print("  still depends on the compounding path and on share flooring")
        print("  pushing realised risk below the 0.75% target.")


if __name__ == "__main__":
    main()
