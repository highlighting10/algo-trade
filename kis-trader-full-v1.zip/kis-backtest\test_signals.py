"""End-to-end: synthetic bars -> signals.py -> minervini_backtest.run(). No network."""
import numpy as np, pandas as pd
import vcp_engine as ve
from signals import PITBars, generate_signals, constant_universe, pit_universe
from minervini_backtest import BacktestConfig, run

rng = np.random.default_rng(11)
DATES = pd.bdate_range("2021-01-04", periods=800)      # >2y so VCP has its window


def synth(seed, drift=0.0004, vol=0.018, base=50.0):
    r = np.random.default_rng(seed)
    c = base * np.cumprod(1 + r.normal(drift, vol, len(DATES)))
    o = np.r_[c[0], c[:-1]]
    h = np.maximum(o, c) * (1 + abs(r.normal(0, .004, len(DATES))))
    l = np.minimum(o, c) * (1 - abs(r.normal(0, .004, len(DATES))))
    v = r.integers(4e5, 4e6, len(DATES)).astype(float)
    return pd.DataFrame({"Open": o, "High": h, "Low": l, "Close": c, "Volume": v},
                        index=DATES)


TICKERS = [f"T{i:02d}" for i in range(12)]
BARS = {t: synth(100 + i, drift=0.0002 + 0.00012 * i) for i, t in enumerate(TICKERS)}
BARS["^GSPC"] = synth(7, drift=0.0003, base=3800)


# ---------- 1. the look-ahead guard, proved not asserted ----------
def test_no_lookahead():
    s = PITBars(BARS)                    # calendar mode (production semantics)
    T = DATES[600]
    s.set_date(T)
    for period, off in (("1y", pd.DateOffset(years=1)),
                        ("2y", pd.DateOffset(years=2))):
        df = s.fetch("T05", period)
        # the REAL invariants are the two bounds. Row count is data-dependent
        # under calendar slicing (holidays), so asserting it would be asserting
        # the fixture, not the guard.
        assert df.index.max() <= T, (period, df.index.max(), T)
        assert df.index.min() >= T - off, (period, df.index.min(), T - off)
    # session mode still available and still bounded
    s2 = PITBars(BARS, period_mode="sessions")
    s2.set_date(T)
    assert len(s2.fetch("T05", "2y")) == 504
    # a date before any history exists yields nothing, not a stale row
    s.set_date(pd.Timestamp("2019-01-01"))
    assert s.fetch("T05", "1y") is None
    print("PASS  look-ahead guard: window bounded by [T-period, T] in calendar "
          "mode, tail(504) in session mode")


# ---------- 2. tz-aware bars normalised (the yfinance mixing trap) ----------
def test_tz_normalised():
    tzed = {t: df.tz_localize("America/New_York") for t, df in list(BARS.items())[:2]}
    s = PITBars(tzed)
    s.set_date(DATES[400])
    df = s.fetch(list(tzed)[0], "1y")
    assert df.index.tz is None
    print("PASS  tz-aware bars normalised to naive on ingest")


# ---------- 3. fetcher fails CLOSED when unset ----------
def test_fetcher_fails_closed():
    ve._FETCH = None
    try:
        ve._fetch_history("T00", "1y")
        raise AssertionError("should have raised")
    except RuntimeError as e:
        assert "no fetcher installed" in str(e)
    print("PASS  unset fetcher raises instead of masquerading as a data gap")


# ---------- 4. Stage-1 return shape is what signals.py assumes ----------
def test_stage1_contract():
    s = PITBars(BARS); s.set_date(DATES[600]); ve.set_fetcher(s.fetch)
    res = ve.check_minervini_technicals("T11")
    assert len(res) == 6, len(res)
    structural, price, high20, ret6m, raw_rs, status = res
    assert isinstance(status, str)
    assert raw_rs is None or isinstance(raw_rs, (int, float, np.floating))
    print(f"PASS  Stage-1 contract: 6-tuple, raw_rs at index 4, status={status!r}")


# ---------- 5. RS is a population percentile, recomputed per T ----------
def test_rs_is_population_relative():
    s = PITBars(BARS); s.set_date(DATES[600]); ve.set_fetcher(s.fetch)
    raw = {}
    for t in TICKERS:
        r = ve.check_minervini_technicals(t)
        if r[4] is not None:
            raw[t] = r[4]
    full = ve.compute_rs_ratings(raw)
    half = ve.compute_rs_ratings({k: raw[k] for k in list(raw)[:6]})
    shared = set(full) & set(half)
    changed = [t for t in shared if full[t] != half[t]]
    assert changed, "RS should shift when the scanned population changes"
    print(f"PASS  RS is population-relative: {len(changed)}/{len(shared)} ratings "
          f"move when the universe halves -- so it MUST be recomputed per T")


# ---------- 6. full pipeline: bars -> signals -> backtest ----------
def test_end_to_end():
    scan_dates = DATES[520::20]                        # monthly-ish rescan
    sigs = generate_signals(BARS, scan_dates,
                            constant_universe(TICKERS),
                            emit_threshold=0.0, log=lambda *a: None)
    scored = sum(len(v) for v in sigs.values())
    print(f"PASS  signal pass: {len(sigs)} date(s) emitted, {scored} candidate(s)")
    if not sigs:
        print("      (synthetic random walks rarely form real VCP bases -- the "
              "pipeline ran end to end, which is what this test checks)")
        return
    px = {t: df for t, df in BARS.items() if t != "^GSPC"}
    cfg = BacktestConfig(rank_mode="rs_only",
                         sector_map={t: "Tech" for t in TICKERS},
                         vcp_threshold=0.0, slippage_bps=5.0)
    eq, tr, st, dr, dg = run(px, sigs, cfg)
    print(f"      backtest ran: {st['num_trades']} trade(s), "
          f"end equity ${st['end_equity']:,.2f}, drops {dg['drops_total']}")


# ---------- 7. PIT universe actually shrinks the scan ----------
def test_pit_universe():
    f = pit_universe({DATES[0]: TICKERS[:6], DATES[400]: TICKERS})
    assert len(f(DATES[100])) == 6 and len(f(DATES[500])) == 12
    assert f(pd.Timestamp("2019-01-01")) == []
    print("PASS  pit_universe returns the snapshot at or before T (empty before)")


if __name__ == "__main__":
    for fn in (test_no_lookahead, test_tz_normalised, test_fetcher_fails_closed,
               test_stage1_contract, test_rs_is_population_relative,
               test_pit_universe, test_end_to_end):
        fn()
    print("\nSIGNAL PIPELINE OK")
