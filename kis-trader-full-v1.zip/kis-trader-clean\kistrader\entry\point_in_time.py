"""
P3.2 — point-in-time fundamentals.  PURE.  NOTHING CALLS THIS YET.
==================================================================

Recovered from `minervini_fixes_complete_first_draft.zip`
(`minervini_fixes_complete_draft/point_in_time.py`, 601 bytes, 10/10 on its own
suite) and taken **close to as-is**, exactly as `PLAN_20260828` sec.4 item 6
instructs. `FundamentalObservation`, `available_as_of` and `latest_available`
keep the draft's names and semantics.

Three things are added, and each is stated here so the delta from the draft is
never in doubt:

1. `series_available_as_of` — the draft returns ONE observation, but
   `compute_math_floor` scores a four-quarter series and `_yoy_growth` compares
   against the year-ago quarter. A primitive that answers "the latest" cannot
   feed either.
2. **UNKNOWN handling.** The draft's `available_date` is a required field, so a
   record that does not know its own availability cannot be represented. Real
   fundamentals do not know it — see below — so `available_date` is now
   `Optional`, and an observation with `None` is **invisible to every query**.
   Fail closed: a datum that cannot prove when it became knowable can never be
   used to justify a historical decision.
3. `restatements` — same period, later availability. The draft's `max` already
   picks the right one; this makes them countable, because a restatement is a
   fact about the data you want to see rather than silently resolve.

WHY `available_date` IS USUALLY UNKNOWN, AND WHAT FIXES IT

`available_date` is the date the market could first have known a figure. It is
NOT the fiscal period end, and it is not the date we fetched.

Neither endpoint the screener calls supplies it:

  * Finnhub `/stock/earnings` returns `period` — the fiscal period END, which is
    `period_end` here, not availability.
  * Finnhub `/stock/metric` quarterly series: same, `period` is a period end.
  * yfinance income statement: columns are period ends.

The announcement date lives in Finnhub `/calendar/earnings`, a different call.

**The archive answers it without one.** Once fundamentals are snapshotted every
session and never overwritten, the FIRST DAY a given (ticker, period_end, value)
appears in the archive IS the day it became available to us — exact to within
one trading day, fabricated from nothing, and costing no extra API budget.

So the sequence is: capture now (patch AG), derive `available_date` from the
archive later, backfill it into the records. Until then every observation
carries `available_date=None` and this module refuses to answer — which is the
correct behaviour for a look-ahead guard with no evidence.

A DELIBERATELY REJECTED SHORTCUT

`available_date = period_end + 45 days` (the 10-Q deadline) would make every
query answerable immediately and would be conservative in direction. It is still
a fabricated date, and this project's standing rule is UNKNOWN over invention —
the same rule that keeps `avg_vol_50 = 0.0` from being guessed and a missing
close from being faked to the pivot. A fabricated availability date is exactly
the kind of number that reads as evidence three months later.

SELF-TEST

    python -m kistrader.entry.point_in_time
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from typing import Iterable, List, Optional


@dataclass(frozen=True)
class FundamentalObservation:
    """One fundamental datum and the two dates that matter about it.

    period_end      the fiscal period this value describes
    available_date  when the market could first have known it. None == UNKNOWN,
                    and UNKNOWN is invisible to every query in this module.
    value           the figure
    source_id       provenance ('finnhub', 'yfinance', ...)
    """
    period_end: date
    available_date: Optional[date]
    value: float
    source_id: str = ""


def available_as_of(obs: FundamentalObservation, decision_date: date) -> bool:
    """True only when the observation provably existed on decision_date.

    UNKNOWN availability returns False. The draft made this field required and
    so never had to decide; real data forced the question, and 'we do not know
    when this became public' must never read as 'it was public'."""
    if obs is None or obs.available_date is None:
        return False
    return obs.available_date <= decision_date


def latest_available(observations: Iterable[FundamentalObservation],
                     decision_date: date) -> Optional[FundamentalObservation]:
    """The most recently AVAILABLE observation as of decision_date, or None.

    Draft semantics preserved: ordered by `available_date`, so a restatement
    (same period_end, later availability) correctly supersedes the original."""
    valid = [x for x in (observations or []) if available_as_of(x, decision_date)]
    return max(valid, key=lambda x: x.available_date) if valid else None


def series_available_as_of(observations: Iterable[FundamentalObservation],
                           decision_date: date,
                           n: Optional[int] = None
                           ) -> List[FundamentalObservation]:
    """The n most recent PERIODS knowable on decision_date, newest period first.

    One observation per `period_end` — the latest-available one, so restatements
    resolve the same way `latest_available` resolves them. Ordered by period,
    NOT by availability, because a consumer scoring 'the last four quarters'
    means four consecutive fiscal periods, not the four most recently published
    figures (which can be three restatements of one quarter).

    Returns fewer than n, or nothing at all, when that is the truth. A caller
    that needs exactly n must check the length; this function never pads."""
    best = {}
    for x in observations or []:
        if not available_as_of(x, decision_date):
            continue
        cur = best.get(x.period_end)
        if cur is None or x.available_date > cur.available_date:
            best[x.period_end] = x
    out = sorted(best.values(), key=lambda x: x.period_end, reverse=True)
    return out if n is None else out[:n]


def restatements(observations: Iterable[FundamentalObservation],
                 decision_date: date) -> List[tuple]:
    """[(period_end, count)] for periods with more than one available figure.

    A restatement is a fact worth seeing rather than silently resolving: if a
    period has been restated, a backtest that used the original made a decision
    on a number the market later disowned."""
    seen = {}
    for x in observations or []:
        if available_as_of(x, decision_date):
            seen[x.period_end] = seen.get(x.period_end, 0) + 1
    return sorted([(p, c) for p, c in seen.items() if c > 1])


# --------------------------------------------------------------------------
def _self_test() -> int:
    ok = [0, 0]

    def check(name, cond, detail=""):
        ok[1] += 1
        ok[0] += 1 if cond else 0
        print("  [%s] %s   %s" % ("PASS" if cond else "FAIL", name, detail))

    d = date
    print("=" * 64)
    print("P3.2 POINT-IN-TIME — self test")
    print("=" * 64)

    print("the draft's own cases, preserved verbatim")
    old = FundamentalObservation(d(2026, 3, 31), d(2026, 5, 5), 1.10, "finnhub")
    check("invisible the day before it was available",
          latest_available([old], d(2026, 4, 20)) is None)
    check("visible on and after its available_date",
          latest_available([old], d(2026, 5, 6)) == old)
    check("visible exactly ON its available_date",
          latest_available([old], d(2026, 5, 5)) == old)

    print("UNKNOWN availability is invisible — the addition the draft lacked")
    unk = FundamentalObservation(d(2026, 3, 31), None, 9.99, "finnhub")
    check("available_date=None -> not available, ever",
          not available_as_of(unk, d(2099, 1, 1)))
    check("...and latest_available skips it",
          latest_available([unk], d(2099, 1, 1)) is None)
    check("...even alongside a known one, the known one wins",
          latest_available([unk, old], d(2026, 6, 1)) == old)

    print("restatement: same period, later availability")
    orig = FundamentalObservation(d(2026, 6, 30), d(2026, 8, 1), 1.20, "finnhub")
    rest = FundamentalObservation(d(2026, 6, 30), d(2026, 9, 1), 1.05, "finnhub")
    check("before the restatement, the original stands",
          latest_available([orig, rest], d(2026, 8, 15)) == orig)
    check("after it, the restatement supersedes",
          latest_available([orig, rest], d(2026, 9, 15)) == rest)
    check("restatements are countable",
          restatements([orig, rest], d(2026, 9, 15)) == [(d(2026, 6, 30), 2)])
    check("...and not counted before the second figure existed",
          restatements([orig, rest], d(2026, 8, 15)) == [])

    print("series — one per PERIOD, newest period first")
    q = [FundamentalObservation(d(2025, 9, 30), d(2025, 11, 1), 0.90),
         FundamentalObservation(d(2025, 12, 31), d(2026, 2, 1), 1.00),
         FundamentalObservation(d(2026, 3, 31), d(2026, 5, 5), 1.10),
         FundamentalObservation(d(2026, 6, 30), d(2026, 8, 1), 1.20)]
    s = series_available_as_of(q, d(2026, 8, 15))
    check("all four periods knowable", len(s) == 4, str([x.value for x in s]))
    check("newest period first", [x.value for x in s] == [1.20, 1.10, 1.00, 0.90])
    s = series_available_as_of(q, d(2026, 5, 10))
    check("a mid-window date sees only what had published",
          [x.value for x in s] == [1.10, 1.00, 0.90])
    check("n truncates to the most recent periods",
          [x.value for x in series_available_as_of(q, d(2026, 8, 15), 2)]
          == [1.20, 1.10])
    check("it NEVER pads to n",
          len(series_available_as_of(q, d(2025, 12, 1), 4)) == 1)
    s = series_available_as_of(q + [orig, rest], d(2026, 9, 15))
    check("a restated period appears ONCE, restated value",
          len(s) == 4 and s[0].value == 1.05, str([x.value for x in s]))
    check("ordered by PERIOD, not by availability",
          [x.period_end for x in s] == sorted([x.period_end for x in s],
                                              reverse=True))

    print("degenerate inputs never raise")
    check("empty -> None", latest_available([], d(2026, 1, 1)) is None)
    check("None -> None", latest_available(None, d(2026, 1, 1)) is None)
    check("empty series -> []", series_available_as_of(None, d(2026, 1, 1)) == [])

    print("=" * 64)
    print("PASSED %d / %d" % (ok[0], ok[1]))
    print("=" * 64)
    return 0 if ok[0] == ok[1] else 1


if __name__ == "__main__":
    raise SystemExit(_self_test())
