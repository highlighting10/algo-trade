"""
KIS Execution Engine — confirmation-based monitor (reliable build).

Design rule: CONFIRM, NEVER INFER.
  * Every broker inquiry is tri-state. A transport error returns UNKNOWN/None,
    NEVER a silent "not found" that could be misread as a fill. On UNKNOWN the
    state machine HOLDS and retries — it never transitions on uncertainty.
  * Fills are confirmed from the per-order executions inquiry (prompt, keyed to
    the order), not inferred from an order's absence in the unfilled list.
  * A position is marked CLOSED only on POSITIVE fill evidence (executions, or an
    uncancelled order confirmed gone-by-fill) — never because a status/balance
    call came back empty or zero.
  * An uncancelled order that has left the book is ambiguous (filled vs expired/
    externally-cancelled). We do NOT guess: we open a bounded SETTLE window and
    resolve it from positive evidence (executions catching up, or holdings
    dropping). We resend the residual only after settle confirms a non-fill, and
    close only after evidence confirms a fill. Neither direction acts on a guess.
  * Holdings are a BACKSTOP, not an authority: a 0 reading never closes a position
    (it could be a balance parse miss) — it only alerts. Every order is also
    clamped to live holdings as defence-in-depth against oversell.
  * The partial only moves to breakeven AFTER its fill is confirmed; an in-flight
    partial is cancelled before an exit begins so two sells can't rest at once.
  * Recovery is snapshot-based: every transition AND every working order persists a
    full JSON snapshot, so a reboot rehydrates exact state (incl. the live exit
    order) and reconciles to the broker.

Out of scope (next file): PENDING_ENTRY arming + the decision engine (§1.1-1.4).
Items marked  # VERIFY  need confirmation against the KIS overseas_stock examples.
"""

from __future__ import annotations

import json
import time
import sqlite3
import os
import threading
from enum import Enum
from dataclasses import dataclass, asdict
from typing import Optional

import requests


# ---------------------------------------------------------
# 0. Config
# ---------------------------------------------------------

R_PARTIAL_MULTIPLE = 3.0
PARTIAL_FRACTION = 1.0 / 3.0
# STALL_DAY 252 (PARAMETER_FREEZE Rev 3): day-10 was cutting winners --
# EMA_BREAK trades average 3.5R MFE against STALL_EXIT's 0.758R. At 252 no
# trade reaches the gate, so there is no promotion to TRAILING, STALL_EXIT
# never fires, and the EMA trail is reachable ONLY through the +3R partial.
# See tests/test_exit_state_machine.py case D, which pins that.
#
# The env override exists so the soak can exercise the promotion path with a
# short stall WITHOUT editing this verified-core file. It must never be set
# on the live box: param_snapshot reads this attribute and exits 1 on any
# value but 252.
STALL_DAY = int(os.environ.get("KIS_STALL_DAY", 252))
STALL_R_FLOOR = 1.0
EMA_LEN = 21

BASE_EXIT_SLIP = 0.02
PARTIAL_SLIP = 0.01
SLIP_STEP = 0.01
MAX_SLIP = 0.09
REPRICE_AFTER_SECS = 20
SETTLE_SECS = 8          # bounded window to resolve an ambiguous uncancelled-GONE order
MAX_EXIT_ATTEMPTS = 6
EXIT_FLAT_CONFIRM_SECS = 15.0  # mock has NO fills feed; a flat exit is confirmed only after
                              # holdings==0 has PERSISTED this long (defeats a transient parse-miss)
PRICE_BAND = 0.10
MAX_BALANCE_PAGES = 20   # safety bound on inquire-balance continuation paging

# MEASURED 2026-09-16/17 (FINDING_20260916), 2,334 samples over 16 hours at
# timeout=30 so nothing was truncated. US open hours, successful calls only:
#            p50    p90    p99    max      n
#   balance  7.86  10.56  11.99  12.16    197
#   psamount 7.78  10.00  12.32  13.19    177
#   quote    2.71   4.95   8.36  15.16    247
# rt_cd = 0 on every one. At the old timeout of 5 the client hung up on 78%
# of healthy balance calls and 83% of psamount, holding the lock ~15s each
# time to return None. 15 exceeds both account maxima by ~14%, so attempt 1
# covers the whole observed distribution and the retries stop being
# load-bearing -- they were only ever compensating for the short timeout.
#
# These two move TOGETHER. _request sleeps after EVERY failed attempt,
# including the last, so the worst-case lock hold is
#     HTTP_RETRIES * HTTP_TIMEOUT + sum(0.5 * 2**a for a in range(RETRIES))
#     = 2 * 15 + (0.5 + 1.0) = 31.5s     (was 3 * 5 + 3.5 = 18.5s)
# That is a LIVENESS bound, not a network one: reconcile()/recover() hold
# ExecutionMonitor._lock across get_all_holdings(), and on_tick() -- stop
# breaches -- takes the same lock. Reaching 31.5s needs two consecutive
# balance calls over 15s; balance never exceeded 12.16s in 197 samples.
HTTP_TIMEOUT = 15
HTTP_RETRIES = 2
TOKEN_REFRESH_MARGIN = 600

# --- REST rate limiting (token bucket) + liveness watchdog (ported from v3, made safe) ---
REST_RATE_HZ = 3             # sustained REST calls/sec; stay under the KIS gateway limit
REST_BURST = 4              # bucket capacity for short bursts (e.g. a reconnection resync)
WATCHDOG_CHECK_SECS = 15     # how often the watchdog wakes
HEARTBEAT_TIMEOUT_SECS = 60  # feed silent longer than this -> reconnect + reconcile
RECONCILE_EVERY_SECS = 300   # periodic positive-evidence reconcile (also resolves stuck 'held 0')
# --- PATCH D: broker-read vs size fact ---
# Re-read delay after an UNKNOWN or zero holdings read at the +3R trigger. The
# retry only happens while price is ABOVE +3R, so this is deliberately seconds:
# long enough not to hammer inquire-balance, short enough that a transient miss
# recovers while the trigger is still live.
PARTIAL_RETRY_SECS = 8.0

# TR_IDs verified against koreainvestment/open-trading-api (examples_llm/overseas_stock), 2026-06-30:
TR_PRICE = "HHDFS00000300"
TR_QUOTE = "HHDFS76200100"
TR_BUY_MOCK, TR_BUY_LIVE = "VTTT1002U", "TTTT1002U"
TR_SELL_MOCK, TR_SELL_LIVE = "VTTT1001U", "TTTT1006U"
TR_CANCEL_MOCK, TR_CANCEL_LIVE = "VTTT1004U", "TTTT1004U"
TR_UNFILLED_MOCK, TR_UNFILLED_LIVE = "VTTS3018R", "TTTS3018R"   # 미체결 (resting orders)
TR_FILLS_MOCK, TR_FILLS_LIVE = "VTTS3035R", "TTTS3035R"          # 체결내역 (executions)
TR_BALANCE_MOCK, TR_BALANCE_LIVE = "VTTS3012R", "TTTS3012R"      # 잔고 (holdings)

# Tri-state order status
RESTING, GONE, UNKNOWN = "RESTING", "GONE", "UNKNOWN"


# ---------------------------------------------------------
# 1. State models (§1.6)
# ---------------------------------------------------------

class PositionState(Enum):
    PENDING_ENTRY = "PENDING_ENTRY"
    FILLED = "FILLED"
    TRAILING = "TRAILING"
    PARTIAL_TAKEN = "PARTIAL_TAKEN"
    EXITING = "EXITING"
    CANCELLED = "CANCELLED"
    CLOSED = "CLOSED"


HOLDING_STATES = (PositionState.FILLED, PositionState.TRAILING, PositionState.PARTIAL_TAKEN)
TERMINAL_STATES = (PositionState.CLOSED, PositionState.CANCELLED)


@dataclass
class Position:
    ticker: str
    state: PositionState
    shares: int                       # current remaining shares we believe we hold
    entry_price: float
    stop_loss_price: float            # moves to breakeven after a CONFIRMED partial
    initial_risk_per_share: float     # FROZEN at fill = entry - initial_stop
    exchange: str = "NAS"
    days_held: int = 0
    last_roll_date: str = ""          # idempotency guard for advance_trading_day
    partial_done: bool = False
    order_key: str = ""               # deterministic trade id e.g. "MU:2026-06-29"
    pending_exit: Optional[str] = None

    # --- live exit-order tracking ---
    exit_reason: Optional[str] = None
    exit_attempts: int = 0
    live_order_id: Optional[str] = None
    live_order_qty: int = 0
    live_order_filled: int = 0
    live_order_ts: float = 0.0
    cancel_requested: bool = False
    awaiting_settle: bool = False     # resolving an ambiguous uncancelled-GONE order
    settle_ts: float = 0.0
    flat_since: float = -1.0          # monotonic ts a corroborated holdings==0 was first seen mid-exit (-1 = not timing)

    # --- live partial-order tracking (confirmed before breakeven) ---
    partial_pending: bool = False
    partial_order_id: Optional[str] = None
    partial_qty: int = 0
    partial_filled: int = 0

    def r_multiple(self, price: float) -> float:
        if self.initial_risk_per_share <= 0:
            return 0.0
        return (price - self.entry_price) / self.initial_risk_per_share

    # snapshot (de)serialization for crash recovery
    def to_dict(self) -> dict:
        d = asdict(self)
        d["state"] = self.state.value
        return d

    @staticmethod
    def from_dict(d: dict) -> "Position":
        d = dict(d)
        d["state"] = PositionState(d["state"])
        return Position(**d)


# ---------------------------------------------------------
# 2. Broker layer — tri-state inquiries
# ---------------------------------------------------------

class RateLimiter:
    """Thread-safe token bucket. acquire() blocks until a token frees up, so ALL REST
    traffic — including a reconnection resync burst — stays under the KIS gateway limit
    (the token-bucket the v3 spec asked for). Shared across tick / watchdog / WS threads."""
    def __init__(self, rate_hz, burst):
        self.rate = float(rate_hz)
        self.capacity = float(burst)
        self.tokens = float(burst)
        self.updated = time.monotonic()
        self._lock = threading.Lock()

    def acquire(self):
        while True:
            with self._lock:
                now = time.monotonic()
                self.tokens = min(self.capacity, self.tokens + (now - self.updated) * self.rate)
                self.updated = now
                if self.tokens >= 1.0:
                    self.tokens -= 1.0
                    return
                deficit = (1.0 - self.tokens) / self.rate
            time.sleep(deficit)   # sleep WITHOUT the lock so refill accounting stays honest


class KISBroker:
    def __init__(self, app_key, app_secret, cano, acnt_prdt_cd="01", is_mock=True):
        self.app_key, self.app_secret = app_key, app_secret
        self.cano, self.acnt_prdt_cd = cano, acnt_prdt_cd
        self.is_mock = is_mock
        self.base_url = ("https://openapivts.koreainvestment.com:29443" if is_mock
                         else "https://openapi.koreainvestment.com:9443")
        self._token = None
        self._token_expiry = 0.0
        self._rl = RateLimiter(REST_RATE_HZ, REST_BURST)
        # Why the LAST _failed() call failed. Read by the callers that
        # turn a failure into an operator message; see _failed below.
        self.last_fail = ""

    # -- auth --
    def _ensure_token(self) -> str:
        if self._token and time.time() < self._token_expiry - TOKEN_REFRESH_MARGIN:
            return self._token
        res = self._request("POST", f"{self.base_url}/oauth2/tokenP",
                            headers={"content-type": "application/json"},
                            json_body={"grant_type": "client_credentials",
                                       "appkey": self.app_key, "appsecret": self.app_secret})
        if res.get("_transport_error") or not res.get("access_token"):
            raise RuntimeError(f"token issuance failed: {res}")
        self._token = res["access_token"]
        self._token_expiry = time.time() + int(res.get("expires_in", 23 * 3600))
        return self._token

    def _headers(self, tr_id, tr_cont="") -> dict:
        h = {"authorization": f"Bearer {self._ensure_token()}", "appkey": self.app_key,
             "appsecret": self.app_secret, "tr_id": tr_id, "custtype": "P"}
        if tr_cont:
            h["tr_cont"] = tr_cont          # "" first call, "N" for each continuation
        return h

    # -- bounded HTTP; transport failure returns a tagged dict, never raises --
    def _request(self, method, url, headers=None, params=None, json_body=None) -> dict:
        last = None
        for attempt in range(HTTP_RETRIES):
            self._rl.acquire()                       # token-bucket paced
            try:
                r = requests.request(method, url, headers=headers, params=params,
                                     json=json_body, timeout=HTTP_TIMEOUT)
                return r.json()
            except (requests.RequestException, ValueError) as e:
                last = e
                time.sleep(0.5 * (2 ** attempt))
        return {"rt_cd": "-1", "msg1": f"network error: {last}", "_transport_error": True}

    def _request_paged(self, method, url, headers=None, params=None) -> tuple:
        """Like _request but also returns the response 'tr_cont' header (for paging).
        Returns (json_dict, resp_tr_cont). Transport failure -> (tagged dict, "")."""
        last = None
        for attempt in range(HTTP_RETRIES):
            self._rl.acquire()                       # token-bucket paced
            try:
                r = requests.request(method, url, headers=headers, params=params,
                                     timeout=HTTP_TIMEOUT)
                return r.json(), r.headers.get("tr_cont", "")
            except (requests.RequestException, ValueError) as e:
                last = e
                time.sleep(0.5 * (2 ** attempt))
        return {"rt_cd": "-1", "msg1": f"network error: {last}", "_transport_error": True}, ""

    def _failed(self, res: dict) -> bool:
        """True if the call did not succeed -- and records WHY on self.

        The verdict is unchanged; only `last_fail` is new. It exists because
        a transport timeout and a KIS rejection are DIFFERENT FAULTS that
        this one bit made indistinguishable: measured 2026-09-17, 216 of
        2,334 samples came back rt_cd=1 after ~9s (the server answering and
        saying no) against 81 genuine hangs. Both printed the same
        "holdings unreadable" line, and a bigger timeout only helps one of
        them.

        Was a @staticmethod; every call site already calls it on an
        instance, so this is not a caller-visible change.
        """
        if res.get("_transport_error"):
            self.last_fail = "transport: %s" % (
                str(res.get("msg1") or "")[:160],)
            return True
        rt = res.get("rt_cd")
        if rt not in ("0", None):
            self.last_fail = "KIS rt_cd=%s: %s" % (
                rt, str(res.get("msg1") or "")[:160])
            return True
        return False

    def _excg(self, exchange):
        return {"NAS": "NASD", "NYS": "NYSE", "AMS": "AMEX"}.get(exchange, "NASD")

    # -- market data --
    def get_quote(self, ticker, exchange="NAS") -> dict:
        res = self._request("GET",
            f"{self.base_url}/uapi/overseas-price/v1/quotations/inquire-asking-price",
            headers=self._headers(TR_QUOTE), params={"AUTH": "", "EXCD": exchange, "SYMB": ticker})
        # inquire-asking-price splits its payload: summary (last) -> output1,
        # 호가 ladder (pbid1) -> output2. Scan every dict container per field.
        def _pick(field):
            for c in ("output1", "output2", "output3", "output"):
                d = res.get(c)
                if isinstance(d, dict) and field in d:
                    return d[field]
            return 0
        last = float(_pick("last") or 0)
        bid = float(_pick("pbid1") or 0)                 # confirmed: pbid1 lives in output2
        return {"last": last, "bid": bid or last}

    # --- PATCH AF (S2 breakout volume) ---
    def get_session_volume(self, ticker, exchange="NAS"):
        """Today's cumulative traded volume in SHARES, or None == UNKNOWN.

        I3 (2026-09-04) established this endpoint and this field. `inquire-price`
        returns output.tvol (today) and output.pvol (the PREVIOUS day); `base` is
        the previous close, verified by last + diff == base to the cent and by
        pvol matching yfinance's prior-day volume to 0.06%.

        TR_PRICE had ZERO call sites in this codebase before this method -- which
        is exactly why I3 existed. get_quote reads inquire-asking-price, whose
        only volume-named fields (bvol/avol) are order-book DEPTH, not trades.

        None on every failure path, INCLUDING a literal 0: before the open a
        zero is not the fact "nothing traded", it is "no session yet". Callers
        must treat None as UNKNOWN and fail closed -- an unknown numerator can
        only REFUSE a breakout, never confirm one.
        """
        try:
            res = self._request(
                "GET", f"{self.base_url}/uapi/overseas-price/v1/quotations/price",
                headers=self._headers(TR_PRICE),
                params={"AUTH": "", "EXCD": exchange, "SYMB": ticker})
        except Exception:
            return None
        if not isinstance(res, dict) or res.get("_transport_error"):
            return None
        rt = res.get("rt_cd")
        if rt is not None and str(rt) != "0":
            return None
        out = res.get("output")
        if not isinstance(out, dict):
            return None
        try:
            v = float(out.get("tvol"))
        except (TypeError, ValueError):
            return None
        return v if v > 0 else None
    # --- end PATCH AF (S2 breakout volume) ---

    # -- holdings: source of truth for exposure. None == UNKNOWN (do not act) --
    def _balance_rows(self, excg) -> Optional[list]:
        """All holding rows across ALL pages, or None on any transport/API failure.
        inquire-balance paginates: response tr_cont F/M = more, D/E/blank = last; the
        next request echoes CTX_AREA_FK200/NK200 from the prior body with tr_cont='N'."""
        tr = TR_BALANCE_MOCK if self.is_mock else TR_BALANCE_LIVE
        rows, fk, nk, cont = [], "", "", ""
        for _ in range(MAX_BALANCE_PAGES):
            res, resp_cont = self._request_paged("GET",
                f"{self.base_url}/uapi/overseas-stock/v1/trading/inquire-balance",
                headers=self._headers(tr, cont),
                params={"CANO": self.cano, "ACNT_PRDT_CD": self.acnt_prdt_cd,
                        "OVRS_EXCG_CD": excg, "TR_CRCY_CD": "USD",
                        "CTX_AREA_FK200": fk, "CTX_AREA_NK200": nk})
            if self._failed(res):
                return None
            rows.extend(res.get("output1") or [])
            if resp_cont not in ("F", "M"):          # no more pages
                return rows
            fk = (res.get("ctx_area_fk200") or "").strip()
            nk = (res.get("ctx_area_nk200") or "").strip()
            cont = "N"
        return rows                                   # page cap hit; return what we have

    def get_holding(self, ticker, exchange="NAS") -> Optional[int]:
        rows = self._balance_rows(self._excg(exchange))
        if rows is None:
            return None
        return sum(int(r.get("ovrs_cblc_qty", 0) or 0)
                   for r in rows if r.get("ovrs_pdno") == ticker)

    def get_all_holdings(self) -> Optional[dict]:
        rows = self._balance_rows("NASD")             # NASD = all US exchanges
        if rows is None:
            return None
        out: dict = {}
        for r in rows:
            t = r.get("ovrs_pdno")
            if t:
                out[t] = out.get(t, 0) + int(r.get("ovrs_cblc_qty", 0) or 0)
        return out

    # -- executions: prompt, per-order fill confirmation. None == UNKNOWN --
    def get_fills(self, order_id) -> Optional[int]:
        """Cumulative filled qty for one order, or None on transport/API error."""
        tr = TR_FILLS_MOCK if self.is_mock else TR_FILLS_LIVE
        today = time.strftime("%Y%m%d")
        # inquire-ccnl requires PDNO, SLL_BUY_DVSN, CCLD_NCCS_DVSN, ORD_DT, ORD_GNO_BRNO, ODNO.
        # MOCK constraint: PDNO and OVRS_EXCG_CD must be "" (all); divisions must be "00".
        # ODNO must be "" (server can't filter by it) -> we match order_id client-side below.
        # NOTE: today/today window; an order straddling KST midnight could need a wider window,
        # but widening risks cross-day ODNO collisions (ODNO is a daily sequence).
        pdno = "" if self.is_mock else "%"
        excg = "" if self.is_mock else "NASD"
        res = self._request("GET",
            f"{self.base_url}/uapi/overseas-stock/v1/trading/inquire-ccnl",
            headers=self._headers(tr),
            params={"CANO": self.cano, "ACNT_PRDT_CD": self.acnt_prdt_cd,
                    "PDNO": pdno,
                    "ORD_STRT_DT": today, "ORD_END_DT": today,
                    "SLL_BUY_DVSN": "00", "CCLD_NCCS_DVSN": "00",
                    "OVRS_EXCG_CD": excg, "SORT_SQN": "DS",
                    "ORD_DT": "", "ORD_GNO_BRNO": "", "ODNO": "",
                    "CTX_AREA_FK200": "", "CTX_AREA_NK200": ""})
        if self._failed(res):
            return None
        filled = 0
        for row in (res.get("output") or []):
            if str(row.get("odno")) == str(order_id):
                filled += int(row.get("ft_ccld_qty", row.get("ccld_qty", 0)) or 0)
        return filled

    # -- order book presence: RESTING / GONE / UNKNOWN --
    def get_order_status(self, order_id) -> str:
        tr = TR_UNFILLED_MOCK if self.is_mock else TR_UNFILLED_LIVE
        res = self._request("GET",
            f"{self.base_url}/uapi/overseas-stock/v1/trading/inquire-nccs",
            headers=self._headers(tr),
            params={"CANO": self.cano, "ACNT_PRDT_CD": self.acnt_prdt_cd,
                    "OVRS_EXCG_CD": "NASD", "SORT_SQN": "DS",
                    "CTX_AREA_FK200": "", "CTX_AREA_NK200": ""})
        if self._failed(res):
            return UNKNOWN
        for row in (res.get("output") or []):
            if str(row.get("odno")) == str(order_id):
                return RESTING
        return GONE

    # -- orders --
    def place_limit_order(self, ticker, shares, price, side, exchange="NAS") -> dict:
        if side.upper() == "BUY":
            tr = TR_BUY_MOCK if self.is_mock else TR_BUY_LIVE
        else:
            tr = TR_SELL_MOCK if self.is_mock else TR_SELL_LIVE
        res = self._request("POST",
            f"{self.base_url}/uapi/overseas-stock/v1/trading/order",
            headers=self._headers(tr),
            json_body={"CANO": self.cano, "ACNT_PRDT_CD": self.acnt_prdt_cd,
                       "OVRS_EXCG_CD": self._excg(exchange), "PDNO": ticker,
                       "ORD_QTY": str(int(shares)), "OVRS_ORD_UNPR": f"{price:.2f}",
                       "CTAC_TLNO": "", "MGCO_APTM_ODNO": "",
                       "ORD_SVR_DVSN_CD": "0", "ORD_DVSN": "00"})
        ok = not self._failed(res)
        out = res.get("output", {}) or {}
        return {"ok": ok, "order_id": out.get("ODNO") or out.get("odno"),
                "msg": res.get("msg1")}

    def cancel_order(self, ticker, order_id, qty, exchange="NAS") -> dict:
        tr = TR_CANCEL_MOCK if self.is_mock else TR_CANCEL_LIVE
        res = self._request("POST",
            f"{self.base_url}/uapi/overseas-stock/v1/trading/order-rvsecncl",
            headers=self._headers(tr),
            json_body={"CANO": self.cano, "ACNT_PRDT_CD": self.acnt_prdt_cd,
                       "OVRS_EXCG_CD": self._excg(exchange), "PDNO": ticker,
                       "ORGN_ODNO": str(order_id), "RVSE_CNCL_DVSN_CD": "02",  # 02 = 취소 (cancel)
                       "MGCO_APTM_ODNO": "",
                       "ORD_QTY": str(int(qty)), "OVRS_ORD_UNPR": "0", "ORD_SVR_DVSN_CD": "0"})
        return {"ok": not self._failed(res), "msg": res.get("msg1")}


# ---------------------------------------------------------
# 3. Event store — append-only log + full snapshot per event
# ---------------------------------------------------------

class EventStore:
    def __init__(self, db_path="kis_engine_state.db"):
        self.conn = sqlite3.connect(db_path, check_same_thread=False)
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.execute('''
            CREATE TABLE IF NOT EXISTS position_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ts DATETIME DEFAULT CURRENT_TIMESTAMP,
                ticker TEXT, order_key TEXT, event_type TEXT, state_to TEXT,
                shares INTEGER, price REAL, broker_order_id TEXT, payload TEXT)''')
        self.conn.commit()

    def log(self, pos: "Position", event_type, price, broker_order_id=None, key_override=None):
        """Append an event AND a full JSON snapshot (payload) for crash recovery."""
        self.conn.execute(
            "INSERT INTO position_events (ticker, order_key, event_type, state_to, shares, "
            "price, broker_order_id, payload) VALUES (?,?,?,?,?,?,?,?)",
            (pos.ticker, key_override or pos.order_key, event_type, pos.state.value,
             pos.shares, price, broker_order_id, json.dumps(pos.to_dict())))
        self.conn.commit()

    def find_live_order(self, order_key, attempt) -> Optional[str]:
        client_key = f"{order_key}:EXIT:{attempt}"
        row = self.conn.execute(
            "SELECT broker_order_id FROM position_events WHERE order_key=? AND "
            "event_type='ORDER_SENT' AND broker_order_id IS NOT NULL ORDER BY id DESC LIMIT 1",
            (client_key,)).fetchone()
        return row[0] if row else None

    def load_open_snapshots(self) -> list:
        """Latest snapshot per trade; return only the non-terminal ones (full Positions)."""
        rows = self.conn.execute(
            "SELECT payload FROM position_events WHERE id IN "
            "(SELECT MAX(id) FROM position_events WHERE event_type NOT LIKE 'ORDER_SENT' "
            " GROUP BY order_key)").fetchall()
        out = []
        for (payload,) in rows:
            if not payload:
                continue
            pos = Position.from_dict(json.loads(payload))
            if pos.state not in TERMINAL_STATES:
                out.append(pos)
        return out

    def last_entry_snapshot(self, ticker):
        """Most recent persisted snapshot for `ticker`, with its wall-clock age in
        days (both `now` and the stored ts are UTC, so the delta is tz-consistent).
        Returns (Position, age_days) or None. Used by orphan reconciliation to match
        a late fill against the stop we recorded when we armed the order — i.e. we
        CONFIRM the holding against our own log, we do not infer a stop."""
        row = self.conn.execute(
            "SELECT payload, (julianday('now') - julianday(ts)) AS age_days "
            "FROM position_events WHERE ticker=? AND payload IS NOT NULL "
            "ORDER BY id DESC LIMIT 1", (ticker,)).fetchone()
        if not row or not row[0]:
            return None
        return Position.from_dict(json.loads(row[0])), float(row[1] or 0.0)

    # --- E10 layer 2 2026-09-19 --- progressive exposure reads OUR OWN trades.
    # --- E10 layer 2b --- ...and only the ones the STRATEGY made.
    def recent_closed_r(self, limit: int = 20, on_skip=None) -> list:
        """Realized R of the most recently CLOSED trades, NEWEST FIRST.

        CONFIRM, NEVER INFER. Every value comes from the CLOSED event's own
        price column and payload. Where R is not computable from what was
        actually logged, the entry is float('nan') -- never a filled-in guess:

          * partial_done=True   the +3R partial's FILL price is nowhere in the
                                log. _finalize_partial records the tick price,
                                and the KIS fills feed returns a QUANTITY, not
                                a price, so the blended R of a two-leg exit
                                cannot be reconstructed. Scoring the final leg
                                alone would call a +1R trade a loss.
          * initial_risk_per_share <= 0   R is undefined, not zero. Position.
                                r_multiple() returns 0.0 there, which would
                                read as a scratch; that is a different claim.
          * a payload that will not parse.

        RECONCILE_CLOSED is NOT included at all: that path logs at entry_price
        because the exit price is genuinely unknown, so it would enter as a
        fabricated 0.0.

        PROVENANCE (layer 2b). A close is SKIPPED ENTIRELY -- not scored, not
        NaN -- unless its order_key also carries an ENTRY_ event, which is
        entry_manager's namespace for a strategy entry. A hand-seeded position
        writes SEEDED_ENTRY_ARMED / SEEDED_FILL instead and is not a trade the
        strategy made. `on_skip(order_key, kind)` reports each one; kind is
        "seeded" (a known manual entry) or "unknown" (neither marker present --
        a new code path or a pruned log, and the streak may be wrong).

        loss_streak_from() STOPS at a NaN, so an unknown trade ends a streak
        rather than extending it. That is the permissive direction, and it is
        deliberate: the failure mode is a ceiling left at 1.00, which is
        today's behaviour and the deployment control. Closing it requires the
        partial fill price to be recorded at _finalize_partial.
        """
        n = max(1, int(limit))
        rows = self.conn.execute(
            "SELECT order_key, price, payload FROM position_events "
            "WHERE event_type LIKE 'CLOSED:%' AND payload IS NOT NULL "
            "ORDER BY id DESC LIMIT ?", (n * 4,)).fetchall()
        ordered, seen = [], set()
        for order_key, price, payload in rows:
            if order_key in seen:
                continue          # one trade, one verdict; newest event wins.
            seen.add(order_key)   # a re-adopted key must not count twice --
            ordered.append((order_key, price, payload))   # two rows would fire
            if len(ordered) >= n:                         # the gate a rung early
                break
        if not ordered:
            return []

        # --- E10 layer 2b --- PROVENANCE, bounded to the keys actually read.
        #
        # THE PATTERN IS ANCHORED AND THE UNDERSCORE IS ESCAPED. Both matter:
        #   * '%ENTRY_ARMED%' MATCHES 'SEEDED_ENTRY_ARMED:manual' -- the exact
        #     row this rule exists to exclude. A leading % reopens the hole
        #     while looking like it is filtering.
        #   * in SQLite LIKE, '_' is a single-character wildcard, so 'ENTRY_%'
        #     without ESCAPE also matches 'ENTRYX...'.
        #
        # THIS RESTS ON ENTRY_ARMED BEING LOGGED UNDER THE BARE order_key.
        # entry_manager uses key_override elsewhere ("{key}:ENTRY",
        # "{key}:WATCH"); adding one to ENTRY_ARMED would break provenance
        # with no error anywhere. apply_e10_2b.py --verify asserts it.
        #
        # KNOWN HAZARD, UNFIXED: pruning position_events would strip old
        # ENTRY_ rows while CLOSED: rows survive, turning real trades into
        # "unknown provenance". Nothing here guards that -- the unknown-
        # provenance alert is what would tell you it happened.
        keys = [k for k, _p, _pay in ordered]
        marks = {}
        q = ("SELECT DISTINCT order_key, "
             "CASE WHEN event_type LIKE 'ENTRY!_%' ESCAPE '!' "
             "THEN 1 ELSE 0 END "
             "FROM position_events "
             "WHERE (event_type LIKE 'ENTRY!_%' ESCAPE '!' "
             "OR event_type LIKE 'SEEDED!_%' ESCAPE '!') "
             "AND order_key IN (" + ",".join("?" * len(keys)) + ")")
        for k, is_entry in self.conn.execute(q, keys):
            marks[k] = max(marks.get(k, 0), int(is_entry))

        out = []
        for order_key, price, payload in ordered:
            mark = marks.get(order_key)
            if mark != 1:
                # SKIPPED, never NaN: NaN would END the streak, so one seeded
                # position would silently clear a genuine run of losses.
                if on_skip is not None:
                    try:
                        on_skip(order_key,
                                "seeded" if mark == 0 else "unknown")
                    except Exception:     # noqa: BLE001 -- a report must never
                        pass              # break the read it reports on
                continue
            try:
                d = json.loads(payload)
                risk = float(d.get("initial_risk_per_share") or 0.0)
                if d.get("partial_done") or risk <= 0 or price is None:
                    out.append(float("nan"))
                else:
                    out.append((float(price) - float(d["entry_price"])) / risk)
            except (ValueError, TypeError, KeyError):
                out.append(float("nan"))
        return out


# ---------------------------------------------------------
# 4. Execution monitor — confirmation-based state machine
# ---------------------------------------------------------

class ExecutionMonitor:
    def __init__(self, broker, db, alert=None, clock=time.monotonic,
                 orphan_resolver=None):
        self.broker = broker
        self.db = db
        self.alert = alert or (lambda m: print(f"[ALERT] {m}"))
        self.clock = clock
        # Optional callback resolve(ticker, held, exchange) -> Position | None.
        # When set (entry half wires it), an orphan holding that matches a recorded
        # armed order is ADOPTED with its persisted stop instead of merely alerted.
        # Default None -> legacy behaviour (alert only) is byte-for-byte unchanged.
        self.orphan_resolver = orphan_resolver
        self._lock = threading.Lock()   # serialize tick path vs WebSocket callbacks
        # --- liveness watchdog (ported from v3) ---
        self._wd_thread = None
        self._wd_stop = threading.Event()
        self._last_msg_ts = clock()
        self._positions_provider = None
        self._reconnect = None
        # --- PATCH D --- order_key -> monotonic deadline for the next holdings
        # re-read at the +3R trigger. Keyed per POSITION, not per ticker: a
        # stale key left by a closed position would otherwise suppress the
        # alert on the next position in the same name. TRANSIENT on purpose --
        # a retry timer need not survive a restart (retrying immediately after
        # one is correct), so this stays out of Position and the persisted
        # snapshot is untouched.
        self._partial_retry_at = {}

    # ===== day roll (idempotent) =====
    def advance_trading_day(self, positions, session_date: str):
        with self._lock:
            for p in positions:
                if p.state in HOLDING_STATES and p.last_roll_date != session_date:
                    p.days_held += 1
                    p.last_roll_date = session_date
                    self.db.log(p, "DAY_ROLL", p.entry_price)

    # ===== intraday tick =====
    def on_tick(self, pos: Position, price: float, bid: float):
        with self._lock:
            self._on_tick(pos, price, bid)

    def _on_tick(self, pos: Position, price: float, bid: float):
        if pos.state == PositionState.EXITING:
            self._advance_exit(pos, bid, price)
            return
        if pos.partial_pending:                      # confirm an in-flight partial first
            self._confirm_partial(pos, price)
        if pos.state not in HOLDING_STATES:
            return
        # --- PATCH D --- PRECEDENCE, PROVEN UNREACHABLE (F8, 2026-08-23).
        # These two branches can never both apply on one tick: before the
        # partial, price <= stop implies r <= -1 and therefore never >= 3;
        # after it, partial_done closes the second branch permanently. A
        # sabotage that swapped them changed nothing in any of 17 cases. Do not
        # "simplify" the ordering on the assumption that it decides something.
        # The same-bar question in the BACKTEST is settled entirely by its own
        # ambiguity convention -- there is nothing here to diff against.
        if price <= pos.stop_loss_price:             # -1R / breakeven hard stop: act now
            self._begin_exit(pos, "STOP_HIT", bid, price)
            return
        if (not pos.partial_done and not pos.partial_pending
                and pos.r_multiple(price) >= R_PARTIAL_MULTIPLE):
            self._take_partial(pos, bid)

    # ===== close (queued for next open) =====
    def on_close(self, pos: Position, close_price: float, ema: float):
        with self._lock:
            if pos.state == PositionState.FILLED and pos.days_held >= STALL_DAY:
                if pos.r_multiple(close_price) < STALL_R_FLOOR:
                    pos.pending_exit = "STALL_EXIT"
                    self.db.log(pos, "STALL_FLAGGED", close_price)
                else:
                    pos.state = PositionState.TRAILING
                    self.db.log(pos, "DAY10_SURVIVOR", close_price)
            elif pos.state in (PositionState.TRAILING, PositionState.PARTIAL_TAKEN):
                if close_price < ema:
                    pos.pending_exit = "EMA_BREAK"
                    self.db.log(pos, "EMA_FLAGGED", close_price)

    # ===== session open =====
    def on_session_open(self, pos: Position, price: float, bid: float):
        with self._lock:
            if pos.pending_exit and pos.state in HOLDING_STATES:
                reason, pos.pending_exit = pos.pending_exit, None
                self._begin_exit(pos, reason, bid, price)

    # --- PATCH D --- throttle the holdings re-read at the +3R trigger.
    def _may_read_holding(self, key) -> bool:
        return self.clock() >= self._partial_retry_at.get(key, 0.0)

    def _defer_holding_read(self, key) -> bool:
        """Arm the throttle. True if this is the FIRST deferral for this
        POSITION, so the caller alerts once instead of once per retry."""
        first = key not in self._partial_retry_at
        self._partial_retry_at[key] = self.clock() + PARTIAL_RETRY_SECS
        return first

    # ----- partial: send now, flip to breakeven only after CONFIRMED fill -----
    def _take_partial(self, pos: Position, bid: float):
        # SIZE is a fact about our own position: decide it with no broker call.
        # Reachable only for shares in {1, 2}; at 0.85% risk that needs a
        # ~$14,000 share price, so in practice this branch is dead code.
        want = int(pos.shares * PARTIAL_FRACTION)
        if want <= 0:                                 # too few shares to scale: just arm trail
            pos.partial_done = True
            pos.stop_loss_price = pos.entry_price
            pos.state = PositionState.PARTIAL_TAKEN
            self.db.log(pos, "PARTIAL_SKIPPED_SMALL", pos.entry_price)
            return
        key = pos.order_key or pos.ticker             # per POSITION, not per ticker
        if not self._may_read_holding(key):
            return                                    # inside the retry window
        held = self.broker.get_holding(pos.ticker, pos.exchange)
        if held is None or held <= 0:
            # UNKNOWN, or the broker reports flat while we believe we hold.
            # NEITHER is evidence. Breakeven is never granted on an unconfirmed
            # read -- the same rule _finalize_partial applies to a zero fill.
            if self._defer_holding_read(key) and held is not None:
                self.alert(f"{pos.ticker} at +3R but the broker reports 0 held "
                           f"while we hold {pos.shares} -- NOT partialling and "
                           f"NOT moving to breakeven. Retrying.")
            return
        self._partial_retry_at.pop(key, None)         # good read: episode over
        qty = min(want, held)
        limit = self._band(bid * (1 - PARTIAL_SLIP), bid)
        res = self.broker.place_limit_order(pos.ticker, qty, limit, "SELL", pos.exchange)
        if res["ok"] and res["order_id"]:
            pos.partial_pending = True
            pos.partial_order_id = res["order_id"]
            pos.partial_qty = qty
            pos.partial_filled = 0
            self.db.log(pos, "PARTIAL_SENT", limit, res["order_id"])
        else:
            self.alert(f"{pos.ticker} partial rejected: {res['msg']}")

    def _confirm_partial(self, pos: Position, price: float):
        filled = self.broker.get_fills(pos.partial_order_id)
        if filled is None:
            return                                    # UNKNOWN -> wait
        newly = filled - pos.partial_filled
        if newly > 0:
            pos.shares -= newly
            pos.partial_filled = filled
            self.db.log(pos, "PARTIAL_FILL", price, pos.partial_order_id)
        if pos.partial_filled >= pos.partial_qty:     # CONFIRMED -> now breakeven
            self._finalize_partial(pos, price, took=True)
            return
        if self.broker.get_order_status(pos.partial_order_id) == GONE:
            # order off the book: finalize with whatever actually filled
            self._finalize_partial(pos, price, took=pos.partial_filled > 0)

    def _finalize_partial(self, pos: Position, price: float, took: bool):
        pos.partial_pending = False
        pos.partial_order_id = None
        if took:
            pos.partial_done = True
            pos.stop_loss_price = pos.entry_price      # breakeven only after a real fill
            pos.state = PositionState.PARTIAL_TAKEN
            self.db.log(pos, "PARTIAL_TAKEN", price)
        else:
            self.alert(f"{pos.ticker} partial filled 0 — NOT moving to breakeven, will retry")
            self.db.log(pos, "PARTIAL_VOID", price)

    # ----- exit: confirmation-based, settle-gated, holdings-backstopped, idempotent -----
    def _begin_exit(self, pos: Position, reason: str, bid: float, price: float):
        if pos.state != PositionState.EXITING:
            # Cancel any in-flight partial first so two sells can't rest on the same
            # shares. Count any fills it already had (holdings clamp covers the rest).
            if pos.partial_pending and pos.partial_order_id:
                self.broker.cancel_order(pos.ticker, pos.partial_order_id,
                                         pos.partial_qty - pos.partial_filled, pos.exchange)
                f = self.broker.get_fills(pos.partial_order_id)
                if f is not None and f > pos.partial_filled:
                    pos.shares -= (f - pos.partial_filled)
                pos.partial_pending = False
                pos.partial_order_id = None
                self.db.log(pos, "PARTIAL_CANCELLED_FOR_EXIT", price)
            pos.state = PositionState.EXITING
            pos.exit_reason = reason
            pos.exit_attempts = 0
            pos.awaiting_settle = False
            pos.flat_since = -1.0
            self._clear_live(pos)
            self.db.log(pos, f"EXIT_BEGIN:{reason}", price)
        self._advance_exit(pos, bid, price)

    def _advance_exit(self, pos: Position, bid: float, price: float):
        # 1) Reconcile the working order from POSITIVE evidence only.
        if pos.live_order_id:
            filled = self.broker.get_fills(pos.live_order_id)
            if filled is None:
                return                                # UNKNOWN -> hold, never assume
            newly = filled - pos.live_order_filled
            if newly > 0:
                pos.shares -= newly
                pos.live_order_filled = filled
                self.db.log(pos, "EXIT_FILL", price, pos.live_order_id)
            if pos.shares <= 0:
                return self._close(pos, price)        # executions confirm flat
            status = self.broker.get_order_status(pos.live_order_id)
            if status == UNKNOWN:
                return
            if status == RESTING:
                pos.awaiting_settle = False
                if (self.clock() - pos.live_order_ts) >= REPRICE_AFTER_SECS and not pos.cancel_requested:
                    self.broker.cancel_order(pos.ticker, pos.live_order_id,
                                             pos.live_order_qty - pos.live_order_filled, pos.exchange)
                    pos.cancel_requested = True
                return                                # let cancel/fill resolve next tick
            # status == GONE -------------------------------------------------
            remainder = pos.live_order_qty - pos.live_order_filled
            if pos.cancel_requested:
                # WE cancelled it: fills already counted, remainder genuinely cancelled.
                self._clear_live(pos)
                pos.exit_attempts += 1
                # fall through to resend the residual (clamped)
            else:
                # Uncancelled order left the book: filled vs expired/external-cancel is
                # AMBIGUOUS. Do not guess. Open a bounded settle window and resolve from
                # positive evidence (executions catching up, or holdings dropping).
                if not pos.awaiting_settle:
                    pos.awaiting_settle = True
                    pos.settle_ts = self.clock()
                    self.db.log(pos, "EXIT_SETTLE_WAIT", price, pos.live_order_id)
                    return
                held = self.broker.get_holding(pos.ticker, pos.exchange)
                # Holdings may confirm a PARTIAL reduction, but must NEVER infer a full
                # fill that closes the position: a held==0 can be a balance PARSE-MISS,
                # not a real flat (that was bug B'). So require held > 0 here. A full
                # fill is confirmed only by executions (counted at the top of this
                # method) or, failing that, resolved by the settle timeout below.
                if held is not None and held > 0 and held <= pos.shares - remainder:
                    # a real, nonzero, reduced holding -> the order's remainder filled;
                    # shares stays > 0 by construction, so we resend the residual.
                    pos.shares -= remainder
                    self.db.log(pos, "EXIT_PARTIAL_CONFIRMED", price, pos.live_order_id)
                    pos.awaiting_settle = False
                    self._clear_live(pos)
                    # fall through to resend the residual (clamped to holdings)
                elif (self.clock() - pos.settle_ts) >= SETTLE_SECS:
                    # Settle elapsed with no evidence of a fill -> treat as a genuine
                    # non-fill (day-order expiry / external cancel) -> resend residual.
                    pos.awaiting_settle = False
                    self._clear_live(pos)
                    pos.exit_attempts += 1
                    self.db.log(pos, "EXIT_SETTLE_TIMEOUT_RESEND", price)
                else:
                    return                            # keep waiting for evidence

        # 2) No working order, shares remain -> send one, CLAMPED to live holdings.
        held = self.broker.get_holding(pos.ticker, pos.exchange)
        if held is None:
            return                                    # can't confirm exposure -> hold
        if held <= 0:
            # Holdings say flat, but executions never confirmed it. On the KIS mock the
            # fills feed (inquire-ccnl) is ALWAYS empty, so get_fills can never drive
            # shares to 0 and the executions-based close above is a dead end here. A single
            # held==0 can still be a transient balance parse-miss (bug B'), so we do NOT
            # close on one reading. We reach section 2 only with no working order (any prior
            # sell already GONE from the book), so if the flat PERSISTS for
            # EXIT_FLAT_CONFIRM_SECS while we're actively exiting, the sell filled: confirm
            # the close from holdings — the exit-side twin of adopting a late entry fill
            # against a known armed order. A real flat persists; a parse-miss does not.
            now = self.clock()
            if pos.flat_since < 0.0:
                pos.flat_since = now
                self.db.log(pos, "EXIT_FLAT_OBSERVED", price)
                return                                # first sighting -> require persistence
            if (now - pos.flat_since) >= EXIT_FLAT_CONFIRM_SECS:
                self.db.log(pos, "EXIT_FLAT_CONFIRMED", price)
                return self._close(pos, price)        # holdings-confirmed flat -> close
            self.alert(f"{pos.ticker}: holdings flat, confirming exit "
                       f"({now - pos.flat_since:.0f}/{EXIT_FLAT_CONFIRM_SECS:.0f}s)")
            return                                    # flat, but not yet persisted enough
        pos.flat_since = -1.0                         # a real holding is present -> reset the flat timer
        qty = min(pos.shares, held)                   # defence-in-depth clamp
        if qty <= 0:
            return
        if pos.exit_attempts >= MAX_EXIT_ATTEMPTS:
            self.alert(f"{pos.ticker} exit unfilled after {pos.exit_attempts} attempts — "
                       f"still working at max aggression, MANUAL CHECK ADVISED")
        attempt = pos.exit_attempts
        existing = self.db.find_live_order(pos.order_key, attempt)
        if existing:                                  # crash-safe: adopt prior send
            pos.live_order_id, pos.live_order_qty = existing, qty
            pos.live_order_filled, pos.live_order_ts = 0, self.clock()
            pos.cancel_requested = pos.awaiting_settle = False
            self.db.log(pos, "ORDER_WORKING", price, existing)   # persist for recovery
            return
        slip = min(BASE_EXIT_SLIP + attempt * SLIP_STEP, MAX_SLIP)
        limit = self._band(bid * (1 - slip), bid, price)
        res = self.broker.place_limit_order(pos.ticker, qty, limit, "SELL", pos.exchange)
        if res["ok"] and res["order_id"]:
            pos.live_order_id, pos.live_order_qty = res["order_id"], qty
            pos.live_order_filled, pos.live_order_ts = 0, self.clock()
            pos.cancel_requested = pos.awaiting_settle = False
            # per-attempt key for idempotent re-adoption after a crash:
            self.db.log(pos, "ORDER_SENT", limit, res["order_id"],
                        key_override=f"{pos.order_key}:EXIT:{attempt}")
            # main-key snapshot so recovery rehydrates the LIVE order (fixes mid-exit recovery):
            self.db.log(pos, "ORDER_WORKING", limit, res["order_id"])
        else:
            pos.exit_attempts += 1
            self.db.log(pos, f"EXIT_REJECT:{res.get('msg')}", limit)

    def _clear_live(self, pos: Position):
        pos.live_order_id = None
        pos.live_order_qty = 0
        pos.live_order_filled = 0
        pos.cancel_requested = False

    def _close(self, pos: Position, price: float):
        self._clear_live(pos)
        pos.shares = 0
        pos.state = PositionState.CLOSED
        self.db.log(pos, f"CLOSED:{pos.exit_reason}", price)

    @staticmethod
    def _band(raw_price, ref, current=None):
        c = current or ref
        lo, hi = c * (1 - PRICE_BAND + 0.005), c * (1 + PRICE_BAND - 0.005)
        return round(min(max(raw_price, lo), hi), 2)

    # ===== reboot-and-continue: snapshot recovery + broker reconcile =====
    def recover(self) -> list:
        with self._lock:
            return self._recover()

    def _recover(self) -> list:
        positions = self.db.load_open_snapshots()     # rehydrated full Positions
        now = self.clock()
        for pos in positions:
            # H2: monotonic timers do NOT survive a process restart. Rebase them so the
            # first post-recovery tick sees a sane elapsed instead of a bogus huge/negative.
            if pos.live_order_id:
                pos.live_order_ts = now
            if pos.awaiting_settle:
                pos.settle_ts = now
        truth = self.broker.get_all_holdings()
        if truth is None:
            self.alert("recover: holdings unreadable [%s] — retrying before "
                       "trusting local state"
                       % (getattr(self.broker, "last_fail", "")
                          or "no reason recorded"))
            return positions
        self._converge(positions, truth, "recover")
        return [p for p in positions if p.state not in TERMINAL_STATES]

    # ===== positive-evidence reconcile (shared by recover + watchdog) =====
    def reconcile(self, positions, source="periodic") -> list:
        """Public, lock-taking. Converge local state to the broker WITHOUT the v3
        'overwrite' hazard: a full read failure (None) changes nothing, and an
        absent/zero holding is never treated as a close. Returns still-managed positions."""
        with self._lock:
            truth = self.broker.get_all_holdings()
            if truth is None:
                self.alert("%s: holdings unreadable [%s] — reconcile skipped, "
                           "state unchanged"
                           % (source, getattr(self.broker, "last_fail", "")
                              or "no reason recorded"))
                return [p for p in positions if p.state not in TERMINAL_STATES]
            self._converge(positions, truth, source)
            return [p for p in positions if p.state not in TERMINAL_STATES]

    def _converge(self, positions, truth: dict, source: str):
        """Lock-free core (caller holds _lock). Broker wins ONLY on positive evidence:
          * held == shares            -> nothing to do
          * held == 0 (or absent)     -> AMBIGUOUS (parse-miss / page gap / transient).
                                         Close ONLY if the working order's fills confirm
                                         the full qty; otherwise HOLD and alert.
          * held > 0 and != shares    -> adopt broker qty, logging the exact delta.
        EXITING positions are owned by the exit loop and left untouched here."""
        for pos in positions:
            if pos.state not in HOLDING_STATES:        # skip EXITING / terminal
                continue
            held = truth.get(pos.ticker, 0)
            if held == pos.shares:
                continue
            if held == 0:
                f = self.broker.get_fills(pos.live_order_id) if pos.live_order_id else None
                if f is not None and pos.live_order_qty > 0 and f >= pos.live_order_qty:
                    self.alert(f"{source}: {pos.ticker} flat CONFIRMED by fills — CLOSED")
                    pos.shares = 0
                    pos.state = PositionState.CLOSED
                    self.db.log(pos, f"RECONCILE_CLOSED:{source}", pos.entry_price)
                else:
                    self.alert(f"{source}: {pos.ticker} broker=0 but no positive fill evidence "
                               f"— NOT closing (possible parse-miss/page gap); local={pos.shares}")
                    self.db.log(pos, f"RECONCILE_ZERO_UNCONFIRMED:{source}", pos.entry_price)
                continue
            # held > 0 and differs: a real, nonzero qty -> broker wins, audit the delta.
            # --- PATCH AI (persist the adopted qty) --- ADOPT FIRST, THEN LOG.
            # EventStore.log serialises pos.to_dict(), so logging before the
            # mutation persisted the OLD count and the snapshot never converged:
            # every restart reloaded the stale qty and re-adopted it -- three
            # times in 22 hours on the live box (INSW 15->26, 2026-09-04/05),
            # while status.py kept printing 15 against an account holding 26.
            # The RECONCILE_CLOSED branch above already had this order.
            # Both strings are unchanged: `prev` carries the pre-adopt value.
            prev = pos.shares
            pos.shares = held
            self.alert(f"{source}: {pos.ticker} qty local={prev} broker={held} — adopting broker")
            self.db.log(pos, f"RECONCILE_DELTA:{prev}->{held}:{source}", pos.entry_price)
            # --- end PATCH AI (persist the adopted qty) ---
        # orphans: broker holds something with no LIVE local record. A late fill of an
        # entry we already ruled expired lands here (settle window < broker fill latency).
        # Try to CONFIRM it against our own armed record (recorded stop) before giving up;
        # only a holding with no matching armed order stays alert-only (genuine unknown).
        known = {p.ticker for p in positions}
        for tkr, held in truth.items():
            if not held or tkr in known:
                continue
            adopted = None
            if self.orphan_resolver is not None:
                try:
                    adopted = self.orphan_resolver(tkr, int(held))
                except Exception as ex:
                    self.alert(f"{source}: orphan_resolver({tkr}) error: {ex}")
            if adopted is not None:
                self.alert(f"{source}: adopted late-fill {tkr} {adopted.shares}sh "
                           f"stop={adopted.stop_loss_price:.2f} from armed record — now managed")
            else:
                self.alert(f"{source}: broker holds {held} {tkr} with no local record — investigate")

    # ===== liveness watchdog: heartbeat -> reconnect + reconcile (ported from v3) =====
    def start_watchdog(self, positions_provider, reconnect=None):
        """positions_provider() -> current live [Position]; reconnect() re-establishes the
        WS feed (optional). Daemon thread; safe no-op if already running."""
        if self._wd_thread and self._wd_thread.is_alive():
            return
        self._positions_provider = positions_provider
        self._reconnect = reconnect
        self._wd_stop.clear()
        self._last_msg_ts = self.clock()
        self._wd_thread = threading.Thread(target=self._watchdog_loop, name="kis-watchdog", daemon=True)
        self._wd_thread.start()

    def heartbeat(self):
        """Call from the WS on-message callback to mark the feed alive."""
        self._last_msg_ts = self.clock()

    def stop_watchdog(self):
        self._wd_stop.set()
        if self._wd_thread:
            self._wd_thread.join(timeout=2)

    def _watchdog_loop(self):
        last_reconcile = self.clock()
        while not self._wd_stop.wait(WATCHDOG_CHECK_SECS):
            now = self.clock()
            silent = now - self._last_msg_ts
            if silent > HEARTBEAT_TIMEOUT_SECS:        # dead-man's switch
                self.alert(f"watchdog: feed silent {silent:.0f}s > {HEARTBEAT_TIMEOUT_SECS}s "
                           f"— reconnect + reconcile")
                if self._reconnect:
                    try:
                        self._reconnect()
                    except Exception as ex:
                        self.alert(f"watchdog: reconnect failed: {ex}")
                self._last_msg_ts = self.clock()
                self._safe_reconcile("watchdog")
                last_reconcile = self.clock()
            elif (now - last_reconcile) >= RECONCILE_EVERY_SECS:
                self._safe_reconcile("periodic")       # safety-net; also resolves stuck 'held 0'
                last_reconcile = self.clock()

    def _safe_reconcile(self, source):
        if not self._positions_provider:
            return
        try:
            self.reconcile(self._positions_provider(), source)
        except Exception as ex:
            self.alert(f"{source} reconcile error: {ex}")
