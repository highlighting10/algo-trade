# DEPLOY CLOSED — box on `089196c`, three observability fixes (2026-09-17)

Third deploy in three days. Carries nothing that changes what the system trades —
all three commits make an existing failure **say what it is**. That is the point:
a fault logged 522+ times went a month without a cause because one bit collapsed
two different faults into one sentence.

---

## 1. What is on the box now

```
/home/kis/kis-trader   detached HEAD at tag deploy-soak-2026-09-17 = 089196c
                       = main be27e31 + cherry-pick "VCP_SCORE_THRESHOLD 75 -> 45"
```

Three commits the box did not have (plus three docs-only):

```
1b6fe94  cli: pin stdout/stderr to UTF-8 so a redirected gate cannot die mid-suite
84bbd9b  entry: a buying-power UNKNOWN now names its cause, not just the policy
be27e31  engine: _failed records WHY, so holdings unreadable names its cause
```

| gate | result |
|---|---|
| `pytest -q` | **2 failed / 88 passed** — the two named drift guards, no third red |
| `param_snapshot` | exit **1**, exactly one differing parameter. 23/23 PINNED, 14/14 IDENTITY |
| `KIS_STALL_DAY=6` | prints **6** — the systemd `Environment=` route still works |
| boot record | `tree = 089196c`, no `+dirty`; `KIS_MOCK=1` |
| editable install | resolves to `/home/kis/kis-trader/kistrader` |
| `clock_check` | ET = UTC−4, `session_date 2026-09-17`, `is_trading_day True` |
| `recover()` | `started; 7 live; 0 pending entry; 0 watching; phase=CLOSED` — no "no local record" |
| units | `kistrader` active · `kistrader-deadman` active, ARMED, FRESH · all four `enabled` |
| supervisor | one `starting child`. No storm. |

Outage **06:35:26 → 06:37:29 UTC**, ~2 minutes, market closed, 7 hours before the
open. Rollback: `git checkout $(cat ~/backups/PRE_DEPLOY_HEAD.txt)` → `9adbb2b`;
the prior target is preserved at `~/backups/PRE_DEPLOY_HEAD_20260915.txt` →
`6869ec7`. DB backup `~/backups/pre_deploy_20260917.db`, 249,856 B, taken through
python's `sqlite3` module.

Box found exactly where the documents said — `9adbb2b`, clean tree, four units
enabled. Second deploy running in succession with no drift.

## 2. Why this deployed mid-week instead of waiting

The original plan was to hold until after the 20:00 UTC close so that today stayed
a clean no-probe control day. That was over-cautious and the call was reversed:

* the deploy is ~2 minutes of downtime **seven hours before the open**, and the
  control measures the in-session failure rate;
* the three commits change message text, not behaviour, so the count stays
  comparable either way;
* 06:35 UTC is inside the documented window (after the previous close, before the
  12:00 UTC screener timer);
* waiting put the reason data on Friday — the last session before the weekend.

## 3. What it buys, and what it is NOT

Every one of the three makes something that already failed explain itself:

```
periodic: holdings unreadable [KIS rt_cd=1: ...] — reconcile skipped
periodic: holdings unreadable [transport: ... Read timed out ...] — reconcile skipped
```

That distinction is the whole deploy. Measured 09-17 over 2,334 samples: **216
server rejections (`rt_cd=1`) against 81 genuine hangs**, and `_failed` returned
the same bit for both. A bigger timeout helps one and does nothing for the other.

**`HTTP_TIMEOUT` and `HTTP_RETRIES` are deliberately NOT in this deploy.** They get
set against the open-hours distribution once the log can say which fault it is
looking at. Shipping the constant first would have fixed the smaller half and left
the rejections producing an identical symptom — the same trap that hid this for a
month.

## 4. First evidence expected

No failure has occurred since the 06:36 restart, because 07h–10h UTC is the quiet
band (`FINDING_20260916` §9). The first `[reason]` line arrives with the **13:30 UTC
US open**, which is also the first test of whether `rt_cd=1` or `transport`
dominates.

```bash
grep "holdings unreadable \[" kistrader_alerts.log | tail -20
```

## 5. Running alongside

A `tvol` probe started 10:23 UTC (PID 175045, `~/tvol_20260917.csv`, one KIS call
per minute, deadline 20:05 UTC) to settle E9's blocker — the mock's session volume
is *believed* ~15 min delayed and that has never been measured.

Its first row already contradicts an assumption in the shipped code:

```
2026-09-17T10:23:46Z,42679,334.2012,0
```

`tvol = 42,679` three hours **before** the US open, where
`get_session_volume`'s own docstring expects zero (*"before the open a zero is not
the fact 'nothing traded', it is 'no session yet'"*) and the code returns `None`
for `v <= 0`. Either pre-market volume counts, or the field is stale from the
previous session. Watching whether `tvol` **resets** at 13:30 UTC decides which,
and the two have different consequences for every `THIN` verdict recorded so far.

## 6. Carried forward

1. **`HTTP_TIMEOUT` / `HTTP_RETRIES`** — after tonight's reason breakdown, moved
   together, with the lock-hold bound stated in the commit.
2. **`ARM BLOCKED: no equity reading` is a misnomer** — `_account_state()` returns
   `None` for a holdings failure too, and the caller names the wrong cause.
   Resolved 09-17, fix rides with the timeout patch.
3. **The mock degrades whenever a market is open** (`FINDING_20260916` §9). Not
   fixable from our side; it bounds what any constant can achieve.
4. `docs/FINDING_20260916...md` amendments are laptop-only until committed —
   docs-only, so they do not invalidate the tag.
5. The box still wants a reboot; all units are `enabled`, so it self-recovers.
   **Not before 20:05 UTC** — it would kill the tvol probe.
