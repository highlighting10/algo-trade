"""Deterministic self-test. Verifies mechanics with NO data feed and NO network."""
import numpy as np, pandas as pd
from minervini_backtest import (STALL_DAY, BTCandidate, BacktestConfig, DecisionConfig,
                                compare_settings, load_sector_map,
                                run, run_band)

DATES = pd.bdate_range("2024-01-02", periods=60)


def ohlc(dates, closes, gap_first=None):
    c = np.asarray(closes, float)
    o = np.r_[c[0], c[:-1]]
    if gap_first is not None:
        o = o.copy(); o[1] = gap_first
    h = np.maximum(o, c) * 1.01
    l = np.minimum(o, c) * 0.99
    return pd.DataFrame({"Open": o, "High": h, "Low": l, "Close": c}, index=dates)


def cand(t, **kw):
    d = dict(ticker=t, exchange="NAS", pivot=100.0, contraction_low=95.0, atr=2.0,
             last_close=99.0, rs_rating=90, vcp_score=85.0, session_date="2024-01-02")
    d.update(kw)
    return BTCandidate(**d)


def base_cfg(**kw):
    d = dict(rank_mode="rs_only", sector_map={"A": "Tech", "B": "Tech", "C": "Health",
                                              "D": "Tech", "E": "Energy"},
             slippage_bps=0, broker_commission_pct=0, sec_fee_pct=0, taf_per_share=0)
    d.update(kw)
    return BacktestConfig(**d)


# ---------------------------------------------------------------- fail-closed
def test_fail_closed():
    try:
        BacktestConfig()                       # type: ignore[call-arg]
        raise AssertionError("rank_mode should be REQUIRED")
    except TypeError:
        pass
    try:
        BacktestConfig(rank_mode="whatever", sector_map={"A": "T"})
        raise AssertionError("bad rank_mode should raise")
    except ValueError as e:
        assert "seed doc" in str(e).lower() or "rank_mode" in str(e)
    try:
        BacktestConfig(rank_mode="rs_only")    # sector_cap on, no map
        raise AssertionError("empty sector_map with sector_cap should raise")
    except ValueError as e:
        assert "SILENTLY more permissive" in str(e)
    # explicit opt-outs work
    BacktestConfig(rank_mode="rs_only", allow_missing_sector_map=True)
    BacktestConfig(rank_mode="rs_only", decision=DecisionConfig(sector_cap=0))
    # bare-ticker signal refused
    p = {"A": ohlc(DATES, np.linspace(99, 130, 60))}
    try:
        run(p, {DATES[0]: ["A"]}, base_cfg())
        raise AssertionError("bare ticker should be refused")
    except TypeError as e:
        assert "bare ticker" in str(e)
    print("PASS  fail-closed guards")


# ------------------------------------------------------- production stop/size
def test_stop_and_size():
    c = np.r_[99, 101, 102, 96, 90, np.linspace(89, 80, 55)]
    p = {"A": ohlc(DATES, c)}
    eq, tr, st, dr, dg = run(p, {DATES[0]: [cand("A")]}, base_cfg())
    t = tr[0]
    # limit = pivot*1.005 = 100.5 ; structural = 95*0.995 = 94.525
    # atr floor: depth 5% -> below depth_shallow -> mult = atr_mult_min 1.3
    #            100.5 - 1.3*2.0 = 97.9 ; stop = min(94.525, 97.9) = 94.53 (rounded)
    assert abs(t.entry_price - 100.5) < 1e-9, t.entry_price
    assert t.reason == "STOP_HIT", t.reason
    assert abs(t.exit_price - 94.53) < 1e-9, t.exit_price
    rps = 100.5 - 94.53
    assert t.shares == int(np.floor((100_000 * 0.0075) / rps)), t.shares
    assert abs(t.r_at_exit + 1.0) < 1e-6, t.r_at_exit      # a stop is exactly -1R
    print(f"PASS  production geometry: entry {t.entry_price} stop {t.exit_price} "
          f"shares {t.shares} r {t.r_at_exit}")


def test_gap_above_limit_rejected():
    c = np.r_[99, 120, np.linspace(121, 140, 58)]
    p = {"A": ohlc(DATES, c, gap_first=115.0)}             # opens above the 100.5 limit
    eq, tr, st, dr, dg = run(p, {DATES[0]: [cand("A")]}, base_cfg())
    assert len(tr) == 0, tr
    assert dg["drops_by_reason"].get("gap_above_limit") == 1, dg["drops_by_reason"]
    print("PASS  gap above limit -> no chase, counted")


# -------------------------------------------------------------- exit rules
def test_partial_then_breakeven():
    # rip to +3R (118.41), then collapse to breakeven INSIDE the EMA(21) warm-up
    # window so the breakeven stop is the only exit that can fire.
    c = np.r_[99, 101, 125, 124, 100, np.linspace(99, 90, 55)]
    p = {"A": ohlc(DATES, c)}
    eq, tr, st, dr, dg = run(p, {DATES[0]: [cand("A")]}, base_cfg())
    assert dg["partials_taken"] == 1, dg
    t = tr[0]
    assert t.reason == "STOP_HIT" and abs(t.exit_price - 100.5) < 1e-9, (t.reason, t.exit_price)
    assert abs(t.r_at_exit) < 1e-6, t.r_at_exit            # breakeven stop = 0R
    # the partial sold floor(125/3)=41 shares, leaving 84 on the runner
    assert t.shares == 125 - int(125 / 3), t.shares
    print(f"PASS  +3R partial -> breakeven stop (exit {t.exit_price}, {t.r_at_exit}R, "
          f"{t.shares} shares left)")


def test_stall_exit_day10():
    c = np.r_[99, 101, [102.0] * 58]                       # flat: never reaches 1R
    p = {"A": ohlc(DATES, c)}
    eq, tr, st, dr, dg = run(p, {DATES[0]: [cand("A")]}, base_cfg())
    t = tr[0]
    assert t.reason == "STALL_EXIT", t.reason
    held = len(DATES[(DATES > t.entry_date) & (DATES <= t.exit_date)])
    # days_held hits STALL_DAY on the 10th session AFTER entry; the stall is
    # flagged at that close and filled at the NEXT open -> 11 sessions elapsed.
    assert held == STALL_DAY + 1, held
    print(f"PASS  stall exit: flagged at days_held={STALL_DAY}, filled next open "
          f"({held} sessions after entry)")


def test_ema_break_after_day10():
    c = np.r_[99, 101, np.linspace(103, 145, 30), np.linspace(144, 100, 28)]
    p = {"A": ohlc(DATES, c)}
    eq, tr, st, dr, dg = run(p, {DATES[0]: [cand("A")]}, base_cfg())
    reasons = [t.reason for t in tr]
    assert "EMA_BREAK" in reasons or dg["partials_taken"] == 1, (reasons, dg)
    print(f"PASS  trail/EMA path exercised: {reasons}")


# ------------------------------------------------- v1 bugs that are now fixed
def test_eod_open_forced():
    p = {"A": ohlc(DATES, np.linspace(99, 400, 60))}       # never exits
    eq, tr, st, dr, dg = run(p, {DATES[0]: [cand("A")]}, base_cfg())
    assert dg["eod_open_forced"] == 1 and st["num_trades"] == 1, (dg, st)
    assert st["win_rate_pct"] == 100.0, st
    print("PASS  open-at-end position is force-closed and counted (v1 bug #1)")


def test_threshold_and_drops_counted():
    p = {t: ohlc(DATES, np.linspace(99, 130, 60)) for t in "ABC"}
    sigs = [cand("A", vcp_score=85), cand("B", vcp_score=60), cand("C", vcp_score=79.9)]
    eq, tr, st, dr, dg = run(p, {DATES[0]: sigs}, base_cfg(vcp_threshold=80.0))
    assert dg["drops_by_reason"].get("below_vcp_threshold") == 2, dg["drops_by_reason"]
    assert dg["drops_total"] >= 2
    print(f"PASS  threshold drops counted: {dg['drops_by_reason']}")


def test_sector_cap_binds():
    p = {t: ohlc(DATES, np.linspace(99, 130, 60)) for t in "ABD"}
    sigs = [cand("A", rs_rating=95), cand("B", rs_rating=94), cand("D", rs_rating=93)]
    eq, tr, st, dr, dg = run(p, {DATES[0]: sigs}, base_cfg())   # all three are Tech
    capped = [x for x in dr.detail if "sector cap" in x[2]]
    assert len(capped) == 1, dr.detail
    assert dg["sector_cap_measured"] is True
    print(f"PASS  sector cap binds (1 rejected of 3 Tech): {capped[0][1]}")


# --------------------------------------------------------------- the band
def test_band():
    c = np.r_[99, 101, 125, np.linspace(124, 92, 57)]
    p = {"A": ohlc(DATES, c)}
    out = run_band(p, {DATES[0]: [cand("A")]}, base_cfg())
    b = out["band"]
    assert set(("worst", "best", "band")) <= set(out)
    assert b["ambiguous_bars"] >= 0
    print(f"PASS  band: total_return {b['total_return_pct']}  "
          f"ambiguous_bars={b['ambiguous_bars']}")


def test_frozen_sector_map():
    import tempfile, os
    good = "ticker,sector\nA,Information Technology\nB,Health Care\n"
    bad = "ticker,sector\nA,Information Technology\nB,\n"
    with tempfile.TemporaryDirectory() as td:
        gp, bp = os.path.join(td, "g.csv"), os.path.join(td, "b.csv")
        open(gp, "w").write(good); open(bp, "w").write(bad)
        m = load_sector_map(gp)
        assert m == {"A": "Information Technology", "B": "Health Care"}, m
        try:
            load_sector_map(bp)
            raise AssertionError("blank sector should raise")
        except ValueError as e:
            assert "silently disables" in str(e)
    print("PASS  frozen sector map loads; blank sector fails closed")


def test_unmapped_ticker_dropped():
    p = {t: ohlc(DATES, np.linspace(99, 130, 60)) for t in "AE"}
    # "E" is Energy in base_cfg's map; build a map that omits it entirely
    cfg = BacktestConfig(rank_mode="rs_only", sector_map={"A": "Tech"},
                         slippage_bps=0, broker_commission_pct=0, sec_fee_pct=0, taf_per_share=0)
    eq, tr, st, dr, dg = run(p, {DATES[0]: [cand("A"), cand("E")]}, cfg)
    assert dg["drops_by_reason"].get("unmapped_sector") == 1, dg["drops_by_reason"]
    assert {t.ticker for t in tr} == {"A"}, tr
    print("PASS  ticker missing from the frozen map is dropped and counted")


def test_worst_bound_decision_rule():
    c = np.r_[99, 101, 125, np.linspace(124, 92, 57)]
    p = {"A": ohlc(DATES, c)}
    runs = {}
    for label, thr in (("thr_80", 80.0), ("thr_60", 60.0)):
        runs[label] = run_band(p, {DATES[0]: [cand("A", vcp_score=85)]},
                               base_cfg(vcp_threshold=thr))
    for label, r in runs.items():
        assert r["conservative"] is r["worst"]["stats"], label
        lo, hi = r["band"]["total_return_pct"]
        assert r["conservative"]["total_return_pct"] == lo, (label, lo, hi)
    ranked = compare_settings(runs, metric="expectancy_R")
    assert len(ranked) == 2 and ranked[0][1] >= ranked[1][1], ranked
    print(f"PASS  decision rule uses the worst bound only: {ranked}")


if __name__ == "__main__":
    for fn in (test_fail_closed, test_stop_and_size, test_gap_above_limit_rejected,
               test_partial_then_breakeven, test_stall_exit_day10,
               test_ema_break_after_day10, test_eod_open_forced,
               test_threshold_and_drops_counted, test_sector_cap_binds, test_band,
               test_frozen_sector_map, test_unmapped_ticker_dropped,
               test_worst_bound_decision_rule):
        fn()
    print("\nALL SELF-TESTS PASSED")
