#!/usr/bin/env python3
"""
F8 -- sabotage proof for the DIFF ITSELF.

`sabotage_check.py` proves the fixture detects defects planted in engine_v2.
This proves the other direction, which is the one F8 actually needs: plant a
defect in the HARNESS and confirm the diff goes red. A green diff between two
engines is worthless until it has been shown that a disagreement would surface.

Throwaway copies only; `minervini_backtest.py` is never modified. Every patch
asserts its anchor matched exactly once (standing rule 4).

    python sabotage_harness.py --prod-root /path/to/kis-trader-clean \\
                               --harness /path/to/minervini_backtest.py
"""
from __future__ import annotations

import argparse
import os
import shutil
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from engine_side import EngineExitRunner, load_production   # noqa: E402
import cases as C                                           # noqa: E402


SABOTAGES = [
    ("gap-through fills at the STOP instead of the OPEN",
     """                fill = pos.stop_loss_price if entry_bar else (
                    o if o < pos.stop_loss_price else pos.stop_loss_price)""",
     """                fill = pos.stop_loss_price""",
     "would hide Rev 3 F7's 'realised max risk is 1.07R' entirely",
     ["2"]),

    ("elif -> if in the close block (the R2 structural fact)",
     "            elif pos.state in (ExitState.TRAILING, ExitState.PARTIAL_TAKEN):",
     "            if pos.state in (ExitState.TRAILING, ExitState.PARTIAL_TAKEN):",
     "the EMA test would also run on the promotion bar",
     ["5b"]),

    ("queued exit fills at the CLOSE instead of the next OPEN",
     '            close_position(tkr, positions[tkr], d, float(df.at[d, "Open"]), reason)',
     '            close_position(tkr, positions[tkr], d, float(df.at[d, "Close"]), reason)',
     "1.0R per stalled trade, in the flattering direction",
     ["6", "8", "8b"]),

    ("partial uses round() instead of int()",
     "                qty = int(pos.shares * PARTIAL_FRACTION)",
     "                qty = round(pos.shares * PARTIAL_FRACTION)",
     "scale-out size differs whenever shares mod 3 == 2",
     ["9"]),

    ("stop loses precedence to the +3R partial on a same-bar touch",
     "            if stop_touched and (worst or not partial_touched):",
     "            if stop_touched and (not partial_touched):",
     "the pessimistic same-bar assumption would silently become optimistic",
     ["3"]),
]


def patch(src, anchor, repl, label):
    n = src.count(anchor)
    if n != 1:
        raise AssertionError(f"[{label}] anchor matched {n} times, expected 1 "
                             f"-- refusing to patch (standing rule 4)")
    return src.replace(anchor, repl)


def diff_all(E, harness, tick_path="worst"):
    """Return {case_key: 'agree' | 'DISAGREE(...)' | 'error'} over the diff cases."""
    out = {}
    for case in C.ALL:
        if case.tick_path:            # bound probe, not an agreement test
            continue
        if getattr(case, "differs", ""):
            # a KNOWN, characterised difference (cases 10/11). Compare against
            # the PINNED harness values instead of against the engine, so a
            # planted defect still surfaces here.
            try:
                h = harness.run(case)
                ok = (h.exit_reason == case.h_reason and h.exit_bar == case.h_bar
                      and abs((h.exit_price or 0) - (case.h_price or 0)) <= 1e-4
                      and abs((h.r_multiple or 0) - (case.h_r or 0)) <= 1e-3)
                out[case.key] = "agree" if ok else (
                    f"PINNED DIFFERENCE MOVED: {h.exit_reason} bar={h.exit_bar} "
                    f"px={h.exit_price} R={h.r_multiple}")
            except Exception as ex:
                out[case.key] = f"error {type(ex).__name__}: {str(ex)[:90]}"
            continue
        try:
            t = EngineExitRunner(E, stall_day=case.stall_day, tick_path=tick_path).run(
                case.bars, entry_price=C.ENTRY, stop_price=C.STOP,
                shares=case.shares, emas=case.emas)
            h = harness.run(case)
            same = (t.key() == h.key()
                    and (t.r_multiple is None) == (h.r_multiple is None)
                    and (t.r_multiple is None
                         or abs(t.r_multiple - h.r_multiple) <= 1e-3))
            out[case.key] = "agree" if same else (
                f"DISAGREE engine {t.key()} R={t.r_multiple} "
                f"vs harness {h.key()} R={h.r_multiple}")
        except Exception as ex:
            out[case.key] = f"error {type(ex).__name__}: {str(ex)[:90]}"
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--prod-root", required=True)
    ap.add_argument("--harness", required=True)
    args = ap.parse_args()

    from harness_side import load_harness_adapter

    E, _P = load_production(args.prod_root)
    with open(args.harness, encoding="utf-8") as fh:
        original = fh.read()

    print("=" * 78)
    print("F8 SABOTAGE PROOF -- the DIFF must go red when the HARNESS is broken")
    print("=" * 78)

    # baseline
    for mod in [m for m in list(sys.modules) if m in ("kistrader",) or m.startswith("kistrader.")]:
        del sys.modules[mod]
    base = load_harness_adapter(args.harness, args.prod_root)
    baseline = diff_all(E, base)
    disagreeing = [k for k, v in baseline.items() if v != "agree"]
    print(f"  baseline: {len(baseline)} diff cases, "
          f"{'ALL AGREE' if not disagreeing else 'disagreements: ' + str(disagreeing)}")
    if disagreeing:
        print("  cannot run the proof from a red baseline.")
        return 1
    print()

    failures = []
    for i, (name, anchor, repl, why, must_break) in enumerate(SABOTAGES):
        tmp = tempfile.mkdtemp(prefix="f8hsab_")
        try:
            broken = os.path.join(tmp, "minervini_backtest.py")
            with open(broken, "w", encoding="utf-8") as fh:
                fh.write(patch(original, anchor, repl, name))
            for mod in [m for m in list(sys.modules)
                        if m in ("kistrader", "f8_harness") or m.startswith("kistrader.")]:
                del sys.modules[mod]
            adapter = load_harness_adapter(broken, args.prod_root)
            got = diff_all(E, adapter)
            caught = sorted(k for k, v in got.items() if v != "agree")

            print(f"[{i + 1}] {name}")
            print(f"     effect: {why}")
            print(f"     diff went red on: {', '.join(caught) if caught else '(nothing)'}")
            for k in caught[:3]:
                print(f"        {k}: {got[k]}")
            missed = [k for k in must_break if k not in caught]
            if missed:
                print(f"     [FAIL] not caught in case(s) {missed}")
                failures.append(name)
            else:
                print(f"     [PASS] caught by {', '.join(must_break)}")
            print()
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    print("=" * 78)
    if failures:
        print(f"PROOF FAILED for: {'; '.join(failures)}")
        print("A green diff cannot be trusted -- it has not been shown able to fail.")
        return 1
    print("PROOF PASSED -- every planted harness defect surfaced in the diff.")
    print(f"The {len(baseline)}-case green result is therefore evidence, not an "
          f"absence of testing.")
    print("=" * 78)
    return 0


if __name__ == "__main__":
    sys.exit(main())
