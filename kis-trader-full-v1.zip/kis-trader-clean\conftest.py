# Makes `import kistrader...` and the sibling test module resolve for pytest AND
# for direct `python tests/xxx.py` runs, without installing the package.
import os, sys
_ROOT = os.path.dirname(os.path.abspath(__file__))
for _p in (_ROOT, os.path.join(_ROOT, "tests")):
    if _p not in sys.path:
        sys.path.insert(0, _p)
