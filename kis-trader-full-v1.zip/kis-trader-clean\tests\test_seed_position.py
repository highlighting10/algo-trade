#!/usr/bin/env python3
"""Tests for the seed AND close tools: fail-closed guards, a correct FILLED
snapshot recovery adopts, and a terminal close that recovery stops rehydrating.
Uses a temp DB via KIS_* env; the broker is injected, so no network."""
from __future__ import annotations
import os, sys, tempfile

# Self-locating AND shadow-proof. Two separate problems, both measured:
#  1. `kistrader` and `screeners` are not installed packages (pyproject
#     packages.find includes only kistrader*), so a DIRECT run -- sys.path[0] is
#     tests/ -- cannot import either. pytest happens to work because pyproject
#     sets pythonpath = [".", "tests"].
#  2. kis-backtest ships a partial COPY of kistrader/. Run pytest from the parent
#     directory and it collects both projects; whichever imports first wins
#     sys.modules, and after that sys.path is irrelevant -- Python never
#     re-resolves an imported package. That produced five collection errors
#     naming the wrong repo.
import os as _os, sys as _sys
_ROOT = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))
for _p in (_os.path.join(_ROOT, "screeners"), _ROOT):
    while _p in _sys.path:
        _sys.path.remove(_p)                 # move to the FRONT, not merely present
    _sys.path.insert(0, _p)
_k = _sys.modules.get("kistrader")
_kf = _os.path.abspath(getattr(_k, "__file__", "") or "") if _k is not None else ""
if _k is not None and not _kf.startswith(_ROOT + _os.sep):
    print(f"[path] evicting a foreign kistrader loaded from {_kf!r}; "
          f"this suite tests {_ROOT!r}")
    for _m in [_m for _m in list(_sys.modules)
               if _m == "kistrader" or _m.startswith("kistrader.")]:
        del _sys.modules[_m]

from kistrader.core.engine_v2 import EventStore, PositionState

PASS, FAIL = [], []
def check(name, cond, detail=""):
    (PASS if cond else FAIL).append(name)
    print(f"  [{'PASS' if cond else 'FAIL'}] {name}" + (f"  ({detail})" if detail and not cond else ""))

def _env(db_path, mock="1"):
    os.environ["KIS_APP_KEY"] = "x"; os.environ["KIS_APP_SECRET"] = "x"
    os.environ["KIS_CANO"] = "123"; os.environ["KIS_MOCK"] = mock
    os.environ["KIS_EQUITY_USD"] = "100000"; os.environ["KIS_DB"] = db_path

def _run(argv):
    from kistrader.tools import seed_position
    try:
        return seed_position.main(argv), None
    except SystemExit as e:
        return None, (e.code if isinstance(e.code, str) else f"exit:{e.code}")

def _close(argv, broker=None):
    from kistrader.tools import close_position
    try:
        return close_position.main(argv, broker_factory=(lambda: broker) if broker else None), None
    except SystemExit as e:
        return None, (e.code if isinstance(e.code, str) else f"exit:{e.code}")


class _FakeBroker:
    """Minimal stand-in: only get_all_holdings is consulted by the close tool."""
    def __init__(self, holdings):
        self._h = holdings          # dict, or None to simulate an unreadable read
    def get_all_holdings(self):
        return self._h


def close_tests():
    print("CLOSE POSITION TESTS")
    import tempfile
    from kistrader.core.engine_v2 import EventStore, PositionState
    d = tempfile.mkdtemp()
    seed = ["--ticker", "F", "--shares", "2", "--entry", "12.30", "--stop", "13.00",
            "--confirm", "--session-date", "2026-07-22"]

    # a live seeded record to close
    p = os.path.join(d, "close.db"); _env(p)
    _run(seed)
    live = [s for s in EventStore(p).load_open_snapshots() if s.ticker == "F"]
    check("setup: one live F record", len(live) == 1)

    base = ["--order-key", "F:2026-07-22"]

    # 1) no --confirm
    _, err = _close(base, _FakeBroker({}))
    check("no --confirm -> refuses", err and "confirm" in err, f"err={err}")

    # 2) unknown key
    _, err = _close(["--order-key", "NOPE:2026-01-01", "--confirm"], _FakeBroker({}))
    check("unknown order_key -> refuses", err and "no live" in err, f"err={err}")

    # 3) THE safety gate: broker still holds the shares
    _, err = _close(base + ["--confirm"], _FakeBroker({"F": 2}))
    check("broker still holds -> refuses (never strand a real position)",
          err and "still holds" in err, f"err={err}")

    # 4) holdings unreadable is NOT flat
    _, err = _close(base + ["--confirm"], _FakeBroker(None))
    check("holdings unreadable -> refuses (unknown is not flat)",
          err and "UNREADABLE" in err, f"err={err}")

    # 5) broker confirms flat -> closes; recovery stops seeing it
    rc, err = _close(base + ["--confirm"], _FakeBroker({"MU": 5}))
    check("broker flat -> closes", rc == 0, f"rc={rc} err={err}")
    still = [s for s in EventStore(p).load_open_snapshots() if s.ticker == "F"]
    check("record no longer rehydrated by recovery", still == [], f"n={len(still)}")
    row = EventStore(p).conn.execute(
        "SELECT event_type, state_to, shares FROM position_events "
        "WHERE order_key='F:2026-07-22' ORDER BY id DESC LIMIT 1").fetchone()
    check("terminal event written with an audit tag",
          row and row[0].startswith("MANUAL_CLOSED") and row[1] == "CLOSED"
          and row[2] == 0, f"row={row}")

    # 6) closing again -> nothing live to close
    _, err = _close(base + ["--confirm"], _FakeBroker({}))
    check("double close -> refuses (already terminal)", err and "no live" in err, f"err={err}")

    # 7) --force bypasses the broker check entirely (offline box)
    p7 = os.path.join(d, "force.db"); _env(p7)
    _run(seed)
    rc, err = _close(base + ["--confirm", "--force"], None)
    check("--force closes without any broker call", rc == 0, f"rc={rc} err={err}")
    row = EventStore(p7).conn.execute(
        "SELECT event_type FROM position_events WHERE order_key='F:2026-07-22' "
        "ORDER BY id DESC LIMIT 1").fetchone()
    check("forced close is tagged distinctly in the trail",
          row and row[0].startswith("MANUAL_CLOSED_FORCED"), f"row={row}")


def main():
    print("=" * 62); print("SEED / CLOSE POSITION TESTS"); print("=" * 62)
    d = tempfile.mkdtemp()
    base = ["--ticker", "F", "--shares", "2", "--entry", "12.30", "--stop", "13.00"]

    # 1) refuses without --confirm
    _env(os.path.join(d, "a.db"))
    _, err = _run(base)
    check("no --confirm -> refuses", err and "confirm" in err, f"err={err}")

    # 2) refuses live without --allow-live
    _env(os.path.join(d, "b.db"), mock="0")
    _, err = _run(base + ["--confirm"])
    check("KIS_MOCK=0 without --allow-live -> refuses", err and "live" in err.lower(), f"err={err}")

    # 3) happy path writes a FILLED snapshot recovery can load
    p3 = os.path.join(d, "c.db"); _env(p3)
    rc, err = _run(base + ["--confirm", "--session-date", "2026-07-22"])
    check("mock seed returns 0", rc == 0, f"rc={rc} err={err}")
    snaps = EventStore(p3).load_open_snapshots()
    f = [s for s in snaps if s.ticker == "F"]
    check("exactly one live F snapshot", len(f) == 1, f"n={len(f)}")
    if f:
        s = f[0]
        check("state is FILLED", s.state == PositionState.FILLED)
        check("shares seeded", s.shares == 2)
        check("entry_price seeded", abs(s.entry_price - 12.30) < 1e-9)
        check("stop seeded", abs(s.stop_loss_price - 13.00) < 1e-9)
        check("frozen R is negative (stop>entry, exit-test geometry)",
              s.initial_risk_per_share < 0, f"R={s.initial_risk_per_share}")
        check("order_key uses the given date", s.order_key == "F:2026-07-22", s.order_key)

    # 4) refuses to shadow an existing live snapshot (same key)
    rc2, err2 = _run(base + ["--confirm", "--session-date", "2026-07-22"])
    check("second seed of same key -> refuses (no shadow)",
          rc2 is None and err2 and "already exists" in err2, f"rc={rc2} err={err2}")

    # 5) positive-risk (normal hold) geometry also allowed
    p5 = os.path.join(d, "e.db"); _env(p5)
    rc3, _ = _run(["--ticker", "MU", "--shares", "1", "--entry", "100.0",
                   "--stop", "92.0", "--confirm"])
    s5 = [s for s in EventStore(p5).load_open_snapshots() if s.ticker == "MU"]
    check("normal stop<entry seeds with positive R", rc3 == 0 and s5
          and s5[0].initial_risk_per_share > 0)

    close_tests()

    print("=" * 62); print(f"PASSED {len(PASS)} / {len(PASS)+len(FAIL)}")
    if FAIL: print("FAILED:", ", ".join(FAIL))
    print("=" * 62)
    return 1 if FAIL else 0

def test_seed_and_close_suite():
    """D8: this file defines no module-level test_ functions, so pytest used to
    collect NOTHING from it and all 23 checks silently never ran. main() drives
    the whole suite and returns 1 on any failure."""
    assert main() == 0, f"{len(FAIL)} failed check(s): " + "; ".join(FAIL)


if __name__ == "__main__":
    sys.exit(main())
