"""The cost robustness check: does the winning parameter survive the cost sweep?"""
import numpy as np, pandas as pd
from minervini_backtest import BTCandidate, BacktestConfig, robustness_check

D = pd.bdate_range("2023-01-02", periods=260)


def ohlc(dates, closes, seed=0):
    r = np.random.default_rng(seed)
    c = np.asarray(closes, float); o = np.r_[c[0], c[:-1]]
    return pd.DataFrame({"Open": o,
                         "High": np.maximum(o, c) * (1 + abs(r.normal(0, .005, len(c)))),
                         "Low": np.minimum(o, c) * (1 - abs(r.normal(0, .005, len(c)))),
                         "Close": c}, index=dates[:len(c)])


TICKERS = list("ABCDEFGH")
PRICES = {}
for i, t in enumerate(TICKERS):
    r = np.random.default_rng(300 + i)
    c = 100 * np.cumprod(1 + r.normal(0.0010 - i * 0.00022, 0.017, len(D)))
    PRICES[t] = ohlc(D, np.r_[99, c[1:]], seed=i)

# rescan every three weeks, pivot tracking the recent high as the nightly
# screener does; VCP score descends with rank so a threshold actually bites
SIGNALS = {}
for i in range(0, len(D) - 25, 21):
    row = []
    for j, t in enumerate(TICKERS):
        win = PRICES[t]["Close"].iloc[max(0, i - 20):i + 1]
        px = float(win.max()) if len(win) else 100.0
        row.append(BTCandidate(ticker=t, exchange="NAS", pivot=px,
                               contraction_low=px * 0.95, atr=px * 0.02,
                               last_close=px * 0.99, rs_rating=95 - j * 2,
                               vcp_score=90.0 - j * 4.0,
                               session_date=str(D[i].date())))
    SIGNALS[D[i]] = row

# distinct sectors: with all-Tech and sector_cap=2 the CAP decides everything
# and the threshold never binds -- see the "did not differentiate" verdict below
SECTORS = ["Tech", "Health", "Energy", "Financials",
           "Utilities", "Materials", "Staples", "Industrials"]
CFG = BacktestConfig(rank_mode="rs_only",
                     sector_map=dict(zip(TICKERS, SECTORS)),
                     vcp_threshold=80.0)
CFG_CAPPED = BacktestConfig(rank_mode="rs_only",
                            sector_map={t: "Tech" for t in TICKERS},
                            vcp_threshold=80.0)

SETTINGS = {"thr_60": {"vcp_threshold": 60.0},
            "thr_70": {"vcp_threshold": 70.0},
            "thr_80": {"vcp_threshold": 80.0}}


def show(r):
    print(f"  metric: {r['metric']}   verdict: {r['verdict']}")
    for slip in r["slippage_grid"]:
        scores = r["scores_by_slippage"][slip]
        order = " > ".join(r["ranking_by_slippage"][slip])
        detail = "  ".join(f"{k}={v:+.3f}" for k, v in scores.items())
        print(f"    {slip:5.1f} bps/side   {order:28}  {detail}")
    print(f"  winner stable: {r['winner_stable']}   order stable: "
          f"{r['full_order_stable']}   differentiated: {r['settings_differentiated']}")
    print(f"  drops: {r['drops_by_reason_sample']}")
    print(f"  held_ticker_time_frac: {r['held_ticker_time_frac_sample']}")


print("=== threshold sweep, expectancy_R ===")
r1 = robustness_check(PRICES, SIGNALS, CFG, settings=SETTINGS,
                      metric="expectancy_R")
show(r1)

print("\n=== same settings, judged on total_return_pct ===")
r2 = robustness_check(PRICES, SIGNALS, CFG, settings=SETTINGS,
                      metric="total_return_pct")
show(r2)

print("\n=== judged on max_drawdown_pct (less negative is better) ===")
r3 = robustness_check(PRICES, SIGNALS, CFG, settings=SETTINGS,
                      metric="max_drawdown_pct", higher_is_better=True)
show(r3)

print("\nThe verdict is the deliverable. A NOT ROBUST result means the "
      "parameter\nchoice is unsupported -- report the instability, do not pick "
      "the slippage\nlevel that produces the preferred answer.")
