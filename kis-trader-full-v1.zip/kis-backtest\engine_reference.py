#!/usr/bin/env python3
r"""
engine_reference.py -- the anchor that has to exist BEFORE the VCP engine is
changed.

TARGET REPO: kis-backtest (for the bars and its own vcp_engine.py).
Reads the screeners out of kis-trader-clean. READ-ONLY except for the one
reference JSON it writes in --freeze mode. No network: the analyzer takes
DataFrames directly, so nothing is fetched.

WHY THIS EXISTS

`03_gate.py` pins ten production VCP scores from a 2026-08-05 run. It is the
project's only reproduction anchor, and it answers exactly one question: "does
the extraction still reproduce production?"

Any change to `_zigzag_pivots` -- the adaptive-threshold work -- makes that gate
FAIL BY DESIGN, because the scores it pins would legitimately move. Losing the
anchor at the moment you most need one is how a change becomes unauditable.

The fix is not to protect the old scores. It is to record enough BEFORE the
change that afterwards you can say WHICH STAGE moved and BY HOW MUCH, instead of
only that the total moved.

WHAT IT CAPTURES, PER TICKER, PER ENGINE COPY

  * the ten component stage scores (t, b, c, h, v, vo, ti, re, ac, rd) --
    captured by wrapping the stage methods, because `generate_report` returns
    the merged Metrics but NOT the per-stage scores
  * Score, Grade, Trade_Signal_Active
  * Wave_Count, Wave_Depths_Pct, Pivot, Base_High, Base_Start_Bar,
    Invalid_Waves_Dropped
  * the engine block sha and the full VCPConfig field set that produced it

THE THREE (OR MORE) ENGINE COPIES

This project keeps the VCP engine in at least three places:

    kis-trader-clean/screeners/sp500_v21.py      inlined, 49,804 bytes
    kis-trader-clean/screeners/us_small_v21.py   inlined, byte-identical
    kis-backtest/vcp_engine.py                   differs by ONE BLANK LINE

`test_screener_harness` S13 (patch I2) compares the first two byte-wise. Nothing
compares them to the third, and nothing compares either to the copies in the
RUNNING `kis-trader` tree (verified 2026-08-29: engine block identical there,
sha ae96d98efd43).

So --freeze runs every copy over the SAME bars and refuses to write unless they
agree on every field of every ticker. That is a BEHAVIOURAL parity check, which
is strictly stronger than the byte comparison: two files can differ in whitespace
and be identical engines, and -- far worse -- two files can be byte-identical
and still be handed different configs.

The screener engines are loaded by exec'ing ONLY the block
`def safe_divide(` .. `VCPAnalyzerV3 = VCPAnalyzerV4` in a fresh namespace, never
by importing the screener module. The block is self-contained (ScoreCalculator,
VCPConfig, Wave, VCPAnalyzerV4 all inside it), so nothing else in those 160 KB
scripts runs -- no network, no side effects.

USE

    # before touching the engine
    python engine_reference.py --freeze --clean C:\...\kis-trader-clean

    # after any engine change, and in CI
    python engine_reference.py --verify --clean C:\...\kis-trader-clean

--verify exits non-zero on ANY difference and prints a stage-level breakdown:
which ticker, which stage, old -> new. A change that moves only stage 3/4 is a
contraction-scoring change; one that moves stage 1 as well has touched base
detection, which is a much larger claim.

WHAT IT IS NOT

Not a judgement. A stage moving is not a regression -- for a deliberate engine
change it is the POINT. This tells you what moved so the change can be
described; it cannot tell you the new scores are better. Only the frozen-set
reproduction and a sweep can speak to that, and both come after.
"""
from __future__ import annotations

import argparse
import dataclasses
import hashlib
import json
import math
import os
import pathlib
import sys
from dataclasses import dataclass, field, replace
from typing import Dict, List, Optional, Tuple

BLOCK_START = "def safe_divide("
BLOCK_END = "VCPAnalyzerV3 = VCPAnalyzerV4"
GATE_TICKERS = ["NTAP", "UNH", "NUE", "STT", "HPE",
                "BRKR", "PTGX", "IRDM", "OKTA", "LFST"]
DEFAULT_OUT = "engine_reference.json"


def load_block_engine(path: str, label: str):
    """exec ONLY the inlined engine block from a screener, in a fresh namespace."""
    src = open(path, encoding="utf-8").read()
    if src.count(BLOCK_START) != 1 or src.count(BLOCK_END) != 1:
        raise SystemExit(f"[ref] {label}: engine boundaries are not unique in "
                         f"{path}. Refusing to guess which slice is the engine.")
    i = src.index(BLOCK_START)
    j = src.index(BLOCK_END) + len(BLOCK_END)
    if j <= i:
        raise SystemExit(f"[ref] {label}: engine boundaries are out of order.")
    blk = src[i:j]
    import types
    import numpy as _np
    import pandas as _pd
    # A REAL module object registered in sys.modules: @dataclass resolves string
    # annotations through sys.modules[cls.__module__], so a bare dict namespace
    # makes dataclasses raise on `sys.modules.get(...).__dict__`.
    modname = "engine_ref_" + label.replace(":", "_").replace("-", "_")
    mod = types.ModuleType(modname)
    mod.__dict__.update({"np": _np, "pd": _pd, "math": math,
                         "dataclass": dataclass, "field": field,
                         "replace": replace, "dataclasses": dataclasses,
                         "Optional": Optional, "List": List, "Dict": Dict,
                         "Tuple": Tuple})
    sys.modules[modname] = mod
    exec(compile(blk, f"{label}::engine", "exec"), mod.__dict__)
    for need in ("VCPAnalyzerV4", "VCPConfig"):
        if need not in mod.__dict__:
            raise SystemExit(f"[ref] {label}: engine block defines no {need}.")
    return (mod.__dict__["VCPAnalyzerV4"], mod.__dict__["VCPConfig"],
            hashlib.sha256(blk.encode()).hexdigest()[:16], len(blk))


def stage_methods(cls) -> List[str]:
    """Discover the stage_* methods. Fail closed on an unexpected count: a
    renamed stage would otherwise be silently dropped from the reference."""
    names = sorted(n for n in dir(cls)
                   if n.startswith("stage_") and callable(getattr(cls, n)))
    if len(names) != 10:
        raise SystemExit(f"[ref] expected 10 stage_* methods, found "
                         f"{len(names)}: {names}. The engine has changed shape; "
                         f"update this script deliberately rather than freezing "
                         f"a partial reference.")
    return names


def wrap_stages(cls):
    """Record each stage's SCORE. generate_report merges the stages' Metrics but
    not their scores, and the scores are what a stage-level diff needs."""
    originals = {}
    for name in stage_methods(cls):
        orig = getattr(cls, name)

        def make(nm, fn):
            def wrapped(self, *a, **k):
                out = fn(self, *a, **k)
                try:
                    score = out[0] if isinstance(out, tuple) else out
                    getattr(self, "_ref_stages").__setitem__(nm, float(score))
                except Exception:
                    pass
                return out
            return wrapped

        originals[name] = orig
        setattr(cls, name, make(name, orig))

    orig_rep = cls.generate_report

    def rep(self, *a, **k):
        self._ref_stages = {}
        return orig_rep(self, *a, **k)

    originals["generate_report"] = orig_rep
    cls.generate_report = rep
    return originals


def unwrap(cls, originals):
    for name, fn in originals.items():
        setattr(cls, name, fn)


def rnd(v, nd=6):
    if isinstance(v, float):
        if not math.isfinite(v):
            return str(v)
        return round(v, nd)
    if isinstance(v, dict):
        return {k: rnd(x, nd) for k, x in sorted(v.items())}
    if isinstance(v, (list, tuple)):
        return [rnd(x, nd) for x in v]
    return v


def record(analyzer_cls, cfg_cls, df, index_df):
    a = analyzer_cls(df, index_df=index_df, config=cfg_cls())
    rep = a.generate_report()
    if not rep:
        return {"report": None}
    pat = rep.get("Extracted_Pattern") or {}
    return {
        "Score": rnd(rep.get("Score")),
        "Grade": rep.get("Grade"),
        "Trade_Signal_Active": bool(rep.get("Trade_Signal_Active")),
        "Base_Confidence": rep.get("Base_Confidence"),
        "stages": rnd(getattr(a, "_ref_stages", {})),
        "Wave_Count": pat.get("Wave_Count"),
        "Wave_Depths_Pct": rnd(pat.get("Wave_Depths_Pct")),
        "Pivot": rnd(pat.get("Pivot")),
        "Base_High": rnd(pat.get("Base_High")),
        "Base_Start_Bar": pat.get("Base_Start_Bar"),
        "Invalid_Waves_Dropped": pat.get("Invalid_Waves_Dropped"),
    }


def main() -> int:
    ap = argparse.ArgumentParser()
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--freeze", action="store_true")
    g.add_argument("--verify", action="store_true")
    ap.add_argument("--repo", default=".", help="kis-backtest root (bars + vcp_engine)")
    ap.add_argument("--clean", required=True,
                    help="kis-trader-clean root; its screeners supply two engines")
    ap.add_argument("--also", default=None,
                    help="an ADDITIONAL tree whose screeners must also agree, "
                         "e.g. the running kis-trader")
    ap.add_argument("--bars", default="data/bars")
    ap.add_argument("--asof", default="2026-08-03",
                    help="03_gate.py's GATE_DATE, so this ties to a known anchor")
    ap.add_argument("--extra", type=int, default=40,
                    help="deterministic extra tickers beyond the 10 gate names, "
                         "to widen wave-count coverage")
    ap.add_argument("--out", default=DEFAULT_OUT)
    a = ap.parse_args()

    root = os.path.abspath(a.repo)
    sys.path.insert(0, root)
    os.chdir(root)
    import pandas as pd
    import vcp_engine as harness

    engines = {}
    hb = open(os.path.join(root, "vcp_engine.py"), encoding="utf-8").read()
    i, j = hb.index(BLOCK_START), hb.index(BLOCK_END) + len(BLOCK_END)
    engines["harness"] = (harness.VCPAnalyzerV4, harness.VCPConfig,
                          hashlib.sha256(hb[i:j].encode()).hexdigest()[:16],
                          j - i, os.path.join(root, "vcp_engine.py"))
    trees = [("clean", a.clean)] + ([("also", a.also)] if a.also else [])
    for tag, troot in trees:
        for scr in ("sp500_v21.py", "us_small_v21.py"):
            p = os.path.join(troot, "screeners", scr)
            if not os.path.isfile(p):
                raise SystemExit(f"[ref] {p} not found.")
            lbl = f"{tag}:{scr[:-3]}"
            cls, cfgc, sha, n = load_block_engine(p, lbl)
            engines[lbl] = (cls, cfgc, sha, n, p)

    print("=" * 78)
    print(f"  ENGINE REFERENCE -- {'FREEZE' if a.freeze else 'VERIFY'}   "
          f"as-of {a.asof}")
    print("=" * 78)
    for lbl, (_c, cfgc, sha, n, p) in engines.items():
        cfg = cfgc()
        print(f"  {lbl:22} block {n:,} B  sha {sha}  "
              f"atr_mult={cfg.atr_multiplier} min_pct={cfg.min_pct} "
              f"max_score={cfg.max_score}")

    bars_dir = pathlib.Path(a.bars)
    avail = sorted(p.stem for p in bars_dir.glob("*.parquet"))
    if "^GSPC" not in avail:
        raise SystemExit("[ref] ^GSPC missing from the bars directory.")
    pool = [t for t in avail if t != "^GSPC"]
    picks = [t for t in GATE_TICKERS if t in pool]
    missing = [t for t in GATE_TICKERS if t not in pool]
    if a.extra > 0 and len(pool) > a.extra:
        step = max(1, len(pool) // a.extra)
        picks += [t for t in pool[::step] if t not in picks][:a.extra]
    picks = sorted(set(picks))
    if missing:
        print(f"  NOTE gate tickers absent from bars: {missing}")
    print(f"  {len(picks)} ticker(s); slicing every series to <= {a.asof}")

    asof = pd.Timestamp(a.asof)
    idx = pd.read_parquet(bars_dir / "^GSPC.parquet")
    if getattr(idx.index, "tz", None) is not None:
        idx.index = idx.index.tz_localize(None)
    idx = idx.loc[idx.index <= asof]

    wrapped = {}
    for lbl, (cls, _cfgc, _s, _n, _p) in engines.items():
        wrapped[lbl] = (cls, wrap_stages(cls))

    out = {}
    try:
        for t in picks:
            df = pd.read_parquet(bars_dir / f"{t}.parquet")
            if getattr(df.index, "tz", None) is not None:
                df.index = df.index.tz_localize(None)
            df = df.loc[df.index <= asof]
            if df.empty:
                continue
            per = {}
            for lbl, (cls, _cfgc, _s, _n, _p) in engines.items():
                cfgc = engines[lbl][1]
                try:
                    per[lbl] = record(cls, cfgc, df, idx)
                except Exception as e:
                    per[lbl] = {"error": f"{type(e).__name__}: {e}"}
            out[t] = {"rows": int(len(df)),
                      "last_bar": str(df.index[-1].date()),
                      "engines": per}
    finally:
        for lbl, (cls, originals) in wrapped.items():
            unwrap(cls, originals)

    # ---- three-way (or five-way) behavioural parity -----------------------
    labels = list(engines)
    base_lbl = labels[0]
    disagree = []
    for t, rec in out.items():
        ref = rec["engines"][base_lbl]
        for lbl in labels[1:]:
            other = rec["engines"][lbl]
            if json.dumps(rnd(ref), sort_keys=True) != json.dumps(rnd(other),
                                                                 sort_keys=True):
                keys = sorted(set(ref) | set(other))
                bad = [k for k in keys if rnd(ref.get(k)) != rnd(other.get(k))]
                disagree.append((t, lbl, bad))
    print(f"\n  behavioural parity across {len(labels)} engine copies on "
          f"{len(out)} ticker(s): "
          + ("AGREE" if not disagree else f"{len(disagree)} DISAGREEMENT(S)"))
    for t, lbl, bad in disagree[:12]:
        print(f"    {t:8} {base_lbl} vs {lbl}: {bad}")

    if a.freeze:
        if disagree:
            print("\n  REFUSING TO FREEZE. An anchor built on engines that "
                  "disagree is worthless -- reconcile them first.")
            return 2
        blob = {
            "asof": a.asof,
            "engines": {lbl: {"sha": s, "bytes": n, "path": p,
                              "config": rnd({f.name: getattr(cfgc(), f.name)
                                             for f in dataclasses.fields(cfgc())
                                             if not isinstance(
                                                 getattr(cfgc(), f.name),
                                                 (dict, list))})}
                        for lbl, (_c, cfgc, s, n, p) in engines.items()},
            "tickers": out,
        }
        with open(a.out, "w", encoding="utf-8") as fh:
            json.dump(blob, fh, indent=1, sort_keys=True)
        print(f"\n  FROZEN -> {a.out}  ({len(out)} tickers x {len(labels)} engines)")
        print("  Run --verify after ANY engine change. A stage that moves is")
        print("  not a regression for a deliberate change -- it is the point.")
        print("  This tells you WHICH stage, so the change can be described.")
        return 0

    # ---- verify -----------------------------------------------------------
    if not os.path.isfile(a.out):
        raise SystemExit(f"[ref] {a.out} not found. Run --freeze first, on the "
                         f"engine you are changing FROM.")
    old = json.load(open(a.out, encoding="utf-8"))
    if old.get("asof") != a.asof:
        raise SystemExit(f"[ref] frozen as-of {old.get('asof')} != {a.asof}. "
                         f"Compare like with like.")
    print(f"\n  frozen shas: "
          + ", ".join(f"{k}={v['sha']}" for k, v in old["engines"].items()))
    moved_sha = [k for k, v in old["engines"].items()
                 if k in engines and engines[k][2] != v["sha"]]
    print(f"  engine sha changed since freeze: "
          + (", ".join(moved_sha) if moved_sha else "none"))

    stage_delta, n_diff, n_same = {}, 0, 0
    for t, rec in sorted(out.items()):
        o = old["tickers"].get(t)
        if o is None:
            print(f"    {t:8} NEW ticker, not in the reference")
            continue
        for lbl in labels:
            a_new = rec["engines"].get(lbl, {})
            a_old = (o.get("engines") or {}).get(lbl, {})
            if not a_old:
                continue
            if json.dumps(rnd(a_new), sort_keys=True) == json.dumps(
                    rnd(a_old), sort_keys=True):
                n_same += 1
                continue
            n_diff += 1
            print(f"    {t:8} [{lbl}]  Score {a_old.get('Score')} -> "
                  f"{a_new.get('Score')}   waves "
                  f"{a_old.get('Wave_Count')} -> {a_new.get('Wave_Count')}")
            so, sn = a_old.get("stages") or {}, a_new.get("stages") or {}
            for k in sorted(set(so) | set(sn)):
                if rnd(so.get(k)) != rnd(sn.get(k)):
                    d = (sn.get(k) or 0) - (so.get(k) or 0)
                    stage_delta[k] = stage_delta.get(k, 0.0) + abs(d)
                    print(f"             {k:28} {so.get(k)} -> {sn.get(k)} "
                          f"({d:+.3f})")
    print(f"\n  {n_same} unchanged, {n_diff} changed (ticker x engine)")
    if stage_delta:
        print("  total absolute movement by stage:")
        for k, v in sorted(stage_delta.items(), key=lambda kv: -kv[1]):
            print(f"    {k:28} {v:8.3f}")
        print("\n  A change confined to stage_3_and_4_contractions is a")
        print("  contraction-SCORING change. Movement in stage_1/stage_2 as well")
        print("  means BASE DETECTION moved, which is a much larger claim and")
        print("  invalidates more downstream than the wave count alone.")
    return 1 if (n_diff or disagree) else 0


if __name__ == "__main__":
    raise SystemExit(main())
