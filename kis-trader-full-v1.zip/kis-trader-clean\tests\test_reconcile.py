#!/usr/bin/env python3
"""
`_converge` — the broker/local reconciliation, which had no test at all.
========================================================================

WHY THIS EXISTS

`grep -rn "reconcile\\|_converge" tests/` returned two lines, both in
`test_pipeline_e2e`, both only setting up holdings. The function that decides
what the engine believes it holds — called on every `recover()` and every
periodic watchdog pass — shipped with no direct coverage, and a persistence
defect lived in it for as long as it has existed.

THE DEFECT THIS PINS

    self.alert(f"... qty local={pos.shares} broker={held} — adopting broker")
    self.db.log(pos, f"RECONCILE_DELTA:{pos.shares}->{held}:{source}", ...)
    pos.shares = held                       # <- AFTER the log

`EventStore.log` serialises `pos.to_dict()`, so the snapshot written by that
call carries the OLD share count. The mutation on the next line touches only the
in-memory object, and nothing persists it afterwards — both call sites
(`_recover` and `reconcile`) return immediately.

Measured on the live box, 2026-09-05:

    218  2026-09-04 13:31:12  FILLED                             shares=15
    221  2026-09-04 16:45:52  RECONCILE_DELTA:15->26:periodic    shares=15
    225  2026-09-05 02:08:09  RECONCILE_DELTA:15->26:recover     shares=15
    226  2026-09-05 11:40:57  RECONCILE_DELTA:15->26:recover     shares=15

Twenty-two hours, three reconciles, never converged — because every restart
reloads 15 from the store and re-adopts. The sibling branch twelve lines up gets
the order right (`pos.shares = 0; pos.state = CLOSED; self.db.log(...)`), which
is what makes this an oversight rather than a design.

WHY IT MATTERS, STATED AT ITS ACTUAL SIZE

In-process the engine is correct: `pos.shares` becomes 26 and an exit sells 26.
The damage is to the crash-recovery record, and it has two edges:

1. `recover()` reloads 15 and only reaches 26 if the very next holdings read
   succeeds. When `get_all_holdings()` returns None the reconcile is skipped by
   design — correctly, it is the fail-closed branch — and the engine then manages
   15 while the account holds 26. An exit sells 15 and leaves 11 shares with no
   stop. That is the ORPHAN direction, the one `status.py --live` exists to name.
2. It never converges, so the same WARN repeats forever. The notifier collapses
   digits when deduplicating, so a permanently-unconverged position goes quiet
   after the first push. A divergence that alerts once and then hides is worse
   than one that never alerted.

Case A fails on the pre-patch code. That is the point of it.

Run:  python tests/test_reconcile.py
      python -m pytest -q tests/test_reconcile.py
"""
from __future__ import annotations

import os
import sys
import tempfile

_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.dirname(_HERE)
for _p in (_ROOT, _HERE):
    if _p not in sys.path:
        sys.path.insert(0, _p)

from kistrader.core.engine_v2 import (          # noqa: E402
    EventStore, ExecutionMonitor, Position, PositionState)

FAIL: list = []
_N = [0]


def check(name, cond, detail=""):
    _N[0] += 1
    print(f"  [{'PASS' if cond else 'FAIL'}] {name}   {detail}")
    if not cond:
        FAIL.append(name)


class Broker:
    """Only what `_converge` touches. `holdings=None` is the unreadable case."""
    def __init__(self, holdings=None, fills=None):
        self.holdings = {} if holdings is None else holdings
        self.readable = True
        self.fills = fills or {}

    def get_all_holdings(self):
        return None if not self.readable else dict(self.holdings)

    def get_fills(self, order_id):
        return self.fills.get(order_id)


def _pos(ticker="INSW", shares=15, state=PositionState.FILLED, **kw):
    return Position(ticker=ticker, state=state, shares=shares,
                    entry_price=102.87, stop_loss_price=92.67,
                    initial_risk_per_share=10.20,
                    order_key=f"{ticker}:2026-09-04", **kw)


class Rig:
    """A real EventStore on a temp file, so persistence is actually exercised.
    An in-memory dict would pass the buggy code."""
    def __init__(self, holdings=None, fills=None):
        fd, self.path = tempfile.mkstemp(suffix=".db")
        os.close(fd)
        self.db = EventStore(self.path)
        # EVERY connection opened on this file, so close() can close them all.
        # Windows refuses to unlink a file that still has an open handle, and
        # reload() deliberately opens more of them.
        self._conns = [self.db.conn]
        self.broker = Broker(holdings, fills)
        self.alerts = []
        self.mon = ExecutionMonitor(self.broker, self.db,
                                    alert=self.alerts.append)

    def seed(self, pos, event="FILLED"):
        self.db.log(pos, event, pos.entry_price)
        return pos

    def reload(self):
        """A fresh EventStore over the same file — what a restart actually does."""
        es = EventStore(self.path)
        self._conns.append(es.conn)
        return es.load_open_snapshots()

    def events(self, ticker="INSW"):
        return [r[0] for r in self.db.conn.execute(
            "SELECT event_type FROM position_events WHERE ticker=? ORDER BY id",
            (ticker,))]

    def close(self):
        for c in self._conns:
            try:
                c.close()
            except Exception:
                pass
        # Best-effort. A temp file left behind is untidy; a test that fails
        # because the OS would not unlink it is worse, and says nothing about
        # the code under test.
        for suffix in ("", "-wal", "-shm"):
            p = self.path + suffix
            try:
                if os.path.exists(p):
                    os.remove(p)
            except OSError:
                pass


def case_a_delta_is_persisted():
    print("A  a broker delta must survive a restart  (FAILS pre-patch)")
    r = Rig(holdings={"INSW": 26})
    p = r.seed(_pos(shares=15))
    try:
        r.mon.reconcile([p], source="periodic")
        check("in-memory position adopts the broker qty", p.shares == 26,
              f"shares={p.shares}")
        check("the alert names both sides",
              any("local=15 broker=26" in a and "adopting broker" in a
                  for a in r.alerts), "; ".join(r.alerts)[:90])
        check("the audit string is unchanged",
              "RECONCILE_DELTA:15->26:periodic" in r.events(),
              str(r.events()))
        snaps = r.reload()
        got = snaps[0].shares if snaps else None
        check("the PERSISTED snapshot carries 26, not 15", got == 26,
              f"reloaded shares={got}")
    finally:
        r.close()


def case_b_converges():
    print("B  ...and it converges: a second reconcile has nothing to say")
    r = Rig(holdings={"INSW": 26})
    r.seed(_pos(shares=15))
    try:
        r.mon.reconcile(r.reload(), source="recover")
        n1 = sum(1 for e in r.events() if e.startswith("RECONCILE_DELTA"))
        r.mon.reconcile(r.reload(), source="recover")
        n2 = sum(1 for e in r.events() if e.startswith("RECONCILE_DELTA"))
        check("first pass logs exactly one delta", n1 == 1, f"n={n1}")
        check("second pass logs none — converged", n2 == 1,
              f"n={n2} (the live box logged 3 and counting)")
    finally:
        r.close()


def case_c_agreement_is_silent():
    print("C  agreement writes nothing and says nothing")
    r = Rig(holdings={"INSW": 15})
    p = r.seed(_pos(shares=15))
    try:
        r.mon.reconcile([p], source="periodic")
        check("no event appended", r.events() == ["FILLED"], str(r.events()))
        check("no alert", r.alerts == [], str(r.alerts))
    finally:
        r.close()


def case_d_zero_unconfirmed_never_closes():
    print("D  broker=0 with no fill evidence is AMBIGUOUS, never a close")
    r = Rig(holdings={})
    p = r.seed(_pos(shares=15))
    try:
        r.mon.reconcile([p], source="periodic")
        check("state unchanged", p.state == PositionState.FILLED, p.state.value)
        check("shares unchanged", p.shares == 15, f"shares={p.shares}")
        check("logged as unconfirmed, not closed",
              any(e.startswith("RECONCILE_ZERO_UNCONFIRMED") for e in r.events()),
              str(r.events()))
        check("the alert says NOT closing",
              any("NOT closing" in a for a in r.alerts), "; ".join(r.alerts)[:90])
    finally:
        r.close()


def case_e_zero_confirmed_closes():
    print("E  broker=0 CONFIRMED by fills does close, and persists closed")
    r = Rig(holdings={}, fills={"OID1": 15})
    p = _pos(shares=15)
    p.live_order_id = "OID1"
    p.live_order_qty = 15
    r.seed(p)
    try:
        r.mon.reconcile([p], source="periodic")
        check("state CLOSED", p.state == PositionState.CLOSED, p.state.value)
        check("persisted as terminal — nothing left open", r.reload() == [],
              str([(x.ticker, x.shares) for x in r.reload()]))
    finally:
        r.close()


def case_f_unreadable_changes_nothing():
    print("F  an unreadable holdings read changes nothing at all")
    r = Rig(holdings={"INSW": 26})
    p = r.seed(_pos(shares=15))
    r.broker.readable = False
    try:
        r.mon.reconcile([p], source="periodic")
        check("shares untouched", p.shares == 15, f"shares={p.shares}")
        check("no event appended", r.events() == ["FILLED"], str(r.events()))
        check("the alert says skipped",
              any("reconcile skipped" in a for a in r.alerts),
              "; ".join(r.alerts)[:90])
    finally:
        r.close()


def case_g_exiting_is_owned_by_the_exit_loop():
    print("G  an EXITING position is not converged here")
    r = Rig(holdings={"INSW": 26})
    p = r.seed(_pos(shares=15, state=PositionState.EXITING))
    try:
        r.mon.reconcile([p], source="periodic")
        check("shares untouched", p.shares == 15, f"shares={p.shares}")
        check("no delta logged",
              not any(e.startswith("RECONCILE_DELTA") for e in r.events()),
              str(r.events()))
    finally:
        r.close()


def case_h_orphan_without_resolver_only_alerts():
    print("H  a holding with no local record alerts and is never invented")
    r = Rig(holdings={"INSW": 15, "NVDA": 100})
    p = r.seed(_pos(shares=15))
    try:
        r.mon.reconcile([p], source="periodic")
        check("the orphan is named",
              any("no local record" in a and "NVDA" in a for a in r.alerts),
              "; ".join(r.alerts)[:110])
        check("nothing was written for it", r.events("NVDA") == [],
              str(r.events("NVDA")))
    finally:
        r.close()


def main() -> int:
    print("=" * 64)
    print("_converge — BROKER/LOCAL RECONCILIATION")
    print("=" * 64)
    for fn in (case_a_delta_is_persisted, case_b_converges,
               case_c_agreement_is_silent, case_d_zero_unconfirmed_never_closes,
               case_e_zero_confirmed_closes, case_f_unreadable_changes_nothing,
               case_g_exiting_is_owned_by_the_exit_loop,
               case_h_orphan_without_resolver_only_alerts):
        fn()
    print("=" * 64)
    print(f"PASSED {_N[0] - len(FAIL)} / {_N[0]}")
    print("=" * 64)
    return 1 if FAIL else 0


def test_zz_all_checks_passed():
    """Terminal guard. check() never raises, so without this pytest would report
    this file as passed no matter how many checks failed."""
    main()
    assert not FAIL, f"{len(FAIL)} failed check(s): " + "; ".join(FAIL)


if __name__ == "__main__":
    raise SystemExit(main())
