# Trading System — Full Development-Cycle Checklist

Status legend: `[x]` done & verified · `[~]` partial / in progress · `[!]` built but NOT yet
proven against reality · `[ ]` not started

> Note: screener internals (§1) reflect prior sessions and are from memory — adjust to your
> actual code. Everything in §2–§5 and §7 was built/verified in the current sessions.

**Where you are right now:** exit engine + run loop + tradability gate = built & tested.
The two big open fronts are (a) the **decision-engine / entry half** (§3) and (b) **proving
the mock write-paths + first forward test** (§7.3–7.4, Monday). Roughly: US exit half done;
US entry half unbuilt; non-US markets deferred.

---

## 1. Screener Suite `[~]`
- [x] **1.1 Stage 1 — Minervini Trend Template**
  - [x] 1.1.1 MA structure (50/150/200) + slope
  - [x] 1.1.2 price vs 52-week high/low thresholds
  - [x] 1.1.3 full 8-criteria trend gate
- [x] **1.2 Stage 2 — Ranking & fundamentals**
  - [x] 1.2.1 RS Rating (IBD percentile, two-pass, segmental ratios)
  - [x] 1.2.2 Finnhub math floor (0–45)
  - [x] 1.2.3 Gemini qualitative (0–55), batched (~10/call)
  - [x] 1.2.4 Stage 2c selective grounding (high-RS rejects, web_search verify)
  - [x] 1.2.5 CATALYST_SCORE_THRESHOLD tuned (55→40)
- [x] **1.3 Stage 3 — VCP engine**
  - [x] 1.3.1 ATR-hybrid ZigZag swing detection
  - [x] 1.3.2 depth / volatility / wave-count / down-vol dry-up / time contraction
  - [x] 1.3.3 pivot lock + breakout proximity tiers
  - [x] 1.3.4 per-universe benchmarks (^GSPC / EFA / EWY)
- [x] **1.4 Universe modules**
  - [x] 1.4.1 S&P 500  *(executable)*
  - [x] 1.4.2 US small-cap  *(executable; some names not on KIS — see §2)*
  - [~] 1.4.3 MSCI ex-US  *(screening done; execution unsupported — see §6)*
  - [~] 1.4.4 MSCI Korea  *(screening done; needs domestic-API engine — see §6.3)*
- [x] **1.5 Regression tests** (`test_screeners_v21.py`, AST static-ref guard)
- [ ] **1.6 Output contract for the entry half**  ← formalization gap
  - [ ] 1.6.1 emit per name: ticker, exchange, RS%, Stage2%, VCP depth, ATR, pivot, base-low→stop
  - [ ] 1.6.2 stable schema (CSV/JSON) the decision engine consumes
- [~] **1.7 Known debt**
  - [ ] 1.7.1 Gemini key stored plaintext (`chmod 600` no-op on Windows) — move to env/secret

## 2. Tradability Gate (`kis_tradable_universe.py`) `[x]`
- [x] 2.1 master download (nas/nys/ams `.cod`) — URLs verified vs official repo
- [!] 2.1a first `--refresh` on your machine (download domain unreachable from build env)
- [x] 2.2 parse (25-col tab, symbol @ index 4) + encoding fallback
- [x] 2.3 cache + freshness window
- [x] 2.4 `resolve()` / `filter()` + symbology variants (BRK-B ↔ BRK.B)
- [ ] 2.5 wire into pipeline (screener output → gate → decision engine)

## 3. Decision Engine / Entry Half `[ ]`  ← THE BRIDGE (unbuilt)
- [ ] 3.1 Portfolio Rank Score (2×RS% + Stage2%)
- [ ] 3.2 Top-N selection (N_max = 8) + exposure/sector caps
- [ ] 3.3 Position sizing (equal-R, adaptive ATR mult 1.3–2.5 via VCP depth)
- [ ] 3.4 Stop derivation (VCP base-low / ATR) → `initial_risk_per_share`
- [ ] 3.5 `PENDING_ENTRY` arming
  - [ ] 3.5.1 place entry limit (BUY)
  - [ ] 3.5.2 entry fill confirmation (`get_fills`)
  - [ ] 3.5.3 construct `Position` on fill → hand to monitor
  - [ ] 3.5.4 entry timeout / partial-entry / rejection handling
- [ ] 3.6 dedup vs existing holdings & open orders
- [ ] 3.7 buying-power / cash check before arming
- [ ] 3.8 entry-half tests (mock)

## 4. Execution / Exit Engine (`engine.py`) `[x]`
- [x] **4.1 Broker layer**
  - [x] 4.1.1 auth / token caching
  - [x] 4.1.2 TR_IDs — live `T`-prefix corrected (verified vs repo)
  - [x] 4.1.3 `get_quote` — bid read from `output2`
  - [x] 4.1.4 `get_holding` / `get_all_holdings` — paginated (H1)
  - [x] 4.1.5 `get_fills` — `inquire-ccnl` full params (safety-critical fix)
  - [x] 4.1.6 `get_order_status` — nccs paging fields
  - [x] 4.1.7 `place_limit_order` / `cancel_order` — body parity
  - [x] 4.1.8 rate limiter (token bucket, M3)
  - [!] 4.1.9 mock write-paths proven vs real account  ← Monday
- [x] **4.2 Exit state machine**
  - [x] 4.2.1 synthetic stop (STOP_HIT)
  - [x] 4.2.2 3R partial + breakeven move
  - [~] 4.2.3 EMA trail (logic done; needs provider — §5.4)
  - [~] 4.2.4 stall exit (day-10) (logic done; needs provider)
  - [x] 4.2.5 reprice loop / order aging
  - [x] 4.2.6 oversell clamp
  - [x] 4.2.7 tri-state UNKNOWN handling
  - [x] 4.2.8 settle window (ambiguous GONE)
- [x] **4.3 Persistence & recovery**
  - [x] 4.3.1 append-only SQLite event store
  - [x] 4.3.2 snapshot recovery + idempotent re-adoption
  - [x] 4.3.3 positive-evidence reconcile (C1)
  - [x] 4.3.4 monotonic-timer rebase on restart (H2)
  - [x] 4.3.5 audit-delta logging
- [~] **4.4 Liveness**
  - [x] 4.4.1 watchdog (heartbeat → reconnect + reconcile)
  - [x] 4.4.2 periodic reconcile (M1 self-heal)
  - [ ] 4.4.3 WebSocket feed (REST-floor for now)
- [ ] **4.5 Residual logic debt**
  - [ ] 4.5.1 M2 — `_take_partial` band price-fallback
  - [ ] 4.5.2 M4 — confirm real KIS `PRICE_BAND`
  - [ ] 4.5.3 `get_quote` `_failed` guard (0/0 on transport error)

## 5. Run Loop / Scheduler (`run_loop.py`) `[x]`
- [x] 5.1 US session clock (manual DST + 2026 holidays)
- [x] 5.2 REST poll → on_tick / on_session_open / on_close / day-roll
- [x] 5.3 recover-on-start + watchdog wiring (positions_provider)
- [ ] 5.4 EMA + daily-close providers for `on_close`  ← wire 21-EMA + close
- [x] 5.5 bootstrap entrypoint (`run_forward_test.py`)
- [ ] 5.6 WebSocket integration (future accelerant)

## 6. Market-Coverage Extensions `[ ]`  (deferred — US first, per your scope)
- [ ] 6.1 non-US exchange codes in `_excg` (TSE / SEHK / SHAA / …)
- [ ] 6.2 multi-currency balance (`TR_CRCY_CD` per market)
- [ ] 6.3 KIS **domestic** API engine for MSCI Korea (separate engine)

## 7. Testing & Validation `[~]`
- [x] 7.1 Sim harness — 8 invariants (`kis_engine_simharness.py`) 8/8
- [x] 7.2 Contract verifier — read paths (auth/quote/balance/nccs/ccnl)
- [!] 7.3 Contract verifier — write paths (`--with-order-test` / `--with-fill-test`)  ← Monday
- [ ] 7.4 Mock forward test — exit half, seeded position  ← Monday
- [ ] 7.5 Entry-half tests (after §3)
- [ ] 7.6 End-to-end pipeline test (screener → gate → entry → manage → exit)
- [ ] 7.7 ~3-month mock forward run (operational reliability, not alpha)

## 8. Ops / Production Hardening `[ ]`
- [ ] 8.1 Real alert sink (Slack / PagerDuty / SMS) wired to `alert`
- [ ] 8.2 Structured logging + rotation
- [~] 8.3 Secrets: env-var / secret-store (fix plaintext Gemini + KIS keys)
- [ ] 8.4 Process supervision / auto-restart
- [ ] 8.5 Health / metrics dashboard
- [ ] 8.6 Live-account cutover checklist (only after mock validation)

---

## Current Focus — next 3 actions
1. **Monday (US session):** prove mock write-paths (7.3) → run first mock forward test of the exit half (7.4).
2. **Wire EMA + close providers** (5.4) so the trail/stall logic is actually active.
3. **Build the decision-engine bridge** (§3) for the US universes — the piece that connects
   screener output to the exit engine and makes the pipeline autonomous. Start with §1.6
   (formalize the screener→engine output contract), then §3.1–3.5.
