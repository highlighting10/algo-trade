from kistrader.config import Config, load_dotenv
from kistrader.entry.decision_engine import DecisionEngine, DecisionConfig, AccountState
from kistrader.entry.screen_contract import read_candidates

load_dotenv()
c = Config.from_env()
cands = read_candidates(c.candidates_path)
eng = DecisionEngine(DecisionConfig())
acct = AccountState(equity=c.equity_usd, cash=c.equity_usd)
plans, rej = eng.plan(cands, acct)

print(f"equity={acct.equity}  risk_budget={acct.equity * eng.cfg.risk_per_trade_pct}  risk/sh={11.47}")
print(f"  risk-based shares = {(acct.equity * eng.cfg.risk_per_trade_pct) / 11.47:.0f}")
print(f"  20% cap shares = {(acct.equity * eng.cfg.max_position_pct) / 193.05:.0f}")

for p in plans:
    print(f"{p.ticker}: {p.shares}주  진입 {p.limit_price}  손절 {p.stop_price}  "
          f"리스크/주 {p.est_risk_per_share}  명목 ${p.est_notional:.0f}")
for r in rej:
    print("거부:", r.ticker, r.reason)
