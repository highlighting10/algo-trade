#!/usr/bin/env python3
"""
F8 -- the PRODUCTION side of the differential fixture.

Drives the REAL `kistrader/core/engine_v2.py` over a sequence of daily OHLC bars
and reports, per trade, the triple the diff asserts on:

    (exit_reason, exit_bar, exit_price)

This is PARAMETER_FREEZE Rev 3 sec.10's preferred fix ("drive the real engine_v2
with a backtest broker"), built so the same object doubles as that broker.

---------------------------------------------------------------------------
WHY LOAD BY PATH
---------------------------------------------------------------------------
`kis-backtest` ships a partial COPY of `kistrader/`, and Python puts the cwd at
sys.path[0], so a plain `import kistrader...` run from the harness repo silently
resolves to the vendored copy (FINDING_backtest_vendored_engine_20260820.md).
A differential fixture that has to hold BOTH engines in one process cannot rely
on sys.path at all.

So we load production's modules from an explicit absolute path with
importlib. Verified precondition: engine_v2.py and providers.py import only
stdlib + `requests` -- no intra-package imports -- so they load standalone with no
package context. `loaded_from()` prints the resolved path of each side, the same
way the 08-20 FINDING recorded `LOADED: ...`. Never report a number from this
file without that line.

---------------------------------------------------------------------------
THE CONVENTIONS. READ THESE BEFORE TRUSTING A NUMBER.
---------------------------------------------------------------------------
`engine_v2` is TICK-driven (`on_tick(price, bid)`) plus `on_close(close, ema)`.
Daily bars carry no intraday sequence, so a tick path must be SYNTHESISED. Every
choice below is a modelling decision, not a fact about the engine, and each one
is a place the harness can legitimately differ.

1. TICK PATH (`tick_path=`)

   "worst"  (default) open -> stop -> +3R -> breakeven-retest -> close
            The stop is visited BEFORE the +3R trigger, so a bar that touches
            both stops out. This is the freeze's stated rule ("both trigger on
            the same bar -> assume the STOP hit first. Always.") and the
            harness's own `ambiguity_mode="worst"`.
            The breakeven-retest exists because "worst" is genuinely worst only
            if a bar that partials AND trades back to entry is allowed to do
            both: 1/3 out at +3R, 2/3 out at breakeven, on one bar.

   "olhc"   open -> stop -> +3R -> close. Same stop-first precedence, but no
            same-bar breakeven retest. Use to size how much the retest costs.

   "ohlc"   open -> +3R -> stop -> close. OPTIMISTIC: partial before stop.
            Present only so the pessimism of "worst" can be measured, never as
            a default.

2. TICK PRICES ARE DECISION PRICES, NOT BAR EXTREMES.
   The stop tick is fed at exactly `stop` (or at `open` when the bar gaps
   through it, because then the open tick is already below the stop). The +3R
   tick is fed at exactly `entry + 3R`, never at `high`. Filling at the extreme
   would flatter the partial and punish the stop. This reproduces the freeze's
   documented fill rules WITHOUT special-casing them: the engine simply sees the
   price at which its own condition first becomes true.

3. FILL PRICE vs ENGINE LIMIT -- the reason the diff does not assert on price.
   engine_v2 has NO fill model. It decides "exit now" and places a limit at
   `_band(bid * (1 - slip), bid, price)`, ~2% under the bid, repricing more
   aggressively every REPRICE_AFTER_SECS. What that limit actually gets is the
   market's business.
   So this broker fills at the TICK price (the decision price) and records the
   engine's limit separately as `engine_limit`. `fill_price` is what the diff
   compares; the gap between the two is exit slippage the harness does not model
   at all, and is reported rather than asserted.

4. days_held / SESSION COUNTING.
   run_loop rolls the day at the first cycle of a new trading date -- before the
   open, therefore before that session's on_close. A position filled intraday on
   bar 0 was not in the list when bar 0 rolled, so:

        bar 0 = entry session, days_held 0
        bar N                 days_held N

   If the harness counts the entry session as day 1, every stall comparison is
   off by one and the stall cases below will say so.

5. EXIT LATENCY. engine_v2 needs a second tick to confirm a fill from positive
   evidence (`_advance_exit` reconciles the working order at the TOP of the next
   call). `_drain` therefore re-ticks at the SAME price until the position
   leaves EXITING. That is engine plumbing, not a bar of delay: exit_bar is the
   bar on which the decision was made.
"""
from __future__ import annotations

import importlib.util
import os
import sys
import tempfile
from dataclasses import dataclass, field
from typing import Optional, Sequence


# ---------------------------------------------------------------------------
# explicit, shadow-proof loading of the PRODUCTION modules
# ---------------------------------------------------------------------------

def load_module(path: str, name: str):
    """Load a module from an absolute file path, bypassing sys.path entirely."""
    path = os.path.abspath(path)
    if not os.path.isfile(path):
        raise FileNotFoundError(f"cannot load {name}: no such file {path!r}")
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise ImportError(f"cannot build a spec for {path!r}")
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    mod.__f8_loaded_from__ = path
    return mod


def load_production(repo_root: str):
    """Load production engine_v2 + providers from `repo_root` (kis-trader-clean).
    Returns (engine_v2_module, providers_module)."""
    E = load_module(os.path.join(repo_root, "kistrader", "core", "engine_v2.py"),
                    "f8_prod_engine_v2")
    P = load_module(os.path.join(repo_root, "kistrader", "entry", "providers.py"),
                    "f8_prod_providers")
    return E, P


def loaded_from(mod) -> str:
    return getattr(mod, "__f8_loaded_from__", "<unknown>")


# ---------------------------------------------------------------------------
# bars
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class Bar:
    date: str
    open: float
    high: float
    low: float
    close: float

    def __post_init__(self):
        if not (self.low <= self.open <= self.high and self.low <= self.close <= self.high):
            raise ValueError(f"incoherent bar {self.date}: "
                             f"O{self.open} H{self.high} L{self.low} C{self.close}")


@dataclass
class Trade:
    """The unit the diff compares. `exit_bar` is the INDEX into the bar list."""
    exit_reason: Optional[str] = None
    exit_bar: Optional[int] = None
    exit_price: Optional[float] = None      # share-weighted, all legs
    r_multiple: Optional[float] = None      # share-weighted realised R
    legs: list = field(default_factory=list)   # [(bar, qty, price, tag)]
    days_held: int = 0
    final_state: str = ""
    engine_limits: list = field(default_factory=list)  # what engine_v2 actually sent

    def key(self):
        """The tuple the diff asserts on. Price deliberately excluded -- see sec.3."""
        return (self.exit_reason, self.exit_bar)


# ---------------------------------------------------------------------------
# broker + clock
# ---------------------------------------------------------------------------

class BarClock:
    """Monotonic clock the runner advances by hand, so SETTLE/REPRICE timers are
    deterministic instead of wall-clock dependent."""
    def __init__(self, t0: float = 1000.0):
        self.t = float(t0)

    def __call__(self) -> float:
        return self.t

    def advance(self, secs: float):
        self.t += secs


class BarBroker:
    """In-memory broker for daily-bar replay.

    A SELL limit is filled IMMEDIATELY and IN FULL at the current tick price
    (see sec.3 above), because engine_v2 only ever sends one after its own trigger
    condition has already become true at that price. The engine's limit is
    recorded but not used to fill.
    """

    RESTING, GONE = "RESTING", "GONE"

    def __init__(self, ticker: str, shares: int):
        self.ticker = ticker
        self.holdings = {ticker: int(shares)}
        self.orders = {}
        self._next = 1
        self.tick_price = 0.0        # set by the runner before each engine call
        self.bar_index = 0
        self.fills = []              # [(bar, qty, price, tag)]
        self.limits = []             # [(bar, limit)] -- what engine_v2 asked for
        self.place_calls = 0
        self.cancel_calls = 0
        # Labels each fill leg. Set by the runner to a callable reading the live
        # Position, because WHICH leg an order belongs to is only knowable at the
        # moment engine_v2 places it (a partial is sent while still FILLED; an
        # exit is sent while EXITING).
        self.tag_fn = lambda: "EXIT"

    # -- runner hooks --
    def set_tick(self, price: float, bar_index: int):
        self.tick_price = float(price)
        self.bar_index = int(bar_index)

    # -- broker interface used by ExecutionMonitor --
    def place_limit_order(self, ticker, shares, price, side, exchange="NAS"):
        self.place_calls += 1
        oid = f"F8-{self._next}"
        self._next += 1
        qty = int(shares)
        self.limits.append((self.bar_index, float(price)))
        # fill in full at the decision price
        fill_px = self.tick_price
        self.holdings[ticker] = max(0, self.holdings.get(ticker, 0) - qty)
        self.orders[oid] = {"ticker": ticker, "qty": qty, "filled": qty,
                            "price": fill_px, "status": self.GONE}
        self.fills.append((self.bar_index, qty, fill_px, self.tag_fn()))
        return {"ok": True, "order_id": oid, "msg": "ok"}

    def cancel_order(self, ticker, order_id, qty, exchange="NAS"):
        self.cancel_calls += 1
        return {"ok": True, "msg": "cancelled"}

    def get_fills(self, order_id):
        o = self.orders.get(order_id)
        return None if o is None else o["filled"]

    def get_order_status(self, order_id):
        o = self.orders.get(order_id)
        return self.GONE if o is None else o["status"]

    def get_holding(self, ticker, exchange="NAS"):
        return self.holdings.get(ticker, 0)

    def get_all_holdings(self):
        return dict(self.holdings)

    def get_quote(self, ticker, exchange="NAS"):
        return {"last": self.tick_price, "bid": self.tick_price}


# ---------------------------------------------------------------------------
# the runner
# ---------------------------------------------------------------------------

MAX_DRAIN_TICKS = 12       # bound on the confirm-the-fill re-tick loop
TICK_PATHS = ("worst", "olhc", "ohlc")


class EngineExitRunner:
    """Replays daily bars through the real ExecutionMonitor, in run_loop's order:

        DAY_ROLL -> on_session_open -> intraday ticks -> on_close
    """

    def __init__(self, E, *, stall_day: int, tick_path: str = "worst"):
        if tick_path not in TICK_PATHS:
            raise ValueError(f"tick_path must be one of {TICK_PATHS}")
        self.E = E
        self.stall_day = int(stall_day)
        self.tick_path = tick_path

    # -- internals --
    def _tmp_db(self):
        fd, path = tempfile.mkstemp(suffix=".db")
        os.close(fd)
        return self.E.EventStore(path), path

    def _partial_trigger(self, pos) -> float:
        return pos.entry_price + self.E.R_PARTIAL_MULTIPLE * pos.initial_risk_per_share

    def _tick_prices(self, bar: Bar, pos, is_entry_bar: bool = False):
        """Yield decision prices for one bar, RE-READING `pos` between yields --
        deliberately, because the stop moves when a partial confirms."""
        E = self.E
        # THE ENTRY BAR HAS NO OPEN TICK. The position does not exist until the
        # breakout fills it intraday, so the bar's open happened BEFORE we were
        # in and cannot trigger anything. Starting the path at the open would
        # book a gap the trade never took: a bar that opens at 85, runs through
        # the pivot (filling us at 100) and prints a high of 105 would exit at
        # 85 instead of at the stop. The harness gets this right explicitly
        # ("On the entry bar the gap already happened before the fill, so the
        # stop fills AT the stop, not at the open") and this side must match --
        # not to agree with the harness, but because the harness is correct.
        first = pos.entry_price if is_entry_bar else bar.open
        yield first

        # A bar that OPENS at or above +3R fires the partial on that very first
        # tick. engine_v2 confirms a partial on the NEXT call (_confirm_partial
        # runs at the top of _on_tick), so without this second tick the position
        # stays PARTIAL_PENDING for the rest of the bar: `partial_done` never
        # becomes True, and the same-bar breakeven retest below is skipped
        # entirely. That silently spared the runner a breakeven stop-out on every
        # gap-up-partial bar -- found by the randomised sweep (F961), not by any
        # of the hand-written cases, and it made this side look better than the
        # engine really is.
        if pos.partial_pending:
            yield first

        def stop_tick():
            s = pos.stop_loss_price
            # A gap through the stop is already covered by the first tick when
            # that tick IS the open. On the entry bar the first tick is the
            # entry, so the stop is reachable from any low at or below it.
            if first > s >= bar.low:
                return s
            return None

        def partial_tick():
            if pos.partial_done or pos.partial_pending:
                return None
            t = self._partial_trigger(pos)
            return t if bar.high >= t else None

        if self.tick_path == "ohlc":
            t = partial_tick()
            if t is not None:
                yield t
                yield t          # second tick confirms the partial fill
            s = stop_tick()
            if s is not None:
                yield s
        else:
            s = stop_tick()
            if s is not None:
                yield s
            t = partial_tick()
            if t is not None:
                yield t
                yield t
            if self.tick_path == "worst" and pos.partial_done:
                # same-bar breakeven retest: the bar partialled AND traded back
                # to entry, so "worst" takes both legs on this bar.
                s2 = pos.stop_loss_price
                if bar.low <= s2 <= bar.high:
                    yield s2

        yield bar.close

    def _drain(self, mon, pos, broker, price, bar_i, clock):
        """engine_v2 confirms a fill on the NEXT call -- re-tick at the same price
        until the position leaves EXITING. Not a bar of latency (see sec.5)."""
        n = 0
        while pos.state == self.E.PositionState.EXITING and n < MAX_DRAIN_TICKS:
            clock.advance(1.0)
            broker.set_tick(price, bar_i)
            mon.on_tick(pos, price, price)
            n += 1
        if n >= MAX_DRAIN_TICKS:
            raise RuntimeError(f"exit did not settle in {MAX_DRAIN_TICKS} ticks "
                               f"(bar {bar_i}, state {pos.state})")

    # -- public --
    def run(self, bars: Sequence[Bar], *, entry_price: float, stop_price: float,
            shares: int, emas: Optional[Sequence[Optional[float]]] = None,
            ticker: str = "TST") -> Trade:
        E = self.E
        old_stall = E.STALL_DAY
        E.STALL_DAY = self.stall_day
        db, db_path = self._tmp_db()
        try:
            broker = BarBroker(ticker, shares)
            clock = BarClock()
            mon = E.ExecutionMonitor(broker, db, alert=lambda m: None, clock=clock)
            pos = E.Position(
                ticker=ticker, state=E.PositionState.FILLED, shares=int(shares),
                entry_price=float(entry_price), stop_loss_price=float(stop_price),
                initial_risk_per_share=float(entry_price) - float(stop_price),
                exchange="NAS", days_held=0, order_key=f"{ticker}:{bars[0].date}")

            # a leg placed while EXITING is an exit leg; anything else is the
            # +3R partial (engine_v2 sends that one while still FILLED)
            broker.tag_fn = lambda: (pos.exit_reason or "EXIT"
                                     if pos.state == E.PositionState.EXITING
                                     else "PARTIAL")

            exit_bar = None
            for i, bar in enumerate(bars):
                if i > 0:                                   # sec.4: entry session does not roll
                    mon.advance_trading_day([pos], bar.date)

                # queued exit from last close executes at THIS open
                if pos.pending_exit and pos.state in E.HOLDING_STATES:
                    broker.set_tick(bar.open, i)
                    mon.on_session_open(pos, bar.open, bar.open)
                    self._drain(mon, pos, broker, bar.open, i, clock)
                if pos.state in E.TERMINAL_STATES:
                    exit_bar = i
                    break

                for px in self._tick_prices(bar, pos, is_entry_bar=(i == 0)):
                    broker.set_tick(px, i)
                    mon.on_tick(pos, px, px)
                    if pos.state == E.PositionState.EXITING:
                        self._drain(mon, pos, broker, px, i, clock)
                    if pos.state in E.TERMINAL_STATES:
                        break
                if pos.state in E.TERMINAL_STATES:
                    exit_bar = i
                    break

                # on_close ALWAYS runs, exactly as run_loop calls it on every
                # OPEN->CLOSED transition. When a case supplies no EMA we pass
                # 0.0 rather than skipping: `close < 0.0` is unreachable, so the
                # EMA branch stays inert while the STALL branch still runs. That
                # keeps this side structurally identical to the harness, which
                # evaluates its close block on every bar regardless of the EMA.
                ema = emas[i] if (emas is not None and i < len(emas)) else None
                mon.on_close(pos, bar.close, 0.0 if ema is None else float(ema))

            return self._to_trade(pos, broker, bars, exit_bar, entry_price, stop_price, shares)
        finally:
            E.STALL_DAY = old_stall
            db.conn.close()
            try:
                os.unlink(db_path)
            except OSError:
                pass

    # -- reporting --
    @staticmethod
    def _to_trade(pos, broker, bars, exit_bar, entry_price, stop_price, shares) -> Trade:
        risk = float(entry_price) - float(stop_price)
        legs = list(broker.fills)
        # exit_price is the price of the leg(s) that CLOSED the position. The +3R
        # partial is a separate leg and is reported in `legs`, not folded in here
        # -- averaging them would make a 1.0R partial-then-breakeven trade look
        # like a single fill at 110.
        exit_legs = [l for l in legs if l[3] != "PARTIAL"]
        eq = sum(q for _, q, _, _ in exit_legs)
        wavg = (sum(q * p for _, q, p, _ in exit_legs) / eq) if eq else None
        sold = sum(q for _, q, _, _ in legs)
        r = None
        if risk > 0:
            # open remainder (never exited) is marked at the last close
            pnl = sum(q * (p - entry_price) for _, q, p, _ in legs)
            rest = int(shares) - sold
            if rest > 0:
                pnl += rest * (bars[-1].close - entry_price)
            r = pnl / (int(shares) * risk)
        return Trade(exit_reason=pos.exit_reason, exit_bar=exit_bar,
                     exit_price=None if wavg is None else round(wavg, 4),
                     r_multiple=None if r is None else round(r, 4),
                     legs=legs, days_held=pos.days_held,
                     final_state=pos.state.value,
                     engine_limits=list(broker.limits))
