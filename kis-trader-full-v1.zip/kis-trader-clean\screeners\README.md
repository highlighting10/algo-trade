# screeners/

Put your four screeners here:

- `sp500_v21.py`       ✅ §1.6 patch applied
- `us_small_v21.py`    ✅ §1.6 patch applied
- the MSCI ex-US screener      ⬜ still needs the §1.6 patch
- the MSCI Korea screener      ⬜ still needs the §1.6 patch

They produce `candidates.csv`, which the entry half consumes
(`entry/screen_contract.py` → `read_candidates`).

## The §1.6 patch

`sp500_v21.py` and `us_small_v21.py` already have it: three keys added to the
`Extracted_Pattern` dict in `generate_report()` — `Base_Low`, `Latest_Close`,
`Latest_ATR` — with no change to scoring/detection. Apply the same three lines
(see `../docs/screener_patch_1_6.md`) to the MSCI ex-US and MSCI Korea screeners
when you add them; the `Extracted_Pattern` block is identical across all four.

Without the patch the pipeline fails *closed* — it arms nothing and tells you why —
rather than trading with the extension guard and ATR stop silently disabled.

## Generating candidates.csv

`entry/screen_contract.py` provides `candidate_from_report()` and
`write_candidates()`; call them from your screener's output stage, or adapt the
report dicts your screeners already emit.
