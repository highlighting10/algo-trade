"""
10_rr.py -- WHY is realised reward:risk 1.15:1 instead of the assumed 3:1?

The project's founding calculation assumed 50 trades/yr, 50% wins, 3:1 R:R,
giving +1.0R per trade. The backtest measures a 49.6% win rate -- the assumption
was right -- but 1.15:1, giving +0.05R. The entire gap is reward:risk.

This separates the two possible causes, which have opposite remedies:

  ENTRY problem  -- trades never go anywhere. MFE (max favourable excursion) is
                    small, so there was never 3R to capture. Fix the setups.

  EXIT problem   -- trades DO reach 2-3R but we exit near zero. MFE is large and
                    give-back is large. Fix the exit rules.

Usage:
    python scripts/10_rr.py --threshold 70 --signals data/signals_daily.pkl
"""
import pathlib as _pl
import sys as _sys
_sys.path.insert(0, str(_pl.Path(__file__).resolve().parent.parent))

import argparse
import pathlib
import pickle
from collections import defaultdict

import numpy as np
import pandas as pd

from minervini_backtest import (BacktestConfig, DecisionConfig, load_sector_map,
                                run)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--threshold", type=float, default=70.0)
    ap.add_argument("--slippage", type=float, default=5.0)
    ap.add_argument("--signals", default="data/signals.pkl")
    ap.add_argument("--start", default=None)
    ap.add_argument("--end", default=None)
    ap.add_argument("--rank-mode", default="rs_only",
                    choices=["rs_only", "vcp_only", "rs_plus_vcp"])
    ap.add_argument("--stall-day", type=int, default=None)
    ap.add_argument("--risk-pct", type=float, default=None)
    ap.add_argument("--max-position-pct", type=float, default=None)
    ap.add_argument("--regime-ma", type=int, default=None)
    args = ap.parse_args()

    bars = {p.stem: pd.read_parquet(p)
            for p in pathlib.Path("data/bars").glob("*.parquet")}
    prices = {t: d for t, d in bars.items() if t != "^GSPC"}
    with open(args.signals, "rb") as f:
        signals = pickle.load(f)["signals"]
    if args.start or args.end:
        lo = pd.Timestamp(args.start) if args.start else pd.Timestamp.min
        hi = pd.Timestamp(args.end) if args.end else pd.Timestamp.max
        signals = {d: v for d, v in signals.items() if lo <= pd.Timestamp(d) <= hi}

    _b = bars.get("^GSPC")
    cfg = BacktestConfig(rank_mode=args.rank_mode, equity_mode="compounding",
                         entry_mode="pivot_limit", ambiguity_mode="worst",
                         vcp_threshold=args.threshold, slippage_bps=args.slippage,
                         sector_map=load_sector_map("data/sectors.csv"),
                         benchmark_close=(_b["Close"] if _b is not None else None),
                         decision=DecisionConfig(
                             **{k: v for k, v in
                                (("risk_per_trade_pct", args.risk_pct),
                                 ("max_position_pct", args.max_position_pct))
                                if v is not None}),
                         **({"stall_day": args.stall_day}
                            if args.stall_day is not None else {}),
                         **({"regime_ma": args.regime_ma}
                            if args.regime_ma is not None else {}))
    eq, trades, st, dr, dg = run(prices, signals, cfg)
    if not trades:
        raise SystemExit("[rr] no trades")

    mfe = np.array([t.max_r_seen for t in trades])
    # a run with zero losers (small samples) must not crash the ratio
    _al = st["avg_loss_pct"]
    rr = (abs(st["avg_win_pct"] / _al) if _al else float("nan"))

    print("=" * 72)
    print(f"REWARD:RISK  threshold={args.threshold}  {len(trades)} trades")
    print("=" * 72)
    print(f"  win rate                 : {st['win_rate_pct']}%  "
          f"(founding assumption: 50%)")
    _rr_txt = f"{rr:.2f} : 1" if _al else "n/a (no losing trades)"
    print(f"  avg win / avg loss       : {st['avg_win_pct']}% / "
          f"{st['avg_loss_pct']}%  = {_rr_txt}  (assumption: 3:1)")
    print(f"  expectancy per trade     : {st['expectancy_R']:+.3f} R  "
          f"(assumption: +1.0 R)")
    print()
    print("  DID THE MOVES EXIST?  (MFE = best R the trade ever showed)")
    print(f"    mean MFE               : {mfe.mean():.3f} R")
    print(f"    median MFE             : {np.median(mfe):.3f} R")
    print(f"    p75 / p90 MFE          : {np.percentile(mfe,75):.3f} / "
          f"{np.percentile(mfe,90):.3f} R")
    print(f"    reached >= 2R          : {st['pct_reaching_2R']}% of trades")
    print(f"    reached >= 3R          : {st['pct_reaching_3R']}% of trades")
    print()
    print("  HOW MUCH DID WE GIVE BACK?")
    print(f"    mean MFE               : {st['avg_mfe_R']:+.3f} R")
    print(f"    mean exit              : {st['avg_r_at_exit']:+.3f} R")
    print(f"    mean give-back         : {st['giveback_R']:+.3f} R "
          f"({100*st['giveback_R']/max(st['avg_mfe_R'],1e-9):.0f}% of MFE)")
    print()
    print("  BY EXIT REASON")
    by = defaultdict(list)
    for t in trades:
        by[t.reason].append(t)
    print(f"    {'reason':<12} {'n':>5} {'mean MFE':>9} {'mean exit':>10} "
          f"{'give-back':>10} {'held':>6}")
    for r in sorted(by, key=lambda k: -len(by[k])):
        g = by[r]
        m = np.mean([t.max_r_seen for t in g])
        e = np.mean([t.r_at_exit for t in g])
        h = np.mean([t.days_held for t in g])
        print(f"    {r:<12} {len(g):>5} {m:>9.3f} {e:>10.3f} {m-e:>10.3f} {h:>6.1f}")

    print()
    print("=" * 72)
    print("  DIAGNOSIS")
    print("=" * 72)
    rex = np.array([float(t.r_at_exit) for t in trades])
    win, los = rex > 0, rex <= 0
    mfe_w = mfe[win].mean() if win.any() else float("nan")
    mfe_l = mfe[los].mean() if los.any() else float("nan")
    ex_w = rex[win].mean() if win.any() else float("nan")
    ex_l = rex[los].mean() if los.any() else float("nan")
    gb_w = mfe_w - ex_w
    print("  GIVE-BACK SPLIT BY OUTCOME -- the aggregate figure mixes two different")
    print("  things and misleads whenever the win rate is low.")
    print(f"    winners  n={int(win.sum()):<5} mean MFE {mfe_w:+.3f} R   "
          f"mean exit {ex_w:+.3f} R   gave back {100 * gb_w / max(mfe_w, 1e-9):.0f}%")
    print(f"    losers   n={int(los.sum()):<5} mean MFE {mfe_l:+.3f} R   "
          f"mean exit {ex_l:+.3f} R")
    print("    MFE on a LOSING trade is intrabar noise, not a captured gain handed")
    print("    back. Only the winners' figure is a give-back.")
    print()
    for _k in ("total_return_pct", "max_drawdown_pct"):
        if _k not in st:
            print(f"  [!] {_k} missing from stats. available keys: {sorted(st)}")
    print(f"  total return             : {st.get('total_return_pct', float('nan')):+.2f}%")
    print(f"  max drawdown             : {st.get('max_drawdown_pct', float('nan')):+.2f}%")
    print()
    if gb_w > 0.5 * mfe_w:
        print("  EXIT problem: winners hand back more than half of what they showed.")
    elif st["pct_reaching_3R"] < 10:
        print("  ENTRY problem: the moves are not there to catch.")
    else:
        print("  Winners are being captured and the moves exist. Expectancy is limited")
        print("  by the win rate -- the intended shape of a trend system.")
    if mfe_l > 0.75:
        print()
        print(f"  NOTE: losers showed {mfe_l:.2f} R of MFE on average, which makes a")
        print("  tighter stop LOOK attractive. Do not assume it -- measure it with")
        print("  06_sweep.py --param betrigger. On this book that test came back NEGATIVE.")


if __name__ == "__main__":
    main()
