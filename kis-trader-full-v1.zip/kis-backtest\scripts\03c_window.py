"""
03c_window.py -- WHICH 2y window did production actually use?

The engine's base detector is sensitive to the FRONT edge of the window: extra
early bars can expose a competing earlier base and move base_start_bar by
hundreds of bars, which moves the score discontinuously.

signals.PITBars slices tail(504) because I hardcoded 2y = 504 sessions.
Production calls yf.Ticker(t).history(period="2y"), which is a CALENDAR window --
on 2026-08-05 it starts ~2024-08-05, not 2024-08-01.

This does not assume which is right. It sweeps the window length, scores each
one, and reports which lengths reproduce the known production scores. If a single
length reproduces most tickers, that is production's window and the fix is exact.

Usage:
    python scripts/03c_window.py
    python scripts/03c_window.py --lo 480 --hi 530
"""
import pathlib as _pl
import sys as _sys
_sys.path.insert(0, str(_pl.Path(__file__).resolve().parent.parent))

import argparse
import pathlib
from collections import Counter

import pandas as pd

import vcp_engine as ve
from signals import VCP_BENCHMARK

GATE_DATE = pd.Timestamp("2026-08-05")
EXPECTED = {
    "NTAP": 73.55, "UNH": 67.58, "NUE": 59.83, "STT": 58.64, "HPE": 58.25,
    "BRKR": 72.00, "PTGX": 62.54, "IRDM": 58.66, "OKTA": 58.29, "LFST": 57.07,
}
TOL = 0.01


def load(t):
    p = pathlib.Path(f"data/bars/{t}.parquet")
    if not p.exists():
        return None
    df = pd.read_parquet(p).sort_index()
    if getattr(df.index, "tz", None) is not None:
        df.index = df.index.tz_localize(None)
    return df


def score_for(df, idx_df, n_rows, T):
    w = df.loc[:T].tail(n_rows)
    if len(w) < 60:
        return None, None
    i = idx_df.loc[:T].tail(n_rows) if idx_df is not None else None
    try:
        rep = ve.VCPAnalyzerV4(w, index_df=i, config=ve.VCPConfig()).generate_report()
    except Exception:
        return None, None
    if not rep:
        return None, None
    pat = rep.get("Extracted_Pattern") or {}
    return rep.get("Score"), pat.get("Base_Start_Bar")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--lo", type=int, default=485)
    ap.add_argument("--hi", type=int, default=525)
    args = ap.parse_args()

    idx_df = load(VCP_BENCHMARK)
    if idx_df is None:
        raise SystemExit("[window] no ^GSPC bars")

    bars = {t: load(t) for t in EXPECTED}
    bars = {t: d for t, d in bars.items() if d is not None}
    T = GATE_DATE
    print(f"[window] gate {T.date()}, sweeping window length {args.lo}..{args.hi}\n")

    # what a CALENDAR 2y window would contain, for reference
    cal_start = T - pd.DateOffset(years=2)
    for t, df in list(bars.items())[:1]:
        n_cal = len(df.loc[cal_start:T])
        print(f"[window] calendar 2y ({cal_start.date()}..{T.date()}) = {n_cal} rows "
              f"for {t}; current code uses tail(504)\n")

    hits = Counter()
    per_ticker = {}

    # ---- calendar mode first: this is literally what production calls --------
    print("=" * 74)
    print("CALENDAR 2y WINDOW  (what yf.Ticker().history(period='2y') returns)")
    print("=" * 74)
    cal_ok = 0
    for t, df in bars.items():
        exp = EXPECTED[t]
        w = df.loc[cal_start:T]
        i = idx_df.loc[cal_start:T]
        try:
            rep = ve.VCPAnalyzerV4(w, index_df=i, config=ve.VCPConfig()).generate_report()
        except Exception as e:
            print(f"  {t:6} EXCEPTION {type(e).__name__}")
            continue
        sc = rep.get("Score") if rep else None
        pat = (rep or {}).get("Extracted_Pattern") or {}
        ok = sc is not None and abs(sc - exp) <= TOL
        cal_ok += bool(ok)
        print(f"  {t:6} exp={exp:6.2f} got={sc if sc is not None else '-':>6} "
              f"{'MATCH' if ok else '     '}  rows={len(w)} "
              f"base_start_bar={pat.get('Base_Start_Bar')} waves={pat.get('Wave_Count')}")
    print(f"\n  calendar mode reproduces {cal_ok}/{len(bars)} ticker(s)\n")

    print("=" * 74)
    print(f"SESSION-COUNT SWEEP  {args.lo}..{args.hi}")
    print("=" * 74)
    for t, df in bars.items():
        exp = EXPECTED[t]
        matches = []
        for n in range(args.lo, args.hi + 1):
            sc, bsb = score_for(df, idx_df, n, T)
            if sc is not None and abs(sc - exp) <= TOL:
                matches.append(n)
                hits[n] += 1
        per_ticker[t] = matches
        shown = matches if len(matches) <= 8 else matches[:8] + ["..."]
        print(f"  {t:6} expected {exp:6.2f}  reproduced at window length(s): "
              f"{shown if matches else 'NONE in range'}")

    print("\n" + "=" * 74)
    print("WINDOW LENGTHS THAT REPRODUCE THE MOST TICKERS")
    print("=" * 74)
    if not hits:
        print("  none in this range.")
        print("  Widen with --lo/--hi, or the divergence is not window length.")
    else:
        for n, c in hits.most_common(8):
            first = {t: (bars[t].loc[:T].tail(n).index[0].date()) for t in list(bars)[:1]}
            print(f"  tail({n}): reproduces {c}/{len(bars)} ticker(s)   "
                  f"window starts {list(first.values())[0]}")
        best, cnt = hits.most_common(1)[0]
        print(f"\n  BEST: tail({best}) reproduces {cnt}/{len(bars)}")
        if cnt >= len(bars) - 2:
            print(f"  -> set _PERIOD_SESSIONS['2y'] = {best} in signals.py, rerun 03_gate.py")
        else:
            print("  -> no single length reproduces most tickers, so window length")
            print("     alone is not the explanation. Do NOT tune it to fit.")
        never = [t for t, m in per_ticker.items() if not m]
        if never:
            print(f"  Never reproduced at any length: {never}")
            print("  Those need a separate explanation -- chase them individually.")


if __name__ == "__main__":
    main()
