#!/usr/bin/env python3
"""
apply_e11_timing.py -- E11: the TIMING half of E10, in the e2e suite.

WHAT WAS STILL UNPROVEN

Layer 1 proved the arithmetic (35/35). Layer 2's --verify proved the read, and
--verify-real proved it against the box's own event store. None of that shows:

  * that arm_today calls the read at the right MOMENT,
  * that self.mon.db is the right object at runtime,
  * that the LOSS_STREAK alert renders in a driven session,
  * that the ceiling actually reaches plan().

Only a driven loop shows those, which is what this block adds to
tests/test_pipeline_e2e.py. It needs no market and no data -- E7 already drives
arm_today end to end with fake brokers and a fake clock; this is the same shape
with the gate ON.

THE LADDER IS THE PROOF

Four candidates at 20,100 of notional each against 100,000 of equity, so every
rung lands on a DIFFERENT arm count:

    ceiling 1.00 -> 4 armed        (gate off, or streak 0-1)
    ceiling 0.50 -> 2 armed        (streak 2)
    ceiling 0.25 -> 1 armed        (streak 3+)

Monotone and distinct at every rung. A ceiling that was computed and then
dropped would pass every unit check and fail here.

MEASURED SABOTAGE (2026-09-20, before shipping)

    loss_streak never reaches decide()   ->  7 checks red, 117/124
    provenance filter disabled (2b off)  ->  4 checks red, 120/124

The second reproduces the production defect exactly: `a seeded WINNER does not
restore the ceiling (4 [])` -- four armed instead of one, because the seed
cleared a real three-loss streak. That is the bug found on the box on 09-19.

    python apply_e11_timing.py --verify
    python apply_e11_timing.py
    python apply_e11_timing.py --revert

Run from the repo root, on branch e10-progressive-exposure. Requires 2b.
"""
from __future__ import annotations

import argparse
import os
import subprocess
import sys
import tempfile

REPO_BRANCH = "e10-progressive-exposure"
F_TEST = os.path.join("tests", "test_pipeline_e2e.py")
SENTINEL = "def test_e11_progressive_exposure"
N_NEW_CHECKS = 23

BLOCK = '''def _streak_close(db, key, r=-1.0, provenance="ENTRY_ARMED", partial=False):
    """Write ONE closed trade into the event store the loop actually reads.

    `provenance` is the layer-2b allowlist marker: an ENTRY_ event means the
    strategy made this trade. None writes no marker at all (unknown
    provenance); "SEEDED_ENTRY_ARMED:manual" is what seed_position writes.
    """
    import json
    entry, risk, tkr = 100.0, 10.0, key.split(":")[0]
    ins = ("INSERT INTO position_events (ticker, order_key, event_type, "
           "state_to, shares, price, broker_order_id, payload) "
           "VALUES (?,?,?,?,?,?,?,?)")
    if provenance:
        db.conn.execute(ins, (tkr, key, provenance, "FILLED", 0, entry, None, None))
    # Serialised through the REAL Position, not a hand-built dict: recovery
    # deserialises every payload on start(), so a hand-built one both crashes
    # load_open_snapshots and lets the Position schema drift away from what
    # this fixture claims a close looks like.
    pos = Position(ticker=tkr, state=PositionState.CLOSED, shares=0,
                   entry_price=entry, stop_loss_price=entry - risk,
                   initial_risk_per_share=risk, order_key=key,
                   partial_done=partial)
    db.conn.execute(ins, (tkr, key, "CLOSED:STOP_HIT", "CLOSED", 0,
                          entry + r * risk, None, json.dumps(pos.to_dict())))
    db.conn.commit()


def _streak_setup(now, ceilings, losses=0, seeded=None, unknown=0):
    """A loop with the progressive-exposure gate configured, a seeded history,
    and FOUR candidates. Four is deliberate: each is 20,100 of notional against
    100,000 of equity, so the ceiling lands on a DIFFERENT arm count at every
    rung -- 1.00 -> 4 armed, 0.50 -> 2, 0.25 -> 1. A ladder that is monotone
    and distinct is what proves the number reached plan() rather than merely
    being computed and dropped."""
    b, db, path, mon, entry, dec, loop, fclk = _assemble(now)
    loop.exposure = ExposureController(ExposureConfig(loss_streak_ceilings=ceilings))
    for i in range(losses):
        _streak_close(db, f"L{i}:2026-07-0{i + 1}", r=-1.0)
    if seeded is not None:                      # newest: a seeded WINNER
        _streak_close(db, "SEED:2026-07-06", r=seeded,
                      provenance="SEEDED_ENTRY_ARMED:manual")
    for i in range(unknown):
        _streak_close(db, f"U{i}:2026-07-06", r=-1.0, provenance=None)
    cands = [_cand(t, pivot=100.0, base_low=92.0, last_close=100.0)
             for t in ("AAA", "BBB", "CCC", "DDD")]
    csv = _write_csv(cands, path="e2e_streak.csv", regime="risk_on")
    return b, db, loop, csv


def test_e11_progressive_exposure():
    """E10 layers 1/2/2b -- the TIMING half.

    Layer 1 proved the arithmetic and layer 2's verify proved the read against
    the box's real store. Neither could show that `arm_today` calls the read at
    the right moment, that `self.mon.db` is the right object at runtime, that
    the LOSS_STREAK alert renders in a session, or that the ceiling reaches
    plan(). Those are what this block is for, and only a driven loop shows them.

    THE LADDER IS THE PROOF. Four candidates at 20,100 each against 100,000 of
    equity: ceiling 1.00 -> 4 armed, 0.50 -> 2, 0.25 -> 1. Each rung produces a
    different, observable arm count, so a ceiling that was computed but never
    written would fail here even though every unit check still passed.

    Sabotage-measured 2026-09-20: dropping `loss_streak=` from the decide()
    call turns 7 of these red; disabling the 2b provenance filter turns 4 red,
    reproducing the box's seeded-position defect exactly."""
    from kistrader.notifier import classify
    from kistrader.entry.exposure_controller import DEFAULT_LOSS_STREAK_CEILINGS
    print("E11 progressive exposure: our own closed trades write the ceiling")
    now = {"t": OPEN_UTC}
    RUNGS = DEFAULT_LOSS_STREAK_CEILINGS

    # (a) THE SHIPPED DEFAULT. Gate off -> unchanged, and the store is never
    # read. A counter, not an assertion about intent: with the gate off the
    # tree must make no extra database call at all.
    b, db, loop, csv = _streak_setup(now, ceilings=None, losses=3)
    calls = []
    _real = db.recent_closed_r
    db.recent_closed_r = lambda *a, **k: (calls.append(1), _real(*a, **k))[1]
    seen = _capture(loop)
    armed, rej = loop.arm_today(csv)
    check("gate OFF (shipped default): all four arm despite 3 real losses",
          len(armed) == 4, f"{len(armed)} {[r.reason for r in rej]}")
    check("gate OFF: the event store is never read", calls == [], f"{calls}")
    check("gate OFF: no progressive-exposure alert",
          not any("progressive exposure" in m for m in seen), f"{seen}")

    # (b) 1 loss -> the gate is SILENT. It must not bite before its first rung.
    b, db, loop, csv = _streak_setup(now, ceilings=RUNGS, losses=1)
    seen = _capture(loop)
    armed, rej = loop.arm_today(csv)
    check("streak 1: gate silent, all four arm", len(armed) == 4,
          f"{len(armed)} {[r.reason for r in rej]}")
    check("streak 1: nothing announced",
          not any("progressive exposure" in m for m in seen), f"{seen}")

    # (c) 2 losses -> ceiling 0.50. The ladder's first rung, and the arm count
    # is what shows the number arrived at plan().
    b, db, loop, csv = _streak_setup(now, ceilings=RUNGS, losses=2)
    seen = _capture(loop)
    armed, rej = loop.arm_today(csv)
    check("streak 2 -> ceiling 50%: exactly two arm", len(armed) == 2,
          f"{len(armed)} {[r.reason for r in rej]}")
    check("streak 2: the rejection names the exposure ceiling",
          bool(rej) and all("exposure ceiling" in r.reason for r in rej),
          f"{[r.reason for r in rej]}")
    check("streak 2: announced, with the count and the ceiling",
          any("progressive exposure" in m and "2 consecutive losing" in m
              and "50%" in m for m in seen),
          f"{[m for m in seen if 'progressive' in m]}")

    # (d) 3 losses -> ceiling 0.25. The deeper rung must bind HARDER, not the
    # same: identical arm counts here would pass a gate that ignored the rung.
    b, db, loop, csv = _streak_setup(now, ceilings=RUNGS, losses=3)
    seen = _capture(loop)
    armed, rej = loop.arm_today(csv)
    check("streak 3 -> ceiling 25%: exactly one arms", len(armed) == 1,
          f"{len(armed)} {[r.reason for r in rej]}")
    check("streak 3: announced at 25%",
          any("progressive exposure" in m and "25%" in m for m in seen),
          f"{[m for m in seen if 'progressive' in m]}")
    # Normal operation on a bad run, not a fault: it must NOT reach the phone,
    # and it must NOT carry the ARM BLOCKED phrase that routes a CRITICAL.
    check("streak 3: the alert is WARN, not a phone push",
          all(classify(m) == "WARN"
              for m in seen if "progressive exposure" in m),
          f"{[(classify(m), m) for m in seen if 'progressive exposure' in m]}")
    check("streak 3: arming is LIMITED, never BLOCKED",
          not any("ARM BLOCKED" in m for m in seen), f"{seen}")
    # The ceiling is built per call. Written back onto the shared config, a bad
    # run would clamp every future session, silently and for good.
    check("streak 3: the shared DecisionConfig was NOT mutated",
          loop.decision.cfg.max_portfolio_exposure_pct == 1.0,
          f"{loop.decision.cfg.max_portfolio_exposure_pct}")

    # (e) 2b, end to end: a SEEDED WINNER sits newest in the store. Unfiltered
    # it would end the streak and restore the full ceiling. This is the defect
    # found on the box (HPE:2026-08-20), driven through a real arm.
    b, db, loop, csv = _streak_setup(now, ceilings=RUNGS, losses=3, seeded=+2.0)
    seen = _capture(loop)
    armed, rej = loop.arm_today(csv)
    check("2b: a seeded WINNER does not restore the ceiling", len(armed) == 1,
          f"{len(armed)} {[r.reason for r in rej]}")
    check("2b: the skip is reported, never silent",
          any("manually seeded" in m for m in seen),
          f"{[m for m in seen if 'loss-streak' in m]}")
    check("2b: a seed skip is WARN (routine), not a push",
          all(classify(m) == "WARN" for m in seen if "manually seeded" in m),
          f"{[(classify(m), m) for m in seen if 'manually seeded' in m]}")

    # (f) 2b: a close with NEITHER marker. A code path nobody registered, or a
    # pruned log. Both change what the gate is doing, so this one pushes.
    b, db, loop, csv = _streak_setup(now, ceilings=RUNGS, losses=3, unknown=1)
    seen = _capture(loop)
    armed, rej = loop.arm_today(csv)
    check("2b: unknown provenance is reported",
          any("UNKNOWN provenance" in m for m in seen),
          f"{[m for m in seen if 'loss-streak' in m]}")
    check("2b: unknown provenance PUSHES (manual check)",
          any(classify(m) == "CRITICAL" for m in seen if "UNKNOWN provenance" in m),
          f"{[(classify(m), m) for m in seen if 'UNKNOWN' in m]}")

    # (g) FAIL CLOSED. The gate is on and the read throws: no streak, so the
    # gate cannot evaluate, so nothing arms. A survival gate is not exempt.
    b, db, loop, csv = _streak_setup(now, ceilings=RUNGS, losses=3)
    def _boom(*a, **k):
        raise RuntimeError("event store unreadable")
    db.recent_closed_r = _boom
    seen = _capture(loop)
    armed, rej = loop.arm_today(csv)
    check("read throws -> arms NOTHING (fail closed)", armed == [], f"{armed}")
    check("read throws -> no broker order", b.place_calls == 0, f"{b.place_calls}")
    check("read throws -> the cause is named",
          any("loss-streak read error" in m for m in seen), f"{seen}")
    check("read throws -> it PUSHES (a silent halt is worth a phone call)",
          any(classify(m) == "CRITICAL" for m in seen
              if "loss-streak read error" in m),
          f"{[(classify(m), m) for m in seen if 'read error' in m]}")
    check("read throws -> ARM BLOCKED, so it cannot be missed in the log",
          any("ARM BLOCKED" in m for m in seen), f"{seen}")


'''

ANCHOR_BLOCK_OLD = "def test_zz_all_checks_passed():"
ANCHOR_BLOCK_NEW = BLOCK + "def test_zz_all_checks_passed():"

ANCHOR_MAIN_OLD = "    test_e10_alert_severity_contract()\n"
ANCHOR_MAIN_NEW = ("    test_e10_alert_severity_contract()\n"
                   "    test_e11_progressive_exposure()\n")

EDITS = [
    (F_TEST, ANCHOR_BLOCK_OLD, ANCHOR_BLOCK_NEW),
    (F_TEST, ANCHOR_MAIN_OLD, ANCHOR_MAIN_NEW),
]


def _read(p):
    with open(p, encoding="utf-8") as fh:
        return fh.read()


def _write(p, text):
    compile(text, p, "exec")
    d = os.path.dirname(os.path.abspath(p))
    fd, tmp = tempfile.mkstemp(dir=d, suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as fh:
            fh.write(text)
        os.replace(tmp, p)
    except BaseException:
        if os.path.exists(tmp):
            os.unlink(tmp)
        raise


def _ascii_guard():
    try:
        BLOCK.encode("ascii")
    except UnicodeEncodeError as e:
        raise SystemExit(f"patch text is not pure ASCII: {e}")


def check_branch(force):
    try:
        r = subprocess.run(["git", "rev-parse", "--abbrev-ref", "HEAD"],
                           capture_output=True, text=True, timeout=5)
        b = r.stdout.strip() if r.returncode == 0 else ""
    except Exception:                      # noqa: BLE001
        b = ""
    if force or b == REPO_BRANCH:
        print(f"  branch = {b or '(unknown)'}")
        return
    raise SystemExit(f"REFUSING: on branch {b!r}, expected {REPO_BRANCH!r}. "
                     f"--force-branch to override.")


def apply(revert=False):
    if not os.path.isfile(F_TEST):
        raise SystemExit(f"missing {F_TEST} (run from the repo root)")
    if "def recent_closed_r" not in _read(os.path.join(
            "kistrader", "core", "engine_v2.py")):
        raise SystemExit("layer 2 is NOT applied. E11 tests it; apply a36c38a first.")
    if "on_skip" not in _read(os.path.join("kistrader", "core", "engine_v2.py")):
        raise SystemExit("layer 2b is NOT applied. E11 tests it; apply cf15e41 first.")

    src = _read(F_TEST)
    hits = sum(1 for _f, _o, new in EDITS if new in src)
    if not revert and hits == len(EDITS):
        raise SystemExit("already applied -- nothing to do")
    if not revert and hits:
        raise SystemExit(f"PARTIAL state: {hits}/{len(EDITS)}. Refusing.")
    if revert and hits == 0:
        raise SystemExit("not applied -- nothing to revert")
    if revert and hits != len(EDITS):
        raise SystemExit(f"PARTIAL state: {hits}/{len(EDITS)}. Refusing.")

    for _f, old, new in EDITS:
        src_from, src_to = (new, old) if revert else (old, new)
        n = src.count(src_from)
        if n != 1:
            raise SystemExit(f"anchor matched {n} times, expected 1:\n"
                             f"---\n{src_from[:120]}\n---")
        src = src.replace(src_from, src_to, 1)
    _write(F_TEST, src)
    print(f"  {'reverted' if revert else 'patched '} {F_TEST}  "
          f"({len(EDITS)} edit(s))")
    print("REVERTED." if revert else "APPLIED.")


class V:
    def __init__(self):
        self.p = self.f = 0

    def check(self, label, cond, detail=""):
        ok = bool(cond)
        self.p += ok
        self.f += (not ok)
        print(f"  {'PASS' if ok else 'FAIL'}  {label}"
              + (f"   {detail}" if detail and not ok else ""))

    def done(self):
        print(f"\n  {self.p}/{self.p + self.f} checks passed")
        return 0 if self.f == 0 else 1


def verify():
    _ascii_guard()
    v = V()
    src = _read(F_TEST)
    for i, (_f, _o, new) in enumerate(EDITS, 1):
        v.check(f"edit {i}/{len(EDITS)} present exactly once",
                src.count(new) == 1, f"count={src.count(new)}")
    v.check("sentinel present", src.count(SENTINEL) == 1)
    v.check("main() runs it", "    test_e11_progressive_exposure()\n" in src)
    v.check("declared before the terminal guard",
            src.index(SENTINEL) < src.index("def test_zz_all_checks_passed"))
    try:
        compile(src, F_TEST, "exec")
        v.check("compiles", True)
    except SyntaxError as e:
        v.check("compiles", False, str(e))
        return v.done()

    sys.path.insert(0, os.getcwd())
    sys.path.insert(0, os.path.join(os.getcwd(), "tests"))
    import test_pipeline_e2e as T

    n_pass, n_fail = len(T.PASS), len(T.FAIL)
    print("\n  --- running the block ---")
    T.test_e11_progressive_exposure()
    print("  --- end ---\n")
    new_pass = len(T.PASS) - n_pass
    v.check(f"the block contributes {N_NEW_CHECKS} checks",
            new_pass + (len(T.FAIL) - n_fail) == N_NEW_CHECKS,
            f"{new_pass + (len(T.FAIL) - n_fail)}")
    v.check("every one of them passes", len(T.FAIL) == n_fail,
            f"{T.FAIL[n_fail:]}")

    # ---- POSITIVE CONTROLS ----
    # A guard that fires on every run passes every static check. These two say
    # what would have to break for the block above to be worth anything.
    now = {"t": T.OPEN_UTC}
    from kistrader.entry.exposure_controller import (
        DEFAULT_LOSS_STREAK_CEILINGS, ExposureController, ExposureConfig,
        loss_streak_from)

    # 1. The ladder must come from the GATE. Swap in a controller that ignores
    #    the streak and the same fixture must arm 4 instead of 1 -- otherwise
    #    "1 armed" could be any other cap doing the limiting.
    b, db, loop, csv = T._streak_setup(now, ceilings=DEFAULT_LOSS_STREAK_CEILINGS,
                                       losses=3)
    loop.exposure = ExposureController(ExposureConfig())      # gate OFF
    T._capture(loop)
    armed_off, _r = loop.arm_today(csv)
    v.check("POSITIVE CONTROL the 1-armed result comes from the GATE",
            len(armed_off) == 4, f"{len(armed_off)}")

    # 2. Provenance must be what excludes the seed. Score the SAME store
    #    without the allowlist and the streak must collapse to 0.
    import json as _json
    b, db, loop, csv = T._streak_setup(now, ceilings=DEFAULT_LOSS_STREAK_CEILINGS,
                                       losses=3, seeded=+2.0)
    real = db.recent_closed_r()
    blind, seen_keys = [], set()
    for key, price, payload in db.conn.execute(
            "SELECT order_key, price, payload FROM position_events "
            "WHERE event_type LIKE 'CLOSED:%' AND payload IS NOT NULL "
            "ORDER BY id DESC"):
        if key in seen_keys:
            continue
        seen_keys.add(key)
        d = _json.loads(payload)
        risk = float(d.get("initial_risk_per_share") or 0.0)
        blind.append((float(price) - float(d["entry_price"])) / risk
                     if risk > 0 else float("nan"))
    v.check("POSITIVE CONTROL provenance is what drops the seed",
            len(real) == 3 and len(blind) == 4, f"real={len(real)} blind={len(blind)}")
    v.check("POSITIVE CONTROL without it the seed would CLEAR the streak",
            loss_streak_from(real) == 3 and loss_streak_from(blind) == 0,
            f"real={loss_streak_from(real)} blind={loss_streak_from(blind)}")
    db.conn.close()
    return v.done()


def main(argv=None):
    ap = argparse.ArgumentParser(description="E11 -- the timing half, in e2e")
    ap.add_argument("--verify", action="store_true")
    ap.add_argument("--revert", action="store_true")
    ap.add_argument("--force-branch", action="store_true")
    a = ap.parse_args(argv)
    _ascii_guard()
    if a.verify:
        return verify()
    check_branch(a.force_branch)
    apply(revert=a.revert)
    return 0


if __name__ == "__main__":
    sys.exit(main())
