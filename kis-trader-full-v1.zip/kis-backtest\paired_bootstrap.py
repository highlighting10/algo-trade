#!/usr/bin/env python3
r"""
paired_bootstrap.py -- the noise floor for SIZE-SENSITIVE metrics, and the
question of whether Phase B was adjudicated against the wrong one.

READ-ONLY. Runs no sweep, writes no file, changes nothing.
Run from the kis-backtest root:

    .\.venv\Scripts\python.exe paired_bootstrap.py                    # the CONTROL
    .\.venv\Scripts\python.exe paired_bootstrap.py --a thr_70 --b thr_75

-----------------------------------------------------------------------------
WHY THE EXISTING FLOOR CANNOT ADJUDICATE S1

`+/-0.19-0.20 R` was derived for `expectancy_R`, which `_summarize` documents as
*"the RUNNER leg's per-share R and ... position-size INVARIANT"*. An exposure
mechanism acts ENTIRELY through size. Adjudicating a graded exposure ceiling on
that metric asks a question the metric is built not to answer, and would return
a confident null no matter what the mechanism did.

So S1 needs a floor for `expectancy_R_weighted`, `total_return_pct` and
`max_drawdown_pct`. None exists.

-----------------------------------------------------------------------------
WHY "RUN A NULL ARM AND MEASURE THE SPREAD" IS THE WRONG INSTRUMENT

This backtest is DETERMINISTIC. A genuinely inert parameter produces a spread of
exactly zero, which is not a floor -- it is a tautology. The uncertainty being
estimated is not run-to-run variance; it is SAMPLING variability: would this
margin survive if the market had dealt a different but comparable hand?

That makes it a resampling problem, and it needs NO new backtest runs beyond the
two arms themselves.

-----------------------------------------------------------------------------
THE CLAIM THIS TOOL EXISTS TO TEST

Every Phase B comparison was PAIRED: two arms, identical bars, identical dates,
overlapping trades. The `+/-0.19 R` figure is an UNPAIRED standard error -- the
uncertainty of one configuration's estimate on its own. For two arms measured on
the same data, the SE of their DIFFERENCE is smaller, often far smaller, because
the shared market path cancels.

If that is what happened, the floor Phase B adjudicated against was too WIDE,
and "inside the noise floor" was sometimes the wrong verdict.

  * **S3 is safe either way** -- 0/16 cells with a monotone dose-response does
    not rest on the floor.
  * **S5 is safe** -- 8/8 dominance, also floor-independent.
  * **S4 is NOT safe.** It was closed as null on "best arm 4/8, every cell
    inside 1 SE". If that SE was unpaired, S4 may deserve re-adjudication.

This tool measures the ratio directly. It does not assume it.

-----------------------------------------------------------------------------
METHOD

  1. Run both arms at the frozen set, 5.0 bps, WORST intrabar bound -- the
     harness's own decision rule (`run_band`: "the WORST bound is the number a
     parameter choice is judged on").
  2. Slice each equity curve to `diag["stats_window"]`, the harness's own
     definition of the active window, so a flat cash prefix cannot dilute the
     resample.
  3. MOVING-BLOCK BOOTSTRAP over the calendar. Draw block starts, concatenate to
     the original length, and apply THE SAME DRAW TO BOTH ARMS. That is what
     makes the difference paired.
       - returns: compound the resampled daily returns -> total_return, max_DD
       - trades:  take trades whose EXIT DATE falls in the drawn blocks, with
                  multiplicity -> expectancy_R, expectancy_R_weighted
  4. Report, for each metric: the paired difference distribution, each arm's own
     (unpaired) distribution, and the RATIO of the naive unpaired SE
     `sqrt(sdA^2 + sdB^2)` to the paired SE. That ratio is the answer.

Metrics are recomputed here UNROUNDED. `_summarize` rounds `expectancy_R` to
3 dp, which is coarse enough to dominate a bootstrap spread. `_weighted_r` is
imported rather than reimplemented so the weighted definition cannot drift.

-----------------------------------------------------------------------------
POSITIVE CONTROL -- RUN THIS FIRST, IT IS THE DEFAULT

`exp_blank` vs `exp_ceiling` produced BYTE-IDENTICAL trade lists in T2
(`verify_QT2_ledger.py`, 2026-08-30). A correct paired bootstrap MUST therefore
return a difference of exactly 0.0 with exactly 0.0 spread on every metric and
every draw. The tool asserts this and refuses to report anything else.

If that assertion fails, the pairing is broken -- the two arms are being drawn
against different blocks -- and every number this tool produces is worthless.

-----------------------------------------------------------------------------
WHAT THIS DOES NOT DO

  * It does not make the survivorship-biased absolute returns real. The band it
    produces is the uncertainty of a comparison WITHIN this harness.
  * A block bootstrap destroys autocorrelation beyond the block length, so
    max-drawdown uncertainty is understated for drawdowns longer than one block.
    Reported alongside the result, not buried: try --block 42 and --block 63 and
    say whether the answer moves.
  * `--seed` changes the numbers. It is printed with every result. A run that
    does not state its seed is not a result.

Docstring is raw: names `scripts\06_sweep.py`, and `\06` is a valid octal escape
(patch N's bug).
"""
from __future__ import annotations

import argparse
import pathlib
import pickle
import sys
from dataclasses import replace

import numpy as np
import pandas as pd

from minervini_backtest import (BacktestConfig, DecisionConfig, load_bars,
                                load_sector_map, run, _weighted_r)

SLIP = 5.0

CELLS = {
    # the CONTROL: identical by construction (T2, 2026-08-30)
    "exp_blank":     {"exposure_policy": "constant"},
    "exp_ceiling":   {"exposure_policy": "regime_ceiling",
                      "exposure_risk_off_pct": 0.0},
    # the pair the threshold sweep could never separate
    "thr_70":        {"vcp_threshold": 70.0},
    "thr_75":        {"vcp_threshold": 75.0},
    # S3's pair -- a KNOWN-LARGE difference, the negative control
    "fb_off":        {"fb_trigger": None},
    "fb_two_closes": {"fb_trigger": "two_closes"},
    # --- E10 Phase 1 (2026-09-19) --- the GRADED exposure arms, the ones
    # this tool was written for and the only ones it could not address.
    # Same field shape as scripts/06_sweep.py's "exposure" group, so the
    # bootstrap and the sweep measure the same arms by the same names.
    # exp_000 is NOT added: it is byte-identical to "exp_ceiling" above
    # (regime_ceiling, risk_off 0.0), which is also half the positive
    # control. Use --b exp_ceiling when you mean exp_000.
    # NOTE: every regime_ceiling arm REQUIRES regime_ma (engine line 442
    # refuses it with regime_ma=None). base sets regime_ma=20, which is
    # Rev 3's reproduction, NOT production (regime_ma=None since PATCH F3).
    "exp_100":       {"exposure_policy": "regime_ceiling",
                      "exposure_risk_off_pct": 1.00},
    "exp_075":       {"exposure_policy": "regime_ceiling",
                      "exposure_risk_off_pct": 0.75},
    "exp_050":       {"exposure_policy": "regime_ceiling",
                      "exposure_risk_off_pct": 0.50},
    "exp_025":       {"exposure_policy": "regime_ceiling",
                      "exposure_risk_off_pct": 0.25},
    # --- end E10 Phase 1 ---
}

METRICS = ("expectancy_R", "expectancy_R_weighted",
           "total_return_pct", "max_drawdown_pct")


def _metrics(eq_vals: np.ndarray, trades: list) -> dict:
    """Unrounded, and the weighted definition is imported, not copied."""
    out = {}
    if len(eq_vals) > 1 and eq_vals[0] > 0:
        out["total_return_pct"] = (eq_vals[-1] / eq_vals[0] - 1.0) * 100.0
        peak = np.maximum.accumulate(eq_vals)
        out["max_drawdown_pct"] = float((eq_vals / peak - 1.0).min()) * 100.0
    else:
        out["total_return_pct"] = float("nan")
        out["max_drawdown_pct"] = float("nan")
    if trades:
        out["expectancy_R"] = float(np.mean([t.r_at_exit for t in trades]))
        out["expectancy_R_weighted"] = float(np.mean([_weighted_r(t) for t in trades]))
    else:
        out["expectancy_R"] = float("nan")
        out["expectancy_R_weighted"] = float("nan")
    return out


def _arm(prices, signals, base, name):
    cfg = replace(base, slippage_bps=SLIP, ambiguity_mode="worst", **CELLS[name])
    eq, trades, stats, _drops, diag = run(prices, signals, cfg)
    lo, hi = diag["stats_window"].split("..")
    eq = eq.dropna()
    eq = eq.loc[(eq.index >= pd.Timestamp(lo)) & (eq.index <= pd.Timestamp(hi))]
    by_date = {}
    for t in trades:
        by_date.setdefault(pd.Timestamp(t.exit_date).normalize(), []).append(t)
    print(f"[bs] {name:14s} trades={stats.get('num_trades'):4d}  "
          f"E(R)={stats.get('expectancy_R')}  "
          f"E(Rw)={stats.get('expectancy_R_weighted')}  "
          f"ret={stats.get('total_return_pct')}%  "
          f"DD={stats.get('max_drawdown_pct')}%  "
          f"window={diag['stats_window']}")
    return {"eq": eq, "trades": trades, "by_date": by_date, "stats": stats}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--a", default="exp_blank", choices=sorted(CELLS))
    ap.add_argument("--b", default="exp_ceiling", choices=sorted(CELLS))
    ap.add_argument("--block", type=int, default=21,
                    help="block length in trading days (default 21 ~ 1 month)")
    ap.add_argument("--draws", type=int, default=2000)
    ap.add_argument("--seed", type=int, default=12345,
                    help="CHANGES THE NUMBERS. Printed with every result.")
    args = ap.parse_args()
    if args.a == args.b:
        raise SystemExit("[bs] --a and --b are the same cell; nothing to compare.")

    bars = load_bars()                       # patch S: refuses on a wrong cwd
    prices = {t: d for t, d in bars.items() if t != "^GSPC"}
    with open("data/signals_daily.pkl", "rb") as fh:
        signals = pickle.load(fh)["signals"]
    bench = bars.get("^GSPC")
    if bench is None:
        raise SystemExit("[bs] no ^GSPC bars -- the frozen set needs regime_ma=20.")

    base = BacktestConfig(
        rank_mode="vcp_only", equity_mode="compounding",
        entry_mode="pivot_limit", ambiguity_mode="worst",
        vcp_threshold=75.0, regime_ma=20, stall_day=252,
        sector_map=load_sector_map("data/sectors.csv"),
        decision=DecisionConfig(risk_per_trade_pct=0.0085,
                                max_position_pct=0.25, sector_cap=2),
        benchmark_close=bench["Close"])

    print(f"[bs] frozen set, {SLIP} bps, worst bound | block={args.block} "
          f"draws={args.draws} seed={args.seed}")
    A = _arm(prices, signals, base, args.a)
    B = _arm(prices, signals, base, args.b)

    if not A["eq"].index.equals(B["eq"].index):
        raise SystemExit("[bs] the two arms have DIFFERENT stats windows. The "
                         "pairing would compare different calendars; refusing.")
    idx = A["eq"].index
    rA = A["eq"].pct_change().fillna(0.0).to_numpy()
    rB = B["eq"].pct_change().fillna(0.0).to_numpy()
    dates = idx.normalize().to_numpy()
    n = len(idx)
    L = max(1, args.block)
    if n <= L:
        raise SystemExit(f"[bs] window is {n} days, block is {L}. Too short.")
    nblocks = int(np.ceil(n / L))

    identical = ([ (t.ticker, t.entry_date, t.exit_date, t.shares, t.exit_price)
                   for t in A["trades"] ]
                 == [ (t.ticker, t.entry_date, t.exit_date, t.shares, t.exit_price)
                      for t in B["trades"] ]) and np.allclose(rA, rB)
    if identical:
        print("[bs] the two arms are IDENTICAL -- running as the POSITIVE CONTROL: "
              "every paired difference must be exactly 0.0")

    rng = np.random.default_rng(args.seed)
    startsmax = n - L
    dA = {m: [] for m in METRICS}
    dB = {m: [] for m in METRICS}
    dd = {m: [] for m in METRICS}
    for _ in range(args.draws):
        starts = rng.integers(0, startsmax + 1, size=nblocks)
        pos = np.concatenate([np.arange(s, s + L) for s in starts])[:n]
        eqA = np.cumprod(1.0 + rA[pos]) * 100.0
        eqB = np.cumprod(1.0 + rB[pos]) * 100.0
        drawn = dates[pos]
        tA, tB = [], []
        for d in drawn:
            key = pd.Timestamp(d)
            if key in A["by_date"]:
                tA.extend(A["by_date"][key])
            if key in B["by_date"]:
                tB.extend(B["by_date"][key])
        mA, mB = _metrics(eqA, tA), _metrics(eqB, tB)
        for m in METRICS:
            dA[m].append(mA[m])
            dB[m].append(mB[m])
            dd[m].append(mB[m] - mA[m])

    point = {m: _metrics(np.cumprod(1.0 + rB) * 100.0, B["trades"])[m]
                - _metrics(np.cumprod(1.0 + rA) * 100.0, A["trades"])[m]
             for m in METRICS}

    print()
    print(f"[bs] paired difference  ({args.b} - {args.a})")
    # THREE DIFFERENT QUANTITIES. Labelling sqrt(varA+varB) as "unpaired SE"
    # invited exactly one error on 2026-08-30: it was read as a SINGLE-ARM SE
    # and compared against the documented +/-0.19-0.20 R floor, which IS a
    # single-arm SE. They differ by sqrt(2). Each is now named and printed.
    print(f"[bs] {'metric':22s} {'point':>9s} {'pairedSE':>9s} "
          f"{'sd(A)':>9s} {'sd(B)':>9s} {'unpairD':>9s} {'ratio':>6s}"
          f"  {'5%..95% paired':>22s}")
    failures = []
    for m in METRICS:
        d = np.asarray(dd[m], dtype=float)
        d = d[np.isfinite(d)]
        a = np.asarray(dA[m], dtype=float); a = a[np.isfinite(a)]
        b = np.asarray(dB[m], dtype=float); b = b[np.isfinite(b)]
        if not len(d):
            print(f"[bs] {m:22s}  all draws undefined (too few trades per block?)")
            continue
        se_p = float(d.std(ddof=1)) if len(d) > 1 else 0.0
        sd_a = float(a.std(ddof=1)) if len(a) > 1 else 0.0
        sd_b = float(b.std(ddof=1)) if len(b) > 1 else 0.0
        se_u = float(np.sqrt(sd_a ** 2 + sd_b ** 2))
        ratio = (se_u / se_p) if se_p > 0 else float("inf")
        lo, hi = np.percentile(d, [5, 95])
        print(f"[bs] {m:22s} {point[m]:+9.4f} {se_p:9.4f} "
              f"{sd_a:9.4f} {sd_b:9.4f} {se_u:9.4f} {ratio:6.1f}"
              f"  {lo:+10.4f}..{hi:+9.4f}")
        if identical and (se_p != 0.0 or point[m] != 0.0):
            failures.append(f"{m}: point={point[m]} paired SE={se_p}, both must be 0")

    if identical:
        print()
        if failures:
            print("[bs] CONTROL FAILED -- the pairing is broken and every number")
            print("[bs] above is worthless:")
            for f in failures:
                print("[bs]   " + f)
            return 1
        print("[bs] CONTROL PASSED: identical arms -> exactly zero difference and")
        print("[bs] zero spread on every metric. The pairing is sound.")
        print("[bs] Now run a real pair, e.g. --a thr_70 --b thr_75")
        return 0

    # --- E10 option (d): SURVIVAL AS A FREQUENCY (2026-09-19) --------------
    # max_drawdown_pct is ONE number per path, measured +/-4.0-4.2 pp paired --
    # which is why exp_100 vs exp_000 sat at 0.5 SE and could not be read
    # (RESULT_20260919_E10_phase1). Minervini states the reason for progressive
    # exposure is SURVIVAL, so ask the survival question directly: across the
    # drawn paths, how OFTEN is a drawdown breached? A proportion is a better
    # behaved estimator than the tail value it summarises.
    #
    # It is only better if the arms DISAGREE on some paths. Paths where both
    # breach, or neither does, carry exactly zero information about the
    # difference -- so `discord` is printed, and it is the number that decides
    # whether this estimator has anything in it at all.
    #
    # Same draws, same pairing, no new machinery.
    ddA = np.asarray(dA["max_drawdown_pct"], dtype=float)
    ddB = np.asarray(dB["max_drawdown_pct"], dtype=float)
    _ok = np.isfinite(ddA) & np.isfinite(ddB)
    ddA, ddB = ddA[_ok], ddB[_ok]
    _N = len(ddA)
    _lblA, _lblB = "P(%s)" % args.a, "P(%s)" % args.b
    print()
    print("[bs] SURVIVAL: breach frequency over %d paired paths  (%s - %s)"
          % (_N, args.b, args.a))
    print("[bs] %10s %13s %13s %9s %6s %6s %8s %9s %7s"
          % ("threshold", _lblA, _lblB, "diff pp", "n10", "n01",
             "discord", "mcSE pp", "mc_z"))
    for _thr in (-10.0, -15.0, -20.0, -25.0, -30.0, -35.0):
        _bA, _bB = ddA <= _thr, ddB <= _thr
        _pA, _pB = float(_bA.mean()), float(_bB.mean())
        _n10 = int(np.sum(_bB & ~_bA))
        _n01 = int(np.sum(_bA & ~_bB))
        _disc = _n10 + _n01
        _se = (np.sqrt(_disc) / _N) if _disc else 0.0
        _z = ((_pB - _pA) / _se) if _se > 0 else float("nan")
        print("[bs] %+10.1f %13.4f %13.4f %+9.2f %6d %6d %8.4f %9.3f %7.1f"
              % (_thr, _pA, _pB, (_pB - _pA) * 100.0, _n10, _n01,
                 _disc / _N if _N else 0.0, _se * 100.0, _z))
    print("[bs] mc_z IS NOT A SIGNIFICANCE TEST -- FALSIFIED 2026-09-19.")
    print("[bs]   mcSE = sqrt(discord)/N is MONTE CARLO precision. discord grows")
    print("[bs]   with N, so mcSE falls as 1/sqrt(N) and mc_z RISES as sqrt(N).")
    print("[bs]   Measured: 2000 -> 8000 draws DOUBLED every mc_z (1.77-2.03x,")
    print("[bs]   predicted 2.00) while every diff pp held and pairedSE above did")
    print("[bs]   NOT move. More draws add no information -- they resample the")
    print("[bs]   same ~200 trades. McNemar assumes INDEPENDENT subjects; these")
    print("[bs]   are resamples of ONE history.")
    print("[bs]   Use mc_z for one thing only: confirming the draw count is high")
    print("[bs]   enough that diff pp is stable. NEVER quote it as evidence.")
    print("[bs] READ discord: concordant paths -- both arms breach, or neither --")
    print("[bs]   contribute exactly nothing to the difference. Small discord")
    print("[bs]   means the estimate rests on a handful of paths, whatever mc_z")
    print("[bs]   prints (see the -10% row, discord ~7).")
    print("[bs] THE UNCERTAINTY OF diff pp ON ANOTHER HISTORY IS UNMEASURED HERE.")
    print("[bs]   Sub-period dominance is the route, and it is floor-independent.")
    print("[bs]   See RESULT_20260919_E10_phase1d_breach_frequency_works_the_")
    print("[bs]   test_does_not.")
    # --- end E10 option (d) ------------------------------------------------

    print()
    print("[bs] THE THREE COLUMNS ARE THREE DIFFERENT QUANTITIES")
    print("[bs]   sd(A), sd(B)  each arm's OWN standard error. This is what the")
    print("[bs]                 documented +/-0.19-0.20 R floor measures, and the")
    print("[bs]                 bootstrap reproduces it: 0.193 on expectancy_R.")
    print("[bs]   unpairD       sqrt(sdA^2 + sdB^2): the SE of a difference between")
    print("[bs]                 two INDEPENDENT estimates. = sqrt(2) x sd when the")
    print("[bs]                 arms are alike. NOT a single-arm SE.")
    print("[bs]   pairedSE      the SE of the difference when both arms are drawn")
    print("[bs]                 against the SAME blocks. This is the correct floor")
    print("[bs]                 for comparing two arms on the same data.")
    print("[bs]   ratio = unpairD / pairedSE.")
    print("[bs] JUDGE A MARGIN AGAINST THE PAIRED 5-95% BAND, not against a")
    print("[bs] single-arm SE. The inherited +/-0.19-0.20 is a single-arm figure")
    print("[bs] and is ~1.25x too WIDE when used on a difference -- conservative,")
    print("[bs] but it is not the right number.")
    print("[bs] CHECK BEFORE QUOTING: re-run with --block 42 and --block 63.")
    print("[bs]   A block bootstrap understates drawdown uncertainty for")
    print("[bs]   drawdowns longer than one block. If the answer moves with the")
    print("[bs]   block length, report the range, not one number.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
