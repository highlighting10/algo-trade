from kistrader.config import Config
from kistrader.entry.entry_manager import KISBrokerWithEntry
from kistrader.entry.screen_contract import Candidate, write_candidates

c = Config.from_env()
b = KISBrokerWithEntry(c.app_key, c.app_secret, c.cano, acnt_prdt_cd=c.acnt_prdt_cd, is_mock=True)

TICKER, EXCH, DATE = "NVDA", "NAS", "2026-07-06"
last  = b.get_quote(TICKER, EXCH)["last"]
pivot = round(last * 1.002, 2)          # 피벗을 시세 살짝 아래로 → 돌파 상태로 간주되어 체결

cand = Candidate(
    ticker=TICKER, exchange=EXCH, rs_proxy=90, stage2_score=70, vcp_score=88,
    pivot=pivot, base_high=round(pivot, 2), base_low=round(pivot*0.95, 2),
    depth_pct=0.10, last_close=round(last, 2), atr=round(last*0.02, 2),
    trade_signal=True, session_date=DATE, name="Apple", close_known=True)
print("작성:", write_candidates("candidates.csv", [cand]), "건  pivot=", pivot, " last=", last)