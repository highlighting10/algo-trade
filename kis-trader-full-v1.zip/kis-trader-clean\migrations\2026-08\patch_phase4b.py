#!/usr/bin/env python3
"""
patch_phase4b.py -- orphans are handled MANUALLY, with a rate-limited alert.

THE DECISION
Recovering a stop for an orphan needs the base the breakout came from, and that
base no longer exists on today's chart. Every automated route to it -- a
doctrinal entry x 0.90, a fresh VCP read, a reconstructed as-of-entry-date base --
either fabricates initial_risk_per_share (which the +3R partial, every
r_multiple() log line and the stall floor all compute from) or needs a fill date
the broker does not return. Rather than build a second, weaker strategy inside
error-recovery code, the system does one thing well: it COUNTS the orphan and
tells the operator.

WHAT THIS ADDS
  * one alert per orphan per ORPHAN_ALERT_COOLDOWN_SECS (6h), naming the ticker,
    quantity, last price, its exposure contribution, and the resolved exchange;
  * a ready seed command with the two unknowable fields left blank, and the
    EXCHANGE filled in -- because "F seeded as NAS instead of NYS caused a silent
    position skip with no error" is already in this project's history and a
    paste-ready command with the wrong default would recreate it;
  * cooldown entries pruned when the holding disappears, so an orphan that comes
    back after being closed alerts immediately rather than waiting out a stale
    timer.

WHAT IT DOES NOT ADD
No suggested stop. No VCP call. No adoption into management. The alert states
plainly that the position has no stop, no +3R partial and no trail, so nothing
about it can be mistaken for managed.

THE COOLDOWN IS IN MEMORY
A process restart re-alerts. The notifier's own dedup window limits the damage,
and a restart loop is a bigger problem than a duplicate page. Persisting it is
possible if the noise ever justifies the extra state.

VERIFY BEFORE TRUSTING THE PAGE: ORPHAN_ALERT_LEVEL is the token this message
carries so the notifier routes it as a phone push rather than a log line. It is
set to "CRITICAL" on the strength of the notifier's documented behaviour
(CRITICAL -> Telegram push, WARN/INFO -> rotating log only). Confirm it against
notifier.py -- if the routing keys on something else, this alert reaches the log
and nothing else, which is the exact silent-failure shape this project keeps
hunting.

Anchors are asserted; edits are applied bottom-up.

Usage:  python patch_phase4b.py <repo-root>
"""
from __future__ import annotations

import os
import sys

OLD_DETAIL_SIG = '''    def _orphan_notional(self, ticker: str, qty: int):
        """Value a broker holding we have no local record for.
'''

NEW_DETAIL_SIG = '''    def _orphan_detail(self, ticker: str, qty: int):
        """Value a broker holding we have no local record for.

        Returns (notional, exchange, last_price) or None. The exchange is
        returned as well as used, so the alert can put the RIGHT code into the
        seed command instead of letting the --exchange NAS default silently
        mis-seed a NYSE name.
'''

OLD_CALLER = '''                n = self._orphan_notional(t, qty)
                if n is None:
                    unpriced.append(t)
                else:
                    open_notional += n
'''

NEW_CALLER = '''                det = self._orphan_detail(t, qty)
                if det is None:
                    unpriced.append(t)
                else:
                    open_notional += det[0]
                    orphans.append((t, qty) + det)
'''

OLD_INIT = "        open_notional, unpriced = 0.0, []\n"
NEW_INIT = "        open_notional, unpriced, orphans = 0.0, [], []\n"

OLD_UNPRICED = '''        if unpriced:
            self.alert("ARM BLOCKED: broker holds " + ", ".join(sorted(unpriced)) +
'''

NEW_UNPRICED = '''        # Report the orphans we COULD price before deciding whether to refuse:
        # an unpriceable one must not hide the others.
        self._report_orphans(orphans)
        if unpriced:
            self.alert("ARM BLOCKED: broker holds " + ", ".join(sorted(unpriced)) +
'''

REPORT_FN = '''    def _report_orphans(self, orphans):
        """One alert per orphan per ORPHAN_ALERT_COOLDOWN_SECS.

        An orphan is resolved by a human, and a human does not need telling
        every session. Entries are pruned once the holding is gone, so a name
        that reappears after being closed alerts immediately instead of waiting
        out a stale timer.

        In memory only: a restart re-alerts. The notifier's own dedup window
        limits that, and a restart loop is a bigger problem than a repeat page."""
        now = time.time()
        still_held = {t for t, *_ in orphans}
        for t in list(self._orphan_alerted):
            if t not in still_held:
                del self._orphan_alerted[t]
        for t, qty, notional, ex, last in orphans:
            if now - self._orphan_alerted.get(t, 0.0) < ORPHAN_ALERT_COOLDOWN_SECS:
                continue
            self._orphan_alerted[t] = now
            self.alert(
                f"{ORPHAN_ALERT_LEVEL} ORPHAN {t} — {qty} sh held at the broker "
                f"with NO local record (last ${last:,.2f}, ~${notional:,.0f}). "
                f"Counted against the exposure ceiling; NOT managed: no stop, no "
                f"+3R partial, no trail. Handle it manually — seed it to manage, "
                f"or close it in the broker app: "
                f"kistrader seed --ticker {t} --shares {qty} --entry <FILL> "
                f"--stop <FROM CHART> --exchange {ex} --confirm "
                f"(repeats every {ORPHAN_ALERT_COOLDOWN_SECS // 3600}h until it is "
                f"seeded or gone)")

'''

E9 = '''def test_e9_orphan_alert_is_rate_limited():
    """§orphans are handled MANUALLY. The system counts them and tells the
    operator; it never invents a stop. One page per orphan per 6h."""
    print("E9 orphan alert: once per orphan per cooldown, with the right exchange")
    now = {"t": OPEN_UTC}

    b, db, path, mon, entry, dec, loop, fclk = _assemble(now)
    b._holdings = {"ZZZ": 500}
    b._price["ZZZ"] = 198.40
    seen = _capture(loop)

    loop._account_state()
    hits = [m for m in seen if "ORPHAN ZZZ" in m]
    check("first sighting alerts exactly once", len(hits) == 1, f"{len(hits)}")
    if hits:
        m = hits[0]
        check("names the quantity and the last price", "500 sh" in m and "198.40" in m, m)
        check("states plainly that it is NOT managed",
              "NOT managed" in m and "no stop" in m, m)
        check("carries the seed command with an explicit --exchange",
              "kistrader seed --ticker ZZZ" in m and "--exchange" in m, m)
        check("leaves the two unknowable fields blank",
              "<FILL>" in m and "<FROM CHART>" in m, m)
        check("routes as a phone push, not a log line", m.startswith(ORPHAN_ALERT_LEVEL), m)

    # a second look in the same session must NOT re-page
    seen.clear()
    loop._account_state()
    check("second look inside the cooldown does not re-alert",
          not [m for m in seen if "ORPHAN ZZZ" in m], f"{seen}")

    # ... but it does once the cooldown has elapsed
    loop._orphan_alerted["ZZZ"] -= (ORPHAN_ALERT_COOLDOWN_SECS + 1)
    seen.clear()
    loop._account_state()
    check("alerts again after the cooldown elapses",
          len([m for m in seen if "ORPHAN ZZZ" in m]) == 1, f"{seen}")

    # two orphans are tracked independently
    b._holdings = {"ZZZ": 500, "QQQ": 10}
    b._price["QQQ"] = 50.0
    seen.clear()
    loop._account_state()
    check("a second orphan alerts on its own schedule",
          [m for m in seen if "ORPHAN QQQ" in m] and
          not [m for m in seen if "ORPHAN ZZZ" in m], f"{seen}")

    # once it is gone the timer is dropped, so a REAPPEARING orphan pages at once
    b._holdings = {}
    loop._account_state()
    check("cooldown entries are pruned when the holding disappears",
          loop._orphan_alerted == {}, f"{loop._orphan_alerted}")
    b._holdings = {"ZZZ": 500}
    seen.clear()
    loop._account_state()
    check("a reappearing orphan alerts immediately, not after the old timer",
          len([m for m in seen if "ORPHAN ZZZ" in m]) == 1, f"{seen}")

    # a SEEDED position is not an orphan and must never page
    b, db, path, mon, entry, dec, loop, fclk = _assemble(now)
    b._holdings = {"MU": 10}
    loop._positions.append(Position(
        ticker="MU", state=PositionState.FILLED, shares=10, entry_price=50.0,
        stop_loss_price=45.0, initial_risk_per_share=5.0, exchange="NAS",
        order_key="MU:e9"))
    seen = _capture(loop)
    loop._account_state()
    check("a position with a local record is not an orphan",
          not [m for m in seen if "ORPHAN" in m], f"{seen}")


'''


def edit(text, old, new, label):
    n = text.count(old)
    if n != 1:
        raise SystemExit(f"REFUSING: anchor for {label} matched {n} times, expected 1")
    print(f"  ok  {label}")
    return text.replace(old, new)


def read(p):
    with open(p, encoding="utf-8") as f:
        return f.read()


def write(p, s):
    with open(p, "w", encoding="utf-8", newline="") as f:
        f.write(s)


def main(root):
    pl = os.path.join(root, "kistrader", "entry", "pipeline.py")
    te = os.path.join(root, "tests", "test_pipeline_e2e.py")
    for p in (pl, te):
        if not os.path.isfile(p):
            raise SystemExit(f"REFUSING: not found: {p}")
    s, t = read(pl), read(te)
    if "_orphan_notional" not in s:
        raise SystemExit("REFUSING: Phase 4 has not been applied.")
    if "_report_orphans" in s or "test_e9_orphan_alert_is_rate_limited" in t:
        raise SystemExit("REFUSING: Phase 4b appears to be applied already.")

    print(f"pipeline.py  ({pl})")
    s = edit(s, OLD_UNPRICED, NEW_UNPRICED, "report priceable orphans before refusing")
    s = edit(s, OLD_CALLER, NEW_CALLER, "collect orphan detail for the alert")
    s = edit(s, OLD_INIT, NEW_INIT, "_account_state: collect orphans")
    s = edit(s, OLD_DETAIL_SIG, NEW_DETAIL_SIG,
             "_orphan_notional -> _orphan_detail (also returns exchange + last)")
    s = edit(s, "        return qty * last if last > 0 else None\n",
             "        return (qty * last, ex, last) if last > 0 else None\n",
             "_orphan_detail: return the tuple")
    s = edit(s, "    def _orphan_detail(self, ticker: str, qty: int):\n",
             REPORT_FN + "    def _orphan_detail(self, ticker: str, qty: int):\n",
             "add _report_orphans")
    s = edit(s, "        self.exposure = exposure or ExposureController()\n",
             "        self.exposure = exposure or ExposureController()\n"
             "        self._orphan_alerted = {}    # ticker -> last alert time (see\n"
             "                                     # _report_orphans; in memory by design)\n",
             "PipelineLoop: per-orphan alert timers")
    s = edit(s, "from datetime import datetime, timezone\n",
             "import time\nfrom datetime import datetime, timezone\n",
             "import time")
    s = edit(s, "from typing import Callable, Optional\n",
             "from typing import Callable, Optional\n"
             "\n"
             "# One page per orphan per this window. An orphan is resolved by a human,\n"
             "# and a human does not need telling every session.\n"
             "ORPHAN_ALERT_COOLDOWN_SECS = 6 * 3600\n"
             "# The token the notifier routes on. CRITICAL -> phone push; WARN/INFO ->\n"
             "# rotating log only. If this does not match notifier.py's rule the alert\n"
             "# reaches the log and nothing else.\n"
             'ORPHAN_ALERT_LEVEL = "CRITICAL"\n',
             "orphan alert constants")
    write(pl, s)

    print(f"test_pipeline_e2e.py  ({te})")
    t = edit(t, "    test_e8_exposure_from_broker_truth()\n",
             "    test_e8_exposure_from_broker_truth()\n"
             "    test_e9_orphan_alert_is_rate_limited()\n",
             "register test_e9 in main()")
    t = edit(t, "def test_zz_all_checks_passed():", E9 + "def test_zz_all_checks_passed():",
             "insert test_e9_orphan_alert_is_rate_limited")
    t = edit(t, "from dataclasses import replace\n",
             "from dataclasses import replace\n"
             "from kistrader.entry.pipeline import (ORPHAN_ALERT_COOLDOWN_SECS,\n"
             "                                      ORPHAN_ALERT_LEVEL)\n",
             "e2e: import the orphan alert constants")
    write(te, t)
    print("\nPHASE 4b APPLIED. Orphans: counted, reported every 6h, never managed.")
    return 0


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("usage: python patch_phase4b.py <repo-root>")
    sys.exit(main(sys.argv[1]))
