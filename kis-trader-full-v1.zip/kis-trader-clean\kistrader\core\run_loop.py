#!/usr/bin/env python3
"""
Run loop + US session scheduler
===============================

The motor. The ExecutionMonitor has all the callbacks (on_tick / on_close /
on_session_open / advance_trading_day / recover / watchdog) but nothing *calls* them.
This owns the live Position list and drives those callbacks on a US-market schedule by
REST-polling quotes — the "REST-floor" design, with the WebSocket left as a future
latency accelerant.

Scope: forward-testing the EXIT engine against a MANUALLY-seeded position (buy a name
in the mock account, hand the engine that Position). Entry/decision-engine is separate.

Session clock is self-contained (no tzdata/market-calendar dependency): US/Eastern DST
is computed from the fixed federal rule, plus a hardcoded NYSE holiday set. Swap in
pandas_market_calendars later if you want half-days and multi-year coverage.

Providers (injected): ema_provider(ticker)->float and close_provider(ticker)->float feed
on_close (stall-exit + EMA-trail). Without them the loop still runs intraday stop/partial;
on_close is skipped with a one-time alert.
"""
from __future__ import annotations
import time
from datetime import datetime, timezone, timedelta
from typing import Optional, Callable

# NYSE holidays 2026 (regular full closures). Half-days not modeled.
HOLIDAYS_2026 = {
    "2026-01-01",  # New Year's Day
    "2026-01-19",  # MLK Jr. Day
    "2026-02-16",  # Washington's Birthday
    "2026-04-03",  # Good Friday
    "2026-05-25",  # Memorial Day
    "2026-06-19",  # Juneteenth
    "2026-07-03",  # Independence Day (observed; Jul 4 is a Saturday)
    "2026-09-07",  # Labor Day
    "2026-11-26",  # Thanksgiving
    "2026-12-25",  # Christmas
}


def _nth_weekday(year, month, weekday, n):
    """Date of the n-th `weekday` (Mon=0..Sun=6) in year/month."""
    d = datetime(year, month, 1)
    offset = (weekday - d.weekday()) % 7
    return d + timedelta(days=offset + 7 * (n - 1))


def _eastern_offset_hours(dt_utc: datetime) -> int:
    """US/Eastern UTC offset for an instant: EDT(-4) or EST(-5), via the federal rule
    (DST 2nd Sun Mar 02:00 -> 1st Sun Nov 02:00, boundaries expressed in UTC)."""
    y = dt_utc.year
    dst_start = _nth_weekday(y, 3, 6, 2).replace(hour=7, tzinfo=timezone.utc)   # 02:00 EST = 07:00 UTC
    dst_end = _nth_weekday(y, 11, 6, 1).replace(hour=6, tzinfo=timezone.utc)    # 02:00 EDT = 06:00 UTC
    return -4 if dst_start <= dt_utc < dst_end else -5


class USSessionClock:
    OPEN_H, OPEN_M = 9, 30
    CLOSE_H, CLOSE_M = 16, 0

    def __init__(self, now_fn: Optional[Callable[[], datetime]] = None, holidays=HOLIDAYS_2026):
        self._now = now_fn or (lambda: datetime.now(timezone.utc))
        self.holidays = set(holidays)

    def now_et(self) -> datetime:
        u = self._now()
        if u.tzinfo is None:
            u = u.replace(tzinfo=timezone.utc)
        return u + timedelta(hours=_eastern_offset_hours(u))

    def session_date(self, et: Optional[datetime] = None) -> str:
        return (et or self.now_et()).strftime("%Y-%m-%d")

    def is_trading_day(self, et: Optional[datetime] = None) -> bool:
        et = et or self.now_et()
        return et.weekday() < 5 and et.strftime("%Y-%m-%d") not in self.holidays

    def is_open(self, et: Optional[datetime] = None) -> bool:
        et = et or self.now_et()
        if not self.is_trading_day(et):
            return False
        mins = et.hour * 60 + et.minute
        return self.OPEN_H * 60 + self.OPEN_M <= mins < self.CLOSE_H * 60 + self.CLOSE_M

    def phase(self, et: Optional[datetime] = None) -> str:
        return "OPEN" if self.is_open(et) else "CLOSED"


class RunLoop:
    def __init__(self, monitor, broker, clock: Optional[USSessionClock] = None,
                 quote_poll_secs=7, open_sleep_secs=None, closed_sleep_secs=30,
                 ema_provider=None, close_provider=None, alert=None,
                 close_log=None):
        self.mon = monitor
        self.broker = broker
        # --- PATCH AA (I5) --- observation sink, default OFF. Nothing in the
        # exit path reads it; see kistrader/entry/close_log.py.
        self.close_log = close_log
        self.clock = clock or USSessionClock()
        self.quote_poll_secs = quote_poll_secs
        self.open_sleep = open_sleep_secs if open_sleep_secs is not None else quote_poll_secs
        self.closed_sleep = closed_sleep_secs
        self.ema_provider = ema_provider
        self.close_provider = close_provider
        self.alert = alert or (lambda m: print(f"[LOOP] {m}"))
        self._positions: list = []
        self._last_phase = "CLOSED"
        self._rolled_date = None
        self._last_price: dict = {}
        self._warned_no_ema = False
        self._stop = False

    # ---- position ownership ----
    def seed(self, positions):
        self._positions = list(positions)

    def positions(self):
        return [p for p in self._positions if p.state.value not in ("CLOSED", "CANCELLED")]

    # ---- startup ----
    def start(self):
        recovered = self.mon.recover()                 # rehydrate from the event store
        have = {p.order_key for p in self._positions}
        for p in recovered:
            if p.order_key not in have:
                self._positions.append(p)
        self.mon.start_watchdog(self.positions, reconnect=None)  # REST-floor: no WS reconnect
        self._last_phase = self.clock.phase()
        self.alert(f"started; {len(self.positions())} live position(s); phase={self._last_phase}")

    # ---- one iteration ----
    def _quote(self, pos):
        q = self.broker.get_quote(pos.ticker, pos.exchange)
        last = float(q.get("last") or 0) if q else 0
        bid = float(q.get("bid") or 0) if q else 0
        if last <= 0:
            return None
        self._last_price[pos.ticker] = last
        return last, (bid or last)

    def _do_close(self, pos):
        if not (self.ema_provider and self.close_provider):
            if not self._warned_no_ema:
                self.alert("no ema/close provider wired — skipping on_close "
                           "(stall-exit + EMA-trail inactive; intraday stop/partial still run)")
                self._warned_no_ema = True
            return
        try:
            self.mon.on_close(pos, float(self.close_provider(pos.ticker)),
                              float(self.ema_provider(pos.ticker)))
        except Exception as ex:
            self.alert(f"on_close({pos.ticker}) error: {ex}")
        # --- PATCH AA (I5) --- observation only, in its OWN try. It runs
        # whether or not on_close above succeeded, because the position still
        # had a close either way, and a logging failure must never reach the
        # exit path. close_log.record() already swallows; this is the second
        # boundary, deliberately.
        if getattr(self, "close_log", None) is not None:
            try:
                self.close_log.record(pos, self.clock.session_date())
            except Exception as ex:
                self.alert(f"close_log({pos.ticker}) error: {ex}")

    def cycle(self):
        et = self.clock.now_et()
        date = self.clock.session_date(et)
        phase = self.clock.phase(et)

        # day roll (once per trading day)
        if self.clock.is_trading_day(et) and date != self._rolled_date:
            try:
                self.mon.advance_trading_day(self.positions(), date)
            except Exception as ex:
                self.alert(f"advance_trading_day error: {ex}")
            self._rolled_date = date

        # session-open transition: execute any exits queued overnight
        if phase == "OPEN" and self._last_phase != "OPEN":
            for pos in self.positions():
                q = self._quote(pos)
                if q:
                    try:
                        self.mon.on_session_open(pos, q[0], q[1])
                    except Exception as ex:
                        self.alert(f"on_session_open({pos.ticker}) error: {ex}")

        # intraday: poll + tick
        if phase == "OPEN":
            for pos in self.positions():
                q = self._quote(pos)
                if q:
                    try:
                        self.mon.on_tick(pos, q[0], q[1])
                    except Exception as ex:
                        self.alert(f"on_tick({pos.ticker}) error: {ex}")
            self.mon.heartbeat()                        # REST poll is our liveness signal

        # session-close transition: stall / EMA-trail
        if phase == "CLOSED" and self._last_phase == "OPEN":
            for pos in self.positions():
                self._do_close(pos)

        self._last_phase = phase
        return phase

    # ---- drivers ----
    def run_forever(self, sleep_fn=time.sleep):
        self.start()
        while not self._stop:
            phase = self.cycle()
            sleep_fn(self.open_sleep if phase == "OPEN" else self.closed_sleep)

    def run_cycles(self, n, sleep_fn=lambda s: None):
        """Test/backtest driver: run exactly n cycles (clock's now_fn advances time)."""
        for _ in range(n):
            if self._stop:
                break
            phase = self.cycle()
            sleep_fn(self.open_sleep if phase == "OPEN" else self.closed_sleep)

    def stop(self):
        self._stop = True
        self.mon.stop_watchdog()
