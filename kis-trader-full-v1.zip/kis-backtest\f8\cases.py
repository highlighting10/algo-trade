#!/usr/bin/env python3
"""
F8 -- the eight differential cases (plus four extras that probe convention).

Every case uses the same geometry so the numbers stay readable:

    entry 100.00   stop 90.00   risk 10.00/sh   shares 30
    -> +1R = 110    +3R = 130 (the partial trigger)    breakeven = 100

A case declares the `stall_day` it exercises, exactly as
`tests/test_exit_state_machine.py` does. NOTHING here depends on the production
default: at 252 the promotion / stall / trail paths are unreachable (Rev 3 R2),
so the cases that need them state a short stall_day and say so.

`expect` is the PRODUCTION answer, asserted against the real engine. It is not
a guess -- it was read off the engine and then checked by hand against
engine_v2.on_tick / on_close / on_session_open. The harness side is compared to
the same triple, and any disagreement is the finding.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from engine_side import Bar

ENTRY, STOP, SHARES = 100.0, 90.0, 30
RISK = ENTRY - STOP


def _d(i: int) -> str:
    return f"2026-0{1 + i // 28}-{1 + i % 28:02d}"


def bars(*ohlc) -> list:
    return [Bar(_d(i), o, h, l, c) for i, (o, h, l, c) in enumerate(ohlc)]


@dataclass
class Case:
    key: str
    title: str
    stall_day: int
    bars: list
    emas: Optional[list] = None          # per-bar EMA21 fed to on_close; None = skip
    expect_reason: Optional[str] = None
    expect_bar: Optional[int] = None
    expect_price: Optional[float] = None
    expect_r: Optional[float] = None
    note: str = ""
    core_eight: bool = True
    tick_path: Optional[str] = None      # None = run under the suite default
    shares: int = SHARES
    # A KNOWN, CHARACTERISED disagreement. When set, the runner asserts the
    # harness produces exactly these values instead of asserting agreement --
    # so the difference is pinned rather than tolerated, and any change to
    # either engine shows up as a failure.
    h_reason: Optional[str] = None
    h_bar: Optional[int] = None
    h_price: Optional[float] = None
    h_r: Optional[float] = None
    differs: str = ""


# --------------------------------------------------------------------------
# 1. clean stop hit, intraday
# --------------------------------------------------------------------------
C1 = Case(
    "1", "clean intraday stop", 252,
    bars((100, 105, 98, 104),
         (104, 106, 88, 92)),
    expect_reason="STOP_HIT", expect_bar=1, expect_price=90.0, expect_r=-1.0,
    note="open 104 is above the stop, the bar trades through it -> fill AT the "
         "stop, exactly -1R. The only exit a FILLED position has at 252.")

# --------------------------------------------------------------------------
# 2. gap-through: the open is already below the stop
# --------------------------------------------------------------------------
C2 = Case(
    "2", "gap-through the stop", 252,
    bars((100, 105, 98, 104),
         (85, 88, 84, 86)),
    expect_reason="STOP_HIT", expect_bar=1, expect_price=85.0, expect_r=-1.5,
    note="fills at the OPEN, not at the stop. This is Rev 3 F7's 'realised max "
         "risk is 1.07R, not 1.00R' -- if the harness fills gaps at the stop it "
         "cannot have produced a 1.07 average and something else explains it.")

# --------------------------------------------------------------------------
# 3. stop and +3R touched on the SAME bar
# --------------------------------------------------------------------------
C3 = Case(
    "3", "stop and +3R on one bar -> STOP first", 252,
    bars((100, 105, 98, 104),
         (105, 132, 88, 120)),
    expect_reason="STOP_HIT", expect_bar=1, expect_price=90.0, expect_r=-1.0,
    note="the pessimistic assumption, always. Under tick_path='ohlc' this same "
         "bar partials first and the trade survives -- which is why the "
         "convention is reported with every number.")

# --------------------------------------------------------------------------
# 4. +3R partial -> breakeven -> pullback to breakeven (next bar)
# --------------------------------------------------------------------------
C4 = Case(
    "4", "+3R partial, then breakeven stop", 252,
    bars((100, 105, 98, 104),
         (105, 132, 104, 130),
         (125, 126, 99, 101)),
    expect_reason="STOP_HIT", expect_bar=2, expect_price=100.0, expect_r=1.0,
    note="10sh out at 130 (+3R), stop to breakeven, 20sh out at 100 (0R) -> "
         "+1.0R overall. The ONLY route to the trail at STALL_DAY=252.")

# --------------------------------------------------------------------------
# 5. EMA21 break after promotion
# --------------------------------------------------------------------------
C5 = Case(
    "5", "EMA break after promotion to TRAILING", 3,
    bars((100, 105, 98, 104),
         (104, 108, 103, 107),
         (107, 112, 106, 111),
         (111, 115, 110, 114),
         (113, 114, 108, 109),
         (108, 110, 107, 109)),
    emas=[99.0, 100.0, 102.0, 105.0, 112.0, 112.0],
    expect_reason="EMA_BREAK", expect_bar=5, expect_price=108.0, expect_r=0.8,
    note="bar 3: days_held 3 >= stall_day 3 and r +1.4 >= floor -> promoted "
         "(the `if` branch, EMA NOT evaluated that bar). bar 4: TRAILING and "
         "close 109 < EMA 112 -> queued. bar 5: executes at the OPEN, 108.")

C5b = Case(
    "5b", "promotion bar whose close is ALREADY below the EMA", 3,
    bars((100, 105, 98, 104),
         (104, 108, 103, 107),
         (107, 112, 106, 111),
         (111, 115, 110, 112),
         (111, 113, 108, 109),
         (108, 110, 107, 109)),
    emas=[99.0, 100.0, 102.0, 118.0, 118.0, 118.0],
    expect_reason="EMA_BREAK", expect_bar=5, expect_price=108.0, expect_r=0.8,
    note="THE `elif`. Bar 3 promotes (days 3, r +1.2) AND closes 112 < EMA 118. "
         "Because the EMA test is an `elif`, it is NOT evaluated on the "
         "promotion bar: the break is only seen at bar 4 and exits at bar 5's "
         "open. Turn that `elif` into an `if` and the exit moves a whole bar "
         "earlier, to bar 4 at 111 -- +1.1R instead of +0.8R. This is the case "
         "that makes the R2 structural fact observable end-to-end; "
         "test_exit_state_machine case D pins the same line from the other side.",
    core_eight=False)

# --------------------------------------------------------------------------
# 6. stall exit at a short stall_day
# --------------------------------------------------------------------------
C6 = Case(
    "6", "STALL_EXIT below the R floor", 3,
    bars((100, 105, 98, 104),
         (104, 106, 102, 105),
         (105, 107, 103, 106),
         (106, 107, 104, 105),
         (104, 106, 103, 105)),
    emas=[99.0, 100.0, 101.0, 102.0, 103.0],
    expect_reason="STALL_EXIT", expect_bar=4, expect_price=104.0, expect_r=0.4,
    note="bar 3: days_held 3 >= 3 and r +0.5 < floor 1.0 -> STALL_EXIT queued, "
         "position stays FILLED. bar 4: executes at the OPEN, 104.")

# --------------------------------------------------------------------------
# 7. stall_r_floor: exactly at the floor promotes instead of exiting
# --------------------------------------------------------------------------
C7 = Case(
    "7", "STALL_R_FLOOR boundary: r == 1.0 promotes", 3,
    bars((100, 105, 98, 104),
         (104, 108, 103, 107),
         (107, 111, 106, 109),
         (109, 112, 108, 110),
         (110, 112, 108, 111)),
    emas=[99.0, 100.0, 102.0, 104.0, 106.0],
    expect_reason=None, expect_bar=None, expect_price=None, expect_r=1.1,
    note="bar 3 closes at 110 = exactly +1.0R. The test is `< STALL_R_FLOOR`, "
         "so equality PROMOTES rather than exiting. Position is still open at "
         "the end, marked to the last close. Case 7b runs the identical bars "
         "at 252, where the whole branch is unreachable.")

C7b = Case(
    "7b", "the same bars at STALL_DAY=252 -> nothing fires", 252,
    C7.bars, emas=C7.emas,
    expect_reason=None, expect_bar=None, expect_price=None, expect_r=1.1,
    note="Rev 3 R2: 'structurally inert at stall 252'. Same bars, same EMAs, no "
         "promotion, no stall, no trail. If the harness exits here at 252 its "
         "stall gate is wired differently.",
    core_eight=False)

# --------------------------------------------------------------------------
# 8. EOD/open exit path: the queued exit takes the OPEN, whatever it is
# --------------------------------------------------------------------------
C8 = Case(
    "8", "queued exit fills at the next OPEN, gap and all", 3,
    bars((100, 105, 98, 104),
         (104, 106, 102, 105),
         (105, 107, 103, 106),
         (106, 107, 104, 105),
         (95, 99, 94, 98)),
    emas=[99.0, 100.0, 101.0, 102.0, 103.0],
    expect_reason="STALL_EXIT", expect_bar=4, expect_price=95.0, expect_r=-0.5,
    note="identical to case 6 except bar 4 gaps down. The exit is executed at "
         "the open (95), not at bar 3's close (105). A harness that exits a "
         "queued signal at the SIGNAL bar's close books +0.5R here instead of "
         "-0.5R -- a 1.0R error per stalled trade, in the flattering direction.")

# ---------------------------- extras: convention probes --------------------

C3b = Case(
    "3b", "case 3's bar under tick_path='ohlc' (optimistic)", 252,
    C3.bars,
    expect_reason=None, expect_bar=None, expect_price=None, expect_r=None,
    note="informational: shows what the same bar costs if the partial is "
         "allowed to precede the stop. Expectation is left open deliberately.",
    core_eight=False, tick_path="ohlc")

C4b = Case(
    "4b", "partial AND breakeven on the SAME bar", 252,
    bars((100, 105, 98, 104),
         (105, 132, 99, 120)),
    expect_reason="STOP_HIT", expect_bar=1, expect_price=100.0, expect_r=1.0,
    note="the same-bar breakeven retest that makes tick_path='worst' actually "
         "worst. Under 'olhc' this bar only partials and the trade survives.",
    core_eight=False)

C8b = Case(
    "8b", "a queued exit and a gap THROUGH the stop on the same open", 3,
    bars((100, 105, 98, 104),
         (104, 106, 102, 105),
         (105, 107, 103, 106),
         (106, 107, 104, 105),
         (85, 90, 84, 88)),
    emas=[99.0, 100.0, 101.0, 102.0, 103.0],
    expect_reason="STALL_EXIT", expect_bar=4, expect_price=85.0, expect_r=-1.5,
    note="PRECEDENCE, and a likely disagreement. run_loop calls on_session_open "
         "BEFORE the first tick, so the queued STALL_EXIT consumes the position "
         "and the reason booked is STALL_EXIT, not STOP_HIT -- at the same price. "
         "A harness that checks the stop first books this as STOP_HIT and the "
         "exit-reason histogram in Rev 3 sec.2 shifts.",
    core_eight=False)

C9 = Case(
    "9", "partial share truncation: int(shares * 1/3)", 252,
    bars((100, 105, 98, 104),
         (105, 132, 104, 130),
         (125, 126, 99, 101)),
    expect_reason="STOP_HIT", expect_bar=2, expect_price=100.0, expect_r=0.9375,
    note="32 shares, chosen because int/round/exact all disagree there: "
         "engine_v2 sells int(32 * 1/3) = 10. A harness using the exact "
         "fraction books 10.667 and a harness using round() books 11 -- 0.9375R, "
         "1.0R and 1.031R for the identical bars. Position sizing produces odd "
         "share counts constantly, so this is not a corner case.",
    core_eight=False, shares=32)



C2b = Case(
    "2b", "the ENTRY BAR itself pierces the stop, after gapping down", 252,
    bars((85, 105, 84, 100),
         (100, 102, 97, 99)),
    expect_reason="STOP_HIT", expect_bar=0, expect_price=90.0, expect_r=-1.0,
    note="The stock opened at 85, ran up through the pivot (filling us at 100) "
         "and printed a high of 105 -- so the 85 open happened BEFORE we were in "
         "and must not trigger anything. The stop fills AT the stop. Found by "
         "re-checking: the first version of the engine-side runner started every "
         "bar at the open and booked this as -1.5R at 85, a full 0.5R of "
         "phantom loss on any entry bar that gapped. No case in the original "
         "eight reached it, because every one of them opened at the entry price.",
    core_eight=False)


# ---------------------------- known disagreements --------------------------
# Both found by fuzz_f8.py, not by hand. Both have ONE root cause: the harness
# decides the +3R partial from the bar's HIGH alone and fills it at exactly the
# +3R level, ignoring the OPEN -- even though it already honours the open for
# the stop (`o if o < stop else stop`). Both understate, so Rev 3's numbers stay
# a lower bound.

C10 = Case(
    "10", "bar OPENS above +3R -> partial fills at the open, not at +3R", 252,
    bars((100, 105, 98, 104),
         (136, 136, 121, 123),
         (120, 121, 99, 101)),
    expect_reason="STOP_HIT", expect_bar=2, expect_price=100.0, expect_r=1.2,
    h_reason="STOP_HIT", h_bar=2, h_price=100.0, h_r=1.0,
    differs="engine fills the partial at the 136.00 open; the harness fills at "
            "exactly 130.00. Reason, bar and exit price all agree -- only the "
            "partial leg differs, by the size of the gap (0.2R here).",
    note="production polls from the open, so the first quote it sees is 136 and "
         "r_multiple(136) = 3.6 >= 3 fires the partial THERE. The harness's "
         "`fill = slip_sell(partial_level)` is unconditional.",
    core_eight=False)

C11 = Case(
    "11", "opens above +3R AND trades below the original stop", 252,
    bars((100, 105, 98, 104),
         (130, 130, 85.84, 120.71)),
    expect_reason="STOP_HIT", expect_bar=1, expect_price=100.0, expect_r=1.0,
    h_reason="STOP_HIT", h_bar=1, h_price=90.0, h_r=-1.0,
    differs="A 2.0R divergence. The harness sees stop and +3R both inside "
            "[low, high], calls it ambiguous and applies stop-first. But the bar "
            "OPENED at 130: the +3R was reached at the open, so the stop CANNOT "
            "have preceded it and there is no ambiguity to resolve. Production "
            "partials at 130, moves to breakeven, and exits the runner at 100 "
            "(+1.0R); the harness books -1.0R at 90.",
    note="the harness already applies exactly this reasoning to the stop one "
         "line earlier -- `o if o < pos.stop_loss_price` exists because the open "
         "pins the ordering. It simply is not applied to the partial.",
    core_eight=False)

CORE_EIGHT = [C1, C2, C3, C4, C5, C6, C7, C8]
EXTRAS = [C2b, C5b, C7b, C3b, C4b, C8b, C9, C10, C11]
ALL = CORE_EIGHT + EXTRAS
