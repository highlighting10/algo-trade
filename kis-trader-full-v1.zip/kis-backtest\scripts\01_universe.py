"""
01_universe.py -- build data/universe.csv and data/sectors.csv from Wikipedia.

Run once. Output is FROZEN and committed: every later run reads these files, never
the network (seed doc S4, "store once, replay many").

Writes:
    data/universe.csv   ticker,index          -- what to download
    data/sectors.csv    ticker,sector         -- GICS sector, for the sector cap

NOTE ON SURVIVORSHIP: these are TODAY'S constituents. Every backtest built on them
is survivorship-biased and its absolute numbers are an optimistic ceiling. Step 07
sizes that hole; it does not close it.
"""
import pathlib as _pl
import sys as _sys
_sys.path.insert(0, str(_pl.Path(__file__).resolve().parent.parent))
import sys
import time
from io import StringIO

import pandas as pd
import requests

# pd.read_html(url) lets urllib fetch the page, and urllib's default User-Agent is
# blocked by Wikipedia with HTTP 403. Their bot policy wants a descriptive agent, so
# we fetch with requests and hand read_html the TEXT instead of the URL.
HEADERS = {
    "User-Agent": "kistrader-backtest/1.0 (personal research; python-requests)",
    "Accept-Language": "en-US,en;q=0.9",
}
TIMEOUT = 30

PAGES = {
    "sp500": "https://en.wikipedia.org/wiki/List_of_S%26P_500_companies",
    "sp400": "https://en.wikipedia.org/wiki/List_of_S%26P_400_companies",
    "sp600": "https://en.wikipedia.org/wiki/List_of_S%26P_600_companies",
}


def find_constituent_table(tables):
    """Pick the table that has both a symbol and a GICS sector column. Table
    order on these pages changes, so never index by position."""
    for df in tables:
        cols = {str(c).strip().lower(): c for c in df.columns}
        sym = next((cols[k] for k in cols if k in ("symbol", "ticker symbol", "ticker")), None)
        sec = next((cols[k] for k in cols if "gics" in k and "sector" in k and "sub" not in k), None)
        if sym is not None and sec is not None:
            return df, sym, sec
    return None, None, None


def main():
    rows = []
    for name, url in PAGES.items():
        print(f"[universe] fetching {name} ...")
        tables = None
        for attempt in (1, 2, 3):
            try:
                resp = requests.get(url, headers=HEADERS, timeout=TIMEOUT)
                resp.raise_for_status()
                tables = pd.read_html(StringIO(resp.text))   # needs lxml
                break
            except Exception as e:
                print(f"[universe]   attempt {attempt}/3 failed: "
                      f"{type(e).__name__}: {e}")
                if attempt < 3:
                    time.sleep(3 * attempt)
        if tables is None:
            print(f"[universe] FAILED {name} after 3 attempts.")
            print("[universe] If this is HTTP 403, the User-Agent is being refused --")
            print("[universe] edit HEADERS at the top of this file. If it is a")
            print("[universe] timeout, it is the network.")
            print("[universe] cannot continue -- a partial universe would silently "
                  "change every RS percentile.")
            sys.exit(1)
        df, sym, sec = find_constituent_table(tables)
        if df is None:
            print(f"[universe] FAILED {name}: no table with symbol + GICS sector columns")
            sys.exit(1)
        n = 0
        for t, s in zip(df[sym], df[sec]):
            t = str(t).strip().upper().replace(".", "-")   # BRK.B -> BRK-B (yfinance)
            s = str(s).strip()
            if not t or t == "NAN" or not s or s.lower() == "nan":
                print(f"[universe]   skipped malformed row: {t!r}/{s!r}")
                continue
            rows.append({"ticker": t, "index": name, "sector": s})
            n += 1
        print(f"[universe] {name}: {n} constituents")

    all_df = pd.DataFrame(rows)
    dupes = all_df[all_df.duplicated("ticker", keep=False)]
    if len(dupes):
        print(f"[universe] {len(dupes)} ticker(s) appear in more than one index; "
              f"keeping the first occurrence")
    all_df = all_df.drop_duplicates("ticker", keep="first").sort_values("ticker")

    all_df[["ticker", "index"]].to_csv("data/universe.csv", index=False)
    all_df[["ticker", "sector"]].to_csv("data/sectors.csv", index=False)

    print(f"\n[universe] wrote data/universe.csv  ({len(all_df)} tickers)")
    print(f"[universe] wrote data/sectors.csv   ({all_df['sector'].nunique()} sectors)")
    print("[universe] sector counts:")
    for s, c in all_df["sector"].value_counts().items():
        print(f"[universe]   {s:26} {c}")

    # fail closed here rather than at backtest time
    from minervini_backtest import load_sector_map
    m = load_sector_map("data/sectors.csv")
    print(f"[universe] load_sector_map OK: {len(m)} entries")


if __name__ == "__main__":
    main()
