# Minervini exit upgrade — Phase E, stage 0

**Nothing in this stage changes what the trader does.** No exit fires earlier,
no partial is taken sooner, no stop moves. `engine_v2.py` is untouched and no
module in the exit path imports the new code.

## What stage 0 ships

A **sell-signal observer** (`kistrader/core/minervini_exit_rules.py`) that
computes Minervini's two selling families and records them, one row per held
position per close, in the existing I5 log (`runs/close_observations.csv`).

| family | signals |
|---|---|
| sell into strength | `climax_gain`, `climax_volume`, `climax_range`, `exhaustion_gap`, `extended_from_ema` |
| sell into weakness | `failed_breakout`, `ma_violation_on_volume`, `worst_down_day`, `heaviest_down_volume` |

Plus one summary column, `sell_verdict`, taking `SELL_INTO_WEAKNESS`,
`SELL_INTO_STRENGTH`, `HOLD`, or blank.

Every signal is tri-state — `True`, `False`, or blank when the data to answer it
was not available. Blank and `False` are different rows and the analysis needs
to tell them apart.

## Why it records instead of trading

`RESULT_20260828_S3_failed_breakout` measured a structural pre-stop exit at
**0 of 16 cells**, with a monotone dose-response in the harmful direction
(+0.380 R → −0.069 R as the trigger got easier to fire). Three earlier
measurements point the same way (the `be_2.0` breakeven trigger, the half-at-2R
partial, the F3 prescribed fix). S3 sec.5 states the standing conclusion:

> in this book, exiting earlier than the ATR stop destroys expectancy

and names the only route that can overturn it — *"the instrumentation route
(I4 → I5: log why the 68% die, trade nothing), not another exit sweep."*

This is that instrument, extended from I5's raw quantities (volume ratio, range,
close location) to the named signals the doctrine actually uses.

## The failure net

The existing hard stop, the broker-confirmed exit state machine, the +3R
partial, the EMA trail and the stall exit are unchanged and remain the only
things that sell. They are not a net under a new layer; in stage 0 they are the
whole exit engine, exactly as they were.

## What would take this to stage 1

Weeks of rows, then a paired sweep on the backtest harness asking whether a
position that fired a weakness signal was measurably more likely to stop out,
and how many sessions of warning the signal gave. A threshold ships only if that
sweep clears the pre-registered noise floor. Nothing here is evidence yet.

These are objective approximations of Minervini's selling principles, not a
claim to reproduce his discretionary judgment.
