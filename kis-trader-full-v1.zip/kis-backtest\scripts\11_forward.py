"""
11_forward.py -- THE DECISIVE TEST. Do the moves exist, or do we leave too early?

10_rr.py could not answer this. Its MFE is measured over the ACTUAL hold, so a
trade cut at day 10 cannot show a move that happened on day 25. "The move was not
there" and "we left before it happened" produce identical numbers.

This measures MFE over a FIXED forward window from entry, ignoring when we
actually exited. Same entries, same risk-per-share, but the question becomes:
looking forward N sessions from every entry we took, how far did price actually
go in our favour?

    forward MFE stays ~1R at every horizon
        -> the setups genuinely do not produce 3R moves. The founding 3:1
           assumption is unachievable and no exit rule can rescue it. STOP.

    forward MFE grows materially with the horizon
        -> the moves ARE there and the exits are leaving them on the table.
           The strategy has a repair path worth pursuing.

Usage:
    python scripts/11_forward.py --threshold 70 --signals data/signals_daily.pkl
"""
import pathlib as _pl
import sys as _sys
_sys.path.insert(0, str(_pl.Path(__file__).resolve().parent.parent))

import argparse
import pathlib
import pickle

import numpy as np
import pandas as pd

from minervini_backtest import (BacktestConfig, DecisionConfig, load_sector_map,
                                run)

HORIZONS = (5, 10, 20, 40, 60, 90)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--threshold", type=float, default=70.0)
    ap.add_argument("--slippage", type=float, default=5.0)
    ap.add_argument("--signals", default="data/signals.pkl")
    ap.add_argument("--start", default=None)
    ap.add_argument("--end", default=None)
    args = ap.parse_args()

    bars = {}
    for p in pathlib.Path("data/bars").glob("*.parquet"):
        df = pd.read_parquet(p)
        if getattr(df.index, "tz", None) is not None:
            df.index = df.index.tz_localize(None)
        bars[p.stem] = df.sort_index()
    prices = {t: d for t, d in bars.items() if t != "^GSPC"}

    with open(args.signals, "rb") as f:
        signals = pickle.load(f)["signals"]
    if args.start or args.end:
        lo = pd.Timestamp(args.start) if args.start else pd.Timestamp.min
        hi = pd.Timestamp(args.end) if args.end else pd.Timestamp.max
        signals = {d: v for d, v in signals.items() if lo <= pd.Timestamp(d) <= hi}

    cfg = BacktestConfig(rank_mode="rs_only", equity_mode="compounding",
                         entry_mode="pivot_limit", ambiguity_mode="worst",
                         vcp_threshold=args.threshold, slippage_bps=args.slippage,
                         sector_map=load_sector_map("data/sectors.csv"),
                         decision=DecisionConfig())
    eq, trades, st, dr, dg = run(prices, signals, cfg)
    if not trades:
        raise SystemExit("[forward] no trades")

    # ---- forward MFE and MAE over fixed horizons, ignoring the real exit -----
    rows = {h: {"mfe": [], "mae": []} for h in HORIZONS}
    skipped = 0
    for t in trades:
        df = prices.get(t.ticker)
        rps = t.risk_per_share
        if df is None or rps <= 0:
            skipped += 1
            continue
        fwd = df.loc[df.index > t.entry_date]
        if fwd.empty:
            skipped += 1
            continue
        for h in HORIZONS:
            w = fwd.iloc[:h]
            if w.empty:
                continue
            rows[h]["mfe"].append(float((w["High"].max() - t.entry_price) / rps))
            rows[h]["mae"].append(float((w["Low"].min() - t.entry_price) / rps))

    print("=" * 74)
    print(f"FORWARD EXCURSION  threshold={args.threshold}  {len(trades)} trades"
          + (f"  ({skipped} skipped)" if skipped else ""))
    print("=" * 74)
    print("  Measured from entry, ignoring when we actually exited.")
    print()
    print(f"  {'horizon':>8} {'n':>6} {'mean MFE':>9} {'median':>8} "
          f"{'>=2R':>7} {'>=3R':>7} {'mean MAE':>9}")
    for h in HORIZONS:
        m = np.array(rows[h]["mfe"])
        a = np.array(rows[h]["mae"])
        if not len(m):
            continue
        print(f"  {h:>6}d {len(m):>6} {m.mean():>9.3f} {np.median(m):>8.3f} "
              f"{100*np.mean(m>=2):>6.1f}% {100*np.mean(m>=3):>6.1f}% {a.mean():>9.3f}")

    print()
    print(f"  actual hold (mean)     : {np.mean([t.days_held for t in trades]):.1f} sessions")
    print(f"  actual MFE captured    : {st['avg_mfe_R']:+.3f} R")
    print(f"  actual exit            : {st['avg_r_at_exit']:+.3f} R")

    m10 = np.array(rows[10]["mfe"]) if rows[10]["mfe"] else np.array([0.0])
    m60 = np.array(rows[60]["mfe"]) if rows[60]["mfe"] else np.array([0.0])
    growth = m60.mean() - m10.mean()

    print()
    print("=" * 74)
    print("  VERDICT")
    print("=" * 74)
    print(f"  MFE at 10d: {m10.mean():.3f} R   at 60d: {m60.mean():.3f} R   "
          f"growth: {growth:+.3f} R")
    if m60.mean() < 1.5:
        print("  Even at 60 sessions the average trade barely exceeds 1R. The 3:1")
        print("  assumption is not achievable on these setups. This is an ENTRY")
        print("  problem and no exit change repairs it.")
    elif growth > 0.75:
        print("  MFE grows substantially with the horizon: the moves ARE there and")
        print("  the current exits are cutting before they develop. This is an EXIT")
        print("  problem, and it is fixable. Compare the >=3R column at 10d vs 60d.")
    else:
        print("  MFE grows only modestly. Longer holds help somewhat but will not")
        print("  reach 3:1 -- expect incremental improvement, not transformation.")
    print()
    print("  Watch the MAE column too: a longer horizon that lifts MFE also")
    print("  deepens the adverse excursion, and the stop fires on the way.")


if __name__ == "__main__":
    main()
