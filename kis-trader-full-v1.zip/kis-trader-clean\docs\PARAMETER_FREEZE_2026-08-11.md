# kistrader Step 5 — PARAMETER FREEZE
**Rev 3 · 2026-08-11 · supersedes Rev 1 (`PARAMETER_FREEZE_rev1_superseded.md`) and SESSION_CLOSE.md §3–§5**

---

## 0. ONE PARAGRAPH

A bug that had silently disabled `rank_mode` for the entire project was found and
fixed. With correct ranking, six parameters were re-decided and one was measured
inert. Per-trade expectancy went **+0.052 R → +0.330 R** and the payoff ratio went
**1.15:1 → 3.20:1**, closing the reward-to-risk shortfall SESSION_CLOSE §4 called
"the entire gap". Measured at the **complete frozen set** (threshold 75, stall 252,
risk 0.85%, cap 25%, `regime_ma = 20`): **+49.92% total return over 8.6 years,
−19.50% max drawdown, 31.0% win rate, expectancy +0.330 R, 200 trades**, positive
in both halves. That is ~4.8%/yr against ^GSPC's 13.09%/yr — but at only **~38%
average deployment**, where a same-exposure passive blend returns 4.95%/yr. On a like-for-like exposure basis
the strategy edges passive on return and loses on drawdown. The remaining
structural difference from Minervini is exposure management; a binary regime gate
is measured and worth +0.038 R against a ±0.19 R standard error.

---

## 1. FROZEN PARAMETER SET

| parameter | value | production location | evidence |
|---|---|---|---|
| `rank_mode` | **`vcp_only`** | `decision_engine.rank_score` — **needs a new `vcp_weight` field** | ROBUST; wins all 4 cost levels; margins 5.79–8.62 return-% |
| `VCP_SCORE_THRESHOLD` | **75** | `config.py` | best mean (+0.281) and best worst cell (+0.217) of all 7; zero negative cells; **only positive threshold cost-monotone in both halves** |
| `stall_day` | **252** | `engine_v2.py` `STALL_DAY` | best mean (+0.199), best worst cell (+0.048); only 252 and 126 positive in all 8 half×cost cells, and 252 dominates 126 |
| `stall_r_floor` | 1.0 (unchanged) | `engine_v2.py` | **structurally inert at stall 252** — no trade reaches day 252; all four floors byte-identical in both halves |
| `risk_per_trade_pct` | **0.0085** | `decision_engine.py` | JH decision; below Minervini's 1.25–2.5% band; unclipped at the 25% cap |
| `max_position_pct` | **0.25** | `decision_engine.py` | 25 vs 30 differ by 0.033 R — inside noise. Cap stops binding above ~35% |
| `be_trigger_r` | **None (off)** | not in production — **do not build** | `be_off` wins 6 of 8 cells, best mean, best worst cell; monotone decay away from it |
| `regime_ma` | **20** | new; see §5 | beats the control in **both** halves on expectancy (8/8 cells) AND on drawdown (−19.50% vs −21.64%). See §5 for an open question about 150 |
| pyramid | **NOT SHIPPING** | — | overlay estimator flipped sign twice vs harness. *The capital objection raised at threshold 70 no longer applies (see §5).* |
| `n_max` | 8 (unchanged) | — | rarely binding at ~2.8 average positions |

---

## 2. MEASURED PERFORMANCE

### Baseline first — WITHOUT the regime gate (`regime_off`), full window, 5 bps

```
  225 trades over 2018-01-02 .. 2026-08-07
  win rate            31.1%           payoff 3.14 : 1
  expectancy          +0.294 R        avg win 20.15% / avg loss -6.41%
  total return        +51.44%         max drawdown  -21.64%
  mean MFE 2.104 R    p75 3.376   p90 5.308   reached 3R: 30.2%

  BY EXIT REASON
    STOP_HIT     154   MFE 0.811   exit -1.071   held 19.5 sessions
    EMA_BREAK     64   MFE 5.196   exit +3.398   held 67.0 sessions
    EOD_OPEN       7   MFE 2.285   exit +1.961   held 50.6 sessions
    STALL_EXIT     0   <- stall_day 252 removed this exit entirely

  winners n=70   MFE 4.979   exit 3.311   gave back 34%
  losers  n=155  MFE 0.806   exit -1.068
```

**Split:** H1 (2018-01→2022-06) +0.332 R over 103 trades. H2 (2022-07→2026-08)
+0.252 R over 122 trades, +20.65% return, −22.36% drawdown. Both halves positive,
and the H1/H2 asymmetry that dominated Rev 1 is largely gone at threshold 75.

### WITH `regime_ma = 20` — the complete frozen set, measured

```
  full   200 trades   win 31.0%   payoff 3.20:1   E +0.330 R
         total return +49.92%     max drawdown -19.50%
         winners n=62  MFE 5.137  exit 3.438  gave back 33%

  H1      93 trades   win 30.1%   payoff 3.68:1   E +0.376 R
         total return +23.38%     max drawdown -13.24%
  H2     107 trades   win 31.8%   payoff 2.82:1   E +0.290 R
         total return +21.49%     max drawdown -19.56%
```

**Consistency checks, all passed:** sweep and `10_rr` agree exactly on both return
(+49.92%) and drawdown (−19.50%); H1 93 + H2 107 = 200 = the full run; and
H1 compounded with H2 gives +49.89% against a measured +49.92% (0.03 pts).

**`regime_20` beats `regime_off` on every measured axis except raw return:**
expectancy full +0.294→+0.330, H1 +0.332→+0.376, H2 +0.252→+0.290, payoff
3.14→3.20, drawdown −21.64%→−19.50%, return/drawdown 2.38→2.56. Return falls
1.52 pts. **This is the frozen configuration.**

**Deployment at the frozen set:** H2 measured 3.805 of 8 slots; H1 ~1.85.
Window-weighted **2.78 of 8 × 13.6% notional = ~37.8% of equity.**
*(Rev 1 quoted 68.9% — that was threshold 70 and does not apply here.)*

```
  strategy          5.09%/yr @ -21.64% drawdown, ~37.8% deployed
  passive same expo 4.95%/yr @ ~12.9%
  ^GSPC            13.09%/yr @ ~34% (2020), ~25% (2022), 100% deployed
```

At the same exposure the strategy **beats passive on return and loses on
drawdown**. Against the fully-invested index it loses on return and wins on
drawdown. **It is a low-exposure, low-return, moderate-risk system — not a
market-beating one.**

---

## 3. WHY IT CANNOT BEAT THE INDEX — the arithmetic

Total R delivered over the whole 8.6-year window, by threshold, at 5 bps:

```
    thr_55   54.0 R      thr_70   65.3 R      thr_85    6.9 R
    thr_60   73.3 R      thr_75   64.9 R
    thr_65   92.4 R      thr_80   27.8 R
```

**The system's total R is capacity-limited to 65–92 R over 8.6 years.** That is
the ceiling, and it is set by how many qualified setups exist — not by tuning.

The index returned +188% over the same window. R required, by risk level:

| risk/trade | R needed | best measured (92.4 R) | resulting max drawdown |
|---|---|---|---|
| 0.85% (frozen) | 221 R | not reachable | −21.6% |
| 1.25% | 150 R | not reachable | −31.8% |
| 2.00% | 94 R | borderline | −50.9% |
| 2.50% | 75 R | **reachable** | −63.6% |

**Matching the index is arithmetically possible only at 2.0–2.5% risk, which
triples the drawdown to 50–64%.** Minervini himself advises keeping maximum
drawdown below 20–30%. So: the edge is real, positive in both halves at every
cost level; its *scale* is not enough to match a 100%-invested index at a
drawdown anyone should accept.

**The one lever that would close it is the win rate**, holding payoff at 3.14:1:

```
  31.1% (measured)  -> +0.239 R  ->  5.3%/yr
  35%               -> +0.403 R  ->  8.9%/yr
  40%               -> +0.613 R  -> 13.6%/yr   <- index parity
  48% (Minervini)   -> +0.950 R  -> 21.0%/yr
```

Win rate is worth roughly 3× everything else combined. It is a function of stock
selection, which is why lengthening the hold and raising risk did not move it.

**And this is where the honest upside sits.** The backtest gate is
`Stage 1 AND VCP ≥ 75`. Production's gate is `Stage 1 AND Stage 2 ≥ 40 AND
VCP ≥ 75`. **Production trades a strict subset.** If Stage 2 (EPS/revenue
acceleration + catalyst) has any predictive power at all, the production win rate
is above 31.1% and **every number in this document is a lower bound.** That is
not measurable in backtest — Gemini has no point-in-time history — and can only
be settled by the Step 4 forward test.

---

## 4. NOISE FLOOR — apply this before believing any margin

Per-trade SD computed from the actual distribution (lower bound; winners exit
above 10R, so the true SD is higher):

```
  SD = 1.95 R
    n=225 (frozen set, full)   SE = 0.130 R
    n=103 (H1)                 SE = 0.192 R
    n=122 (H2)                 SE = 0.177 R
```

**At ~100 trades per half the standard error is ±0.19 R.** Margins below that are
not evidence. This voids the *magnitude* of several comparisons but changes no
decision:

| comparison | margin | status |
|---|---|---|
| `stall_252` vs `stall_126` | 0.050 | inside noise — chosen on 8-cell dominance |
| `maxpos_25` vs `maxpos_30` | 0.033 | inside noise — kept 25 |
| `be_off` vs `be_2.0` | 0.029 | inside noise — kept `off` (build nothing) |
| `regime_20` vs `regime_off` | 0.038 | inside noise — chosen on 8/8 cells |
| **`thr_75` vs `thr_70`** | see below | **NOT inside noise — paired band analysis** |

Two diagnostics *not* subject to this floor, because they test structure rather
than magnitude:
- **Cost monotonicity.** Cost cannot reorder a fixed trade set; a non-monotone
  column means the trade set moved and that rank is churn.
- **8-cell dominance.** Winning both halves is two independent successes.

### Why 75 and not 70 — the paired argument

```
  H1  38 trades scoring 70-75   +12.2 R total  = +0.32 R each   <- winners
  H2  34 trades scoring 70-75   -11.9 R total  = -0.35 R each   <- losers
```

| | thr_70 | thr_75 | delta |
|---|---|---|---|
| trades | 296 | 225 | −71 (−24%) |
| total return | +53.25% | +51.44% | −1.81 pts |
| max drawdown | −28.99% | −21.64% | **+7.35 pts (−25%)** |
| return / drawdown | 1.84 | **2.38** | **+29%** |
| H2 return | +13.52% | **+20.65%** | **+53%** |

Give up 1.8 points of return, buy 7.4 points of drawdown and half the H2
shortfall. Production currently runs 80, which at the frozen config scores
**+0.43 R in H1 and −0.05 to −0.11 R in H2** — four negative cells.

---

## 5. EXPOSURE MANAGEMENT

All five SEPA elements are implemented (§7). The one real difference from
Minervini is that he varies exposure with market conditions and this system does
not.

Measured, threshold 75, all 8 half×cost cells:

| setting | worst cell | mean | beats `off` |
|---|---|---|---|
| `regime_off` | +0.217 | +0.281 | — |
| **`regime_20`** | **+0.243** | **+0.320** | **8 / 8** |
| `regime_150` | +0.180 | +0.284 | 4/8 (wins H1, loses H2) |
| `regime_100` | +0.179 | +0.273 | 3/8 (wins H1, loses H2) |
| `regime_200` | +0.131 | +0.264 | 4/8 (wins H1, loses H2) |
| `regime_50` | +0.092 | +0.162 | 0/8 |

Total R: `regime_off` 64.9 R on 225 trades, `regime_20` 65.6 R on ~199.
**Same return, ~12% fewer trades.** A risk control, not a return enhancer.

### DRAWDOWN SWEEP — the only fully-stable result in the project

```
              0 bps    5 bps   15 bps   30 bps
  regime_150 -14.31   -14.50   -14.92   -15.53
  regime_200 -14.35   -14.53   -14.93   -15.56
  regime_100 -14.51   -14.61   -17.41   -19.10
  regime_50  -17.35   -18.43   -18.32   -20.01
  regime_20  -19.27   -19.50   -20.09   -21.00
  regime_off -22.01   -21.64   -22.45   -24.73
```
**ROBUST, winner stable across costs, FULL ORDERING STABLE.** Nothing else in this
project has produced a fully stable ordering. The ranking is also mechanistic:
longer moving averages stay switched off through an entire sustained bear
(2018 Q4, 2020, 2022) — which is where a maximum drawdown is made — whereas a
20-day gate re-admits entries on every bear-market rally.

### OPEN QUESTION — `regime_150` vs `regime_20`

Return divided by |drawdown|, by cost level:
```
  regime_150   3.76   3.14   3.11   2.54   <- best at ALL FOUR
  regime_200   3.43   3.22   2.82   2.27
  regime_100   3.23   3.06   1.99   1.47
  regime_20    2.66   2.56   2.27   1.91
  regime_off   2.39   2.38   2.08   1.51
```

**The two metrics disagree.** `regime_20` wins the split-sample expectancy test
(both halves, 8/8 cells) — the discipline used for every other parameter in this
document. `regime_150` wins risk-adjusted return at every cost level and cuts max
drawdown by a third, but **loses H2 on expectancy** (+0.216 vs `off` +0.252).

Why it matters: a −14.50% drawdown instead of −19.50% is budget that can be
converted back into return through sizing. At 1.25% risk (Minervini's band floor)
`regime_150` would return roughly +74% at a ~−21% drawdown, against `regime_off`'s
+51.44% at −21.64% — the same risk for ~44% more return.

**Not resolved. Two commands settle it** — split-sample the drawdown:
```
06_sweep.py --param regime --metric max_drawdown_pct ... --start 2018-01-01 --end 2022-06-30
06_sweep.py --param regime --metric max_drawdown_pct ... --start 2022-07-01
```
If `regime_150` cuts drawdown in **both** halves, it beats `regime_20` on the
project's own standard and the frozen value changes. **`regime_ma` is a single
integer in config, so this does not block production** — ship 20, resolve later.

Implemented in `exposure_controller.py`: three reachable states, fails closed on
an unreadable benchmark, and it **writes the existing
`DecisionConfig.max_portfolio_exposure_pct`** rather than adding a second gate.
Deliberately excluded: trade-feedback, breadth and volatility inputs (never
measured — 225 trades cannot support twelve free parameters).

**Correction to Rev 1 on the pyramid:** the "no free capital" objection was
computed at threshold 70 (68.9% deployment). At the frozen threshold 75,
deployment is ~37.8% and adds would take it to ~54% — **there is headroom, and
the capital objection is withdrawn.** The estimator objection stands: the overlay
flipped sign twice and the add leg has never been harness-validated. The pyramid
is now the largest *untested* upside available, not a closed question.

---

## 6. FALLACIES AND FRAGILITIES

**F1 — "cost is a uniform drag" is false.** `be_2.0` scored +0.174 at 0 bps and
+0.204 at 5 bps — impossible for a fixed trade set. Slippage changes fill price →
stop distance → share count → cash → **which trades get taken**. Cost is a
selector, not a drag. Economically it remains trivial (1.4 bps/side commission);
this is a methodology point only. *Use: non-monotone columns flag churn.*

**F2 — `be_2.0` is an artifact.** Wins 4/4 at 0.75%/20%, wins 0/4 at 0.85%/25%,
non-monotone in both. `be_off` is monotone in both.

**F3 — `10_rr.py`'s old verdict was wrong at this book.** It read "90% of MFE
given back → EXIT problem", dominated by 154 STOP_HIT trades whose 0.81 R MFE was
intrabar noise. Real winner give-back is 34%, and the fix it prescribed was
*measured to destroy expectancy*. Diagnostic replaced; give-back now split by
outcome.

**F4 — sizing moves expectancy through trade-set churn, not mechanism.** The
`maxpos` sweep is non-monotone in all four cost columns; the peak wanders between
25/30/35. Trade counts *are* smooth (320→299→299→295→294→294) and 35% ≡ 40% (the
cap stops binding at ~35%), so the direction is real and the magnitude is not.

**F5 — the overlay estimator is retired.** Overlay vs harness on the breakeven
leg: `+0.0994 → −0.0760` at stall 10, and `+0.4097 → −0.2070` at stall 252. Sign
flipped twice, error growing with the claim.

**F6 — no held-out data remains.** Every split-sample is one window cut in two,
and every parameter was chosen with both halves visible.

**F7 — realised max risk is 1.07 R, not 1.00 R.** Avg loss 6.41% against a ~6.3%
stop; STOP_HIT mean exit −1.071 R. Gap-through is real and priced.

**F8 — the harness exit engine has never been validated against `engine_v2`.**
SESSION_CLOSE §2 flagged it and it is still open. Every exit number in this
document comes from a reimplementation, not from the code that will run live.
**This is the largest single unvalidated assumption in the project.**

---

## 7. SEPA COVERAGE

Rev 1 claimed Fundamentals and Catalyst were missing. **That was wrong.**
`sp500_v21.py` v11 implements a hybrid Stage 2: a Python math floor 0–45 computed
from real fundamentals (Earnings Acceleration /25 = EPS growth /12 full at +25%
YoY + acceleration /8 + surprises /5; Revenue Acceleration /20 = growth /12 full
at +20% YoY + acceleration /8; year-ago base ≤ 0 zeroes growth), plus Gemini
scoring only the 55 qualitative points. Gate at 40, deliberately below the
45-point math ceiling so elite EPS/revenue acceleration passes on numbers alone.

| SEPA element | kistrader | status |
|---|---|---|
| 1. Trend | Stage 1, 7 per-stock conditions | implemented |
| 2. Fundamentals | Stage 2 math floor 0–45 | **implemented, to spec** |
| 3. Catalyst | Stage 2 qualitative 0–55 | **implemented** |
| 4. Entry | VCP + pivot limit | implemented |
| 5. Exit | ⅓ + breakeven at 3R, EMA21 break | implemented |
| Exposure management | binary regime gate (§5) | partial |

The backtest measures Stage 1 + VCP + Exit only. Stage 2 is not reconstructible
point-in-time and is carried as a known, accepted population difference — and, per
§3, as the reason these numbers are a lower bound.

---

## 8. HARNESS ENGINEERING — COMPLETE

| change | file | verification |
|---|---|---|
| `RANK_WEIGHTS`, engine built from weights, `stage2_score := vcp_score` | `minervini_backtest.py` | production engine run directly: 3 input orders, `n_max=1`, same pick — bug proven, then fixed |
| itemised drop tags `decision_engine/ <reason>` | `minervini_backtest.py` | tags sum exactly to the old opaque bucket |
| `be_trigger_r` + validation + next-bar trigger | `minervini_backtest.py` | `be_3.0 ≡ be_off` to 4 dp with identical trade counts |
| `regime_ma` + fail-closed gate | `minervini_backtest.py` | both fail-closed paths tested |
| `--rank-mode --stall-day --risk-pct --max-position-pct` | `06_sweep.py`, `10_rr.py`, `15_pyramid_decompose.py` | `None` defaults reproduce prior output exactly |
| give-back split by outcome; return + drawdown printed | `10_rr.py` | fails loud if a stats key is absent |
| sweep groups `betrigger`, `maxpos`, `regime` | `06_sweep.py` | each has an explicit control setting |

**Determinism confirmed:** the H1 `stallday` sweep was run twice, byte-identical.

**Still open:** `verify_all.py` printed `PASSED` while reporting
`No module named pyflakes`. pyflakes is installed now, but **the tool still fails
open** — make it exit non-zero when a check cannot run.

---

## 9. PRODUCTION CHANGE SPEC

**(a) `decision_engine.py` — new ranking term.** `vcp_only` cannot ship as config;
production's `stage2_score` is the live catalyst, not `vcp_score`.
```python
    vcp_weight: float = 0.0        # DecisionConfig; default preserves behaviour

    return (self.cfg.rs_weight * c.rs_rating
            + self.cfg.stage2_weight * c.stage2_score
            + self.cfg.vcp_weight * c.vcp_score)
```
Then `rs_weight=0.0, stage2_weight=0.0, vcp_weight=1.0`.
**`rank_score` has zero test coverage in any suite. Add one.**

**(b) Config values:** `VCP_SCORE_THRESHOLD` 80→75 · `STALL_DAY` 10→252 ·
`risk_per_trade_pct` 0.0075→0.0085 · `max_position_pct` 0.20→0.25.

**(c) `exposure_controller.py`** wired to write `max_portfolio_exposure_pct`.

**(d) NOT shipping:** breakeven trigger, pyramid.

### Risks

**R1 — population mismatch, accepted.** Production runs Stage 2; no backtest ever
has. Carried deliberately: Gemini is not backtestable and the VCP filter is strong
on its own. Per §3 this makes the backtest a lower bound, not an overstatement.

**R2 — `STALL_DAY = 252` removes the soak's ability to exercise the trail path.**
At 252 there is no promotion to `TRAILING`, `STALL_EXIT` never fires, and the
trail is reachable only via the +3R partial (57 of 200 trades, held 67 sessions).
See the soak options appended to this document.

**R3 — orphan exposure bug.** `_account_state()` computes `open_notional` from
local positions while `held_tickers` comes from broker truth — two gates, two
sources. Fix: read `open_notional` from broker holdings. `reconcile()` already
adopts broker quantities for known positions and resolves late fills; only the
no-armed-record orphan is unhandled, and it should be adopted for **accounting**
but never for **management** — the armed record is what carries the stop.

**R4 — threshold 75 raises order flow ~3× vs 80**, into the still-undiagnosed
LUV/NUE rejections and KIS rate limits.

**R5 — `n_max = 8` is rarely binding** at ~2.8 average positions.

**R6 — four values across three files.** No single source of truth. Print the
active parameter set at boot.

**R7 — uncounted in the backtest:** Korean CGT 22% annual; FX (deliberate); idle
cash at 0% (~62% of the account at the frozen set, worth roughly +1.5%/yr
uncounted at ~2.5% short rates — material against a 5.1%/yr result).

---

## 10. DISCIPLINE ADDED THIS SESSION

- Multi-site patches are given **bottom-up**, so no edit renumbers a later one.
- **No line numbers inside code comments.** Correct for exactly one commit.
- **Check cost monotonicity** before believing a rank (F1).
- **An overlay is a screen, never evidence** (F5).
- **Assert the anchor matched before every string replace.**
- **A tool's verdict text can prescribe a fix its own data refutes** (F3).
- **Compute the standard error before quoting a margin** (§4).
- **H1 / H2 are time periods, never configurations.** Not a choice; a parameter
  must hold in both.
- **Carry the configuration with every number.** The 68.9% deployment figure in
  Rev 1 was a threshold-70 measurement quoted against a threshold-75 set.

---

# 11. PARAMETERS — CONCLUSION

**What was wrong at the start of the day.** `rank_mode` had never taken effect —
`decision_engine.plan()` re-sorted on its own `rank_score` and discarded the
harness ordering, so every run in the project's history ranked on `2×RS`. The
sweeps were internally consistent but were all measuring one ranking nobody chose.

**What changed.** Six parameters moved: ranking to `vcp_only`, threshold 80→75,
stall 10→252, risk 0.75%→0.85%, position cap 20%→25%, breakeven trigger measured
dead. One proven inert (`stall_r_floor`). One added (`regime_ma = 20`).

**Measured at the complete frozen set:** 200 trades, win 31.0%, payoff 3.20:1,
expectancy +0.330 R, **total return +49.92%, max drawdown −19.50%**, positive in
both halves (H1 +0.376 R / +23.38%; H2 +0.290 R / +21.49%).

**What that bought.**
```
             expectancy   payoff   win rate   total return   max drawdown
  start        +0.052 R   1.15:1     49.6%          ~3%/yr        unmeasured
  regime_off   +0.294 R   3.14:1     31.1%      +51.44%           -21.64%
  FROZEN       +0.330 R   3.20:1     31.0%      +49.92%           -19.50%
```
Expectancy up **5.7×**. The payoff ratio now exceeds the founding 3:1 assumption —
the shortfall SESSION_CLOSE called "the entire gap" is closed. The system changed
shape: from a coin-flip with small edges to a low-win-rate, fat-tailed trend
system, which is Minervini's actual profile.

**What it did not buy.** ~5.1%/yr against ^GSPC's 13.09%/yr. Per §3 the ceiling is
65–92 R over 8.6 years and matching the index needs 2.0–2.5% risk, which triples
drawdown to 50–64%. **The parameter space is exhausted** — every remaining margin
is inside ±0.19 R.

**The honest verdict.** A defensible low-exposure system: 21.6% maximum drawdown
against the index's ~34% in 2020, positive in both halves at every cost level,
every parameter chosen on 8-cell dominance rather than a single winning number,
and it edges a same-exposure passive blend on return. It is not a market-beating
system, and no parameter choice available in this harness makes it one.

**Where remaining upside actually lives**, in order of expected value:
1. **Stage 2 in production** (§3) — the backtest omits the fundamentals+catalyst
   filter, so these numbers are a lower bound. Settled only by the forward test.
2. **The pyramid** (§5) — the capital objection is withdrawn at threshold 75; the
   estimator objection stands. Needs a harness implementation, not an overlay.
3. **Cash yield** (R7) — ~62% of the account earns 0% in the harness; ~+1.5%/yr
   uncounted, which is 30% of the measured return.

Deploy the code and run the soak — those close real unknowns. **Treat the
live-money decision as separate, and take it on the drawdown profile and the
forward test, not on the backtest return.**

---

# 12. APPENDIX — SOAK OPTIONS FOR R2

At `STALL_DAY = 252` the promotion → `TRAILING` → `EMA_BREAK` path is
unreachable inside a short soak. Four ways to close it, best first.

**Option A — deterministic integration test (recommended, no market needed).**
Feed `engine_v2` a synthetic bar sequence that drives a position past
`stall_day`, into `TRAILING`, then breaks EMA21. Runs in seconds, repeatable,
covers the exact code path, and doubles as the fix for **F8** — the harness exit
engine has never been validated against `engine_v2`, and the same fixture can
assert both engines produce identical exits. Highest value per hour on the list.

**Option B — `seed_position.py` on the mock account.** It exists for exactly
this: *"Primary use: deterministic EXIT-side testing… the exit half proven in two
minutes instead of waiting for a real stop breach."* Mock-only unless
`--allow-live`, requires `--confirm` and an explicit `--stop`. Seed a lot with a
stop below price, let it run to +3R territory, and the partial → `PARTIAL_TAKEN`
→ EMA trail path executes end-to-end against the real broker. Proves the live
plumbing that Option A cannot.

**Option C — soak-only `STALL_DAY = 5–6`.** Market-driven evidence, no new code.
Risk: you are soaking a configuration you will not ship, and the value can leak
to live. If chosen, record it as soak-only **and** print the active parameter set
at boot (R6) so a wrong value is visible on day one rather than in a post-mortem.

**Option D — temporarily lower `R_PARTIAL_MULTIPLE`** so the partial fires sooner
and routes into `PARTIAL_TAKEN` → trail. Config-only, but it changes exit
geometry, so it tests a path the production config will reach far less often.

**Recommendation: A + B.** A gives repeatable coverage of the state machine and
closes F8; B proves the live order path once. C only if you want market-driven
evidence on top, and never without the boot-time parameter log.
