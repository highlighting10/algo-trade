"""kistrader.notifier ??observability for the unattended loop.

Wired in as the `alert=` callback for ExecutionMonitor / EntryManager. Goals:

  * QUIET PHONE: only CRITICAL conditions push to Telegram. WARN/INFO are logged
    locally only. In normal operation nothing pushes, so a buzz *means act*.
  * DEDUP: a repeating condition (e.g. MANUAL CHECK firing every tick) pushes ONCE,
    then stays silent on that specific condition for `push_cooldown_secs`. A DIFFERENT
    condition still pushes immediately. This suppresses repeats, never new problems ??    unlike a blind global rate cap, which can swallow the alert you actually need.
  * NON-BLOCKING: `alert()` is called under the monitor's lock; a blocking HTTP send
    there would stall trading. emit() only classifies + logs + queues; a daemon thread
    does the network send (with timeout + retry).
  * NEVER CRASH THE LOOP: emit() swallows all exceptions. Alerting must not take down
    the thing it's watching.
  * FAIL-SAFE CREDS: if TG_BOT_TOKEN/TG_CHAT_ID are absent, it logs everything locally
    and simply skips the push (one-time warning). The loop runs regardless.

Severity is inferred from the message text (keeps the verified core untouched ??no
change to the `alert(msg)` signature anywhere). Tune the pattern lists below if a new
alert type should escalate or quiet down.
"""
from __future__ import annotations
import os
import re
import time
import queue
import logging
import threading
from logging.handlers import RotatingFileHandler
from typing import Callable, Optional

try:
    import requests
except Exception:                     # requests is a core dep, but never hard-fail here
    requests = None


# --- severity classification (message-text based) -------------------------------
# CRITICAL = "the engine hit something it cannot resolve and a position's risk may be
# affected" -> the ONLY bucket that buzzes your phone.
CRITICAL_SUBSTRINGS = (
    "arm blocked",           # arm_today refused to arm: stale/missing CSV, no equity
    "manual check",          # exit stuck at max aggression
    "no local record",       # orphan holding with no armed record to adopt against
    "handoff error",         # on_fill / adoption handoff threw -> a fill may be unmanaged
    "orphan_resolver",        # the adoption resolver itself errored
    " error:",               # ANY callback/provider exception: on_tick/on_close/
                             # on_session_open/advance_trading_day/reconcile/
                             # buying_power. A raising on_tick means a held position's
                             # stop is not being evaluated. Every " error:" alert in the
                             # codebase sits inside an exception handler -- there is no
                             # routine one. Broad on purpose: an explicit list would let
                             # a NEW error alert default to WARN silently, which is the
                             # exact defect this line exists to close.
    "exception", "traceback",
)
# INFO = the engine WORKING (never pushes; local log / optional digest).
INFO_SUBSTRINGS = (
    "adopted late-fill", "late fill adopted", "now managed",
    "confirming exit", "closed:", "day10_survivor", "partial_taken", "started;",
)
# Anything else -> WARN (local log, no push). Surfaces in the log, not your pocket.


def classify(message: str) -> str:
    m = (message or "").lower()
    for s in CRITICAL_SUBSTRINGS:
        if s in m:
            return "CRITICAL"
    for s in INFO_SUBSTRINGS:
        if s in m:
            return "INFO"
    return "WARN"


def dedup_key(message: str) -> str:
    """Collapse digits so '51 attempts'/'52 attempts' and '(12/15s)'/'(13/15s)'
    map to the same condition and dedup together."""
    return re.sub(r"\d+", "#", (message or "")).strip()


class Notifier:
    def __init__(self, token: Optional[str] = None, chat_id: Optional[str] = None,
                 log_path: str = "kistrader_alerts.log",
                 push_cooldown_secs: float = 3600.0,
                 heartbeat_secs: float = 900.0,
                 sender: Optional[Callable[[str], bool]] = None):
        self.token = token
        self.chat_id = chat_id
        self.cooldown = float(push_cooldown_secs)
        self.heartbeat_secs = float(heartbeat_secs)
        self._sender = sender or self._telegram_send
        self._last_push: dict[str, float] = {}
        self._lock = threading.Lock()
        self._q: "queue.Queue[str]" = queue.Queue()
        self._status = "starting"
        self._warned_no_creds = False
        self._log = self._make_logger(log_path)

        threading.Thread(target=self._drain, daemon=True).start()
        if self.heartbeat_secs > 0:
            threading.Thread(target=self._heartbeat_loop, daemon=True).start()

    # -- the alert= target -----------------------------------------------------
    def emit(self, message: str):
        """Wire this as alert= on ExecutionMonitor / EntryManager. Never raises."""
        try:
            sev = classify(message)
            self._log.info("%-8s | %s", sev, message)
            if sev == "CRITICAL" and self._should_push(message):
                self._q.put(f"\U0001F6A8 kistrader CRITICAL\n{message}")
        except Exception:
            pass                       # alerting must never crash the trading loop

    # convenience: explicit severities if a caller wants them
    def info(self, message: str):
        try: self._log.info("%-8s | %s", "INFO", message)
        except Exception: pass

    def set_status(self, status: str):
        """Feed the loop's one-line state (e.g. '2 live, phase=OPEN') for heartbeats."""
        self._status = status

    def test(self) -> bool:
        """Send a one-off push to verify the channel end-to-end. Returns True on success."""
        try:
            return bool(self._sender("\u2705 kistrader notifier online ??this is a test push."))
        except Exception:
            return False

    # -- internals -------------------------------------------------------------
    def _should_push(self, message: str) -> bool:
        key = dedup_key(message)
        now = time.monotonic()
        with self._lock:
            last = self._last_push.get(key)
            if last is not None and (now - last) < self.cooldown:
                return False
            self._last_push[key] = now
            return True

    def _drain(self):
        while True:
            text = self._q.get()
            try:
                if not self._sender(text):
                    self._log.warning("PUSH-FAILED | %s", text.replace("\n", " | "))
            except Exception as e:
                self._log.warning("PUSH-ERROR %s | %s", e, text.replace("\n", " | "))
            finally:
                self._q.task_done()

    def _telegram_send(self, text: str) -> bool:
        if not self.token or not self.chat_id:
            if not self._warned_no_creds:
                self._warned_no_creds = True
                self._log.warning("TG creds missing (TG_BOT_TOKEN/TG_CHAT_ID) ??"
                                  "logging only, no push")
            return False
        if requests is None:
            self._log.warning("requests unavailable ??cannot push")
            return False
        url = f"https://api.telegram.org/bot{self.token}/sendMessage"
        for attempt in range(3):
            try:
                r = requests.post(url, json={"chat_id": self.chat_id, "text": text},
                                  timeout=10)
                if r.status_code == 200 and r.json().get("ok"):
                    return True
                self._log.warning("TG HTTP %s: %s", r.status_code, r.text[:200])
            except Exception as e:
                self._log.warning("TG attempt %d failed: %s", attempt + 1, e)
            time.sleep(2 * (attempt + 1))
        return False

    def _heartbeat_loop(self):
        while True:
            time.sleep(self.heartbeat_secs)
            try:
                self._log.info("%-8s | %s", "HEARTBEAT", self._status)
            except Exception:
                pass

    @staticmethod
    def _make_logger(path: str) -> logging.Logger:
        lg = logging.getLogger("kistrader.notifier")
        lg.setLevel(logging.INFO)
        if not lg.handlers:
            try:
                h = RotatingFileHandler(path, maxBytes=2_000_000, backupCount=3,
                                        encoding="utf-8")
            except Exception:
                h = logging.StreamHandler()
            h.setFormatter(logging.Formatter("%(asctime)s %(message)s"))
            lg.addHandler(h)
            lg.propagate = False
        return lg

    @classmethod
    def from_env(cls, **kw) -> "Notifier":
        return cls(token=os.environ.get("TG_BOT_TOKEN"),
                   chat_id=os.environ.get("TG_CHAT_ID"), **kw)
