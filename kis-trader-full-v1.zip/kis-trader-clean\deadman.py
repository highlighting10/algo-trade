#!/usr/bin/env python3
"""
deadman.py — EXTERNAL dead-man's switch for kistrader (Step 6 work item #2).
============================================================================

THE GAP THIS CLOSES: the in-process Notifier can report anything except its own
death. If the loop process dies, silence — no push, no error, nothing. The only
honest detector of "the process stopped" is a SECOND process that watches for
evidence of life and alerts when it stops arriving.

DESIGN RULES (each is load-bearing):

1.  ZERO coupling to the kistrader package. Stdlib only; parses .env itself;
    never imports kistrader. Reason: a watcher that shares code with the thing
    it watches shares its failure modes — a broken venv, a mid-edit repo, or an
    import-time crash would kill both. This file must run when everything else
    is on fire.
2.  FAIL CLOSED on credentials. If TG_BOT_TOKEN / TG_CHAT_ID are missing, it
    REFUSES to watch (unless --dry). A dead-man that cannot alert is worse than
    none: it manufactures false confidence. (Same names the Notifier uses, read
    from the same .env.)
3.  Evidence of life = the WATCHED FILE'S MTIME. Content-agnostic, format-proof.
    Default target: heartbeat.txt, written by PipelineLoop._heartbeat() at the
    end of EVERY cycle in every phase (build_pipeline defaults
    heartbeat_path="heartbeat.txt"; cli.cmd_run passes no override).
    That writer was described here as "pending" long after it shipped, and the
    default stayed on kistrader_alerts.log. Three costs, all avoidable:
      - LATENCY. The alerts log advances on the Notifier's 15-minute beat, so it
        needs a 2100s (35 min) threshold. heartbeat.txt advances every cycle
        (quote_poll_secs=7 OPEN, closed_sleep_secs=30 CLOSED), so 300s buys the
        same confidence: ten consecutive missed CLOSED cycles, ~43 OPEN ones.
      - RENAME HAZARD. Archiving the alerts log (bugB_closed_*.log) makes the
        watched path vanish and fires DOWN on a healthy loop. Nothing renames
        heartbeat.txt.
      - WHAT IT PROVES. The alerts log's mtime proves the Notifier's heartbeat
        THREAD is alive. heartbeat.txt's mtime proves the CYCLE completed -- the
        thing that places orders and manages exits. A daemon thread can keep
        beating while the main loop is wedged, and the old default would report
        FRESH right through it.
    If you point --file back at kistrader_alerts.log, put --stale-secs back to
    2100 with it; the two defaults are a pair.
4.  Alert STATE MACHINE, not a firehose: FRESH->STALE pushes once; while STALE,
    re-push every --renotify-secs (a single missed push must not be the whole
    story); STALE->FRESH pushes RECOVERED (so post-alert silence is
    interpretable). State persists to a small JSON file so --once mode under
    Task Scheduler keeps its dedup across invocations.
5.  NEVER raises. Every send is wrapped; a Telegram failure is printed and the
    watch continues. The watcher outliving errors is the entire point.
6.  Deliberately NO session-clock awareness in v1: run the watcher when the
    engine is supposed to be running (start them together; scheduler window
    later). Duplicating the session clock here would fork "headless time
    correctness" — itself an open Step-6 item — into two places that can drift.

MODES
    python deadman.py --test              one real push now (proves the channel)
    python deadman.py                     watch loop (check every --interval s)
    python deadman.py --once              single check, exit 0 fresh / 1 stale
                                          (Task Scheduler / cron friendly)
    add --dry to any mode                 print instead of pushing (rehearsal)

2-MINUTE END-TO-END DRILL (no engine needed):
    echo hi > hb_drill.txt
    python deadman.py --file hb_drill.txt --stale-secs 60 --interval 10
    ... wait ~60s -> phone buzzes DOWN ...
    echo hi > hb_drill.txt        (in another shell)
    ... phone buzzes RECOVERED -> Ctrl+C. Drill complete.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
import urllib.parse
import urllib.request
from datetime import datetime

# A scheduler redirects stdout to a FILE or a PIPE, and that stream takes
# its encoding from the locale -- cp949 on this box, which cannot encode
# U+2014. Printing a single em dash then raises UnicodeEncodeError and this
# process DIES (exit 1). Measured 2026-09-14: every redirected run crashed
# on its own first log line, while the interactive run was fine because
# Python writes to a Windows console through the UTF-16 API instead.
#
# Pin the encoding so no character in any message can kill the watcher.
# Guarded: sys.stdout is None under pythonw and may already be detached.
for _s in (sys.stdout, sys.stderr):
    try:
        _s.reconfigure(encoding="utf-8", errors="backslashreplace")
    except Exception:                                     # noqa: BLE001
        pass


# ---------------------------------------------------------------- env / creds

def load_env(path: str) -> dict:
    """Minimal KEY=VALUE .env reader. Real environment variables win, so the
    scheduler can inject creds without a file at all."""
    vals = {}
    try:
        with open(path, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                k, v = line.split("=", 1)
                vals[k.strip()] = v.strip().strip('"').strip("'")
    except OSError:
        pass
    vals.update({k: v for k, v in os.environ.items()
                 if k in ("TG_BOT_TOKEN", "TG_CHAT_ID")})
    return vals


def telegram_send(token: str, chat_id: str, text: str) -> bool:
    """POST to Telegram. Returns ok; NEVER raises (rule 5)."""
    try:
        data = urllib.parse.urlencode({"chat_id": chat_id, "text": text}).encode()
        req = urllib.request.Request(
            f"https://api.telegram.org/bot{token}/sendMessage", data=data)
        with urllib.request.urlopen(req, timeout=10) as r:
            return json.loads(r.read().decode() or "{}").get("ok", False)
    except Exception as e:                                    # noqa: BLE001
        print(f"[deadman] telegram send FAILED: {e}", flush=True)
        return False


# ---------------------------------------------------------------- state

# A --dry rehearsal persisted STALE and a fresh last_alert_ts into the SAME
# file the live watcher reads, so the live watcher missed the FRESH->STALE
# edge and suppressed its first DOWN push for a full --renotify-secs. Two
# names, two lifetimes; an explicit --state-file still overrides both.
STATE_FILE = ".deadman_state.json"
DRY_STATE_FILE = ".deadman_state.dry.json"


def load_state(path: str) -> dict:
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except Exception:                                         # noqa: BLE001
        return {"status": "FRESH", "last_alert_ts": 0.0, "stale_since": 0.0}


def save_state(path: str, st: dict) -> None:
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(st, f)
    except Exception as e:                                    # noqa: BLE001
        print(f"[deadman] state save failed (continuing): {e}", flush=True)


# ---------------------------------------------------------------- core check

def file_age(path: str, now: float):
    """(age_seconds, reason) — missing file counts as stale with its own reason."""
    try:
        return now - os.path.getmtime(path), ""
    except OSError:
        return None, "heartbeat file missing"


def evaluate(args, st: dict, now: float, send):
    """One check. Mutates st, returns (is_stale, line_for_console)."""
    age, why = file_age(args.file, now)
    stale = (age is None) or (age > args.stale_secs)
    ts = datetime.now().strftime("%H:%M:%S")

    def fmt_age():
        return why if age is None else f"no write for {int(age)}s (threshold {args.stale_secs}s)"

    if stale and st["status"] == "FRESH":
        st.update(status="STALE", stale_since=now, last_alert_ts=now)
        send(f"[kistrader DEAD-MAN] DOWN? {fmt_age()} -- file: {args.file}. "
             f"Process may have died; no in-process alert can fire.")
        return True, f"{ts}  STALE (alerted): {fmt_age()}"
    if stale and st["status"] == "STALE":
        if now - st["last_alert_ts"] >= args.renotify_secs:
            st["last_alert_ts"] = now
            mins = int((now - st["stale_since"]) / 60)
            send(f"[kistrader DEAD-MAN] STILL DOWN -- stale {mins}m. file: {args.file}")
            return True, f"{ts}  STALE (re-alerted, {mins}m)"
        return True, f"{ts}  STALE (suppressed; next re-alert in "\
                     f"{int(args.renotify_secs - (now - st['last_alert_ts']))}s)"
    if (not stale) and st["status"] == "STALE":
        mins = int((now - st["stale_since"]) / 60)
        st.update(status="FRESH", stale_since=0.0)
        send(f"[kistrader DEAD-MAN] RECOVERED -- heartbeat fresh again after ~{mins}m.")
        return False, f"{ts}  RECOVERED (alerted)"
    return False, f"{ts}  FRESH ({int(age)}s old)"


# ---------------------------------------------------------------- main

def main() -> int:
    ap = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--file", default="heartbeat.txt",
                    help="file whose mtime is the heartbeat (default: the file "
                         "PipelineLoop._heartbeat writes every cycle). Point it "
                         "at kistrader_alerts.log only with --stale-secs 2100.")
    ap.add_argument("--stale-secs", type=int, default=300,
                    help="alert when the file is older than this (default 300 = "
                         "10 missed CLOSED cycles at closed_sleep_secs=30, or "
                         "~43 OPEN ones at quote_poll_secs=7)")
    ap.add_argument("--interval", type=int, default=60,
                    help="watch mode: seconds between checks (default 60)")
    ap.add_argument("--renotify-secs", type=int, default=1800,
                    help="while stale, re-alert this often (default 1800)")
    ap.add_argument("--state-file", default=None,
                    help="dedup state, survives restarts / --once invocations "
                         "(default: %s, or %s under --dry so a rehearsal cannot "
                         "consume the live watcher's FRESH->STALE edge)"
                         % (STATE_FILE, DRY_STATE_FILE))
    ap.add_argument("--env", default=".env", help="path to .env for TG_* creds")
    ap.add_argument("--once", action="store_true",
                    help="single check; exit 0 fresh, 1 stale (for Task Scheduler)")
    ap.add_argument("--dry", action="store_true",
                    help="print alerts instead of pushing (rehearsal / sandbox)")
    ap.add_argument("--test", action="store_true",
                    help="send one real test push and exit")
    args = ap.parse_args()
    if args.state_file is None:
        args.state_file = DRY_STATE_FILE if args.dry else STATE_FILE

    env = load_env(args.env)
    token, chat = env.get("TG_BOT_TOKEN", ""), env.get("TG_CHAT_ID", "")

    if args.dry:
        def send(text):
            print(f"[deadman DRY] would push: {text}", flush=True)
            return True
    else:
        # RULE 2 — fail closed: no creds, no watch.
        if not token or not chat:
            print("[deadman] REFUSING to watch: TG_BOT_TOKEN / TG_CHAT_ID not found "
                  f"in {args.env} or environment. A dead-man that cannot alert is "
                  "false confidence. Fix .env, or rehearse with --dry.", flush=True)
            return 2

        def send(text):
            ok = telegram_send(token, chat, text)
            print(f"[deadman] push {'ok' if ok else 'FAILED'}: {text}", flush=True)
            return ok

    if args.test:
        ok = send("[kistrader DEAD-MAN] test push -- channel verified.")
        return 0 if ok else 1

    st = load_state(args.state_file)
    print(f"[deadman] ARMED  file={args.file}  stale>{args.stale_secs}s  "
          f"mode={'once' if args.once else f'watch/{args.interval}s'}  "
          f"{'DRY' if args.dry else 'push=telegram'}  state={args.state_file}",
          flush=True)

    if args.once:
        stale, line = evaluate(args, st, time.time(), send)
        print(line, flush=True)
        save_state(args.state_file, st)
        return 1 if stale else 0

    try:
        while True:
            _, line = evaluate(args, st, time.time(), send)
            print(line, flush=True)
            save_state(args.state_file, st)
            time.sleep(max(5, args.interval))
    except KeyboardInterrupt:
        print("\n[deadman] stopped by user.", flush=True)
        return 0


if __name__ == "__main__":
    sys.exit(main())
