#!/usr/bin/env python3
"""
Daily-close + EMA providers (§5.4)
==================================

The exit engine's EMA-trail (§4.2.3) and stall-exit (§4.2.4) are built but
DORMANT because on_close needs two per-ticker inputs the run loop doesn't
compute on its own: the latest daily close and the 21-period EMA of daily
closes. This module supplies both, and wires them into RunLoop via
`ema_provider` / `close_provider`.

Design:
  * `ema(values, period)` is a pure function — unit-tested against a hand
    computed series, no data source involved.
  * `DailyCloseEMAProvider` turns an INJECTED daily-close fetch into the two
    callables the run loop wants. The fetch is injectable so tests run offline
    with a fixed series; in production you pass a yfinance-backed fetch.
  * Fetches are cached per (ticker, calendar-day), so a single on_close cycle
    fetches each name at most once per day.
  * Insufficient data / fetch failure -> the provider returns None. The run
    loop calls float(...) on the result inside a try/except, so a None simply
    SKIPS that name's on_close for the day (fail-safe: no stall/trail action on
    missing data), which is the correct degrade.
"""
from __future__ import annotations

import time
from typing import Callable, Optional, Sequence


def ema(values: Sequence[float], period: int) -> float:
    """Classic EMA over `values` (oldest -> newest); returns the final EMA.
    Seeded with the SMA of the first `period` values, then k = 2/(period+1).
    Requires len(values) >= period (raises ValueError otherwise)."""
    if period <= 0:
        raise ValueError("period must be positive")
    if len(values) < period:
        raise ValueError(f"need >= {period} values, got {len(values)}")
    k = 2.0 / (period + 1.0)
    e = sum(values[:period]) / period            # SMA seed
    for v in values[period:]:
        e = v * k + e * (1.0 - k)
    return e


class DailyCloseEMAProvider:
    """Wraps a daily-close fetch into run-loop `close_provider`/`ema_provider`.

    fetch_daily_closes(ticker) -> list[float] of daily closes, OLDEST first,
    NEWEST last (the most recent completed session at the end). Return an empty
    list / raise on failure; the provider converts that to None (skip)."""

    def __init__(self, fetch_daily_closes: Callable[[str], Sequence[float]],
                 ema_period: int = 21, alert: Optional[Callable[[str], None]] = None,
                 today_fn: Callable[[], str] = lambda: time.strftime("%Y-%m-%d"),
                 fetch_daily_bars: Optional[Callable[[str], Sequence]] = None):
        self._fetch = fetch_daily_closes
        self.ema_period = ema_period
        self.alert = alert or (lambda m: None)
        self._today = today_fn
        self._cache: dict = {}                    # ticker -> (day_str, closes)
        # --- PATCH Z (I4) --- optional OHLCV source. Keyword-only in practice:
        # every existing call site passes the close fetch positionally and never
        # this, so they keep the exact behaviour they had. When it IS supplied,
        # closes are DERIVED from the bars so there is one fetch and one cache
        # and close()/ema() cannot disagree with volume()/range_pct().
        self._fetch_bars = fetch_daily_bars
        self._bar_cache: dict = {}                # ticker -> (day_str, bars)

    def _closes(self, ticker: str) -> Optional[list]:
        day = self._today()
        hit = self._cache.get(ticker)
        if hit and hit[0] == day:
            return hit[1]
        # --- PATCH Z (I4) --- one source of truth. With a bars fetch wired, the
        # closes come out of the same bars volume() and range_pct() read, so the
        # two can never describe different sessions.
        if self._fetch_bars is not None:
            bars = self._bars(ticker)
            closes = [float(b["close"]) for b in bars] if bars else None
            self._cache[ticker] = (day, closes)
            return closes
        try:
            raw = self._fetch(ticker)
        except Exception as ex:                   # fetch failure -> UNKNOWN (skip)
            self.alert(f"daily-close fetch failed for {ticker}: {ex}")
            return None
        closes = [float(x) for x in (raw or []) if x is not None]
        closes = closes or None
        self._cache[ticker] = (day, closes)
        return closes

    # --- PATCH Z (I4) --- OHLCV -------------------------------------------
    # Everything below returns None when it cannot answer, exactly as close()
    # and ema() do. A caller that skips on None is already correct.

    @staticmethod
    def _norm_bar(raw) -> Optional[dict]:
        """A mapping with open/high/low/close/volume (any case), or a 5-tuple
        (o, h, l, c, v). Anything else -> None, and the bar is dropped."""
        try:
            if isinstance(raw, dict):
                low = {str(k).lower(): v for k, v in raw.items()}
                o, h, l = low.get("open"), low.get("high"), low.get("low")
                c, v = low.get("close"), low.get("volume")
            elif isinstance(raw, (list, tuple)) and len(raw) >= 5:
                o, h, l, c, v = raw[0], raw[1], raw[2], raw[3], raw[4]
            else:
                return None
            if c is None:
                return None
            bar = {"open": float(o) if o is not None else None,
                   "high": float(h) if h is not None else None,
                   "low": float(l) if l is not None else None,
                   "close": float(c),
                   "volume": float(v) if v is not None else None}
            # NaN is not a value. float('nan') != float('nan') is the only test
            # that works without importing math for one comparison.
            for k, val in bar.items():
                if val is not None and val != val:
                    bar[k] = None
            return None if bar["close"] != bar["close"] else bar
        except (TypeError, ValueError):
            return None

    def _bars(self, ticker: str) -> Optional[list]:
        if self._fetch_bars is None:
            return None
        day = self._today()
        hit = self._bar_cache.get(ticker)
        if hit and hit[0] == day:
            return hit[1]
        try:
            raw = self._fetch_bars(ticker)
        except Exception as ex:                   # same degrade as _closes
            self.alert(f"daily-bar fetch failed for {ticker}: {ex}")
            return None
        bars = [b for b in (self._norm_bar(r) for r in (raw or [])) if b]
        bars = bars or None
        self._bar_cache[ticker] = (day, bars)
        return bars

    def bars(self, ticker: str) -> Optional[list]:
        """Normalised daily bars, oldest first. None without a bars fetch."""
        return self._bars(ticker)

    def volume(self, ticker: str) -> Optional[float]:
        """Latest session volume."""
        bs = self._bars(ticker)
        return bs[-1]["volume"] if bs else None

    def avg_volume(self, ticker: str, n: int = 50) -> Optional[float]:
        """Mean volume over the last n COMPLETE sessions, the latest included.
        None when fewer than n bars carry a volume - a short average is a
        different statistic, not a degraded one."""
        bs = self._bars(ticker)
        if not bs or n <= 0:
            return None
        vols = [b["volume"] for b in bs[-n:] if b["volume"] is not None]
        if len(vols) < n:
            self.alert(f"{ticker}: {len(vols)} of {n} bars carry volume; "
                       f"avg_volume unavailable")
            return None
        return sum(vols) / float(n)

    def volume_ratio(self, ticker: str, n: int = 50) -> Optional[float]:
        """volume / avg_volume(n) -- the comparison P0.1 could not make because
        Avg_Vol_50 is computed by the screener and discarded at the
        Extracted_Pattern boundary (PLAN_20260828 finding #2)."""
        v, a = self.volume(ticker), self.avg_volume(ticker, n)
        if v is None or not a:
            return None
        return v / a

    def range_pct(self, ticker: str) -> Optional[float]:
        """(high - low) / close of the latest bar."""
        bs = self._bars(ticker)
        if not bs:
            return None
        b = bs[-1]
        if b["high"] is None or b["low"] is None or not b["close"]:
            return None
        return (b["high"] - b["low"]) / b["close"]

    def close_location(self, ticker: str) -> Optional[float]:
        """(close - low) / (high - low) of the latest bar, in [0, 1].

        The churning / distribution primitive: a close at the LOW of a wide bar
        on heavy volume is distribution; near the HIGH is accumulation. A
        zero-range bar has no close location and returns None rather than a
        made-up 0.5."""
        bs = self._bars(ticker)
        if not bs:
            return None
        b = bs[-1]
        if b["high"] is None or b["low"] is None:
            return None
        span = b["high"] - b["low"]
        if span <= 0:
            return None
        loc = (b["close"] - b["low"]) / span
        return min(1.0, max(0.0, loc))
    # --- end PATCH Z (I4) ---

    def close(self, ticker: str) -> Optional[float]:
        cs = self._closes(ticker)
        return cs[-1] if cs else None

    def ema(self, ticker: str) -> Optional[float]:
        cs = self._closes(ticker)
        if not cs or len(cs) < self.ema_period:
            if cs is not None and len(cs) < self.ema_period:
                self.alert(f"{ticker}: only {len(cs)} daily closes "
                           f"(< {self.ema_period}); EMA unavailable, on_close skipped")
            return None
        return ema(cs, self.ema_period)

    # -- bind to RunLoop(ema_provider=..., close_provider=...) --
    def as_close_provider(self) -> Callable[[str], Optional[float]]:
        return lambda t: self.close(t)

    def as_ema_provider(self) -> Callable[[str], Optional[float]]:
        return lambda t: self.ema(t)

    # --- PATCH Z (I4) --- one call, everything I5 needs for one ticker.
    def observe(self, ticker: str, avg_window: int = 50) -> dict:
        """Every I4 quantity for one ticker in a single pass over one cached
        fetch. Values are None where unavailable; the dict shape never varies,
        so a log written from it has stable columns from day one."""
        return {
            "ticker": ticker,
            "close": self.close(ticker),
            "ema": self.ema(ticker),
            "volume": self.volume(ticker),
            "avg_volume": self.avg_volume(ticker, avg_window),
            "volume_ratio": self.volume_ratio(ticker, avg_window),
            "range_pct": self.range_pct(ticker),
            "close_location": self.close_location(ticker),
        }
    # --- end PATCH Z (I4) ---


def build_yf_daily_fetch(lookback_days: int = 120):
    """Default production fetch: daily closes from yfinance (oldest->newest).
    Imported lazily so the module (and its tests) don't require yfinance.
    Wire on your machine:  prov = DailyCloseEMAProvider(build_yf_daily_fetch())."""
    def _fetch(ticker: str):
        import yfinance as yf                     # lazy; raises if not installed
        df = yf.Ticker(ticker).history(period=f"{lookback_days}d", interval="1d")
        if df is None or df.empty or "Close" not in df:
            return []
        return [float(x) for x in df["Close"].tolist() if x == x]   # drop NaN
    return _fetch


# --- PATCH Z (I4) ---
def build_yf_daily_bars_fetch(lookback_days: int = 120):
    """Production OHLCV fetch, oldest->newest. Same yfinance call
    `build_yf_daily_fetch` already makes - the frame ALREADY carries Open/High/
    Low/Volume and the close-only version throws them away.

    Wire:  prov = DailyCloseEMAProvider(build_yf_daily_fetch(),
                                        fetch_daily_bars=build_yf_daily_bars_fetch())

    The close fetch stays as the first argument so a bars-side failure degrades
    to close+ema rather than taking the trail and stall exits down with it."""
    def _fetch(ticker: str):
        import yfinance as yf                     # lazy, as above
        df = yf.Ticker(ticker).history(period=f"{lookback_days}d", interval="1d")
        if df is None or df.empty or "Close" not in df:
            return []
        cols = [c for c in ("Open", "High", "Low", "Close", "Volume") if c in df]
        out = []
        for row in df[cols].itertuples(index=False):
            d = dict(zip(cols, row))
            out.append({"open": d.get("Open"), "high": d.get("High"),
                        "low": d.get("Low"), "close": d.get("Close"),
                        "volume": d.get("Volume")})
        return out
    return _fetch
# --- end PATCH Z (I4) ---
