#!/usr/bin/env python3
"""
patch_phase4.py -- PHASE 4: orphan exposure (R3) + fail-closed holdings (D5).

TWO GATES, TWO SOURCES -- the bug this closes

    truth = self.broker.get_all_holdings()
    held  = frozenset(truth) if truth is not None else frozenset()   # broker
    open_notional = sum(p.shares * p.entry_price for p in live)      # LOCAL

held_tickers came from broker truth; open_notional came from our own position
list. A holding the broker reports but we have no record of -- the no-armed-record
orphan reconcile() does not resolve -- was therefore invisible to the exposure
ceiling. The account looks emptier than it is, and the system over-deploys.

AND the read failed OPEN. `truth is None` means UNKNOWN, not flat, but it
degraded to an EMPTY set: the dedup gate stopped seeing holdings, and once
exposure moves onto the same read it would compute as ZERO -- full headroom --
on the one gate with no downstream re-check. (EntryManager.arm_batch re-checks
dedup and alerts; nothing re-checks exposure.) The Production Integration Plan's
Phase 4 as written would have copied that fail-open into the gate it was meant
to fix.

WHAT THIS DOES

1. UNKNOWN holdings -> refuse to arm this pass, loudly. Exits and position
   management are untouched; only new entries stop.

2. Exposure counts EVERY broker-reported holding:
     - known ticker  -> max(broker qty, local shares) x our entry_price.
       Quantity from broker truth, price from our record; the larger share count
       is the conservative direction (more measured exposure -> fewer entries).
     - orphan        -> broker qty x a live quote, resolved through the tradable
       universe. Adopted for ACCOUNTING ONLY. It is never turned into a managed
       Position: the armed record carries the stop, and a managed position with
       no stop is worse than an unmanaged one.
     - a position we track that the broker does not report (the pre-reconcile
       window) is still counted, rather than losing the exposure.

3. An orphan that cannot be priced -> refuse to arm, naming the ticker. Inventing
   a number would silently understate exposure, which is the failure this phase
   exists to remove.

get_all_holdings() returns ticker -> QUANTITY only (engine_v2.py:315), so the
price has to come from somewhere: our record for known names, a quote for
orphans. That is why this is not the one-line change the plan describes.

Anchors are asserted; edits are applied bottom-up.

Usage:  python patch_phase4.py <repo-root>
"""
from __future__ import annotations

import os
import sys

OLD_BLOCK = '''        truth = self.broker.get_all_holdings()
        held = frozenset(truth) if truth is not None else frozenset()
        live = self.positions()
        open_notional = sum(p.shares * p.entry_price for p in live)
'''

NEW_BLOCK = '''        # §R3/D5. UNKNOWN is not flat. This used to degrade to an EMPTY held set,
        # which fails OPEN on both gates that depend on it: dedup stops seeing
        # real holdings, and exposure would measure zero -- full headroom -- with
        # nothing downstream to re-check it.
        truth = self.broker.get_all_holdings()
        if truth is None:
            self.alert("ARM BLOCKED: broker holdings UNREADABLE — cannot measure "
                       "exposure or de-duplicate against real positions. Arming "
                       "NOTHING (fail-safe). Exits and open positions are "
                       "unaffected.")
            return None
        held = frozenset(truth)
        live = self.positions()

        # Exposure is measured from BROKER truth, the same source held_tickers
        # uses -- one source, not two. Every reported holding counts, including
        # ones we have no record of.
        by_ticker = {}
        for p in live:
            by_ticker.setdefault(p.ticker, []).append(p)
        open_notional, unpriced = 0.0, []
        for t, qty in truth.items():
            qty = int(qty or 0)
            if qty <= 0:
                continue
            ps = by_ticker.get(t)
            if ps:
                # quantity from the broker, price from our own record. Taking the
                # LARGER share count is the conservative direction: more measured
                # exposure means fewer new entries, never more.
                open_notional += max(qty, sum(p.shares for p in ps)) * ps[0].entry_price
            else:
                n = self._orphan_notional(t, qty)
                if n is None:
                    unpriced.append(t)
                else:
                    open_notional += n
        # A position we track that the broker does not report yet (the
        # pre-reconcile window) still occupies capital -- count it rather than
        # lose it.
        for p in live:
            if p.ticker not in truth:
                open_notional += p.shares * p.entry_price
        if unpriced:
            self.alert("ARM BLOCKED: broker holds " + ", ".join(sorted(unpriced)) +
                       " with no local record and no usable price — exposure "
                       "cannot be measured, so it cannot be respected. Arming "
                       "NOTHING (fail-safe). Seed or close the position.")
            return None
'''

ORPHAN_FN = '''    def _orphan_notional(self, ticker: str, qty: int):
        """Value a broker holding we have no local record for.

        ACCOUNTING ONLY. This never becomes a managed Position: the armed record
        is what carries the stop, and a managed position with no stop is worse
        than an unmanaged one. It exists so the orphan counts against the
        exposure ceiling instead of being invisible to it.

        Returns None when the name cannot be priced -- unresolvable exchange, a
        failed or zero quote. The caller turns that into a refusal to arm.
        Guessing a value here would understate exposure silently, which is the
        exact failure this phase removes."""
        ex = self.universe.resolve(ticker) if self.universe is not None else "NAS"
        if not ex:
            return None
        try:
            q = self.broker.get_quote(ticker, ex)
        except Exception:                      # noqa: BLE001 — transport failure
            return None
        last = float((q or {}).get("last") or 0)
        return qty * last if last > 0 else None

'''

E8 = '''def test_e8_exposure_from_broker_truth():
    """§R3/D5. held_tickers came from broker truth while open_notional came from
    the LOCAL position list -- two gates, two sources -- so a holding the broker
    reports and we have no record of was invisible to the exposure ceiling. And
    an unreadable holdings read degraded to an EMPTY set, which fails open."""
    print("E8 exposure is measured from broker truth, and UNKNOWN is not flat")
    now = {"t": OPEN_UTC}
    CAND = dict(pivot=100.0, base_low=92.0, last_close=100.0)

    # (a) UNKNOWN holdings -> arm nothing, loudly
    b, db, path, mon, entry, dec, loop, fclk = _assemble(now)
    csv = _write_csv([_cand("MU", **CAND)], path="e2e_expo.csv")
    b._holdings_readable = False
    seen = _capture(loop)
    armed, _rej = loop.arm_today(csv)
    check("holdings UNREADABLE: arms nothing", armed == [], f"{armed}")
    check("holdings UNREADABLE: no order placed", b.place_calls == 0, f"{b.place_calls}")
    check("holdings UNREADABLE: escalated, and says why",
          any("UNREADABLE" in m and "ARM BLOCKED" in m for m in seen), f"{seen}")

    # (b) an orphan the broker reports counts against the ceiling
    b, db, path, mon, entry, dec, loop, fclk = _assemble(now)
    csv = _write_csv([_cand("MU", **CAND)], path="e2e_expo.csv")
    b._holdings = {"ZZZ": 500}          # no local record for ZZZ
    b._price["ZZZ"] = 200.0             # 500 x 200 = 100,000 of exposure
    seen = _capture(loop)
    acct = loop._account_state()
    check("orphan is priced into open_notional",
          acct is not None and abs(acct.open_notional - 100_000.0) < 1e-6,
          f"{acct.open_notional if acct else None}")
    check("orphan is NOT adopted as a managed position",
          all(p.ticker != "ZZZ" for p in loop.positions()),
          f"{[p.ticker for p in loop.positions()]}")
    check("orphan still appears in held_tickers (dedup unchanged)",
          "ZZZ" in acct.held_tickers, f"{acct.held_tickers}")

    # ... and that exposure actually binds the ceiling
    loop.decision = DecisionEngine(replace(loop.decision.cfg,
                                           max_portfolio_exposure_pct=0.5))
    seen = _capture(loop)
    armed, rej = loop.arm_today(csv)
    check("orphan exposure blocks a new entry that would breach the ceiling",
          armed == [] and any("exposure ceiling" in r.reason for r in rej),
          f"armed={armed} rej={[r.reason for r in rej]}")

    # (c) an orphan that cannot be priced -> refuse, naming it
    b, db, path, mon, entry, dec, loop, fclk = _assemble(now)
    csv = _write_csv([_cand("MU", **CAND)], path="e2e_expo.csv")
    b._holdings = {"NOPRICE": 10}
    b.get_quote = lambda t, ex="NAS": {"last": 0}      # zero == unusable
    seen = _capture(loop)
    armed, _rej = loop.arm_today(csv)
    check("unpriceable orphan: arms nothing", armed == [], f"{armed}")
    check("unpriceable orphan: the alert names the ticker",
          any("NOPRICE" in m for m in seen), f"{seen}")

    # (d) for a KNOWN ticker the broker's larger quantity wins
    b, db, path, mon, entry, dec, loop, fclk = _assemble(now)
    _write_csv([_cand("MU", **CAND)], path="e2e_expo.csv")
    pos = Position(ticker="MU", state=PositionState.FILLED, shares=10,
                   entry_price=50.0, stop_loss_price=45.0,
                   initial_risk_per_share=5.0, exchange="NAS",
                   order_key="MU:e8")
    loop._positions.append(pos)
    b._holdings = {"MU": 25}            # broker says 25, we recorded 10
    acct = loop._account_state()
    check("known ticker: the larger (broker) quantity is used",
          abs(acct.open_notional - 25 * 50.0) < 1e-6, f"{acct.open_notional}")

    # (e) a position the broker does not report yet is still counted
    b, db, path, mon, entry, dec, loop, fclk = _assemble(now)
    pos = Position(ticker="MU", state=PositionState.FILLED, shares=10,
                   entry_price=50.0, stop_loss_price=45.0,
                   initial_risk_per_share=5.0, exchange="NAS",
                   order_key="MU:e8b")
    loop._positions.append(pos)
    b._holdings = {}                    # pre-reconcile window
    acct = loop._account_state()
    check("pre-reconcile position still counts against exposure",
          abs(acct.open_notional - 500.0) < 1e-6, f"{acct.open_notional}")


'''


def edit(text, old, new, label):
    n = text.count(old)
    if n != 1:
        raise SystemExit(f"REFUSING: anchor for {label} matched {n} times, expected 1")
    print(f"  ok  {label}")
    return text.replace(old, new)


def read(p):
    with open(p, encoding="utf-8") as f:
        return f.read()


def write(p, s):
    with open(p, "w", encoding="utf-8", newline="") as f:
        f.write(s)


def main(root):
    pl = os.path.join(root, "kistrader", "entry", "pipeline.py")
    te = os.path.join(root, "tests", "test_pipeline_e2e.py")
    for p in (pl, te):
        if not os.path.isfile(p):
            raise SystemExit(f"REFUSING: not found: {p}")
    s, t = read(pl), read(te)
    if "expected_regime_ma" not in s:
        raise SystemExit("REFUSING: Phase 3d has not been applied.")
    if "_orphan_notional" in s or "test_e8_exposure_from_broker_truth" in t:
        raise SystemExit("REFUSING: Phase 4 appears to be applied already.")

    print(f"pipeline.py  ({pl})")
    s = edit(s, OLD_BLOCK, NEW_BLOCK, "_account_state: fail closed + broker-truth exposure")
    s = edit(s, "    def _account_state(self) -> Optional[AccountState]:\n",
             ORPHAN_FN + "    def _account_state(self) -> Optional[AccountState]:\n",
             "add _orphan_notional")
    write(pl, s)

    print(f"test_pipeline_e2e.py  ({te})")
    t = edit(t, "    test_e7_regime_gate()\n",
             "    test_e7_regime_gate()\n    test_e8_exposure_from_broker_truth()\n",
             "register test_e8 in main()")
    t = edit(t, "def test_zz_all_checks_passed():", E8 + "def test_zz_all_checks_passed():",
             "insert test_e8_exposure_from_broker_truth")
    t = edit(t, "from kistrader.entry.exposure_controller import (ExposureController,\n"
                "                                                 ExposureConfig)\n",
             "from kistrader.entry.exposure_controller import (ExposureController,\n"
             "                                                 ExposureConfig)\n"
             "from kistrader.core.engine_v2 import Position\n"
             "from dataclasses import replace\n",
             "e2e: import Position and replace for the exposure tests")
    write(te, t)
    print("\nPHASE 4 APPLIED. R3 closed; UNKNOWN holdings now fail closed.")
    return 0


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("usage: python patch_phase4.py <repo-root>")
    sys.exit(main(sys.argv[1]))
