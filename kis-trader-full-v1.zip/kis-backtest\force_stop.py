"""force_stop.py  —  ONE-SHOT test helper (mock only).

Bumps the persisted stop of a currently-managed position to just above the live
price, so the next real tick in the loop trips `price <= stop` and drives the FULL
exit lifecycle (STOP_HIT -> SELL on the mock -> settle -> CLOSED) on live data.

Only the TRIGGER is engineered; the SELL limit is banded around the live price
(engine_v2 `_band`), so it stays marketable regardless of the stop value.

Usage (mock, US hours), with the run loop STOPPED first:
    python force_stop.py            # bumps NVDA by default
    python force_stop.py TSLA       # bump a different ticker
Then wait ~60s (KIS token cadence) and relaunch:
    python -m kistrader.cli run --no-open-order-check
"""
import sys
from kistrader.config import Config, load_dotenv
from kistrader.core.engine_v2 import EventStore
from kistrader.entry.entry_manager import KISBrokerWithEntry

TICKER = (sys.argv[1] if len(sys.argv) > 1 else "NVDA").upper()
MARGIN = 1.01                       # set stop 1% above spot -> guaranteed trip next tick


def main() -> int:
    load_dotenv()
    c = Config.from_env()
    db = EventStore(c.db_path)
    open_positions = db.load_open_snapshots()
    pos = next((p for p in open_positions if p.ticker == TICKER), None)
    if pos is None:
        live = [p.ticker for p in open_positions]
        print(f"[force_stop] no live/managed {TICKER} snapshot to bump. "
              f"currently managed: {live or 'none'}")
        print("[force_stop] start the loop once so recover() adopts/rehydrates it, "
              "then stop the loop and re-run this.")
        return 2

    broker = KISBrokerWithEntry(c.app_key, c.app_secret, c.cano, is_mock=True)
    q = broker.get_quote(TICKER, pos.exchange)
    last = float(q.get("last") or 0)
    bid = float(q.get("bid") or 0)
    if last <= 0:
        print(f"[force_stop] refusing to bump: quote for {TICKER} came back "
              f"empty/zero ({q}). Try again (quote/token may be transient).")
        return 3

    old_stop = pos.stop_loss_price
    new_stop = round(last * MARGIN, 2)
    pos.stop_loss_price = new_stop
    db.log(pos, f"FORCE_STOP_FOR_TEST:spot={last},bid={bid},old={old_stop},new={new_stop}", last)

    print(f"[force_stop] {TICKER}: spot={last}  bid={bid}")
    print(f"[force_stop] stop {old_stop} -> {new_stop} (persisted as FORCE_STOP_FOR_TEST)")
    print(f"[force_stop] shares held (snapshot)={pos.shares}  state={pos.state.value}")
    print("[force_stop] DONE. Wait ~60s, then relaunch:")
    print("             python -m kistrader.cli run --no-open-order-check")
    print("[force_stop] Expect on next tick: EXIT_BEGIN:STOP_HIT -> SELL placed -> "
          "EXIT_FILL/EXIT_SETTLE_WAIT -> CLOSED:STOP_HIT")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
