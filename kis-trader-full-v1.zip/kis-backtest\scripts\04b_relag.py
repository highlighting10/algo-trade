"""
04b_relag.py -- produce a lagged signal file from an EXISTING one. Seconds, not hours.

A delivery lag is a pure re-keying: shift_signal_dates() moves each date's
candidate list forward N sessions and touches nothing else. The candidates
themselves are identical, because they were computed from data through their
original date either way.

So DO NOT re-run 04_signals.py just to change --lag. That recomputes ~880,000
Stage-1 scans and ~100,000 VCP reports to produce a dictionary you already have.

Usage:
    python scripts/04b_relag.py --lag 1
    python scripts/04b_relag.py --lag 1 --in data/signals.pkl --out data/signals_lag1.pkl
"""
import pathlib as _pl
import sys as _sys
_sys.path.insert(0, str(_pl.Path(__file__).resolve().parent.parent))

import argparse
import pathlib
import pickle

import pandas as pd

from signals import PITBars, shift_signal_dates


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--lag", type=int, required=True)
    ap.add_argument("--in", dest="src", default="data/signals.pkl")
    ap.add_argument("--out", dest="dst", default=None)
    args = ap.parse_args()
    dst = args.dst or f"data/signals_lag{args.lag}.pkl"

    with open(args.src, "rb") as f:
        blob = pickle.load(f)
    sigs = blob["signals"]
    base_lag = blob.get("lag", 0)
    if base_lag:
        print(f"[relag] WARNING: source already carries lag={base_lag}. Re-lagging "
              f"would compound it. Re-lag from the lag=0 file instead.")
        raise SystemExit(1)

    # the calendar must come from the bars, not from the signal dates -- signals
    # only exist on scan dates, and shifting must step over REAL sessions
    bars = {p.stem: pd.read_parquet(p, columns=["Close"])
            for p in pathlib.Path("data/bars").glob("*.parquet")}
    cal = PITBars(bars).calendar()

    before = sum(len(v) for v in sigs.values())
    out = shift_signal_dates(sigs, cal, args.lag)
    after = sum(len(v) for v in out.values())

    src_dates = sorted(sigs)
    dst_dates = sorted(out)
    print(f"[relag] lag {args.lag}: {len(src_dates)} -> {len(dst_dates)} date(s), "
          f"{before} -> {after} candidate(s)")
    for a, b in list(zip(src_dates, dst_dates))[:3]:
        print(f"[relag]   {a.date()} -> {b.date()}")

    blob["signals"] = out
    blob["lag"] = args.lag
    blob["relagged_from"] = args.src
    with open(dst, "wb") as f:
        pickle.dump(blob, f)
    print(f"[relag] wrote {dst}")


if __name__ == "__main__":
    main()
