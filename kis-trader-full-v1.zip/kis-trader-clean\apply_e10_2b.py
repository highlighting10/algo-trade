#!/usr/bin/env python3
"""
apply_e10_2b.py -- E10 layer 2b: a close counts only if the STRATEGY made it.

THE HOLE THIS CLOSES, measured on the box's own database 2026-09-19:

    HPE:2026-08-20   SEEDED_ENTRY_ARMED:manual   -- a hand-seeded test position

That is not a trade the strategy made. It sat in the same CLOSED: set the loss
streak reads. It happened to come back NaN because its seeded geometry put the
stop ABOVE the entry (initial_risk_per_share = -1.0440), which the risk<=0
guard caught BY ACCIDENT. seed_position also seeds normal geometry -- MU
100.00/92.00 at +8.0 R/share in test_seed_position -- and a seed like that
scores as an ordinary trade. Seed three, let them stop out, and the gate clamps
LIVE exposure to 25% on data the strategy never generated.

THE RULE

    a close counts only if its order_key also carries an ENTRY_ event

ENTRY_ is entry_manager's own namespace: ENTRY_ARMED, ENTRY_ADOPT,
ENTRY_LATE_FILL_ADOPTED, ENTRY_HELD_CONFIRMED, ENTRY_SETTLE_WAIT,
ENTRY_CANCELLED. A seed writes SEEDED_ENTRY_ARMED and SEEDED_FILL -- neither
starts with ENTRY_. Verified against all four real closes on the box: three
count, the seed does not.

It is an ALLOWLIST on purpose. A denylist of known manual tools leaks the
moment someone adds a new one; an allowlist needs future tools only to NOT
write ENTRY_, which is the safer default. It also anchors on the ENTRY, not the
exit -- so a real trade you force-close by hand still counts, correctly.

SKIPPED, NOT NaN. NaN ENDS a streak, so one seeded position would silently
clear a genuine run of losses -- the same contamination, reversed. A skip is
invisible and the count continues past it.

    python apply_e10_2b.py --verify              # check only, no writes
    python apply_e10_2b.py --verify-real DB      # run it against REAL data
    python apply_e10_2b.py                       # apply
    python apply_e10_2b.py --revert              # byte-exact undo

Run from the repo root (kis-trader-clean), on branch e10-progressive-exposure.
Requires layer 2 (a36c38a) to be applied.
"""
from __future__ import annotations

import argparse
import json
import math
import os
import subprocess
import sys
import tempfile

REPO_BRANCH = "e10-progressive-exposure"

F_ENGINE = os.path.join("kistrader", "core", "engine_v2.py")
F_PIPE = os.path.join("kistrader", "entry", "pipeline.py")
F_ENTRY = os.path.join("kistrader", "entry", "entry_manager.py")

SENTINEL = "on_skip"

# The assumption the whole rule rests on: ENTRY_ARMED is logged under the BARE
# order_key. entry_manager uses key_override elsewhere ('{key}:ENTRY',
# '{key}:WATCH'); one added here would break provenance with no error anywhere.
ENTRY_ARMED_CALL = 'self.db.log(pos, "ENTRY_ARMED", plan.limit_price, res["order_id"])'

# Plain-text shapes of the two new alerts. The verify also asserts the
# distinctive fragment of each is really in the patched source, so a reworded
# alert cannot pass by leaving the probe behind.
SEEDED_ALERT_PROBE = ("loss-streak: skipped 1 manually seeded close(s) -- not "
                      "strategy trades, so they do not move the ceiling "
                      "(HPE:2026-08-20)")
UNKNOWN_ALERT_PROBE = ("loss-streak: 1 close(s) of UNKNOWN provenance -- no "
                       "ENTRY_ and no SEEDED_ event on the key, so they were "
                       "SKIPPED and the streak may be wrong. manual check: "
                       "either a new entry path or a pruned log (X:1)")

# --------------------------------------------------------------------------
# 1. engine_v2.py -- provenance inside the read
# --------------------------------------------------------------------------

ENGINE_OLD = '''    # --- E10 layer 2 2026-09-19 --- progressive exposure reads OUR OWN trades.
    def recent_closed_r(self, limit: int = 20) -> list:
'''

ENGINE_NEW = '''    # --- E10 layer 2 2026-09-19 --- progressive exposure reads OUR OWN trades.
    # --- E10 layer 2b --- ...and only the ones the STRATEGY made.
    def recent_closed_r(self, limit: int = 20, on_skip=None) -> list:
'''

ENGINE_BODY_OLD = '''        n = max(1, int(limit))
        rows = self.conn.execute(
            "SELECT order_key, price, payload FROM position_events "
            "WHERE event_type LIKE 'CLOSED:%' AND payload IS NOT NULL "
            "ORDER BY id DESC LIMIT ?", (n * 4,)).fetchall()
        out, seen = [], set()
        for order_key, price, payload in rows:
            if order_key in seen:
                continue          # one trade, one verdict; newest event wins.
            seen.add(order_key)   # a re-adopted key must not count twice --
            try:                  # two rows would fire the gate a rung early.
                d = json.loads(payload)
                risk = float(d.get("initial_risk_per_share") or 0.0)
                if d.get("partial_done") or risk <= 0 or price is None:
                    out.append(float("nan"))
                else:
                    out.append((float(price) - float(d["entry_price"])) / risk)
            except (ValueError, TypeError, KeyError):
                out.append(float("nan"))
            if len(out) >= n:
                break
        return out
'''

ENGINE_BODY_NEW = '''        n = max(1, int(limit))
        rows = self.conn.execute(
            "SELECT order_key, price, payload FROM position_events "
            "WHERE event_type LIKE 'CLOSED:%' AND payload IS NOT NULL "
            "ORDER BY id DESC LIMIT ?", (n * 4,)).fetchall()
        ordered, seen = [], set()
        for order_key, price, payload in rows:
            if order_key in seen:
                continue          # one trade, one verdict; newest event wins.
            seen.add(order_key)   # a re-adopted key must not count twice --
            ordered.append((order_key, price, payload))   # two rows would fire
            if len(ordered) >= n:                         # the gate a rung early
                break
        if not ordered:
            return []

        # --- E10 layer 2b --- PROVENANCE, bounded to the keys actually read.
        #
        # THE PATTERN IS ANCHORED AND THE UNDERSCORE IS ESCAPED. Both matter:
        #   * '%ENTRY_ARMED%' MATCHES 'SEEDED_ENTRY_ARMED:manual' -- the exact
        #     row this rule exists to exclude. A leading % reopens the hole
        #     while looking like it is filtering.
        #   * in SQLite LIKE, '_' is a single-character wildcard, so 'ENTRY_%'
        #     without ESCAPE also matches 'ENTRYX...'.
        #
        # THIS RESTS ON ENTRY_ARMED BEING LOGGED UNDER THE BARE order_key.
        # entry_manager uses key_override elsewhere ("{key}:ENTRY",
        # "{key}:WATCH"); adding one to ENTRY_ARMED would break provenance
        # with no error anywhere. apply_e10_2b.py --verify asserts it.
        #
        # KNOWN HAZARD, UNFIXED: pruning position_events would strip old
        # ENTRY_ rows while CLOSED: rows survive, turning real trades into
        # "unknown provenance". Nothing here guards that -- the unknown-
        # provenance alert is what would tell you it happened.
        keys = [k for k, _p, _pay in ordered]
        marks = {}
        q = ("SELECT DISTINCT order_key, "
             "CASE WHEN event_type LIKE 'ENTRY!_%' ESCAPE '!' "
             "THEN 1 ELSE 0 END "
             "FROM position_events "
             "WHERE (event_type LIKE 'ENTRY!_%' ESCAPE '!' "
             "OR event_type LIKE 'SEEDED!_%' ESCAPE '!') "
             "AND order_key IN (" + ",".join("?" * len(keys)) + ")")
        for k, is_entry in self.conn.execute(q, keys):
            marks[k] = max(marks.get(k, 0), int(is_entry))

        out = []
        for order_key, price, payload in ordered:
            mark = marks.get(order_key)
            if mark != 1:
                # SKIPPED, never NaN: NaN would END the streak, so one seeded
                # position would silently clear a genuine run of losses.
                if on_skip is not None:
                    try:
                        on_skip(order_key,
                                "seeded" if mark == 0 else "unknown")
                    except Exception:     # noqa: BLE001 -- a report must never
                        pass              # break the read it reports on
                continue
            try:
                d = json.loads(payload)
                risk = float(d.get("initial_risk_per_share") or 0.0)
                if d.get("partial_done") or risk <= 0 or price is None:
                    out.append(float("nan"))
                else:
                    out.append((float(price) - float(d["entry_price"])) / risk)
            except (ValueError, TypeError, KeyError):
                out.append(float("nan"))
        return out
'''

ENGINE_DOC_OLD = '''        RECONCILE_CLOSED is NOT included at all: that path logs at entry_price
        because the exit price is genuinely unknown, so it would enter as a
        fabricated 0.0.
'''

ENGINE_DOC_NEW = '''        RECONCILE_CLOSED is NOT included at all: that path logs at entry_price
        because the exit price is genuinely unknown, so it would enter as a
        fabricated 0.0.

        PROVENANCE (layer 2b). A close is SKIPPED ENTIRELY -- not scored, not
        NaN -- unless its order_key also carries an ENTRY_ event, which is
        entry_manager's namespace for a strategy entry. A hand-seeded position
        writes SEEDED_ENTRY_ARMED / SEEDED_FILL instead and is not a trade the
        strategy made. `on_skip(order_key, kind)` reports each one; kind is
        "seeded" (a known manual entry) or "unknown" (neither marker present --
        a new code path or a pruned log, and the streak may be wrong).
'''

# --------------------------------------------------------------------------
# 2. pipeline.py -- report the skips, graded by cause
# --------------------------------------------------------------------------

PIPE_OLD = '''            try:
                streak = loss_streak_from(self.mon.db.recent_closed_r())
            except Exception as _e:            # noqa: BLE001 -- see below
'''

PIPE_NEW = '''            try:
                # --- E10 layer 2b --- a skip must never be silent. Two of the
                # four errors on 2026-09-19 were a filter dropping rows with
                # nothing saying so; a gate quietly not biting is the same
                # shape. Graded by cause: a seed is routine, an unexplained
                # close is not.
                _skipped = {"seeded": [], "unknown": []}
                streak = loss_streak_from(self.mon.db.recent_closed_r(
                    on_skip=lambda k, why: _skipped[why].append(k)))
                _sd, _un = _skipped["seeded"], _skipped["unknown"]
                if _sd:
                    # WARN: log only. Excluding a seed is correct behaviour.
                    self.alert("loss-streak: skipped %d manually seeded "
                               "close(s) -- not strategy trades, so they do "
                               "not move the ceiling (%s)"
                               % (len(_sd), ", ".join(_sd)))
                if _un:
                    # CRITICAL via "manual check": neither ENTRY_ nor SEEDED_
                    # means a code path nobody registered, or a pruned log.
                    # Both change what the gate is doing.
                    self.alert("loss-streak: %d close(s) of UNKNOWN "
                               "provenance -- no ENTRY_ and no SEEDED_ event "
                               "on the key, so they were SKIPPED and the "
                               "streak may be wrong. manual check: either a "
                               "new entry path or a pruned log (%s)"
                               % (len(_un), ", ".join(_un)))
            except Exception as _e:            # noqa: BLE001 -- see below
'''

EDITS = [
    (F_ENGINE, ENGINE_OLD, ENGINE_NEW),
    (F_ENGINE, ENGINE_DOC_OLD, ENGINE_DOC_NEW),
    (F_ENGINE, ENGINE_BODY_OLD, ENGINE_BODY_NEW),
    (F_PIPE, PIPE_OLD, PIPE_NEW),
]


# --------------------------------------------------------------------------
# machinery
# --------------------------------------------------------------------------

def _ascii_guard():
    for name, txt in (("ENGINE_NEW", ENGINE_NEW), ("ENGINE_DOC_NEW", ENGINE_DOC_NEW),
                      ("ENGINE_BODY_NEW", ENGINE_BODY_NEW), ("PIPE_NEW", PIPE_NEW)):
        try:
            txt.encode("ascii")
        except UnicodeEncodeError as e:
            raise SystemExit(f"patch text {name} is not pure ASCII: {e}")


def _read(path):
    with open(path, encoding="utf-8") as fh:
        return fh.read()


def _write(path, text):
    compile(text, path, "exec")
    d = os.path.dirname(os.path.abspath(path))
    fd, tmp = tempfile.mkstemp(dir=d, suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as fh:
            fh.write(text)
        os.replace(tmp, path)
    except BaseException:
        if os.path.exists(tmp):
            os.unlink(tmp)
        raise


def _branch():
    try:
        r = subprocess.run(["git", "rev-parse", "--abbrev-ref", "HEAD"],
                           capture_output=True, text=True, timeout=5)
        return r.stdout.strip() if r.returncode == 0 else ""
    except Exception:                      # noqa: BLE001
        return ""


def check_branch(force):
    b = _branch()
    if force or b == REPO_BRANCH:
        print(f"  branch = {b or '(unknown)'}")
        return
    raise SystemExit(f"REFUSING: on branch {b!r}, expected {REPO_BRANCH!r}. "
                     f"Re-run with --force-branch if you really mean it.")


def applied_state():
    hits = 0
    for path, _old, new in EDITS:
        if not os.path.isfile(path):
            raise SystemExit(f"missing file: {path} (run from the repo root)")
        hits += 1 if new in _read(path) else 0
    return hits, len(EDITS)


def apply(revert=False):
    if "def recent_closed_r" not in _read(F_ENGINE):
        raise SystemExit("layer 2 is NOT applied (no recent_closed_r). "
                         "2b patches layer 2; apply a36c38a first.")
    hits, total = applied_state()
    if not revert and hits == total:
        raise SystemExit(f"already applied (all {total} edits present)")
    if not revert and hits:
        raise SystemExit(f"PARTIAL state: {hits}/{total}. Refusing to patch "
                         f"on top. Use --revert or fix by hand.")
    if revert and hits == 0:
        raise SystemExit(f"not applied (0/{total}) -- nothing to revert")
    if revert and hits != total:
        raise SystemExit(f"PARTIAL state: {hits}/{total}. Refusing to revert "
                         f"half a patch.")

    by_file = {}
    for path, old, new in EDITS:
        by_file.setdefault(path, []).append((new, old) if revert else (old, new))
    for path, ops in by_file.items():
        text = _read(path)
        for src, dst in ops:
            c = text.count(src)
            if c != 1:
                raise SystemExit(f"anchor in {path} matched {c} times, "
                                 f"expected 1:\n---\n{src[:200]}\n---")
            text = text.replace(src, dst, 1)
        _write(path, text)
        print(f"  {'reverted' if revert else 'patched '} {path}  "
              f"({len(ops)} edit(s))")
    print("REVERTED." if revert else "APPLIED.")


# --------------------------------------------------------------------------
# verify
# --------------------------------------------------------------------------

class V:
    def __init__(self):
        self.p = self.f = 0

    def check(self, label, cond, detail=""):
        ok = bool(cond)
        self.p += ok
        self.f += (not ok)
        print(f"  {'PASS' if ok else 'FAIL'}  {label}"
              + (f"   {detail}" if detail and not ok else ""))

    def done(self):
        print(f"\n  {self.p}/{self.p + self.f} checks passed")
        return 0 if self.f == 0 else 1


_OPEN = []


def _store(d):
    from kistrader.core.engine_v2 import EventStore
    st = EventStore(os.path.join(d, "v.db"))
    _OPEN.append(st)
    return st


def _close_stores():
    while _OPEN:
        try:
            _OPEN.pop().conn.close()
        except Exception:                  # noqa: BLE001
            pass


def _ins(st, key, et, price=None, pay=None):
    st.conn.execute(
        "INSERT INTO position_events (ticker, order_key, event_type, state_to,"
        " shares, price, broker_order_id, payload) VALUES (?,?,?,?,?,?,?,?)",
        (key.split(":")[0], key, et, "X", 0, price,
         None, json.dumps(pay) if pay is not None else None))
    st.conn.commit()


def _pay(entry=100.0, risk=10.0, partial=False):
    return {"entry_price": entry, "initial_risk_per_share": risk,
            "partial_done": partial}


def _mkdir(root, name):
    p = os.path.join(root, name)
    os.makedirs(p, exist_ok=True)
    return p


def verify():
    _ascii_guard()
    v = V()

    for i, (path, _old, new) in enumerate(EDITS, 1):
        src = _read(path)
        v.check(f"edit {i}/{len(EDITS)} present exactly once in "
                f"{os.path.basename(path)}", src.count(new) == 1,
                f"count={src.count(new)}")

    eng, pipe = _read(F_ENGINE), _read(F_PIPE)
    v.check("sentinel present", eng.count(SENTINEL) >= 1 and SENTINEL in pipe)
    # Targets the SQL, not the file: the comment above the query QUOTES the
    # bad pattern in order to warn about it, and a naive grep fails on that.
    v.check("pattern is ANCHORED (no leading wildcard in the SQL)",
            "LIKE '%ENTRY" not in eng and 'LIKE "%ENTRY' not in eng
            and "'ENTRY!_%' ESCAPE '!'" in eng)
    v.check("underscore is ESCAPED", eng.count("ESCAPE '!'") >= 3)
    v.check("skip is a continue, never a NaN append",
            'on_skip(order_key,' in eng and '"seeded" if mark == 0' in eng)
    v.check("seeded alert fragment in source",
            '"loss-streak: skipped %d manually seeded "' in pipe)
    v.check("unknown alert fragment in source",
            '"loss-streak: %d close(s) of UNKNOWN "' in pipe)

    # THE ASSUMPTION THE RULE RESTS ON.
    ent = _read(F_ENTRY)
    v.check("ENTRY_ARMED is logged under the BARE order_key (no key_override)",
            ent.count(ENTRY_ARMED_CALL) == 1,
            "entry_manager changed -- provenance would break silently")

    for p in (F_ENGINE, F_PIPE):
        try:
            compile(_read(p), p, "exec")
            v.check(f"compiles: {os.path.basename(p)}", True)
        except SyntaxError as e:
            v.check(f"compiles: {os.path.basename(p)}", False, str(e))

    sys.path.insert(0, os.getcwd())
    from kistrader.notifier import classify
    from kistrader.entry.exposure_controller import loss_streak_from

    v.check("seeded alert is WARN (log only)",
            classify(SEEDED_ALERT_PROBE) == "WARN", classify(SEEDED_ALERT_PROBE))
    v.check("unknown-provenance alert is CRITICAL (pushes)",
            classify(UNKNOWN_ALERT_PROBE) == "CRITICAL",
            classify(UNKNOWN_ALERT_PROBE))

    import tempfile as _tf
    with _tf.TemporaryDirectory(ignore_cleanup_errors=True) as td:
        # A strategy trade counts.
        st = _store(_mkdir(td, "a"))
        _ins(st, "AAA:1", "ENTRY_ARMED")
        _ins(st, "AAA:1", "CLOSED:STOP_HIT", 90.0, _pay())
        got = st.recent_closed_r()
        v.check("ENTRY_ARMED -> counts",
                len(got) == 1 and abs(got[0] + 1.0) < 1e-9, str(got))

        # Every ENTRY_ flavour the real box has written counts.
        st2 = _store(_mkdir(td, "b"))
        for i, et in enumerate(("ENTRY_ADOPT", "ENTRY_HELD_CONFIRMED",
                                "ENTRY_SETTLE_WAIT", "ENTRY_CANCELLED:gone",
                                "ENTRY_LATE_FILL_ADOPTED:held=12,armed=0")):
            _ins(st2, f"B{i}:1", et)
            _ins(st2, f"B{i}:1", "CLOSED:STOP_HIT", 90.0, _pay())
        v.check("every real ENTRY_ flavour counts",
                len(st2.recent_closed_r()) == 5, str(st2.recent_closed_r()))

        # POSITIVE CONTROL 1: the seed is excluded, and reported as "seeded".
        st3 = _store(_mkdir(td, "c"))
        _ins(st3, "HPE:2026-08-20", "SEEDED_ENTRY_ARMED:manual")
        _ins(st3, "HPE:2026-08-20", "SEEDED_FILL:60@53.956")
        _ins(st3, "HPE:2026-08-20", "CLOSED:STOP_HIT", 53.0, _pay(54.0, 2.0))
        seen = []
        got = st3.recent_closed_r(on_skip=lambda k, w: seen.append((k, w)))
        v.check("POSITIVE CONTROL seed is SKIPPED, not scored", got == [], str(got))
        v.check("POSITIVE CONTROL seed reported as 'seeded'",
                seen == [("HPE:2026-08-20", "seeded")], str(seen))

        # POSITIVE CONTROL 2: an unanchored pattern would have let it back in.
        n_anchored = st3.conn.execute(
            "SELECT COUNT(*) FROM position_events WHERE event_type "
            "LIKE 'ENTRY!_%' ESCAPE '!'").fetchone()[0]
        n_loose = st3.conn.execute(
            "SELECT COUNT(*) FROM position_events WHERE event_type "
            "LIKE '%ENTRY!_ARMED%' ESCAPE '!'").fetchone()[0]
        v.check("POSITIVE CONTROL unanchored '%ENTRY_ARMED%' WOULD match the "
                "seed", n_anchored == 0 and n_loose == 1,
                f"anchored={n_anchored} loose={n_loose}")

        # Unknown provenance: neither marker.
        st4 = _store(_mkdir(td, "d"))
        _ins(st4, "X:1", "CLOSED:STOP_HIT", 90.0, _pay())
        seen = []
        got = st4.recent_closed_r(on_skip=lambda k, w: seen.append((k, w)))
        v.check("no marker at all -> SKIPPED", got == [], str(got))
        v.check("...and reported as 'unknown', not 'seeded'",
                seen == [("X:1", "unknown")], str(seen))

        # THE POINT: a seed must not clear a real losing streak.
        st5 = _store(_mkdir(td, "e"))
        for i in range(3):
            _ins(st5, f"R{i}:1", "ENTRY_ARMED")
            _ins(st5, f"R{i}:1", "CLOSED:STOP_HIT", 90.0, _pay())
        _ins(st5, "SEED:1", "SEEDED_ENTRY_ARMED:manual")       # newest
        _ins(st5, "SEED:1", "CLOSED:STOP_HIT", 99.0, _pay())   # a WINNER seed
        v.check("a seeded WINNER does not reset a real 3-loss streak",
                loss_streak_from(st5.recent_closed_r()) == 3,
                str(st5.recent_closed_r()))

        # ...and the pre-2b behaviour would have. Control for the control.
        pre = st5.conn.execute(
            "SELECT COUNT(*) FROM position_events "
            "WHERE event_type LIKE 'CLOSED:%'").fetchone()[0]
        v.check("...where pre-2b would have seen 4 closes and returned 0",
                pre == 4)

        # A raising on_skip must not break the read.
        st6 = _store(_mkdir(td, "f"))
        _ins(st6, "S:1", "SEEDED_ENTRY_ARMED:manual")
        _ins(st6, "S:1", "CLOSED:STOP_HIT", 90.0, _pay())
        _ins(st6, "T:1", "ENTRY_ARMED")
        _ins(st6, "T:1", "CLOSED:STOP_HIT", 90.0, _pay())
        def _boom(k, w):
            raise RuntimeError("reporting must not break the read")
        got = st6.recent_closed_r(on_skip=_boom)
        v.check("a raising on_skip is swallowed; the read still returns",
                len(got) == 1, str(got))

        # Default on_skip=None stays silent and behaves identically.
        v.check("on_skip=None is silent and unchanged",
                len(st6.recent_closed_r()) == 1)

        # Empty store still returns [] without running the IN query.
        st7 = _store(_mkdir(td, "g"))
        v.check("empty store -> []", st7.recent_closed_r() == [])

        # A key with BOTH markers counts (entry wins over seeded).
        st8 = _store(_mkdir(td, "h"))
        _ins(st8, "U:1", "SEEDED_ENTRY_ARMED:manual")
        _ins(st8, "U:1", "ENTRY_ARMED")
        _ins(st8, "U:1", "CLOSED:STOP_HIT", 90.0, _pay())
        v.check("both markers -> counts (ENTRY_ wins)",
                len(st8.recent_closed_r()) == 1)

        # NaN paths from layer 2 still work through the new structure.
        st9 = _store(_mkdir(td, "i"))
        _ins(st9, "P:1", "ENTRY_ARMED")
        _ins(st9, "P:1", "CLOSED:EMA_BREAK", 130.0, _pay(partial=True))
        got = st9.recent_closed_r()
        v.check("layer 2 partial_done -> still NaN",
                len(got) == 1 and math.isnan(got[0]), str(got))

        _close_stores()

    return v.done()


# --------------------------------------------------------------------------
# verify against REAL data
# --------------------------------------------------------------------------

LIVE_NAME = "kis_engine_state.db"


def verify_real(db):
    """Run the patched read against a COPY of the box's event store, and show
    what changed. This is the only check that uses payloads I did not write."""
    if not os.path.isfile(db):
        raise SystemExit(f"no such database: {db}")
    if os.path.basename(db) == LIVE_NAME:
        raise SystemExit(f"REFUSING: {db} is the live database name. "
                         f"EventStore writes on open. Use a copy.")
    sys.path.insert(0, os.getcwd())
    from kistrader.core.engine_v2 import EventStore
    from kistrader.entry.exposure_controller import (
        DEFAULT_LOSS_STREAK_CEILINGS, loss_streak_from, streak_ceiling)

    st = EventStore(db)

    # Pre-2b: score every close, no provenance. Recomputed here rather than
    # remembered, so the comparison is against this database, not a story.
    pre = []
    rows = st.conn.execute(
        "SELECT order_key, price, payload FROM position_events "
        "WHERE event_type LIKE 'CLOSED:%' AND payload IS NOT NULL "
        "ORDER BY id DESC").fetchall()
    seen = set()
    for key, price, payload in rows:
        if key in seen:
            continue
        seen.add(key)
        try:
            d = json.loads(payload)
            risk = float(d.get("initial_risk_per_share") or 0.0)
            if d.get("partial_done") or risk <= 0 or price is None:
                pre.append((key, float("nan")))
            else:
                pre.append((key, (float(price) - float(d["entry_price"])) / risk))
        except (ValueError, TypeError, KeyError):
            pre.append((key, float("nan")))

    skips = []
    post = st.recent_closed_r(limit=200,
                              on_skip=lambda k, w: skips.append((k, w)))
    st.conn.close()

    print("=" * 78)
    print(f"LAYER 2b AGAINST REAL DATA -- {db}")
    print("=" * 78)
    print(f"\n  BEFORE 2b: {len(pre)} close(s) scored")
    for k, r in pre:
        print(f"      {k:<24} {'NaN' if math.isnan(r) else '%+.3f R' % r}")
    print(f"\n  AFTER 2b:  {len(post)} close(s) scored, {len(skips)} skipped")
    for k, w in skips:
        print(f"      SKIPPED  {k:<24} ({w})")
    print(f"      values = {[('NaN' if math.isnan(x) else '%+.2f' % x) for x in post]}")

    s_pre = loss_streak_from([r for _k, r in pre])
    s_post = loss_streak_from(post)
    print("\n" + "-" * 78)
    print(f"  loss_streak  BEFORE {s_pre}  ->  AFTER {s_post}")
    print(f"  ceiling      BEFORE {streak_ceiling(DEFAULT_LOSS_STREAK_CEILINGS, s_pre):.2f}"
          f"  ->  AFTER {streak_ceiling(DEFAULT_LOSS_STREAK_CEILINGS, s_post):.2f}")
    unknown = [k for k, w in skips if w == "unknown"]
    if unknown:
        print(f"\n  *** {len(unknown)} close(s) of UNKNOWN provenance: {unknown}")
        print("      Neither ENTRY_ nor SEEDED_. Investigate before trusting")
        print("      this streak -- a new entry path, or a pruned log.")
    print("\n  Read-only. Nothing traded, nothing written to the box.")
    print("=" * 78)
    return 0


def main(argv=None):
    ap = argparse.ArgumentParser(description="E10 layer 2b -- strategy provenance")
    ap.add_argument("--verify", action="store_true")
    ap.add_argument("--verify-real", metavar="DB",
                    help="run the patched read against a COPY of the box store")
    ap.add_argument("--revert", action="store_true")
    ap.add_argument("--force-branch", action="store_true")
    a = ap.parse_args(argv)
    _ascii_guard()
    if a.verify_real:
        return verify_real(a.verify_real)
    if a.verify:
        return verify()
    check_branch(a.force_branch)
    apply(revert=a.revert)
    return 0


if __name__ == "__main__":
    sys.exit(main())
