# FINDING — 2026-09-14: supervisor and dead-man are BUILT. What's missing is evidence, not code.

**The handoff is wrong in two places.** §7 lists "No external dead-man's-switch yet" as a known
deferred issue, §11 lists it as Step 6 work item #2, and the completion table says
*Supervisor / auto-restart ~10%*.

Both files exist, complete, in the repo root:

| file | bytes | state |
|---|---|---|
| `supervisor.py` | 8,677 | full implementation |
| `deadman.py` | 10,693 | full implementation |

Neither is ~10%. What is at 0% is **evidence**: no test module exists for either, neither appears in
`cli.py`'s test tuple, and nothing in `kistrader/` imports them. By that tuple's own stated rule —
*"a suite outside it is a suite nobody runs"* — these are one step worse: there is no suite at all.

So the honest reading is **code ~90%, proof 0%**, not 10% of anything.

---

## What they actually do

**`supervisor.py`** spawns `python -m kistrader.cli run <args>` and restarts it on any exit, clean or
crashed ("the loop is meant to be eternal, so ANY exit is abnormal"). Exponential backoff, base
**65s** — chosen because KIS issues at most one access token per minute per app key (`EGW00133`), so
a 5s retry is *guaranteed* to fail on token issuance and burn a crash-storm slot. Backoff resets
after 600s of uptime. Crash-storm guard stops restarting after 6 exits in 1800s and exits 3, on the
reasoning that a loop dying every minute has a systemic cause and hammering KIS makes it worse.
Ctrl+C and a `supervisor.stop` file both shut down cleanly; `INTERRUPT_EXITS` covers the Windows
`STATUS_CONTROL_C_EXIT` codes so an operator stop isn't mistaken for a crash. Its docstring warns
against passing `--no-open-order-check` to a soak run, since that silently skips the §3.9.1
resting-order backstop the soak exists to prove.

**`deadman.py`** watches a file's mtime and pushes to Telegram when it stops advancing. Zero coupling
to `kistrader` (stdlib only, parses `.env` itself) so a broken venv or mid-edit repo can't take the
watcher down with the thing it watches. Fails closed without `TG_BOT_TOKEN`/`TG_CHAT_ID` — "a
dead-man that cannot alert is false confidence". FRESH→STALE pushes once, re-pushes every 1800s while
stale, STALE→FRESH pushes RECOVERED, state persisted to JSON so `--once` under Task Scheduler keeps
its dedup.

---

## Exercised today, with no credentials

Both are testable offline and neither had been run. `deadman.py --dry` and `supervisor.py --cmd`
exist precisely for this.

**`deadman.py`**, full state machine:

| case | result |
|---|---|
| fresh file | `FRESH (0s old)`, rc 0 |
| aged past threshold | `STALE (alerted)`, one DOWN push, rc 1 |
| checked again while stale | `STALE (suppressed; next re-alert in 1799s)` — no second push |
| file touched again | `RECOVERED (alerted)`, rc 0 |
| file absent | `DOWN? heartbeat file missing`, rc 1 |
| no TG creds, no `--dry` | `REFUSING to watch`, rc 2 |

**`supervisor.py`**, restart policy:

| case | result |
|---|---|
| `--dry` | prints command + policy, rc 0 |
| child exits immediately | restart at 1s, then 2s, then 2s — doubling, capped |
| 4th exit inside the window | `CRASH STORM: 4 exits within 600s — NOT restarting`, rc 3 |
| `supervisor.stop` created mid-run | child terminated, `stopped by operator`, rc 0, stop file consumed |

That is the first evidence either file has ever produced.

---

## The defect this turned up

`deadman.py` rule 3 says a dedicated `heartbeat.txt` writer is *"pending run_loop.py upload"* and
defaults to watching `kistrader_alerts.log` at a 2100s (35 min) threshold.

**That writer is not pending.** `PipelineLoop._heartbeat()` overwrites `heartbeat.txt` at the end of
**every cycle, in every phase**; `build_pipeline` defaults `heartbeat_path="heartbeat.txt"`;
`cli.cmd_run` passes no override. `heartbeat.txt` is already in `.gitignore`. The better signal has
been on disk the whole time while the watcher looked at the weaker one.

Three costs, all paid by that default:

1. **Latency.** The alerts log advances on the Notifier's 15-minute beat, so it needs 2100s.
   `heartbeat.txt` advances every cycle — `quote_poll_secs=7` OPEN, `closed_sleep_secs=30` CLOSED — so
   **300s** buys the same confidence (ten consecutive missed CLOSED cycles). Detection of a dead
   process drops from ~35 minutes to ~5.
2. **Rename hazard**, which rule 3 documents and then ships anyway: archiving the alerts log
   (`bugB_closed_*.log`) makes the watched path vanish and fires DOWN on a healthy loop.
3. **What it proves.** The alerts log's mtime proves the Notifier's *daemon thread* is alive.
   `heartbeat.txt`'s mtime proves the *cycle completed* — the thing that places orders and manages
   exits. A wedged main loop with a healthy heartbeat thread reads as FRESH under the old default.

Fixed in `apply_deadman_heartbeat_default.py`: two defaults and the docstring that justifies them.
Nothing else — state machine, credential rule and send path untouched, and the 2100s pairing is kept
in the help text for anyone who points `--file` back at the log.

---

## Corrected estimate rows

| piece | handoff | actual |
|---|---|---|
| Supervisor / auto-restart | ~10% | code complete; restart, backoff, storm guard and stop file exercised offline. Never run against the real `cli run` (needs KIS). |
| External dead-man's-switch | "not built" | built; state machine exercised offline. Real Telegram send unproven here. |

---

## Still unproven, and what each needs

- **The Telegram send path.** Every drill above used `--dry`. `python deadman.py --test` is a
  one-command channel check if `TG_BOT_TOKEN`/`TG_CHAT_ID` are in `.env`; the fail-closed refusal is
  proven either way.
- **Supervisor over the real loop.** `--cmd` proved the policy against a synthetic child. Supervising
  `kistrader.cli run` needs KIS credentials, and the 65s backoff reasoning can only be confirmed
  against real token issuance.
- **Neither has a test module.** Adding `test_supervisor` / `test_deadman` to `cli.py`'s tuple would
  make today's drills repeatable instead of a one-off paste in a transcript. That is the gap worth
  closing next in this area.
- **No session-clock awareness in the watcher** — deliberate, v1: duplicating the session clock would
  fork "headless time correctness" into two places that can drift. Start the watcher with the engine.
- **Neither is installed** under Task Scheduler / NSSM. That, plus secrets hardening, is what's left
  of Step 6 before a soak can run unattended.


---

## AMENDMENT, same day: they could not run unattended at all

Everything above stands except its headline. "Code ~90%, proof 0%" was measured **interactively**.
Wiring the drills into `tests/test_watchdogs.py` and running them on the box produced three failures
and one hard crash of the test runner, and the cause was neither the tests nor Windows in general:

```
UnicodeEncodeError: 'cp949' codec can't encode character '—'
  File "supervisor.py", line 66, in log
```

Both files printed em dashes. A redirected stream takes its encoding from the locale — cp949 on this
machine — and cp949 has no U+2014. **Any run with stdout redirected to a file or a pipe died with
exit 1 on its own first log line.** That is precisely how Task Scheduler, NSSM, or
`supervisor.py > soak.log` run them. Interactively it never showed, because since 3.6 Python writes
to a Windows *console* through the UTF-16 API.

So the honest correction: the two files whose entire job is unattended operation **could not run
unattended**. Not a style issue — a hard crash, on the first line of output, every time.

Worst case is `deadman.py`: the crash is on the line that *alerts*. The dead-man's-switch died at the
moment it was supposed to speak, and the failure it produced was silence — the exact condition it
exists to detect. It would have looked like a healthy soak.

Measured before the fix, output redirected:

| case | expected | observed |
|---|---|---|
| supervisor, crash-storm | rc 3 | **rc 1**, traceback |
| supervisor, stop file | rc 0, file consumed | **rc 1**, stop file left behind, **child still running** |
| deadman `--dry --once` | rc 1, state written | **rc 1** by coincidence, **no state file** |

The orphaned child is its own hazard: the supervisor died and left the process it was supervising
alive, holding the redirected log open (`PermissionError [WinError 32]` on cleanup). A supervisor
that dies without taking its child down is worse than no supervisor — the loop keeps trading with
nothing watching it.

### Fixed in `apply_watchdog_encoding.py`

Two layers. `sys.stdout`/`sys.stderr` pinned to UTF-8 at startup in both files, so no character in
any future message can kill a watchdog; and the 9 + 4 printed em dashes rewritten to `--`, so the
bytes stay plain even if the pin is ever removed. Docstrings keep their prose — argparse prints them
under `--help`, and the pin covers that.

### Why a Linux check said 38/38 while the box disagreed

The test asserted the platform it happened to run on. `PYTHONIOENCODING=cp949` reproduces the crash
on **any** platform, needs no Windows, and is now two cases in section I of the suite — verified to
fail on the unpatched files (38/42) and pass on the patched ones (42/42). The general lesson, which
cost three bad guesses today: a hostile condition has to be *forced*, not waited for.

### Blast radius — checked, and it stops at these two files

The trading loop is unaffected. `notifier.emit` writes through a `RotatingFileHandler` opened with
`encoding="utf-8"`, queues Telegram as UTF-8, never prints to stdout, and swallows exceptions;
`cli.py`'s own prints are pure ASCII; the engine's em dashes all travel through `alert()`, not
`print()`. Only the two stdlib-only watchdogs print directly — which is also why nothing else caught
it.

### The estimate rows, corrected again

| piece | handoff | after the first pass | actual |
|---|---|---|---|
| Supervisor / auto-restart | ~10% | code complete, exercised offline | code complete and now **provably runnable redirected**; 42-check suite in `cli.py`'s tuple; still never run against the real `cli run` (needs KIS) |
| External dead-man's-switch | "not built" | built, exercised offline | built, redirected-safe, suite-covered; real Telegram send still unproven |

### Also fixed, in the tests themselves

- A `subprocess.TimeoutExpired` escaped and killed the whole `cli test` run — every suite after
  `test_watchdogs` never executed, and the total was never confirmed. A timeout is now a FAIL with
  the child killed.
- All subprocess cases shared one temp directory, so a failure could not be attributed. One
  directory each.
- Failures reported bare booleans. Every case now prints the child's own last lines — which is what
  finally identified this bug rather than a fourth guess.


---

## SECOND AMENDMENT, same night: the BOX was never at risk, and (a) was a rediscovery

Both amendments above were written without reading `cloud_provisioning.md` or
`BOX_LIVE_STATUS_20260818.md`. Reading them corrects two claims:

### The cp949 crash could not reach the deployed system

Every systemd unit carries, by design and without exception:

```
WorkingDirectory=/home/kis/kis-trader
Environment="PYTHONIOENCODING=utf-8"       # journald is a pipe; services do not
                                           # inherit your login LANG
```

`BOX_LIVE_STATUS_20260818` records the gate directly: *"`cli run --once` piped —
no `UnicodeEncodeError`; em-dash renders in journald."* Tested, on the box, on
2026-08-18, and it passed. `cloud_provisioning.md` §8.5's disposition says the
same: the em-dash class of fault was closed there by pinning the encoding on
every unit.

So the honest severity: **this was a LAPTOP-ONLY fault.** It breaks a hand-run
`supervisor.py > soak.log` on Korean Windows, and it would break a Windows
Task Scheduler install — but that install does not exist and is not the target.
The soak was never blind.

"The two files whose entire job is unattended operation could not run
unattended" is therefore **false as written** and is retracted. The accurate
statement: they could not run redirected *on this laptop*, where nothing pins the
encoding; the deployment target pins it per-unit and was verified doing so
nearly a month ago.

The fix still earns its place — it makes the files correct independent of who
sets an environment variable, and the unit's `Environment=` becomes belt to the
code's braces rather than the only thing standing between the watcher and
silence. But it is hardening, not a rescue.

### Finding (a) was already known, twice

The stale `deadman.py` docstring was recorded on **2026-08-18** as bug #2 of that
day, and again in `cloud_provisioning.md` §3 as a ⚠ CORRECTED entry:

> `deadman.py`'s own docstring is stale. It says the dedicated heartbeat writer
> is "pending run_loop.py upload". It landed... Measured gap **30.003 s**, so
> 180 s is six cycles of margin.

The unit has always passed `--file heartbeat.txt --stale-secs 180` explicitly, so
the shipped default never applied in production. My patch aligned the default
with what the box already did — worth doing, and not a discovery. The box's 180 s
comes from a **measured** 30.003 s heartbeat gap; my 300 s was derived from
`closed_sleep_secs=30` as a source constant. The box value is better evidence and
should win if the two ever have to agree.

### What this says about the method, not just the facts

Three times today I asserted platform behaviour I could not run. This one is
worse: I asserted a *deployment* state that 127 project docs already recorded,
without reading them. The project instruction is "do not infer, if unknown
research and test" — and the research here was two documents away.
