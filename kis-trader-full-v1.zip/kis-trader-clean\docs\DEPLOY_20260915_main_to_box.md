# DEPLOY RUNBOOK — main `4229e83` to the box (window: Tue 2026-09-15)

Carries sixteen commits the box has never had: Phase E stage 0, E11 stage 1, the
two screener scoring changes, 4A steps 1 and 3, and the watchdog work.

Cutover shape is unchanged from `CUTOVER_RUNBOOK_20260829` and
`DEPLOY_20260904_i3_run`: **swap in place, same `WorkingDirectory=`, nothing in
systemd changes.** Runtime state is gitignored and survives the checkout —
`kis_engine_state.db`, `.env`, `.deadman_state.json`, `candidates.csv`,
`regime.json`, `runs/`, `fundamentals_archive/`, logs, `heartbeat.txt`.

Every block is labelled **LAPTOP** or **BOX** (`HANDOFF_PHASE_E` §7 rule 1).
Every `systemctl`/`journalctl` carries `--no-pager` (rule 2).

---

## 0. STATE — read off `.git` tonight, not assumed

| | |
|---|---|
| laptop `main` | **`4bac30e`** "docs: deploy runbook main -> box; correct the box commit to 6869ec7" (= `4229e83` + this document's own commit) |
| laptop `deploy-soak` | **`6869ec7`** = tag `deploy-soak-2026-09-08` = main `516aec3` + cherry-pick "VCP_SCORE_THRESHOLD 75 -> 45" |
| box | `/home/kis/kis-trader`, `kisbox` (`kis@2.29.9.125`), detached at `deploy-soak-2026-09-08` = `6869ec7` |
| box rollback file | `~/backups/PRE_DEPLOY_HEAD.txt` → `c4080e9` |
| box units | `kistrader.service` · `kistrader-deadman.service` · `kistrader-screeners.{service,timer}` · `kistrader-backup.{service,timer}` |
| `VCP_SCORE_THRESHOLD` on `main` | **75** (`screen_contract.py:90`) — the cherry-pick is required |
| suite on `main` | **626 / 626** via `kistrader test`, measured 2026-09-14 |
| `pytest -q` on `main` | **90 passed**, measured 2026-09-14 (87 at `c4a38db`, 88 at `516aec3`) |
| soak tag | **`deploy-soak-2026-09-15` = `9adbb2b`** = `4bac30e` + cherry-pick `6869ec7` |
| bundle | `kis-trader-clean-20260915.bundle`, 528 KB, **transferred to `/home/kis/` 2026-09-14**, `bundle verify` ok, 17 refs, complete history |

**Correction carried in from last night.** `DAY_CLOSE_20260914`'s correction block
says the box is on `d87d9c7` (09-05). It is not — that was already two deploys
stale when it was written. `HANDOFF_PHASE_E_20260908` §1, timestamped
2026-09-08 14:07 UTC, records `deploy-soak-2026-09-08 = 6869ec7`, and the laptop's
`refs/heads/deploy-soak` and `refs/tags/deploy-soak-2026-09-08` both resolve to
`6869ec7`. The gap is sixteen commits, not nineteen.

**Box state is asserted from a document dated 09-08, so step 4.1 re-reads it
before anything is touched.** The box has drifted off its documented commit once
before, silently (`DEPLOY_CLOSE_20260905` §2). A mismatch there is a finding to
resolve *before* the deploy, not a detail to overwrite.

### The sixteen commits

```
891e421  Phase E stage 0: Minervini sell-signal observer -- records, trades nothing
5c506a5  E11 stage 1: adaptive ZigZag knob, proven no-op at contraction_ratio=...
c4cdb71  tol: VCP_CONTRACTION_MODE -> strict; S13 asserts the screener constant
3ebb1c6  feat(screeners): score final-contraction tightness in stage 3/4
6bfc0bf  feat(tools): plan_probe -- read_candidates + decision_engine.plan offline
f80eb79  4A: log scores with arm rejections; plumbing CSV gets its own regime sidecar
bc17594  4A step 1: assert the arm-reject line carries RS / stage2 / VCP
b402f71  tests: drop the duplicate DecisionEngine import
df61582  docs: day close 2026-09-13
df0b9be  4A step 3: --offline mode on make_plumbing_csv (no broker, no keys)
107b874  gitignore: emit_probe.csv is probe output, not a record
1c62310  docs: step 3 result -- n_max, exposure ceiling and dedup made to bind
3d81088  deadman: watch heartbeat.txt, and stop --dry poisoning live alert state
2080956  watchdogs: survive redirected output, and get a suite that proves it
53be8f6  docs: day close 2026-09-14
4229e83  docs: correct three 09-14 claims against the box's actual state
```

### What actually changes on the box — only group A trades differently

**A. Screener behaviour. This is the whole risk surface of this deploy.**
`c4cdb71` sets `VCP_CONTRACTION_MODE` to `strict`; `3ebb1c6` scores final-contraction
tightness in stage 3/4; `5c506a5` adds the adaptive ZigZag knob and was *proven a
no-op at the shipped `contraction_ratio`* — a knob, not a change. The first two
are not no-ops. **The candidate set produced from Tue 12:00 UTC onward is not
comparable with the set produced before it.** Record that boundary; do not read a
change in candidate count across it as a market observation.

**B. Observation only.** `891e421`'s sell-signal observer records and trades
nothing. It rides inside `CloseLog`, so there is **no new boot-log line** — the
boot record still ends at the existing
`close observation log -> runs/close_observations.csv (I5; trades nothing, ...)`.
Its one visible effect is the column rotation in §5.4.

**C. Watchdogs — real changes, inert on this box.** The deadman's new default
`--file heartbeat.txt --stale-secs 300` never applies here: `kistrader-deadman.service`
passes `--file heartbeat.txt --stale-secs 180` explicitly, from a measured
30.003 s heartbeat gap. The `--dry` state split keeps the live name
`.deadman_state.json` unchanged, so the box's existing state file is picked up
and no systemd line moves. The UTF-8 pin is hardening on a box where every unit
already sets `Environment="PYTHONIOENCODING=utf-8"`.

**D. Laptop-only tooling.** `plan_probe`, `make_plumbing_csv --offline`,
`tests/test_watchdogs.py`, docs. Present on the box, exercised by nothing there.

---

## 1. THE WINDOW

Both prior runbooks: **after 16:00 ET, before the 08:00 ET screener timer.**

```
Mon 2026-09-14 20:00 UTC   US close          = Tue 05:00 KST
Tue 2026-09-15 12:00 UTC   screener timer    = Tue 21:00 KST
```

So the box work happens **Tue 05:00–21:00 KST**, and finishing before 12:00 UTC
means the screener timer fires under the new tree on its own, which is what §5.5
reads.

The reason is not ceremony: the box holds **7 live positions** and the swap leaves
them unmonitored for its duration. Watches themselves survive — `pipeline.start()`
calls `recover_watches()` — but a stop that straddles a session is a gap in the
soak's own evidence.

**Section 2 is laptop-only, touches no live system, and can be done immediately.**

`clock_check.py` on the box is the authority on whether Tue 09-15 is a trading day
and on the holiday list. Do not take it from here.

---

## 2. LAPTOP — rebuild `deploy-soak`, tag, bundle

```powershell
cd C:\Users\user\PyCharmMiscProject\kis-trader-clean

git status --short                     # MUST be empty. *.bak is ignored since 8658f7c
git log --oneline -1                   # 4229e83
git log --oneline 516aec3..main        # the sixteen above, in order

$env:PYTHONUTF8 = "1"                  # test_entry_half.py:672 -- an em dash kills the
                                       # suite under ANY stdout redirect. Workaround, not fix.
python -m kistrader.cli test           # EXPECT 626 / 626. This is the real gate.
python -m pytest -q                    # MEASURED 2026-09-14: 90 passed.
                                       # It was 87 at c4a38db and 88 at 516aec3 -- the
                                       # number was measured, not carried forward, and
                                       # it is an input to the box check below.
```

`pytest -q` and `kistrader test` are different gates: `pytest` counts test
*functions*, `kistrader test` counts *assertions* across twelve suites. Quoting one
as the other is what `DEPLOY_20260904` §6 had to correct.

**Counting 626 out of a redirected `gate.log` — two traps, both measured 2026-09-14.**
Summing every `^PASSED n / n` line gives **614**, which is not a regression:

* `test_candidate_emit` prints `32/32 emitter contract tests passed` and never the
  word `PASSED` in that shape, so the pattern misses it entirely.
* `test_point_in_time` prints **two** totals — its inner pure-module self-test
  (`PASSED 20 / 20`) and then its own (`PASSED 27 / 27`). The 20 is already inside
  the 27, so a naive sum double-counts it.

`614 - 20 + 32 = 626`. The reliable gate is the **exit code plus the absence of
`[FAIL]` / `Traceback`**, not an arithmetic total — a total is what has produced a
false stale number twice in this project already.

```powershell
# -B recreates the ref; the old soak tip is preserved by tag deploy-soak-2026-09-08
git checkout -B deploy-soak main
git cherry-pick 6869ec7                # "TECHNICAL soak: VCP_SCORE_THRESHOLD 75 -> 45"

python -c "print([l.strip() for l in open('kistrader/entry/screen_contract.py',encoding='utf-8') if 'VCP_SCORE_THRESHOLD =' in l])"
#   MUST print VCP_SCORE_THRESHOLD = 45

python -m pytest -q
#   MEASURED 2026-09-14: 2 failed, 88 passed -- exactly the two named drift guards,
#   reported through each file's terminal test_zz_all_checks_passed guard:
#       tests/test_boot_params.py   "live: no refusal when the set matches"
#       tests/test_entry_half.py    "threshold is 75"
#   No third red. THIS PAIR, 2 / 88, is what the box must reproduce in §5.1.
#
#   The rule that produced it, for the next deploy: exactly 2 failed, and
#   passed = (the main number) - 2.
#   The two are drift guards and red is the PASS condition on a soak branch:
#       test_entry_half    'threshold is 75'
#       test_boot_params   'live: no refusal when the set matches'
#   A THIRD red is a real finding. Read it before deciding anything: if it is
#   another threshold-75 guard added since 09-08 it is expected-but-new and gets
#   recorded; if it is anything else the deploy stops here.

git tag deploy-soak-2026-09-15
git bundle create ..\kis-trader-clean-20260915.bundle --all
git bundle verify ..\kis-trader-clean-20260915.bundle
git checkout main                      # leave the laptop on main
```

If the cherry-pick conflicts it is one line in `screen_contract.py`. Take `45`,
`git add`, `git cherry-pick --continue`. Do not resolve it by editing anything else
in that file.

**Note, 2026-09-14 run.** The first build was made with `docs/` uncommitted, so its
bundle carried `main` = `4229e83` without these two documents. Nothing had been
transferred yet, so the tag was rebuilt rather than left inconsistent:

```powershell
git add docs/DAY_CLOSE_20260914.md docs/DEPLOY_20260915_main_to_box.md
git commit -m "docs: deploy runbook main -> box; correct the box commit to 6869ec7"
git status --short                     # NOW empty

git checkout -B deploy-soak main
git cherry-pick 6869ec7
python -m pytest -q                    # still 2 failed / 88 passed, same two guards
git tag -f deploy-soak-2026-09-15      # -f is safe ONLY because nothing was shipped yet
git bundle create ..\kis-trader-clean-20260915.bundle --all
git bundle verify ..\kis-trader-clean-20260915.bundle
git checkout main
```

`git tag -f` on a tag that has already reached the box is a different act entirely
— then the box and the laptop disagree about what a name means. Move a tag only
before it has been transferred.

**Before the box touches KIS, the laptop must be fully stopped** — one app key,
one machine (EGW00133):

```powershell
Get-CimInstance Win32_Process -Filter "Name LIKE '%python%'"   # must return nothing
```

---

## 3. TRANSFER

```powershell
ssh kisbox exit
scp ..\kis-trader-clean-20260915.bundle kis@2.29.9.125:/home/kis/
```

**DONE 2026-09-14.** `ssh kisbox exit` returned silently (alias alive, host key
matched, no password prompt) and the bundle copied — 528 KB at 295 KB/s. The box
now holds the bundle and is otherwise untouched: nothing stopped, nothing checked
out, the trader and the deadman still running on `6869ec7`.

The `kisbox` alias was written to `~/.ssh/config` on 09-04 (no BOM — a BOM breaks
`ssh_config`). If it is gone, the key is `~\.ssh\kistrader_box`, a **non-default
name**, so a bare `scp` fails `Permission denied (publickey)` — pass `-i`.
A publickey denial is client-side; a UFW lockout would time out instead.

---

## 4. BOX — the swap

### 4.1 Confirm the box is where the documents say

```bash
ssh kisbox
cd /home/kis/kis-trader
git rev-parse HEAD                      # EXPECT 6869ec7...  (deploy-soak-2026-09-08)
git describe --tags --exact-match 2>/dev/null || echo "detached, no exact tag"
systemctl list-units 'kis*' --no-pager
systemctl is-active kistrader kistrader-deadman --no-pager
systemctl is-enabled kistrader kistrader-deadman \
                     kistrader-screeners.timer kistrader-backup.timer --no-pager
```

**Anything other than `6869ec7` stops the deploy.** It means the box moved without
a record, which has happened once before, and the first job is to find out to what
and when — not to bury it under a new checkout.

### 4.2 Stop, deadman first

```bash
sudo systemctl stop kistrader-deadman kistrader
systemctl is-active kistrader kistrader-deadman --no-pager    # both inactive
```

Deadman first, or it reports the deliberate outage as a failure.

### 4.3 Back up — python's `sqlite3` module, never `cp`

The DB is WAL mode, so a `cp` of it is a corrupt copy. **The `sqlite3` CLI is not
installed on this box** (found 09-04, again 09-05); `deploy/backup_state.sh` has
always used the module.

```bash
mkdir -p ~/backups
cd /home/kis/kis-trader
.venv/bin/python - <<'PY'
import os, sqlite3
dst = os.path.expanduser("~/backups/pre_deploy_20260915.db")
s = sqlite3.connect("kis_engine_state.db"); t = sqlite3.connect(dst)
s.backup(t); t.close(); s.close()
print("backup ok:", os.path.getsize(dst), "bytes")
PY

cp .env              ~/backups/.env.pre_20260915
cp .deadman_state.json ~/backups/.deadman_state.pre_20260915

cp ~/backups/PRE_DEPLOY_HEAD.txt ~/backups/PRE_DEPLOY_HEAD_20260908.txt   # preserve c4080e9
git rev-parse HEAD > ~/backups/PRE_DEPLOY_HEAD.txt
cat ~/backups/PRE_DEPLOY_HEAD.txt ~/backups/PRE_DEPLOY_HEAD_20260908.txt
#   EXPECT 6869ec7... then c4080e9...
```

Backups go to `~/backups/`, not the repo: untracked files in the repo produce a
`+dirty` boot flag that then means nothing, which is how a real source edit would
once have read identically (09-04).

### 4.4 Fetch and check out, in place

```bash
git status --short                      # MUST be clean before checkout
git fetch /home/kis/kis-trader-clean-20260915.bundle --tags
git checkout deploy-soak-2026-09-15
git rev-parse HEAD                      # MUST read 9adbb2b...
git status --short                      # runtime state still ignored
ls -l kis_engine_state.db .env .deadman_state.json candidates.csv regime.json heartbeat.txt
```

**Do NOT run `git clean -fd`.** It is the natural next command after a checkout
that leaves untracked files behind, and it is the one that deletes the event
store. Leave leftovers; list them later with `git status --ignored`.

### 4.5 Refresh the editable install

```bash
.venv/bin/pip install -e ".[screeners]" --no-deps
.venv/bin/python -c "import kistrader,os;print(os.path.dirname(kistrader.__file__))"
#   MUST print /home/kis/kis-trader/kistrader
```

This is the step PATCH G's `_assert_kistrader_local` exists for: on 2026-08-25 a
screener ran clean-tree source against an old-repo package through a stale
editable install.

---

## 5. BOX — verify, before anything restarts

### 5.1 Gates

```bash
cd /home/kis/kis-trader
.venv/bin/python -m pytest -q
#   MUST be 2 failed / 88 passed, and the two must be the same two named guards.
#   A different number means the deploy is not what was tested.

.venv/bin/python -m kistrader.tools.param_snapshot ; echo "exit=$?"
#   EXPECT exit 1 with exactly ONE differing parameter:
#       VCP_SCORE_THRESHOLD live=45.0 frozen=75
#   That 1 is by design on a soak box (FREEZE_REV3_CORRECTIONS §1). It is not a
#   deploy failure. TWO differing parameters IS one.
#   param_snapshot.py has not been modified since 2026-08-24 and its pin lists
#   cover DecisionConfig, engine_v2 and the TR ids only -- none of this deploy's
#   changes are in its scope, which is why one is still the right answer.

KIS_STALL_DAY=6 .venv/bin/python -m kistrader.tools.param_snapshot | grep -i stall
#   MUST show 6 -- the systemd Environment= route, still the only proof it works

.venv/bin/python clock_check.py
#   ET vs a world clock. This is the authority on session_date, is_trading_day
#   and the holiday list -- not the laptop, and not this document.
```

### 5.2 Restart the trader, and read the right file

```bash
sudo systemctl start kistrader
sleep 25
journalctl -u kistrader -n 40 --no-pager
tail -40 kistrader_alerts.log
```

**The recovery proof is in `kistrader_alerts.log`, not the journal.**
`RunLoop.start()` reports through `self.alert(...)` and INFO is routed to the log
file, so `journalctl | grep recover` returns nothing on a perfectly healthy boot.

Want:

* `started; N live; ...` with **N = 7** — 8 if the watch armed on 09-14 filled during that
  session. A restored watch line (`watch RESTORED pivot=`) may also appear; watches survive a
  restart, so one is expected if it had not triggered by the swap.
* **no `no local record` CRITICAL** on any position
* `tree = <the new sha>` with **no `+dirty`**
* the unchanged `close observation log -> runs/close_observations.csv (I5; ...)` line

If a `recover()` traceback appears, read the **last** frame and count
`starting child` in the supervisor log before blaming the deploy: 2 is a transient
the supervisor absorbed, 6 is a storm. A rollback was once done for a fault that
had already healed.

### 5.3 Restart the deadman — and prove it

```bash
sudo systemctl start kistrader-deadman
systemctl is-active  kistrader kistrader-deadman --no-pager
systemctl is-enabled kistrader kistrader-deadman \
                     kistrader-screeners.timer kistrader-backup.timer --no-pager
journalctl -u kistrader-deadman -n 20 --no-pager    # want ARMED / FRESH
```

**A deploy is not finished until `is-active` AND `is-enabled` on both.** The
deadman was once left down for ten hours while heartbeats kept being written, and
a quiet phone during those ten hours meant nothing at all.

### 5.4 The one expected new artefact

Phase E stage 0 widens `CloseLog`'s column set, and `_rotate_if_header_changed`
moves the old log aside exactly once rather than appending ragged rows under a
narrower header:

```bash
ls -l runs/close_observations.csv*
grep -n "close_log: column set changed" kistrader_alerts.log | tail -2
```

Expect `runs/close_observations.csv.pre_<N>cols` to appear beside a fresh
`close_observations.csv`, and one alert line naming it. That is the designed
migration, not damage — the pre-deploy rows are preserved in the `.pre_<N>cols`
file and nothing merges them.

### 5.5 The first screener run under the new tree — Tue 12:00 UTC

```bash
ls -lt candidates.csv regime.json | head
ls fundamentals_archive/2026-09/ | grep -c 2026-09-15        # AJ: want non-zero
grep -E "arm reject|TRIGGERED|BREAKOUT HELD" kistrader_alerts.log | tail -40
```

Two things are new to read here:

* **arm rejections now carry their scores** (`4A` step 1): every rejected candidate
  logs `[rs=.. s2=.. vcp=..]` with its reason. This is `§9`'s "cheap + legitimate"
  line finally producing data — it costs nothing and changes nothing traded.
  The before-picture is on record: on 2026-09-14 13:30:41 UTC the box logged 13
  rejections with reasons and **no score suffix**, because `f80eb79`/`bc17594` are
  in this deploy. After it, the same lines carry the three numbers.
* **the candidate set is under strict contraction mode with tightness scoring for
  the first time.** Whatever it produces, it is the start of a new series, not a
  continuation of the old one.

`BREAKOUT HELD` must still be **zero**: it only fires under
`--require-breakout-volume`, which is not passed.

---

## 6. ROLLBACK — one command, because the state never moved

```bash
sudo systemctl stop kistrader-deadman kistrader
cd /home/kis/kis-trader
git checkout $(cat ~/backups/PRE_DEPLOY_HEAD.txt)       # -> 6869ec7
.venv/bin/pip install -e ".[screeners]" --no-deps
sudo systemctl start kistrader kistrader-deadman
systemctl is-active kistrader kistrader-deadman --no-pager
```

The event store, `.env` and the deadman state were never touched, so this restores
the previous system exactly. **That property is the entire reason for swapping in
place**, and it is worth more than the tidiness of a fresh clone.

One thing rollback does **not** undo: the `close_observations.csv` column
rotation (§5.4). The old rows are in `.pre_<N>cols`; the narrower log restarts
empty. Harmless, but know it before reading that file after a rollback.

---

## 7. RECHECK — what was derived, and what was not

**Derived, with the source:**

* Laptop refs read out of `.git` directly: `refs/heads/main` = `4229e83`,
  `refs/heads/deploy-soak` = `refs/tags/deploy-soak-2026-09-08` = `6869ec7`. The
  sixteen commits and their order come from `.git/logs/HEAD`, which also shows
  `56ca157` reset away and `cb40ce2` amended to `df0b9be` — neither is in the
  chain.
* `VCP_SCORE_THRESHOLD = 75` on `main`, read at `screen_contract.py:90`. The
  cherry-pick is required and touches one line.
* **`param_snapshot` still expects exactly one differing parameter**, because
  `kistrader/tools/param_snapshot.py` has not been modified since 2026-08-24 and
  its `PINNED_DECISION` / `PINNED_ENGINE` / `IDENTITY_TR` groups read
  `DecisionConfig`, `engine_v2` and TR ids. `VCP_CONTRACTION_MODE` lives in
  `screeners/`, outside all three.
* **No systemd change is needed for the deadman work.** The live state file is
  still `.deadman_state.json` (`STATE_FILE`); only `--dry` moved, to
  `.deadman_state.dry.json`. The unit passes `--file` and `--stale-secs`
  explicitly, so the changed defaults never apply here.
* **No new boot-log line for Phase E stage 0**: `cli.py` prints only the existing
  `close observation log -> ...`; the observer is imported by
  `close_log.py:70` (`from kistrader.core.minervini_exit_rules import
  OBSERVATION_FIELDS, observe`) and its fields are merged into the same row.
* **The column rotation is real and benign**, read at
  `close_log.py:_rotate_if_header_changed` — renames once to `.pre_<n>cols`,
  alerts, never overwrites an existing archive.
* `tests/test_watchdogs.py` defines `t_*` functions, not `test_*`, so pytest
  imports it and collects zero functions from it. It does not move the pytest
  count; it does move the `kistrader test` count, which is why §2 records both.

**NOT verified from here, each with its own check in the sequence:**

* **That the box is still on `6869ec7`.** Asserted from a document dated
  2026-09-08. §4.1 re-reads it, and a mismatch stops the deploy.
* ~~**The `pytest -q` count on `main`.**~~ **MEASURED 2026-09-14: 90 passed**, and
  the soak branch reproduces 2 failed / 88 passed with no third red. Both were
  measured rather than carried forward, which is the correction
  `DEPLOY_20260904` §6 had to make about 449-vs-87.
* ~~**The bundle carries `main` = `4229e83`, without this document's own commit.**~~
  **Resolved before transfer.** The docs were committed (`4bac30e`), the branch
  rebuilt, the tag moved with `-f` to `9adbb2b`, and the bundle rebuilt and
  verified. `git tag -f` was legitimate only because nothing had shipped yet.
  **Docs-only edits made to this file AFTER `9adbb2b` do not invalidate the tag
  and must not trigger another rebuild** — `docs/` reaches nothing the box runs,
  and chasing it is an infinite regress, since each rebuild needs its own note.
* **That Tue 2026-09-15 is a trading day**, and the box's holiday list.
  `clock_check.py` on the box is the authority.
* **That the account still holds 7 positions.** Last recorded 09-08.
* **The mock `tvol` delay** — still unmeasured, still gates E9. A THIN verdict is
  not yet readable.
