#!/usr/bin/env python3
"""
PATCH A -- param_snapshot: report the two fail-closed switches and the tree sha.

WHAT IT ADDS

1. allow_missing_close and require_atr, printed at every boot.
   These are SAFETY switches, not tuning knobs, and both are currently
   invisible. They are NOT frozen parameters -- no backtest ever chose them --
   so they must never affect the exit code, and this patch does not let them.

   Only ONE has a dangerous direction:
     allow_missing_close=True  -> arms a position with no verifiable close
     require_atr=True          -> STRICTER than the default; the default already
                                  accepts a contraction-only stop, which is the
                                  doctrinal anchor (the final contraction's low,
                                  with ATR as a band around it)
   So require_atr is printed and never alerted on. An alert that fires on the
   safe direction teaches you to ignore alerts.

2. tree = <short sha> from `git rev-parse`, plus +dirty when the working tree
   has uncommitted edits. This replaces the "sha-pin engine_v2 and
   decision_engine" idea: it covers the WHOLE tree, needs no pin to maintain,
   and stays true after a legitimate deploy. It can never raise -- a boot log
   must not be able to abort a run.

WHAT IT DOES NOT DO

It does not block a live boot on allow_missing_close=True. It alerts CRITICAL.
The refusal path stays driven by FROZEN alone; escalating this to a hard block
is a separate decision, deliberately not taken here.

USAGE (from the kis-trader-clean root)

    python patch_A_param_snapshot.py --file kistrader/tools/param_snapshot.py
    python patch_A_param_snapshot.py --file kistrader/tools/param_snapshot.py --revert

Asserts every anchor matches exactly once before writing anything, and refuses
to run twice.
"""
from __future__ import annotations

import argparse
import os
import sys

MARK = "# --- PATCH A: fail-closed switches + tree sha ---"

A1_ANCHOR = 'MISSING = object()      # distinct from None, which is a legitimate value\n'
A1_NEW = A1_ANCHOR + '''
# --- PATCH A: fail-closed switches + tree sha ---
# NOT frozen parameters: no backtest ever chose them, so they never affect the
# exit code. Reported because flipping one silently changes what gets ARMED.
SWITCH_DEFAULTS = {"allow_missing_close": False, "require_atr": False}


def switches():
    """Live values of the two fail-closed switches, MISSING if unreadable."""
    try:
        from kistrader.entry.decision_engine import DecisionConfig
        cfg = DecisionConfig()
        return {k: getattr(cfg, k, MISSING) for k in SWITCH_DEFAULTS}
    except ImportError:
        return {k: MISSING for k in SWITCH_DEFAULTS}


def tree_sha(root=None):
    """Which commit is this process actually running? Whole tree, no pin to
    maintain, still true after a deploy. NEVER raises: a boot log must not be
    able to abort a run."""
    import subprocess
    if root is None:
        here = os.path.dirname(os.path.abspath(__file__))       # kistrader/tools
        root = os.path.dirname(os.path.dirname(here))           # repo root
    try:
        r = subprocess.run(["git", "rev-parse", "--short", "HEAD"], cwd=root,
                           capture_output=True, text=True, timeout=5)
        if r.returncode != 0 or not r.stdout.strip():
            return "unknown (not a git checkout)"
        sha = r.stdout.strip()
        d = subprocess.run(["git", "status", "--porcelain"], cwd=root,
                           capture_output=True, text=True, timeout=5)
        if d.returncode == 0 and d.stdout.strip():
            return sha + " +dirty (uncommitted edits in the tree)"
        return sha
    except Exception:                       # noqa: BLE001 -- never break a boot
        return "unknown (git unavailable)"
'''

A2_ANCHOR = '''    p("-" * (w + 46))
    ov = screener_overrides()
'''
A2_NEW = '''    p("-" * (w + 46))
    for _k, _v in switches().items():                       # --- PATCH A ---
        _d = SWITCH_DEFAULTS[_k]
        if _k == "allow_missing_close" and _v is True:
            _note = "  <- ARMS WITHOUT A VERIFIABLE CLOSE"
        elif _v != _d:
            _note = "  <- non-default (stricter)" if _k == "require_atr" else "  <- non-default"
        else:
            _note = ""
        p(f"  {'ok ' if _v == _d else '** '}{_k:<{w}}  "
          f"live={_fmt(_v):<12} default={_fmt(_d)}{_note}")
    p(f"  tree = {tree_sha()}")                             # --- PATCH A ---
    ov = screener_overrides()
'''

A3_ANCHOR = '''    print(f"  KIS_MOCK={'1 (mock)' if is_mock else '0 (LIVE)'}", file=stream)
'''
A3_NEW = A3_ANCHOR + '''    # --- PATCH A --- allow_missing_close is the only dangerous direction.
    # Alerts, does NOT raise: the refusal path stays driven by FROZEN alone.
    if switches().get("allow_missing_close") is True and not is_mock:
        _m = ("allow_missing_close=True on a LIVE account -- the system will arm "
              "a position with no verifiable close. This is a fail-closed "
              "switch, not a tuning knob.")
        print("  CRITICAL: " + _m, file=stream)
        if alert is not None:
            try:
                alert("CRITICAL: " + _m)
            except Exception:              # noqa: BLE001 -- never mask the boot
                pass
'''

EDITS = [("switches() + tree_sha()", A1_ANCHOR, A1_NEW),
         ("render(): print switches and tree", A2_ANCHOR, A2_NEW),
         ("boot_log(): CRITICAL on live", A3_ANCHOR, A3_NEW)]


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--file", default="kistrader/tools/param_snapshot.py")
    ap.add_argument("--revert", action="store_true")
    a = ap.parse_args()

    if not os.path.isfile(a.file):
        print("FATAL: no such file %r -- run from the kis-trader-clean root." % a.file)
        return 2
    with open(a.file, encoding="utf-8") as fh:
        src = fh.read()

    if a.revert:
        if MARK not in src:
            print("nothing to revert: %s does not carry patch A." % a.file)
            return 0
        out = src
        for label, anchor, new in EDITS:
            if out.count(new) != 1:
                print("FATAL: %r appears %d time(s), expected 1. Refusing to "
                      "guess." % (label, out.count(new)))
                return 1
            out = out.replace(new, anchor)
        verb = "REVERTED"
    else:
        if MARK in src:
            print("already applied: %s carries patch A. Nothing to do." % a.file)
            return 0
        for label, anchor, _new in EDITS:          # check ALL before writing ANY
            if src.count(anchor) != 1:
                print("FATAL: anchor %r appears %d time(s), expected exactly 1.\n"
                      "This file is not the version the patch was written "
                      "against. Nothing written." % (label, src.count(anchor)))
                return 1
        out = src
        for _label, anchor, new in EDITS:
            out = out.replace(anchor, new)
        verb = "APPLIED"

    # No BOM, LF endings -- house rule 5. Set-Content would add a BOM here.
    with open(a.file, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(out)
    print("%s: %s  (%+d lines)"
          % (verb, a.file, len(out.splitlines()) - len(src.splitlines())))
    print("Now run:  python -m kistrader.tools.param_snapshot")
    print("Exit code must still be 0 at the frozen set -- the switches and the")
    print("tree sha are REPORTED, never scored.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
