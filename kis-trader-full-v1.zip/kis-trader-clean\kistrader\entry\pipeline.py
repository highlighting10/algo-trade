#!/usr/bin/env python3
"""
Pipeline wiring — screener -> gate -> decision -> entry -> monitor  (§2.5, §5.3)
==============================================================================

The four entry modules are deliberately broker/loop-agnostic so they can be
unit-tested. This file is the (thin, non-invasive) glue that makes the whole
thing autonomous: it composes them with the *tested* RunLoop/ExecutionMonitor
without editing either file.

What it adds on top of RunLoop:

  1. Recovery routing (§5.3). ExecutionMonitor.recover() rehydrates ALL
     non-terminal snapshots — holdings AND any PENDING_ENTRY left mid-arm at a
     crash. Holdings go to the monitor; PENDING_ENTRY snapshots go to
     EntryManager.adopt() (which re-adopts the resting order and resolves it,
     never re-placing). Pivot WATCHES are rehydrated separately by
     EntryManager.recover_watches(): same-session watches are restored, stale
     ones expire loudly, and a watch whose order was already placed pre-crash
     is closed idempotently. start() is IDEMPOTENT — run_forever() calls it
     and cli.py may have called it already; recovery must run exactly once.

  2. Entry polling + pivot watch. During an OPEN session each cycle polls the
     entry manager: the watch tick places the BUY limit only once a live quote
     prints last >= pivot; placed orders are then driven to a confirmed fill;
     fills append (via on_fill) to the monitor's live list. On the
     OPEN->CLOSED transition all still-untriggered watches expire — breakout
     signals are day orders.

  3. Heartbeat. Every cycle (any phase) writes one line to heartbeat_path so
     an EXTERNAL watcher (deadman.py) can detect process death by file mtime.
     The write is wrapped: a failing heartbeat must never kill the loop — the
     watcher treating a stale file as DOWN is the correct failure direction.

Arming is an explicit daily step (arm_today), NOT something the loop does on its
own — autonomous *management* is safe; autonomous *buying* should be a deliberate,
supervised call while you're forward-testing.

Account I/O note: sizing needs account equity and the buying-power gate needs
cash. KIS exposes these via inquire-balance(output2)/inquire-psamount, but those
field/TR contracts are not yet verified here — so equity_provider and
buying_power_provider are INJECTED. Until you've run them through
kis_contract_verify.py, wire conservative providers (or set require_buying_power
and let the fail-safe refuse to arm).
"""
from __future__ import annotations

import time
from datetime import datetime, timezone
from typing import Callable, Optional

# One page per orphan per this window. An orphan is resolved by a human,
# and a human does not need telling every session.
ORPHAN_ALERT_COOLDOWN_SECS = 6 * 3600
# NOTE: severity is NOT set by a prefix. notifier.classify() infers it from
# message text -- classify("CRITICAL ...") returns WARN. The orphan alert
# pushes because it contains "no local record", which is in the notifier's
# CRITICAL list. test_e10_alert_severity_contract pins that.

from kistrader.core.engine_v2 import ExecutionMonitor, EventStore, PositionState
from kistrader.core.run_loop import RunLoop
from kistrader.entry.entry_manager import (EntryManager, KISBrokerWithEntry,
                                           make_kis_buying_power_provider)
from kistrader.entry.decision_engine import DecisionEngine, DecisionConfig, AccountState
from kistrader.entry.screen_contract import (read_candidates, read_regime,
                                             regime_path_for,
                                             VCP_SCORE_THRESHOLD)
from kistrader.entry.exposure_controller import (ExposureController,
                                                 ExposureState,
                                                 loss_streak_from,
                                                 apply_to_decision_config)


class PipelineLoop(RunLoop):
    """RunLoop + entry watching/arming/polling + state-routed recovery."""

    def __init__(self, monitor, broker, entry_mgr: EntryManager,
                 decision: DecisionEngine, universe=None,
                 equity_provider: Optional[Callable[[], Optional[float]]] = None,
                 sector_of: Optional[Callable[[str], str]] = None,
                 heartbeat_path: Optional[str] = "heartbeat.txt",
                 candidates_path: str = "candidates.csv",
                 auto_arm: bool = False, exposure=None, **kw):
        super().__init__(monitor, broker, **kw)
        self.entry = entry_mgr
        self.decision = decision
        self.universe = universe          # TradableUniverse (gate); may be None
        self.equity_provider = equity_provider
        self.sector_of = sector_of
        self.heartbeat_path = heartbeat_path
        self.candidates_path = candidates_path
        self.auto_arm = auto_arm            # Step 6: unattended daily arm (opt-in)
        # Regime gate (Phase 3c). Stateless and injectable; it takes NUMBERS,
        # not a data source, so the caller owns the read and its failure path.
        # ExposureConfig(regime_ma=None) disables it and reproduces the
        # pre-Phase-3 behaviour exactly, which makes it the deployment control.
        self.exposure = exposure or ExposureController()
        self._orphan_alerted = {}    # ticker -> last alert time (see
                                     # _report_orphans; in memory by design)
        self._auto_armed_date = None        # once-per-session guard (any arm counts)
        self._started = False

    # ---- recovery routing (override; IDEMPOTENT) ----
    def start(self):
        if self._started:
            return                        # run_forever() calls start() too (cli.py
        self._started = True              # may already have) — recover exactly once
        recovered = self.mon.recover()                     # rehydrate + reconcile holdings
        holdings = [p for p in recovered if p.state != PositionState.PENDING_ENTRY]
        pendings = [p for p in recovered if p.state == PositionState.PENDING_ENTRY]
        have = {p.order_key for p in self._positions}
        for p in holdings:
            if p.order_key not in have:
                self._positions.append(p)
        if pendings:
            still = self.entry.adopt(pendings)             # re-adopt; NEVER re-place
            self.alert(f"recovery: {len(pendings)} pending entr(y/ies), "
                       f"{len(still)} still resting after adopt")
        watches = self.entry.recover_watches(self.clock.session_date())
        if watches:
            self.alert(f"recovery: {len(watches)} pivot watch(es) restored")
        self.mon.start_watchdog(self.positions, reconnect=None)
        self._last_phase = self.clock.phase()
        self.alert(f"started; {len(self.positions())} live; "
                   f"{len(self.entry.pending())} pending entry; "
                   f"{len(self.entry.watching())} watching; phase={self._last_phase}")

    # ---- per-cycle: monitor side, then watch/poll entries when OPEN ----
    def cycle(self):
        prev = self._last_phase                            # super() will update it
        before = self._state_map()                         # for exit-transition alerts
        phase = super().cycle()                            # exits/partials/day-roll/etc.
        if phase == "CLOSED":
            # Feed the monitor's feed-watchdog while the market is closed. Its
            # job is catching a silent quote feed DURING trading; with no feed
            # due, the minute-wise "feed silent" reconciles are pure noise plus
            # ~1k wasted KIS calls per night on a 24/7 box (observed 2026-07-21).
            self.mon.heartbeat()
        if (self.auto_arm and phase == "OPEN"
                and self._auto_armed_date != self.clock.session_date()):
            # Unattended mode (Step 6): ONE deliberate arm per session, at the
            # first OPEN cycle — always after start()/recovery, never before.
            # A stale, empty, or missing candidates.csv arms nothing, loudly:
            # arm_today's freshness gate refuses every row not dated for THIS
            # session, so a screener that didn't run cannot arm yesterday's
            # pivots. Recovery is fix-the-file THEN RESTART — the guard above
            # is in-memory and only clears on restart.
            self.arm_today(self.candidates_path)
        if phase == "OPEN" and (self.entry.pending() or self.entry.watching()):
            self.entry.poll()                              # watch tick + fills (on_fill)
        if prev == "OPEN" and phase == "CLOSED":
            n = self.entry.expire_watches("session close")
            if n:
                self.alert(f"session close: {n} untriggered watch(es) expired")
        self._alert_state_changes(before)                  # exits are otherwise SILENT
        self._prune_terminal()                             # after alerting, not before
        self._heartbeat(phase)
        return phase

    def _prune_terminal(self):
        """Drop CLOSED/CANCELLED positions once their transition has been alerted.
        RunLoop.positions() filters them from the managed view, but _positions
        itself is never pruned, so an always-on process accumulates every trade
        it has ever handled and _state_map() walks that whole list every cycle.
        Pruning AFTER _alert_state_changes preserves the notification; recovery
        is unaffected because recover() only ever returns non-terminal snapshots."""
        live = [p for p in self._positions
                if p.state.value not in ("CLOSED", "CANCELLED")]
        if len(live) != len(self._positions):
            self._positions = live

    # ---- exit visibility (non-invasive; zero engine_v2 edits) ----
    def _state_map(self) -> dict:
        # keyed by order_key over the RAW list: positions() filters terminal states,
        # so a CLOSED transition would vanish before we could report it.
        return {p.order_key: p.state for p in self._positions}

    def _alert_state_changes(self, before: dict):
        """Alert on every managed-position state transition.

        WHY: engine_v2's exit path PERSISTS its lifecycle (EXIT_BEGIN, ORDER_SENT,
        EXIT_FLAT_*, CLOSED) but never calls alert(). Confirmed live 2026-07-23:
        F hit its stop, a real SELL executed and the position closed in 58s with
        ZERO alert lines — unattended, that is a stop firing with no notification.
        Watching TRANSITIONS here instead of instrumenting each exit branch means
        no core edits and no exit path can be missed, including ones added later.

        order_keys absent from `before` are skipped: they are brand-new fills and
        EntryManager already announces those (avoids a duplicate alert)."""
        for p in self._positions:
            was = before.get(p.order_key)
            if was is None or was == p.state:
                continue
            last = self._last_price.get(p.ticker)
            if p.state == PositionState.EXITING:
                self.alert(f"{p.ticker} EXITING — {p.exit_reason or 'exit'} "
                           f"(stop {p.stop_loss_price:.2f}"
                           + (f", last {last:.2f}" if last else "") + ")")
            elif p.state == PositionState.CLOSED:
                # R only when risk is a real positive number (a seeded exit-test
                # position has stop>entry, i.e. negative R — reporting it would lie)
                r = (p.r_multiple(last) if last and p.initial_risk_per_share > 0
                     else None)
                self.alert(f"{p.ticker} CLOSED — {p.exit_reason or 'closed'}"
                           + (f" @ ~{last:.2f}" if last else "")
                           + (f", R={r:+.2f}" if r is not None else "")
                           + f" (entry {p.entry_price:.2f})")
            else:
                self.alert(f"{p.ticker} {was.value} -> {p.state.value}")

    def _heartbeat(self, phase: str):
        """One overwritten line; mtime is the liveness signal for deadman.py.
        MUST never raise — a broken heartbeat means the watcher alerts, which is
        the correct failure direction (loud, external), not a dead loop."""
        if not self.heartbeat_path:
            return
        try:
            with open(self.heartbeat_path, "w", encoding="utf-8") as f:
                f.write(f"{datetime.now(timezone.utc).isoformat()} phase={phase} "
                        f"live={len(self.positions())} "
                        f"pending={len(self.entry.pending())} "
                        f"watching={len(self.entry.watching())}\n")
        except Exception:
            pass

    # ---- explicit daily arm step ----
    def arm_today(self, candidates_path: str, session_date: Optional[str] = None):
        """Read the screener's candidates, gate to KIS-tradable names, size &
        select with the decision engine, and arm the survivors as pivot WATCHES
        (orders are placed by the loop only when last >= pivot). Returns
        (armed, rejections). Call once per session (e.g. shortly after open).
        Every rejection is logged individually — reasons must never be silent.
        Rows not dated for THIS session are dropped; a file with no fresh rows,
        or no file at all, arms nothing and alerts CRITICAL (ARM BLOCKED)."""
        session_date = session_date or self.clock.session_date()
        # Any arm attempt (even one the fail-safe aborts below) satisfies the
        # auto-arm once-per-session guard: a failed arm becomes ONE loud
        # "skipping arm (fail-safe)" no-trade day, not a 7-second retry storm.
        self._auto_armed_date = session_date
        # A missing/unreadable file must NOT raise out of cycle(): run_forever has
        # no per-cycle guard, so an uncaught read error is a deterministic restart
        # loop ending at the crash-storm guard — a failed SCREENER stopping the
        # loop from MANAGING held positions.
        bad_rows = []
        # --- PATCH AD (schema v4) --- note_rows are NOT rejections. They are
        # rows that WOULD be rejected once REQUIRE_CATALYST_EVIDENCE is flipped.
        # Logging them is how the flip becomes a decision instead of a surprise.
        note_rows = []
        try:
            cands = read_candidates(candidates_path,
                                    on_bad=lambda row, why: bad_rows.append(why),
                                    on_note=lambda row, why: note_rows.append(
                                        (row.get("ticker"), why)))
        except Exception as e:
            self.alert(f"ARM BLOCKED: could not read {candidates_path} "
                       f"({type(e).__name__}: {e}) — arming NOTHING (fail-safe). "
                       f"Fix the file, then RESTART the loop to re-arm this session.")
            return [], []
        for why in bad_rows:
            self.alert(f"bad candidate row: {why}")
        # --- PATCH AD (schema v4) ---
        if note_rows:
            self.alert(f"catalyst evidence: {len(note_rows)} candidate(s) would "
                       f"be rejected once REQUIRE_CATALYST_EVIDENCE is on "
                       f"(nothing dropped now)")
            for tkr, why in note_rows:
                self.alert(f"  evidence gap {tkr}: {why[0] if why else ''}")
        # --- end PATCH AD (schema v4) ---
        # §freshness gate. The emit side purges stale rows when it WRITES, so a
        # stale file means the screener did not run at all. Runs BEFORE
        # universe.ensure() and _account_state() so a stale day costs no KIS call.
        fresh = [c for c in cands if c.session_date == session_date]
        n_stale = len(cands) - len(fresh)
        if n_stale:
            bad_dates = ",".join(sorted({(c.session_date or "<missing>")
                                         for c in cands if c.session_date != session_date}))
            if not fresh:
                self.alert(f"ARM BLOCKED: candidates.csv is entirely STALE — "
                           f"{n_stale} row(s) dated {bad_dates}, expected {session_date}. "
                           f"Arming NOTHING. Fix the CSV, then RESTART the loop to re-arm.")
                return [], []
            self.alert(f"freshness gate: dropped {n_stale} STALE row(s) dated {bad_dates} "
                       f"(expected {session_date}); {len(fresh)} fresh row(s) kept")
        cands = fresh

        # §regime gate (Phase 3c). Evaluated after the freshness gate and
        # before universe.ensure()/_account_state(), so the DECISION never
        # depends on a KIS call. Note it does NOT short-circuit: plan() still
        # runs, because a named rejection per candidate is what makes a
        # regime-off day auditable. A risk-off day therefore still costs the
        # account read -- cheap, and the alternative is a second gate, which
        # is the shape of the orphan open_notional bug.
        #
        # The sidecar is written by the screener beside candidates.csv. Anything
        # unusable -- missing, stale, malformed, screeners disagreeing about the
        # benchmark, or an --emit-threshold degraded run -- becomes (None, None),
        # which ExposureController turns into UNAVAILABLE and a 0.0 ceiling.
        # A gate that cannot evaluate must not pass.
        bclose, bma, rmeta = read_regime(
            regime_path_for(candidates_path), session_date,
            # F2/F3: the sidecar records what the screener ACTUALLY applied.
            # Cross-check both against what this trader believes, or a
            # screener running at a different bar -- or on a different MA
            # window than the one being logged -- arms silently.
            expected_threshold=float(VCP_SCORE_THRESHOLD),
            expected_regime_ma=self.exposure.cfg.regime_ma)
        # PATCH F2 -- the handshake is enforced whether or not the regime
        # gate is on. rmeta["validated"] is False for a missing, stale,
        # malformed, disagreeing, degraded or threshold-mismatched sidecar.
        # --- E10 layer 2 --- progressive exposure. The controller takes a
        # NUMBER by design, so the READ and its failure path are owned here.
        # Skipped entirely while the gate is off, so the default tree makes no
        # extra database call and its behaviour is unchanged.
        streak = None
        if self.exposure.cfg.loss_streak_ceilings is not None:
            try:
                # --- E10 layer 2b --- a skip must never be silent. Two of the
                # four errors on 2026-09-19 were a filter dropping rows with
                # nothing saying so; a gate quietly not biting is the same
                # shape. Graded by cause: a seed is routine, an unexplained
                # close is not.
                _skipped = {"seeded": [], "unknown": []}
                streak = loss_streak_from(self.mon.db.recent_closed_r(
                    on_skip=lambda k, why: _skipped[why].append(k)))
                _sd, _un = _skipped["seeded"], _skipped["unknown"]
                if _sd:
                    # WARN: log only. Excluding a seed is correct behaviour.
                    self.alert("loss-streak: skipped %d manually seeded "
                               "close(s) -- not strategy trades, so they do "
                               "not move the ceiling (%s)"
                               % (len(_sd), ", ".join(_sd)))
                if _un:
                    # CRITICAL via "manual check": neither ENTRY_ nor SEEDED_
                    # means a code path nobody registered, or a pruned log.
                    # Both change what the gate is doing.
                    self.alert("loss-streak: %d close(s) of UNKNOWN "
                               "provenance -- no ENTRY_ and no SEEDED_ event "
                               "on the key, so they were SKIPPED and the "
                               "streak may be wrong. manual check: either a "
                               "new entry path or a pruned log (%s)"
                               % (len(_un), ", ".join(_un)))
            except Exception as _e:            # noqa: BLE001 -- see below
                # " error:" is a notifier CRITICAL substring on purpose. The
                # streak stays None, decide() then fails closed at a 0%
                # ceiling, and a silent halt is worth a phone push.
                self.alert(f"loss-streak read error: {_e!r} -- the "
                           f"progressive-exposure gate cannot evaluate")
        regime = self.exposure.decide(
            bclose, bma, handshake_ok=rmeta.get("validated", False),
            loss_streak=streak)
        if regime.state is ExposureState.RISK_ON:
            self.alert(f"regime: RISK_ON — {rmeta['reason'] or regime.reason}")
        elif regime.state is ExposureState.RISK_OFF:
            # The market answered the question. Normal operation on a no-trade
            # day: logged, NOT pushed. The operator must still be able to tell
            # this apart from "nothing qualified", which is why the sidecar
            # reason is carried.
            self.alert(f"regime RISK_OFF: {regime.reason} "
                       f"[sidecar: {rmeta['reason']}] — exposure ceiling "
                       f"{regime.max_portfolio_exposure_pct:.0%}, NO new entries. "
                       f"Exits and existing positions are unaffected.")
        elif regime.state is ExposureState.LOSS_STREAK:
            # --- E10 layer 2 --- progressive exposure biting on our OWN closed
            # trades. NORMAL operation after a run of losses: logged, never
            # pushed. It does NOT block arming -- the ceiling is partial, so
            # plan() still fills up to it. Must never contain "ARM BLOCKED";
            # without this branch the decision fell through to the UNAVAILABLE
            # message below and a routine streak read as a regime FAULT.
            self.alert(f"progressive exposure: {regime.reason} -- ceiling "
                       f"{regime.max_portfolio_exposure_pct:.0%}, new entries "
                       f"limited. Exits and existing positions are unaffected.")
        else:
            # UNAVAILABLE is not a market verdict, it is a fault: a missing or
            # stale sidecar, screeners disagreeing, a threshold or regime_ma
            # mismatch, or an --emit-threshold run. All of them stop trading
            # entirely, and none of them fixes itself.
            #
            # "ARM BLOCKED" is load-bearing: notifier.classify() routes on
            # message text, and that phrase is what makes this a phone push
            # instead of a line in a log nobody reads. Do not reword it without
            # checking CRITICAL_SUBSTRINGS.
            self.alert(f"ARM BLOCKED: regime UNAVAILABLE — {regime.reason} "
                       f"[sidecar: {rmeta['reason']}] — exposure ceiling "
                       f"{regime.max_portfolio_exposure_pct:.0%}, NO new entries "
                       f"until this is fixed. Exits and existing positions are "
                       f"unaffected.")
        # ONE GATE, ONE SOURCE: write the existing ceiling rather than adding a
        # second check. Built per call, so a ceiling never leaks across sessions.
        gated = DecisionEngine(apply_to_decision_config(self.decision.cfg, regime))
        # §2.5 tradability gate: drop names KIS can't trade, and stamp the exchange
        if self.universe is not None:
            self.universe.ensure()
            keep = []
            for c in cands:
                ex = self.universe.resolve(c.ticker)
                if ex:
                    c.exchange = ex
                    keep.append(c)
                else:
                    self.alert(f"gate: {c.ticker} not KIS-tradable — dropped")
            cands = keep

        account = self._account_state()
        if account is None:
            # _account_state() returns None for EITHER a missing equity
            # reading or an unreadable holdings read, and both branches now
            # alert with their own cause. This line must not claim one:
            # on 2026-09-08 and 09-11 it blamed equity for a holdings
            # failure, and equity is a constant that cannot fail.
            self.alert("ARM BLOCKED: account state unavailable (cause on "
                       "the preceding line) -- skipping arm (fail-safe)")
            return [], []
        plans, drej = gated.plan(cands, account)
        armed, arej = self.entry.arm_batch(plans, account, session_date)
        rejections = drej + arej
        # Brief sec.9 "cheap + legitimate": the SCORES belong on these
        # lines, not just the reason. At max 1 armable name per session
        # (RESULT_20260911_emit_bar_yield_measured sec.8) a soak produces
        # almost all of its information as near-misses, and a reason alone
        # cannot say how close anything came.
        #
        # Read off the Candidate rather than added to Rejection: that
        # dataclass is built at ~8 sites across decision_engine and
        # entry_manager, and widening it would touch the live arm path and
        # the test suite to carry data already in scope here. A ticker not
        # found falls back to the bare line -- a fabricated rs=0 in a log
        # meant for distribution analysis is worse than an absent field.
        _cand_by_ticker = {c.ticker: c for c in cands}
        for r in rejections:
            _rc = _cand_by_ticker.get(r.ticker)
            if _rc is None:
                self.alert(f"arm reject: {r.ticker} — {r.reason}")
            else:
                self.alert(f"arm reject: {r.ticker} — {r.reason} "
                           f"[rs={_rc.rs_proxy} s2={_rc.stage2_score:.1f} "
                           f"vcp={_rc.vcp_score:.1f}]")
        self.alert(f"arm_today: {len(cands)} candidates -> {len(plans)} planned "
                   f"-> {len(armed)} armed ({len(self.entry.watching())} watching, "
                   f"{len(self.entry.pending())} order(s) live)")
        return armed, rejections

    def _report_orphans(self, orphans):
        """One alert per orphan per ORPHAN_ALERT_COOLDOWN_SECS.

        An orphan is resolved by a human, and a human does not need telling
        every session. Entries are pruned once the holding is gone, so a name
        that reappears after being closed alerts immediately instead of waiting
        out a stale timer.

        In memory only: a restart re-alerts. The notifier's own dedup window
        limits that, and a restart loop is a bigger problem than a repeat page."""
        now = time.time()
        still_held = {t for t, *_ in orphans}
        for t in list(self._orphan_alerted):
            if t not in still_held:
                del self._orphan_alerted[t]
        for t, qty, notional, ex, last in orphans:
            if now - self._orphan_alerted.get(t, 0.0) < ORPHAN_ALERT_COOLDOWN_SECS:
                continue
            self._orphan_alerted[t] = now
            self.alert(
                # "no local record" is LOAD-BEARING: notifier.classify()
                # routes on message text and that phrase is in its
                # CRITICAL list. Reword it and this stops being a phone
                # push and becomes a line in a log nobody reads.
                f"ORPHAN {t} — {qty} sh held at the broker "
                f"with NO local record (last ${last:,.2f}, ~${notional:,.0f}). "
                f"Counted against the exposure ceiling; NOT managed: no stop, no "
                f"+3R partial, no trail. Handle it manually — seed it to manage, "
                f"or close it in the broker app: "
                f"kistrader seed --ticker {t} --shares {qty} --entry <FILL> "
                f"--stop <FROM CHART> --exchange {ex} --confirm "
                f"(repeats every {ORPHAN_ALERT_COOLDOWN_SECS // 3600}h until it is "
                f"seeded or gone)")

    def _orphan_detail(self, ticker: str, qty: int):
        """Value a broker holding we have no local record for.

        Returns (notional, exchange, last_price) or None. The exchange is
        returned as well as used, so the alert can put the RIGHT code into the
        seed command instead of letting the --exchange NAS default silently
        mis-seed a NYSE name.

        ACCOUNTING ONLY. This never becomes a managed Position: the armed record
        is what carries the stop, and a managed position with no stop is worse
        than an unmanaged one. It exists so the orphan counts against the
        exposure ceiling instead of being invisible to it.

        Returns None when the name cannot be priced -- unresolvable exchange, a
        failed or zero quote. The caller turns that into a refusal to arm.
        Guessing a value here would understate exposure silently, which is the
        exact failure this phase removes."""
        ex = self.universe.resolve(ticker) if self.universe is not None else "NAS"
        if not ex:
            return None
        try:
            q = self.broker.get_quote(ticker, ex)
        except Exception:                      # noqa: BLE001 — transport failure
            return None
        last = float((q or {}).get("last") or 0)
        return (qty * last, ex, last) if last > 0 else None

    def _account_state(self) -> Optional[AccountState]:
        equity = self.equity_provider() if self.equity_provider else None
        if equity is None:
            # Alert HERE, where the cause is known. The caller sees only
            # None and cannot tell this path from the holdings one below.
            self.alert("ARM BLOCKED: no equity reading -- skipping arm "
                       "(fail-safe)")
            return None
        # cash is advisory here — the ENFORCED cash gate is arm_batch's
        # buying-power check. Prefer the (USD) buying-power provider so the field
        # is truthful; fall back to equity only if no provider is wired.
        cash = self.entry._buying_power()
        if cash is None:
            cash = float(equity)
        # §R3/D5. UNKNOWN is not flat. This used to degrade to an EMPTY held set,
        # which fails OPEN on both gates that depend on it: dedup stops seeing
        # real holdings, and exposure would measure zero -- full headroom -- with
        # nothing downstream to re-check it.
        truth = self.broker.get_all_holdings()
        if truth is None:
            self.alert("ARM BLOCKED: broker holdings UNREADABLE — cannot measure "
                       "exposure or de-duplicate against real positions. Arming "
                       "NOTHING (fail-safe). Exits and open positions are "
                       "unaffected.")
            return None
        held = frozenset(truth)
        live = self.positions()

        # Exposure is measured from BROKER truth, the same source held_tickers
        # uses -- one source, not two. Every reported holding counts, including
        # ones we have no record of.
        by_ticker = {}
        for p in live:
            by_ticker.setdefault(p.ticker, []).append(p)
        open_notional, unpriced, orphans = 0.0, [], []
        for t, qty in truth.items():
            qty = int(qty or 0)
            if qty <= 0:
                continue
            ps = by_ticker.get(t)
            if ps:
                # quantity from the broker, price from our own record. Taking the
                # LARGER share count is the conservative direction: more measured
                # exposure means fewer new entries, never more.
                open_notional += max(qty, sum(p.shares for p in ps)) * ps[0].entry_price
            else:
                det = self._orphan_detail(t, qty)
                if det is None:
                    unpriced.append(t)
                else:
                    open_notional += det[0]
                    orphans.append((t, qty) + det)
        # A position we track that the broker does not report yet (the
        # pre-reconcile window) still occupies capital -- count it rather than
        # lose it.
        for p in live:
            if p.ticker not in truth:
                open_notional += p.shares * p.entry_price
        # Report the orphans we COULD price before deciding whether to refuse:
        # an unpriceable one must not hide the others.
        self._report_orphans(orphans)
        if unpriced:
            self.alert("ARM BLOCKED: broker holds " + ", ".join(sorted(unpriced)) +
                       " with no local record and no usable price — exposure "
                       "cannot be measured, so it cannot be respected. Arming "
                       "NOTHING (fail-safe). Seed or close the position.")
            return None
        sector_counts = {}
        if self.sector_of:
            for p in live:
                s = self.sector_of(p.ticker)
                if s:
                    sector_counts[s] = sector_counts.get(s, 0) + 1
        return AccountState(
            equity=float(equity), cash=float(cash),
            held_tickers=held,
            pending_tickers=frozenset(self.entry._pending_tickers()),
            open_position_count=len(live), open_notional=open_notional,
            sector_counts=sector_counts, sector_of=self.sector_of)


def build_pipeline(app_key, app_secret, cano, *, is_mock=True,
                   db_path="kis_engine_state.db", candidates_path="candidates.csv",
                   decision_config: Optional[DecisionConfig] = None,
                   equity_provider=None, buying_power_provider=None,
                   sector_of=None, universe=None, alert=None,
                   require_buying_power=True, auto_buying_power=False,
                   require_open_order_check=True,
                   ema_provider=None, close_provider=None,
                   breakout_volume=False, breakout_volume_provider=None,
                   require_breakout_volume=False,
                   # --- PATCH AK (trigger extension) --- None = log only
                   max_trigger_extension_pct=None,
                   # --- end PATCH AK (trigger extension) ---
                   heartbeat_path="heartbeat.txt", auto_arm=False):
    """One-call wiring for a forward-test. Returns (loop, ctx-dict) so you can
    reach the parts. Uses KISBrokerWithEntry so entry_price can use real VWAP.
    Pass ema_provider/close_provider (see providers.DailyCloseEMAProvider) to
    activate the EMA-trail (§4.2.3) and stall-exit (§4.2.4); without them those
    two exit rules stay dormant and the loop warns once.
    auto_buying_power=True wires make_kis_buying_power_provider off the broker
    (⚠ still `# VERIFY` — confirm the endpoint with `kistrader verify` first)."""
    broker = KISBrokerWithEntry(app_key, app_secret, cano, is_mock=is_mock)
    db = EventStore(db_path)
    monitor = ExecutionMonitor(broker, db, alert=alert)

    if auto_buying_power and buying_power_provider is None:
        # alert= so a UNKNOWN refusal names its cause. Without it the only
        # record is "buying power UNKNOWN", which states the policy and not
        # the fault (FINDING_20260916).
        buying_power_provider = make_kis_buying_power_provider(broker,
                                                              alert=alert)

    # --- PATCH AF (S2 breakout volume) --- same shape as auto_buying_power:
    # the provider is wired off THIS broker rather than passed in, because the
    # broker does not exist until this function builds it.
    if breakout_volume and breakout_volume_provider is None:
        breakout_volume_provider = broker.get_session_volume
    if require_breakout_volume and breakout_volume_provider is None:
        raise ValueError(
            "require_breakout_volume=True with no provider would arm NOTHING, "
            "silently and forever -- every breakout would be held on 'no "
            "provider is wired'. Pass breakout_volume=True (wires the KIS "
            "session-volume read off this broker) or supply "
            "breakout_volume_provider. See REVIEW_20260904 sec.2, where exactly "
            "this combination shipped and no test could see it.")
    # --- end PATCH AF (S2 breakout volume) ---

    # on_fill: newly filled entries join the managed list the monitor iterates.
    loop_ref = {}
    def on_fill(pos):
        loop = loop_ref.get("loop")
        if loop is not None:
            loop._positions.append(pos)

    entry = EntryManager(broker, db, on_fill=on_fill, alert=alert,
                         buying_power_provider=buying_power_provider,
                         require_buying_power=require_buying_power,
                         require_open_order_check=require_open_order_check,
                         # --- PATCH AF (S2 breakout volume) ---
                         breakout_volume_provider=breakout_volume_provider,
                         require_breakout_volume=require_breakout_volume,
                         # --- end PATCH AF (S2 breakout volume) ---
                         # --- PATCH AK (trigger extension) ---
                         max_trigger_extension_pct=max_trigger_extension_pct)
                         # --- end PATCH AK (trigger extension) ---
    # Let recover()/reconcile adopt a late fill (orphan holding) against the stop we
    # recorded when we armed the order, instead of leaving it unmanaged (bug B).
    monitor.orphan_resolver = entry.resolve_orphan

    decision = DecisionEngine(decision_config or DecisionConfig())
    loop = PipelineLoop(monitor, broker, entry, decision, universe=universe,
                        equity_provider=equity_provider, sector_of=sector_of,
                        heartbeat_path=heartbeat_path,
                        candidates_path=candidates_path, auto_arm=auto_arm,
                        alert=alert, ema_provider=ema_provider,
                        close_provider=close_provider)
    loop_ref["loop"] = loop
    return loop, {"broker": broker, "db": db, "monitor": monitor,
                  "entry": entry, "decision": decision,
                  "candidates_path": candidates_path}


if __name__ == "__main__":
    # Sketch only — fill in credentials/providers to run a real forward test.
    #
    #   loop, ctx = build_pipeline(APP_KEY, APP_SECRET, CANO, is_mock=True,
    #                              equity_provider=lambda: 100_000.0,
    #                              buying_power_provider=my_verified_cash_fn,
    #                              universe=TradableUniverse())
    #   loop.start()                      # routes recovery (holdings/pending/watches)
    #   loop.arm_today(ctx["candidates_path"])   # explicit daily step -> WATCHES
    #   loop.run_forever()                # trigger on pivot; manage fills & exits
    print(__doc__)
