"""
14_pyramid_design.py -- WHICH pyramid is best, not whether to pyramid.

13_pyramid.py answered "does adding pay". On threshold-70 daily signals it did:
edge = E[r | MFE>=T] - T came back POSITIVE at every trigger. This script
searches the design space and applies the constraints 13 ignored.

FIVE THINGS THIS ADDS OVER 13_pyramid.py
  1. POSITION-CAP FEASIBILITY. notional_1 = risk/stop; the add costs
     k*notional_1*(1+T*stop) more. max_position_pct caps the SUM. A variant
     that breaches it is marked INFEASIBLE and excluded from the ranking
     rather than reported as a winner you cannot run.
  2. MULTI-TRANCHE. Minervini builds in 2-3 steps, not one.
  3. RISK-CONSTANT FAMILY. Start at fraction f of full size and build back to
     1.0 on strength. Max risk never exceeds the current 1.0R.
  4. BOOTSTRAP. The whole gain in the 13_pyramid run came from 103 EMA_BREAK
     trades. Resampling says whether that survives its own sample noise.
  5. DISPLACEMENT COST. The overlay gives the add free capital. It is not
     free -- at threshold 70 capacity rejections outnumber accepted plans.
     This reports how many foregone new entries each add can afford to
     crowd out before it stops paying.

STILL NOT MODELLED (unchanged from 13_pyramid.py, read them again)
  - a breakeven stop whipsawing a trade that dips and recovers: upper bound
  - the +3R partial (R_PARTIAL_MULTIPLE=3.0, PARTIAL_FRACTION=1/3)
  - intra-trade dips that would have stopped the add before the final exit

ENTANGLEMENT WARNING, verified in minervini_backtest.py:705-710. A trade is
promoted FILLED -> TRAILING only if r >= stall_r_floor at stall_day, and
EMA_BREAK can fire only from TRAILING. With the defaults stall_day=10 and
stall_r_floor=1.0, every EMA_BREAK trade was at >=1.0R on day 10 BY
CONSTRUCTION. An add trigger at T=1.0 is therefore nearly the same test as the
promotion gate. Changing stall_day or stall_r_floor will move this result.
Sweep T away from 1.0 and check the answer holds.

Usage:
    python scripts/14_pyramid_design.py --threshold 70 --signals data/signals_daily.pkl
    python scripts/14_pyramid_design.py --threshold 70 --signals data/signals_daily.pkl --start 2018-01-01 --end 2022-06-30
    python scripts/14_pyramid_design.py --threshold 70 --signals data/signals_daily.pkl --start 2022-07-01
"""
import pathlib as _pl
import sys as _sys
_sys.path.insert(0, str(_pl.Path(__file__).resolve().parent.parent))

import argparse
import itertools
import pathlib
import pickle
import numpy as np
import pandas as pd

from minervini_backtest import (BacktestConfig, DecisionConfig, load_sector_map,
                                run)


# --------------------------------------------------------------------------- #
# Overlay primitives. Every one uses ONLY max_r_seen and r_at_exit.
#
# Tranche stop by continuity: if the trade FINISHED below (T - s) it must have
# passed through (T - s) after the add, so that tranche was stopped at -s. If it
# finished above, the overlay lets it ride -- it cannot see an intra-trade dip.
# --------------------------------------------------------------------------- #
def tranche_pnl(m, r, T, k, s):
    """P&L of one added tranche, in units of tranche-1 risk."""
    return np.where(m >= T, k * np.maximum(r - T, -s), 0.0)


def base_leg(m, r, be_at):
    """Tranche 1. be_at=None -> untouched. Otherwise stop to breakeven once
    MFE reaches be_at."""
    if be_at is None:
        return r
    return np.where(m >= be_at, np.maximum(r, 0.0), r)


def variant_add_on_top(m, r, trigs, be_at):
    """Full-size tranche 1, then add. Max risk grows above 1.0R."""
    out = base_leg(m, r, be_at)
    for (T, k, s) in trigs:
        out = out + tranche_pnl(m, r, T, k, s)
    return out


def variant_risk_constant(m, r, f, trigs, be_at):
    """Start at fraction f of full size, build back toward 1.0 on strength.
    Max risk NEVER exceeds 1.0R (the current system's risk)."""
    out = f * base_leg(m, r, be_at)
    for (T, k, s) in trigs:
        out = out + tranche_pnl(m, r, T, k, s)
    return out


def max_risk_R(f, trigs):
    return f + sum(k * s for (_T, k, s) in trigs)


def peak_notional_frac(f, trigs, risk_pct, stop_pct):
    """Fraction of equity in the name once every tranche has filled."""
    n1 = risk_pct / stop_pct
    tot = f * n1
    for (T, k, _s) in trigs:
        tot += k * n1 * (1.0 + T * stop_pct)
    return tot


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--threshold", type=float, default=70.0)
    ap.add_argument("--slippage", type=float, default=5.0)
    ap.add_argument("--signals", default="data/signals.pkl")
    ap.add_argument("--start", default=None)
    ap.add_argument("--end", default=None)
    ap.add_argument("--risk-pct", type=float, default=0.0075,
                    help="risk_per_trade_pct the design must live under")
    ap.add_argument("--max-position-pct", type=float, default=0.20,
                    help="decision_engine max_position_pct")
    ap.add_argument("--stop-pct", type=float, default=0.0625,
                    help="average stop distance; 0.0625 was derived as "
                         "risk_per_trade_pct / measured notional fraction")
    ap.add_argument("--boot", type=int, default=2000)
    ap.add_argument("--top", type=int, default=15)
    args = ap.parse_args()

    bars = {p.stem: pd.read_parquet(p)
            for p in pathlib.Path("data/bars").glob("*.parquet")}
    prices = {t: d for t, d in bars.items() if t != "^GSPC"}
    with open(args.signals, "rb") as f:
        signals = pickle.load(f)["signals"]
    if args.start or args.end:
        lo = pd.Timestamp(args.start) if args.start else pd.Timestamp.min
        hi = pd.Timestamp(args.end) if args.end else pd.Timestamp.max
        signals = {d: v for d, v in signals.items() if lo <= pd.Timestamp(d) <= hi}
    if not signals:
        raise SystemExit("[pyr2] no signals in the requested window")

    _b = bars.get("^GSPC")
    cfg = BacktestConfig(rank_mode="rs_only", equity_mode="compounding",
                         entry_mode="pivot_limit", ambiguity_mode="worst",
                         vcp_threshold=args.threshold, slippage_bps=args.slippage,
                         sector_map=load_sector_map("data/sectors.csv"),
                         decision=DecisionConfig(),
                         benchmark_close=(_b["Close"] if _b is not None else None))
    eq, trades, st, dr, dg = run(prices, signals, cfg)
    if not trades:
        raise SystemExit("[pyr2] no trades")

    m = np.array([float(t.max_r_seen) for t in trades])
    r = np.array([float(t.r_at_exit) for t in trades])
    reasons = [t.reason for t in trades]
    n = len(trades)
    base = r.mean()

    print("=" * 86)
    print(f"PYRAMID DESIGN SEARCH  threshold={args.threshold}  {n} trades  "
          f"{min(signals).date()}..{max(signals).date()}")
    print(f"constraints: risk/trade {args.risk_pct*100:.2f}%   "
          f"max_position_pct {args.max_position_pct*100:.0f}%   "
          f"assumed stop {args.stop_pct*100:.2f}%")
    print("=" * 86)
    print(f"  baseline expectancy {base:+.4f} R  (harness {st['expectancy_R']:+.3f} R)")
    if abs(base - float(st["expectancy_R"])) > 0.02:
        print("  *** MISMATCH vs harness expectancy_R -- STOP and check r_at_exit.")
    print()

    # ------------------------------------------------------------------ 1
    print("  1. POSITION-CAP FEASIBILITY  (why some designs cannot be run)")
    n1 = args.risk_pct / args.stop_pct
    print(f"     tranche-1 notional = risk/stop = {n1*100:.1f}% of equity")
    print(f"     {'trigger T':>10}{'max k under the cap':>24}")
    for T in (0.5, 1.0, 1.5, 2.0):
        kmax = (args.max_position_pct / n1 - 1.0) / (1.0 + T * args.stop_pct)
        print(f"     {T:>10.1f}{max(kmax,0.0):>24.3f}")
    print("     A single add larger than this breaches max_position_pct.")
    print()

    # ------------------------------------------------------------------ 2
    designs = []
    Ts = (0.5, 0.75, 1.0, 1.5, 2.0)
    ks = (0.25, 0.5, 0.75, 1.0)
    ss = (0.25, 0.5, 0.75, 1.0)

    for T, k, s in itertools.product(Ts, ks, ss):
        for be in (None, T):
            designs.append((f"1-add T={T} k={k} s={s}"
                            f"{' +BE' if be else ''}", 1.0, [(T, k, s)], be))
    for T1, T2 in ((0.5, 1.5), (1.0, 2.0), (0.5, 1.0), (1.0, 2.5)):
        for k in (0.25, 0.5):
            for s in (0.5, 1.0):
                for be in (None, T1):
                    designs.append((f"2-add T={T1}/{T2} k={k} s={s}"
                                    f"{' +BE' if be else ''}", 1.0,
                                    [(T1, k, s), (T2, k, s)], be))
    for f0 in (0.5, 0.67):
        for T in (0.5, 1.0, 1.5):
            for s in (0.5, 1.0):
                for be in (None, T):
                    designs.append((f"risk-const f={f0} T={T} s={s}"
                                    f"{' +BE' if be else ''}", f0,
                                    [(T, 1.0 - f0, s)], be))

    rows = []
    for label, f0, trigs, be in designs:
        v = (variant_risk_constant(m, r, f0, trigs, be) if f0 != 1.0
             else variant_add_on_top(m, r, trigs, be))
        peak = peak_notional_frac(f0, trigs, args.risk_pct, args.stop_pct)
        rows.append(dict(label=label, exp=float(v.mean()), risk=max_risk_R(f0, trigs),
                         peak=peak, feasible=peak <= args.max_position_pct + 1e-12,
                         vec=v))

    feas = [x for x in rows if x["feasible"]]
    infeas = [x for x in rows if not x["feasible"]]
    print(f"  2. RANKING  ({len(feas)} feasible of {len(rows)} designs; "
          f"{len(infeas)} breach the position cap)")
    print(f"     {'design':<34}{'exp R':>9}{'vs base':>9}{'maxRisk':>9}"
          f"{'peak notional':>15}{'exp/risk':>10}")
    for x in sorted(feas, key=lambda d: -d["exp"])[:args.top]:
        print(f"     {x['label']:<34}{x['exp']:>+9.4f}{x['exp']-base:>+9.4f}"
              f"{x['risk']:>8.2f}R{x['peak']*100:>14.1f}%"
              f"{x['exp']/x['risk']:>10.4f}")
    print()
    print("     best design that BREACHES the cap (for reference only):")
    if infeas:
        b = max(infeas, key=lambda d: d["exp"])
        print(f"     {b['label']:<34}{b['exp']:>+9.4f}{b['exp']-base:>+9.4f}"
              f"{b['risk']:>8.2f}R{b['peak']*100:>14.1f}%   INFEASIBLE")
    print()

    # ------------------------------------------------------------------ 3
    print(f"  3. BOOTSTRAP on the top feasible design ({args.boot} resamples)")
    best = max(feas, key=lambda d: d["exp"])
    idx = np.random.default_rng(0).integers(0, n, size=(args.boot, n))
    bs_best = best["vec"][idx].mean(axis=1)
    bs_base = r[idx].mean(axis=1)
    delta = bs_best - bs_base
    print(f"     design            : {best['label']}")
    print(f"     point estimate    : {best['exp']-base:+.4f} R over baseline")
    print(f"     5th / 50th / 95th : {np.percentile(delta,5):+.4f} / "
          f"{np.percentile(delta,50):+.4f} / {np.percentile(delta,95):+.4f}")
    print(f"     P(improvement > 0): {100*np.mean(delta>0):.1f}%")
    if np.percentile(delta, 5) <= 0:
        print("     *** the 5th percentile is not above zero -- this is not a result")
    print()

    # ------------------------------------------------------------------ 4
    print("  4. LEAVE-ONE-COHORT-OUT  (does one exit reason carry everything?)")
    print(f"     {'excluded cohort':<16}{'n left':>8}{'base':>10}{'design':>10}{'gain':>10}")
    for excl in sorted(set(reasons)):
        keep = np.array([x != excl for x in reasons])
        if keep.sum() < 30:
            continue
        print(f"     {excl:<16}{int(keep.sum()):>8}{r[keep].mean():>+10.4f}"
              f"{best['vec'][keep].mean():>+10.4f}"
              f"{best['vec'][keep].mean()-r[keep].mean():>+10.4f}")
    print()

    # ------------------------------------------------------------------ 5
    print("  5. DISPLACEMENT TOLERANCE  (the overlay gives the add free capital)")
    for T, k, s in ((1.0, 0.5, 0.5), (1.0, 0.25, 0.5), (0.5, 0.5, 0.5)):
        fired = int((m >= T).sum())
        if not fired:
            continue
        tot = tranche_pnl(m, r, T, k, s).sum()
        per_add = tot / fired
        print(f"     T={T} k={k} s={s}: {fired} adds, {per_add:+.4f} R each; "
              f"each add can crowd out {per_add/base:.1f} new entries "
              f"(worth {base:+.4f} R) before it stops paying")
    print()

    # ------------------------------------------------------------------ 6
    print("  6. TRIGGER SENSITIVITY  (is this just the stall_r_floor gate?)")
    print(f"     {'T':>6}{'n fire':>9}{'E[r|MFE>=T]':>14}{'edge':>9}")
    for T in (0.25, 0.5, 0.75, 1.0, 1.25, 1.5, 2.0, 2.5, 3.0):
        sel = m >= T
        if not sel.any():
            continue
        e = r[sel].mean()
        print(f"     {T:>6.2f}{int(sel.sum()):>9}{e:>+14.3f}{e-T:>+9.3f}")
    print("     stall_r_floor is 1.0. If the edge is positive ONLY at T=1.0 this")
    print("     is the promotion gate wearing a pyramid costume. If it holds at")
    print("     0.5 and 2.0 as well, it is a real property of the trades.")
    print()
    print("=" * 86)
    print("  Re-run with --start 2018-01-01 --end 2022-06-30 and --start 2022-07-01.")
    print("  Six parameters already reversed on the split. Nothing here counts")
    print("  until the winning design wins in BOTH halves.")


if __name__ == "__main__":
    main()
