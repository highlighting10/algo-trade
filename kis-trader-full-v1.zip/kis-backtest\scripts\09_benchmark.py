"""
09_benchmark.py -- the comparison every number in this project has been missing.

A strategy returning +19% over 8.6 years means nothing without knowing what the
market did over the SAME window. This computes buy-and-hold ^GSPC on the exact
stats window the backtest used, plus each half, so the split-sample reversals can
be read against the regime they happened in.

Usage:
    python scripts/09_benchmark.py --threshold 70 --signals data/signals_daily.pkl
    python scripts/09_benchmark.py --threshold 70 --signals data/signals_daily.pkl \\
        --split 2022-07-01
"""
import pathlib as _pl
import sys as _sys
_sys.path.insert(0, str(_pl.Path(__file__).resolve().parent.parent))

import argparse
import pathlib
import pickle

import pandas as pd

from minervini_backtest import (BacktestConfig, DecisionConfig, load_sector_map,
                                run)


def bh(idx: pd.Series, lo, hi):
    """Buy-and-hold total return and max drawdown over [lo, hi]."""
    w = idx.loc[(idx.index >= lo) & (idx.index <= hi)]
    if len(w) < 2:
        return None
    ret = float(w.iloc[-1] / w.iloc[0] - 1) * 100
    dd = float((w / w.cummax() - 1).min()) * 100
    yrs = max((w.index[-1] - w.index[0]).days, 1) / 365.25
    cagr = (float(w.iloc[-1] / w.iloc[0]) ** (1 / yrs) - 1) * 100
    return {"return_pct": round(ret, 2), "cagr_pct": round(cagr, 2),
            "max_dd_pct": round(dd, 2), "years": round(yrs, 2)}


def strat(prices, signals, cfg, lo, hi):
    sub = {d: v for d, v in signals.items()
           if lo <= pd.Timestamp(d) <= hi}
    if not sub:
        return None
    eq, tr, st, dr, dg = run(prices, sub, cfg)
    return {"return_pct": st["total_return_pct"], "cagr_pct": st["cagr_pct"],
            "max_dd_pct": st["max_drawdown_pct"], "trades": st["num_trades"],
            "positions": dg["avg_positions_held"]}


def row(label, s, b):
    if s is None or b is None:
        print(f"  {label:14} (no data)")
        return
    c_s = s["cagr_pct"] if isinstance(s["cagr_pct"], (int, float)) else float("nan")
    print(f"  {label:14} strategy {s['return_pct']:>8.2f}%  "
          f"({c_s:>5.2f}%/yr, dd {s['max_dd_pct']:>7.2f}%, {s['trades']:>4} trades)")
    print(f"  {'':14} buy&hold {b['return_pct']:>8.2f}%  "
          f"({b['cagr_pct']:>5.2f}%/yr, dd {b['max_dd_pct']:>7.2f}%)")
    print(f"  {'':14} -> strategy trails by "
          f"{b['return_pct'] - s['return_pct']:.2f} points of total return")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--threshold", type=float, default=70.0)
    ap.add_argument("--slippage", type=float, default=5.0)
    ap.add_argument("--signals", default="data/signals.pkl")
    ap.add_argument("--split", default="2022-07-01",
                    help="split date for the two-half comparison")
    ap.add_argument("--benchmark", default="^GSPC")
    args = ap.parse_args()

    bars = {p.stem: pd.read_parquet(p)
            for p in pathlib.Path("data/bars").glob("*.parquet")}
    if args.benchmark not in bars:
        raise SystemExit(f"[bench] no bars for {args.benchmark}")
    idx = bars[args.benchmark]["Close"]
    if getattr(idx.index, "tz", None) is not None:
        idx.index = idx.index.tz_localize(None)
    prices = {t: d for t, d in bars.items() if t != args.benchmark}

    with open(args.signals, "rb") as f:
        signals = pickle.load(f)["signals"]
    ds = sorted(pd.Timestamp(d) for d in signals)
    lo, hi = ds[0], ds[-1]
    split = pd.Timestamp(args.split)

    cfg = BacktestConfig(rank_mode="rs_only", equity_mode="compounding",
                         entry_mode="pivot_limit", ambiguity_mode="worst",
                         vcp_threshold=args.threshold, slippage_bps=args.slippage,
                         sector_map=load_sector_map("data/sectors.csv"),
                         decision=DecisionConfig())

    print("=" * 74)
    print(f"BENCHMARK  threshold={args.threshold}  {lo.date()}..{hi.date()}")
    print("=" * 74)
    row("FULL", strat(prices, signals, cfg, lo, hi), bh(idx, lo, hi))
    print()
    row("H1", strat(prices, signals, cfg, lo, split - pd.Timedelta(days=1)),
        bh(idx, lo, split - pd.Timedelta(days=1)))
    print()
    row("H2", strat(prices, signals, cfg, split, hi), bh(idx, split, hi))

    print()
    print("=" * 74)
    print("  Buy-and-hold here is the INDEX, not an investable product -- no")
    print("  dividends, no ETF fee, no tax. It is a reference line, not a")
    print("  portfolio you could have held exactly.")
    print("  The strategy's figures still carry the survivorship ceiling, the")
    print("  Stage-2 cut, and an exit engine unvalidated against production.")


if __name__ == "__main__":
    main()
