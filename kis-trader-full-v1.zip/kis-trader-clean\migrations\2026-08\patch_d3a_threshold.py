#!/usr/bin/env python3
"""
patch_d3a_threshold.py -- D3a: ONE declaration of VCP_SCORE_THRESHOLD.

PURE REFACTOR. The value stays 80. Nothing about which names reach
candidates.csv changes. The 80 -> 75 move is D3b, a separate commit inside
Phase 2, so that if the screen changes you know it was the number and not the
plumbing.

THE PROBLEM
`VCP_SCORE_THRESHOLD = 80` was declared TWICE -- once in sp500_v21.py, once in
us_small_v21.py, the second carrying the comment "(Mirrors the sp500 screener
exactly.)". A comment asserting two literals are equal is not a single source of
truth; it is true until someone edits one of them. Both screeners feed the SAME
candidates.csv, so a divergence means half the universe screens at a bar nobody
chose, and nothing in the system would report it.

Separately, the trader could not see the value at all, which is what breaks the
Phase 5 boot-time parameter log: it would have to print a number with no causal
link to the screeners that produced today's file.

THE FIX
Declare it once in kistrader/entry/screen_contract.py -- already the contract
boundary between the screener suite and the entry half, already imported by
both sides, and importing nothing heavier than csv/json/math. Each screener
resolves it through a guarded loader shaped exactly like the existing
_load_emitter(): a real import, and a loud actionable SystemExit if the package
is not importable. Never a local fallback literal -- that would silently
recreate the drift this removes.

DEPENDENCY NOTE
This makes `kistrader` importable a requirement for the screeners at import
time, not just when --emit-candidates is used. That is not new in practice:
_load_emitter()'s own docstring already states that `python screeners/x.py`
needs `pip install -e .`, and `python -m screeners.x` from the repo root works
without it. Both invocations still work.

Anchors are asserted; edits are applied bottom-up within each file.

Usage:  python patch_d3a_threshold.py <repo-root>
"""
from __future__ import annotations

import os
import sys

CONTRACT_BLOCK = '''# ---------------------------------------------------------------------------
# Strategy gate — the ONE declaration, shared by both screeners and the trader
# ---------------------------------------------------------------------------
# Stage-3 VCP bar. FINAL pick = Stage 1 AND Stage 2 AND VCP >= this value.
#
# It lives here rather than in either screener because it used to be declared
# twice, once per screener, each with a comment claiming the other mirrored it.
# Two literals are not a single source of truth. Both screeners write the SAME
# candidates.csv, so a divergence would screen half the universe at a bar nobody
# chose, silently. This module is the existing contract boundary between the
# screener suite and the entry half and carries no heavy imports, so both sides
# can read it freely.
#
# 80 = 80% of the achievable max_score=104 scale.
#
# CHANGING THIS NUMBER CHANGES THE STRATEGY. It decides which names reach
# candidates.csv at all. It is a BACKTEST decision — never pick a new value in a
# code session. --emit-threshold lowers ONLY the emit filter for supervised
# plumbing tests and leaves this bar untouched.
VCP_SCORE_THRESHOLD = 80


'''

LOADER = '''def _load_vcp_threshold():
    """Resolve the ONE declaration of the Stage-3 VCP bar (screen_contract).

    Same two-invocation contract as _load_emitter():
      * `python -m screeners.<name>`  -> works from the repo root, no install
      * `python screeners\\\\<name>.py`  -> needs `pip install -e .`

    There is deliberately NO local fallback value. A fallback would let this
    screener run at a different bar from its sibling and from the trader, which
    is exactly the drift that moving the constant here removes. Fail closed and
    say how to fix it."""
    try:
        from kistrader.entry.screen_contract import VCP_SCORE_THRESHOLD as _thr
        return _thr
    except ImportError as e:
        raise SystemExit(
            f"[config] FATAL: cannot read VCP_SCORE_THRESHOLD from "
            f"kistrader.entry.screen_contract ({e}).\\n"
            f"  The Stage-3 VCP bar is declared there ONCE and shared by both\\n"
            f"  screeners and the trader. Refusing to guess a value.\\n"
            f"  Fix either way, from the repo root:\\n"
            f"      pip install -e .                        (then re-run as-is)\\n"
            f"      python -m screeners.{_SCREENER}         (no install needed)")


VCP_SCORE_THRESHOLD = _load_vcp_threshold()
'''


def edit(text, old, new, label):
    n = text.count(old)
    if n != 1:
        raise SystemExit(f"REFUSING: anchor for {label} matched {n} times, expected 1")
    print(f"  ok  {label}")
    return text.replace(old, new)


def read(p):
    with open(p, encoding="utf-8") as f:
        return f.read()


def write(p, s):
    with open(p, "w", encoding="utf-8", newline="") as f:
        f.write(s)


OLD_COMMENT_HEAD = """# Stage 3 gate: minimum VCP score (0-100, on the max_score=104 scale where 100 is
# now achievable) for a candidate to become a FINAL match. 80 = 80% of achievable
# points -- the forward-test starting point. Final pick = Stage 1 AND Stage 2 AND
# VCP >= VCP_SCORE_THRESHOLD."""

NEW_COMMENT = """# Stage 3 gate: minimum VCP score for a candidate to become a FINAL match.
# Final pick = Stage 1 AND Stage 2 AND VCP >= VCP_SCORE_THRESHOLD.
#
# DECLARED ONCE, in kistrader/entry/screen_contract.py, and read by BOTH
# screeners and the trader. Do not re-introduce a literal here: both screeners
# write the same candidates.csv, so a local value would screen half the universe
# at a bar nobody chose, with nothing reporting it."""


def patch_screener(path, modname, comment_tail):
    print(f"{os.path.basename(path)}  ({path})")
    s = read(path)
    if "_load_vcp_threshold" in s:
        raise SystemExit(f"REFUSING: {path} already patched.")
    # bottom-up: the docstring sits far below the declaration
    s = edit(s,
             "    clears VCP_SCORE_THRESHOLD (the final-match gate, 80), else 'fail'. Tied to",
             "    clears VCP_SCORE_THRESHOLD (the final-match gate), else 'fail'. Tied to",
             "result_outcome docstring: drop the hardcoded 80")
    s = edit(s,
             OLD_COMMENT_HEAD + comment_tail + "\nVCP_SCORE_THRESHOLD = 80\n",
             NEW_COMMENT + "\n" + LOADER.replace("{_SCREENER}", modname) + "\n",
             "replace the local literal + its stale comment with the shared loader")
    write(path, s)


def main(root):
    sc = os.path.join(root, "kistrader", "entry", "screen_contract.py")
    sp = os.path.join(root, "screeners", "sp500_v21.py")
    us = os.path.join(root, "screeners", "us_small_v21.py")
    for p in (sc, sp, us):
        if not os.path.isfile(p):
            raise SystemExit(f"REFUSING: not found: {p}")

    s_sc = read(sc)
    if "VCP_SCORE_THRESHOLD" in s_sc:
        raise SystemExit("REFUSING: screen_contract already declares VCP_SCORE_THRESHOLD.")

    print(f"screen_contract.py  ({sc})")
    s_sc = edit(s_sc,
                "SCHEMA_VERSION = 3   # v3: contraction_low (Minervini stop anchor)",
                CONTRACT_BLOCK + "SCHEMA_VERSION = 3   # v3: contraction_low (Minervini stop anchor)",
                "declare VCP_SCORE_THRESHOLD (value unchanged at 80)")
    write(sc, s_sc)

    patch_screener(sp, "sp500_v21", "")
    patch_screener(us, "us_small_v21", " (Mirrors the sp500 screener exactly.)")

    print("\nD3a APPLIED — pure refactor, value still 80. Run the suites; "
          "then a --dry-run screener to prove the loader resolves.")
    return 0


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("usage: python patch_d3a_threshold.py <repo-root>")
    sys.exit(main(sys.argv[1]))
