#!/usr/bin/env python3
"""
Boot-time parameter log (Phase 5 / R6)
======================================

The set the process is about to trade with, printed at startup -- and, on a LIVE
account, enforced. The asymmetry is the whole design: the Phase 7 soak needs a
short STALL_DAY, so mock must tolerate drift; a live account must not, or the
soak value reaches real money.

These tests drive boot_log() directly rather than through cli.cmd_run, which
needs Config/credentials/a broker. The cli edit is two lines and is exercised by
importing it.
"""
from __future__ import annotations

import io
import sys

# Self-locating AND shadow-proof. Two separate problems, both measured:
#  1. `kistrader` and `screeners` are not installed packages (pyproject
#     packages.find includes only kistrader*), so a DIRECT run -- sys.path[0] is
#     tests/ -- cannot import either. pytest happens to work because pyproject
#     sets pythonpath = [".", "tests"].
#  2. kis-backtest ships a partial COPY of kistrader/. Run pytest from the parent
#     directory and it collects both projects; whichever imports first wins
#     sys.modules, and after that sys.path is irrelevant -- Python never
#     re-resolves an imported package. That produced five collection errors
#     naming the wrong repo.
import os as _os, sys as _sys
_ROOT = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))
for _p in (_os.path.join(_ROOT, "screeners"), _ROOT):
    while _p in _sys.path:
        _sys.path.remove(_p)                 # move to the FRONT, not merely present
    _sys.path.insert(0, _p)
_k = _sys.modules.get("kistrader")
_kf = _os.path.abspath(getattr(_k, "__file__", "") or "") if _k is not None else ""
if _k is not None and not _kf.startswith(_ROOT + _os.sep):
    print(f"[path] evicting a foreign kistrader loaded from {_kf!r}; "
          f"this suite tests {_ROOT!r}")
    for _m in [_m for _m in list(_sys.modules)
               if _m == "kistrader" or _m.startswith("kistrader.")]:
        del _sys.modules[_m]

from kistrader.tools import param_snapshot as PS

PASS, FAIL = [], []


def check(name, cond, detail=""):
    (PASS if cond else FAIL).append(name)
    print(f"  [{'PASS' if cond else 'FAIL'}] {name}" + (f"  ({detail})" if detail and not cond else ""))


def _run(is_mock, alert=None):
    """Return (raised, text)."""
    buf = io.StringIO()
    try:
        PS.boot_log(is_mock, alert=alert, stream=buf)
        return None, buf.getvalue()
    except SystemExit as e:
        return str(e.code), buf.getvalue()


def test_clean_tree_boots():
    print("P1 a frozen parameter set boots, mock and live alike")
    raised, text = _run(True)
    check("mock: no refusal", raised is None, f"{raised}")
    check("mock: the set is printed", "ACTIVE PARAMETER SET" in text)
    check("mock: KIS_MOCK is stated", "KIS_MOCK=1 (mock)" in text, text[-200:])
    raised, text = _run(False)
    check("live: no refusal when the set matches", raised is None, f"{raised}")
    check("live: KIS_MOCK is stated", "KIS_MOCK=0 (LIVE)" in text, text[-200:])


def test_drift_is_tolerated_on_mock_and_fatal_on_live():
    print("P2 drift: mock continues, LIVE refuses — the soak cannot leak")
    real = dict(PS.FROZEN)
    PS.FROZEN["STALL_DAY"] = 999                 # stand-in for a soak KIS_STALL_DAY
    try:
        raised, text = _run(True)
        check("mock: continues despite drift", raised is None, f"{raised}")
        check("mock: says the set must never reach live",
              "NEVER reach a live account" in text, text[-300:])

        seen = []
        raised, text = _run(False, alert=seen.append)
        check("live: refuses to start", raised is not None, f"{raised}")
        check("live: the refusal names the count",
              raised and "parameter(s) differ" in raised, f"{raised}")
        check("live: it points at the soak override specifically",
              raised and "KIS_STALL_DAY" in raised, f"{raised}")
        check("live: the operator is alerted before the process dies",
              seen == [raised], f"{seen}")
    finally:
        PS.FROZEN.clear(); PS.FROZEN.update(real)


def test_refusal_reaches_the_phone():
    """The refusal is useless in a log: the process is about to exit, the
    supervisor will restart it, and the operator learns nothing until the
    crash-storm guard trips. It must classify as CRITICAL."""
    print("P3 the LIVE refusal is a phone push, not a log line")
    try:
        from kistrader.notifier import classify
    except ImportError as e:
        check("kistrader.notifier importable", False, str(e)); return
    real = dict(PS.FROZEN)
    PS.FROZEN["STALL_DAY"] = 999
    try:
        seen = []
        raised, _ = _run(False, alert=seen.append)
        check("the refusal message classifies CRITICAL",
              bool(seen) and classify(seen[0]) == "CRITICAL",
              f"{[classify(m) for m in seen]}")
    finally:
        PS.FROZEN.clear(); PS.FROZEN.update(real)


def test_alert_failure_never_masks_the_refusal():
    print("P4 a broken alert channel must not swallow the refusal")
    real = dict(PS.FROZEN)
    PS.FROZEN["STALL_DAY"] = 999
    try:
        def boom(_m):
            raise RuntimeError("telegram down")
        raised, _ = _run(False, alert=boom)
        check("still refuses when the alert callback raises", raised is not None,
              f"{raised}")
    finally:
        PS.FROZEN.clear(); PS.FROZEN.update(real)


def test_cli_calls_it():
    """The two-line cli edit: importable, and cmd_run references boot_log."""
    print("P5 cli.cmd_run is wired to it")
    import inspect
    try:
        from kistrader import cli
    except ImportError as e:
        check("kistrader.cli importable", False, str(e)); return
    src = inspect.getsource(cli.cmd_run)
    check("cmd_run calls boot_log", "boot_log(" in src, src[:200])
    check("it runs BEFORE build_pipeline (no broker connection on a bad set)",
          src.index("boot_log(") < src.index("build_pipeline("), "ordering")


def test_zz_all_checks_passed():
    assert not FAIL, f"{len(FAIL)} failed check(s): " + "; ".join(FAIL)


def test_boot_params():
    main()


def main():
    print("=" * 62)
    print("BOOT-TIME PARAMETER LOG (R6)")
    print("=" * 62)
    test_clean_tree_boots()
    test_drift_is_tolerated_on_mock_and_fatal_on_live()
    test_refusal_reaches_the_phone()
    test_alert_failure_never_masks_the_refusal()
    test_cli_calls_it()
    print("=" * 62)
    print(f"PASSED {len(PASS)} / {len(PASS) + len(FAIL)}")
    if FAIL:
        print("FAILED:", ", ".join(FAIL))
    print("=" * 62)
    return 1 if FAIL else 0


if __name__ == "__main__":
    sys.exit(main())
