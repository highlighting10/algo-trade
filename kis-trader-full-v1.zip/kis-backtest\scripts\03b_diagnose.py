"""
03b_diagnose.py -- WHY do the gate scores differ? Run this when 03_gate.py fails.

Splits the question into causes that are actually distinguishable:

  1. CORPORATE ACTIONS. auto_adjust=True back-adjusts the WHOLE history for any
     dividend or split. A distribution between the box's run date and your
     download date silently rescales every historical bar for that ticker, so the
     score computed then is not reproducible now. This is a property of adjusted
     data, not a bug -- but it must be identified rather than assumed.

  2. THRESHOLD FLIPS. The VCP score is NOT a continuous function of price. Wave
     detection has thresholds, so a 0.2% rescale usually moves the score slightly
     but can occasionally change the wave count and move it a lot. That is why a
     handful of small deltas plus one huge one is the expected signature of (1),
     not evidence of a second, different fault.

  3. WINDOW EDGE. The 2y slice is tail(504). One extra or missing bar shifts the
     window start, which can shift base detection.

Usage:
    python scripts/03b_diagnose.py
    python scripts/03b_diagnose.py --ticker UNH
"""
import pathlib as _pl
import sys as _sys
_sys.path.insert(0, str(_pl.Path(__file__).resolve().parent.parent))

import argparse
import pathlib

import pandas as pd

import vcp_engine as ve
from signals import PITBars, VCP_BENCHMARK, VCP_PERIOD

GATE_DATE = pd.Timestamp("2026-08-05")
EXPECTED = {
    "NTAP": 73.55, "UNH": 67.58, "NUE": 59.83, "STT": 58.64, "HPE": 58.25,
    "BRKR": 72.00, "PTGX": 62.54, "IRDM": 58.66, "OKTA": 58.29, "LFST": 57.07,
}


def corporate_actions(ticker, since):
    """Any dividend or split AFTER `since` retroactively rescales the whole
    adjusted history, so the pre-`since` bars you download today differ from the
    ones the box saw."""
    try:
        import yfinance as yf
        tk = yf.Ticker(ticker)
        out = []
        for label, ser in (("dividend", tk.dividends), ("split", tk.splits)):
            if ser is None or len(ser) == 0:
                continue
            idx = ser.index
            if getattr(idx, "tz", None) is not None:
                ser = ser.copy()
                ser.index = idx.tz_localize(None)
            after = ser[ser.index > since]
            for d, v in after.items():
                out.append((label, pd.Timestamp(d).date(), float(v)))
        return out
    except Exception as e:
        return [("ERROR", str(type(e).__name__), str(e)[:60])]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ticker", default=None)
    args = ap.parse_args()

    names = [args.ticker] if args.ticker else sorted(EXPECTED)
    bars = {}
    for t in names + [VCP_BENCHMARK]:
        p = pathlib.Path(f"data/bars/{t}.parquet")
        if p.exists():
            bars[t] = pd.read_parquet(p)
    missing = [t for t in names if t not in bars]
    if missing:
        print(f"[diag] no bars for {missing}")

    server = PITBars(bars)
    cal = server.calendar()
    gate = GATE_DATE if GATE_DATE in cal else cal[cal <= GATE_DATE][-1]
    server.set_date(gate)
    ve.set_fetcher(server.fetch)
    print(f"[diag] gate date {gate.date()}\n")

    print("=" * 78)
    print("1. CORPORATE ACTIONS AFTER THE GATE DATE  (rescales adjusted history)")
    print("=" * 78)
    for t in names:
        if t not in bars:
            continue
        acts = corporate_actions(t, gate)
        exp = EXPECTED.get(t)
        if acts:
            print(f"  {t:6} {len(acts)} action(s) since {gate.date()}: {acts}")
        else:
            print(f"  {t:6} none  <-- score SHOULD be reproducible exactly"
                  + (f" (expected {exp})" if exp else ""))

    print("\n" + "=" * 78)
    print("2. REPORT INTERNALS  (where a threshold flip would show)")
    print("=" * 78)
    idx = server.fetch(VCP_BENCHMARK, VCP_PERIOD)
    for t in names:
        if t not in bars:
            continue
        df = server.fetch(t, VCP_PERIOD)
        if df is None or df.empty:
            print(f"  {t:6} no window")
            continue
        try:
            rep = ve.VCPAnalyzerV4(df, index_df=idx, config=ve.VCPConfig()).generate_report()
        except Exception as e:
            print(f"  {t:6} EXCEPTION {type(e).__name__}: {e}")
            continue
        if not rep:
            print(f"  {t:6} no report")
            continue
        pat = rep.get("Extracted_Pattern") or {}
        exp = EXPECTED.get(t)
        got = rep.get("Score")
        delta = f"{got - exp:+.2f}" if isinstance(exp, float) else "n/a"
        print(f"  {t:6} score={got:6.2f} exp={exp if exp else '-':>6} d={delta:>7} "
              f"grade={rep.get('Grade')}")
        print(f"         rows={len(df)} first={df.index[0].date()} last={df.index[-1].date()}")
        print(f"         waves={pat.get('Wave_Count')} base_start_bar={pat.get('Base_Start_Bar')} "
              f"pivot={pat.get('Pivot')}")
        print(f"         depths={pat.get('Wave_Depths_Pct')}")
        print(f"         warnings={rep.get('Base_Warnings')} conf={rep.get('Base_Confidence')}")

    print("\n" + "=" * 78)
    print("HOW TO READ THIS")
    print("=" * 78)
    print("  * A ticker with NO corporate actions but a NON-ZERO delta is a real")
    print("    problem -- that one is worth chasing.")
    print("  * A ticker WITH actions and any delta is explained: adjusted history")
    print("    was rescaled after the box ran. Not reproducible, not a bug.")
    print("  * A large delta alongside a changed Wave_Count or Base_Start_Bar is a")
    print("    threshold flip amplifying a small rescale. Expected behaviour.")
    print("  * If MOST tickers have no actions and still differ, suspect the bar")
    print("    source instead: confirm yf.Ticker().history(auto_adjust=True).")


if __name__ == "__main__":
    main()
