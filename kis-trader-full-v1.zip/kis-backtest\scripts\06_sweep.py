"""
06_sweep.py -- sweep ONE parked parameter across the cost grid. The deliverable.

    python scripts/06_sweep.py --param threshold
    python scripts/06_sweep.py --param nmax
    python scripts/06_sweep.py --param maxstop
    python scripts/06_sweep.py --param atrfloor
    python scripts/06_sweep.py --param entrystyle

ONE parameter at a time. Two at once makes the run uninterpretable (seed doc S10).

The verdict is the deliverable, not the winning number.
"""
import pathlib as _pl
import sys as _sys
_sys.path.insert(0, str(_pl.Path(__file__).resolve().parent.parent))
import argparse
import pathlib
import pickle

import pandas as pd

from minervini_backtest import (BacktestConfig, DecisionConfig, load_bars,
                                load_sector_map, robustness_check)

SWEEPS = {
# SESSION_CLOSE section 5 item 1. regime_off is the control and MUST
    # reproduce the existing numbers exactly.
    "regime": {"regime_off": {"regime_ma": None},
               **{f"regime_{n}": {"regime_ma": n} for n in (20, 50, 100, 150, 200)}},
    # FALLACY-4 TEST. expectancy_R is per-share, so max_position_pct CANNOT change
    # r for a fixed trade set. Any response must come from the exposure ceiling
    # admitting a DIFFERENT set. risk is pinned so this stays single-parameter.
    # Smooth + monotone curve => real mechanism. Noisy => the +0.051 R was luck.
    "maxpos": {f"maxpos_{int(p*100)}":
               {"_decision": {"max_position_pct": p}}
               for p in (0.15, 0.20, 0.25, 0.30, 0.35, 0.40)},
   # Phase 2. be_off reproduces today's behaviour exactly, so it is the control.
    "betrigger": {"be_off": {"be_trigger_r": None},
                  **{f"be_{r}": {"be_trigger_r": r}
                     for r in (0.25, 0.5, 0.75, 1.0, 1.5, 2.0, 3.0)}},
    # --- PATCH O --- S3, the failed-breakout exit. fb_off is the CONTROL and
    # MUST reproduce the existing numbers exactly. Entry is pivot*1.005 and the
    # realised stop is ~6.3-6.5% below it, so "close below pivot" fires around
    # -0.5% instead of -6.4% -- the largest mechanical change available to the
    # exit side. Read BOTH expectancy_R and expectancy_R_weighted: this changes
    # how many trades reach +3R at all, so the runner-leg figure is biased
    # (corrections v2 sec.4).
    "failedbreak": {
        "fb_off":        {"fb_trigger": None},
        "fb_same_day":   {"fb_trigger": "same_day"},
        "fb_two_closes": {"fb_trigger": "two_closes"},
        "fb_buf_1":      {"fb_trigger": "buffer", "fb_buffer_pct": 0.01},
        "fb_buf_2":      {"fb_trigger": "buffer", "fb_buffer_pct": 0.02},
    },
    # --- PATCH R --- S1 T2. EQUIVALENCE TEST, NOT A STRATEGY SWEEP.
    # Two spellings of ONE mechanism: the legacy eligibility blank
    # (minervini_backtest.py:946) against production's ceiling writer
    # (exposure_controller.apply_to_decision_config). They should be
    # indistinguishable at a 0.00 risk-off ceiling.
    #
    # THE PASS CONDITION IS INVERTED HERE. Every other entry in this dict wants
    # `settings_differentiated: True`; this one wants False, with identical
    # scores in all 8 cells. A single differing cell means regime_20's 8/8
    # result was measured on a mechanism production does not run -- a real
    # finding, to be written up, not averaged away.
    #
    # drops_by_reason is NOT comparable between the cells and does not need to
    # be: the blank cut candidates before plan() saw them, so names now charged
    # to dedup / n_max / sector cap were all logged as "regime_off" before.
    #
    # Requires a real --regime-ma. Q's __post_init__ refuses regime_ceiling with
    # regime_ma=None rather than letting it quietly equal the control.
    "expequiv": {
        "exp_blank":   {"exposure_policy": "constant"},
        "exp_ceiling": {"exposure_policy": "regime_ceiling",
                        "exposure_risk_off_pct": 0.0},
    },
    # --- PATCH V --- S1 step 1: the GRADED exposure ceiling.
    # Both ENDS are already measured, so only the middle is a new claim:
    #   exp_100 == regime OFF   (production today; exposure_controller.py
    #                            records mean +0.281 R for it)
    #   exp_000 == regime_20    (mean +0.320 R, 8/8 cells; and T2 proved the
    #                            ceiling writer is byte-identical to the blank)
    # A monotone curve between two known points is credible. A ragged one is
    # noise, whatever the winner.
    #
    # exposure_unavailable_pct stays 0.00 in every arm because production FAILS
    # CLOSED on an unreadable benchmark. So check exp_100's
    # exposure_reduced_days: 0 means it is exactly regime_off; anything else
    # means it is regime_off PLUS fail-closed days and must be described so.
    #
    # DECISION RULE, pre-registered (RESULT_20260830_paired_noise_floor.md):
    #   PRIMARY  8-cell dominance over the incumbent exp_100, AND cost
    #            monotonicity. Non-parametric, floor-independent.
    #   READ     expectancy_R_weighted -- the only metric that can see a size
    #            effect -- but its paired SE is +/-0.14; it does not adjudicate.
    #   NEVER    total_return_pct (paired SE +/-48-56pp on a 49.92% return) or
    #            max_drawdown_pct (+/-6.1-6.6pp on -19.50%). Measured too noisy.
    #   MARGINS  judged against the PAIRED +/-0.15 R band, not the inherited
    #            +/-0.19-0.20, which is a SINGLE-ARM SE.
    #   A NULL IS A RESULT and closes S1 with nothing shipped.
    #
    # This sweep CANNOT re-argue F3's doctrine. Every arm is keyed to an index
    # moving average, which Minervini's per-stock Trend Template does not use.
    # It answers the SHAPE of a throttle, not the choice of signal.
    "exposure": {
        "exp_100": {"exposure_policy": "regime_ceiling",
                    "exposure_risk_off_pct": 1.00},
        "exp_075": {"exposure_policy": "regime_ceiling",
                    "exposure_risk_off_pct": 0.75},
        "exp_050": {"exposure_policy": "regime_ceiling",
                    "exposure_risk_off_pct": 0.50},
        "exp_025": {"exposure_policy": "regime_ceiling",
                    "exposure_risk_off_pct": 0.25},
        "exp_000": {"exposure_policy": "regime_ceiling",
                    "exposure_risk_off_pct": 0.00},
    },
    # parked #1
    "threshold": {f"thr_{t}": {"vcp_threshold": float(t)}
                  for t in (55, 60, 65, 70, 75, 80, 85)},
    # parked #3
    "nmax": {f"nmax_{n}": {"_decision": {"n_max": n}}
             for n in (4, 6, 8, 10, 12)},
    # parked #4. NOTE: max_stop_pct is a pure REJECTION FILTER (decision_engine
    # line 216) -- it never widens a stop, it only admits candidates whose
    # natural stop is wider. So a monotonically rising curve means "this filter
    # is costing you trades", not "wider stops are better". The grid runs past
    # the doctrinal 10% ceiling deliberately: if the curve never turns over,
    # expectancy_R cannot choose this parameter and the decision is a risk
    # appetite call, not a data call.
    "maxstop": {f"stop_{int(p*100)}": {"_decision": {"max_stop_pct": p}}
                for p in (0.06, 0.08, 0.10, 0.12, 0.15, 0.20, 0.25)},
    # parked #2 -- the ATR floor band, recalibrated for contraction-scale depths
    "atrfloor": {f"atrmin_{m}": {"_decision": {"atr_mult_min": m}}
                 for m in (0.9, 1.1, 1.3, 1.5, 1.8)},
    # NEVER SWEPT. rank_mode replaced production's 2*RS + Stage2 when Stage 2
    # was cut; the seed doc flagged it as a new parameter that must not be chosen
    # by accident. It was set to rs_only and every other sweep ran on top of that
    # choice. Ranking purely on RS systematically buys the most extended names.
    "rankmode": {
        "rs_only": {"rank_mode": "rs_only"},
        "vcp_only": {"rank_mode": "vcp_only"},
        "rs_plus_vcp": {"rank_mode": "rs_plus_vcp"},
    },
    # ---- GROUP 1: long caps x low floors, legacy mechanism, NO new code.
    # Never tested: the stallday sweep held floor at 1.0, the stallfloor sweep
    # held day at 10. "day 126 / floor 0.0" is effectively Minervini's method
    # (no time stop, hard backstop only) and has never been run.
    "longstall": {
        "legacy_10_1.0": {"stall_day": 10, "stall_r_floor": 1.0},
        "oneil_65_1.0": {"stall_day": 65, "stall_r_floor": 1.0},
        "d90_f0.25": {"stall_day": 90, "stall_r_floor": 0.25},
        "d126_f0.5": {"stall_day": 126, "stall_r_floor": 0.5},
        "d126_f0.0": {"stall_day": 126, "stall_r_floor": 0.0},
    },
    # ---- GROUP 2: conditional stall. How many health checks must pass to keep
    # holding a position that is below the promotion floor.
    "condstall": {
        "legacy": {"stall_mode": "legacy"},
        "cond_min1": {"stall_mode": "conditional", "stall_min_conditions": 1},
        "cond_min2": {"stall_mode": "conditional", "stall_min_conditions": 2},
        "cond_min3": {"stall_mode": "conditional", "stall_min_conditions": 3},
        "cond_min4": {"stall_mode": "conditional", "stall_min_conditions": 4},
    },
    # ---- GROUP 3: which single condition carries the signal (min=1, one on)
    "condwhich": {
        "r_only": {"stall_mode": "conditional", "stall_min_conditions": 1,
                    "stall_use_ema": False, "stall_use_bench": False,
                    "stall_use_volume": False},
        "ema_only": {"stall_mode": "conditional", "stall_min_conditions": 1,
                      "stall_use_r": False, "stall_use_bench": False,
                      "stall_use_volume": False},
        "bench_only": {"stall_mode": "conditional", "stall_min_conditions": 1,
                        "stall_use_r": False, "stall_use_ema": False,
                        "stall_use_volume": False},
        "volume_only": {"stall_mode": "conditional", "stall_min_conditions": 1,
                         "stall_use_r": False, "stall_use_ema": False,
                         "stall_use_bench": False},
    },
    # exit geometry -- half of all exits at threshold 80 were STALL_EXIT
    "stallday": {f"stall_{d}": {"stall_day": d} for d in (10, 15, 20, 30, 45, 65, 126, 252)},
    "stallfloor": {f"floor_{f}": {"stall_r_floor": f} for f in (0.0, 0.5, 1.0, 1.5)},
    # parked #5 -- breakout vs volume-confirmed
    "entrystyle": {
        "breakout": {"_decision": {"require_trade_signal": False}},
        "volume_confirmed": {"_decision": {"require_trade_signal": True}},
    },
}


# --- PATCH H (H3) --- regime_ma has THREE states, not two: a window, OFF, and
# "you did not say". None is a legal value (gate off), so it cannot double as
# the not-supplied marker the way argparse's default=None does.
_REGIME_UNSET = object()


def _regime_ma_arg(v):
    """'off' / 'none' / '0' -> None (gate off); otherwise an int >= 2."""
    s = str(v).strip().lower()
    if s in ("off", "none", "0"):
        return None
    try:
        n = int(s)
    except ValueError:
        raise __import__("argparse").ArgumentTypeError(
            f"--regime-ma must be an integer >= 2, or off/none/0. Got {v!r}.")
    if n < 2:
        raise __import__("argparse").ArgumentTypeError(
            f"--regime-ma must be >= 2 (ExposureConfig refuses less), or "
            f"off/none/0 for no gate. Got {n}.")
    return n


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--rank-mode", default=None,
                    choices=["rs_only", "vcp_only", "rs_plus_vcp"],
                    help="REQUIRED. Frozen: vcp_only. Held fixed when sweeping "
                         "something other than rankmode. The old default was "
                         "rs_only -- not the frozen mode, and the one mode that "
                         "inverts if the vendored engine is replaced.")
    ap.add_argument("--regime-ma", type=_regime_ma_arg, default=_REGIME_UNSET,
                    help="REQUIRED. 20 reproduces Rev 3; 'off' (or 'none'/'0') "
                         "is what production has run since PATCH F3 "
                         "(2026-08-25). Before PATCH H there was no way to say "
                         "'off', so every non-regime sweep was forced to a gate "
                         "setting the trader is not executing. Before PATCH E "
                         "it was not a flag at all and fell to None silently.")
    ap.add_argument("--stall-day", type=int, default=None,
                    help="REQUIRED. Frozen: 252. Before PATCH E2 this fell to "
                         "the harness constant STALL_DAY=10, which measured "
                         "-0.057 R against +0.330 R at 252 -- a sign flip from "
                         "one unpassed flag.")
    ap.add_argument("--risk-pct", type=float, default=None)
    ap.add_argument("--max-position-pct", type=float, default=None)
    # --- PATCH H (H2) ---
    ap.add_argument("--sector-cap", type=int, default=None,
                    help="REQUIRED. Production runs 0 (PATCH F 2026-08-25, off "
                         "by declaration: Rev 3 has no sector cap and SEPA has "
                         "no diversification element). The VENDORED engine "
                         "defaults to 2. Corrections v2 sec.6.1 measured the "
                         "cap as neutral on expectancy_R (identical to 3 dp) "
                         "but worth -2.31 pts of return and +1.97 pts of "
                         "drawdown -- so it only matters once BE_CAREFUL "
                         "sec.3.1 is settled, and it must be stated either way.")
    ap.add_argument("--param", required=True, choices=sorted(SWEEPS))
    ap.add_argument("--metric", default="expectancy_R",
                    choices=["expectancy_R", "expectancy_R_weighted",
                             "total_return_pct", "max_drawdown_pct",
                             "win_rate_pct"],
                    help="expectancy_R is the RUNNER leg's per-share R and "
                         "cannot see a change to the partial (corrections v2 "
                         "sec.4). expectancy_R_weighted sees both legs but is "
                         "position-size SENSITIVE, so it is refused for "
                         "--param maxpos, whose FALLACY-4 logic depends on the "
                         "metric being size-invariant.")
    ap.add_argument("--threshold", type=float, default=None,
                    help="REQUIRED. Frozen: 75. Held fixed when sweeping "
                         "something other than threshold. The old default was "
                         "80, which Rev 3 sec.4 measured and REJECTED: +0.43 R "
                         "in H1, -0.05 to -0.11 R in H2, four negative cells.")
    ap.add_argument("--signals", default=None,
                    help="REQUIRED. data/signals_daily.pkl is the daily rescan "
                         "(every=1) whose window matches Rev 3; data/signals.pkl "
                         "is the weekly one (every=5) and carries about a "
                         "quarter as many candidates.")
    ap.add_argument("--start", default=None,
                    help="clip signals to this date onward, so a daily file and "
                         "a weekly file can be compared over the SAME window")
    ap.add_argument("--end", default=None)
    args = ap.parse_args()

    # --- PATCH E: state the configuration or do not run ---
    # Pure argparse validation, no imports, so it can never be masked by an
    # unrelated ImportError. PATCH 2's guard runs immediately after.
    _FROZEN = {"rank_mode": "vcp_only", "threshold": 75.0, "regime_ma": 20}
    # the parameter this run sweeps overrides its held-fixed value per cell
    _SWEPT = {"regime": "regime_ma", "threshold": "threshold",
              "rankmode": "rank_mode"}.get(args.param)
    _missing = []
    if args.rank_mode is None:
        _missing.append("--rank-mode    frozen vcp_only. The old default was "
                        "rs_only, which is NOT the frozen mode.")
    if args.threshold is None:
        _missing.append("--threshold    frozen 75. The old default was 80, a "
                        "configuration Rev 3 sec.4 measured and REJECTED.")
    # --- PATCH H (H3) --- None is now a LEGAL value meaning "gate off", so
    # "not supplied" has to be a distinct sentinel or the two collapse.
    if args.regime_ma is _REGIME_UNSET:
        _missing.append("--regime-ma    frozen 20 for a Rev 3 reproduction; "
                        "'off' for what production runs since PATCH F3. Was "
                        "never passed to BacktestConfig at all before PATCH E, "
                        "so every non-regime sweep ran with the gate OFF by "
                        "accident. State which you mean.")
    # --- PATCH H (H2) ---
    if args.sector_cap is None:
        _missing.append("--sector-cap   production runs 0 (PATCH F 2026-08-25). "
                        "The vendored engine defaults to 2, so every sweep "
                        "before this patch enforced a cap production does not "
                        "have. Corrections v2 sec.6.1: neutral on expectancy_R, "
                        "-2.31 pts return and +1.97 pts drawdown otherwise.")
    if args.signals is None:
        _missing.append("--signals      data/signals_daily.pkl is every=1 and "
                        "matches Rev 3's window; data/signals.pkl is every=5.")
    # --- PATCH E2: stall_day is not optional ---
    if args.stall_day is None:
        _missing.append("--stall-day    frozen 252. Falls to the harness "
                        "constant STALL_DAY=10 otherwise, measured at "
                        "-0.057 R against +0.330 R at 252.")
    if _missing:
        print("[sweep] REFUSING TO RUN. A sweep whose configuration is not "
              "stated cannot have its numbers labelled.")
        for _m in _missing:
            print("[sweep]   " + _m)
        raise SystemExit(2)
    _live = {"rank_mode": args.rank_mode, "threshold": args.threshold,
             "regime_ma": args.regime_ma}
    for _k in ("rank_mode", "threshold", "regime_ma"):
        if _k == _SWEPT:
            print("[sweep]   %s=%s is held fixed but --param %s OVERRIDES it "
                  "per cell" % (_k, _live[_k], args.param))
        elif _live[_k] != _FROZEN[_k]:
            print("[sweep]   NOTE %s=%s is NOT the frozen value (%s). "
                  "Deliberate?" % (_k, _live[_k], _FROZEN[_k]))
    # --- PATCH H (H3) --- the two FROZEN authorities disagree on regime_ma and
    # nothing said so. Name the question this run is answering.
    if _SWEPT != "regime_ma":
        if args.regime_ma is None:
            print("[sweep]   regime_ma=OFF matches PRODUCTION "
                  "(param_snapshot.FROZEN regime_ma=None since PATCH F3, "
                  "2026-08-25). This run does NOT reproduce Rev 3, whose "
                  "published numbers were measured at 20.")
        elif args.regime_ma == 20:
            print("[sweep]   regime_ma=20 reproduces Rev 3, but production has "
                  "run regime_ma=None since PATCH F3 (2026-08-25). This run "
                  "measures a configuration the trader is NOT executing.")
    # --- end PATCH H (H3) ---

    # --- PATCH X --- the sector_cap twin of H3.
    # sector_cap is NOT one of the frozen 15 -- it is a dataclass default no
    # data session ever set -- so no freeze guard covers it. But Rev 3's
    # published figures were measured at 2 and production has run 0 since
    # PATCH F (2026-08-25). The flag is required, so the value is always
    # stated; what was never stated is which set that value reproduces.
    #
    # 2026-08-31: a --sector-cap 0 run returned regime_20 at +0.210 on 216
    # trades against the published +0.330 on 200, ordering reversed, and was
    # read as the frozen set failing to reproduce after commit eddede7. The
    # same command at --sector-cap 2 returned every figure to the digit,
    # margins and drop ledger included. Nothing was broken; nothing said which
    # question the run was answering.
    if args.sector_cap == 2:
        print("[sweep]   sector_cap=2 reproduces Rev 3's published figures "
              "(200 trades, +0.330 R, -19.50% DD, +49.92% at 5 bps), but "
              "production has run sector_cap=0 since PATCH F (2026-08-25). "
              "This run measures a configuration the trader is NOT executing.")
    elif args.sector_cap == 0:
        print("[sweep]   sector_cap=0 matches PRODUCTION (PATCH F, 2026-08-25) "
              "and PLAN_20260828 sec.4's forward-looking configuration. Rev 3's "
              "published figures were measured at 2, so this run does NOT "
              "reproduce the frozen set -- do NOT compare its levels against "
              "200 trades / +0.330 R / -19.50% DD.")
    else:
        print("[sweep]   NOTE sector_cap=%s is neither production's 0 nor "
              "Rev 3's 2. This run reproduces nothing and is comparable only "
              "to itself. Deliberate?" % args.sector_cap)
    # --- end PATCH X ---
    # --- PATCH E2 --- constants with no flag, so a required-argument rule
    # cannot reach them. They all match today; this is a tripwire.
    # STALL_DAY is deliberately absent: the flag above overrides it.
    import minervini_backtest as _mb
    _CONST = {"STALL_R_FLOOR": 1.0, "R_PARTIAL_MULTIPLE": 3.0,
              "PARTIAL_FRACTION": 1.0 / 3.0, "EMA_LEN": 21}
    _drift = []
    for _k, _f in _CONST.items():
        _v = getattr(_mb, _k, None)
        if _v is None or abs(float(_v) - float(_f)) > 1e-9:
            _drift.append("%s = %r, frozen %r" % (_k, _v, _f))
    if _drift:
        print("[sweep] REFUSING TO RUN: harness exit constants have drifted "
              "from the frozen set.")
        for _d in _drift:
            print("[sweep]   " + _d)
        raise SystemExit(2)
    # --- PATCH E3: the weighted metric, and where it must not be used ---
    if args.metric == "expectancy_R_weighted":
        import inspect
        if "expectancy_R_weighted" not in inspect.getsource(_mb):
            print("[sweep] REFUSING TO RUN: this harness has no "
                  "expectancy_R_weighted. It predates commit e607db9 "
                  "(patch 1). Apply patch 1 or judge on expectancy_R.")
            raise SystemExit(2)
        if args.param == "maxpos":
            print("[sweep] REFUSING TO RUN: --param maxpos is the FALLACY-4 "
                  "test. Its inference is that expectancy_R is per-share, so "
                  "max_position_pct cannot move it for a fixed trade set and "
                  "any response must come from the exposure ceiling admitting "
                  "a DIFFERENT set. expectancy_R_weighted IS size-sensitive, "
                  "so every cell would move for a trivial arithmetic reason "
                  "and the curve would look clean while meaning nothing. "
                  "Judge maxpos on expectancy_R.")
            raise SystemExit(2)
    # --- end PATCH E3 ---
    print("[sweep] config rank_mode=%s threshold=%s regime_ma=%s stall_day=%s "
          "metric=%s signals=%s" % (args.rank_mode, args.threshold,
                                    args.regime_ma, args.stall_day,
                                    args.metric, args.signals))
    # --- end PATCH E ---

    # --- PATCH 2: harness snapshot guard ---
    # Before any bar is read: pin WHICH decision_engine is imported, PROVE the
    # rank modes against a conflicting-order fixture, and require the sizing
    # flags when the engine's defaults differ from the frozen set. A sweep whose
    # configuration cannot be stated is a sweep whose numbers cannot be labelled.
    try:
        from harness_snapshot import snapshot
    except ImportError:
        raise SystemExit(
            "[sweep] harness_snapshot.py not found. It must sit at the "
            "kis-backtest root, beside minervini_backtest.py.")
    _snap = snapshot(risk_pct=args.risk_pct,
                     max_position_pct=args.max_position_pct,
                     require_explicit_sizing=True,
                     harness_path="minervini_backtest.py")
    if not _snap.ok:
        for _p in _snap.problems:
            print(f"[sweep] REFUSING TO RUN: {_p}")
        raise SystemExit(2)
    print(f"[sweep] {_snap.one_line()}")
    # --- end PATCH 2 ---

    # --- PATCH S --- was an inline glob, which returns EMPTY WITHOUT ERROR
    # from the wrong cwd. load_bars() refuses at the point of the mistake.
    bars = load_bars()
    prices = {t: d for t, d in bars.items() if t != "^GSPC"}
    with open(args.signals, "rb") as f:
        blob = pickle.load(f)
    signals = blob["signals"]
    if args.start or args.end:
        lo = pd.Timestamp(args.start) if args.start else pd.Timestamp.min
        hi = pd.Timestamp(args.end) if args.end else pd.Timestamp.max
        n0 = len(signals)
        signals = {d: v for d, v in signals.items() if lo <= pd.Timestamp(d) <= hi}
        print(f"[sweep] clipped signals: {n0} -> {len(signals)} date(s)")
    if not signals:
        raise SystemExit("[sweep] no signals in the requested window")
    _ds = sorted(signals)
    print(f"[sweep] {args.signals}: {len(signals)} date(s) "
          f"{_ds[0].date()}..{_ds[-1].date()}, "
          f"{sum(len(v) for v in signals.values())} candidate(s)")
    # --- PATCH E --- provenance, so a result traces back to its input file
    print("[sweep]   signals every=%s lag=%s generated=%s"
          % (blob.get("every", "ABSENT"), blob.get("lag", "ABSENT"),
             blob.get("generated", "ABSENT")))
    if blob.get("every") not in (1, None):
        print("[sweep]   NOTE every=%s means a rescan every %s trading days, "
              "not daily -- fewer chances to fill the eight slots, so a lower "
              "trade count here is a SAMPLING difference, not a strategy one."
              % (blob.get("every"), blob.get("every")))

    # cond 3 (excess return vs benchmark) needs ^GSPC. Without it that check is
    # skipped and reported as unavailable, never silently passed.
    _b = bars.get("^GSPC")
    cfg = BacktestConfig(
        rank_mode=args.rank_mode, equity_mode="compounding", entry_mode="pivot_limit",
        ambiguity_mode="worst", vcp_threshold=args.threshold,
        # --- PATCH E --- regime_ma was NEVER passed here. It fell to the
        # dataclass default `Optional[int] = None`, and None means the regime
        # gate is OFF, so every non-regime sweep ran without one.
        regime_ma=args.regime_ma,
        **({"stall_day": args.stall_day} if args.stall_day is not None else {}),
        sector_map=load_sector_map("data/sectors.csv"), decision=DecisionConfig(
            **{k: v for k, v in
               (("risk_per_trade_pct", args.risk_pct),
                ("max_position_pct", args.max_position_pct),
                # --- PATCH H (H2) --- always passed; the flag is required, so
                # this never falls back to the vendored default of 2.
                ("sector_cap", args.sector_cap)) if v is not None}),
        benchmark_close=(_b["Close"] if _b is not None else None))
    if _b is None:
        print("[sweep] WARNING: no ^GSPC bars -- the benchmark condition will be "
              "skipped, so condstall results understate that check")

    settings = SWEEPS[args.param]
    # --- PATCH H (H1) --- merge, do not replace.
    # robustness_check does `replace(cfg, **kw)`, so a setting carrying a
    # constructed DecisionConfig REPLACED cfg.decision wholesale and silently
    # reverted risk_per_trade_pct to 0.0075, max_position_pct to 0.20 and
    # sector_cap to 2 -- the vendored defaults -- for nmax / maxstop / atrfloor
    # / entrystyle. The flags were mandatory and then discarded.
    # `_decision` is a dict of FIELD OVERRIDES applied to the run's own
    # decision, so a cell can no longer undo a value the operator had to state.
    from dataclasses import replace as _dc_replace
    _merged = {}
    for _lbl, _kw in settings.items():
        if "_decision" in _kw:
            _over = dict(_kw["_decision"])
            _kw = {k: v for k, v in _kw.items() if k != "_decision"}
            _kw["decision"] = _dc_replace(cfg.decision, **_over)
        _merged[_lbl] = _kw
    settings = _merged
    _d0 = next(iter(settings.values())).get("decision", cfg.decision)
    print("[sweep]   per-cell decision: risk=%s cap=%s sector_cap=%s "
          "(inherited from this run, not from DecisionConfig defaults)"
          % (_d0.risk_per_trade_pct, _d0.max_position_pct, _d0.sector_cap))
    # --- end PATCH H (H1) ---
    print(f"[sweep] {args.param}: {len(settings)} setting(s) x 4 cost level(s) "
          f"x 2 intrabar bound(s) = {len(settings)*8} runs")
    print(f"[sweep] judged on {args.metric}, worst bound only\n")

    # All four offered metrics are HIGHER-IS-BETTER as stored, including
    # max_drawdown_pct -- it is negative (e.g. -19.83), so -10 correctly
    # outranks -20. The previous expression here was `(metric != "max_drawdown_pct"
    # or True)`, which is always True: dead logic that read as if it flipped
    # direction. If a lower-is-better metric is ever added, branch here properly.
    r = robustness_check(prices, signals, cfg, settings=settings,
                         metric=args.metric,
                         higher_is_better=True)

    print(f"  VERDICT: {r['verdict']}\n")
    for slip in r["slippage_grid"]:
        order = " > ".join(r["ranking_by_slippage"][slip])
        scores = "  ".join(f"{k}={v:+.4f}"
                           for k, v in r["scores_by_slippage"][slip].items())
        print(f"  {slip:5.1f} bps/side   {order}")
        print(f"                  {scores}")
    print(f"\n  winner stable across costs : {r['winner_stable']}")
    print(f"  full ordering stable       : {r['full_order_stable']}")
    print(f"  settings differentiated    : {r['settings_differentiated']}")
    print(f"  --- diagnostics for the WINNER ({r['probed_setting']}) ---")
    print(f"  avg positions held         : {r['avg_positions_held_sample']} "
          f"of {cfg.decision.n_max} slots")
    print(f"  held_ticker_time_frac      : {r['held_ticker_time_frac_sample']}")
    print(f"  drops (sample setting)     : {r['drops_by_reason_sample']}")
    # --- PATCH K --- one line per cost level. The old single line was the
    # LAST grid level (30.0 bps) printed with no label, which is not the level
    # the metric's headline number comes from.
    _tcs = r.get("trade_counts_by_slippage")
    if not _tcs:
        print(f"  trades per setting         : {r['trade_counts']}  "
              f"<- LAST cost level only (harness predates PATCH K)")
    else:
        print("  trades per setting, per cost level:")
        for _slip in r["slippage_grid"]:
            _row = _tcs.get(_slip, {})
            print(f"    {_slip:>6} bps  " +
                  "  ".join(f"{_k}={_v}" for _k, _v in _row.items()))
    print(f"  winner margin (1st - 2nd)  : {r['winner_margin_by_slippage']}")
    if r["winner_tied"]:
        print(f"  *** TOP {r['n_tied_at_top']} SETTING(S) ARE EXACTLY TIED -- the "
              f"'winner' is dict order, not evidence")
    if r["low_trade_settings"]:
        print(f"  *** LOW TRADE COUNT (< {r['min_confidence_trades']}): "
              f"{r['low_trade_settings']}")
        print("      A high score on a handful of trades is not a result. Check")
        print("      the count before believing the rank.")
    if r["excluded_insufficient_trades"]:
        print(f"  EXCLUDED (no trades)       : {r['excluded_insufficient_trades']}")
        print("     a setting that never trades scores 0.0 and would otherwise")
        print("     outrank a losing one -- excluded rather than counted as a win")

    print("\n" + "-" * 66)
    if not r["settings_differentiated"]:
        print("  FALSE PASS. Every setting scored identically, so a CONSTRAINT")
        print("  decided the outcome, not this parameter. Check the drop counts")
        print("  above -- a binding sector_cap or n_max is the usual cause.")
        print("  Fix that and rerun. Do NOT report this as a result.")
    elif r["verdict"] == "NOT ROBUST":
        print("  The winner FLIPS across the cost grid, so this parameter choice")
        print("  is not supported by the data. Report the instability. Do not")
        print("  pick the slippage level that gives the answer you prefer.")
    else:
        print(f"  Defensible recommendation: {list(r['winner_by_slippage'].values())[0]}")
        print("  Still a RECOMMENDATION WITH EVIDENCE -- do not paste the value")
        print("  into production from here. Apply it in a separate, deliberate step.")


if __name__ == "__main__":
    main()
