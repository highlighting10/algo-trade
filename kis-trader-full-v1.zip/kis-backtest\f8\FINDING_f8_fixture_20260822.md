# F8 — validated, with two characterised divergences. Second pass.

**2026-08-22.** Rev 3 sec.6 F8 — *"the harness exit engine has never been diffed
against `engine_v2`… the largest single unvalidated assumption in the project."*

Fixture: `f8_fixture.zip` → unzip to `kis-backtest\f8\`. Six entry points, all
exit 0. Touches no live system.

---

## READ THIS FIRST — the first pass overstated the result

The first pass reported *"13 of 13 cases agree, F8 closed."* **That claim was
too strong.** The same person chose the cases and derived the expected answers,
so it could only find defects on paths someone thought to write down.

A randomised sweep (`fuzz_f8.py`, 24,000 scenarios across four seeds) was then
written specifically to attack it. It found **four things — two bugs in the
fixture and two real harness defects — none of which any of the fourteen
hand-written cases could reach.** Both fixture bugs flattered the agreement.

The corrected statement is in sec.1. The lesson is the one this project already
holds as standing rule 2, applied one level up: a hand-built fixture that passes
has not been shown able to fail *on paths its author did not imagine*.

---

## 1. The result, stated precisely

The harness's exit engine reproduces `engine_v2`'s **decision layer** — which
reason, on which bar — on **11,950 of 11,950** random scenarios where the bar
does not open beyond the +3R level, and on every one of the 15 hand-built cases.
**Two characterised divergences remain, both in the +3R partial's FILL, both
conservative, both now pinned as regression cases.**

```
12,000 random scenarios, seed 20260822   11,950 agree   50 disagree
4,000 x 3 independent seeds (1, 7, 99999)               17 / 14 / 16 disagree
paths exercised: STOP_HIT 10,599 | partial taken 1,013 | still open 653
                 STALL_EXIT 413  | EMA_BREAK 335
every disagreement in a characterised class; ZERO unknown divergence
```

`fuzz_f8.py` exits 0 only while every disagreement falls into a class cases 10
and 11 pin. A new class fails the run — so it is a usable regression gate after
any change to either engine.

### Independently reproduced on the target machine, 2026-08-22

Walked end to end on the laptop (Windows, Python 3.14, pandas 3.0.3,
numpy 2.4.6) against `kis-trader-clean` and `kis-backtest`:

```
run_f8.py            62/62      engine-only
run_f8.py --harness  98/98      full diff, 13 agree + 2 pinned + 1 bound probe
sabotage_check.py    PASSED     4 planted engine defects caught, 1 proven unreachable
sabotage_harness.py  PASSED     5 planted harness defects surfaced in the diff
fuzz_f8.py 12000     exit 0     11,950 agree / 50 disagree, no unknown divergence
```

The sweep was **bit-identical** to the development run — same 11,950/50 split,
same class counts (48 + 2), same scenario ids (F18, F2519) — despite a different
Python (3.11 vs 3.14) and OS. The RNG stream is stable across both, so the sweep
is a genuine reproducible baseline: a future run that differs *at all* is a
signal, not noise. Record the seed with any number quoted from it.

One incidental confirmation from the run: `decision_engine resolved to:
C:\Users\user\kis-trader-clean\kistrader\__init__.py`, i.e. production's — which
is sec.5.3's trap, observed live rather than inferred.

---

## 2. The two real harness defects — one root cause

**The harness decides the +3R partial from the bar's HIGH alone and fills it at
exactly the +3R level, ignoring the OPEN** — even though it already honours the
open for the stop (`o if o < pos.stop_loss_price else pos.stop_loss_price`).
The reasoning it applies one line earlier is simply not applied to the partial.

### 2.1 Case 10 — the bar opens above +3R (48 of 1,013 partialled trades, 4.7%)

`engine_v2` polls from the open, sees 136.00, and `r_multiple(136) = 3.6 >= 3`
fires the partial **there**. The harness's `fill = slip_sell(partial_level)` is
unconditional, so it books 130.00. Reason, bar and exit price all agree; only
the partial leg differs, by the size of the gap.

### 2.2 Case 11 — opens above +3R AND trades below the original stop (2 in 12,000)

The harness sees stop and +3R both inside `[low, high]`, calls it ambiguous, and
applies stop-first. **But the bar OPENED at 130**: the +3R was reached at the
open, so the stop cannot have preceded it and there is nothing to resolve.
Production books **+1.0R**; the harness books **−1.0R**. A **2.0R divergence**.
Rare, but a gap-up that reverses hard is an earnings day, not an exotic path.

**Both understate, so Rev 3's numbers remain a lower bound in this respect** —
the safe direction, and it compounds with the entry-side asymmetry already on
record. Fixing them would raise the backtest's numbers, not lower them.

---

## 3. The two bugs in my own fixture — both flattered the agreement

**A. The entry bar had an open tick it should not have had.** The position does
not exist until the breakout fills it intraday, so the bar's open happened
before we were in and cannot trigger anything. A bar opening at 85 that ran
through the pivot (filling at 100) and printed a high of 105 was being exited at
85 rather than at the stop — **0.5R of phantom loss on every entry bar that
gapped**. The harness had this right, explicitly, all along. Now case 2b.

**B. A gap-up partial silently skipped its own breakeven stop.** When a bar
opens at or above +3R the partial fires on the first tick, and `engine_v2`
confirms a partial on the *next* call — so with no confirmation tick the
position stayed `partial_pending` all bar, `partial_done` never became True, and
the same-bar breakeven retest never ran. That spared the runner a stop-out it
should have taken. This was the **only** decision-layer disagreement in 3,000
trials, and it was mine.

---

## 4. What still holds from the first pass

- **`box-deploy` is byte-identical to `main`** for every file F8 touches.
  `pytest -q` = 86 passed. The laptop clone is what the box runs.
- **The diff has been shown to fail.** `sabotage_harness.py` plants five defects
  in throwaway copies of the harness — gap-through filling at the stop (caught
  by case 2), `elif`→`if` (5b), queued exit at the close (5, 5b, 6, 8, 8b),
  `round()` for `int()` (9), stop losing same-bar precedence (3). Five for five.
  `sabotage_check.py` does the same against `engine_v2`.
- **The stop-vs-partial precedence in `_on_tick` can never bind** — before the
  partial `price <= stop` implies `r <= −1`; after it `partial_done` closes the
  branch. Proven, not asserted.
- **The EMA trail decision is invariant to EMA lag.** The harness uses
  `ewm(adjust=False)`, production an SMA-seeded EMA over ~82 bars: max 0.01% of
  price, zero decision flips. And `c_t < e_t ⟺ c_t < e_{t−1}` for any
  `0 < k < 1`, so including the current close cannot matter.

---

## 5. Three things that need a decision, unchanged from the first pass

**5.1 The +3R partial never enters a Trade record.** `Trade.r_at_exit` is the
final leg only (the harness says so at line 699). Case 4 is +1.0R share-weighted
and **0.0R in the harness's trade log**. Any expectancy computed by averaging
`r_at_exit` **systematically understates every partialled trade** — and R2
records 57 of 200 trades reaching the trail via the partial. Check how +0.330R
was computed before quoting it again.

**5.2 The fill rule appears ALREADY FIXED.** `FREEZE_REV3_CORRECTIONS` sec.3 says
the harness fills on `high >= limit`. This file refuses gap-above-limit under
`worst` and triggers on `high >= pivot`, filling at the capped limit. No
`high >= limit` path exists in its 1363 lines, and it is dated 08-11 — the
freeze-era file. Re-read sec.3 against it before spending the estimated ~3 hours.

**5.3 Problem 2's trap is live, not pending.** There is no vendored `kistrader/`
in the 08-22 archive, so the harness imports production's `decision_engine`,
whose `DecisionConfig` defaults `vcp_weight = 1.0` — which `run()` line 460
never overrides. With `stage2_score := vcp_score` at line 861, **`rs_only`
currently ranks on RS + VCP**. F8 is unaffected (`vcp_only` collapses to
`2*vcp`, same ordering) but no `rs_only` or `rs_plus_vcp` number produced in
this configuration means what its name says.

---

## 6. Still open

- `kis-backtest` **has no git repository**. `git init` plus a baseline commit
  before any further edit.
- Whether to fix cases 10/11 in the harness. Both are conservative, so this is a
  precision question, not a safety one — but 4.7% of partialled trades is not
  noise.
- sec.5.1's accounting question, sec.5.2's stale correction, sec.5.3's live trap.
- The vendored `screen_contract.py` staleness noted 08-20 is still unchecked.
