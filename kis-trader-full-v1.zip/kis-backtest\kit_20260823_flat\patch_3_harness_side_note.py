#!/usr/bin/env python3
"""
PATCH 3 -- correct a stale claim in f8/harness_side.py's docstring.

WHAT IS WRONG

The module docstring says:

    **There is no vendored `kistrader/` package and no `decision_engine.py` in
    the archive supplied on 2026-08-22.**

That was true of the ARCHIVE and false of the MACHINE, which has the vendored
package. It is the same mistake as the "the trap has already sprung" claim in
the rank roadmap: inferred from an absence in an archive rather than measured on
the machine.

The CONCLUSION it draws is still correct -- run_f8 does import production's
decision_engine, and the 2026-08-23 run confirms it on screen:

    decision_engine resolved to: C:\\Users\\user\\kis-trader-clean\\kistrader\\__init__.py

but for a different reason: run_f8.py inserts --prod-root at sys.path[0], AHEAD
of the vendored copy. That is deliberate, not a fallback.

WHAT THIS CHANGES

The docstring only. No executable line is touched, so F8's results cannot move
-- run run_f8.py afterwards and it must still be 98/98.

The original sentence is NOT deleted silently: the replacement says what stood
there and why it was wrong, per the project's annotate-never-rewrite rule.

USAGE

    python patch_3_harness_side_note.py --file harness_side.py
    python patch_3_harness_side_note.py --file harness_side.py --revert

Refuses to apply twice, and refuses to write anything unless the anchor matches
exactly once.
"""
from __future__ import annotations

import argparse
import os
import sys

MARK = "**CORRECTED 2026-08-23.**"

ANCHOR = """**There is no vendored `kistrader/` package and no `decision_engine.py` in the
archive supplied on 2026-08-22.** So this adapter puts the PRODUCTION repo on
`sys.path`, and the harness imports production's engine. That is a real
difference from the run that produced Rev 3, it is reported on every run, and
"""

REPLACEMENT = """**CORRECTED 2026-08-23.** What stood here said there was no vendored
`kistrader/` package. That was true of the 08-22 ARCHIVE and FALSE of the
machine, which has one -- the same error as the rank roadmap's "the trap has
already sprung", inferred from an absence in an archive instead of measured.

The conclusion is unchanged; the reason is different. `run_f8.py` inserts
`--prod-root` at `sys.path[0]`, AHEAD of the vendored copy, so this adapter
gets PRODUCTION's engine deliberately rather than by fallback.
`scripts/06_sweep.py` inserts the kis-backtest root instead and gets the
VENDORED one. Both are intentional -- but they are not the same engine, so F8
and a sweep do not share an entry path. That is a real
difference from the run that produced Rev 3, it is reported on every run, and
"""


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--file", default="harness_side.py")
    ap.add_argument("--revert", action="store_true")
    a = ap.parse_args()

    if not os.path.isfile(a.file):
        print("FATAL: no such file %r -- run this from the f8 directory." % a.file)
        return 2

    with open(a.file, encoding="utf-8") as fh:
        src = fh.read()

    if a.revert:
        if MARK not in src:
            print("nothing to revert: %s does not carry patch 3." % a.file)
            return 0
        if src.count(REPLACEMENT) != 1:
            print("FATAL: the patched block is not present exactly once "
                  "(found %d). Refusing to guess." % src.count(REPLACEMENT))
            return 1
        out = src.replace(REPLACEMENT, ANCHOR)
        verb = "REVERTED"
    else:
        if MARK in src:
            print("already applied: %s carries patch 3. Nothing to do." % a.file)
            return 0
        n = src.count(ANCHOR)
        if n != 1:
            print("FATAL: the anchor appears %d time(s), expected exactly 1.\n"
                  "The file is not the version this patch was written against. "
                  "Nothing written." % n)
            return 1
        out = src.replace(ANCHOR, REPLACEMENT)
        verb = "APPLIED"

    # No BOM, LF endings -- house rule 5. PowerShell's Set-Content would add a
    # BOM here and Python would then fail to parse the file.
    with open(a.file, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(out)

    delta = len(out.splitlines()) - len(src.splitlines())
    print("%s: %s  (%+d lines, docstring only)" % (verb, a.file, delta))
    print("Now re-run:  python run_f8.py --prod-root <prod> --harness ..\\minervini_backtest.py")
    print("It must still be 98/98 -- this patch touches no executable line.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
