# RUN THESE — exact commands, in order

Windows PowerShell. One command per block. No placeholders except where marked.
Every script auto-inserts the repo root on `sys.path`, so run them from the repo root.

---

## 0. Create the repo

```powershell
New-Item -ItemType Directory -Force -Path C:\Users\user\PyCharmMiscProject\kis-backtest
```

```powershell
Set-Location C:\Users\user\PyCharmMiscProject\kis-backtest
```

Copy the 12 delivered `.py` files + `RUNBOOK.md` into that folder, and the `scripts\`
folder inside it. Then vendor the two production modules:

```powershell
Copy-Item C:\Users\user\PyCharmMiscProject\kis-trader\kistrader\entry\decision_engine.py C:\Users\user\PyCharmMiscProject\kis-backtest\decision_engine.py
```

```powershell
Copy-Item C:\Users\user\PyCharmMiscProject\kis-trader\kistrader\entry\screen_contract.py C:\Users\user\PyCharmMiscProject\kis-backtest\screen_contract.py
```

```powershell
New-Item -ItemType Directory -Force -Path C:\Users\user\PyCharmMiscProject\kis-backtest\data\bars
```

---

## 1. Environment

```powershell
python -m venv C:\Users\user\PyCharmMiscProject\kis-backtest\.venv
```

```powershell
C:\Users\user\PyCharmMiscProject\kis-backtest\.venv\Scripts\Activate.ps1
```

```powershell
pip install "numpy==2.4.6" "pandas==3.0.3" pyarrow "yfinance==1.4.1" "lxml==6.1.1"
```

---

## 2. Verify before touching data — all four must pass

```powershell
python C:\Users\user\PyCharmMiscProject\kis-backtest\self_test.py
```

```powershell
python C:\Users\user\PyCharmMiscProject\kis-backtest\audit.py
```

```powershell
python C:\Users\user\PyCharmMiscProject\kis-backtest\audit_full.py
```

```powershell
python C:\Users\user\PyCharmMiscProject\kis-backtest\test_signals.py
```

Expected tails: `ALL SELF-TESTS PASSED`, `AUDIT PASSED`, `AUDIT CLEAN`,
`SIGNAL PIPELINE OK`.

I built against pandas 3.0.2; you are pinning 3.0.3. **If a rolling/ewm behaviour
changed, it fails here.** That is why this runs before anything else.

---

## 3. Universe + frozen sector map (~1 min, needs network)

```powershell
python C:\Users\user\PyCharmMiscProject\kis-backtest\scripts\01_universe.py
```

Writes `data\universe.csv` and `data\sectors.csv`. Ends with `load_sector_map OK`.
If a Wikipedia table layout moved, it exits non-zero rather than writing a partial
universe — a partial universe silently changes every RS percentile.

---

## 4. Download bars (1–2 h, resumable — just re-run after any failure)

```powershell
python C:\Users\user\PyCharmMiscProject\kis-backtest\scripts\02_download.py
```

Read the COVERAGE block at the end. Names under 504 rows cannot be VCP-scored;
under 221 they cannot clear Stage 1 at all. `^GSPC` missing is fatal.

---

## 5. THE GATE — do not skip

```powershell
python C:\Users\user\PyCharmMiscProject\kis-backtest\scripts\03_gate.py
```

Reproduces the 2026-08-05 scores from the seed doc (NTAP 73.55, UNH 67.58,
BRKR 72.0, PTGX 62.54, +6 more). **Exits non-zero on any mismatch and prints the
four likely causes in order.** If this fails, everything downstream is void.

---

## 6. Generate signals (slow — this is the expensive step)

```powershell
python C:\Users\user\PyCharmMiscProject\kis-backtest\scripts\04_signals.py --every 5 --start 2015-01-01
```

Weekly rescan. Use `--every 1` for every session if you have the time. Caches to
`data\signals.pkl`; nothing downstream regenerates it.

Prints the VCP score distribution and how many emissions clear each threshold. If
nothing clears 80, that is the observation that motivated this project — not an error.
Zero candidates overall **is** an error and it exits non-zero.

---

## 7. First run -- STATE THE CONFIGURATION

> **Rewritten by PATCH L (2026-08-28).** This section used to read
> `05_backtest.py --threshold 80`. That command now REFUSES TO RUN, and it
> was wrong before it refused: 80 is the threshold Rev 3 sec.4 measured and
> REJECTED, and the script silently supplied `rank_mode=rs_only`,
> `stall_day=10`, `regime_ma=None`, `sector_cap=2`, `risk=0.0075` and
> `cap=0.20` -- three of the four frozen parameters wrong. Two reproduction
> attempts through the old command returned +0.04 R and +0.152 R against
> the published +0.330 R before the cause was found.

The frozen set. Expect **200 trades, +49.92% return, -19.50% drawdown** at
5 bps -- if those three do not appear, stop and fix it before running
anything downstream.

```powershell
python C:\Users\user\PyCharmMiscProject\kis-backtest\scripts\05_backtest.py --rank-mode vcp_only --threshold 75 --regime-ma 20 --stall-day 252 --sector-cap 2 --risk-pct 0.0085 --max-position-pct 0.25 --signals data\signals_daily.pkl
```

Prints DIAGNOSTICS before RESULTS, deliberately. If `decision_engine` drops
dominate, you are measuring the caps and not the threshold -- it flags that
inline.

For a run that matches what the trader ACTUALLY executes rather than Rev 3,
swap two flags: `--regime-ma off --sector-cap 0` (PATCH F / F3, 2026-08-25).
Never merge the two configurations in one comparison.

`--signals data\signals_daily.pkl` is every=1 and is Rev 3's window
natively (2018-01-02..2026-08-07). `data\signals.pkl` is every=5 and
starts in 2015; a lower trade count from it is a SAMPLING difference, not a
strategy one.

---

## 8. The sweep — the actual deliverable

```powershell
python C:\Users\user\PyCharmMiscProject\kis-backtest\scripts\06_sweep.py --param threshold --metric expectancy_R
```

Then the same sweep on the other metric, because in testing the two disagreed:

```powershell
python C:\Users\user\PyCharmMiscProject\kis-backtest\scripts\06_sweep.py --param threshold --metric total_return_pct
```

**Decide which metric adjudicates before you look at either output.**

Read the VERDICT line:
- `SETTINGS DID NOT DIFFERENTIATE` → a constraint decided it, not the parameter. False pass.
- `NOT ROBUST` → the winner flips across the cost grid. Report the instability.
- `ROBUST` → defensible recommendation.

Settings that produce **zero trades are excluded and listed** — otherwise a setting
that never trades scores 0.0 and outranks a losing one.

Then one parked parameter at a time — never two:

```powershell
python C:\Users\user\PyCharmMiscProject\kis-backtest\scripts\06_sweep.py --param atrfloor
```

```powershell
python C:\Users\user\PyCharmMiscProject\kis-backtest\scripts\06_sweep.py --param maxstop
```

```powershell
python C:\Users\user\PyCharmMiscProject\kis-backtest\scripts\06_sweep.py --param nmax
```

```powershell
python C:\Users\user\PyCharmMiscProject\kis-backtest\scripts\06_sweep.py --param entrystyle
```

---

## 9. Survivorship

Set the threshold to whatever the sweep settled on, then run:

```powershell
$env:BT_THRESHOLD="80"; python C:\Users\user\PyCharmMiscProject\kis-backtest\scripts\07_survivorship.py
```

Runs coverage (skipped unless you supply `data\removals.csv`), the bias gradient, and
the synthetic delisting stress. Reports bounds; corrects nothing.

`data\removals.csv` is optional and hand-built from the Wikipedia "selected changes"
tables — columns `date,ticker,reason`. Worth doing for one reason above all: rows whose
reason is a **rebalance or market-cap decline are still listed and still in yfinance**,
so reinstating them expands the historical universe for free.

---

## Notes

- `--param atrfloor` sweeps `atr_mult_min`. Confirm that field name exists in your
  vendored `decision_engine.py`; if the ATR band is parameterised differently, edit
  the `SWEEPS` dict in `06_sweep.py`.
- `03_gate.py` scans the **full universe**, not just the ten gate tickers, because RS
  is a percentile over the scanned population. Scoring ten names in isolation gives
  ten different RS ratings and the VCP scores will not match.
- Every script is idempotent except `02_download.py`, which is resumable.
