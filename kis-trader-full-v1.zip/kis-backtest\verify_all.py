"""
verify_all.py -- run this after ANY edit, before running anything else.

Exists because pyflakes is not enough. `pyflakes` (and `ast.parse`) accept code
that the bytecode compiler rejects -- `global X` after X is read in the same
function is a SyntaxError raised at COMPILE time, not parse time. That exact
class of bug shipped in 03_gate.py and only surfaced when it was executed.

Three layers, cheapest first:
  1. compile() every file        -- catches real SyntaxErrors pyflakes misses
  2. pyflakes                    -- undefined names, unused imports
  3. import every module         -- catches import-time failures (bad vendoring,
                                    missing kistrader package, circular imports)

Usage:
    python verify_all.py
"""
import pathlib
import subprocess
import sys


def compile_all(files):
    bad = []
    for p in files:
        try:
            compile(p.read_text(encoding="utf-8"), str(p), "exec")
        except SyntaxError as e:
            bad.append(f"{p}:{e.lineno}  {e.msg}")
    return bad


def import_all(modules):
    bad = []
    for m in modules:
        try:
            __import__(m)
        except Exception as e:
            bad.append(f"{m}: {type(e).__name__}: {e}")
    return bad


def main():
    root = pathlib.Path(__file__).resolve().parent
    files = sorted(root.glob("*.py")) + sorted((root / "scripts").glob("*.py"))
    print(f"[verify] {len(files)} file(s)\n")

    print("1. compile()  (catches what pyflakes cannot)")
    bad = compile_all(files)
    for b in bad:
        print(f"   SYNTAX  {b}")
    print("   ok" if not bad else f"   {len(bad)} broken")
    if bad:
        sys.exit(1)

    print("\n2. pyflakes")
    try:
        r = subprocess.run([sys.executable, "-m", "pyflakes"] + [str(f) for f in files],
                           capture_output=True, text=True)
        out = (r.stdout + r.stderr).strip()
        print("   " + (out.replace("\n", "\n   ") if out else "ok"))
    except FileNotFoundError:
        print("   skipped (pip install pyflakes)")

    print("\n3. import every module")
    mods = ["minervini_backtest", "signals", "vcp_engine"]
    bad = import_all(mods)
    for b in bad:
        print(f"   IMPORT  {b}")
    print("   ok" if not bad else f"   {len(bad)} broken")
    if bad:
        print("\n   If this is 'No module named kistrader', the vendored production")
        print("   modules are in the wrong place. decision_engine.py imports")
        print("   kistrader.entry.screen_contract, so both must live at")
        print("   kistrader\\entry\\ with __init__.py files, not flat at the root.")
        sys.exit(1)

    print("\n[verify] PASSED")


if __name__ == "__main__":
    main()
