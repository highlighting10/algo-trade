# FINDING — 2026-09-16: `HTTP_TIMEOUT = 5` is below the median latency of every account endpoint

> ## ⚠ TITLE AND HEADLINE CORRECTED 2026-09-17 — read §8 before §2
>
> A 16-hour, 2,334-sample probe says the title is **wrong for most of the day**.
> From 06h–13h UTC the median is **1.0 s**, not 7 s, and nothing fails. The 60
> samples this document was built on were taken at 04:0x–04:2x, inside a two-hour
> anomaly (05h median 19.58 s, 68% failures). I generalised from an unrepresentative
> window — the exact error project instruction 1 exists to prevent.
>
> What survives: at the **market open** the median is ~7.8 s and a 5 s timeout
> truncates over 90% of account calls. What is new and larger: **216 of 2,334
> samples were rejected by the server (`rt_cd=1`), not timed out**, and `_failed()`
> cannot tell the two apart. §8 has the measurements; §6's plan is superseded.

One miscalibrated constant sits under at least four separate logged symptoms, one of
which has silently killed two entries. Measured on the box, market closed, trader
stopped, token pre-issued, zero contention.

---

## 1. What started it

Tuesday's screener run armed nothing:

```
2026-09-15 13:30:57,578 WARN | arm: buying power UNKNOWN — refusing to arm (fail-safe). ...
2026-09-15 13:30:57,579 WARN | arm reject: HALO — buying power unknown (fail-safe) [rs=95 s2=50.0 vcp=67.2]
2026-09-15 13:30:57,579 WARN | arm_today: 19 candidates -> 1 planned -> 0 armed (0 watching, 0 order(s) live)
```

HALO carried `vcp=67.2`, the top non-duplicate under `vcp_only` ranking — it *was* the
plan. `entry_manager.py:161` makes this a batch-level refusal, not a per-candidate one:

```python
bp = self._buying_power()
if self.require_bp and bp is None:
    self.alert("arm: buying power UNKNOWN — refusing to arm (fail-safe). ...")
    return [], [Rejection(p.ticker, "buying power unknown (fail-safe)") for p in plans]
```

Not the first time, and **not caused by the 09-15 deploy** — `entry_manager.py` is
unchanged since 09-08:

```
3151:  2026-09-08 14:08:33   UNKNOWN (no plan to kill)
3539:  2026-09-10 13:31:21   UNKNOWN -> arm reject: MPC
4263:  2026-09-15 13:30:57   UNKNOWN -> arm reject: HALO
```

**Two arms lost.** Nobody noticed because the alert is WARN — log only, no push —
and `0 armed` reads exactly like a day when nothing qualified.

### CORRECTION, same day: it is at least FOUR arming events, not two

Reading the box's CRITICAL history for a routine health check turned up two more,
on the sibling endpoint, each of which blocked a **whole session's** batch rather
than one candidate:

```
2026-09-08 14:57:37 CRITICAL | ARM BLOCKED: broker holdings UNREADABLE -- cannot
  measure exposure or de-duplicate against real positions. Arming NOTHING (fail-safe).
2026-09-08 14:57:37 CRITICAL | ARM BLOCKED: no equity reading -- skipping arm (fail-safe)
2026-09-11 13:30:42 CRITICAL | ARM BLOCKED: broker holdings UNREADABLE -- ...
2026-09-11 13:30:42 CRITICAL | ARM BLOCKED: no equity reading -- skipping arm (fail-safe)
```

`inquire-balance`, median 7.17 s, against the same 5 s timeout. So the ledger is:

| date | endpoint | cost |
|---|---|---|
| 2026-09-08 | balance | **whole batch** blocked |
| 2026-09-10 | psamount | MPC |
| 2026-09-11 | balance | **whole batch** blocked |
| 2026-09-15 | psamount | HALO |

These two *did* reach the phone — CRITICAL routes to Telegram — so unlike the WARN
pair they were seen, and were read as a broker problem rather than as a client
timeout. Both readings were wrong in the same direction: the broker was answering
fine.

~~**Unresolved, flagged not inferred:** `ARM BLOCKED: no equity reading` fires in
the same millisecond as the holdings failure on both dates...~~

**RESOLVED 2026-09-17 — the message is a misnomer.** `pipeline._account_state()`
has **two** `return None` paths, and the holdings one already alerts accurately:

```python
truth = self.broker.get_all_holdings()
if truth is None:
    self.alert("ARM BLOCKED: broker holdings UNREADABLE — ...")
    return None          # <- caller cannot tell WHICH None this was
...
account = self._account_state()
if account is None:
    self.alert("ARM BLOCKED: no equity reading — skipping arm (fail-safe)")
```

Equity never failed — it is `lambda: cfg.equity_usd`, a constant. So 09-08 and
09-11 were **one** fault reported twice, the second line naming the wrong cause.
The event count in the table above is unchanged; only the diagnosis is. Fix rides
with the timeout patch: the second alert must not claim a cause it cannot know.

## 2. The measurement

Direct HTTP, `timeout=20/30` so nothing is truncated, n=20 each. Idle box, market
closed, trader stopped, token issued once up front.

| endpoint | min | med | p90 | max | **> 5 s** | `rt_cd != 0` |
|---|---|---|---|---|---|---|
| quote (`inquire-asking-price`) | 2.64 | 3.88 | 5.10 | 6.15 | 3/20 | **0** |
| `inquire-psamount` | 4.87 | 6.98 | 7.94 | 8.52 | **19/20** | **0** |
| `inquire-balance` | 3.46 | 7.17 | 9.08 | 9.71 | **17/20** | **0** |

```
psamount  4.9 5.7 6.2 6.2 6.3 6.5 6.5 6.7 6.8 6.9 7.1 7.1 7.2 7.2 7.2 7.3 7.7 7.9 8.4 8.5
balance   3.5 4.8 5.0 5.6 6.2 6.6 6.7 6.8 7.0 7.1 7.2 7.5 7.5 7.7 7.9 8.7 9.0 9.1 9.1 9.7
quote     2.6 3.0 3.0 3.1 3.2 3.4 3.4 3.8 3.8 3.9 3.9 4.1 4.2 4.4 4.7 4.9 4.9 5.1 5.7 6.2
```

**`rt_cd = 0` on 60 of 60.** The server answered correctly every single time. Every
failure in production is the client hanging up on a healthy response.

`HTTP_TIMEOUT = 5` (`engine_v2.py:77`) is **below the median** of both account
endpoints.

## 3. The shipped path failing, caught live

A later probe died before it began, which is the cleanest evidence in this document:

```
RuntimeError: token issuance failed: {'rt_cd': '-1',
  'msg1': "network error: HTTPSConnectionPool(host='openapivts.koreainvestment.com',
           port=29443): Read timed out. (read timeout=5)", '_transport_error': True}
```

`_ensure_token` exhausted **all three** `HTTP_RETRIES` at 5 s each, on an idle box.

This matters because it closes a semantic gap I had flagged and could not close from
the numbers alone: `requests`' `timeout=` is a connect timeout plus a *read* timeout
applied between socket reads, **not** a total-elapsed budget. A 7 s response can
survive a 5 s timeout if no single inter-byte gap exceeds it. So "19/20 over 5 s" does
not by itself prove 19/20 of real calls fail — and I was not willing to claim it did.
The token failure proves the timeout does trip in practice, without needing the
inference.

## 4. One cause, four symptoms

* **`holdings unreadable`** — 522+ occurrences, ~20–40/day, logged since August and
  written off as "chronic background, not a regression". It is `inquire-balance`
  (median 7.17 s) losing to a 5 s timeout.
* **`buying power UNKNOWN`** ×3 — `inquire-psamount` (median 6.98 s), two arms lost.
* **`watchdog: feed silent 67s > 60s`** — quote is the fastest endpoint and still puts
  3/20 over the line.
* **token issuance** — §3.

The `# VERIFY` markers on `make_kis_buying_power_provider` are now **closed, and they
were never the fault**: TR `VTTS3007R` is correct, the param set is correct, and all
three candidate field names — `ord_psbl_frcr_amt`, `frcr_ord_psbl_amt1`,
`ovrs_ord_psbl_amt` — are present in `output`. The provider was right all along; it
was being cut off mid-call.

## 5. Why the fix is not "raise the timeout"

`reconcile()` and `recover()` hold `self._lock` **across** `broker.get_all_holdings()`,
and `on_tick()` takes the same lock. A slow balance read blocks the tick path — pivot
triggers, stop checks — for its entire duration.

```
worst-case lock hold, current (5 s  x 3 + 1.5 backoff)   16.5 s
                 timeout 12, retries 3                   37.5 s
                 timeout 12, retries 2                   24.5 s
                 timeout 12, retries 1                   12.0 s
```

Raising the timeout alone makes the stall **worse**. The timeout and the retry count
have to move together. The retries were compensating for a timeout that truncated
healthy calls; with `rt_cd = 0` on 60/60, a timeout that covers the distribution makes
attempt 1 succeed, and `HTTP_RETRIES` returns to its real job — genuine transport
faults.

Candidate: `HTTP_TIMEOUT = 12`, `HTTP_RETRIES = 2` → 24.5 s bound. Or retries 1 →
12 s, **better than today** on both reliability and worst-case stall.

**That constant is NOT being set from this data.** Every sample here is from an idle
box with the market closed, and all three production failures happened at the open,
under load, where the tail is unmeasured. Choosing a number from the wrong
distribution is precisely the error this project keeps paying for.

## 6. Next, in order

1. **Instrument, don't guess.** Log elapsed time on every `_request` failure — the
   reason is currently discarded at `if broker._failed(res): return None` and at
   `except Exception: return None`, both silent. One log line each, zero behaviour
   change, and tomorrow's open hands over the distribution that matters.
2. **Then set the constants** from the open-hours tail, timeout and retries together,
   with the lock-hold bound stated explicitly in the commit.
3. **Separately: the lock across a network call** is a pre-existing hazard that this
   finding only made visible. Not urgent, not this patch, but it is why the bound
   matters at all.
4. **Re-examine `_failed`'s silence.** `rt_cd = "-1"` with `_transport_error` is a
   transport fault and is treated identically to a genuine KIS rejection. Those are
   different conditions and only one of them is worth retrying.

## 7. What this does to the soak's evidence

Nothing traded wrongly — every one of these paths is fail-closed, which is why the
system has been correct and quiet rather than wrong and loud. But the soak's
*opportunity* record is understated: at least two entries that passed every strategy
gate were refused for a transport fault, and `holdings unreadable` means `_converge`
has been running far less often than assumed. Any future reading of "how many
candidates actually arm" has to account for this.

---

## 8. THE FULL-SESSION PROBE — 2026-09-17, and what it corrects

`~/http_latency_20260916.csv`: 2,334 samples, 778 per endpoint, 04:08–20:04 UTC,
one sample per endpoint per minute at `timeout=30`, token issued once at start so
the session made no `/oauth2/tokenP` call. Sections 2–5 above rest on 60 samples
taken in a single 20-minute window; this supersedes them where they disagree.

### 8.1 The median is 1 second, not 7

Eight clean hours, 06h–13h UTC, market closed, no incident:

| endpoint | n | p50 | p90 | bad |
|---|---|---|---|---|
| psamount | 434 | **1.03** | 1.15 | 14 |
| balance | 434 | **0.97** | 1.14 | 15 |
| quote | 434 | **0.95** | 0.99 | 10 |

Hourly medians make the shape unmistakable:

```
hour   psamount  balance     quote
04h      7.15     7.01      4.23     <- the window sections 2-5 were measured in
05h     19.58    19.16     15.69     <- 68% of calls failed this hour
06h..13h ~1.03    ~0.97     ~0.95     <- eight hours, ZERO failures
14h..19h ~7.4-8.8 ~7.2-9.0  ~1.8-3.7  <- market open
```

**So `HTTP_TIMEOUT = 5` is not below the median.** It is below the open-hours median
and it was below the median during a two-hour anomaly I happened to sample. The
title of this document stands only as a description of market hours.

### 8.2 What IS true: the open truncates over 90% of account calls

Good rows only, 14h–19h UTC — this is what a timeout must cover:

| endpoint | p50 | p90 | p95 | p99 | max | cut by 5s / 8s / 10s / 12s / 15s |
|---|---|---|---|---|---|---|
| psamount | 7.78 | 10.00 | 10.78 | 12.32 | 13.19 | **93.8%** / 44.1% / 10.2% / 2.3% / 0.0% |
| balance | 7.86 | 10.56 | 11.41 | 11.99 | 12.16 | **91.9%** / 47.2% / 15.2% / 1.0% / 0.0% |
| quote | 2.71 | 4.95 | 6.01 | 8.36 | 15.16 | 9.7% / 1.6% / 0.4% / 0.4% / 0.4% |

An ~8x jump in median at the open, which is exactly when arming happens. The four
lost arming events (§1) all occurred at 13:30–14:57 UTC.

### 8.3 The larger finding: a third of open-hours calls are REJECTED, not timed out

| outcome | n | p50 elapsed |
|---|---|---|
| `rt_cd=0` (success) | 2,037 | 1.02 |
| **`rt_cd=1` (server rejected)** | **216** | **8.83** |
| `EXC` (genuine hang) | 81 | 30.83 |

Open-hours rejection rate: **psamount 34.7%, balance 28.0%, quote 10.2%.**

These are not timeouts. The server answered and said no, after ~9 seconds. And
`_failed()` collapses them into the same outcome:

```python
return bool(res.get("_transport_error")) or res.get("rt_cd") not in ("0", None)
```

`rt_cd=1` → `_failed` → `get_all_holdings` returns `None` → `holdings unreadable`.
**So the chronic symptom has at least two distinct causes, and the rejection path
may be the dominant one.** Raising the timeout does nothing for it.

### 8.4 Two things this probe cannot answer, one of them my fault

1. **What `rt_cd=1` actually says.** The probe recorded `rt_cd` and not `msg1`.
   That is a design gap in the instrument, mine, and it is the single most
   important missing field: `EGW00201` (rate limit) and a token problem imply
   completely different fixes. Re-probe with `msg1` captured.
2. **Whether the probe caused what it measured.** It added 3 calls/min during the
   open on top of the trader. If the rejections are rate-limiting, some share of
   §8.2 and §8.3 is self-inflicted. Testable for free by comparing this box's own
   `holdings unreadable` count on 09-16 (probe running) against 09-14 / 09-15
   (no probe).

### 8.5 Therefore: the constant is NOT set today

§6 said "instrument, then set the constants". That plan is intact but its input
was wrong. Revised order:

1. Settle the contamination question (one grep, costs nothing).
2. Re-probe with `msg1`, and at a cadence that cannot itself rate-limit.
3. **Separate `rt_cd=1` from `_transport_error` in `_failed`** — they are different
   conditions and only one of them is worth retrying. This is now the most
   valuable single change and it is independent of the timeout.
4. Only then set `HTTP_TIMEOUT` / `HTTP_RETRIES`, against the open-hours tail,
   with the lock-hold bound (§5) stated in the commit.

On today's numbers a 12 s timeout would cover p99 of both account endpoints at the
open — but setting it before step 3 would fix the smaller half of the problem and
leave the rejections producing the identical symptom, which is how this fault
stayed unexplained for a month in the first place.

---

## 9. THE WINDOW — the mock degrades whenever a market is open (2026-09-17)

Two independent instruments, two days, same result.

**Instrument 1 — yesterday's latency probe**, bad-sample rate by UTC hour:

```
04h 1.7%   05h 68%   06h 21%   07h-12h  0.0%   13h 8.6%   14h-19h ~25%
```

**Instrument 2 — today's trader**, `holdings unreadable` per hour, no probe running,
reconcile every 300 s so **12 cycles/hour** is the denominator:

```
03h  12   <- every single cycle failed; _converge did not run at all that hour
04h   5
05h   4
06h   1       KRX closes 06:30 UTC
07h   0  ─┐
08h   0   ├─ complete hours, ~40 cycles, zero failures
09h   0   │
10h   0  ─┘  (partial when read)
```

Converted to market sessions:

```
KRX     00:00-06:30 UTC   degraded
gap     06:30-13:30 UTC   clean, median 1.0 s, zero failures
US      13:30-20:00 UTC   degraded, median ~8 s, ~25% rejected
```

**The mock is shared infrastructure and it is slowest exactly when someone is
trading** — which is the only time this system needs it. That is a property of the
venue, not of our client.

**Method note, recorded because it nearly went wrong twice.** The first read of the
07h–12h counts was taken at 06:39 UTC, when hours 07 onward had not happened: six
zeros that meant "no data", not "no failures". The same shape appeared again with
the 11h/12h columns at 10:21. Only complete elapsed hours are counted above.

### What it does to the fix

It makes `HTTP_TIMEOUT` a **smaller lever than §8 implied**. Raising it helps the
timeout half during market hours, and does nothing at all for the `rt_cd=1`
rejections (28–35% of open-hours account calls), which are the venue refusing, not
the socket expiring. Both still produce one indistinguishable `holdings unreadable`
line — which `be27e31` fixes as of today's deploy.

It also reframes the chronic count. ~20–40/day was read for a month as background
noise. It is not noise: it is a daily, predictable, session-aligned outage of
`_converge`, and during the worst hour reconciliation stops completely.
