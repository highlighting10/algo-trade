#!/usr/bin/env python3
"""
make_plumbing_csv.py — hand-built candidates for PLUMBING MODE (§9).
====================================================================

STRATEGY MODE vs PLUMBING MODE — these must never mix. The screeners produce
strategy-mode candidates (real RS / catalyst / VCP) into candidates.csv. THIS
script produces plumbing-mode candidates: the scores are INVENTED and the base
geometry is synthesized around the live quote so the name is in breakout state
and the entry limit lands marketable. Its only purpose is to drive the arm path
end-to-end on the mock when the screeners legitimately emit nothing.

It therefore writes to a SCRATCH file (default plumbing_candidates.csv) and
refuses to write candidates.csv. Point the runtime at it per-session:

    $env:KIS_CANDIDATES="plumbing_candidates.csv"
    python -m kistrader.cli run --once --arm --no-open-order-check

Geometry (mirrors make_csv.py's proven single-ticker trick):
    pivot      = last * 1.002    -> entry limit = pivot*(1+chase) lands ABOVE the
                                    market => marketable => the mock fills it
    last_close = last            -> close just UNDER pivot => breakout, and the
                                    extension guard passes (not extended)
    base_low   = pivot * 0.95    -> ~5% structural stop
    atr        = last * 0.02     -> 2% ATR, so the ATR floor is real but not binding

Requires: a live KIS mock session (quotes), .env configured. Costs no Gemini.

OFFLINE MODE (--offline)
    No broker, no TradableUniverse, no .env, no network. The price is
    FABRICATED per ticker (deterministic, 50..250) and the exchange is the
    placeholder NAS -- arm_today's tradability gate overwrites exchange from
    the universe before any order, so a placeholder cannot reach one. Rows are
    named "(PLUMBING OFFLINE)" and the sidecar screener is PLUMBING_OFFLINE so
    an arm log says which mode wrote the file.

    Its purpose is the DOWNSTREAM caps, which real signals cannot exercise:
    the bar store measured at most ONE armable name per session
    (RESULT_20260911_emit_bar_yield_measured sec.8), so n_max, the exposure
    ceiling and dedup can only ever be reached from a hand-built CSV.

        python make_plumbing_csv.py --offline A B C D E F G H I J
        python -m kistrader.tools.plan_probe plumbing\\plumbing_candidates.csv
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import zlib

from kistrader.config import Config, load_dotenv
from kistrader.entry.entry_manager import KISBrokerWithEntry
from kistrader.entry.screen_contract import (VCP_SCORE_THRESHOLD, Candidate,
                                             regime_path_for, write_candidates,
                                             write_regime)
from kistrader.core.kis_tradable_universe import TradableUniverse

DEFAULT_TICKERS = ["NVDA", "MSFT", "AAPL"]

# arm_today reads regime_path_for(candidates_path) == <dirname>/regime.json, and
# write_regime MERGES into an existing same-session file. So a plumbing sidecar
# written beside the screeners' one would record a benchmark DISAGREEMENT and
# make read_regime refuse a GENUINE run. Isolate by directory -- the only thing
# regime_path_for keys on -- and name the screener so every arm log says which
# mode wrote the file.
PLUMBING_SCREENER = "PLUMBING_MANUAL"
# A DIFFERENT name for offline rows: same guards, but the arm log then says
# whether the prices were quoted from the mock or fabricated here.
PLUMBING_OFFLINE_SCREENER = "PLUMBING_OFFLINE"
OURS = {PLUMBING_SCREENER, PLUMBING_OFFLINE_SCREENER}
DEFAULT_OUT = os.path.join("plumbing", "plumbing_candidates.csv")

# arm_today overwrites exchange from universe.resolve() before anything is
# armed, so an offline placeholder can never reach an order.
OFFLINE_EXCHANGE = "NAS"
DEFAULT_STOP_PCT = 0.05          # the shipped geometry; see --stop-pct
MAX_STOP_PCT_ARG = 0.09          # DecisionConfig.max_stop_pct is 0.10


def offline_last(ticker: str) -> float:
    """A fabricated price, DETERMINISTIC per ticker (50.00 .. 250.00).

    crc32, not hash(): hash() is salted per process, so the same ticker list
    would write a different CSV on every run and a diff would mean nothing.
    The value is arbitrary by design -- nothing downstream of the caps cares
    what it is, only that it is stable and positive."""
    return 50.0 + (zlib.crc32(ticker.encode("ascii", "replace")) % 20001) / 100.0


def us_session_date() -> str:
    """Today's US session date (EDT = UTC-4). Plumbing-grade, not a calendar."""
    return (dt.datetime.now(dt.timezone.utc) - dt.timedelta(hours=4)).date().isoformat()


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("tickers", nargs="*", default=None,
                    help=f"tickers (default: {' '.join(DEFAULT_TICKERS)})")
    ap.add_argument("--out", default=DEFAULT_OUT,
                    help="scratch CSV path. Its DIRECTORY gets a plumbing "
                         "regime.json, so it must not be a directory a real "
                         "screener writes into.")
    ap.add_argument("--session-date", default=None, help="YYYY-MM-DD (default: US today)")
    ap.add_argument("--offline", action="store_true",
                    help="fabricate prices instead of quoting them: no broker, "
                         "no universe, no .env, no network. For exercising the "
                         "downstream caps without credentials.")
    ap.add_argument("--stop-pct", type=float, default=DEFAULT_STOP_PCT,
                    help="structural stop width under the pivot (default %.2f). "
                         "This decides WHICH cap binds first: measured on a "
                         "$211,710 account, 0.05 sizes each position at 14.3%%%% "
                         "so seven fill the ceiling and n_max is unreachable; "
                         "0.07 sizes them at 10.7%%%% so eight fit and n_max "
                         "fires on the ninth."
                         % DEFAULT_STOP_PCT)
    args = ap.parse_args()

    if not (0.01 <= args.stop_pct <= MAX_STOP_PCT_ARG):
        raise SystemExit("[plumb] --stop-pct %.3f out of range 0.01..%.2f. "
                         "DecisionConfig.max_stop_pct is 0.10, and a stop at "
                         "or past it is rejected per-candidate, which tests "
                         "the stop gate, not the caps."
                         % (args.stop_pct, MAX_STOP_PCT_ARG))

    if os.path.basename(args.out).lower() == "candidates.csv":
        raise SystemExit("[plumb] refusing to write candidates.csv — these are INVENTED "
                         "scores. Keep plumbing mode in its own file.")

    # The sidecar lands in the CSV's directory. If a REAL screener already owns a
    # regime.json there, writing ours would merge a null benchmark beside its
    # real one, record a disagreement, and make read_regime refuse a genuine
    # strategy run. Refuse instead of poisoning it.
    _outdir = os.path.dirname(os.path.abspath(args.out))
    os.makedirs(_outdir, exist_ok=True)
    _rp = regime_path_for(args.out)
    if os.path.isfile(_rp):
        try:
            with open(_rp, "r", encoding="utf-8") as _fh:
                _others = sorted(set(json.load(_fh).get("screeners") or {})
                                 - OURS)
        except Exception:
            _others = ["<unreadable>"]
        if _others:
            raise SystemExit(
                "[plumb] refusing: %s is owned by %s. A plumbing sidecar merged "
                "there would record a benchmark disagreement and stop a REAL run "
                "from arming. Use --out under its own directory (default %s)."
                % (_rp, ", ".join(_others), DEFAULT_OUT))

    tickers = [t.strip().upper() for t in (args.tickers or DEFAULT_TICKERS)]
    session_date = args.session_date or us_session_date()

    screener = PLUMBING_OFFLINE_SCREENER if args.offline else PLUMBING_SCREENER
    if args.offline:
        # No .env read, no Config, no broker, no universe: nothing here can
        # touch an account, so the KIS_MOCK check has nothing to protect. The
        # banner is the substitute -- a log that cannot be mistaken for a run
        # against real quotes, let alone for strategy evidence.
        broker = uni = None
        print("*" * 74)
        print("*** OFFLINE PLUMBING — prices are FABRICATED and scores are "
              "INVENTED.")
        print("*** No broker was contacted. NOT strategy evidence. Exchange is a "
              "placeholder.")
        print("*" * 74)
    else:
        load_dotenv()
        c = Config.from_env()
        if not c.is_mock:
            raise SystemExit("[plumb] KIS_MOCK is not 1. Refusing to build fake candidates "
                             "for a LIVE account.")

        broker = KISBrokerWithEntry(c.app_key, c.app_secret, c.cano,
                                    acnt_prdt_cd=c.acnt_prdt_cd, is_mock=True)
        uni = TradableUniverse()
        uni.ensure()

    print(f"[plumb] session_date={session_date}  out={args.out}  "
          f"({screener}, stop {100 * args.stop_pct:.1f}%)")
    cands, skipped = [], []
    for t in tickers:
        if args.offline:
            # no tradability read offline: the gate lives in arm_today and
            # needs the broker. Nothing is skipped here, so a name that KIS
            # cannot trade still gets a row -- it is dropped at arm time, and
            # the caps this CSV exists to exercise do not care.
            ex, q = OFFLINE_EXCHANGE, {"last": offline_last(t), "volume": 0}
        else:
            ex = uni.resolve(t)
            if not ex:
                skipped.append((t, "not KIS-tradable"))
                continue
            q = broker.get_quote(t, ex)
        last = float(q.get("last") or 0)
        if last <= 0:
            skipped.append((t, f"empty/zero quote {q} — market closed or bad symbol"))
            continue

        pivot = round(last * 1.002, 2)
        # One number for base_low, contraction_low and depth_pct: the synthetic
        # base IS its own final contraction, so a second value here would be a
        # geometry this generator never produces.
        stop_anchor = round(pivot * (1.0 - args.stop_pct), 2)
        cand = Candidate(
            ticker=t, exchange=ex,
            rs_proxy=90, stage2_score=70.0, vcp_score=88.0,     # INVENTED
            pivot=pivot,
            base_high=pivot,
            base_low=stop_anchor,
            depth_pct=round(args.stop_pct, 4),
            # v3: synthetic base IS its own final contraction (one-contraction
            # base), so contraction_low == base_low and the stop computes to the
            # identical number the base anchor produced pre-v3.
            contraction_low=stop_anchor,
            last_close=round(last, 2),
            atr=round(last * 0.02, 2),
            # PATCH AF/S2: 0.0 is UNKNOWN and entry_manager REFUSES the breakout
            # confirmation on it, so leaving it unset makes that whole path
            # untestable. Prefer the quote's own figure; otherwise a synthetic
            # baseline the live volume can plausibly exceed by 1.5x.
            avg_vol_50=float(q.get("volume") or 0) or 500000.0,
            trade_signal=True,
            session_date=session_date,
            name=f"{t} (PLUMBING OFFLINE)" if args.offline else f"{t} (PLUMBING)",
            close_known=True,
        )
        probs = cand.problems()
        if probs:
            skipped.append((t, "; ".join(probs)))
            continue
        cands.append(cand)
        print(f"  {t:<6} {ex}  last={last:<9.2f} pivot={pivot:<9.2f} "
              f"stop~{cand.base_low:<9.2f} atr={cand.atr:.2f}")

    for t, why in skipped:
        print(f"  {t:<6} SKIPPED: {why}")
    if not cands:
        raise SystemExit("[plumb] no usable quotes — nothing written.")

    n = write_candidates(args.out, cands)
    # regime_ma=None and benchmark=None mean "the gate is off", which matches
    # ExposureConfig.regime_ma's own default, so read_regime check 5 passes and
    # PATCH F4 returns validated=True with no benchmark. test_pipeline_e2e E7
    # covers this exact path: "gate off + the screener's OWN null-regime sidecar:
    # ARMS". vcp_threshold is the REAL bar and degraded_threshold stays None --
    # a degraded sidecar can never arm, and plumbing needs to arm, so plumbing is
    # invented SCORES in a separate file, never a lowered bar.
    write_regime(_rp, session_date=session_date, screener=screener,
                 vcp_threshold=VCP_SCORE_THRESHOLD, benchmark=None,
                 regime_ma=None, benchmark_close=None, benchmark_ma=None,
                 bar_date=None, emitted=n, degraded_threshold=None)
    print(f"\n[plumb] wrote {n} PLUMBING row(s) -> {args.out}")
    print(f"[plumb] sidecar -> {_rp}  (screener={screener}, "
          f"regime_ma=null, vcp_threshold={VCP_SCORE_THRESHOLD})")
    if args.offline:
        print("[plumb] check the caps offline (no broker, no keys):")
        print(f"    python -m kistrader.tools.plan_probe {args.out}")
    print("[plumb] arm with:")
    print(f'    $env:KIS_CANDIDATES="{args.out}"')
    print("    python -m kistrader.cli run --once --arm --no-open-order-check")
    print(f"[plumb] REMEMBER: clear the env var (or restart the shell) before any "
          f"real strategy run, and delete {args.out}.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
