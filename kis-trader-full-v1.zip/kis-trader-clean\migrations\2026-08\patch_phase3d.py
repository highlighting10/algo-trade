#!/usr/bin/env python3
"""
patch_phase3d.py -- close the four gaps found rechecking Phase 3.

F1  The Phase 3c comment claimed the gate's placement means "a no-trade day must
    cost no KIS call". Measured false: on a risk-off day arm_today still calls
    _account_state(), and in production universe.ensure() too, because the gate
    writes a ceiling rather than short-circuiting. The BEHAVIOUR is right --
    running plan() is what produces a named rejection per candidate -- so the
    comment is corrected rather than the code. Short-circuiting would be the
    second-gate shape exposure_controller.py exists to avoid.

F2  read_regime(expected_threshold=...) was built, tested, and never called. The
    trader can see screen_contract.VCP_SCORE_THRESHOLD, so it now passes it: a
    screener that emitted at a different bar than the trader believes is caught
    instead of silently arming.

F3  The sidecar's regime_ma was never cross-checked. The trader consumes the
    screener's PRECOMPUTED MA, so if the two configure different windows the
    trader gates on the screener's 20-day average while its own config and logs
    say something else. Reachable exactly when regime_150 is tested by injecting
    a different ExposureConfig instead of changing the default -- which is the
    open question in freeze doc §5, i.e. the most likely thing to happen next.

F4  write_regime wrote to a fixed `<path>.tmp`. Two screeners running
    concurrently would race on it. The runbook runs them sequentially, so this
    needs a scheduling mistake to bite; a PID suffix costs one line.

BACKTEST FIDELITY, verified while rechecking (minervini_backtest.py:462, 851-859)
    _regime_sma = benchmark_close.rolling(regime_ma).mean()
    elif float(_bc) < float(_bm):  -> regime_off, eligible = []
The port matches: same SMA, `>=` is RISK_ON, unavailable empties eligible, and
only NEW entries are blocked. The timing matches too -- the backtest gates day
d+1's fills on day d's close, and production's pre-open screener gates session
D's arming on D-1's close.

Anchors are asserted; edits are applied bottom-up.

Usage:  python patch_phase3d.py <repo-root>
"""
from __future__ import annotations

import os
import sys

REGIME_MA_CHECK = '''    if (expected_regime_ma is not None
            and doc.get("regime_ma") != expected_regime_ma):
        return _no(f"sidecar regime_ma is {doc.get('regime_ma')!r} but this trader "
                   f"is configured for {expected_regime_ma!r}. The MA in the file "
                   f"was computed on the SCREENER's window; consuming it here "
                   f"would gate on one window while logging another")
'''

E7_EXTRA = '''    # (h) the screener emitted at a different bar than the trader expects
    b, db, path, mon, entry, dec, loop, fclk = _assemble(now)
    csv = _write_csv([_cand("MU", **CAND)], path="e2e_regime.csv", regime=None)
    write_regime(regime_path_for(csv), session_date=SESSION, screener="sp500_v21",
                 vcp_threshold=70.0, benchmark="^GSPC", regime_ma=20,
                 benchmark_close=110.0, benchmark_ma=100.0, bar_date=SESSION,
                 log=lambda m: None)
    seen = _capture(loop)
    armed, _rej = loop.arm_today(csv)
    check("threshold mismatch: arms nothing", armed == [], f"{armed}")
    check("threshold mismatch: the reason names the applied threshold",
          any("applied vcp_threshold" in m for m in seen), f"{seen}")

    # (i) the screener used a different regime window than this trader
    b, db, path, mon, entry, dec, loop, fclk = _assemble(now)
    csv = _write_csv([_cand("MU", **CAND)], path="e2e_regime.csv", regime=None)
    write_regime(regime_path_for(csv), session_date=SESSION, screener="sp500_v21",
                 vcp_threshold=75.0, benchmark="^GSPC", regime_ma=150,
                 benchmark_close=110.0, benchmark_ma=100.0, bar_date=SESSION,
                 log=lambda m: None)
    seen = _capture(loop)
    armed, _rej = loop.arm_today(csv)
    check("regime_ma mismatch: arms nothing (the file's MA is not this window)",
          armed == [], f"{armed}")
    check("regime_ma mismatch: the reason names both windows",
          any("regime_ma" in m and "150" in m for m in seen), f"{seen}")

'''

SIDECAR_TESTS = '''def test_regime_ma_mismatch_detected():
    """The reader consumes a PRECOMPUTED MA. If the writer used a different
    window than the consumer expects, the number is not the one the consumer
    thinks it is -- refuse rather than gate on the wrong average."""
    from kistrader.entry.screen_contract import write_regime, read_regime
    _d, _csv, rp = _regime_env()
    write_regime(rp, session_date="2026-08-14", screener="sp500_v21",
                 vcp_threshold=75.0, benchmark="^GSPC", regime_ma=150,
                 benchmark_close=5432.10, benchmark_ma=5400.00,
                 bar_date="2026-08-13", log=lambda m: None)
    c, m, meta = read_regime(rp, "2026-08-14", expected_regime_ma=20)
    assert (c, m) == (None, None), (c, m)
    assert "regime_ma" in meta["reason"] and "150" in meta["reason"], meta["reason"]
    # the matching window is accepted, and None means "do not check"
    assert read_regime(rp, "2026-08-14", expected_regime_ma=150)[2]["usable"]
    assert read_regime(rp, "2026-08-14")[2]["usable"]


def test_regime_tmp_file_is_process_scoped():
    """Two screeners running concurrently must not race on one temp file."""
    import re
    from kistrader.entry import screen_contract as SC
    src = open(SC.__file__, encoding="utf-8").read()
    m = re.search(r"^\\s*tmp = (.+)$", src, re.M)
    assert m, "write_regime no longer has a tmp path"
    assert "getpid" in m.group(1), f"temp path is not process-scoped: {m.group(1)}"


'''


def edit(text, old, new, label):
    n = text.count(old)
    if n != 1:
        raise SystemExit(f"REFUSING: anchor for {label} matched {n} times, expected 1")
    print(f"  ok  {label}")
    return text.replace(old, new)


def read(p):
    with open(p, encoding="utf-8") as f:
        return f.read()


def write(p, s):
    with open(p, "w", encoding="utf-8", newline="") as f:
        f.write(s)


def main(root):
    pl = os.path.join(root, "kistrader", "entry", "pipeline.py")
    sc = os.path.join(root, "kistrader", "entry", "screen_contract.py")
    te = os.path.join(root, "tests", "test_pipeline_e2e.py")
    tc = os.path.join(root, "tests", "test_candidate_emit.py")
    for p in (pl, sc, te, tc):
        if not os.path.isfile(p):
            raise SystemExit(f"REFUSING: not found: {p}")
    s_pl, s_sc, s_te, s_tc = read(pl), read(sc), read(te), read(tc)
    if "ExposureController" not in s_pl:
        raise SystemExit("REFUSING: Phase 3c has not been applied.")
    if "expected_regime_ma" in s_sc:
        raise SystemExit("REFUSING: Phase 3d appears to be applied already.")

    # ---------------- screen_contract.py (bottom-up) -------------------------
    print(f"screen_contract.py  ({sc})")
    s_sc = edit(s_sc, '    tmp = path + ".tmp"\n',
                '    # PID-scoped: two screeners running concurrently must not race on one\n'
                '    # temp file. os.replace stays atomic.\n'
                '    tmp = f"{path}.{os.getpid()}.tmp"\n',
                "F4: process-scoped temp file")
    s_sc = edit(s_sc, '    if doc.get("disagreements"):\n',
                REGIME_MA_CHECK + '    if doc.get("disagreements"):\n',
                "F3: cross-check the sidecar's regime_ma")
    s_sc = edit(s_sc, "                expected_threshold=None):\n",
                "                expected_threshold=None, expected_regime_ma=None):\n",
                "F3: read_regime gains expected_regime_ma")

    # ---------------- pipeline.py (bottom-up) --------------------------------
    print(f"pipeline.py  ({pl})")
    s_pl = edit(s_pl,
                "        bclose, bma, rmeta = read_regime(regime_path_for(candidates_path),\n"
                "                                         session_date)\n",
                "        bclose, bma, rmeta = read_regime(\n"
                "            regime_path_for(candidates_path), session_date,\n"
                "            # F2/F3: the sidecar records what the screener ACTUALLY applied.\n"
                "            # Cross-check both against what this trader believes, or a\n"
                "            # screener running at a different bar -- or on a different MA\n"
                "            # window than the one being logged -- arms silently.\n"
                "            expected_threshold=float(VCP_SCORE_THRESHOLD),\n"
                "            expected_regime_ma=self.exposure.cfg.regime_ma)\n",
                "F2/F3: pass both cross-checks from the trader")
    s_pl = edit(s_pl,
                "        # §regime gate (Phase 3c). Sits here, after freshness and BEFORE\n"
                "        # universe.ensure()/_account_state(), for the reason the freshness gate\n"
                "        # gives for itself: a no-trade day must cost no KIS call.\n",
                "        # §regime gate (Phase 3c). Evaluated after the freshness gate and\n"
                "        # before universe.ensure()/_account_state(), so the DECISION never\n"
                "        # depends on a KIS call. Note it does NOT short-circuit: plan() still\n"
                "        # runs, because a named rejection per candidate is what makes a\n"
                "        # regime-off day auditable. A risk-off day therefore still costs the\n"
                "        # account read -- cheap, and the alternative is a second gate, which\n"
                "        # is the shape of the orphan open_notional bug.\n",
                "F1: correct the comment to match measured behaviour")
    s_pl = edit(s_pl,
                "from kistrader.entry.screen_contract import (read_candidates, read_regime,\n"
                "                                             regime_path_for)\n",
                "from kistrader.entry.screen_contract import (read_candidates, read_regime,\n"
                "                                             regime_path_for,\n"
                "                                             VCP_SCORE_THRESHOLD)\n",
                "F2: import the shared threshold")

    # ---------------- tests --------------------------------------------------
    print(f"test_pipeline_e2e.py  ({te})")
    s_te = edit(s_te,
                "    # (f) regime_ma=None disables the phase -> pre-Phase-3 behaviour exactly\n",
                E7_EXTRA + "    # (f) regime_ma=None disables the phase -> pre-Phase-3 behaviour exactly\n",
                "E7: threshold and regime_ma mismatch cases")
    print(f"test_candidate_emit.py  ({tc})")
    s_tc = edit(s_tc,
                'ALL = [v for k, v in sorted(globals().items()) if k.startswith("test_")]\n',
                SIDECAR_TESTS
                + 'ALL = [v for k, v in sorted(globals().items()) if k.startswith("test_")]\n',
                "sidecar: regime_ma cross-check + process-scoped temp file")

    write(sc, s_sc); write(pl, s_pl); write(te, s_te); write(tc, s_tc)
    print("\nPHASE 3d APPLIED. F1-F4 closed.")
    return 0


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("usage: python patch_phase3d.py <repo-root>")
    sys.exit(main(sys.argv[1]))
