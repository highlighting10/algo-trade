# DEPLOY CLOSED — box on `9adbb2b`, sixteen commits landed (2026-09-15)

Executes `DEPLOY_20260915_main_to_box` §4 and §5. Carried Phase E stage 0, E11
stage 1, the two screener scoring changes, 4A steps 1 and 3, and the watchdog
work. **Deploy verified; the evidence it exists to produce arrives at the
12:00 UTC screener timer and the 20:00 UTC session close, both today.**

---

## 1. What is on the box now

```
/home/kis/kis-trader   detached HEAD at tag deploy-soak-2026-09-15 = 9adbb2b
                       = main 4bac30e + cherry-pick "VCP_SCORE_THRESHOLD 75 -> 45"
```

| gate | result |
|---|---|
| `pytest -q` | **2 failed / 88 passed** — exactly the two named drift guards, reported through each file's terminal `test_zz_all_checks_passed`. No third red. |
| `param_snapshot` | exit **1**, exactly **one** differing parameter (`VCP_SCORE_THRESHOLD live=45.0 frozen=75`). 23/23 PINNED, 14/14 IDENTITY. |
| `KIS_STALL_DAY=6 param_snapshot` | `** STALL_DAY live=6 frozen=252` — the systemd `Environment=` route still works |
| boot record | `tree = 9adbb2b`, **no `+dirty`**; `KIS_MOCK=1` |
| editable install | resolves to `/home/kis/kis-trader/kistrader` |
| `clock_check` | ET = UTC−4, `session_date 2026-09-14`, `is_trading_day True`, `phase CLOSED`, 10 holidays |
| `recover()` | `started; 7 live; 0 pending entry; 0 watching; phase=CLOSED` — **all seven adopted, no "no local record"** |
| units | `kistrader` active · `kistrader-deadman` active, **ARMED, FRESH (0s)** · both timers active · all four `enabled` |
| supervisor | one `starting child`. No storm. |

Deadman line, in full, because two of its fields are this deploy's own claims
under test:

```
[deadman] ARMED  file=heartbeat.txt  stale>180s  mode=watch/60s  push=telegram  state=.deadman_state.json
```

`state=.deadman_state.json` is the live name, unchanged — which is exactly what
the `--dry` split promised (`3d81088` moved only the rehearsal file, to
`.deadman_state.dry.json`). `file=` and `stale>180s` come from the unit's explicit
flags, so the changed shipped defaults never applied here, as predicted.

**Outage: 00:48:46 → 00:54:51 UTC, 6m05s**, with the US market closed (20:48 ET
Monday). Seven live positions were unmonitored for that span and nothing was
armed or watching, so the window cost nothing.

Rollback target: `git checkout $(cat ~/backups/PRE_DEPLOY_HEAD.txt)` → `6869ec7`.
The previous target is preserved at `~/backups/PRE_DEPLOY_HEAD_20260908.txt` →
`c4080e9`. Pre-deploy DB backup `~/backups/pre_deploy_20260915.db`, 233,472 B,
taken through python's `sqlite3` module (**the CLI is still not installed** —
third time recorded).

## 2. No drift this time

`git rev-parse HEAD` read `6869ec7` before anything was touched, matching
`HANDOFF_PHASE_E_20260908` §1 exactly, with a clean tree and all four units
`active` and `enabled`. This is the first deploy in the series where the box was
found where the documents said it was — `DEPLOY_CLOSE_20260905` §2 found it
silently moved to the production line with the deadman down for ten hours.

The check cost one command and is now the first step of the runbook rather than
an afterthought.

## 3. Why `0 watching`, and why that is not a fault

Monday's session armed exactly one candidate and it never fired:

```
2026-09-14 20:00:10,960 WARN | ANET watch EXPIRED — session close (pivot 200.68 never triggered)
2026-09-14 20:00:10,961 WARN | session close: 1 untriggered watch(es) expired
```

So the swap inherited seven live positions and no watches. Watches survive a
restart (`pipeline.start()` calls `recover_watches()`), but there was nothing to
restore. Had the swap happened mid-session with ANET still armed, the restored
watch line would have been the thing to look for.

## 4. What this deploy actually changes, and when each shows up

**Nothing in it altered behaviour at boot.** Everything it carries becomes
visible on a schedule:

| when | what to read | why |
|---|---|---|
| **today 12:00 UTC** | `candidates.csv`, `regime.json`, `arm reject` lines | first screener run under `VCP_CONTRACTION_MODE = strict` **and** stage-3/4 tightness scoring; also the first arm rejections carrying `[rs=.. s2=.. vcp=..]` |
| **today 20:00 UTC** | `runs/close_observations.csv*` | Phase E stage 0 widens the column set; `_rotate_if_header_changed` moves the old log to `.pre_<N>cols` **once**, on the first `on_close` write — not at boot |
| ongoing | `fundamentals_archive/2026-09/` | AJ's every-session archive, already proven |

**The candidate series breaks today.** Sets produced from 12:00 UTC onward are
not comparable with anything before it. A change in candidate count across that
boundary is this deploy, not the market.

**The before-picture is on record.** On 2026-09-14 13:30:41 UTC, pre-deploy, the
box logged 13 arm rejections with reasons and **no score suffix**
(`RESULT_20260914_step3_caps_bind_offline`). The same lines after today carry the
three numbers. That is a clean A/B on the one instrument 4A step 1 added.

## 5. Not deployed, deliberately

`1b6fe94` — the `kistrader/cli.py` UTF-8 pin that makes a redirected
`kistrader test` survive — landed on `main` **after** the tag `9adbb2b` and is
**not** on the box. Every unit here already sets
`Environment="PYTHONIOENCODING=utf-8"`, so the box's gate was never exposed to
that defect. It rides the next deploy. Recorded so nobody reads its absence as a
missed cherry-pick.

## 6. Carried forward

1. **The mock `tvol` delay, still unmeasured.** Gates E9. A `THIN` breakout-volume
   verdict is not readable until it is taken.
2. **`holdings unreadable`** — three in the last hour of Monday's session,
   consistent with the chronic ~20–40/day. Fail-closed, so it costs reconciles
   rather than trades, but it means `_converge` runs far less often than assumed.
3. **`sector_cap` is still exercised by nothing** — `0` by declaration, and no
   `sector_of` injected. `max_open_positions` left that column on 2026-09-14 when
   the box produced `max_open_positions 8 reached` on TWLO and CRL.
4. **The box still wants a reboot** — pending kernel updates. All units are
   `enabled`, so a reboot brings the stack back on its own.
5. **The live sell path has never been exercised** (`TTTT1006U`). Mock-only bug
   history means "works on mock" and "works live" can diverge on TR ids
   specifically. Needs its own verify pass before any real-money cutover.
