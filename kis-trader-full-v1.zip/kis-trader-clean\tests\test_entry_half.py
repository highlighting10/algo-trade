#!/usr/bin/env python3
"""
Entry-half mock tests (§3.8)
============================

Same spirit as kis_engine_simharness.py: a scriptable fake broker + hard
invariants. Correctness of the ENTRY half is defined by these:

  I1  idempotent arm — a re-arm of the same order_key NEVER double-places.
  I2  positive-evidence only — UNKNOWN holds; GONE-with-no-fills is NEVER a buy.
  I3  partial entry is a real position — remainder cancelled, filled qty handed off.
  I4  risk frozen correctly — initial_risk_per_share == entry - stop, > 0, at fill.
  I5  buying-power gate — UNKNOWN => refuse; batch never over-commits cash.
  I6  dedup — a ticker already held at the broker is skipped.
  I7  crash re-adoption — recovered PENDING_ENTRY re-adopts the SAME order, no re-place.
  I8  decision engine — rank order, equal-R sizing, caps, over-wide-base rejection.
  I9  handoff — the FILLED Position is accepted and driven by the real exit monitor.
  I15 pivot watch — arm != place: the BUY limit exists only after last >= pivot;
      watches persist/recover/expire correctly and never double-place.

  v2 note (2026-07-21): arm_batch creates WATCHES. Tests that need a live order
  set the fake quote at/above the pivot and call poll() once to trigger it.
"""
from __future__ import annotations


import os
import tempfile

# Self-locating AND shadow-proof. Two separate problems, both measured:
#  1. `kistrader` and `screeners` are not installed packages (pyproject
#     packages.find includes only kistrader*), so a DIRECT run -- sys.path[0] is
#     tests/ -- cannot import either. pytest happens to work because pyproject
#     sets pythonpath = [".", "tests"].
#  2. kis-backtest ships a partial COPY of kistrader/. Run pytest from the parent
#     directory and it collects both projects; whichever imports first wins
#     sys.modules, and after that sys.path is irrelevant -- Python never
#     re-resolves an imported package. That produced five collection errors
#     naming the wrong repo.
import os as _os, sys as _sys
_ROOT = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))
for _p in (_os.path.join(_ROOT, "screeners"), _ROOT):
    while _p in _sys.path:
        _sys.path.remove(_p)                 # move to the FRONT, not merely present
    _sys.path.insert(0, _p)
_k = _sys.modules.get("kistrader")
_kf = _os.path.abspath(getattr(_k, "__file__", "") or "") if _k is not None else ""
if _k is not None and not _kf.startswith(_ROOT + _os.sep):
    print(f"[path] evicting a foreign kistrader loaded from {_kf!r}; "
          f"this suite tests {_ROOT!r}")
    for _m in [_m for _m in list(_sys.modules)
               if _m == "kistrader" or _m.startswith("kistrader.")]:
        del _sys.modules[_m]

from kistrader.core.engine_v2 import (Position, PositionState, EventStore, ExecutionMonitor,
                       RESTING, GONE, UNKNOWN, HOLDING_STATES)
from kistrader.entry.screen_contract import (Candidate, candidate_from_report, make_order_key,
                            write_candidates, read_candidates)
from kistrader.entry.decision_engine import DecisionEngine, DecisionConfig, AccountState
from kistrader.entry.entry_manager import EntryManager


# ------------------------------------------------------------------ helpers
class FakeClock:
    def __init__(self): self.t = 1000.0
    def __call__(self): return self.t
    def advance(self, s): self.t += s


class FakeBroker:
    """Fully scriptable. Set _fills[oid], _status[oid], _holdings, _readable
    between poll() calls to drive the state machine deterministically."""
    def __init__(self):
        self._next = 1
        self.orders = {}
        self._fills = {}          # oid -> cumulative filled qty (or None => UNKNOWN)
        self._status = {}         # oid -> RESTING/GONE/UNKNOWN
        self._vwap = {}           # oid -> avg fill price
        self._holdings = {}       # ticker -> qty
        self._holdings_readable = True
        self._open_orders_readable = True
        self._price = {}          # ticker -> last price (for get_quote)
        self.place_calls = 0
        self.cancel_calls = 0

    # -- orders --
    def place_limit_order(self, ticker, shares, price, side, exchange="NAS"):
        self.place_calls += 1
        oid = f"OID{self._next}"; self._next += 1
        self.orders[oid] = dict(ticker=ticker, qty=int(shares), price=price,
                                side=side, exchange=exchange)
        self._fills.setdefault(oid, 0)
        self._status.setdefault(oid, RESTING)
        self._vwap.setdefault(oid, price)
        return {"ok": True, "order_id": oid, "msg": "ok"}

    def cancel_order(self, ticker, order_id, qty, exchange="NAS"):
        self.cancel_calls += 1
        return {"ok": True, "msg": "cancelled"}

    # -- reads (tri-state) --
    def get_fills(self, order_id):
        return self._fills.get(order_id, 0)          # None allowed => UNKNOWN

    def get_fills_detail(self, order_id):
        f = self._fills.get(order_id, 0)
        if f is None:
            return None
        return (f, self._vwap.get(order_id, 0.0))

    def get_order_status(self, order_id):
        return self._status.get(order_id, RESTING)

    def get_holding(self, ticker, exchange="NAS"):
        if not self._holdings_readable:
            return None
        return self._holdings.get(ticker, 0)

    def get_all_holdings(self):
        if not self._holdings_readable:
            return None
        return dict(self._holdings)

    def get_quote(self, ticker, exchange="NAS"):
        p = float(self._price.get(ticker, 100.0))
        return {"last": p, "bid": p}

    def list_open_order_tickers(self):
        if not self._open_orders_readable:
            return None                              # UNKNOWN
        out = {}
        for oid, o in self.orders.items():
            if self._status.get(oid) == RESTING:     # resting == open
                out.setdefault(o["ticker"].upper(), []).append(oid)
        return out


def _db():
    fd, path = tempfile.mkstemp(suffix=".db"); os.close(fd)
    return EventStore(path), path


def _mk_report(pivot, base_low, base_high, atr, last_close, score=90.0, signal=True,
               contraction_low=None):
    # v3: contraction_low = Wave_Lows[-1]. Default keeps the FINAL wave equal to
    # the base low (legacy fixtures unchanged); pass contraction_low to give a
    # candidate DISTINCT geometry so anchor regressions are detectable.
    cl = base_low if contraction_low is None else contraction_low
    return {"Score": score, "Trade_Signal_Active": signal,
            "Extracted_Pattern": {"Pivot": pivot, "Base_High": base_high,
                                  "Base_Low": base_low, "Wave_Lows": [base_low, cl],
                                  "Latest_ATR": atr, "Latest_Close": last_close}}


def _cand(ticker="MU", pivot=100.0, base_low=92.0, base_high=105.0, atr=2.0,
          last_close=99.0, rs=90, s2=70, exch="NAS", date="2026-06-29",
          score=90.0, signal=True, contraction_low=None):
    rep = _mk_report(pivot, base_low, base_high, atr, last_close, score, signal,
                     contraction_low)
    return candidate_from_report(ticker, exch, rs, s2, rep, date)


PASS, FAIL = [], []
_LAST_FILLED = None      # D8: set by test_happy_full_fill, read by
                         # test_handoff_to_monitor under pytest.
def check(name, cond, detail=""):
    (PASS if cond else FAIL).append(name)
    print(f"  [{'PASS' if cond else 'FAIL'}] {name}" + (f" — {detail}" if detail and not cond else ""))


# ------------------------------------------------------------------ I8 decision
def test_decision():
    print("I8 decision engine")
    eng = DecisionEngine(DecisionConfig(risk_per_trade_pct=0.01, sector_cap=0,
                                        max_position_pct=1.0))
    acct = AccountState(equity=100_000, cash=100_000)

    # sizing (v3): entry = pivot*1.005 = 100.5. Anchor = FINAL CONTRACTION low
    # (here == base_low 92 by fixture default): contraction 92*0.995 = 91.54.
    # ATR floor = entry - atr_multiple(contraction_depth)*atr; stop = min(anchor, floor).
    c = _cand()
    plans, rej = eng.plan([c], acct)
    check("produces a plan", len(plans) == 1, f"rej={[r.reason for r in rej]}")
    p = plans[0]
    entry = round(100.0 * 1.005, 2)
    mult = eng.atr_multiple(eng.contraction_depth(c))
    exp_stop = round(min(92.0 * 0.995, entry - mult * 2.0), 2)
    exp_shares = int((100_000 * 0.01) // (entry - exp_stop))
    check("entry limit = pivot*(1+chase)", abs(p.limit_price - entry) < 1e-9,
          f"{p.limit_price} vs {entry}")
    check("stop = min(structural, atr-floor)", abs(p.stop_price - exp_stop) < 1e-9,
          f"{p.stop_price} vs {exp_stop}")
    check("equal-R shares = floor(risk$/rps)", p.shares == exp_shares,
          f"{p.shares} vs {exp_shares}")
    check("risk/share = entry-stop", abs(p.est_risk_per_share - (entry - exp_stop)) < 1e-9)

    # v3 REGRESSION GUARD — anchor must be the FINAL CONTRACTION, not the base low.
    # Distinct geometry makes a silent regression to the deleted base anchor
    # DETECTABLE (the legacy fixtures collapse both anchors to one number).
    cg = _cand("CGEO", pivot=100.0, base_low=88.0, base_high=105.0, atr=2.0,
               last_close=99.0, contraction_low=96.0)
    check("distinct geometry wired (cl != base_low)",
          abs(cg.contraction_low - 96.0) < 1e-9 and abs(cg.base_low - 88.0) < 1e-9)
    plans_g, rej_g = eng.plan([cg], acct)
    check("contraction-anchored plan produced", len(plans_g) == 1,
          f"rej={[r.reason for r in rej_g]}")
    if plans_g:
        entry_g = round(100.0 * 1.005, 2)
        mult_g = eng.atr_multiple(eng.contraction_depth(cg))
        exp_g = round(min(96.0 * 0.995, entry_g - mult_g * 2.0), 2)
        base_anchor_stop = round(min(88.0 * 0.995, entry_g - mult_g * 2.0), 2)
        check("stop anchors the CONTRACTION low", abs(plans_g[0].stop_price - exp_g) < 1e-9,
              f"{plans_g[0].stop_price} vs {exp_g}")
        check("stop is NOT the old base anchor", abs(plans_g[0].stop_price - base_anchor_stop) > 1e-9,
              f"regressed to base anchor {base_anchor_stop}")

    # SHAKEOUT (errata #8): the final wave may undercut the whole base's floor —
    # that is a FEATURE (VLO/SWK/ADM 2026-07-20), and it must plan, anchored on
    # the undercutting contraction low.
    cs = _cand("SHKO", pivot=100.0, base_low=95.0, base_high=105.0, atr=2.0,
               last_close=99.0, contraction_low=93.5)
    plans_s, rej_s = eng.plan([cs], acct)
    check("shakeout geometry (cl < base_low) still plans", len(plans_s) == 1,
          f"rej={[r.reason for r in rej_s]}")
    if plans_s:
        entry_s = round(100.0 * 1.005, 2)
        mult_s = eng.atr_multiple(eng.contraction_depth(cs))
        exp_s = round(min(93.5 * 0.995, entry_s - mult_s * 2.0), 2)
        check("shakeout stop anchors the undercut low", abs(plans_s[0].stop_price - exp_s) < 1e-9,
              f"{plans_s[0].stop_price} vs {exp_s}")

    # Rank order under the PRODUCTION DEFAULT weights. Both weightings are
    # covered exhaustively in test_rank_score(); this pins that plan() uses the
    # CONFIGURED default rather than a formula baked into the call path -- the
    # exact failure that made rank_mode a no-op for the whole project.
    # AAA wins on RS+Stage2, BBB wins on VCP, so the two weightings disagree.
    a = _cand("AAA", rs=95, s2=90, score=72.0)   # 2RS+S2 = 280, vcp 72
    b = _cand("BBB", rs=80, s2=70, score=91.0)   # 2RS+S2 = 230, vcp 91
    plans, _ = eng.plan([a, b], acct)
    check("rank: production default (vcp_only) puts BBB before AAA",
          [x.ticker for x in plans] == ["BBB", "AAA"], f"{[x.ticker for x in plans]}")

    # over-wide base rejected (risk > max_stop_pct)
    wide = _cand("WIDE", pivot=100, base_low=70, base_high=105, atr=2.0)
    plans, rej = eng.plan([wide], acct)
    check("over-wide base rejected", len(plans) == 0 and any("base too wide" in r.reason or
          "max_stop_pct" in r.reason for r in rej), f"{[r.reason for r in rej]}")

    # too-extended rejected
    ext = _cand("EXT", pivot=100, last_close=110)   # >5% over pivot
    plans, rej = eng.plan([ext], acct)
    check("too-extended rejected", len(plans) == 0 and any("extended" in r.reason for r in rej))

    # caps: n_max
    eng2 = DecisionEngine(DecisionConfig(n_max=2, risk_per_trade_pct=0.01,
                                         sector_cap=0, max_position_pct=1.0,
                                         max_portfolio_exposure_pct=10.0))
    # D7: vcp_score ascends while the ticker ascends, so the top-ranked names
    # (T4, T3) are the LAST alphabetically -- a count-only assertion cannot
    # tell a working ranking from a broken one.
    cs = [_cand(f"T{i}", rs=90 - i, score=70.0 + i) for i in range(5)]
    plans, _ = eng2.plan(cs, acct)
    check("n_max caps count", len(plans) == 2)

    # sector cap
    # D7: renamed so ticker-ascending != rank-descending. With S1A/S1B/S1C the
    # two coincided, so this test passed under ANY ranking -- including none.
    sect = {"ZED": "tech", "ABE": "tech", "MID": "energy"}
    acct_s = AccountState(equity=100_000, cash=100_000, sector_of=lambda t: sect.get(t, ""))
    eng3 = DecisionEngine(DecisionConfig(sector_cap=1, risk_per_trade_pct=0.01,
                                         max_position_pct=1.0, max_portfolio_exposure_pct=10.0))
    cs = [_cand("ZED", rs=95, score=95.0), _cand("ABE", rs=90, score=80.0),
          _cand("MID", rs=85, score=88.0)]
    plans, rej = eng3.plan(cs, acct_s)
    picked = {x.ticker for x in plans}
    check("sector cap: the HIGHER-RANKED tech name takes the slot",
          picked == {"ZED", "MID"},
          f"{picked} rej={[ (r.ticker,r.reason) for r in rej]}")

    # exposure ceiling
    eng4 = DecisionEngine(DecisionConfig(risk_per_trade_pct=0.01, sector_cap=0,
                                         max_position_pct=1.0, max_portfolio_exposure_pct=0.02))
    plans, rej = eng4.plan([_cand("E1", rs=95), _cand("E2", rs=90)], acct)
    total = sum(x.est_notional for x in plans)
    check("exposure ceiling respected", total <= 0.02 * 100_000 + 1e-6,
          f"total={total}")

    # dedup vs existing
    acct_d = AccountState(equity=100_000, cash=100_000,
                          held_tickers=frozenset({"MU"}))
    plans, rej = eng.plan([_cand("MU")], acct_d)
    check("dedup vs held", len(plans) == 0 and any("duplicate" in r.reason for r in rej))


# ------------------------------------------------------------------ contract
def test_contract_roundtrip():
    print("§1.6 contract round-trip")
    cands = [_cand("MU"), _cand("NVDA", pivot=180, base_low=165, base_high=190, atr=4)]
    fd, path = tempfile.mkstemp(suffix=".csv"); os.close(fd)
    write_candidates(path, cands)
    back = read_candidates(path)
    os.unlink(path)
    ok = (len(back) == 2 and back[0].ticker == "MU" and
          abs(back[0].pivot - 100.0) < 1e-9 and back[1].ticker == "NVDA")
    check("CSV write/read preserves candidates", ok)
    bad = read_candidates.__doc__ is not None
    check("read has fail-closed docstring", bad)


# ------------------------------------------------------------------ entry mgr
def _mgr(broker, db, clock, filled_box, **kw):
    def on_fill(p): filled_box.append(p)
    kw.setdefault("require_buying_power", False)
    return EntryManager(broker, db, on_fill=on_fill, alert=lambda m: None,
                        clock=clock, entry_timeout_secs=30, **kw)


def test_happy_full_fill():
    print("full-fill happy path + I4 frozen risk")
    b, clk = FakeBroker(), FakeClock()
    db, path = _db(); filled = []
    m = _mgr(b, db, clk, filled)
    eng = DecisionEngine(DecisionConfig(risk_per_trade_pct=0.01, sector_cap=0,
                                        max_position_pct=1.0))
    plans, _ = eng.plan([_cand()], AccountState(equity=100_000, cash=100_000))
    armed, rej = m.arm_batch(plans, None, "2026-06-29")
    check("armed one", len(armed) == 1 and armed[0].state == PositionState.PENDING_ENTRY)
    check("arm placed NO order (watching)", b.place_calls == 0
          and armed[0].live_order_id is None)
    m.poll()                       # fake quote 100.0 >= pivot 100 -> trigger + place
    check("pivot touch placed the order", b.place_calls == 1 and armed[0].live_order_id)
    oid = armed[0].live_order_id
    # not filled yet -> stays pending
    m.poll()
    check("pending before fill", armed[0].state == PositionState.PENDING_ENTRY)
    # broker reports full fill at a VWAP inside the limit
    b._fills[oid] = armed[0].live_order_qty
    b._vwap[oid] = 100.20
    m.poll()
    p = armed[0]
    check("transitions to FILLED", p.state == PositionState.FILLED)
    check("handed to on_fill", len(filled) == 1 and filled[0] is p)
    check("shares = filled qty", p.shares == plans[0].shares)
    check("entry_price = VWAP", abs(p.entry_price - 100.20) < 1e-9, f"{p.entry_price}")
    check("I4 risk frozen = entry-stop > 0",
          abs(p.initial_risk_per_share - round(100.20 - p.stop_loss_price, 4)) < 1e-9
          and p.initial_risk_per_share > 0)
    check("entry-order tracking cleared", p.live_order_id is None and p.live_order_qty == 0)
    check("pending list drained", m.pending() == [])
    db.conn.close(); os.unlink(path)
    global _LAST_FILLED
    _LAST_FILLED = p          # handed to test_handoff_to_monitor;
                              # NOT returned -- pytest warns on non-None
                              # returns and will make that an error.


def test_idempotent_arm():
    print("I1 idempotent arm (no double-buy)")
    b, clk = FakeBroker(), FakeClock()
    db, path = _db()
    eng = DecisionEngine(DecisionConfig(risk_per_trade_pct=0.01, sector_cap=0,
                                        max_position_pct=1.0))
    plans, _ = eng.plan([_cand()], AccountState(equity=100_000, cash=100_000))
    m1 = _mgr(b, db, clk, [])
    m1.arm_batch(plans, None, "2026-06-29")
    m1.poll()                                     # trigger (quote 100 >= pivot 100)
    check("first arm+trigger placed", b.place_calls == 1)
    # a brand-new manager (simulating a fresh process) re-arming the same plan
    m2 = _mgr(b, db, clk, [])
    armed, _ = m2.arm_batch(plans, None, "2026-06-29")
    check("re-arm did NOT place again", b.place_calls == 1, f"place_calls={b.place_calls}")
    check("re-arm adopted the same order id",
          armed and armed[0].live_order_id == "OID1")
    db.conn.close(); os.unlink(path)


def test_positive_evidence_only():
    print("I2 positive-evidence only")
    # (a) UNKNOWN fills -> hold, no transition
    b, clk = FakeBroker(), FakeClock(); db, path = _db()
    m = _mgr(b, db, clk, [])
    eng = DecisionEngine(DecisionConfig(risk_per_trade_pct=0.01, sector_cap=0,
                                        max_position_pct=1.0))
    plans, _ = eng.plan([_cand()], AccountState(equity=100_000, cash=100_000))
    armed, _ = m.arm_batch(plans, None, "2026-06-29")
    m.poll()                                      # trigger -> place
    oid = armed[0].live_order_id
    b._fills[oid] = None                     # UNKNOWN
    m.poll()
    check("UNKNOWN fills -> stays PENDING", armed[0].state == PositionState.PENDING_ENTRY)
    db.conn.close(); os.unlink(path)

    # (b) GONE, we did not cancel, no fills, settle elapses -> CANCELLED (never FILLED)
    b, clk = FakeBroker(), FakeClock(); db, path = _db()
    m = _mgr(b, db, clk, [])
    plans, _ = eng.plan([_cand()], AccountState(equity=100_000, cash=100_000))
    armed, _ = m.arm_batch(plans, None, "2026-06-29")
    m.poll()                                      # trigger -> place
    oid = armed[0].live_order_id
    b._fills[oid] = 0
    b._status[oid] = GONE
    b._holdings_readable = True; b._holdings = {}     # no holdings => no fill evidence
    m.poll()                                  # opens settle window
    check("GONE opens settle (still pending)", armed[0].state == PositionState.PENDING_ENTRY)
    clk.advance(10)                           # > SETTLE_SECS (8)
    m.poll()
    check("GONE + settle + no evidence -> CANCELLED, NOT filled",
          armed[0].state == PositionState.CANCELLED)
    db.conn.close(); os.unlink(path)


def test_partial_entry():
    print("I3 partial entry becomes a real position")
    b, clk = FakeBroker(), FakeClock(); db, path = _db(); filled = []
    m = _mgr(b, db, clk, filled)
    eng = DecisionEngine(DecisionConfig(risk_per_trade_pct=0.05, sector_cap=0,
                                        max_position_pct=1.0))
    plans, _ = eng.plan([_cand()], AccountState(equity=100_000, cash=100_000))
    target = plans[0].shares
    armed, _ = m.arm_batch(plans, None, "2026-06-29")
    m.poll()                                      # trigger -> place
    oid = armed[0].live_order_id
    part = max(1, target // 3)
    b._fills[oid] = part
    b._vwap[oid] = 100.10
    b._status[oid] = RESTING
    m.poll()                                  # counts partial, still resting
    check("partial counted, still pending", armed[0].state == PositionState.PENDING_ENTRY
          and armed[0].live_order_filled == part)
    clk.advance(60)                           # > entry_timeout -> cancel remainder
    m.poll()
    check("remainder cancelled", b.cancel_calls == 1 and armed[0].cancel_requested)
    b._status[oid] = GONE                     # cancel confirmed off book
    m.poll()
    p = armed[0]
    check("partial -> FILLED with partial qty", p.state == PositionState.FILLED
          and p.shares == part, f"shares={p.shares} part={part}")
    check("partial handed to monitor", len(filled) == 1)
    check("partial risk frozen > 0", p.initial_risk_per_share > 0)
    db.conn.close(); os.unlink(path)


def test_buying_power():
    print("I5 buying-power gate")
    eng = DecisionEngine(DecisionConfig(risk_per_trade_pct=0.01, sector_cap=0,
                                        max_position_pct=1.0, max_portfolio_exposure_pct=10.0))
    plans, _ = eng.plan([_cand("AAA", rs=95), _cand("BBB", rs=90)],
                        AccountState(equity=100_000, cash=100_000))
    # (a) UNKNOWN cash + require -> refuse all
    b, clk = FakeBroker(), FakeClock(); db, path = _db()
    m = EntryManager(b, db, alert=lambda m: None, clock=clk,
                     buying_power_provider=lambda: None, require_buying_power=True)
    armed, rej = m.arm_batch(plans, None, "2026-06-29")
    check("UNKNOWN cash -> refuse arm", armed == [] and b.place_calls == 0)
    db.conn.close(); os.unlink(path)

    # (b) cash only enough for the first plan
    b, clk = FakeBroker(), FakeClock(); db, path = _db()
    need0 = plans[0].est_notional
    cash = need0 + 10        # enough for one, not two (after buffer)
    m = EntryManager(b, db, alert=lambda m: None, clock=clk,
                     buying_power_provider=lambda: cash, require_buying_power=True,
                     cash_buffer_pct=0.0)
    armed, rej = m.arm_batch(plans, None, "2026-06-29")
    check("cash gate arms only the affordable subset", len(armed) == 1,
          f"armed={len(armed)} rej={[r.reason for r in rej]}")
    db.conn.close(); os.unlink(path)


def test_dedup_broker():
    print("I6 dedup vs broker holdings")
    b, clk = FakeBroker(), FakeClock(); db, path = _db()
    b._holdings = {"MU": 50}                   # already hold MU
    m = _mgr(b, db, clk, [])
    eng = DecisionEngine(DecisionConfig(risk_per_trade_pct=0.01, sector_cap=0,
                                        max_position_pct=1.0))
    plans, _ = eng.plan([_cand("MU")], AccountState(equity=100_000, cash=100_000))
    armed, rej = m.arm_batch(plans, None, "2026-06-29")
    check("held ticker skipped", armed == [] and b.place_calls == 0
          and any("dedup" in r.reason for r in rej))
    db.conn.close(); os.unlink(path)


def test_crash_readoption():
    print("I7 crash re-adoption")
    b, clk = FakeBroker(), FakeClock(); db, path = _db()
    eng = DecisionEngine(DecisionConfig(risk_per_trade_pct=0.01, sector_cap=0,
                                        max_position_pct=1.0))
    plans, _ = eng.plan([_cand()], AccountState(equity=100_000, cash=100_000))
    m1 = _mgr(b, db, clk, [])
    armed, _ = m1.arm_batch(plans, None, "2026-06-29")
    m1.poll()                                     # trigger -> place
    oid = armed[0].live_order_id
    check("armed & placed once", b.place_calls == 1)

    # simulate crash: NEW manager, rehydrate PENDING_ENTRY from the event store
    filled = []
    m2 = _mgr(b, db, clk, filled)
    snaps = db.load_open_snapshots()
    pend = [p for p in snaps if p.state == PositionState.PENDING_ENTRY]
    check("recovered a PENDING_ENTRY snapshot", len(pend) == 1
          and pend[0].live_order_id == oid)
    # order fully filled while we were down
    b._fills[oid] = armed[0].live_order_qty
    b._vwap[oid] = 100.15
    still = m2.adopt(pend)
    check("adopt did NOT re-place", b.place_calls == 1, f"place_calls={b.place_calls}")
    check("adopt resolved to FILLED + handoff", len(filled) == 1
          and filled[0].state == PositionState.FILLED and still == [])
    db.conn.close(); os.unlink(path)


def test_orphan_open_order_dedup():
    print("I11 §3.9.1 untracked resting order -> no double-buy")
    eng = DecisionEngine(DecisionConfig(risk_per_trade_pct=0.01, sector_cap=0,
                                        max_position_pct=1.0))
    acct = AccountState(equity=100_000, cash=100_000)

    # (a) ORPHAN: a resting MU buy exists at the broker with NO db record
    #     (simulates a crash between place_limit_order and the ORDER_SENT log)
    b, clk = FakeBroker(), FakeClock(); db, path = _db()
    b.place_limit_order("MU", 10, 99.0, "BUY", "NAS")     # orphan: placed, never logged
    check("orphan resting order present", b.place_calls == 1)
    m = _mgr(b, db, clk, [])                               # fresh manager + fresh db
    plans, _ = eng.plan([_cand("MU")], acct)
    armed, rej = m.arm_batch(plans, None, "2026-06-29")
    check("orphan -> NOT re-placed (no double-buy)", b.place_calls == 1,
          f"place_calls={b.place_calls}")
    check("orphan -> rejected", armed == [] and len(rej) == 1)
    check("orphan reason flags untracked resting order",
          rej and ("orphan" in rej[0].reason or "untracked" in rej[0].reason),
          rej[0].reason if rej else "")
    db.conn.close(); os.unlink(path)

    # (b) FAIL-SAFE: open-order read UNKNOWN + require_open_order_check -> refuse batch
    b, clk = FakeBroker(), FakeClock(); db, path = _db()
    b._open_orders_readable = False
    m = _mgr(b, db, clk, [], require_open_order_check=True)
    plans, _ = eng.plan([_cand("MU")], acct)
    armed, rej = m.arm_batch(plans, None, "2026-06-29")
    check("open-order UNKNOWN -> whole batch refused", armed == [] and b.place_calls == 0)
    check("fail-safe reason present",
          rej and "open-order check unknown" in rej[0].reason,
          rej[0].reason if rej else "")
    db.conn.close(); os.unlink(path)

    # (c) OVERRIDE: same UNKNOWN but require_open_order_check=False -> proceeds
    b, clk = FakeBroker(), FakeClock(); db, path = _db()
    b._open_orders_readable = False
    m = _mgr(b, db, clk, [], require_open_order_check=False)
    plans, _ = eng.plan([_cand("MU")], acct)
    armed, _ = m.arm_batch(plans, None, "2026-06-29")
    check("override -> arms despite unreadable open-order check", len(armed) == 1)
    db.conn.close(); os.unlink(path)

    # (d) BACKWARD-COMPAT: a plain broker with no open-order API still arms
    class PlainFake(FakeBroker):
        list_open_order_tickers = None            # not callable -> unsupported
    b, clk = PlainFake(), FakeClock(); db, path = _db()
    m = _mgr(b, db, clk, [], require_open_order_check=True)
    plans, _ = eng.plan([_cand("MU")], acct)
    armed, _ = m.arm_batch(plans, None, "2026-06-29")
    check("plain broker (no open-order API) still arms", len(armed) == 1)
    db.conn.close(); os.unlink(path)


def test_coupling_fail_loud():
    print("I10 §1.6 coupling — missing inputs fail LOUD/SAFE, never silent")
    acct = AccountState(equity=100_000, cash=100_000)

    # report WITHOUT Latest_Close / Latest_ATR (unpatched screener)
    rep_no_close = {"Score": 90.0, "Trade_Signal_Active": True,
                    "Extracted_Pattern": {"Pivot": 100.0, "Base_High": 105.0,
                                          "Base_Low": 92.0, "Wave_Lows": [92.0]}}
    c = candidate_from_report("MU", "NAS", 90, 70, rep_no_close, "2026-06-29")
    check("missing close -> close_known False", c.close_known is False)
    check("missing close -> NOT faked to pivot", c.last_close == 0.0)
    check("missing ATR -> atr 0.0", c.atr == 0.0)
    # candidate itself is still 'valid' (unknown != corrupt)
    check("unknown close is not treated as corrupt row", c.is_valid())

    # (a) default policy: fail CLOSED with an explicit, actionable reason
    eng = DecisionEngine(DecisionConfig(risk_per_trade_pct=0.01, sector_cap=0,
                                        max_position_pct=1.0))
    plans, rej = eng.plan([c], acct)
    reason = rej[0].reason if rej else ""
    check("missing close -> rejected by default (fail closed)",
          plans == [] and len(rej) == 1)
    check("rejection names the fix (§1.6 / allow_missing_close)",
          "last_close" in reason and "allow_missing_close" in reason, reason)

    # (b) conscious override: arms, but the ATR degrade is LABELLED, not silent
    eng2 = DecisionEngine(DecisionConfig(risk_per_trade_pct=0.01, sector_cap=0,
                                         max_position_pct=1.0, allow_missing_close=True))
    plans2, _ = eng2.plan([c], acct)
    check("allow_missing_close -> arms", len(plans2) == 1)
    check("degraded stop is labelled structural-only",
          plans2 and plans2[0].stop_basis == "contraction-only")

    # (c) require_atr flips structural-only into a hard reject
    eng3 = DecisionEngine(DecisionConfig(risk_per_trade_pct=0.01, sector_cap=0,
                                         max_position_pct=1.0, allow_missing_close=True,
                                         require_atr=True))
    plans3, rej3 = eng3.plan([c], acct)
    check("require_atr -> reject when ATR unavailable",
          plans3 == [] and any("ATR" in r.reason for r in rej3))

    # (d) patched screener: full inputs -> full guard + ATR stop, no degrade
    good = _cand("NVDA", pivot=180, base_low=165, base_high=190, atr=4, last_close=181)
    check("patched candidate -> close_known True", good.close_known is True)
    plansg, _ = eng.plan([good], acct)
    check("patched candidate arms under default policy", len(plansg) == 1)
    check("patched candidate uses contraction+ATR stop basis",
          plansg and plansg[0].stop_basis == "contraction+atr")

    # (e) provenance survives the CSV round-trip
    import tempfile as _tf
    fd, p = _tf.mkstemp(suffix=".csv"); os.close(fd)
    write_candidates(p, [c, good])
    back = {x.ticker: x for x in read_candidates(p)}
    check("CSV round-trip preserves close_known False", back["MU"].close_known is False)
    check("CSV round-trip preserves close_known True", back["NVDA"].close_known is True)
    os.unlink(p)


def test_adopt_baseline():
    print("I14 §3.9.2 pre-existing holding not mis-credited as our fill")
    eng = DecisionEngine(DecisionConfig(risk_per_trade_pct=0.01, sector_cap=0,
                                        max_position_pct=1.0))
    acct = AccountState(equity=100_000, cash=100_000)

    # (a) ADOPT case: crash loses the baseline; a pre-existing MU holding must NOT
    #     be read as this order's fill.
    b, clk = FakeBroker(), FakeClock(); db, path = _db()
    m1 = _mgr(b, db, clk, [])
    plans, _ = eng.plan([_cand("MU", pivot=100, base_low=92, last_close=100)], acct)
    armed, _ = m1.arm_batch(plans, None, "2026-06-29")     # watch armed
    m1.poll()                                              # trigger -> place (baseline=0)
    pos = armed[0]; oid = pos.live_order_id
    b._status[oid] = GONE; b._fills[oid] = 0               # order expired, no fill
    b._holdings["MU"] = 50                                 # a pre-existing/unrelated position

    m2 = _mgr(b, db, clk, [])                              # fresh manager (baseline lost)
    m2.adopt([pos])                                        # opens the settle window
    check("still pending after first adopt tick", pos.state == PositionState.PENDING_ENTRY)
    clk.advance(10)                                        # > SETTLE_SECS
    m2.poll()
    check("pre-existing holding NOT adopted as a fill (cancelled)",
          pos.state == PositionState.CANCELLED, f"state={pos.state.value}")
    db.conn.close(); os.unlink(path)

    # (b) NORMAL backstop intact: baseline known (0), holdings show the real fill
    #     (e.g. get_fills under-reported) -> finalize with the held qty.
    b, clk = FakeBroker(), FakeClock(); db, path = _db()
    m = _mgr(b, db, clk, [])
    plans, _ = eng.plan([_cand("NVDA", pivot=180, base_low=165, base_high=190,
                               atr=4, last_close=180)], acct)
    armed, _ = m.arm_batch(plans, None, "2026-06-29")      # watch armed
    b._price["NVDA"] = 180.0
    m.poll()                                               # trigger -> place (baseline=0)
    pos = armed[0]; oid = pos.live_order_id; qty = pos.live_order_qty
    b._status[oid] = GONE; b._fills[oid] = 0               # executions under-report
    b._holdings["NVDA"] = qty                              # holdings show the true fill
    m.poll()                                               # opens settle window
    m.poll()                                               # held-baseline = qty -> finalize
    check("normal holdings backstop still finalizes", pos.state == PositionState.FILLED)
    check("finalized with the held qty", pos.shares == qty, f"shares={pos.shares}")
    db.conn.close(); os.unlink(path)


def test_pivot_watch():
    print("I15 pivot watch — arm != place; trigger, persist, recover, expire")
    eng = DecisionEngine(DecisionConfig(risk_per_trade_pct=0.01, sector_cap=0,
                                        max_position_pct=1.0))
    acct = AccountState(equity=100_000, cash=100_000)

    # (a) below pivot -> NO order; the watch is in-flight for dedup purposes
    b, clk = FakeBroker(), FakeClock(); db, path = _db(); filled = []
    m = _mgr(b, db, clk, filled)
    plans, _ = eng.plan([_cand("MU", pivot=100.0, last_close=99.0)], acct)
    check("(a) plan carries the pivot", abs(plans[0].pivot - 100.0) < 1e-9)
    armed, _ = m.arm_batch(plans, None, "2026-06-29")
    check("(a) armed as WATCH: no broker order", len(armed) == 1
          and b.place_calls == 0 and armed[0].live_order_id is None)
    check("(a) watch counts as in-flight (dedup set)",
          "MU" in m._pending_tickers() and m.pending() == []
          and len(m.watching()) == 1)
    b._price["MU"] = 99.4
    m.poll()
    check("(a) below pivot after poll: still no order", b.place_calls == 0)

    # (b) UNKNOWN / zero quote is NEVER a trigger (§4.5.3 for the entry side)
    b.get_quote = lambda t, e="NAS": {"last": 0, "bid": 0}
    m.poll()
    check("(b) zero quote holds the watch", b.place_calls == 0
          and len(m.watching()) == 1)
    b.get_quote = lambda t, e="NAS": {"last": None, "bid": None}
    m.poll()
    check("(b) None quote holds the watch", b.place_calls == 0)
    del b.get_quote                                 # restore the class impl

    # (c) cross -> EXACTLY one order; the SAME object moves watch -> pending
    b._price["MU"] = 100.0
    m.poll()
    check("(c) pivot touch places exactly one order", b.place_calls == 1
          and armed[0].live_order_id == "OID1")
    check("(c) same Position object now pending", m.pending() == [armed[0]]
          and m.watching() == [])
    m.poll()
    check("(c) further polls do not re-place", b.place_calls == 1)
    db.conn.close(); os.unlink(path)

    # (d) arm_batch dedup vs an ACTIVE watch: no double-watch, no order
    b, clk = FakeBroker(), FakeClock(); db, path = _db()
    m = _mgr(b, db, clk, [])
    plans, _ = eng.plan([_cand("MU", pivot=100, last_close=99)], acct)
    m.arm_batch(plans, None, "2026-06-29")
    armed2, rej2 = m.arm_batch(plans, None, "2026-06-29")
    check("(d) re-arm vs active watch -> dedup reject, no order",
          armed2 == [] and b.place_calls == 0
          and any("dedup" in r.reason for r in rej2),
          f"rej={[r.reason for r in rej2]}")
    db.conn.close(); os.unlink(path)

    # (e) crash MID-WATCH: restore the WATCH (not an order), then trigger once
    b, clk = FakeBroker(), FakeClock(); db, path = _db()
    m1 = _mgr(b, db, clk, [])
    plans, _ = eng.plan([_cand("MU", pivot=100, last_close=99)], acct)
    m1.arm_batch(plans, None, "2026-06-29")
    check("(e) pre-crash: watch armed, no order", b.place_calls == 0)
    check("(e) watch snapshot invisible to open-snapshot recovery",
          db.load_open_snapshots() == [])
    m2 = _mgr(b, db, clk, [])
    rest = m2.recover_watches("2026-06-29")
    check("(e) watch restored, still no order", len(rest) == 1
          and b.place_calls == 0 and len(m2.watching()) == 1)
    b._price["MU"] = 100.5
    m2.poll()
    check("(e) restored watch triggers once", b.place_calls == 1)
    db.conn.close(); os.unlink(path)

    # (f) crash AFTER trigger+place: recovery closes the watch, NEVER re-places
    b, clk = FakeBroker(), FakeClock(); db, path = _db()
    m1 = _mgr(b, db, clk, [])
    plans, _ = eng.plan([_cand("MU", pivot=100, last_close=99)], acct)
    m1.arm_batch(plans, None, "2026-06-29")
    b._price["MU"] = 100.2
    m1.poll()
    check("(f) placed pre-crash", b.place_calls == 1)
    m2 = _mgr(b, db, clk, [])
    rest = m2.recover_watches("2026-06-29")
    check("(f) recover after place: watch closed, NOT re-placed",
          rest == [] and b.place_calls == 1 and m2.watching() == [])
    db.conn.close(); os.unlink(path)

    # (g) watches are DAY ORDERS: stale-session recovery expires; live expiry drains
    b, clk = FakeBroker(), FakeClock(); db, path = _db()
    m1 = _mgr(b, db, clk, [])
    plans, _ = eng.plan([_cand("MU", pivot=100, last_close=99,
                               date="2026-06-29")], acct)
    m1.arm_batch(plans, None, "2026-06-29")
    m2 = _mgr(b, db, clk, [])
    rest = m2.recover_watches("2026-06-30")
    check("(g) stale watch expired on recovery, no order",
          rest == [] and m2.watching() == [] and b.place_calls == 0)
    m3 = _mgr(b, db, clk, [])
    plans2, _ = eng.plan([_cand("ZZ", pivot=50, base_low=47, base_high=52,
                                atr=1.0, last_close=49, date="2026-06-30")], acct)
    m3.arm_batch(plans2, None, "2026-06-30")
    n = m3.expire_watches("session close")
    check("(g) expire_watches drains actively, no order",
          n == 1 and m3.watching() == [] and b.place_calls == 0)
    db.conn.close(); os.unlink(path)

    # (h) gap ABOVE the capped limit: the SAME limit is placed (it rests) — no chase
    b, clk = FakeBroker(), FakeClock(); db, path = _db()
    m = _mgr(b, db, clk, [])
    plans, _ = eng.plan([_cand("MU", pivot=100, last_close=99)], acct)
    lim = plans[0].limit_price
    m.arm_batch(plans, None, "2026-06-29")
    b._price["MU"] = 108.0                      # gapped far past pivot AND limit
    m.poll()
    oid = m.pending()[0].live_order_id
    check("(h) gap-up places the CAPPED limit (no chase)",
          b.place_calls == 1 and abs(b.orders[oid]["price"] - lim) < 1e-9,
          f"placed {b.orders[oid]['price']} vs limit {lim}")
    db.conn.close(); os.unlink(path)


    # (j) CRASH BETWEEN PLACING AND LOGGING TRIGGERED: the watch is still ARMED
    # on disk but the order already exists. Recovery must adopt it via the
    # ORDER_SENT marker and NEVER re-place. (Before the 2026-07-23 reorder,
    # TRIGGERED was logged first, so this window lost the breakout entirely:
    # no watch to restore, no order to adopt.)
    b, clk = FakeBroker(), FakeClock(); db, path = _db()
    m1 = _mgr(b, db, clk, [])
    plans, _ = eng.plan([_cand("MU", pivot=100, last_close=99)], acct)
    m1.arm_batch(plans, None, "2026-06-29")
    b._price["MU"] = 100.2
    m1.poll()
    check("(j) setup: order placed", b.place_calls == 1)
    db.conn.execute("DELETE FROM position_events "
                    "WHERE event_type LIKE 'WATCH_TRIGGERED%'")   # simulate the crash
    db.conn.commit()
    m2 = _mgr(b, db, clk, [])
    rest = m2.recover_watches("2026-06-29")
    check("(j) crash before the TRIGGERED log -> adopted, NOT re-placed",
          rest == [] and b.place_calls == 1 and m2.watching() == [])
    db.conn.close(); os.unlink(path)

    # (i) orphan resolver is INERT against a watch-only record: a broker holding
    # whose newest snapshot is a WATCH (never placed) must NOT be adopted — the
    # ORDER_SENT marker is the authority, and a pre-placement watch has none.
    b, clk = FakeBroker(), FakeClock(); db, path = _db()
    m = _mgr(b, db, clk, [])
    plans, _ = eng.plan([_cand("MU", pivot=100, last_close=99)], acct)
    m.arm_batch(plans, None, "2026-06-29")          # WATCH_ARMED is the newest record
    b._holdings["MU"] = 50                          # an unrelated/manual MU position
    check("(i) resolve_orphan refuses a watch-only record",
          m.resolve_orphan("MU", 50) is None and b.place_calls == 0)
    db.conn.close(); os.unlink(path)


def test_quote_guard():
    print("I12 §4.5.3 a failed/zero quote never becomes a tick")
    from kistrader.core.run_loop import RunLoop

    class _P:                       # minimal position stand-in
        ticker = "AAPL"; exchange = "NAS"

    b = FakeBroker()
    loop = RunLoop(monitor=object(), broker=b, alert=lambda m: None)

    # (a) transport-error-shaped quote (0/0) -> _quote returns None (tick skipped)
    b.get_quote = lambda t, e="NAS": {"last": 0, "bid": 0}
    check("zero/failed quote -> no tick (returns None)", loop._quote(_P()) is None)

    # (b) a valid quote passes through as (last, bid)
    b.get_quote = lambda t, e="NAS": {"last": 190.0, "bid": 189.9}
    check("valid quote -> (last, bid)", loop._quote(_P()) == (190.0, 189.9))

    # (c) None fields don't crash and count as no-quote
    b.get_quote = lambda t, e="NAS": {"last": None, "bid": None}
    check("None fields -> no tick", loop._quote(_P()) is None)


def test_providers():
    print("I13 §5.4 EMA + daily-close providers")
    from kistrader.entry.providers import ema, DailyCloseEMAProvider

    # (a) EMA math, hand-verified: [10,11,12,13,14], period 3
    #     SMA seed=(10+11+12)/3=11; k=0.5; ->13 ->13.0
    check("ema hand-check", abs(ema([10, 11, 12, 13, 14], 3) - 13.0) < 1e-9,
          f"{ema([10,11,12,13,14],3)}")
    try:
        ema([1, 2], 3); ok = False
    except ValueError:
        ok = True
    check("ema raises on < period", ok)

    # (b) provider close/ema over an injected series (offline)
    series = [100.0 + i for i in range(30)]        # 30 daily closes, newest last
    calls = {"n": 0}
    def fetch(t):
        calls["n"] += 1
        return series
    day = {"d": "2026-07-06"}
    prov = DailyCloseEMAProvider(fetch, ema_period=21, today_fn=lambda: day["d"])

    check("close = latest daily close", prov.close("MU") == series[-1])
    check("ema matches pure fn", abs(prov.ema("MU") - ema(series, 21)) < 1e-9)

    # (c) caching: same day -> single fetch reused across close()+ema()+repeat
    calls["n"] = 0
    prov2 = DailyCloseEMAProvider(fetch, ema_period=21, today_fn=lambda: day["d"])
    prov2.close("MU"); prov2.ema("MU"); prov2.close("MU")
    check("cached: one fetch per ticker per day", calls["n"] == 1, f"n={calls['n']}")
    day["d"] = "2026-07-07"                          # new day -> refetch
    prov2.close("MU")
    check("new day -> refetch", calls["n"] == 2, f"n={calls['n']}")

    # (d) insufficient bars -> ema None (on_close will skip, fail-safe)
    short = DailyCloseEMAProvider(lambda t: [10.0, 11.0, 12.0], ema_period=21)
    check("< period bars -> ema None", short.ema("X") is None)
    check("but close still available", short.close("X") == 12.0)

    # (e) fetch failure -> None (skip), never raises out
    boom = DailyCloseEMAProvider(lambda t: (_ for _ in ()).throw(RuntimeError("net")),
                                 ema_period=21)
    check("fetch failure -> close None", boom.close("X") is None)
    check("fetch failure -> ema None", boom.ema("X") is None)

    # (f) binding shape for RunLoop
    cp, ep = prov.as_close_provider(), prov.as_ema_provider()
    check("bound close provider callable", callable(cp) and cp("MU") == series[-1])
    check("bound ema provider callable", callable(ep) and abs(ep("MU") - ema(series, 21)) < 1e-9)


def test_handoff_to_monitor(filled_pos=None):
    print("I9 FILLED position is accepted & driven by the real exit monitor")
    b = FakeBroker(); db, path = _db()
    mon = ExecutionMonitor(b, db, alert=lambda m: None, clock=FakeClock())
    p = _LAST_FILLED if filled_pos is None else filled_pos
    assert p is not None, ("no FILLED position captured -- "
                           "test_happy_full_fill must run first")
    check("FILLED is a HOLDING state", p.state in HOLDING_STATES)
    # a benign tick above stop, below 3R: must not throw and must stay held
    price = p.entry_price + max(0.01, p.initial_risk_per_share)   # ~+1R
    mon.on_tick(p, price, price - 0.01)
    check("monitor.on_tick handled FILLED w/o error", p.state in HOLDING_STATES)
    # r_multiple is well-defined and positive here
    check("r_multiple well-defined at +1R", abs(p.r_multiple(price) - 1.0) < 0.2,
          f"r={p.r_multiple(price)}")
    db.conn.close(); os.unlink(path)


def test_frozen_defaults():
    """The frozen parameter set itself (PARAMETER_FREEZE Rev 3 §1).

    Nothing else in any suite observes these four values -- measured: changing
    all of them breaks exactly one unrelated assertion. Without this test a
    silent revert to 0.0075 / 0.20 / STALL_DAY 10 / threshold 80 would ship
    green. These are backtest decisions; if one has to change here, the backtest
    changed first."""
    print("I8c frozen parameter set + the constraints it implies")
    from kistrader.core import engine_v2 as _E
    from kistrader.entry.screen_contract import VCP_SCORE_THRESHOLD

    cfg = DecisionConfig()
    check("threshold is 75", VCP_SCORE_THRESHOLD == 75, f"{VCP_SCORE_THRESHOLD}")
    check("ranking is vcp_only (0, 0, 1)",
          (cfg.rs_weight, cfg.stage2_weight, cfg.vcp_weight) == (0.0, 0.0, 1.0),
          f"{(cfg.rs_weight, cfg.stage2_weight, cfg.vcp_weight)}")
    check("risk_per_trade_pct is 0.85%", abs(cfg.risk_per_trade_pct - 0.0085) < 1e-12,
          f"{cfg.risk_per_trade_pct}")
    check("max_position_pct is 25%", abs(cfg.max_position_pct - 0.25) < 1e-12,
          f"{cfg.max_position_pct}")
    check("STALL_DAY is 252", _E.STALL_DAY == 252,
          f"{_E.STALL_DAY} -- if this is 5 or 6 you still have KIS_STALL_DAY set "
          f"from a soak run; that value must NEVER reach live")
    check("max_stop_pct unchanged at Minervini's 10% ceiling",
          abs(cfg.max_stop_pct - 0.10) < 1e-12, f"{cfg.max_stop_pct}")
    check("no breakeven trigger was ever built (measured dead)",
          not hasattr(cfg, "be_trigger_r"))

    # -- the exposure ceiling at 0.0 must BLOCK, not mean "disabled" ------------
    # Phase 3's regime gate writes 0.0 here on a RISK_OFF day. sector_cap uses 0
    # to mean "no cap", so this is worth pinning explicitly before anything
    # depends on it.
    acct = AccountState(equity=100_000, cash=100_000)
    off = DecisionEngine(DecisionConfig(max_portfolio_exposure_pct=0.0, sector_cap=0))
    plans, rej = off.plan([_cand("AAA"), _cand("BBB")], acct)
    check("exposure ceiling 0.0 arms NOTHING (0 != disabled)", plans == [],
          f"{[p.ticker for p in plans]}")
    check("and says why", bool(rej) and all("exposure ceiling" in r.reason for r in rej),
          f"{[r.reason for r in rej]}")

    # -- which constraint actually binds at the frozen values -------------------
    # risk 0.85% / cap 25% means the cap only binds when stop distance is under
    # 0.0085/0.25 = 3.4% of entry. Realised stops run 6.3-6.5%, ceiling 10%, so
    # sizing is RISK-limited in normal operation. The freeze doc calls this
    # "unclipped at the 25% cap"; this is that claim, executed.
    eng = DecisionEngine(DecisionConfig())
    entry, stop = 100.0, 93.5                       # 6.5% stop, the realised average
    shares = eng.size(entry, stop, 100_000.0)
    by_risk = int((100_000.0 * 0.0085) // (entry - stop))
    by_cap = int((100_000.0 * 0.25) // entry)
    check("sizing is RISK-limited at a realistic 6.5% stop", shares == by_risk < by_cap,
          f"shares={shares} risk={by_risk} cap={by_cap}")
    # ... and the cap still binds when the stop is unusually tight
    tight = eng.size(100.0, 98.0, 100_000.0)        # 2% stop -> inside 3.4%
    check("the 25% cap still binds on a very tight stop", tight == by_cap,
          f"{tight} vs cap {by_cap}")


def test_zz_all_checks_passed():
    """D8 terminal guard. check() never raises, so without this pytest reports
    every function in this file as passed no matter how many checks failed.
    Defined last on purpose: pytest runs file order, so this sees the whole run.
    Harmless under the direct `python tests/...` run, which main() drives."""
    assert not FAIL, f"{len(FAIL)} failed check(s): " + "; ".join(FAIL)


def test_rank_score():
    """3.1 ranking. This function had ZERO direct coverage in any suite, and it
    is where the bug that invalidated every backtest sweep lived: plan() re-sorts
    on rank_score, so a rank_mode the score cannot express has no effect at all.

    Every case sets the weights EXPLICITLY, so this test does not need editing
    when the production defaults change in Phase 2."""
    print("I8b rank_score: no-op default, both weightings, and they must DIFFER")

    acct = AccountState(equity=100_000, cash=100_000)
    UNCAPPED = dict(risk_per_trade_pct=0.01, sector_cap=0, max_position_pct=1.0,
                    max_portfolio_exposure_pct=10.0)

    # Three names whose RS, Stage-2 and VCP orderings all DISAGREE, so no two
    # weightings can coincide by accident and no ordering can fall through to
    # the ticker tiebreak unnoticed.
    #                  rs        s2         vcp      -> 2*RS+S2
    a = _cand("AAA", rs=80, s2=90.0, score=72.0)   # 250
    b = _cand("BBB", rs=95, s2=70.0, score=91.0)   # 260
    c = _cand("CCC", rs=88, s2=55.0, score=84.0)   # 231

    # (1) rank_score is EXACTLY the linear combination of the three configured
    #     weights -- no hidden term, no formula baked into the call path. The
    #     production DEFAULTS are asserted in test_frozen_defaults(); asserting
    #     them here too would make this test need editing on every parameter
    #     change, which is exactly what it must not do.
    eng_sum = DecisionEngine(DecisionConfig(rs_weight=1.0, stage2_weight=1.0,
                                           vcp_weight=1.0))
    check("rank_score == rs*w1 + stage2*w2 + vcp*w3, no hidden terms",
          all(abs(eng_sum.rank_score(x)
                  - (x.rs_proxy + x.stage2_score + x.vcp_score)) < 1e-12
              for x in (a, b, c)))
    eng_zero = DecisionEngine(DecisionConfig(rs_weight=0.0, stage2_weight=0.0,
                                            vcp_weight=0.0))
    check("all-zero weights collapse every score to 0",
          all(eng_zero.rank_score(x) == 0.0 for x in (a, b, c)))

    # (2) today's production weighting
    eng_rs = DecisionEngine(DecisionConfig(rs_weight=2.0, stage2_weight=1.0,
                                           vcp_weight=0.0, **UNCAPPED))
    order_rs = [p.ticker for p in eng_rs.plan([a, b, c], acct)[0]]
    check("(2,1,0) selects BBB > AAA > CCC", order_rs == ["BBB", "AAA", "CCC"],
          f"{order_rs}")

    # (3) the frozen target weighting (vcp_only)
    eng_vcp = DecisionEngine(DecisionConfig(rs_weight=0.0, stage2_weight=0.0,
                                            vcp_weight=1.0, **UNCAPPED))
    order_vcp = [p.ticker for p in eng_vcp.plan([a, b, c], acct)[0]]
    check("(0,0,1) selects BBB > CCC > AAA", order_vcp == ["BBB", "CCC", "AAA"],
          f"{order_vcp}")

    # (4) THE invariant that was silently false for the project's whole history:
    #     changing the ranking must actually change the selected order.
    check("the two weightings produce DIFFERENT orders", order_rs != order_vcp,
          f"{order_rs} vs {order_vcp}")

    # (5) each weighting ignores the other's inputs completely
    hi_rs = _cand("XRS", rs=99, s2=99.0, score=10.0)
    hi_vcp = _cand("XVC", rs=1, s2=1.0, score=99.0)
    o_v = [p.ticker for p in eng_vcp.plan([hi_rs, hi_vcp], acct)[0]]
    check("vcp_only ignores RS and Stage2 entirely", o_v == ["XVC", "XRS"], f"{o_v}")
    o_r = [p.ticker for p in eng_rs.plan([hi_rs, hi_vcp], acct)[0]]
    check("rs+stage2 ignores VCP entirely", o_r == ["XRS", "XVC"], f"{o_r}")

    # (6) an exact tie must still resolve deterministically, ticker ascending
    z = _cand("ZZZ", rs=50, s2=50.0, score=88.0)
    aa = _cand("AAA", rs=50, s2=50.0, score=88.0)
    o_t = [p.ticker for p in eng_vcp.plan([z, aa], acct)[0]]
    check("exact rank tie falls to ticker ascending", o_t == ["AAA", "ZZZ"], f"{o_t}")

    # (7) the plan carries the score the engine actually ranked on, so the event
    #     log cannot disagree with the selection
    plans, _ = eng_vcp.plan([a], acct)
    check("EntryPlan.rank_score reflects the configured weights",
          bool(plans) and abs(plans[0].rank_score - 72.0) < 1e-12,
          f"{plans[0].rank_score if plans else 'no plan produced'}")


def main():
    print("=" * 62)
    print("ENTRY-HALF INVARIANT TESTS")
    print("=" * 62)
    test_decision()
    test_rank_score()
    test_frozen_defaults()
    test_contract_roundtrip()
    test_happy_full_fill()
    test_idempotent_arm()
    test_positive_evidence_only()
    test_partial_entry()
    test_buying_power()
    test_dedup_broker()
    test_crash_readoption()
    test_orphan_open_order_dedup()
    test_adopt_baseline()
    test_pivot_watch()
    test_quote_guard()
    test_providers()
    test_coupling_fail_loud()
    test_handoff_to_monitor()
    print("=" * 62)
    print(f"PASSED {len(PASS)} / {len(PASS) + len(FAIL)}")
    if FAIL:
        print("FAILED:", ", ".join(FAIL))
    print("=" * 62)
    return 1 if FAIL else 0


if __name__ == "__main__":
    import sys
    sys.exit(main())
