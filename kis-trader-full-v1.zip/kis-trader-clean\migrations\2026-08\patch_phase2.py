#!/usr/bin/env python3
"""
patch_phase2.py -- PHASE 2: promote the frozen parameter set.

THIS IS THE COMMIT THAT CHANGES THE STRATEGY. Everything before it was
scaffolding: Phase 1 added an inert field, D3a moved a declaration, D6/D8 added
tests. Nothing the trader does changed. After this, it does.

PRODUCTION (5 files' worth of values, source: PARAMETER_FREEZE Rev 3 §1)
    VCP_SCORE_THRESHOLD   80     -> 75      screen_contract.py
    rank weights        (2,1,0)  -> (0,0,1) decision_engine.py   [vcp_only]
    risk_per_trade_pct   0.0075  -> 0.0085  decision_engine.py
    max_position_pct     0.20    -> 0.25    decision_engine.py
    STALL_DAY            10      -> 252     engine_v2.py         [+ env override]

STALL_DAY becomes `int(os.environ.get("KIS_STALL_DAY", 252))` per decision D4-B.
The soak needs a short stall (Option C) to exercise paths 252 makes unreachable,
and an env var means that override never becomes an edit to the verified core --
which the README and checklist I12 both rest on being untouched. The safety net
is param_snapshot: it reads the live module attribute, so a stray KIS_STALL_DAY
shows up as a mismatch and exits 1.

TESTS (D7). Measured before writing this: with the production values changed and
no test edits, EXACTLY ONE assertion fails across all four suites. That is not
reassurance -- it is the problem. Three fixtures pass only because their tickers
sort alphabetically in the same order as their RS, so after the weights change
they stay green while no longer testing ranking at all. This patch:

  1. rewrites the rank fixture to pin the PRODUCTION DEFAULT ranking
  2. renames the sector-cap fixture so alphabetical != rank order
  3. varies vcp_score in the n_max fixture and asserts WHICH names survive
  4. adds test_frozen_defaults(): the parameters themselves, the 0.0 exposure
     ceiling, and which constraint actually binds when sizing

Anchors are asserted; edits are applied bottom-up within each file.

Usage:  python patch_phase2.py <repo-root>
"""
from __future__ import annotations

import os
import sys

FROZEN_TEST = '''def test_frozen_defaults():
    """The frozen parameter set itself (PARAMETER_FREEZE Rev 3 §1).

    Nothing else in any suite observes these four values -- measured: changing
    all of them breaks exactly one unrelated assertion. Without this test a
    silent revert to 0.0075 / 0.20 / STALL_DAY 10 / threshold 80 would ship
    green. These are backtest decisions; if one has to change here, the backtest
    changed first."""
    print("I8c frozen parameter set + the constraints it implies")
    from kistrader.core import engine_v2 as _E
    from kistrader.entry.screen_contract import VCP_SCORE_THRESHOLD

    cfg = DecisionConfig()
    check("threshold is 75", VCP_SCORE_THRESHOLD == 75, f"{VCP_SCORE_THRESHOLD}")
    check("ranking is vcp_only (0, 0, 1)",
          (cfg.rs_weight, cfg.stage2_weight, cfg.vcp_weight) == (0.0, 0.0, 1.0),
          f"{(cfg.rs_weight, cfg.stage2_weight, cfg.vcp_weight)}")
    check("risk_per_trade_pct is 0.85%", abs(cfg.risk_per_trade_pct - 0.0085) < 1e-12,
          f"{cfg.risk_per_trade_pct}")
    check("max_position_pct is 25%", abs(cfg.max_position_pct - 0.25) < 1e-12,
          f"{cfg.max_position_pct}")
    check("STALL_DAY is 252", _E.STALL_DAY == 252,
          f"{_E.STALL_DAY} -- if this is 5 or 6 you still have KIS_STALL_DAY set "
          f"from a soak run; that value must NEVER reach live")
    check("max_stop_pct unchanged at Minervini's 10% ceiling",
          abs(cfg.max_stop_pct - 0.10) < 1e-12, f"{cfg.max_stop_pct}")
    check("no breakeven trigger was ever built (measured dead)",
          not hasattr(cfg, "be_trigger_r"))

    # -- the exposure ceiling at 0.0 must BLOCK, not mean "disabled" ------------
    # Phase 3's regime gate writes 0.0 here on a RISK_OFF day. sector_cap uses 0
    # to mean "no cap", so this is worth pinning explicitly before anything
    # depends on it.
    acct = AccountState(equity=100_000, cash=100_000)
    off = DecisionEngine(DecisionConfig(max_portfolio_exposure_pct=0.0, sector_cap=0))
    plans, rej = off.plan([_cand("AAA"), _cand("BBB")], acct)
    check("exposure ceiling 0.0 arms NOTHING (0 != disabled)", plans == [],
          f"{[p.ticker for p in plans]}")
    check("and says why", bool(rej) and all("exposure ceiling" in r.reason for r in rej),
          f"{[r.reason for r in rej]}")

    # -- which constraint actually binds at the frozen values -------------------
    # risk 0.85% / cap 25% means the cap only binds when stop distance is under
    # 0.0085/0.25 = 3.4% of entry. Realised stops run 6.3-6.5%, ceiling 10%, so
    # sizing is RISK-limited in normal operation. The freeze doc calls this
    # "unclipped at the 25% cap"; this is that claim, executed.
    eng = DecisionEngine(DecisionConfig())
    entry, stop = 100.0, 93.5                       # 6.5% stop, the realised average
    shares = eng.size(entry, stop, 100_000.0)
    by_risk = int((100_000.0 * 0.0085) // (entry - stop))
    by_cap = int((100_000.0 * 0.25) // entry)
    check("sizing is RISK-limited at a realistic 6.5% stop", shares == by_risk < by_cap,
          f"shares={shares} risk={by_risk} cap={by_cap}")
    # ... and the cap still binds when the stop is unusually tight
    tight = eng.size(100.0, 98.0, 100_000.0)        # 2% stop -> inside 3.4%
    check("the 25% cap still binds on a very tight stop", tight == by_cap,
          f"{tight} vs cap {by_cap}")


'''


def edit(text, old, new, label):
    n = text.count(old)
    if n != 1:
        raise SystemExit(f"REFUSING: anchor for {label} matched {n} times, expected 1")
    print(f"  ok  {label}")
    return text.replace(old, new)


def read(p):
    with open(p, encoding="utf-8") as f:
        return f.read()


def write(p, s):
    with open(p, "w", encoding="utf-8", newline="") as f:
        f.write(s)


def main(root):
    sc = os.path.join(root, "kistrader", "entry", "screen_contract.py")
    de = os.path.join(root, "kistrader", "entry", "decision_engine.py")
    ev = os.path.join(root, "kistrader", "core", "engine_v2.py")
    th = os.path.join(root, "tests", "test_entry_half.py")
    for p in (sc, de, ev, th):
        if not os.path.isfile(p):
            raise SystemExit(f"REFUSING: not found: {p}")

    s_sc, s_de, s_ev, s_th = read(sc), read(de), read(ev), read(th)
    if "vcp_weight" not in s_de:
        raise SystemExit("REFUSING: Phase 1 has not been applied (no vcp_weight in "
                         "decision_engine.py).")
    if "test_rank_score" not in s_th:
        raise SystemExit("REFUSING: Phase 1's TEST half is missing (no test_rank_score in "
                         "test_entry_half.py). Phase 1 patches two files; both must land.")
    if "test_zz_all_checks_passed" not in s_th:
        raise SystemExit("REFUSING: D8 has not been applied (no terminal guard).")
    if "_load_vcp_threshold" not in read(os.path.join(root, "screeners", "sp500_v21.py")):
        raise SystemExit("REFUSING: D3a has not been applied.")
    if "KIS_STALL_DAY" in s_ev or "test_frozen_defaults" in s_th:
        raise SystemExit("REFUSING: Phase 2 appears to be applied already.")

    # ---------------- screen_contract.py ----------------
    print(f"screen_contract.py  ({sc})")
    s_sc = edit(s_sc, "VCP_SCORE_THRESHOLD = 80", "VCP_SCORE_THRESHOLD = 75",
                "threshold 80 -> 75")
    s_sc = edit(s_sc, "# 80 = 80% of the achievable max_score=104 scale.",
                "# 75, from the paired band analysis: names scoring 70-75 are +0.32 R each\n"
                "# in H1 and -0.35 R each in H2. 75 was the only positive threshold that was\n"
                "# cost-monotone in BOTH halves, with zero negative cells.",
                "threshold rationale")

    # ---------------- decision_engine.py (bottom-up) ----------------
    print(f"decision_engine.py  ({de})")
    s_de = edit(s_de, "    max_position_pct: float = 0.20      # single-name notional cap as frac of equity",
                "    max_position_pct: float = 0.25      # single-name notional cap as frac of equity\n"
                "                                        # (25 vs 30 differ by 0.033 R -- inside the\n"
                "                                        #  +/-0.19 R noise floor; the cap stops\n"
                "                                        #  binding above ~35%)",
                "max_position_pct 0.20 -> 0.25")
    s_de = edit(s_de, "    risk_per_trade_pct: float = 0.0075  # equal-R: risk 0.75% of equity per trade",
                "    risk_per_trade_pct: float = 0.0085  # equal-R: risk 0.85% of equity per trade\n"
                "                                        # (below Minervini's 1.25-2.5% band; raising\n"
                "                                        #  it to index parity scales max drawdown to\n"
                "                                        #  -51%..-64%. BACKTEST decision.)",
                "risk_per_trade_pct 0.0075 -> 0.0085")
    s_de = edit(s_de,
                "    rs_weight: float = 2.0            # score = rs_weight*RS% + stage2_weight*Stage2%\n"
                "    stage2_weight: float = 1.0\n",
                "    # RANKING = vcp_only. rank_mode never took effect before the Phase 1 fix:\n"
                "    # plan() re-sorts on rank_score, so a mode the score could not express was\n"
                "    # silently ignored and every historical sweep ranked on 2*RS.\n"
                "    # vcp_only won all four cost levels by 5.79-8.62 return-%.\n"
                "    rs_weight: float = 0.0            # score = rs_weight*RS% + stage2_weight*Stage2%\n"
                "    stage2_weight: float = 0.0        #         + vcp_weight*VCP%\n",
                "rank weights -> vcp_only")
    s_de = edit(s_de, "    vcp_weight: float = 0.0           # 0.0 preserves today's behaviour exactly.",
                "    vcp_weight: float = 1.0           # the ONLY active ranking term (vcp_only).",
                "vcp_weight 0.0 -> 1.0")

    # ---------------- engine_v2.py (bottom-up) ----------------
    print(f"engine_v2.py  ({ev})")
    s_ev = edit(s_ev, "\nSTALL_DAY = 10\n",
                "\n# STALL_DAY 252 (PARAMETER_FREEZE Rev 3): day-10 was cutting winners --\n"
                "# EMA_BREAK trades average 3.5R MFE against STALL_EXIT's 0.758R. At 252 no\n"
                "# trade reaches the gate, so there is no promotion to TRAILING, STALL_EXIT\n"
                "# never fires, and the EMA trail is reachable ONLY through the +3R partial.\n"
                "# See tests/test_exit_state_machine.py case D, which pins that.\n"
                "#\n"
                "# The env override exists so the soak can exercise the promotion path with a\n"
                "# short stall WITHOUT editing this verified-core file. It must never be set\n"
                "# on the live box: param_snapshot reads this attribute and exits 1 on any\n"
                "# value but 252.\n"
                "STALL_DAY = int(os.environ.get(\"KIS_STALL_DAY\", 252))\n",
                "STALL_DAY 10 -> 252 with a soak-only env override")
    s_ev = edit(s_ev, "import threading\n", "import os\nimport threading\n",
                "import os (needed by the STALL_DAY override)")

    # ---------------- test_entry_half.py (bottom-up) ----------------
    print(f"test_entry_half.py  ({th})")
    s_th = edit(s_th, "    test_rank_score()\n",
                "    test_rank_score()\n    test_frozen_defaults()\n",
                "register test_frozen_defaults in main()")
    s_th = edit(s_th, "def test_zz_all_checks_passed():",
                FROZEN_TEST + "def test_zz_all_checks_passed():",
                "insert test_frozen_defaults()")
    # test_rank_score's first two checks assert that the DEFAULT weights are the
    # pre-Phase-2 no-op. That was correct for Phase 1 and is wrong from here on.
    # Replaced with assertions about the FORMULA, which no parameter change can
    # invalidate; the production defaults are asserted in test_frozen_defaults().
    s_th = edit(s_th,
                "    # (1) the new third term is a true no-op until someone sets it\n"
                "    check(\"vcp_weight defaults to 0.0\", DecisionConfig().vcp_weight == 0.0,\n"
                "          f\"{DecisionConfig().vcp_weight}\")\n"
                "    eng_default = DecisionEngine(DecisionConfig())\n"
                "    old = lambda x: 2.0 * x.rs_rating + 1.0 * x.stage2_score\n"
                "    check(\"default weights reproduce 2*RS + Stage2 exactly\",\n"
                "          all(abs(eng_default.rank_score(x) - old(x)) < 1e-12 for x in (a, b, c)))\n",
                "    # (1) rank_score is EXACTLY the linear combination of the three configured\n"
                "    #     weights -- no hidden term, no formula baked into the call path. The\n"
                "    #     production DEFAULTS are asserted in test_frozen_defaults(); asserting\n"
                "    #     them here too would make this test need editing on every parameter\n"
                "    #     change, which is exactly what it must not do.\n"
                "    eng_sum = DecisionEngine(DecisionConfig(rs_weight=1.0, stage2_weight=1.0,\n"
                "                                           vcp_weight=1.0))\n"
                "    check(\"rank_score == rs*w1 + stage2*w2 + vcp*w3, no hidden terms\",\n"
                "          all(abs(eng_sum.rank_score(x)\n"
                "                  - (x.rs_rating + x.stage2_score + x.vcp_score)) < 1e-12\n"
                "              for x in (a, b, c)))\n"
                "    eng_zero = DecisionEngine(DecisionConfig(rs_weight=0.0, stage2_weight=0.0,\n"
                "                                            vcp_weight=0.0))\n"
                "    check(\"all-zero weights collapse every score to 0\",\n"
                "          all(eng_zero.rank_score(x) == 0.0 for x in (a, b, c)))\n",
                "test_rank_score: assert the FORMULA, not the current defaults")

    s_th = edit(s_th,
                '    cs = [_cand("S1A", rs=95), _cand("S1B", rs=90), _cand("S1C", rs=85)]\n',
                '    cs = [_cand("ZED", rs=95, score=95.0), _cand("ABE", rs=90, score=80.0),\n'
                '          _cand("MID", rs=85, score=88.0)]\n',
                "sector-cap fixture: rank order is no longer alphabetical")
    s_th = edit(s_th,
                '    check("sector cap: 1 tech + energy", picked == {"S1A", "S1C"},\n',
                '    check("sector cap: the HIGHER-RANKED tech name takes the slot",\n'
                '          picked == {"ZED", "MID"},\n',
                "sector-cap fixture: update the assertion to the renamed tickers")
    s_th = edit(s_th,
                '    sect = {"S1A": "tech", "S1B": "tech", "S1C": "energy"}\n',
                '    # D7: renamed so ticker-ascending != rank-descending. With S1A/S1B/S1C the\n'
                '    # two coincided, so this test passed under ANY ranking -- including none.\n'
                '    sect = {"ZED": "tech", "ABE": "tech", "MID": "energy"}\n',
                "sector-cap fixture: rename the tickers")
    s_th = edit(s_th,
                '    cs = [_cand(f"T{i}", rs=90 - i) for i in range(5)]\n',
                '    # D7: vcp_score ascends while the ticker ascends, so the top-ranked names\n'
                '    # (T4, T3) are the LAST alphabetically -- a count-only assertion cannot\n'
                '    # tell a working ranking from a broken one.\n'
                '    cs = [_cand(f"T{i}", rs=90 - i, score=70.0 + i) for i in range(5)]\n',
                "n_max fixture: vary vcp_score")
    s_th = edit(s_th,
                '    # rank order: 2*RS + S2\n'
                '    a = _cand("AAA", rs=80, s2=90)   # 250\n'
                '    b = _cand("BBB", rs=95, s2=70)   # 260\n'
                '    plans, _ = eng.plan([a, b], acct)\n'
                '    check("rank: 2RS+S2 orders BBB before AAA", [x.ticker for x in plans] == ["BBB", "AAA"])\n',
                '    # Rank order under the PRODUCTION DEFAULT weights. Both weightings are\n'
                '    # covered exhaustively in test_rank_score(); this pins that plan() uses the\n'
                '    # CONFIGURED default rather than a formula baked into the call path -- the\n'
                '    # exact failure that made rank_mode a no-op for the whole project.\n'
                '    # AAA wins on RS+Stage2, BBB wins on VCP, so the two weightings disagree.\n'
                '    a = _cand("AAA", rs=95, s2=90, score=72.0)   # 2RS+S2 = 280, vcp 72\n'
                '    b = _cand("BBB", rs=80, s2=70, score=91.0)   # 2RS+S2 = 230, vcp 91\n'
                '    plans, _ = eng.plan([a, b], acct)\n'
                '    check("rank: production default (vcp_only) puts BBB before AAA",\n'
                '          [x.ticker for x in plans] == ["BBB", "AAA"], f"{[x.ticker for x in plans]}")\n',
                "rank fixture: assert the production default ranking")

    write(sc, s_sc); write(de, s_de); write(ev, s_ev); write(th, s_th)
    print("\nPHASE 2 APPLIED. Run the suites, then:")
    print("    python -m kistrader.tools.param_snapshot")
    print("Expect only regime_ma outstanding (that is Phase 3).")
    return 0


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("usage: python patch_phase2.py <repo-root>")
    sys.exit(main(sys.argv[1]))
