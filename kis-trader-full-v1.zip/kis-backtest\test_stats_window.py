"""Known-answer test for the stats window. CAGR must match hand arithmetic."""
import numpy as np, pandas as pd
from minervini_backtest import BTCandidate, BacktestConfig, run

FAILS = []


def check(name, fn):
    try:
        fn(); print(f"  OK    {name}")
    except AssertionError as e:
        FAILS.append((name, str(e))); print(f"  FAIL  {name}: {e}")
    except Exception as e:
        FAILS.append((name, f"{type(e).__name__}: {e}")); print(f"  CRASH {name}: {e}")


def build(bar_start, n_bars, signal_idx, seed=3):
    D = pd.bdate_range(bar_start, periods=n_bars)
    r = np.random.default_rng(seed)
    c = 50 * np.cumprod(1 + r.normal(0.0005, 0.015, len(D)))
    o = np.r_[c[0], c[:-1]]
    P = {"A": pd.DataFrame({"Open": o, "High": np.maximum(o, c) * 1.01,
                            "Low": np.minimum(o, c) * 0.99, "Close": c}, index=D)}
    px = float(P["A"]["Close"].iloc[signal_idx])
    S = {D[signal_idx]: [BTCandidate(
        ticker="A", exchange="NAS", pivot=px, contraction_low=px * 0.95,
        atr=px * 0.02, last_close=px * 0.99, rs_rating=90, vcp_score=85.0,
        session_date=str(D[signal_idx].date()))]}
    return D, P, S


def cfg():
    return BacktestConfig(rank_mode="rs_only", sector_map={"A": "Tech"})


# ---------- 1. the stats window is the ACTIVE window, not the bar calendar ----
def t_window_is_active():
    D, P, S = build("2000-01-03", 6800, 5200)
    eq, tr, st, dr, dg = run(P, S, cfg())
    bar_years = (D[-1] - D[0]).days / 365.25
    assert bar_years > 25, bar_years
    assert dg["stats_window_years"] < 8, dg["stats_window_years"]
    assert eq.index[0] >= D[5200 - 1], (eq.index[0], D[5200])


# ---------- 2. CAGR matches hand arithmetic on the ACTIVE span ---------------
def t_cagr_matches_hand_calc():
    D, P, S = build("2000-01-03", 6800, 5200)
    eq, tr, st, dr, dg = run(P, S, cfg())
    if not isinstance(st["cagr_pct"], (int, float)):
        return                                   # sub-6mo guard fired; nothing to check
    yrs = (eq.index[-1] - eq.index[0]).days / 365.25
    hand = ((eq.iloc[-1] / eq.iloc[0]) ** (1 / yrs) - 1) * 100
    assert abs(st["cagr_pct"] - hand) < 0.01, (st["cagr_pct"], hand)
    # and it must NOT match the diluted version computed over the bar calendar
    bad_yrs = (D[-1] - D[0]).days / 365.25
    bad = ((eq.iloc[-1] / eq.iloc[0]) ** (1 / bad_yrs) - 1) * 100
    assert abs(st["cagr_pct"] - bad) > 1e-6, "CAGR still using the bar calendar"


# ---------- 3. total_return and drawdown are NOT affected by the prefix ------
def t_prefix_does_not_move_return():
    """Same signal, same price path, different amounts of dead calendar in front.
    total_return and max_drawdown must be identical; CAGR must differ."""
    Da, Pa, Sa = build("2000-01-03", 6800, 5200)
    # rebuild with the SAME tail but less leading history
    tail_start = Da[5200 - 600]
    Pb = {"A": Pa["A"].loc[tail_start:]}
    Sb = Sa
    a = run(Pa, Sa, cfg())[2]
    b = run(Pb, Sb, cfg())[2]
    assert a["total_return_pct"] == b["total_return_pct"], \
        (a["total_return_pct"], b["total_return_pct"])
    assert a["max_drawdown_pct"] == b["max_drawdown_pct"], \
        (a["max_drawdown_pct"], b["max_drawdown_pct"])


# ---------- 4. equity curve returned is the trimmed one ---------------------
def t_returned_curve_is_trimmed():
    D, P, S = build("2000-01-03", 6800, 5200)
    eq, tr, st, dr, dg = run(P, S, cfg())
    assert len(eq) < len(D), (len(eq), len(D))
    assert str(eq.index[0].date()) in dg["stats_window"], dg["stats_window"]
    assert str(eq.index[-1].date()) in dg["stats_window"], dg["stats_window"]


# ---------- 5. no signals -> no crash --------------------------------------
def t_no_signals():
    D, P, S = build("2020-01-02", 800, 400)
    eq, tr, st, dr, dg = run(P, {}, cfg())
    assert st["num_trades"] == 0
    assert dg["stats_window"] in ("empty",) or dg["stats_window_years"] >= 0


if __name__ == "__main__":
    for n, f in [("stats window is the active window", t_window_is_active),
                 ("CAGR matches hand arithmetic", t_cagr_matches_hand_calc),
                 ("dead prefix does not move return/drawdown", t_prefix_does_not_move_return),
                 ("returned equity curve is trimmed", t_returned_curve_is_trimmed),
                 ("no signals does not crash", t_no_signals)]:
        check(n, f)
    print()
    print("STATS WINDOW CHECK CLEAN" if not FAILS else f"{len(FAILS)} PROBLEM(S): {FAILS}")
