#!/usr/bin/env bash
set -euo pipefail
cd /home/kis/kis-trader
D=$(TZ=America/New_York date +%F)
echo "=== run_screeners session_date=$D (UTC $(date -u +%FT%TZ)) ==="
./.venv/bin/python -m screeners.sp500_v21    --emit-candidates --session-date "$D"
./.venv/bin/python -m screeners.us_small_v21 --emit-candidates --session-date "$D"
echo "=== run_screeners done ==="
