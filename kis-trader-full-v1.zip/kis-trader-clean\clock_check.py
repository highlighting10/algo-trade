#!/usr/bin/env python3
"""clock_check.py — headless session-clock validation (Step 6 item #4).
Run ON THE CLOUD BOX and compare the output against a world clock + the NYSE.
The session clock is self-contained (federal DST rule + hardcoded 2026
holidays); a box with a bad system clock or TZ config is exactly the failure
this catches before money does. The OUTPUT is the test."""
from datetime import datetime, timezone
from kistrader.core.run_loop import USSessionClock, HOLIDAYS_2026

clk = USSessionClock()
u = datetime.now(timezone.utc)
et = clk.now_et()                      # aware; wall-time shifted to US/Eastern
off = (et - u).total_seconds() / 3600
print(f"system UTC      : {u.strftime('%Y-%m-%d %H:%M:%S')}")
print(f"computed ET     : {et.strftime('%Y-%m-%d %H:%M:%S')}  (UTC{off:+.0f}h; expect -4 EDT / -5 EST)")
print(f"session_date    : {clk.session_date()}")
print(f"is_trading_day  : {clk.is_trading_day()}")
print(f"phase           : {clk.phase()}   (OPEN == 09:30-16:00 ET on trading days)")
print(f"holidays loaded : {len(HOLIDAYS_2026)} (2026)")
print("CHECK by hand: ET matches a world clock; phase matches the NYSE right now.")
