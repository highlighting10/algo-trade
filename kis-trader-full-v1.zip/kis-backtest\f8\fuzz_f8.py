#!/usr/bin/env python3
"""
F8 -- randomised differential sweep.

WHY THIS EXISTS. `run_f8.py` compares fourteen HAND-PICKED cases, and the same
person chose the cases and derived the expected answers. That is exactly the
shape of evidence that looks conclusive and is not: it can only find defects on
paths someone thought to write down. Case 2b -- the entry bar that gaps below
the stop -- was missed by all fourteen, and it was a 0.5R error.

This generates thousands of random bar sequences instead, runs BOTH engines over
each, and reports every disagreement. It cannot prove the engines identical, but
it converts "agrees on the cases I imagined" into "agrees on N thousand paths I
did not".

WHAT IS RANDOMISED
  * bar count, and the OHLC of every bar (coherent by construction)
  * gaps, including gaps through the stop and through breakeven
  * whether the ENTRY bar pierces the stop
  * share count -- including 31, 32, 100 where int/round/exact scale-outs differ
  * stall_day -- 2, 3, 4, 5 and the frozen 252
  * the EMA series, drawn to straddle the closes so the trail actually fires
  * exact boundary touches (low == stop, high == +3R, close == EMA)

WHAT IS HELD FIXED, and why
  entry 100 / stop 90 / risk 10, because the harness's entry must be driven
  through the real decision_engine and that geometry is what it reproduces
  exactly (harness_side asserts it every run). Randomising the entry would
  randomise decision_engine's rounding, not the exit logic.

    python fuzz_f8.py --prod-root ... --harness ... --trials 3000
"""
from __future__ import annotations

import argparse
import os
import random
import sys
from collections import Counter

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from engine_side import Bar, EngineExitRunner, load_production   # noqa: E402
import cases as C                                                # noqa: E402

ENTRY, STOP = C.ENTRY, C.STOP
RISK = ENTRY - STOP
PARTIAL_LEVEL = ENTRY + 3.0 * RISK          # 130.0
SHARE_CHOICES = [3, 7, 30, 31, 32, 100]
STALL_CHOICES = [2, 3, 4, 5, 252]

# Levels worth landing on EXACTLY -- boundary conditions are where `<` vs `<=`
# disagreements live, and a uniform random draw essentially never hits them.
MAGNETS = [STOP, ENTRY, PARTIAL_LEVEL, ENTRY + RISK]

# Disagreement classes already characterised and pinned by cases 10 and 11.
# Anything OUTSIDE this set is a new finding and fails the run.
KNOWN_CLASSES = {
    "R only: partial filled off the +3R level (gap-up partial)",
    "exit price differs",
}


class Scenario:
    """Minimal stand-in for cases.Case, so both sides can consume it unchanged."""
    def __init__(self, key, bars, emas, stall_day, shares):
        self.key = key
        self.bars = bars
        self.emas = emas
        self.stall_day = stall_day
        self.shares = shares
        self.tick_path = None
        self.title = "fuzz"
        self.note = ""
        self.core_eight = False
        self.expect_reason = self.expect_bar = self.expect_price = self.expect_r = None


def _coherent(rng, ref):
    """A random bar around `ref`, occasionally snapped onto a decision level."""
    span = ref * rng.uniform(0.01, 0.16)
    a = ref + rng.uniform(-span, span)
    b = ref + rng.uniform(-span, span)
    lo, hi = min(a, b), max(a, b)
    if rng.random() < 0.30:                      # pull a boundary onto a magnet
        m = rng.choice(MAGNETS)
        if rng.random() < 0.5:
            lo = m
        else:
            hi = m
        lo, hi = min(lo, hi), max(lo, hi)
    if hi - lo < 0.01:
        hi = lo + 0.01
    o = rng.uniform(lo, hi)
    c = rng.uniform(lo, hi)
    if rng.random() < 0.15:                      # gap open to an extreme
        o = lo if rng.random() < 0.5 else hi
    return round(o, 2), round(hi, 2), round(lo, 2), round(c, 2)


def make_scenario(rng, i):
    n = rng.randint(2, 12)
    bars = []

    # ---- bar 0: the ENTRY bar. The harness only fills when open <= limit(100)
    # and high >= pivot(99.5025), so those two are constrained; everything else,
    # including a low far below the stop, is free.
    o0 = round(rng.uniform(80.0, 100.0), 2)
    h0 = round(max(99.51, o0, rng.uniform(99.51, 135.0)), 2)
    l0 = round(min(o0, rng.uniform(80.0, 100.0)), 2)
    c0 = round(rng.uniform(l0, h0), 2)
    bars.append(Bar("d0", o0, h0, l0, c0))

    ref = c0
    for j in range(1, n):
        o, h, l, c = _coherent(rng, ref)
        bars.append(Bar(f"d{j}", o, h, l, c))
        ref = c

    # EMA drawn to straddle the closes, so the trail fires roughly half the time
    if rng.random() < 0.15:
        emas = None
    else:
        emas = [round(b.close * rng.uniform(0.90, 1.10), 2) for b in bars]
        if rng.random() < 0.25:                  # exact close == ema touches
            k = rng.randrange(len(bars))
            emas[k] = bars[k].close

    return Scenario(f"F{i}", bars, emas,
                    rng.choice(STALL_CHOICES), rng.choice(SHARE_CHOICES))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--prod-root", required=True)
    ap.add_argument("--harness", required=True)
    ap.add_argument("--trials", type=int, default=2000)
    ap.add_argument("--seed", type=int, default=20260822)
    ap.add_argument("--tick-path", default="worst")
    ap.add_argument("--show", type=int, default=12, help="max disagreements to print")
    args = ap.parse_args()

    from harness_side import load_harness_adapter

    E, _P = load_production(args.prod_root)
    harness = load_harness_adapter(args.harness, args.prod_root)
    rng = random.Random(args.seed)

    print("=" * 78)
    print("F8 RANDOMISED DIFFERENTIAL SWEEP")
    print("=" * 78)
    print(f"  engine_v2 : {E.__f8_loaded_from__}")
    print(f"  harness   : {args.harness}")
    print(f"  trials {args.trials}   seed {args.seed}   tick_path {args.tick_path}")
    print("=" * 78)

    agree = 0
    disagreements = []
    errors = Counter()
    reasons = Counter()
    exercised = Counter()
    classes = Counter()

    for i in range(args.trials):
        sc = make_scenario(rng, i)
        try:
            t = EngineExitRunner(E, stall_day=sc.stall_day,
                                 tick_path=args.tick_path).run(
                sc.bars, entry_price=ENTRY, stop_price=STOP,
                shares=sc.shares, emas=sc.emas)
        except Exception as ex:
            errors[f"engine {type(ex).__name__}"] += 1
            continue
        try:
            h = harness.run(sc)
        except Exception as ex:
            errors[f"harness {type(ex).__name__}: {str(ex)[:60]}"] += 1
            continue

        reasons[(str(t.exit_reason), str(h.exit_reason))] += 1
        if t.exit_reason:
            exercised[t.exit_reason] += 1
        else:
            exercised["(still open)"] += 1
        if any(l[3] == "PARTIAL" for l in t.legs):
            exercised["+3R partial taken"] += 1

        same_key = t.key() == h.key()
        same_px = ((t.exit_price is None and h.exit_price is None)
                   or (t.exit_price is not None and h.exit_price is not None
                       and abs(t.exit_price - h.exit_price) <= 1e-4))
        same_r = ((t.r_multiple is None) == (h.r_multiple is None)
                  and (t.r_multiple is None
                       or abs(t.r_multiple - h.r_multiple) <= 1e-3))
        if same_key and same_px and same_r:
            agree += 1
        else:
            # classify, so thousands of trials do not need eyeballing
            if not same_key:
                cls = "DECISION LAYER (reason or bar differs)"
            elif not same_px:
                cls = "exit price differs"
            else:
                gapped = [l for l in t.legs
                          if l[3] == "PARTIAL" and abs(l[2] - PARTIAL_LEVEL) > 1e-6]
                cls = ("R only: partial filled off the +3R level (gap-up partial)"
                       if gapped else "R only: other")
            classes[cls] += 1
            disagreements.append((sc, t, h, same_key, same_px, same_r, cls))

    total = agree + len(disagreements)
    print(f"\n  compared {total} scenarios "
          f"({sum(errors.values())} skipped -- see below)")
    print(f"  AGREE      {agree}")
    print(f"  DISAGREE   {len(disagreements)}")

    print("\n  paths actually exercised (engine side):")
    for k, v in exercised.most_common():
        print(f"    {k:<18} {v}")

    if errors:
        print("\n  skipped scenarios:")
        for k, v in errors.most_common(8):
            print(f"    {v:>5}  {k}")

    if disagreements:
        print("\n" + "=" * 78)
        print(f"  DISAGREEMENTS (showing up to {args.show})")
        print("=" * 78)
        print("\n  BY CLASS:")
        for k, v in classes.most_common():
            print(f"    {v:>6}  {k}")
        print()
        seen_cls = set()
        shown = [d for d in disagreements
                 if not (d[6] in seen_cls or seen_cls.add(d[6]))][:args.show]
        for sc, t, h, sk, sp, sr, cls in shown:
            which = ",".join(x for x, ok in
                             (("key", sk), ("price", sp), ("R", sr)) if not ok)
            print(f"  --- class: {cls} ---")
            print(f"\n  [{sc.key}] stall_day={sc.stall_day} shares={sc.shares}  "
                  f"differs on: {which}")
            for j, b in enumerate(sc.bars):
                e = "-" if sc.emas is None else sc.emas[j]
                print(f"      bar{j}  O{b.open:8.2f} H{b.high:8.2f} "
                      f"L{b.low:8.2f} C{b.close:8.2f}   ema {e}")
            print(f"      engine_v2 -> {t.exit_reason} bar={t.exit_bar} "
                  f"px={t.exit_price} R={t.r_multiple}  legs={t.legs}")
            print(f"      harness   -> {h.exit_reason} bar={h.exit_bar} "
                  f"px={h.exit_price} R={h.r_multiple}")
        print("\n" + "=" * 78)
        unknown = {k: v for k, v in classes.items() if k not in KNOWN_CLASSES}
        print(f"\n  {len(disagreements)} disagreement(s).")
        if unknown:
            print("  UNKNOWN CLASSES PRESENT -- triage before concluding:")
            for k, v in unknown.items():
                print(f"    {v:>6}  {k}")
            print("=" * 78)
            return 1
        print("  All fall into CHARACTERISED classes (cases 10 and 11 pin them).")
        print("  No unknown divergence.")
        print("=" * 78)
        return 0

    print("\n" + "=" * 78)
    print(f"  NO DISAGREEMENTS across {total} random scenarios.")
    print("=" * 78)
    return 0


if __name__ == "__main__":
    sys.exit(main())
