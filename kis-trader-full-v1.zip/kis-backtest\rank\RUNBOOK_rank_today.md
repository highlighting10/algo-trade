# RUNBOOK — finish the rank work today

**2026-08-22.** Three changes, each its own commit. Every one is
behaviour-preserving or additive; none changes what the simulation computes.
Total hands-on time is under an hour, most of it reading output.

Everything below runs from `C:\Users\user\PyCharmMiscProject\kis-backtest`.

---

## Before you start

```powershell
cd C:\Users\user\PyCharmMiscProject\kis-backtest
git status --short          # must be clean; baseline is c8900f5
```

Unzip this kit over `rank\`, then **move `harness_snapshot.py` to the repo
ROOT**, beside `minervini_backtest.py`:

```powershell
Move-Item rank\harness_snapshot.py . -Force
```

That location is not cosmetic. `scripts\06_sweep.py` line 3 does
`sys.path.insert(0, <repo root>)`, so a root-level module imports cleanly from
any working directory. A copy left in `rank\` would not be importable from the
sweep.

---

## STEP 1 — the guard, standalone

```powershell
$env:PYTHONPATH = (Get-Location).Path
python harness_snapshot.py --require-explicit-sizing --risk-pct 0.0085 --max-position-pct 0.25
"exit = $LASTEXITCODE"
Remove-Item Env:PYTHONPATH
```

**Expect exit 0**, `profile: vendored-2weight`, `sha256 ... (matches pin)`, and
all three modes `[ OK ]`.

If the sha does NOT match the pin, stop. It means the vendored
`decision_engine.py` has changed since 2026-08-22. That may be fine — but it has
to be a deliberate, explained change, and `EXPECTED_ENGINE_SHA` gets re-pinned in
the same commit as whatever caused it.

Then prove the guard can fail, because a guard that has never failed is not
known to work:

```powershell
$env:PYTHONPATH = (Get-Location).Path
python harness_snapshot.py --require-explicit-sizing      # no sizing flags
"exit = $LASTEXITCODE"                                    # must be 1
Remove-Item Env:PYTHONPATH
```

```powershell
git add harness_snapshot.py rank\
git commit -m "harness_snapshot: pin the decision_engine and prove the rank modes"
```

---

## STEP 2 — wire it into the sweep

```powershell
python rank\patch_2_sweep_guard.py --file scripts\06_sweep.py
```

Then show it works in both directions:

```powershell
python scripts\06_sweep.py --param threshold
# must EXIT 2 with "[sweep] REFUSING TO RUN: engine defaults are risk=0.0075 ..."

python scripts\06_sweep.py --param threshold --risk-pct 0.0085 --max-position-pct 0.25
# must print  [sweep] [harness] engine=... profile=vendored-2weight ... modes=OK
# and then proceed as normal
```

The second one starts a real sweep — Ctrl-C once you have seen the stamp.

```powershell
git add scripts\06_sweep.py
git commit -m "06_sweep: refuse to run unstamped (harness snapshot guard)"
```

**This is the change that closes the live problem.** Until now a bare
`06_sweep.py` silently used `risk 0.0075 / cap 0.20`.

---

## STEP 3 — the share-weighted expectancy

```powershell
python rank\patch_1_weighted_expectancy.py --file minervini_backtest.py
$env:PYTHONPATH = (Get-Location).Path
python rank\verify_patches.py --file minervini_backtest.py
"exit = $LASTEXITCODE"
Remove-Item Env:PYTHONPATH
```

**Expect 12/12.** The verifier reconstructs the pre-patch original in memory by
reversing the edits, so it compares against what is actually on disk rather than
a copy someone remembered to keep. It asserts all 21 pre-existing summary keys
are identical — including `expectancy_R`, which `06_sweep.py`'s FALLACY-4 test
depends on being position-size invariant.

The demonstration to look at:

```
partialled:  expectancy_R = 0.0    expectancy_R_weighted = 1.0
```

A trade that sold a third at +3R and the runner at breakeven earns a full R and
books zero.

```powershell
git add minervini_backtest.py
git commit -m "add expectancy_R_weighted alongside expectancy_R (partial leg included)"
```

---

## STEP 4 — confirm nothing else moved

```powershell
cd f8
$env:PYTHONPATH = ""
python run_f8.py --prod-root C:\Users\user\kis-trader-clean --harness ..\minervini_backtest.py
python fuzz_f8.py --prod-root C:\Users\user\kis-trader-clean --harness ..\minervini_backtest.py --trials 12000
"exit = $LASTEXITCODE"
cd ..
```

**Expect 98/98 and exit 0.** Patch 1 touches `Trade`, `BTPosition` and
`_summarize` — all downstream of the exit decision — so F8 must be unmoved. If
the sweep goes red, patch 1 did something it was not supposed to and the revert
is one command:

```powershell
python rank\patch_1_weighted_expectancy.py --file minervini_backtest.py --revert
```

Both patches revert byte-identically; that is tested, not hoped.

---

## What this closes, and what it does not

**Closed.** The sizing footgun is now impossible to hit silently. The latent
rank trap cannot spring without the run stopping. The engine file is pinned by
sha. And the R statistic that Step 5 exists to produce now has a correctly
weighted companion.

**Not closed, deliberately.** The three-weight migration (roadmap Phase 3) is
still undone — and with the guard in place it is no longer urgent. The vendored
2-weight scheme is correct today; the guard is what makes that fact durable.

**Still open, unrelated to rank.** `FREEZE_REV3_CORRECTIONS` sec.3 describes a
fill rule that does not exist in this file — resolve before spending the ~3
hours it budgets. And whether Rev 3's published `+0.330R` should be restated
using `expectancy_R_weighted` is a data decision, not a code one: run a sweep
and compare the two columns before deciding.

---

## The one thing to carry forward

Every sweep now prints a line like:

```
[harness] engine=entry/decision_engine.py sha=8656b5dc6d45 profile=vendored-2weight
          defaults(rs=2.0,s2=1.0,vcp=none) risk=0.0085 cap=0.25 modes=OK
```

**Paste it beside any number you quote.** Rev 1 quoted a threshold-70 figure
against a threshold-75 set and it took months to catch. That line is the fix for
that class of error, and it costs nothing.
