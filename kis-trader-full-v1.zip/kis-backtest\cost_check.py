import numpy as np, pandas as pd
from minervini_backtest import (BTCandidate, BacktestConfig, run,
                                survivorship_adjustment)

DATES = pd.bdate_range("2024-01-02", periods=60)

def ohlc(dates, closes):
    c = np.asarray(closes, float); o = np.r_[c[0], c[:-1]]
    return pd.DataFrame({"Open": o, "High": np.maximum(o, c)*1.01,
                         "Low": np.minimum(o, c)*0.99, "Close": c}, index=dates)

def cand(t, price=100.0):
    return BTCandidate(ticker=t, exchange="NAS", pivot=price,
                       contraction_low=price*0.95, atr=price*0.02,
                       last_close=price*0.99, rs_rating=90, vcp_score=85.0,
                       session_date="2024-01-02")

# ---- headline: what the researched costs do to one round trip ----
for px, label in ((100.0, "$100 large-cap"), (10.0, "$10 small-cap")):
    notional = 12_500.0
    shares = int(notional / px)
    buy = notional * 0.0025
    sell = notional * (0.0025 + 0.0000206) + min(shares * 0.000195, 9.79)
    rt = buy + sell
    print(f"{label:16} shares={shares:6}  round-trip=${rt:7.2f} "
          f"= {rt/notional*1e4:6.2f} bps  = {rt/750:.3f}R (on a $750 risk unit)")

# ---- with slippage at the top of a sweep ----
for slip in (0, 5, 15, 30):
    notional = 12_500.0
    rt = notional * (0.0050 + 0.0000206) + 2.44 + notional * 2 * slip / 1e4
    print(f"slippage {slip:2} bps/side -> round-trip {rt/notional*1e4:6.2f} bps "
          f"= {rt/750:.3f}R per trade")

# ---- live run with real costs ----
c = np.r_[99, 101, np.linspace(102, 150, 58)]
prices = {"A": ohlc(DATES, c)}
cfg = BacktestConfig(rank_mode="rs_only", sector_map={"A": "Tech"}, slippage_bps=5)
eq, tr, st, dr, dg = run(prices, {DATES[0]: [cand("A")]}, cfg)
print("\nrun with researched costs:", {k: st[k] for k in
      ("num_trades", "total_return_pct", "expectancy_R", "exit_reasons")})

# ---- survivorship sizing, both universes ----
print("\nsurvivorship drag (order of magnitude):")
for uni, rate in (("sp500 (NYSE/AMEX base rate)", 0.012),
                  ("us_small (Nasdaq base rate)", 0.056)):
    for catches in (0.9, 0.7):
        a = survivorship_adjustment(tr, delist_rate_per_year=rate,
                                    stop_catches_frac=catches)
        print(f"  {uni:30} stop_catches={catches:.0%}  "
              f"drag/trade={a['expected_drag_per_trade_pct_equity']:.4f}% equity")
