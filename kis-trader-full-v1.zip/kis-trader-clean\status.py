#!/usr/bin/env python3
"""
status.py — what does the ENGINE think it manages, vs what does the ACCOUNT hold?
=================================================================================

READ-ONLY. Places no orders, writes no state, never mutates the DB. Safe to run
any time, including with a loop running.

    python status.py          # DB snapshots only — free, no token, no network
    python status.py --live   # + broker holdings + drift report (ONE token issuance)

The drift report is the "confirm, never infer" check that matters after any crash,
Ctrl+C, or late-fill episode:

    ORPHAN  — the account holds shares NO snapshot manages. Unprotected: no stop
              is being enforced on it. This is the dangerous direction.
    GHOST   — a snapshot claims a holding the account does not have. The engine
              would act on a position that isn't there.

Note: --live uses one token. KIS allows one issuance per minute (EGW00133), so
wait >=65s after any other command that talks to KIS.
"""
from __future__ import annotations

import argparse
import sys

from kistrader.config import Config, load_dotenv
from kistrader.core.engine_v2 import EventStore


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--live", action="store_true",
                    help="also read broker holdings and report drift (uses one token)")
    args = ap.parse_args()

    load_dotenv()
    c = Config.from_env()
    print(f"[status] db={c.db_path}  mock={c.is_mock}  candidates={c.candidates_path}")

    db = EventStore(c.db_path)
    snaps = db.load_open_snapshots()

    print(f"\n[status] engine snapshots (non-terminal): {len(snaps)}")
    if not snaps:
        print("  (none — the engine is managing nothing)")
    else:
        print(f"  {'ticker':<8}{'state':<16}{'shares':>8}{'entry':>10}{'stop':>10}"
              f"{'R/sh':>9}  order_key")
        for p in sorted(snaps, key=lambda x: x.ticker):
            rps = getattr(p, "initial_risk_per_share", 0.0) or 0.0
            print(f"  {p.ticker:<8}{p.state.value:<16}{p.shares:>8}"
                  f"{p.entry_price:>10.2f}{p.stop_loss_price:>10.2f}{rps:>9.2f}  {p.order_key}")

    if not args.live:
        print("\n[status] account not queried (--live to compare against real holdings).")
        return 0

    # ---- truth side -------------------------------------------------------------
    from kistrader.entry.entry_manager import KISBrokerWithEntry
    broker = KISBrokerWithEntry(c.app_key, c.app_secret, c.cano,
                                acnt_prdt_cd=c.acnt_prdt_cd, is_mock=c.is_mock)
    try:
        truth = broker.get_all_holdings()
    except Exception as e:
        print(f"\n[status] broker read FAILED ({type(e).__name__}: {e})")
        print("[status] cannot compare. If EGW00133: wait 60s and retry.")
        return 2

    if truth is None:
        print("\n[status] broker returned UNKNOWN (None) — holdings unreadable. "
              "No drift conclusion is possible; do NOT assume flat.")
        return 2

    if isinstance(truth, dict):
        held = {str(k).upper(): v for k, v in truth.items()}
    else:
        held = {str(t).upper(): "?" for t in truth}

    print(f"\n[status] account holdings: {len(held)}")
    for t in sorted(held):
        print(f"  {t:<8} qty={held[t]}")

    managed = {p.ticker.upper() for p in snaps}
    orphans = sorted(set(held) - managed)
    ghosts = sorted(managed - set(held))

    print("\n[status] drift:")
    if not orphans and not ghosts:
        print("  CLEAN — every holding has a snapshot and vice versa.")
    for t in orphans:
        print(f"  ORPHAN  {t}: account holds it, NO snapshot manages it -> unprotected, "
              f"no stop enforced. Start the loop so recovery/orphan_resolver can adopt it.")
    for t in ghosts:
        print(f"  GHOST   {t}: snapshot claims it, account does NOT hold it. "
              f"(A PENDING_ENTRY that never filled is normal and expected here.)")
    print("\n[status] read-only; nothing was changed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
