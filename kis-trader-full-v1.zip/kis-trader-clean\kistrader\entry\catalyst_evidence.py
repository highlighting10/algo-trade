#!/usr/bin/env python3
"""
S8 / P1.7 -- the catalyst evidence test.  PURE.  NOTHING IS WIRED TO IT YET.
============================================================================

`PLAN_20260828` sec.4 Phase D item 7:

    S8 -- the one schema bump.  ... **Design the evidence test first** --
    `bool(evidence)` is not a test.  Needs an allow-list of catalyst categories
    or an explicit gap sentinel.

THE HOLE THIS CLOSES, verified

The plan's discard list records `catalyst.gate` as *"verified to pass
'unfamiliar -- needs live lookup', i.e. a `[KNOWLEDGE_GAP]` string laundered
into 'catalyst confirmed'."*  A truthful admission of ignorance was being
counted as a catalyst.  That is worse than a wrong score: it is a wrong score
wearing a confidence it explicitly disclaimed.

`MINERVINI_FIDELITY_20260826` sec.3 is the other half of why this matters.
Gemini's qualitative read stands in for SEPA's fundamental catalyst layer and is
**un-backtestable** -- look-ahead is baked in at the model level, so no sweep can
ever validate it.  A layer that cannot be measured has to be constrained at the
input instead, which is what this is.

THE DESIGN, and why BOTH halves

Allow-list alone: a model that invents a plausible-sounding category passes.
Sentinel alone: a confident, unhedged, entirely unsupported claim passes.
Together they are strictly stronger than either, so both are applied.

    catalyst_evidence := <token>[;<token>...] ["|" <free note>]

  * every token must be in CATEGORIES.  An unknown token is REJECTED and named
    -- not dropped, because silently dropping is how the original hole worked.
  * at least one token is required.  Empty, blank, or note-only is REJECTED.
  * a gap sentinel ANYWHERE -- including inside the free note -- REJECTS.
  * the note is free text and carries no weight.  It is for a human reading the
    CSV, never for the gate.

Deliberately NOT a free-text scan for category words.  Scanning prose for
"earnings" is the same laundering with an extra step: the model writes the word,
the scanner finds it, and nothing was ever verified.  The screener must emit
tokens or the row does not arm.

FAIL CLOSED.  Anything this function cannot affirmatively parse is rejected.
Every rejection names the fix, in the idiom of `screen_contract`'s other guards.

HOW IT SHOULD BE ROLLED OUT -- diagnostic first, flag second

Turning this on the day it lands would reject every candidate the screeners
currently emit, because none of them carry tokens yet.  The intended sequence,
matching this project's standing convention:

  1. land this module (here) -- nothing calls it, nothing changes.
  2. v4 adds the `catalyst_evidence` COLUMN and the screeners start emitting
     tokens.  `require_catalyst_evidence` defaults **False**, and every row that
     WOULD be rejected is logged with its reason.
  3. read the log.  When the rejection rate is understood, flip the default.

Skipping straight to 3 is how you find out in production that the token
vocabulary was wrong.

SELF-TEST

    python -m kistrader.entry.catalyst_evidence
"""
from __future__ import annotations

from typing import Iterable, List, Optional, Tuple

# --------------------------------------------------------------------------
# The allow-list.  Each entry is something SEPA actually claims and something
# this system can, in principle, point at.  `compute_math_floor` already scores
# the first five from fundamentals (earnings/revenue growth + acceleration and
# EPS surprises), which is why those are the ones with a measurable half.
# --------------------------------------------------------------------------
CATEGORIES = (
    "earnings_growth",
    "earnings_acceleration",
    "earnings_surprise",
    "revenue_growth",
    "revenue_acceleration",
    "margin_expansion",
    "guidance_raise",
    "institutional_sponsorship",
    "new_product_or_market",
)

# Substrings that mark an admission of ignorance or an unverifiable claim.
# The first entry is the exact string the audit caught being laundered.
# Matched case-insensitively against the WHOLE field, note included.
GAP_SENTINELS = (
    "unfamiliar",
    "needs live lookup",
    "knowledge_gap",
    "knowledge gap",
    "cannot verify",
    "can't verify",
    "unable to verify",
    "no information",
    "not sure",
    "unsure",
    "unknown",
    "as of my",              # "as of my training data / knowledge cutoff"
    "training data",
    "knowledge cutoff",
    "i don't have",
    "i do not have",
    "assuming",
    "presumably",
    "likely that",
    "appears to",
    "may have",
)

NOTE_SEP = "|"
TOKEN_SEP = ";"


def validate_evidence(evidence: Optional[str]
                      ) -> Tuple[bool, List[str], List[str]]:
    """(ok, reasons, categories).

    ok is True only when at least one allow-listed token parsed, no unknown
    token appeared, and no gap sentinel appeared anywhere in the field.
    `reasons` is empty on success and names the fix on failure.  Never raises."""
    reasons: List[str] = []
    cats: List[str] = []

    try:
        raw = "" if evidence is None else str(evidence)
    except Exception:
        return False, ["catalyst_evidence is not stringifiable"], []

    if not raw.strip():
        return False, ["catalyst_evidence is empty. A missing catalyst is not a "
                       "confirmed one; emit at least one of: "
                       + ", ".join(CATEGORIES)], []

    low = raw.lower()
    hits = [s for s in GAP_SENTINELS if s in low]
    if hits:
        reasons.append(
            "catalyst_evidence contains uncertainty marker(s) %r. An admission "
            "of ignorance is not a catalyst -- this is the exact string class "
            "the 2026-08-28 audit found being passed as 'catalyst confirmed'. "
            "Emit tokens the screener can stand behind, or emit nothing and let "
            "the row fail closed." % (hits,))

    token_part = raw.split(NOTE_SEP, 1)[0]
    seen = set()
    for tok in token_part.split(TOKEN_SEP):
        t = tok.strip().lower()
        if not t:
            continue
        if t not in CATEGORIES:
            reasons.append(
                "unknown catalyst category %r. Allowed: %s. An unrecognised "
                "token is rejected rather than dropped -- silently dropping is "
                "how the original hole worked." % (t, ", ".join(CATEGORIES)))
            continue
        if t not in seen:
            seen.add(t)
            cats.append(t)

    if not cats and not any("unknown catalyst category" in r for r in reasons):
        reasons.append(
            "catalyst_evidence carries no category token before %r. Free text "
            "alone is not evidence; the gate reads tokens, the note is for a "
            "human. Allowed: %s" % (NOTE_SEP, ", ".join(CATEGORIES)))

    return (not reasons), reasons, cats


def evidence_note(evidence: Optional[str]) -> str:
    """The free-text half, for a human reading the CSV. Carries no weight."""
    try:
        raw = "" if evidence is None else str(evidence)
    except Exception:
        return ""
    return raw.split(NOTE_SEP, 1)[1].strip() if NOTE_SEP in raw else ""


def format_evidence(categories: Iterable[str], note: str = "") -> str:
    """Build a well-formed field. Raises on an unknown category, because the
    emitter is the one place a bad token can still be caught cheaply."""
    cats = [str(c).strip().lower() for c in categories if str(c).strip()]
    bad = [c for c in cats if c not in CATEGORIES]
    if bad:
        raise ValueError("unknown catalyst categor%s %s. Allowed: %s"
                         % ("y" if len(bad) == 1 else "ies", bad,
                            ", ".join(CATEGORIES)))
    if not cats:
        raise ValueError("at least one catalyst category is required")
    out = TOKEN_SEP.join(cats)
    n = (note or "").strip()
    if n:
        if NOTE_SEP in n:
            raise ValueError("the note may not contain %r" % NOTE_SEP)
        out = "%s %s %s" % (out, NOTE_SEP, n)
    return out


# --------------------------------------------------------------------------
def _self_test() -> int:
    ok = [0, 0]

    def check(name, cond, detail=""):
        ok[1] += 1
        if cond:
            ok[0] += 1
        print("  [%s] %s   %s" % ("PASS" if cond else "FAIL", name, detail))

    print("=" * 66)
    print("S8 CATALYST EVIDENCE TEST -- self test")
    print("=" * 66)

    print("the hole that was found")
    good, why, _ = validate_evidence("unfamiliar -- needs live lookup")
    check("the audited laundering string is REJECTED", not good)
    check("...and the reason names it as an admission of ignorance",
          any("admission of ignorance" in r for r in why))
    good, _, _ = validate_evidence("earnings_surprise | unfamiliar with this name")
    check("a sentinel hiding in the NOTE still rejects", not good)

    print("fail closed")
    for val, label in ((None, "None"), ("", "empty"), ("   ", "whitespace"),
                       ("| just a note", "note with no tokens")):
        g, _, _ = validate_evidence(val)
        check("%s -> rejected" % label, not g)

    print("the allow-list")
    g, why, c = validate_evidence("earnings_surprise")
    check("a single valid token passes", g, str(c))
    g, why, c = validate_evidence("earnings_surprise;revenue_acceleration")
    check("two valid tokens pass, both returned", g and c ==
          ["earnings_surprise", "revenue_acceleration"], str(c))
    g, why, c = validate_evidence("EARNINGS_SURPRISE ; Revenue_Growth")
    check("case and spacing are tolerated", g and len(c) == 2, str(c))
    g, why, c = validate_evidence("earnings_surprise;earnings_surprise")
    check("a repeated token is de-duplicated", g and c == ["earnings_surprise"])
    g, why, _ = validate_evidence("strong_momentum")
    check("an invented category is REJECTED", not g)
    check("...and the reason names the allowed set",
          any("Allowed:" in r for r in why))
    g, why, c = validate_evidence("earnings_surprise;strong_momentum")
    check("one good + one invented token still rejects (no partial credit)",
          not g and c == ["earnings_surprise"])

    print("prose is not evidence")
    g, _, _ = validate_evidence("strong earnings growth and revenue acceleration")
    check("free prose containing category WORDS is rejected", not g,
          "a scan for 'earnings' is the same laundering with an extra step")

    print("the note")
    g, _, _ = validate_evidence("earnings_surprise | Q3 EPS 1.24 vs 1.05 est")
    check("a valid token with a factual note passes", g)
    check("the note is recoverable for a human reader",
          evidence_note("earnings_surprise | Q3 EPS 1.24 vs 1.05 est")
          == "Q3 EPS 1.24 vs 1.05 est")
    check("no note -> empty string", evidence_note("earnings_surprise") == "")

    print("the emitter side")
    s = format_evidence(["earnings_surprise", "margin_expansion"], "beat by 18%")
    g, _, c = validate_evidence(s)
    check("format_evidence round-trips through validate_evidence", g and len(c) == 2, s)
    try:
        format_evidence(["moon_phase"])
        check("format_evidence rejects an unknown category", False)
    except ValueError:
        check("format_evidence rejects an unknown category", True)
    try:
        format_evidence([])
        check("format_evidence requires at least one category", False)
    except ValueError:
        check("format_evidence requires at least one category", True)

    print("never raises")
    class Boom:
        def __str__(self): raise RuntimeError("nope")
    g, why, _ = validate_evidence(Boom())
    check("an unstringifiable value is rejected, not raised", not g and bool(why))

    print("=" * 66)
    print("PASSED %d / %d" % (ok[0], ok[1]))
    print("=" * 66)
    return 0 if ok[0] == ok[1] else 1


if __name__ == "__main__":
    raise SystemExit(_self_test())
