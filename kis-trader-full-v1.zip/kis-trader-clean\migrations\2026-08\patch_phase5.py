#!/usr/bin/env python3
"""
patch_phase5.py -- PHASE 5: the boot-time parameter log (R6).

THE PROBLEM
The strategy parameters live across four files with no single source of truth,
and nothing reports them at runtime. After a change you cannot look at one place
and know what the trader will do tomorrow. The freeze doc's own discipline --
"carry the configuration with every number" -- had no mechanism behind it.

WHAT LANDS
`boot_log()` in kistrader/tools/param_snapshot.py, called from cli.cmd_run right
after the notifier is built and BEFORE build_pipeline, so a bad set aborts before
any broker connection. It reuses snapshot()/render(), so the boot output and
`python -m kistrader.tools.param_snapshot` cannot disagree -- one implementation,
not two lists that drift.

THE RULE, and why it is not "refuse on any mismatch"
Phase 7's soak deliberately runs a short STALL_DAY so the promotion -> TRAILING
-> EMA_BREAK path is reachable inside a few weeks. Refusing to boot on any
mismatch would block the soak; printing and continuing would let a soak value
reach a live account. So the rule is asymmetric:

    KIS_MOCK=1  ->  print, warn loudly, continue.       (the soak works)
    KIS_MOCK=0  ->  print, CRITICAL alert, REFUSE.      (the soak cannot leak)

That is the specific mechanism the plan describes as "what stops the soak value
reaching live", made mechanical instead of procedural.

The refusal message begins "ARM BLOCKED", which notifier.classify() routes as a
phone push -- so the reason reaches you directly rather than via a crash-storm
guard and a stale-heartbeat deadman ten minutes later. E10 pins that vocabulary;
the same rule applies here.

NO OVERRIDE FLAG. If a parameter is deliberately different, FROZEN in
param_snapshot.py is the place to change it -- a file that says in its own
comments that editing a number without a backtest behind it defeats the tool.
That friction is the point.

SCREENER OVERRIDES: a screener that hardcodes VCP_SCORE_THRESHOLD blocks a live
boot too. A screener file that is simply ABSENT does not -- a trader-only
deployment is legitimate, and treating "not installed" as "misconfigured" would
be a false block.

Anchors are asserted; edits are applied bottom-up.

Usage:  python patch_phase5.py <repo-root>
"""
from __future__ import annotations

import os
import sys

BOOT_LOG = '''def boot_log(is_mock: bool, alert=None, stream=sys.stdout) -> None:
    """R6: print the ACTIVE parameter set at startup; refuse to go LIVE on drift.

    Four strategy values live across four files with no single source of truth
    and nothing reported them, which is how a wrong STALL_DAY stays invisible
    until March. This prints the set the process is actually about to trade with.

    Asymmetric on purpose:
      * mock -> warn and continue, so the Phase 7 soak can run its short
        STALL_DAY;
      * live -> alert and raise SystemExit, so that soak value can never reach a
        real account.

    A screener that hardcodes the threshold blocks a live boot as well. A
    screener file that is merely ABSENT does not: a trader-only deployment is
    legitimate, and treating "not installed" as "misconfigured" is a false block.
    """
    rows, bad = snapshot()
    render(rows, bad, stream=stream)
    overrides = [(n, r) for n, r in screener_overrides() if r != "NOT FOUND"]
    print(f"  KIS_MOCK={'1 (mock)' if is_mock else '0 (LIVE)'}", file=stream)
    if not (bad or overrides):
        print("  parameter set matches PARAMETER_FREEZE — ok to trade.", file=stream)
        return

    what = []
    if bad:
        what.append(f"{bad} parameter(s) differ from the frozen set")
    if overrides:
        what.append("screener threshold overridden in "
                    + ", ".join(n for n, _ in overrides))
    detail = "; ".join(what)

    if is_mock:
        print(f"  WARNING: {detail}. MOCK — continuing. This set must NEVER "
              f"reach a live account.", file=stream)
        return

    msg = (f"ARM BLOCKED: refusing to start LIVE — {detail}. The trader would not "
           f"be running the backtested strategy. Run "
           f"`python -m kistrader.tools.param_snapshot` for the full comparison, "
           f"and check KIS_STALL_DAY is not still set from a soak.")
    print("  " + msg, file=stream)
    if alert is not None:
        try:
            alert(msg)
        except Exception:                  # noqa: BLE001 — never mask the refusal
            pass
    raise SystemExit(msg)


'''

TESTS = '''#!/usr/bin/env python3
"""
Boot-time parameter log (Phase 5 / R6)
======================================

The set the process is about to trade with, printed at startup -- and, on a LIVE
account, enforced. The asymmetry is the whole design: the Phase 7 soak needs a
short STALL_DAY, so mock must tolerate drift; a live account must not, or the
soak value reaches real money.

These tests drive boot_log() directly rather than through cli.cmd_run, which
needs Config/credentials/a broker. The cli edit is two lines and is exercised by
importing it.
"""
from __future__ import annotations

import io
import sys

from kistrader.tools import param_snapshot as PS

PASS, FAIL = [], []


def check(name, cond, detail=""):
    (PASS if cond else FAIL).append(name)
    print(f"  [{'PASS' if cond else 'FAIL'}] {name}" + (f"  ({detail})" if detail and not cond else ""))


def _run(is_mock, alert=None):
    """Return (raised, text)."""
    buf = io.StringIO()
    try:
        PS.boot_log(is_mock, alert=alert, stream=buf)
        return None, buf.getvalue()
    except SystemExit as e:
        return str(e.code), buf.getvalue()


def test_clean_tree_boots():
    print("P1 a frozen parameter set boots, mock and live alike")
    raised, text = _run(True)
    check("mock: no refusal", raised is None, f"{raised}")
    check("mock: the set is printed", "ACTIVE PARAMETER SET" in text)
    check("mock: KIS_MOCK is stated", "KIS_MOCK=1 (mock)" in text, text[-200:])
    raised, text = _run(False)
    check("live: no refusal when the set matches", raised is None, f"{raised}")
    check("live: KIS_MOCK is stated", "KIS_MOCK=0 (LIVE)" in text, text[-200:])


def test_drift_is_tolerated_on_mock_and_fatal_on_live():
    print("P2 drift: mock continues, LIVE refuses — the soak cannot leak")
    real = dict(PS.FROZEN)
    PS.FROZEN["STALL_DAY"] = 999                 # stand-in for a soak KIS_STALL_DAY
    try:
        raised, text = _run(True)
        check("mock: continues despite drift", raised is None, f"{raised}")
        check("mock: says the set must never reach live",
              "NEVER reach a live account" in text, text[-300:])

        seen = []
        raised, text = _run(False, alert=seen.append)
        check("live: refuses to start", raised is not None, f"{raised}")
        check("live: the refusal names the count",
              raised and "parameter(s) differ" in raised, f"{raised}")
        check("live: it points at the soak override specifically",
              raised and "KIS_STALL_DAY" in raised, f"{raised}")
        check("live: the operator is alerted before the process dies",
              seen == [raised], f"{seen}")
    finally:
        PS.FROZEN.clear(); PS.FROZEN.update(real)


def test_refusal_reaches_the_phone():
    """The refusal is useless in a log: the process is about to exit, the
    supervisor will restart it, and the operator learns nothing until the
    crash-storm guard trips. It must classify as CRITICAL."""
    print("P3 the LIVE refusal is a phone push, not a log line")
    try:
        from kistrader.notifier import classify
    except ImportError as e:
        check("kistrader.notifier importable", False, str(e)); return
    real = dict(PS.FROZEN)
    PS.FROZEN["STALL_DAY"] = 999
    try:
        seen = []
        raised, _ = _run(False, alert=seen.append)
        check("the refusal message classifies CRITICAL",
              bool(seen) and classify(seen[0]) == "CRITICAL",
              f"{[classify(m) for m in seen]}")
    finally:
        PS.FROZEN.clear(); PS.FROZEN.update(real)


def test_alert_failure_never_masks_the_refusal():
    print("P4 a broken alert channel must not swallow the refusal")
    real = dict(PS.FROZEN)
    PS.FROZEN["STALL_DAY"] = 999
    try:
        def boom(_m):
            raise RuntimeError("telegram down")
        raised, _ = _run(False, alert=boom)
        check("still refuses when the alert callback raises", raised is not None,
              f"{raised}")
    finally:
        PS.FROZEN.clear(); PS.FROZEN.update(real)


def test_cli_calls_it():
    """The two-line cli edit: importable, and cmd_run references boot_log."""
    print("P5 cli.cmd_run is wired to it")
    import inspect
    try:
        from kistrader import cli
    except ImportError as e:
        check("kistrader.cli importable", False, str(e)); return
    src = inspect.getsource(cli.cmd_run)
    check("cmd_run calls boot_log", "boot_log(" in src, src[:200])
    check("it runs BEFORE build_pipeline (no broker connection on a bad set)",
          src.index("boot_log(") < src.index("build_pipeline("), "ordering")


def test_zz_all_checks_passed():
    assert not FAIL, f"{len(FAIL)} failed check(s): " + "; ".join(FAIL)


def test_boot_params():
    main()


def main():
    print("=" * 62)
    print("BOOT-TIME PARAMETER LOG (R6)")
    print("=" * 62)
    test_clean_tree_boots()
    test_drift_is_tolerated_on_mock_and_fatal_on_live()
    test_refusal_reaches_the_phone()
    test_alert_failure_never_masks_the_refusal()
    test_cli_calls_it()
    print("=" * 62)
    print(f"PASSED {len(PASS)} / {len(PASS) + len(FAIL)}")
    if FAIL:
        print("FAILED:", ", ".join(FAIL))
    print("=" * 62)
    return 1 if FAIL else 0


if __name__ == "__main__":
    sys.exit(main())
'''


def edit(text, old, new, label):
    n = text.count(old)
    if n != 1:
        raise SystemExit(f"REFUSING: anchor for {label} matched {n} times, expected 1")
    print(f"  ok  {label}")
    return text.replace(old, new)


def read(p):
    with open(p, encoding="utf-8") as f:
        return f.read()


def write(p, s):
    with open(p, "w", encoding="utf-8", newline="") as f:
        f.write(s)


def main(root):
    ps = os.path.join(root, "kistrader", "tools", "param_snapshot.py")
    cl = os.path.join(root, "kistrader", "cli.py")
    tf = os.path.join(root, "tests", "test_boot_params.py")
    for p in (ps, cl):
        if not os.path.isfile(p):
            raise SystemExit(f"REFUSING: not found: {p}")
    s_ps, s_cl = read(ps), read(cl)
    if "boot_log" in s_ps or "boot_log" in s_cl:
        raise SystemExit("REFUSING: Phase 5 appears to be applied already.")
    if os.path.exists(tf):
        raise SystemExit(f"REFUSING: {tf} already exists.")

    print(f"param_snapshot.py  ({ps})")
    s_ps = edit(s_ps, "def main(argv=None):\n", BOOT_LOG + "def main(argv=None):\n",
                "add boot_log()")
    s_ps = edit(s_ps, "def render(rows, bad, stream=sys.stdout):\n",
                "def render(rows, bad, stream=sys.stdout):\n", "render already takes a stream")
    write(ps, s_ps)

    print(f"cli.py  ({cl})")
    s_cl = edit(s_cl,
                "    from kistrader.notifier import Notifier\n"
                "    notifier = Notifier.from_env()\n",
                "    from kistrader.notifier import Notifier\n"
                "    notifier = Notifier.from_env()\n"
                "\n"
                "    # R6: print the ACTIVE parameter set before touching the broker.\n"
                "    # On a LIVE account a set that does not match PARAMETER_FREEZE aborts\n"
                "    # here — this is what stops a soak-only KIS_STALL_DAY reaching real\n"
                "    # money. On mock it warns and continues, so the soak can run.\n"
                "    from kistrader.tools.param_snapshot import boot_log\n"
                "    boot_log(cfg.is_mock, alert=notifier.emit)\n",
                "cmd_run: boot_log before build_pipeline")
    write(cl, s_cl)

    print(f"test_boot_params.py  ({tf})")
    write(tf, TESTS)
    print("  ok  new suite written")
    print("\nPHASE 5 APPLIED. The active parameter set is printed at boot, and a "
          "LIVE boot on drift is refused.")
    return 0


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("usage: python patch_phase5.py <repo-root>")
    sys.exit(main(sys.argv[1]))
