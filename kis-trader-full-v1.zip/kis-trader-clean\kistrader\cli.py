"""kistrader command-line interface.

    python -m kistrader.cli test                    # run both test suites (from repo)
    python -m kistrader.cli verify [--allow-fill]   # KIS mock write-path verifier
    python -m kistrader.cli run [--arm] [--once]    # forward-test loop (mock by default)

After `pip install .` the same commands are available as:
    kistrader test | verify | run
"""
from __future__ import annotations

import argparse
import os
import sys
import runpy

# `kistrader test > gate.log` redirects stdout to a FILE, and a redirected
# stream takes its encoding from the locale -- cp949 on this box, which
# cannot encode U+2014. A suite that prints an em dash then dies mid-run
# with UnicodeEncodeError, and a crashed gate looks exactly like a passing
# one in a tail. Worst case measured: test_entry_half's check() prints a
# dash ONLY on a failing check, so the gate survives until it has bad news.
#
# Pinned here rather than in the suites: every suite is run BY this module,
# so this is in place before any of them prints, and it covers `run` and
# `verify` as well. Guarded: sys.stdout is None under pythonw, and pytest
# replaces it with a capture object that has no reconfigure().
for _s in (sys.stdout, sys.stderr):
    try:
        _s.reconfigure(encoding="utf-8", errors="backslashreplace")
    except Exception:                                     # noqa: BLE001
        pass


def _repo_root() -> str:
    # kistrader/cli.py -> kistrader/ -> repo root
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def cmd_test(_args) -> int:
    root = _repo_root()
    tests = os.path.join(root, "tests")
    if not os.path.isdir(tests):
        raise SystemExit("tests/ not found - run test from the repo checkout")
    for p in (root, tests):
        if p not in sys.path:
            sys.path.insert(0, p)
    rc = 0
    # PATCH G2 -- all seven. Four of these used to be missing, and F3
    # broke test_screener_harness for a full day without the runner
    # noticing. A suite outside this tuple is a suite nobody runs.
    # --- PATCH AF (S2 breakout volume) --- eight. test_breakout_volume is the
    # suite that would have caught the 2026-09-04 build_pipeline defect, and by
    # this tuple's own rule a suite outside it is a suite nobody runs.
    for mod in (
                # PHASE E stage 0: the sell-signal observer and the I5 close
                # log, both of which had self-tests that nothing executed.
                "test_minervini_exit_rules",
                "test_entry_half", "test_pipeline_e2e", "test_seed_position",
                "test_exit_state_machine", "test_boot_params",
                "test_candidate_emit", "test_screener_harness",
                "test_breakout_volume", "test_point_in_time",
                # --- PATCH AI (persist the adopted qty) --- ten. _converge had
                # NO suite at all, which is how a persistence defect lived in
                # the reconciliation path for as long as it has existed. By this
                # tuple's own rule, a suite outside it is a suite nobody runs.
                "test_reconcile",
                # --- 2026-09-14 --- twelve. supervisor.py and deadman.py are
                # the two processes that watch the loop from OUTSIDE it, and
                # both had no suite AT ALL -- not merely one outside this
                # tuple. They are also the pair whose failure is silent: a
                # dead-man that never alerts is indistinguishable from a
                # healthy system.
                "test_watchdogs"):
                # --- end PATCH AI (persist the adopted qty) ---
    # --- end PATCH AF (S2 breakout volume) ---
        print("\n" + "#" * 66 + f"\n# {mod}\n" + "#" * 66)
        try:
            runpy.run_module(mod, run_name="__main__")
        except SystemExit as e:
            if e.code:
                rc = e.code
    return rc


def cmd_verify(args) -> int:
    from kistrader.config import load_dotenv
    load_dotenv()                       # so verify sees .env like run does
    from kistrader.tools import contract_verify
    sys.argv = (["contract_verify", "--ticker", args.ticker, "--exchange", args.exchange]
                + (["--allow-fill"] if args.allow_fill else []))
    return contract_verify.main()


def cmd_seed(args) -> int:
    from kistrader.config import load_dotenv
    load_dotenv()                       # so seed sees .env like run does
    from kistrader.tools import seed_position
    argv = ["--ticker", args.ticker, "--shares", str(args.shares),
            "--entry", str(args.entry), "--stop", str(args.stop),
            "--exchange", args.exchange]
    if args.session_date:
        argv += ["--session-date", args.session_date]
    if args.confirm:
        argv += ["--confirm"]
    if args.allow_live:
        argv += ["--allow-live"]
    return seed_position.main(argv)


def cmd_close(args) -> int:
    from kistrader.config import load_dotenv
    load_dotenv()                       # so close sees .env like run does
    from kistrader.tools import close_position
    argv = ["--order-key", args.order_key, "--reason", args.reason]
    if args.confirm:
        argv += ["--confirm"]
    if args.allow_live:
        argv += ["--allow-live"]
    if args.force:
        argv += ["--force"]
    return close_position.main(argv)


def cmd_run(args) -> int:
    from kistrader.config import Config
    from kistrader.entry.pipeline import build_pipeline
    from kistrader.core.kis_tradable_universe import TradableUniverse

    cfg = Config.from_env()
    if cfg.equity_usd is None:
        raise SystemExit("set KIS_EQUITY_USD (account equity in USD) for sizing")

    ema = close = None
    # --- PATCH AB (I5 wiring) --- `prov` is now kept: the CloseLog reads OHLCV
    # off the same provider object, so the log and the trail can never describe
    # different sessions. build_yf_daily_bars_fetch makes the SAME yfinance call
    # build_yf_daily_fetch already makes -- the frame carries O/H/L/V and the
    # close-only version discards them -- so this adds NO network round trip.
    prov = None
    if not args.no_trail:
        from kistrader.entry.providers import (DailyCloseEMAProvider,
                                               build_yf_daily_fetch,
                                               build_yf_daily_bars_fetch)
        prov = DailyCloseEMAProvider(build_yf_daily_fetch(),
                                     fetch_daily_bars=build_yf_daily_bars_fetch())
        ema, close = prov.as_ema_provider(), prov.as_close_provider()
    # --- end PATCH AB (I5 wiring) ---

    open_order_check = cfg.open_order_check and not args.no_open_order_check
    from kistrader.notifier import Notifier
    notifier = Notifier.from_env()

    # R6: print the ACTIVE parameter set before touching the broker.
    # On a LIVE account a set that does not match PARAMETER_FREEZE aborts
    # here — this is what stops a soak-only KIS_STALL_DAY reaching real
    # money. On mock it warns and continues, so the soak can run.
    from kistrader.tools.param_snapshot import boot_log
    boot_log(cfg.is_mock, alert=notifier.emit)
    loop, ctx = build_pipeline(
        cfg.app_key, cfg.app_secret, cfg.cano, is_mock=cfg.is_mock,
        db_path=cfg.db_path, candidates_path=cfg.candidates_path,
        equity_provider=lambda: cfg.equity_usd,
        auto_buying_power=not args.no_bp_gate,
        require_buying_power=not args.no_bp_gate,
        require_open_order_check=open_order_check,
        universe=TradableUniverse(), alert=notifier.emit,
        ema_provider=ema, close_provider=close,
        # --- PATCH AF (S2 breakout volume) ---
        breakout_volume=not args.no_breakout_volume,
        # --- PATCH AK (trigger extension) ---
        max_trigger_extension_pct=args.max_trigger_extension,
        # --- end PATCH AK (trigger extension) ---
        require_breakout_volume=args.require_breakout_volume,
        # --- end PATCH AF (S2 breakout volume) ---
        auto_arm=args.auto_arm)

    # --- PATCH AB (I5 wiring) --- attach the observation log.
    # Attached AFTER build_pipeline because ctx["db"] is the EventStore the
    # pivot lookup needs, and build_pipeline creates it. RunLoop's call site
    # reads getattr(self, "close_log", None), so this is a plain assignment and
    # build_pipeline needs no new parameter.
    #
    # It trades nothing: the call in _do_close sits in its own try, separate
    # from on_close, and every method of CloseLog swallows its own exceptions.
    # A broken log is a missing row, never a missed exit.
    if prov is not None and not args.no_close_log:
        try:
            from kistrader.entry.close_log import (CloseLog,
                                                   make_event_store_pivot_lookup)
            loop.close_log = CloseLog(
                prov, pivot_lookup=make_event_store_pivot_lookup(ctx["db"]),
                alert=notifier.emit)
            print(f"close observation log -> {loop.close_log.path} "
                  f"(I5; trades nothing, --no-close-log to disable)")
        except Exception as ex:
            # An instrument that cannot start must not stop the trader.
            notifier.emit(f"close_log unavailable, continuing without it: {ex}")
    elif prov is None:
        print("close observation log OFF: --no-trail leaves no close/ema/bars "
              "to observe")
    # --- end PATCH AB (I5 wiring) ---

    print(f"pipeline built (mock={cfg.is_mock}); starting...")
    loop.start()
    if args.arm:
        loop.arm_today(cfg.candidates_path)
    if args.once:
        loop.cycle()
        print("single cycle complete (--once)")
        return 0
    loop.run_forever()
    return 0


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="kistrader", description="KIS Minervini/VCP trader")
    sub = ap.add_subparsers(dest="cmd", required=True)

    sub.add_parser("test", help="run both test suites (from a repo checkout)")

    v = sub.add_parser("verify", help="KIS mock write-path + field verifier")
    v.add_argument("--allow-fill", action="store_true",
                   help="also place a marketable 1-share BUY (spends mock cash)")
    v.add_argument("--ticker", default="AAPL")
    v.add_argument("--exchange", default="NAS")

    s = sub.add_parser("seed", help="hand an existing broker holding to the engine "
                                    "(exit test / recovery; mock-only by default)")
    s.add_argument("--ticker", required=True)
    s.add_argument("--shares", type=int, required=True)
    s.add_argument("--entry", type=float, required=True,
                   help="price you paid (entry_price; frozen R = entry-stop)")
    s.add_argument("--stop", type=float, required=True,
                   help="protective stop; ABOVE entry => sells next OPEN cycle")
    s.add_argument("--exchange", default="NAS")
    s.add_argument("--session-date", default=None)
    s.add_argument("--confirm", action="store_true",
                   help="required: writes a FILLED position to the DB")
    s.add_argument("--allow-live", action="store_true",
                   help="permit when KIS_MOCK=0 (otherwise mock-only)")

    x = sub.add_parser("close", help="terminally close a stranded/phantom position "
                                     "record (broker must confirm flat)")
    x.add_argument("--order-key", required=True, help="e.g. F:2026-07-22")
    x.add_argument("--reason", default="manual")
    x.add_argument("--confirm", action="store_true",
                   help="required: permanently ends the record")
    x.add_argument("--allow-live", action="store_true",
                   help="permit when KIS_MOCK=0 (otherwise mock-only)")
    x.add_argument("--force", action="store_true",
                   help="skip the broker-holdings safety check")

    r = sub.add_parser("run", help="forward-test loop (mock unless KIS_MOCK=0)")
    r.add_argument("--arm", action="store_true", help="run today's arm step once at start")
    r.add_argument("--auto-arm", action="store_true",
                   help="UNATTENDED (Step 6): arm once per session at the first "
                        "OPEN cycle. Screener must have written today's "
                        "candidates.csv; stale/empty file arms nothing, loudly.")
    r.add_argument("--once", action="store_true", help="one cycle then exit (smoke)")
    r.add_argument("--no-trail", action="store_true",
                   help="skip the yfinance EMA/close providers")
    # --- PATCH AF (S2 breakout volume) --- the provider is ON by default and
    # ENFORCEMENT is off. The check runs on every breakout and logs its verdict
    # without blocking, so the flip below is made against production evidence
    # rather than against a guess.
    # --- PATCH AK (trigger extension) --- P0.3 remnant. Measured and LOGGED on
    # every trigger; pass a value to ENFORCE. decision_engine checks extension
    # against last_close when the plan is built, hours before the watch fires.
    r.add_argument("--max-trigger-extension", type=float, default=None,
                   metavar="PCT",
                   help="HOLD a trigger more than PCT above the pivot (e.g. "
                        "0.05, the frozen DecisionConfig.max_extension_pct). "
                        "Default: measure and log, block nothing.")
    # --- end PATCH AK (trigger extension) ---
    r.add_argument("--no-breakout-volume", action="store_true",
                   help="do not read live session volume at a breakout at all "
                        "(default: read it and LOG the verdict, blocking nothing)")
    # --- E9 LOCKOUT (2026-09-19) ---
    # This flag is PERMANENTLY DISABLED and refuses at parse time. The gate it
    # enforces compares cumulative session volume at an INTRADAY instant against
    # 1.5x a FULL-DAY average, so it is unreachable by arithmetic and would hold
    # 100% of breakouts while the log read as a quiet market. Measured
    # 2026-09-17: the suspected tvol delay does not exist; tvol never resets and
    # counts pre-market. See FINDING_20260917_e9_tvol_has_no_lag and
    # DECISION_20260919_E9_volume_confirmation_divergence. A daily-bar volume
    # rule is a DIFFERENT rule; it is backtestable via 06_sweep --param
    # entrystyle (Candidate.trade_signal) and is not this flag.
    class _RefuseRequireBreakoutVolume(argparse.Action):
        def __init__(self, option_strings, dest, **kw):
            kw["nargs"] = 0
            super().__init__(option_strings, dest, **kw)

        def __call__(self, parser, ns, values, option_string=None):
            parser.error(
                "--require-breakout-volume is PERMANENTLY DISABLED. It compares "
                "cumulative session volume at an intraday trigger against 1.5x a "
                "FULL-DAY average, which is unreachable by arithmetic: it would "
                "hold 100% of breakouts and the log would read as a quiet market. "
                "Measured 2026-09-17. See FINDING_20260917_e9_tvol_has_no_lag and "
                "DECISION_20260919_E9_volume_confirmation_divergence. Do not "
                "re-enable without replacing the criterion itself.")

    r.add_argument("--require-breakout-volume", default=False,
                   action=_RefuseRequireBreakoutVolume,
                   help="PERMANENTLY DISABLED -- refuses at parse time. See "
                        "DECISION_20260919_E9_volume_confirmation_divergence.")
    # --- end E9 LOCKOUT ---
    # --- end PATCH AF (S2 breakout volume) ---
    # --- PATCH AB (I5 wiring) --- ON by default deliberately: it trades
    # nothing, adds no network call, and its value is WALL-CLOCK, so an
    # instrument someone forgot to switch on during a soak costs market days
    # that cannot be re-run.
    r.add_argument("--no-close-log", action="store_true",
                   help="disable the I5 per-close observation log "
                        "(runs/close_observations.csv). It trades nothing and "
                        "adds no network call; off only if you have a reason.")
    # --- end PATCH AB (I5 wiring) ---
    r.add_argument("--no-bp-gate", action="store_true",
                   help="disable the buying-power gate (smoke runs before `verify`)")
    r.add_argument("--no-open-order-check", action="store_true",
                   help="skip the resting-order dedup gate (mock returns it empty)")

    args = ap.parse_args(argv)
    return {"test": cmd_test, "verify": cmd_verify, "seed": cmd_seed,
            "close": cmd_close, "run": cmd_run}[args.cmd](args) or 0


if __name__ == "__main__":
    sys.exit(main())



