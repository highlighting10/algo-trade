"""Verify the stall_day / stall_r_floor exposure added this session."""
import numpy as np, pandas as pd
from dataclasses import replace
from minervini_backtest import (STALL_DAY, STALL_R_FLOOR, BTCandidate,
                                BacktestConfig, run, robustness_check)

D = pd.bdate_range("2024-01-02", periods=90)
FAILS = []


def ohlc(dates, closes):
    c = np.asarray(closes, float); o = np.r_[c[0], c[:-1]]
    return pd.DataFrame({"Open": o, "High": np.maximum(o, c) * 1.01,
                         "Low": np.minimum(o, c) * 0.99, "Close": c},
                        index=dates[:len(c)])


def cand(t="A", px=100.0):
    return BTCandidate(ticker=t, exchange="NAS", pivot=px, contraction_low=px * .95,
                       atr=px * .02, last_close=px * .99, rs_rating=90,
                       vcp_score=85.0, session_date="2024-01-02")


def cfg(**kw):
    d = dict(rank_mode="rs_only", sector_map={"A": "Tech", "B": "Health"},
             slippage_bps=0, broker_commission_pct=0, sec_fee_pct=0, taf_per_share=0)
    d.update(kw)
    return BacktestConfig(**d)


def check(name, fn):
    try:
        fn(); print(f"  OK    {name}")
    except AssertionError as e:
        FAILS.append((name, str(e))); print(f"  FAIL  {name}: {e}")
    except Exception as e:
        FAILS.append((name, f"{type(e).__name__}: {e}")); print(f"  CRASH {name}: {e}")


# flat price: never reaches 1R, so the stall is the only exit that can fire
FLAT = {"A": ohlc(D, np.r_[99, 101, [102.0] * 88])}
SIG = {D[0]: [cand()]}


def t_defaults_match_engine_v2():
    c = cfg()
    assert c.stall_day == STALL_DAY == 10, (c.stall_day, STALL_DAY)
    assert c.stall_r_floor == STALL_R_FLOOR == 1.0, (c.stall_r_floor, STALL_R_FLOOR)


def t_default_still_fires_at_10():
    eq, tr, st, dr, dg = run(FLAT, SIG, cfg())
    t = tr[0]
    held = len(D[(D > t.entry_date) & (D <= t.exit_date)])
    assert t.reason == "STALL_EXIT", t.reason
    assert held == STALL_DAY + 1, held        # flagged at day 10, filled next open


def t_longer_stall_delays_the_exit():
    for day in (15, 20, 30):
        eq, tr, st, dr, dg = run(FLAT, SIG, cfg(stall_day=day))
        t = tr[0]
        held = len(D[(D > t.entry_date) & (D <= t.exit_date)])
        assert t.reason == "STALL_EXIT", (day, t.reason)
        assert held == day + 1, (day, held, day + 1)


def t_floor_zero_disables_the_stall():
    # r_multiple can never be < 0.0 when price is above entry, so floor=0 means
    # the position promotes to TRAILING instead of stalling out
    eq, tr, st, dr, dg = run(FLAT, SIG, cfg(stall_r_floor=0.0))
    assert all(t.reason != "STALL_EXIT" for t in tr), [t.reason for t in tr]


def t_higher_floor_stalls_more():
    lo = run(FLAT, SIG, cfg(stall_r_floor=0.5))[2]["exit_reasons"].get("STALL_EXIT", 0)
    hi = run(FLAT, SIG, cfg(stall_r_floor=1.5))[2]["exit_reasons"].get("STALL_EXIT", 0)
    assert hi >= lo, (lo, hi)


def t_replace_carries_stall_params():
    c = replace(cfg(), stall_day=30)
    assert c.stall_day == 30 and c.rank_mode == "rs_only"


def t_sweep_settings_apply():
    """robustness_check passes settings through replace() -- confirm stall_day
    actually reaches run() AND changes the outcome.

    The fixture must move AFTER the early stall date, otherwise a later exit
    sells at the same price and the two settings score identically for reasons
    that have nothing to do with whether the kwarg arrived. (First version of
    this test used a flat series and produced exactly that false alarm.)"""
    # flat through ~day 22, then a rally: stall_day=10 exits before it,
    # stall_day=40 survives long enough to promote to TRAILING and ride it
    c = np.r_[99, 101, [102.0] * 22, np.linspace(103, 145, 66)]
    prices = {"A": ohlc(D, c)}
    sig = {D[0]: [cand("A")]}

    early = run(prices, sig, cfg(stall_day=10))
    late = run(prices, sig, cfg(stall_day=40))
    e_t, l_t = early[1][0], late[1][0]
    assert e_t.exit_date != l_t.exit_date, (e_t.exit_date, l_t.exit_date)
    assert l_t.exit_price > e_t.exit_price, (e_t.exit_price, l_t.exit_price)

    r = robustness_check(prices, sig, cfg(),
                         settings={"stall_10": {"stall_day": 10},
                                   "stall_40": {"stall_day": 40}},
                         slippage_grid=(0.0,), metric="expectancy_R")
    scores = r["scores_by_slippage"][0.0]
    assert len(scores) == 2, scores
    assert len(set(scores.values())) > 1, f"stall_day never reached run(): {scores}"
    assert r["settings_differentiated"], r["verdict"]


if __name__ == "__main__":
    for n, f in [("defaults match engine_v2 constants", t_defaults_match_engine_v2),
                 ("default stall still fires at day 10", t_default_still_fires_at_10),
                 ("longer stall_day delays the exit", t_longer_stall_delays_the_exit),
                 ("stall_r_floor=0 disables the stall", t_floor_zero_disables_the_stall),
                 ("higher floor stalls at least as much", t_higher_floor_stalls_more),
                 ("dataclasses.replace carries them", t_replace_carries_stall_params),
                 ("sweep settings actually reach run()", t_sweep_settings_apply)]:
        check(n, f)
    print()
    print("STALL PARAM CHECK CLEAN" if not FAILS else f"{len(FAILS)} PROBLEM(S): {FAILS}")
