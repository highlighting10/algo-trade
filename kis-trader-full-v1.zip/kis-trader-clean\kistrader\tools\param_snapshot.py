#!/usr/bin/env python3
"""
param_snapshot — what is ACTUALLY running, against what the backtest froze.

WHY THIS EXISTS (freeze doc R6)

The strategy parameters live in four different files with no single source of
truth, and NOTHING in the system reports them. After a change you cannot look at
one place and know what the trader will do tomorrow. The freeze doc's own
discipline — "carry the configuration with every number" — has no mechanism
behind it. A deployment figure measured at threshold 70 was once quoted against
a threshold-75 set and inverted a conclusion; the same class of mistake in
production is a wrong STALL_DAY that goes unnoticed until March.

This reads the LIVE values out of the modules that will actually run and prints
them beside the frozen target from PARAMETER_FREEZE_2026-08-11 (Rev 3).

EXIT CODE IS THE POINT
  0  every parameter matches the frozen set  -> safe to deploy
  1  at least one differs                    -> the trader is NOT running the
                                                backtested strategy

So before Phase 2 this exits 1 and lists what has not been promoted yet. That is
correct: it is telling you the truth about a half-migrated tree.

Phase 5 imports snapshot() from here and prints the same rows at boot, so the
boot log and this command can never disagree.

Usage:  python -m kistrader.tools.param_snapshot
        python -m kistrader.tools.param_snapshot --frozen-only
"""
from __future__ import annotations

import argparse
import os
import sys


# The frozen set. Source: PARAMETER_FREEZE_2026-08-11.md Rev 3 §1.
# Editing a number here without a backtest behind it defeats the entire tool.
FROZEN = {
    "VCP_SCORE_THRESHOLD":        75,
    "rs_weight":                  0.0,
    "stage2_weight":              0.0,
    "vcp_weight":                 1.0,
    "STALL_DAY":                  252,
    "STALL_R_FLOOR":              1.0,      # structurally inert at 252
    "risk_per_trade_pct":         0.0085,
    "max_position_pct":           0.25,
    "n_max":                      8,
    "max_open_positions":         8,
    "max_stop_pct":               0.10,     # Minervini doctrinal ceiling
    "max_portfolio_exposure_pct": 1.00,
    "R_PARTIAL_MULTIPLE":         3.0,
    "EMA_LEN":                    21,
    "regime_ma":                  None,        # PATCH F3 2026-08-25 -- gate OFF
}

# Notes shown beside specific rows. Kept short; the freeze doc is the reference.
NOTES = {
    "STALL_DAY": "at 252 there is no promotion; the trail is reachable only via the +3R partial",
    "STALL_R_FLOOR": "inert at STALL_DAY=252 (no trade reaches day 252)",
    "vcp_weight": "vcp_only ranking = (rs, stage2, vcp) weights of (0, 0, 1)",
    "max_position_pct": "25 vs 30 is inside the +/-0.19 R noise floor; 25 kept",
    "regime_ma": "PATCH F3 2026-08-25: OFF (None). DIVERGES from PARAMETER_FREEZE §1, which says 20. Minervini gates per-stock, not on an index MA, and the sweep could not separate 20 from off (0.035-0.049 R against a 0.138 R floor). Rev 3 headline +0.330 R was measured at 20; at off it is +0.294 R.",
}

MISSING = object()      # distinct from None, which is a legitimate value

# --- PATCH A: fail-closed switches + tree sha ---
# NOT frozen parameters: no backtest ever chose them, so they never affect the
# exit code. Reported because flipping one silently changes what gets ARMED.
SWITCH_DEFAULTS = {"allow_missing_close": False, "require_atr": False}

# --- PATCH I --------------------------------------------------------------
# FROZEN is what a BACKTEST chose. These two groups are what the tree was BUILT
# with. Keeping them separate keeps FROZEN's meaning intact: its own comment
# says editing a number there without a backtest behind it defeats the tool.
#
# Measured before this patch: 12 of 21 DecisionConfig fields and 37 of 41
# engine_v2 constants were unguarded, including all 14 TR ids. Corrections v2
# sec.6: "a wrong TR id is invisible to all of them. It is invisible to
# param_snapshot too."
#
# PINNED -- decides BEHAVIOUR, never backtest-chosen. Drift is a stop.
PINNED_DECISION = {
    "sector_cap":           0,        # PATCH F: off by declaration
    "require_trade_signal": False,    # proven unfillable at True (audit 2026-08-28)
    "min_shares":           1,
    "stop_buffer_pct":      0.005,
    "atr_mult_min":         1.3,      # the ATR band; BACKTEST QUESTION #2
    "atr_mult_max":         2.5,
    "depth_shallow":        0.08,     # the depth->multiple lerp
    "depth_deep":           0.25,
    "entry_chase_pct":      0.005,    # caps the fill price by construction
    "max_extension_pct":    0.05,
}

PINNED_ENGINE = {
    "PARTIAL_FRACTION":       1.0 / 3.0,
    "BASE_EXIT_SLIP":         0.02,   # the exit-slippage ladder
    "PARTIAL_SLIP":           0.01,
    "SLIP_STEP":              0.01,
    "MAX_SLIP":               0.09,
    "REPRICE_AFTER_SECS":     20,
    "SETTLE_SECS":            8,      # the ambiguous-GONE window
    "MAX_EXIT_ATTEMPTS":      6,
    "EXIT_FLAT_CONFIRM_SECS": 15.0,   # mock has no fills feed; this closes exits
    "PRICE_BAND":            0.10,
    "PARTIAL_RETRY_SECS":     8.0,
    "REST_RATE_HZ":           3,      # preserved local edit; 8 trips EGW00201
    "REST_BURST":             4,      # preserved local edit
}

# IDENTITY -- not parameters. Endpoint identities. Equality or nothing.
# This is the group that would have caught the mock sell-TR bug.
IDENTITY_TR = {
    "TR_BALANCE_LIVE":  "TTTS3012R", "TR_BALANCE_MOCK":  "VTTS3012R",
    "TR_BUY_LIVE":      "TTTT1002U", "TR_BUY_MOCK":      "VTTT1002U",
    "TR_CANCEL_LIVE":   "TTTT1004U", "TR_CANCEL_MOCK":   "VTTT1004U",
    "TR_FILLS_LIVE":    "TTTS3035R", "TR_FILLS_MOCK":    "VTTS3035R",
    "TR_PRICE":     "HHDFS00000300", "TR_QUOTE":     "HHDFS76200100",
    # TTTT1006U has NEVER been exercised (corrections v2 sec.6). VTTT1001U is
    # NOT the V-prefixed twin of it -- that assumption was the bug.
    "TR_SELL_LIVE":     "TTTT1006U", "TR_SELL_MOCK":     "VTTT1001U",
    "TR_UNFILLED_LIVE": "TTTS3018R", "TR_UNFILLED_MOCK": "VTTS3018R",
}

# --- E10 layer 2 --- PINNED_EXPOSURE. ExposureConfig fields, and NOT in FROZEN
# on purpose: no backtest chose either of them. regime_ma is settled on doctrine
# (PATCH F3) and appears in FROZEN only because PARAMETER_FREEZE Rev 3 names it;
# loss_streak_ceilings is settled on doctrine too (E10, after three measurement
# routes failed to separate the arms) and was never in the freeze doc at all.
#
# This row is the ONLY thing that can see the progressive-exposure gate being
# switched on, because build_pipeline never passes an ExposureConfig: the single
# way to enable it is editing the module default, which is exactly the drift
# this group exists to stop. Turning it on is therefore a two-line change --
# DEFAULT_LOSS_STREAK_CEILINGS there AND the same value here, together.
PINNED_EXPOSURE = {"loss_streak_ceilings": None}


def _read_group(want, source):
    """(rows, n_bad) for one group. rows = [(name, live, expected, ok)].
    MISSING is a mismatch: a constant that vanished is drift, not an absence."""
    rows, bad = [], 0
    for name, exp in want.items():
        got = source.get(name, MISSING)
        if got is MISSING:
            ok = False
        elif isinstance(exp, float):
            ok = isinstance(got, (int, float)) and abs(got - exp) < 1e-12
        else:
            ok = got == exp and type(got) is type(exp)
        if not ok:
            bad += 1
        rows.append((name, got, exp, ok))
    return rows, bad


def extra_drift():
    """(pinned_rows, identity_rows, n_bad) for the two PATCH I groups.
    Unreadable modules report every value MISSING rather than passing quietly."""
    try:
        from kistrader.entry.decision_engine import DecisionConfig
        dc = {k: getattr(DecisionConfig(), k, MISSING) for k in PINNED_DECISION}
    except ImportError:
        dc = {}
    try:
        from kistrader.core import engine_v2 as _E
        ev = {k: getattr(_E, k, MISSING) for k in PINNED_ENGINE}
        tr = {k: getattr(_E, k, MISSING) for k in IDENTITY_TR}
    except ImportError:
        ev, tr = {}, {}
    try:
        from kistrader.entry.exposure_controller import ExposureConfig
        xc = {k: getattr(ExposureConfig(), k, MISSING) for k in PINNED_EXPOSURE}
    except ImportError:
        xc = {}
    p_rows, p_bad = _read_group(PINNED_DECISION, dc)
    e_rows, e_bad = _read_group(PINNED_ENGINE, ev)
    x_rows, x_bad = _read_group(PINNED_EXPOSURE, xc)
    i_rows, i_bad = _read_group(IDENTITY_TR, tr)
    return (p_rows + e_rows + x_rows, i_rows,
            p_bad + e_bad + x_bad + i_bad)
# --- end PATCH I ----------------------------------------------------------


def switches():
    """Live values of the two fail-closed switches, MISSING if unreadable."""
    try:
        from kistrader.entry.decision_engine import DecisionConfig
        cfg = DecisionConfig()
        return {k: getattr(cfg, k, MISSING) for k in SWITCH_DEFAULTS}
    except ImportError:
        return {k: MISSING for k in SWITCH_DEFAULTS}


def tree_sha(root=None):
    """Which commit is this process actually running? Whole tree, no pin to
    maintain, still true after a deploy. NEVER raises: a boot log must not be
    able to abort a run."""
    import subprocess
    if root is None:
        here = os.path.dirname(os.path.abspath(__file__))       # kistrader/tools
        root = os.path.dirname(os.path.dirname(here))           # repo root
    try:
        r = subprocess.run(["git", "rev-parse", "--short", "HEAD"], cwd=root,
                           capture_output=True, text=True, timeout=5)
        if r.returncode != 0 or not r.stdout.strip():
            return "unknown (not a git checkout)"
        sha = r.stdout.strip()
        d = subprocess.run(["git", "status", "--porcelain"], cwd=root,
                           capture_output=True, text=True, timeout=5)
        if d.returncode == 0 and d.stdout.strip():
            return sha + " +dirty (uncommitted edits in the tree)"
        return sha
    except Exception:                       # noqa: BLE001 -- never break a boot
        return "unknown (git unavailable)"


def _live():
    """Read every parameter from the module that will actually run. Anything
    unreadable comes back as MISSING rather than a guessed default."""
    out = {}

    try:
        from kistrader.entry.screen_contract import VCP_SCORE_THRESHOLD
        out["VCP_SCORE_THRESHOLD"] = VCP_SCORE_THRESHOLD
    except ImportError:
        out["VCP_SCORE_THRESHOLD"] = MISSING

    try:
        from kistrader.core import engine_v2 as E
        for k in ("STALL_DAY", "STALL_R_FLOOR", "R_PARTIAL_MULTIPLE", "EMA_LEN"):
            out[k] = getattr(E, k, MISSING)
    except ImportError:
        for k in ("STALL_DAY", "STALL_R_FLOOR", "R_PARTIAL_MULTIPLE", "EMA_LEN"):
            out[k] = MISSING

    try:
        from kistrader.entry.decision_engine import DecisionConfig
        cfg = DecisionConfig()
        for k in ("rs_weight", "stage2_weight", "vcp_weight", "risk_per_trade_pct",
                  "max_position_pct", "n_max", "max_open_positions", "max_stop_pct",
                  "max_portfolio_exposure_pct"):
            out[k] = getattr(cfg, k, MISSING)
    except ImportError:
        for k in ("rs_weight", "stage2_weight", "vcp_weight", "risk_per_trade_pct",
                  "max_position_pct", "n_max", "max_open_positions", "max_stop_pct",
                  "max_portfolio_exposure_pct"):
            out[k] = MISSING

    # The exposure controller is not wired yet (Phase 3). Absent is reported as
    # absent -- never as "off", which would read like a deliberate setting.
    try:
        from kistrader.entry.exposure_controller import ExposureConfig
        out["regime_ma"] = ExposureConfig().regime_ma
    except ImportError:
        out["regime_ma"] = MISSING

    return out


def screener_overrides(root=None):
    """SOURCE cross-check for the one gap D3a leaves open.

    After D3a neither screener can diverge by configuration -- there is no local
    value to set. It can still diverge if someone pastes a literal back in, and
    the snapshot above would not see it: the snapshot reads screen_contract, and
    a screener-local assignment shadows that at runtime inside the screener only.
    Both screeners write the SAME candidates.csv, so that divergence would screen
    half the universe at a bar nobody chose.

    Returns [(filename, offending_rhs)]. Empty means both resolve through the
    shared declaration.

    This is a source scan, so it proves what the files SAY. The runtime detector
    -- what each screener actually APPLIED on a given day -- is the provenance
    artifact written by candidate_emit (D2), which is not built yet."""
    import re
    if root is None:
        here = os.path.dirname(os.path.abspath(__file__))          # kistrader/tools
        root = os.path.dirname(os.path.dirname(here))              # repo root
    out = []
    for name in ("sp500_v21.py", "us_small_v21.py"):
        path = os.path.join(root, "screeners", name)
        if not os.path.isfile(path):
            out.append((name, "NOT FOUND"))
            continue
        with open(path, encoding="utf-8") as fh:
            src = fh.read()
        for rhs in re.findall(r"^VCP_SCORE_THRESHOLD\s*=\s*(.+)$", src, re.M):
            if not rhs.strip().startswith("_load_vcp_threshold"):
                out.append((name, rhs.strip()))
    return out


def _fmt(v):
    if v is MISSING:
        return "NOT PRESENT"
    return repr(v)


def snapshot():
    """Return (rows, n_mismatch). rows = [(name, live, frozen, ok)]."""
    live = _live()
    rows, bad = [], 0
    for name, want in FROZEN.items():
        got = live.get(name, MISSING)
        ok = (got is not MISSING) and (abs(got - want) < 1e-12
                                       if isinstance(want, float) else got == want)
        if not ok:
            bad += 1
        rows.append((name, got, want, ok))
    return rows, bad


def render(rows, bad, stream=sys.stdout):
    w = max(len(r[0]) for r in rows)
    p = lambda s: print(s, file=stream)
    p("=" * (w + 46))
    p("ACTIVE PARAMETER SET  vs  PARAMETER_FREEZE Rev 3")
    p("=" * (w + 46))
    for name, got, want, ok in rows:
        mark = "  ok " if ok else "  ** "
        p(f"{mark}{name:<{w}}  live={_fmt(got):<12} frozen={_fmt(want)}")
        if not ok and name in NOTES:
            p(f"      {' ' * w}  {NOTES[name]}")
    p("-" * (w + 46))
    for _k, _v in switches().items():                       # --- PATCH A ---
        _d = SWITCH_DEFAULTS[_k]
        if _k == "allow_missing_close" and _v is True:
            _note = "  <- ARMS WITHOUT A VERIFIABLE CLOSE"
        elif _v != _d:
            _note = "  <- non-default (stricter)" if _k == "require_atr" else "  <- non-default"
        else:
            _note = ""
        p(f"  {'ok ' if _v == _d else '** '}{_k:<{w}}  "
          f"live={_fmt(_v):<12} default={_fmt(_d)}{_note}")
    p(f"  tree = {tree_sha()}")                             # --- PATCH A ---
    ov = screener_overrides()
    if ov:
        for name, rhs in ov:
            p(f"  ** {name}: VCP_SCORE_THRESHOLD overridden locally -> {rhs}")
        p("     Both screeners write the SAME candidates.csv. Remove the literal.")
    else:
        p("  ok both screeners resolve VCP_SCORE_THRESHOLD via screen_contract")
    # --- PATCH I --- the 37 values FROZEN never covered.
    _pin_rows, _id_rows, _extra = extra_drift()
    p("-" * (w + 46))
    p("  PINNED (decides behaviour; never backtest-chosen)")
    for _n, _g, _e, _ok in _pin_rows:
        if not _ok:
            p(f"  ** {_n:<{w}}  live={_fmt(_g):<12} built-with={_fmt(_e)}")
    p(f"     {sum(1 for r in _pin_rows if r[3])}/{len(_pin_rows)} match "
      f"the values this tree was built with")
    p("  IDENTITY (KIS endpoint ids; equality or nothing)")
    for _n, _g, _e, _ok in _id_rows:
        if not _ok:
            p(f"  ** {_n:<{w}}  live={_fmt(_g):<12} expected={_fmt(_e)}")
    p(f"     {sum(1 for r in _id_rows if r[3])}/{len(_id_rows)} match. "
      f"A wrong TR id is invisible to every test (they use FakeBroker).")
    p("-" * (w + 46))
    # --- end PATCH I ---
    p(f"  KIS_MOCK = {os.environ.get('KIS_MOCK', '(unset -> mock)')}")
    if bad or _extra:
        if bad:
            p(f"  {bad} parameter(s) DIFFER from the frozen set.")
            p("  The trader is NOT running the backtested strategy.")
        if _extra:
            p(f"  {_extra} pinned/identity value(s) DIFFER from what this tree "
              f"was built with.")
    else:
        p("  All parameters match the frozen set.")
    p("=" * (w + 46))


def boot_log(is_mock: bool, alert=None, stream=sys.stdout) -> None:
    """R6: print the ACTIVE parameter set at startup; refuse to go LIVE on drift.

    Four strategy values live across four files with no single source of truth
    and nothing reported them, which is how a wrong STALL_DAY stays invisible
    until March. This prints the set the process is actually about to trade with.

    Asymmetric on purpose:
      * mock -> warn and continue, so the Phase 7 soak can run its short
        STALL_DAY;
      * live -> alert and raise SystemExit, so that soak value can never reach a
        real account.

    A screener that hardcodes the threshold blocks a live boot as well. A
    screener file that is merely ABSENT does not: a trader-only deployment is
    legitimate, and treating "not installed" as "misconfigured" is a false block.
    """
    rows, bad = snapshot()
    render(rows, bad, stream=stream)
    overrides = [(n, r) for n, r in screener_overrides() if r != "NOT FOUND"]
    print(f"  KIS_MOCK={'1 (mock)' if is_mock else '0 (LIVE)'}", file=stream)
    # --- PATCH A --- allow_missing_close is the only dangerous direction.
    # Alerts, does NOT raise: the refusal path stays driven by FROZEN alone.
    if switches().get("allow_missing_close") is True and not is_mock:
        _m = ("allow_missing_close=True on a LIVE account -- the system will arm "
              "a position with no verifiable close. This is a fail-closed "
              "switch, not a tuning knob.")
        print("  CRITICAL: " + _m, file=stream)
        if alert is not None:
            try:
                alert("CRITICAL: " + _m)
            except Exception:              # noqa: BLE001 -- never mask the boot
                pass
    # --- PATCH I --- pinned/identity drift refuses a LIVE boot too.
    _extra = extra_drift()[2]
    if not (bad or overrides or _extra):
        print("  parameter set matches PARAMETER_FREEZE — ok to trade.", file=stream)
        return

    what = []
    if _extra:
        what.append(f"{_extra} pinned/identity value(s) differ from what this "
                    f"tree was built with (see the PINNED/IDENTITY rows above)")
    if bad:
        what.append(f"{bad} parameter(s) differ from the frozen set")
    if overrides:
        what.append("screener threshold overridden in "
                    + ", ".join(n for n, _ in overrides))
    detail = "; ".join(what)

    if is_mock:
        print(f"  WARNING: {detail}. MOCK — continuing. This set must NEVER "
              f"reach a live account.", file=stream)
        return

    msg = (f"ARM BLOCKED: refusing to start LIVE — {detail}. The trader would not "
           f"be running the backtested strategy. Run "
           f"`python -m kistrader.tools.param_snapshot` for the full comparison, "
           f"and check KIS_STALL_DAY is not still set from a soak.")
    print("  " + msg, file=stream)
    if alert is not None:
        try:
            alert(msg)
        except Exception:                  # noqa: BLE001 — never mask the refusal
            pass
    raise SystemExit(msg)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[1].strip())
    ap.add_argument("--frozen-only", action="store_true",
                    help="print the frozen target table and exit 0 (no imports)")
    args = ap.parse_args(argv)

    if args.frozen_only:
        for k, v in FROZEN.items():
            print(f"  {k:<28} {v!r}")
        return 0

    rows, bad = snapshot()
    render(rows, bad)
    # --- PATCH I --- the exit code covers all three groups.
    return 1 if (bad or screener_overrides() or extra_drift()[2]) else 0


if __name__ == "__main__":
    sys.exit(main())
