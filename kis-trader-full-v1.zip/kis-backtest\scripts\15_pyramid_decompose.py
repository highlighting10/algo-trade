"""
15_pyramid_decompose.py -- separate the TRUSTWORTHY half of the pyramid result
from the half the overlay cannot measure, and re-rank on the trustworthy half.

WHY THIS EXISTS
14_pyramid_design.py ranked by total expectancy and put four `T=0.5 ... +BE`
designs on top. That ranking is BIASED, and in a knowable direction:

  * the ADD leg is well modelled. Its loss side is exact by continuity: a trade
    that FINISHED below (T-s) must have passed through (T-s) after the add, so
    the add was stopped at -s. Only its win side is optimistic.
  * the BREAKEVEN leg is an UPPER BOUND and nothing more. The overlay assumes a
    trade that touched +T and finished negative exits at exactly 0.0 R. It
    cannot see a trade that dipped below entry after +T and then recovered --
    a real breakeven stop scratches those at 0.0 instead of letting them run.
    At T=0.5, 399 of 689 trades (58%) get a breakeven stop, so the blind spot
    is at its widest exactly where the ranking put its winners.

So a design whose gain is mostly BE is a design mostly built on the overlay's
blind spot. This script reports the split for every design, applies a whipsaw
haircut to the BE leg, and re-ranks.

WHAT A "BREAKEVEN STOP" ACTUALLY IS HERE, verified in minervini_backtest.py:
  line 636 and 643:  pos.stop_loss_price = pos.entry_price
It ALREADY EXISTS. It fires when the +3R partial fires (R_PARTIAL_MULTIPLE=3.0),
and nowhere else; the stop is otherwise STATIC from entry. So "+BE at T" is not
a new mechanism -- it is moving an existing trigger from 3.0R down to T, and it
can be separated from the partial-sale itself. Two knobs, not one.

Usage:
    python scripts/15_pyramid_decompose.py --threshold 70 --signals data/signals_daily.pkl --rank-mode vcp_only --risk-pct 0.0085 --max-position-pct 0.25
"""
import pathlib as _pl
import sys as _sys
_sys.path.insert(0, str(_pl.Path(__file__).resolve().parent.parent))

import argparse
import itertools
import pathlib
import pickle

import numpy as np
import pandas as pd

from minervini_backtest import (BacktestConfig, DecisionConfig, load_sector_map,
                                run)


def tranche_pnl(m, r, T, k, s):
    """Added tranche P&L in units of tranche-1 risk. Loss side exact."""
    return np.where(m >= T, k * np.maximum(r - T, -s), 0.0)


def be_leg(m, r, be_at, whipsaw):
    """Tranche-1 P&L with a breakeven stop at be_at.

    whipsaw = fraction of triggered WINNERS that a real breakeven stop would
    have scratched to 0.0 (dipped below entry after +T, then recovered).
    whipsaw=0.0 reproduces the optimistic overlay; sweep it upward to see how
    fast the BE gain evaporates. Applied deterministically to the SMALLEST
    winners first, which is the kindest ordering -- a real stop scratches
    whichever trades dipped, not whichever were smallest.
    """
    if be_at is None:
        return r.copy()
    out = np.where(m >= be_at, np.maximum(r, 0.0), r)
    if whipsaw <= 0.0:
        return out
    trig_win = np.where((m >= be_at) & (r > 0.0))[0]
    if len(trig_win) == 0:
        return out
    n_scratch = int(round(whipsaw * len(trig_win)))
    if n_scratch <= 0:
        return out
    order = trig_win[np.argsort(r[trig_win])]
    out[order[:n_scratch]] = 0.0
    return out


def peak_notional_frac(f, trigs, risk_pct, stop_pct):
    n1 = risk_pct / stop_pct
    tot = f * n1
    for (T, k, _s) in trigs:
        tot += k * n1 * (1.0 + T * stop_pct)
    return tot


def max_risk_R(f, trigs):
    return f + sum(k * s for (_T, k, s) in trigs)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--threshold", type=float, default=70.0)
    ap.add_argument("--slippage", type=float, default=5.0)
    ap.add_argument("--signals", default="data/signals.pkl")
    ap.add_argument("--rank-mode", default="rs_only",
                    choices=["rs_only", "vcp_only", "rs_plus_vcp"],
                    help="MUST match the swept winner or the trades are wrong")
    ap.add_argument("--start", default=None)
    ap.add_argument("--end", default=None)
    ap.add_argument("--stall-day", type=int, default=10,
                    help="MUST match the chosen stall_day -- it decides which "
                         "trades exist, so the pyramid measurement moves with it")
    ap.add_argument("--risk-pct", type=float, default=0.0085)
    ap.add_argument("--max-position-pct", type=float, default=0.25)
    ap.add_argument("--stop-pct", type=float, default=0.0625)
    ap.add_argument("--top", type=int, default=12)
    args = ap.parse_args()

    bars = {p.stem: pd.read_parquet(p)
            for p in pathlib.Path("data/bars").glob("*.parquet")}
    prices = {t: d for t, d in bars.items() if t != "^GSPC"}
    with open(args.signals, "rb") as f:
        signals = pickle.load(f)["signals"]
    if args.start or args.end:
        lo = pd.Timestamp(args.start) if args.start else pd.Timestamp.min
        hi = pd.Timestamp(args.end) if args.end else pd.Timestamp.max
        signals = {d: v for d, v in signals.items() if lo <= pd.Timestamp(d) <= hi}
    if not signals:
        raise SystemExit("[dec] no signals in the requested window")

    _b = bars.get("^GSPC")
    cfg = BacktestConfig(rank_mode=args.rank_mode, equity_mode="compounding",
                         entry_mode="pivot_limit", ambiguity_mode="worst",
                         vcp_threshold=args.threshold, slippage_bps=args.slippage,
                         stall_day=args.stall_day,
                         sector_map=load_sector_map("data/sectors.csv"),
                         decision=DecisionConfig(
                             risk_per_trade_pct=args.risk_pct,
                             max_position_pct=args.max_position_pct),
                         benchmark_close=(_b["Close"] if _b is not None else None))
    eq, trades, st, dr, dg = run(prices, signals, cfg)
    if not trades:
        raise SystemExit("[dec] no trades")

    m = np.array([float(t.max_r_seen) for t in trades])
    r = np.array([float(t.r_at_exit) for t in trades])
    n = len(trades)
    base = r.mean()

    print("=" * 92)
    print(f"PYRAMID DECOMPOSITION  threshold={args.threshold}  rank_mode={args.rank_mode}"
          f"  {n} trades  {min(signals).date()}..{max(signals).date()}")
    print(f"constraints: risk {args.risk_pct*100:.2f}%  max_position "
          f"{args.max_position_pct*100:.0f}%  assumed stop {args.stop_pct*100:.2f}%"
          f"  stall_day {args.stall_day}")
    print("=" * 92)
    print(f"  baseline {base:+.4f} R  (harness {st['expectancy_R']:+.3f} R)")
    print()

    designs = []
    for T, k, s in itertools.product((0.5, 0.75, 1.0, 1.5, 2.0),
                                     (0.25, 0.5, 0.75, 1.0),
                                     (0.25, 0.5, 1.0)):
        designs.append((f"T={T} k={k} s={s}", 1.0, [(T, k, s)], T))
        designs.append((f"T={T} k={k} s={s} noBE", 1.0, [(T, k, s)], None))

    rows = []
    for label, f0, trigs, be in designs:
        peak = peak_notional_frac(f0, trigs, args.risk_pct, args.stop_pct)
        if peak > args.max_position_pct + 1e-12:
            continue
        add_part = sum(tranche_pnl(m, r, T, k, s).mean() for (T, k, s) in trigs)
        be_part = be_leg(m, r, be, 0.0).mean() - base
        rows.append(dict(label=label, add=add_part, be=be_part,
                         total=base + add_part + be_part,
                         risk=max_risk_R(f0, trigs), peak=peak, trigs=trigs, be_at=be))

    print(f"  1. DECOMPOSITION  ({len(rows)} feasible designs) ranked by TOTAL")
    print(f"     {'design':<26}{'total':>9}{'add leg':>10}{'BE leg':>9}"
          f"{'BE share':>10}{'maxRisk':>9}{'peak':>8}")
    for x in sorted(rows, key=lambda d: -d["total"])[:args.top]:
        gain = x["add"] + x["be"]
        share = (x["be"] / gain * 100) if gain > 1e-12 else 0.0
        print(f"     {x['label']:<26}{x['total']:>+9.4f}{x['add']:>+10.4f}"
              f"{x['be']:>+9.4f}{share:>9.0f}%{x['risk']:>8.2f}R{x['peak']*100:>7.1f}%")
    print()

    print("  2. SAME DESIGNS ranked by the ADD LEG ONLY (the modelled half)")
    print(f"     {'design':<26}{'add leg':>10}{'total':>9}{'maxRisk':>9}{'peak':>8}")
    for x in sorted(rows, key=lambda d: -d["add"])[:args.top]:
        print(f"     {x['label']:<26}{x['add']:>+10.4f}{x['total']:>+9.4f}"
              f"{x['risk']:>8.2f}R{x['peak']*100:>7.1f}%")
    print()

    print("  3. WHIPSAW STRESS on the BE leg")
    print("     w = fraction of triggered winners a real breakeven stop scratches")
    best_tot = max(rows, key=lambda d: d["total"])
    best_add = max(rows, key=lambda d: d["add"])
    for tag, x in (("best-by-total", best_tot), ("best-by-add", best_add)):
        print(f"     {tag}: {x['label']}")
        print(f"       {'w':>6}{'total':>10}{'vs base':>10}")
        for w in (0.0, 0.10, 0.25, 0.50, 0.75, 1.00):
            v = be_leg(m, r, x["be_at"], w)
            for (T, k, s) in x["trigs"]:
                v = v + tranche_pnl(m, r, T, k, s)
            print(f"       {w:>6.2f}{v.mean():>+10.4f}{v.mean()-base:>+10.4f}")
    print()

    print("  4. HOW EXPOSED IS EACH DESIGN TO THE BLIND SPOT?")
    for T in (0.5, 0.75, 1.0, 1.5, 2.0):
        trig = m >= T
        winners = int((trig & (r > 0)).sum())
        print(f"     BE at {T:>4.2f}R: {int(trig.sum()):>4} trades triggered "
              f"({100*trig.mean():>4.1f}%), {winners:>4} of them finished positive "
              f"and are the ones a real stop could scratch")
    print()
    print("=" * 92)
    print("  DECIDE ON SECTION 2, SANITY-CHECK WITH SECTION 3.")
    print("  A design whose gain is mostly BE leg is mostly unmeasured. The add")
    print("  leg is the part this overlay can actually defend.")
    print("  Then re-run with --start/--end. Nothing counts until both halves agree.")


if __name__ == "__main__":
    main()
