#!/usr/bin/env python3
"""
sector_cap_count -- what did the per-sector cap actually DO in Rev 3?

THE QUESTION THIS ANSWERS

The backtest enforces `sector_cap = 2` against a real data/sectors.csv. Production
does not (cli.py never passes sector_of, so plan.sector is "" and the cap's own
guard is False -- see sector_cap_probe.py). Whether that divergence is a footnote
or a real problem depends on ONE number nobody has: how often the cap bound.

Counting the drops is not enough. A cap that fires 40 times might still change
nothing, because the rejected name is usually replaced by the next candidate. So
this runs the SAME frozen set three ways and compares the outcomes:

  A  cap 2, sector map loaded, strict     <- what Rev 3 ran
  B  cap 0, sector map loaded, strict     <- A minus the cap ONLY
  C  cap 0, NO sector map                 <- production's effective behaviour

  A vs B  isolates the cap.
  B vs C  isolates the unmapped-name filter (strict_sector_map drops names that
          are absent from the frozen sector file; production drops nothing).
  A vs C  is the whole backtest-vs-production divergence.

CARRY THE CONFIGURATION WITH EVERY NUMBER

Every one of the five frozen values is set EXPLICITLY here and printed. That is
not decoration. `06_sweep.py`'s defaults are NOT the frozen set:

    --rank-mode   rs_only   vs frozen vcp_only    <- unguarded
    --threshold   80.0      vs frozen 75          <- unguarded
    regime_ma     None      vs frozen 20          <- unguarded (no flag exists)
    --risk-pct    0.0075    vs frozen 0.0085      <- guarded since 2026-08-22
    --max-pos-pct 0.20      vs frozen 0.25        <- guarded since 2026-08-22

Three of the five would silently produce a different configuration.

Checking those six numbers against themselves would prove nothing -- they are
what the config is built from. So with --prod-root this cross-checks them against
production's `param_snapshot.FROZEN`, an independently maintained copy of the
same frozen set, and REFUSES on any disagreement. That check runs before a single
parquet file is read.

USAGE  (from the kis-backtest root, venv active)

    python sector_cap_count.py --prod-root C:\\Users\\user\\kis-trader-clean

Without --prod-root it still runs, but says loudly that the frozen set is
unverified. Expect three full backtests; time them from the first elapsed line.
"""
from __future__ import annotations

import argparse
import os
import pathlib
import pickle
import sys
import time
from dataclasses import replace

# --- the frozen set, PARAMETER_FREEZE_2026-08-11 (Rev 3) sec.1 --------------- #
FROZEN = {
    "rank_mode":          "vcp_only",
    "vcp_threshold":      75.0,
    "stall_day":          252,
    "regime_ma":          20,
    "risk_per_trade_pct": 0.0085,
    "max_position_pct":   0.25,
}
SECTOR_CAP_DEFAULT = 2      # DecisionConfig's default; NEVER frozen by Rev 3


def hr(c="="):
    print(c * 74)


def _production_frozen(prod_root):
    """Load production's param_snapshot.FROZEN by ABSOLUTE PATH and translate it
    into this script's six keys.

    By absolute path, not by import: kis-backtest ships its own `kistrader`
    package (no tools/ subpackage), so a bare import would either fail or find
    the wrong tree. Returns (dict, None) or (None, reason).
    """
    import importlib.util
    if not prod_root:
        return None, "no --prod-root given"
    path = os.path.join(os.path.abspath(prod_root), "kistrader", "tools",
                        "param_snapshot.py")
    if not os.path.isfile(path):
        return None, "no param_snapshot.py under %r" % prod_root
    try:
        spec = importlib.util.spec_from_file_location("_prod_param_snapshot", path)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        F = mod.FROZEN
    except Exception as e:                                    # noqa: BLE001
        return None, "could not load %s: %s" % (path, e)

    # rank_mode is not a parameter in production -- it is expressed as the three
    # rank weights. (0, 0, 1) IS vcp_only; anything else is not.
    weights = (F.get("rs_weight"), F.get("stage2_weight"), F.get("vcp_weight"))
    rank = {(0.0, 0.0, 1.0): "vcp_only"}.get(weights, "weights%s" % (weights,))
    return {
        "rank_mode":          rank,
        "vcp_threshold":      float(F["VCP_SCORE_THRESHOLD"]),
        "stall_day":          F["STALL_DAY"],
        "regime_ma":          F["regime_ma"],
        "risk_per_trade_pct": F["risk_per_trade_pct"],
        "max_position_pct":   F["max_position_pct"],
    }, None


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", default=".", help="kis-backtest root")
    ap.add_argument("--bars", default="data/bars")
    ap.add_argument("--signals", default="data/signals.pkl")
    ap.add_argument("--sectors", default="data/sectors.csv")
    ap.add_argument("--prod-root", default=None,
                    help="production repo, to cross-check the frozen set against "
                         "param_snapshot.FROZEN (strongly recommended)")
    a = ap.parse_args()

    root = os.path.abspath(a.repo)
    sys.path.insert(0, root)
    try:
        import pandas as pd
        from minervini_backtest import (BacktestConfig, DecisionConfig,
                                        load_sector_map, run)
    except Exception as e:                                    # noqa: BLE001
        print("FATAL: cannot import the harness from %r: %s" % (root, e))
        return 2

    # ---- provenance: which decision_engine are we about to measure? --------- #
    try:
        from kistrader.entry import decision_engine as DE
        engine_path = DE.__file__
    except Exception:                                         # noqa: BLE001
        engine_path = "<not importable>"
    hr()
    print("  SECTOR CAP -- what it actually did at the frozen set")
    hr()
    print("  harness         : %s" % os.path.join(root, "minervini_backtest.py"))
    print("  decision_engine : %s" % engine_path)

    # ---- the frozen set, cross-checked BEFORE any I/O ----------------------- #
    # Comparing the config back against FROZEN would be TAUTOLOGICAL -- it is
    # built from FROZEN, so they agree by construction and the check could never
    # fail. The real risk is that the six numbers were TYPED WRONG here. Only an
    # independent copy of the same frozen set can catch that, and one exists:
    # production's param_snapshot.FROZEN, which boot_log enforces on every live
    # start. Cross-check against THAT, and do it before reading 1500 parquet
    # files -- refusing after a minute of I/O is a worse tool than refusing now.
    cross, why = _production_frozen(a.prod_root)
    hr("-")
    bad = {}
    for k in FROZEN:
        want = cross.get(k, None) if cross else None
        if want is None:
            mark = "(no cross-check)"
        elif want == FROZEN[k]:
            mark = "ok  == production"
        else:
            mark = "** DISAGREES with production: %s" % (want,)
            bad[k] = (FROZEN[k], want)
        print("  %-20s %-12s %s" % (k, FROZEN[k], mark))
    hr("-")
    if cross is None:
        print("  WARNING: %s" % why)
        print("  The six values above are UNVERIFIED against production's guard.")
        print("  Pass --prod-root to cross-check, e.g.")
        print("     --prod-root C:\\Users\\user\\kis-trader-clean")
    if bad:
        print("REFUSING TO RUN: this script's frozen set disagrees with "
              "production's param_snapshot.FROZEN: %s" % bad)
        print("One of the two is wrong. Do not read any number produced here "
              "until that is settled.")
        return 1
    # ---- data --------------------------------------------------------------- #
    bars_dir = pathlib.Path(a.bars)
    if not bars_dir.is_dir():
        print("FATAL: no bar directory at %r" % str(bars_dir))
        return 2
    t0 = time.time()
    bars = {p.stem: pd.read_parquet(p) for p in bars_dir.glob("*.parquet")}
    prices = {t: d for t, d in bars.items() if t != "^GSPC"}
    bench = bars.get("^GSPC")
    if bench is None:
        print("FATAL: no ^GSPC bars -- regime_ma=20 needs the benchmark and the "
              "harness fails closed without it. Cannot run the frozen set.")
        return 2
    if not os.path.isfile(a.signals):
        print("FATAL: no signals file at %r" % a.signals)
        return 2
    with open(a.signals, "rb") as f:
        signals = pickle.load(f)["signals"]
    smap = load_sector_map(a.sectors)
    ds = sorted(signals)
    print("  bars            : %d tickers (+^GSPC)   loaded in %.1fs"
          % (len(prices), time.time() - t0))
    print("  signals         : %d dates  %s .. %s   %d candidate(s)"
          % (len(signals), ds[0].date(), ds[-1].date(),
             sum(len(v) for v in signals.values())))
    print("  sector map      : %d tickers" % len(smap))

    # ---- the frozen set, explicit, and asserted ----------------------------- #
    dec = DecisionConfig(risk_per_trade_pct=FROZEN["risk_per_trade_pct"],
                         max_position_pct=FROZEN["max_position_pct"])
    base = BacktestConfig(
        rank_mode=FROZEN["rank_mode"], equity_mode="compounding",
        entry_mode="pivot_limit", ambiguity_mode="worst",
        vcp_threshold=FROZEN["vcp_threshold"], stall_day=FROZEN["stall_day"],
        regime_ma=FROZEN["regime_ma"], sector_map=smap, decision=dec,
        benchmark_close=bench["Close"])

    # Cheap post-condition: dataclass __post_init__ could in principle coerce a
    # value. This is NOT the frozen-set check (that ran above, before any I/O) --
    # it only catches construction surprising us.
    built = {"rank_mode": base.rank_mode, "vcp_threshold": base.vcp_threshold,
             "stall_day": base.stall_day, "regime_ma": base.regime_ma,
             "risk_per_trade_pct": base.decision.risk_per_trade_pct,
             "max_position_pct": base.decision.max_position_pct}
    drift = {k: (v, FROZEN[k]) for k, v in built.items() if v != FROZEN[k]}
    if drift:
        print("REFUSING TO RUN: BacktestConfig altered a value on "
              "construction: %s" % drift)
        return 1
    if base.decision.sector_cap != SECTOR_CAP_DEFAULT:
        print("REFUSING TO RUN: DecisionConfig.sector_cap is %r, expected the "
              "default %r. The comparison below assumes the default."
              % (base.decision.sector_cap, SECTOR_CAP_DEFAULT))
        return 1
    print("  sector_cap          %-12s %s" % (base.decision.sector_cap,
          "NOT frozen by Rev 3 -- this is what we measure"))

    # ---- the three runs ----------------------------------------------------- #
    CFGS = [
        ("A  cap 2, map, strict   (what Rev 3 ran)", base),
        ("B  cap 0, map, strict   (A minus the cap)",
         replace(base, decision=replace(dec, sector_cap=0))),
        ("C  cap 0, NO map        (production's behaviour)",
         replace(base, decision=replace(dec, sector_cap=0),
                 sector_map={}, allow_missing_sector_map=True)),
    ]

    results = {}
    for label, cfg in CFGS:
        t = time.time()
        _eq, trades, stats, drops, diag = run(prices, signals, cfg)
        results[label[0]] = (stats, drops, diag, trades)
        print("  ran %-46s %6.1fs  %4d trades"
              % (label, time.time() - t, stats["num_trades"]))

    # ---- 1. how often did the cap fire? ------------------------------------- #
    hr()
    print("  1. HOW OFTEN THE CAP FIRED  (run A)")
    hr()
    _s, dropsA, diagA, _t = results["A"]
    cap_keys = {k: v for k, v in diagA["drops_by_reason"].items()
                if "sector cap" in k}
    cap_total = sum(cap_keys.values())
    de_total = sum(v for k, v in diagA["drops_by_reason"].items()
                   if k.startswith("decision_engine/"))
    print("  sector_cap_measured        : %s" % diagA["sector_cap_measured"])
    print("  sector-cap rejections      : %d" % cap_total)
    print("  all decision_engine drops  : %d" % de_total)
    print("  drops of every kind        : %d" % diagA["drops_total"])
    if de_total:
        print("  cap as %% of engine drops   : %.1f%%" % (100.0 * cap_total / de_total))
    days = {d for d, _t, r in dropsA.detail if "sector cap" in r}
    print("  distinct dates it fired on : %d of %d signal dates"
          % (len(days), len(signals)))
    print()
    for k in sorted(cap_keys, key=lambda x: -cap_keys[x]):
        print("      %5d  %s" % (cap_keys[k], k))
    if not cap_keys:
        print("      (none -- the cap never bound)")

    unmapped = diagA["drops_by_reason"].get("unmapped_sector", 0)
    print()
    print("  unmapped_sector drops      : %d   (names absent from the frozen "
          "sector file;\n%s production drops none of these)" % (unmapped, " " * 31))

    # ---- 2. did it change the RESULT? --------------------------------------- #
    hr()
    print("  2. DID IT CHANGE THE RESULT?   <- this is the decision")
    hr()
    KEYS = ("num_trades", "win_rate_pct", "expectancy_R", "total_return_pct",
            "max_drawdown_pct", "cagr_pct")
    print("  %-20s %14s %14s %14s" % ("", "A cap2+map", "B cap0+map", "C cap0 nomap"))
    for k in KEYS:
        row = []
        for tag in "ABC":
            v = results[tag][0].get(k, "-")
            # cagr_pct is a SENTENCE when the window is under six months. Never
            # let a long string silently wreck the column alignment -- a table
            # that looks broken gets read as broken.
            cell = ("%.3f" % v) if isinstance(v, float) else str(v)
            if len(cell) > 14:
                cell = cell[:11] + "..."
            row.append("%14s" % cell)
        print("  %-20s %s %s %s" % (k, *row))

    hr()
    ea, eb, ec = (results[t][0]["expectancy_R"] for t in "ABC")
    na, nb, nc = (results[t][0]["num_trades"] for t in "ABC")
    print("  the cap alone      (A -> B): expectancy %+.3f -> %+.3f  (%+.3f R), "
          "trades %d -> %d" % (ea, eb, eb - ea, na, nb))
    print("  the whole gap      (A -> C): expectancy %+.3f -> %+.3f  (%+.3f R), "
          "trades %d -> %d" % (ea, ec, ec - ea, na, nc))
    print()
    print("  READ IT AGAINST THE NOISE FLOOR. Rev 3 sec.4 gives SE = 1.95/sqrt(n);")
    print("  at n=200 that is 0.138 R. A delta inside that is not evidence --")
    print("  it is the same standard every parameter in Rev 3 was judged by.")
    hr()
    return 0


if __name__ == "__main__":
    sys.exit(main())
