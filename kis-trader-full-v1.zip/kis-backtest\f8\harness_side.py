#!/usr/bin/env python3
"""
F8 -- the HARNESS side of the differential fixture.

Wired against the real `minervini_backtest.py` (v2, 1363 lines, 2026-08-11).
The exit reimplementation lives inside `run()`; there is no separate exit
function to call, so this adapter drives the whole `run()` over a
single-ticker synthetic price frame and reads the resulting `Trade` back.

Nothing in the harness is modified. Exactly one symbol is monkeypatched --
`_ema` -- and only so the SAME EMA series feeds both engines. Holding the
indicator constant is what makes the diff a test of the exit LOGIC rather than
of `ewm(adjust=False)` versus an SMA seed; `ema_compare.py` measures that
separately and finds it immaterial (max 0.01% of price, zero decision flips).

---------------------------------------------------------------------------
FOUR THINGS THIS ADAPTER HAS TO NEUTRALISE, AND WHY EACH IS LEGITIMATE
---------------------------------------------------------------------------
1. COSTS. `slippage_bps=5` and the commission/SEC/TAF model would move every
   exit price by a few basis points. `engine_v2` has no cost model at all, so
   they are set to zero. F8 is about WHEN and WHY a position exits.

2. EQUITY MODE. `compounding` makes share counts depend on prior trades.
   Set to `fixed` at an equity chosen so `decision_engine.size()` returns
   exactly 30 shares, which is what the engine side is seeded with.

3. THE ENTRY. The harness owns its own entry path; the engine side is seeded
   directly. The adapter therefore builds a candidate whose geometry drives
   `decision_engine` to entry 100.00 / stop 90.00 / 30 shares, and ASSERTS the
   harness actually produced that before comparing anything. A mismatch aborts
   the case rather than silently comparing two different trades.

4. EOD_OPEN. A backtest must close everything on the last bar; production just
   keeps holding. A harness `EOD_OPEN` on the FINAL bar is therefore normalised
   to "still open" to match the engine side. This is the one normalisation
   applied, it is applied nowhere else, and it is reported on every case that
   uses it.

---------------------------------------------------------------------------
WHICH decision_engine GETS IMPORTED -- READ THIS
---------------------------------------------------------------------------
`minervini_backtest.py` imports `kistrader.entry.decision_engine`, falling back
to a bare `decision_engine` module. FINDING_backtest_vendored_engine_20260820
recorded that this resolved to a VENDORED copy inside kis-backtest.

**There is no vendored `kistrader/` package and no `decision_engine.py` in the
archive supplied on 2026-08-22.** So this adapter puts the PRODUCTION repo on
`sys.path`, and the harness imports production's engine. That is a real
difference from the run that produced Rev 3, it is reported on every run, and
it has a consequence documented in `describe()`: production's `DecisionConfig`
carries `vcp_weight = 1.0`, which the harness never overrides -- so `rs_only`
and `rs_plus_vcp` silently rank on RS+VCP. F8 is unaffected (it uses
`vcp_only`, where the double-count collapses to 2*vcp and the ordering is
unchanged, and every case has exactly one candidate anyway).
"""
from __future__ import annotations

import os
import sys

from engine_side import Trade, load_module


# geometry the fixture is seeded with, mirrored from cases.py
TARGET_ENTRY, TARGET_STOP, TARGET_SHARES = 100.0, 90.0, 30

# Derived so production's decision_engine lands exactly on the target:
#   entry_limit = round(pivot * (1 + entry_chase_pct 0.005), 2)      -> 100.00
#   structural  = round(contraction_low * (1 - stop_buffer_pct .005), 2) -> 90.00
#   atr small enough that the ATR floor never undercuts the structural stop
PIVOT = 99.5025
CONTRACTION_LOW = 90.452261
ATR = 0.5
LAST_CLOSE = 99.0
WARMUP_BARS = 30


def equity_for(shares: int, risk_per_share: float = 10.0,
               risk_pct: float = 0.0085) -> float:
    """Equity that makes decision_engine.size() return exactly `shares`.

    size() is floor(equity * risk_pct / risk_per_share), so aiming at the
    MIDPOINT of the band that floors to `shares` keeps it off both edges.
    Case 9 runs 32 shares on purpose (int/round/exact all disagree there), and
    an adapter that always sized to 30 would have compared two different
    positions and reported a phantom R disagreement -- it did, until this
    existed."""
    return (shares + 0.5) * risk_per_share / risk_pct


def _partialled(case, t0) -> bool:
    """The harness never records the partial leg in the Trade, so infer it from
    the runner count being short of what was opened."""
    return t0.shares < case.shares


class HarnessAdapter:
    def __init__(self, module, path, decision_engine_from, pd):
        self.m = module
        self.path = path
        self.decision_engine_from = decision_engine_from
        self.pd = pd
        self.notes = []

    def describe(self) -> str:
        return (f"{self.path}\n"
                f"                         decision_engine resolved to: "
                f"{self.decision_engine_from}")

    # -----------------------------------------------------------------
    def _frame(self, case):
        pd = self.pd
        rows, idx = [], []
        # flat warm-up well clear of every trigger level
        for i in range(WARMUP_BARS):
            idx.append(pd.Timestamp("2025-01-01") + pd.Timedelta(days=i))
            rows.append((LAST_CLOSE, LAST_CLOSE, LAST_CLOSE, LAST_CLOSE, 1_000_000.0))
        for j, b in enumerate(case.bars):
            idx.append(pd.Timestamp("2025-01-01") + pd.Timedelta(days=WARMUP_BARS + j))
            rows.append((b.open, b.high, b.low, b.close, 1_000_000.0))
        df = pd.DataFrame(rows, index=pd.DatetimeIndex(idx),
                          columns=["Open", "High", "Low", "Close", "Volume"])
        return df

    def _ema_series(self, case, df):
        """The case's EMA, aligned to the frame. NaN where the case gives none,
        which leaves the harness's EMA branch inert exactly as passing 0.0 does
        on the engine side."""
        pd = self.pd
        vals = [float("nan")] * len(df)
        if case.emas is not None:
            for j, e in enumerate(case.emas):
                if e is not None and WARMUP_BARS + j < len(vals):
                    vals[WARMUP_BARS + j] = float(e)
        return pd.Series(vals, index=df.index, dtype=float)

    # -----------------------------------------------------------------
    def run(self, case) -> Trade:
        m, pd = self.m, self.pd
        df = self._frame(case)
        ema_s = self._ema_series(case, df)

        real_ema = m._ema
        m._ema = lambda close, span=m.EMA_LEN: ema_s
        try:
            cand = m.BTCandidate(
                ticker="TST", exchange="NAS", pivot=PIVOT,
                contraction_low=CONTRACTION_LOW, atr=ATR, last_close=LAST_CLOSE,
                rs_rating=90, vcp_score=90.0,
                session_date=str(df.index[WARMUP_BARS - 1].date()),
                close_known=True, trade_signal=True)
            # armed on the last warm-up bar -> fills on case bar 0
            signals = {df.index[WARMUP_BARS - 1]: [cand]}

            cfg = m.BacktestConfig(
                rank_mode="vcp_only",
                equity_mode="fixed", starting_equity=equity_for(case.shares),
                entry_mode="pivot_limit",
                ambiguity_mode=("best" if (case.tick_path or "worst") == "ohlc"
                                else "worst"),
                vcp_threshold=0.0,
                stall_day=case.stall_day, stall_mode="legacy",
                be_trigger_r=None, regime_ma=None,
                slippage_bps=0.0, broker_commission_pct=0.0, sec_fee_pct=0.0,
                taf_per_share=0.0, taf_cap_per_trade=0.0,
                allow_missing_sector_map=True,
            )
            _eq, trades, _stats, drops, diag = m.run({"TST": df}, signals, cfg)
        finally:
            m._ema = real_ema

        if not trades:
            reasons = "; ".join(f"{r}" for r in list(getattr(drops, "rows", []))[:4])
            raise RuntimeError(f"harness produced no trade for case {case.key}. "
                               f"drops: {reasons or diag}")

        t0 = trades[0]
        # -- assert the entry fixture matched before comparing exits ----------
        # shares is asserted too: t0.shares is the RUNNER count (post-partial),
        # so reconstruct the original from the partial the harness took.
        opened = t0.shares + int(case.shares * m.PARTIAL_FRACTION) if _partialled(case, t0) \
                 else t0.shares
        got = (round(t0.entry_price, 2),
               round(t0.entry_price - t0.risk_per_share, 2), opened)
        want = (TARGET_ENTRY, TARGET_STOP, case.shares)
        if got != want:
            raise RuntimeError(
                f"case {case.key}: harness entry geometry (entry, stop, shares) {got} "
                f"!= fixture {want}. Refusing to compare -- the two engines would be "
                f"running different trades. Retune PIVOT / CONTRACTION_LOW / "
                f"equity_for() in harness_side.py.")

        bar_index = list(df.index).index(pd.Timestamp(t0.exit_date)) - WARMUP_BARS
        reason = t0.reason
        note = ""
        if reason == "EOD_OPEN" and bar_index == len(case.bars) - 1:
            # a backtest must flatten on the last bar; production does not
            reason, bar_index = None, None
            note = "harness EOD_OPEN on the final bar normalised to 'still open'"

        r_weighted = self._weighted_r(case, t0)
        tr = Trade(exit_reason=reason, exit_bar=bar_index,
                   exit_price=None if reason is None else round(float(t0.exit_price), 4),
                   r_multiple=r_weighted, days_held=t0.days_held,
                   final_state="CLOSED" if reason else "OPEN")
        tr.legs = [(bar_index, t0.shares, float(t0.exit_price), reason or "OPEN")]
        tr.harness_r_at_exit = t0.r_at_exit      # the harness's OWN per-trade R
        tr.note = note
        return tr

    # -----------------------------------------------------------------
    def _weighted_r(self, case, t0):
        """Share-weighted R across ALL legs, to match the engine side.

        The harness's own `Trade.r_at_exit` is the FINAL leg only: the +3R
        partial's profit is added to cash and, by its own comment at line 699,
        'NEVER appears in any Trade record'. So a partial-then-breakeven trade
        reads 0.0 R in the harness's trade log and +1.0 R here. Both are
        reported; the difference is an accounting question about Rev 3's
        expectancy, not an exit-logic disagreement."""
        risk = t0.risk_per_share
        if risk <= 0:
            return None
        runner = t0.shares
        partial_qty = case.shares - runner
        partial_level = TARGET_ENTRY + 3.0 * risk
        pnl = runner * (t0.exit_price - t0.entry_price)
        if partial_qty > 0:
            pnl += partial_qty * (partial_level - t0.entry_price)
        return round(pnl / (case.shares * risk), 4)


def load_harness_adapter(harness_path: str, prod_root: str = None) -> HarnessAdapter:
    harness_path = os.path.abspath(harness_path)
    root = os.path.dirname(harness_path)

    try:
        import pandas as pd
    except ImportError as e:
        raise ImportError("the harness needs pandas/numpy: pip install pandas numpy") from e

    added = [root]
    if prod_root:
        added.append(os.path.abspath(prod_root))
    for p in added:
        sys.path.insert(0, p)
    try:
        mod = load_module(harness_path, "f8_harness")
    finally:
        for p in added:
            try:
                sys.path.remove(p)
            except ValueError:
                pass

    k = sys.modules.get("kistrader")
    where = os.path.abspath(getattr(k, "__file__", "") or "") if k else "<bare decision_engine>"
    return HarnessAdapter(mod, harness_path, where, pd)
