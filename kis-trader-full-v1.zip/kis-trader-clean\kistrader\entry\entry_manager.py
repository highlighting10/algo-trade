#!/usr/bin/env python3
"""
Entry manager — PENDING_ENTRY arming (§3.5-3.7)  ["the bridge"]
===============================================================

This is the mirror image of ExecutionMonitor, applied to the BUY side. It takes
EntryPlans from the decision engine, arms them as PENDING_ENTRY orders, drives
each to a confirmed fill, and hands the resulting FILLED Position to the exit
monitor. It obeys the SAME safety rule the exit half was hardened around:

    CONFIRM, NEVER INFER.
      * get_fills(qty) is the fill authority; None == UNKNOWN -> HOLD, never guess.
      * PENDING_ENTRY -> FILLED only on POSITIVE fill evidence (executions, or a
        holdings increase — legitimate here because dedup guarantees a 0 baseline).
      * A GONE order that we did NOT cancel is AMBIGUOUS (filled vs expired). We
        open a bounded settle window and resolve from positive evidence; we never
        read GONE-with-no-fills as a buy.
      * A PARTIAL entry is a REAL position: we cancel the remainder but FILL and
        hand off whatever actually executed. We never silently drop shares we own.
      * On crash recovery we RE-ADOPT the resting order and resolve it; we NEVER
        auto-place a fresh entry (that could buy into a gapped market at a stale
        limit). Re-placing is a live-session decision, not a recovery action.

Fill *price* is a refinement, not a safety dependency: correctness rests only on
get_fills / get_order_status / place_limit_order / cancel_order / get_holding —
the methods the exit half already verified. get_fills_detail (VWAP) is used if
the broker offers it and the price is sane, else we fall back to the entry limit
(a conservative overstatement of entry -> understates R, never the reverse).

PIVOT WATCH (v2, 2026-07-21) — arm != place.
    KIS has no server-side stop/conditional BUY (confirmed: overseas open API is
    limit/market only), so "buy the breakout" must be software. arm_batch now
    creates a WATCH per plan instead of an order: all arm-time gates still run
    (holdings dedup, §3.9.1 open-order backstop, cumulative buying power), but
    the BUY limit is only placed when a live quote prints last >= plan.pivot.
      * below-pivot names no longer buy in-base at market;
      * above-limit gaps place the SAME capped limit (pivot*(1+chase)) which
        RESTS below market — we never chase past the cap, by construction.
    Persistence: every watch transition is logged under `{order_key}:WATCH` with
    the snapshot's state forced to CANCELLED so load_open_snapshots() can never
    resurrect a watch as a phantom PENDING_ENTRY; the live status is the WATCH_*
    event chain (ARMED -> TRIGGERED | EXPIRED | CANCELLED). recover_watches()
    rehydrates same-session watches after a crash and expires stale ones LOUDLY;
    a watch whose order was already placed pre-crash is closed idempotently
    (the ORDER_SENT marker is the authority — same rule as _arm_one). Watches
    are day orders: PipelineLoop expires them on the OPEN->CLOSED transition.
"""
from __future__ import annotations

import json
import time
import threading
from dataclasses import replace
from typing import Callable, Optional

from kistrader.core.engine_v2 import (Position, PositionState, KISBroker, EventStore,
                       SETTLE_SECS, RESTING, UNKNOWN)
from kistrader.entry.decision_engine import EntryPlan, Rejection


# how long a breakout BUY limit may rest before we stop chasing and cancel it
ENTRY_TIMEOUT_SECS = 120
# fraction of buying power held back so a batch never commits to the last cent
CASH_BUFFER_PCT = 0.02


class EntryManager:
    def __init__(self, broker: KISBroker, db: EventStore,
                 on_fill: Optional[Callable[[Position], None]] = None,
                 alert=None, clock=time.monotonic,
                 buying_power_provider: Optional[Callable[[], Optional[float]]] = None,
                 require_buying_power: bool = True,
                 require_open_order_check: bool = True,
                 # --- PATCH AF (S2 breakout volume) --- require_ defaults FALSE.
                 # A gate switched on ahead of its data source arms nothing,
                 # silently, forever (REVIEW_20260904 sec.2). build_pipeline
                 # refuses the combination outright.
                 breakout_volume_provider=None,
                 breakout_volume_multiple: float = 1.5,
                 require_breakout_volume: bool = False,
                 # --- end PATCH AF (S2 breakout volume) ---
                 # --- PATCH AK (trigger extension) --- None = measure and LOG
                 # only. A float ENFORCES; the frozen value is
                 # DecisionConfig.max_extension_pct (0.05). No second copy of
                 # that number lives here.
                 max_trigger_extension_pct=None,
                 # --- end PATCH AK (trigger extension) ---
                 entry_timeout_secs: float = ENTRY_TIMEOUT_SECS,
                 cash_buffer_pct: float = CASH_BUFFER_PCT,
                 orphan_adopt_max_age_days: float = 3.0):
        self.broker = broker
        self.db = db
        self.on_fill = on_fill or (lambda p: None)
        self.alert = alert or (lambda m: print(f"[ENTRY] {m}"))
        self.clock = clock
        self._bp_provider = buying_power_provider
        self.require_bp = require_buying_power
        self.require_open_order_check = require_open_order_check
        self.entry_timeout = entry_timeout_secs
        self._baseline = {}       # order_key -> holding qty at arm (for §3.9.2)
        self.cash_buffer_pct = cash_buffer_pct
        self.orphan_adopt_max_age_days = orphan_adopt_max_age_days
        self._lock = threading.Lock()
        self._pending: list = []            # live PENDING_ENTRY positions we own
        self._watching: list = []           # [(Position, EntryPlan)] armed, PRE-place
        # --- PATCH AF (S2 breakout volume) ---
        self.breakout_volume_provider = breakout_volume_provider
        self.breakout_volume_multiple = float(breakout_volume_multiple)
        self.require_breakout_volume = bool(require_breakout_volume)
        self._vol_held = {}                 # order_key -> consecutive holds
        # --- end PATCH AF (S2 breakout volume) ---
        # --- PATCH AK (trigger extension) ---
        self.max_trigger_extension_pct = (
            None if max_trigger_extension_pct is None
            else float(max_trigger_extension_pct))
        # --- end PATCH AK (trigger extension) ---

    # ---- public position ownership ----
    def pending(self) -> list:
        return [p for p in self._pending if p.state == PositionState.PENDING_ENTRY]

    def watching(self) -> list:
        """Positions armed as pivot watches (no broker order yet)."""
        return [p for p, _ in self._watching]

    def _watching_tickers(self) -> set:
        return {p.ticker for p, _ in self._watching}

    def _pending_tickers(self) -> set:
        # watches ARE in-flight intent: they must dedup exactly like live orders
        # (arm_batch re-runs, AccountState.pending_tickers, decision-engine dedup)
        return {p.ticker for p in self.pending()} | self._watching_tickers()

    def _open_order_tickers(self):
        """(tickers_or_None, supported). supported=False => the broker doesn't
        expose the check (skip it; backward-compat with a plain KISBroker).
        None with supported=True => a runtime read failure (caller fails safe)."""
        fn = getattr(self.broker, "list_open_order_tickers", None)
        if not callable(fn):
            return None, False
        m = fn()
        if m is None:
            return None, True
        return set(m.keys()), True

    # ===================================================================
    # Arming
    # ===================================================================
    def arm_batch(self, plans, account, session_date: str):
        """Arm a batch of EntryPlans. Applies a LIVE dedup vs broker holdings and
        a cumulative buying-power gate (so the batch as a whole can't over-commit).
        Returns (armed_positions, rejections)."""
        with self._lock:
            armed, rejections = [], []

            truth = self.broker.get_all_holdings()
            held = set(truth) if truth is not None else set()
            if truth is None:
                self.alert("arm: holdings unreadable — proceeding on structural dedup only")

            bp = self._buying_power()
            if self.require_bp and bp is None:
                self.alert("arm: buying power UNKNOWN — refusing to arm (fail-safe). "
                           "Wire a verified buying_power_provider or set "
                           "require_buying_power=False to override.")
                return [], [Rejection(p.ticker, "buying power unknown (fail-safe)") for p in plans]

            # §3.9.1 — resting-order backstop. Closes the crash-orphan double-BUY:
            # an order placed-but-not-logged is invisible to holdings/_pending but
            # shows here. UNKNOWN read is fail-safe (refuse) like the BP gate.
            open_tkrs, oo_supported = self._open_order_tickers()
            if oo_supported and open_tkrs is None:
                if self.require_open_order_check:
                    self.alert("arm: open-order check UNREADABLE — refusing to arm "
                               "(fail-safe). Set require_open_order_check=False to override.")
                    return [], [Rejection(p.ticker, "open-order check unknown (fail-safe)")
                                for p in plans]
                self.alert("arm: open-order check unreadable — proceeding without it (override)")
                open_tkrs = set()
            elif not oo_supported:
                open_tkrs = set()               # plain broker: rely on held|pending only

            usable = (bp * (1.0 - self.cash_buffer_pct)) if bp is not None else None
            committed = 0.0
            pend_tkrs = self._pending_tickers()
            armed_tkrs: set = set()             # intra-batch dedup

            for plan in plans:
                # never re-buy a name we already hold or already own in-flight
                if (plan.ticker in held or plan.ticker in pend_tkrs
                        or plan.ticker in armed_tkrs):
                    rejections.append(Rejection(plan.ticker, "dedup: held/pending at broker"))
                    continue
                # a resting order at the broker for this name: adopt if it's OURS
                # (a prior arm we have a record of -> _arm_one re-adopts idempotently),
                # but REFUSE if we have no record of it (crash-orphan / external order
                # -> placing a second order would double-buy). §3.9.1.
                if (plan.ticker in open_tkrs
                        and self._find_entry_order(plan.order_key) is None):
                    rejections.append(Rejection(plan.ticker,
                        "dedup: untracked resting order at broker (orphan/external — investigate)"))
                    continue
                if usable is not None and committed + plan.est_notional > usable:
                    rejections.append(Rejection(plan.ticker,
                        f"insufficient buying power: need {committed + plan.est_notional:.0f} "
                        f"> usable {usable:.0f}"))
                    continue
                if self._find_entry_order(plan.order_key):
                    # a prior send exists (crash-safe re-arm): adopt the ORDER —
                    # the trade is past the watch stage, exactly as before v2.
                    pos = self._arm_one(plan, session_date)
                    if pos is None:
                        rejections.append(Rejection(plan.ticker, "broker rejected entry order"))
                        continue
                    self._pending.append(pos)
                else:
                    pos = self._watch_one(plan, session_date)
                    if pos is None:
                        rejections.append(Rejection(plan.ticker,
                            "no pivot on plan — cannot watch (fail closed)"))
                        continue
                armed.append(pos)
                armed_tkrs.add(plan.ticker)
                committed += plan.est_notional
            return armed, rejections

    def _arm_one(self, plan: EntryPlan, session_date: str,
                 pos: Optional[Position] = None) -> Optional[Position]:
        """Place (or idempotently re-adopt) ONE entry order. entry_price is set to
        the limit as a PROVISIONAL value; it's finalized to the real VWAP at fill.
        When called from the watch trigger, `pos` is the watch's own Position so
        object identity is preserved across watch -> pending -> filled."""
        key = plan.order_key
        if pos is None:
            pos = Position(
                ticker=plan.ticker, state=PositionState.PENDING_ENTRY, shares=0,
                entry_price=plan.limit_price,           # provisional (finalized at fill)
                stop_loss_price=plan.stop_price,
                initial_risk_per_share=0.0,             # frozen at fill
                exchange=plan.exchange, order_key=key, last_roll_date=session_date)
            pos.live_order_qty = plan.shares

        existing = self._find_entry_order(key)
        if existing:                                # crash-safe: a prior send exists
            pos.live_order_id = existing
            pos.live_order_filled = 0
            pos.live_order_ts = self.clock()
            self.db.log(pos, "ENTRY_ADOPT", plan.limit_price, existing)
            return pos

        # baseline holdings BEFORE this order can fill — lets a later holdings-based
        # confirmation credit only THIS order's fill, not a pre-existing position
        # (§3.9.2). dedup makes this 0 in normal flow; we capture it to be sure.
        baseline = self.broker.get_holding(plan.ticker, plan.exchange)
        res = self.broker.place_limit_order(plan.ticker, plan.shares,
                                            plan.limit_price, "BUY", plan.exchange)
        if res.get("ok") and res.get("order_id"):
            pos.live_order_id = res["order_id"]
            pos.live_order_ts = self.clock()
            self._baseline[key] = baseline
            # idempotency marker (distinct key, excluded from snapshot grouping):
            self.db.log(pos, "ORDER_SENT", plan.limit_price, res["order_id"],
                        key_override=f"{key}:ENTRY")
            # main-key snapshot so recovery rehydrates this PENDING_ENTRY:
            self.db.log(pos, "ENTRY_ARMED", plan.limit_price, res["order_id"])
            if plan.stop_basis.endswith("-only"):
                # make a degraded (anchor-only, no ATR floor) stop LOUD, not silent
                self.alert(f"{plan.ticker}: armed with stop_basis={plan.stop_basis} "
                           f"(ATR unavailable) — stop {plan.stop_price:.2f}")
            return pos
        self.db.log(pos, f"ENTRY_REJECT:{res.get('msg')}", plan.limit_price)
        return None

    def _find_entry_order(self, order_key) -> Optional[str]:
        client_key = f"{order_key}:ENTRY"
        row = self.db.conn.execute(
            "SELECT broker_order_id FROM position_events WHERE order_key=? AND "
            "event_type='ORDER_SENT' AND broker_order_id IS NOT NULL "
            "ORDER BY id DESC LIMIT 1", (client_key,)).fetchone()
        return row[0] if row else None

    # --- PATCH AF (S2 breakout volume) ---
    def breakout_volume_verdict(self, plan) -> tuple:
        """(confirmed, reason). NEVER raises. Every UNKNOWN is a refusal.

        The reason string is the whole point: a breakout held because the feed
        is dead must be distinguishable in the log from one held because the
        volume was genuinely thin. Those are opposite facts about the market.
        """
        avg = 0.0
        try:
            avg = float(getattr(plan, "avg_vol_50", 0.0) or 0.0)
        except (TypeError, ValueError):
            avg = 0.0
        if self.breakout_volume_provider is None:
            return False, ("no breakout volume provider is wired -- cannot "
                           "confirm (build_pipeline(breakout_volume=True))")
        if avg <= 0:
            return False, (f"avg_vol_50 is UNKNOWN (0.0) for {plan.ticker} -- "
                           f"the screener supplied no denominator")
        try:
            vol = self.breakout_volume_provider(plan.ticker, plan.exchange)
        except Exception as ex:
            return False, f"volume read failed: {type(ex).__name__}: {ex}"
        if vol is None:
            return False, "session volume UNKNOWN (the read returned nothing)"
        try:
            vol = float(vol)
        except (TypeError, ValueError):
            return False, f"session volume UNKNOWN (unparseable: {vol!r})"
        need = self.breakout_volume_multiple * avg
        mult = self.breakout_volume_multiple
        if vol < need:
            # NOT a thin market -- a UNITS MISMATCH. The left side is
            # cumulative session volume at an intraday instant; the right is
            # `multiple` x a FULL-DAY average. Measured 2026-09-17: the step
            # lands at the open (no lag) and tvol never resets, so this can
            # never pass minutes into a session, for any ticker, at any
            # multiple. FINDING_20260917_e9_tvol_has_no_lag.
            return False, (f"session-so-far {vol:.0f} vs {mult:g}x DAILY "
                           f"avg_vol_50 {avg:.0f} (={need:.0f}) -- units "
                           f"mismatch, NOT evidence of a weak breakout")
        return True, f"volume {vol:.0f} >= {mult:g}x avg_vol_50 {avg:.0f}"

    def _breakout_held(self, pos, why: str) -> None:
        """Report a held breakout on the 1st and every 20th consecutive poll --
        the same shape as _quote_unknown, and for the same reason: a silent hold
        is indistinguishable from 'the market never reached the pivot'."""
        n = self._vol_held.get(pos.order_key, 0) + 1
        self._vol_held[pos.order_key] = n
        if n == 1 or n % 20 == 0:
            self.alert(f"{pos.ticker} BREAKOUT HELD x{n} — {why}")
    # --- end PATCH AF (S2 breakout volume) ---

    # --- PATCH AK (trigger extension) ---
    def trigger_extension_verdict(self, plan, last: float) -> tuple:
        """How far above the pivot is this trigger, and is that acceptable?

        decision_engine measures extension against last_close when the plan is
        BUILT, at 08:00 ET. The watch then sits armed all session and fires on
        the pivot cross, and nothing re-measures. A name planned 1% extended can
        gap and trigger 12% extended. Same parameter, different instant.

        Returns (ok, why). With max_trigger_extension_pct None the verdict is
        always ok and `why` still carries the number -- the diagnostic is the
        point until the log says what the bar should be."""
        pivot = float(getattr(plan, "pivot", 0.0) or 0.0)
        if pivot <= 0:
            return True, "pivot UNKNOWN -- extension not measurable"
        ext = (float(last) - pivot) / pivot
        cap = self.max_trigger_extension_pct
        if cap is None:
            return True, f"ext {ext:+.2%} (not enforced)"
        if ext > cap:
            return False, (f"too extended at trigger: {ext:+.2%} > "
                           f"{cap:.0%} above pivot {pivot:.2f}")
        return True, f"ext {ext:+.2%} <= {cap:.0%}"
    # --- end PATCH AK (trigger extension) ---

    # ===================================================================
    # Pivot watch — armed intent, order placed only on last >= pivot
    # ===================================================================
    def _watch_one(self, plan: EntryPlan, session_date: str) -> Optional[Position]:
        """Arm ONE plan as a watch: full intent (limit/stop/qty) persisted, NO
        broker order. Fails closed if the plan carries no pivot to watch."""
        if not getattr(plan, "pivot", 0) or plan.pivot <= 0:
            self.alert(f"{plan.ticker}: plan has no pivot — cannot watch (fail closed)")
            return None
        pos = Position(
            ticker=plan.ticker, state=PositionState.PENDING_ENTRY, shares=0,
            entry_price=plan.limit_price,           # provisional (finalized at fill)
            stop_loss_price=plan.stop_price,
            initial_risk_per_share=0.0,
            exchange=plan.exchange, order_key=plan.order_key,
            last_roll_date=session_date)
        pos.live_order_qty = plan.shares
        self._log_watch(pos, f"WATCH_ARMED:pivot={plan.pivot:.4f},basis={plan.stop_basis}",
                        plan.limit_price)
        self.alert(f"{plan.ticker} WATCHING pivot={plan.pivot:.2f} "
                   f"limit={plan.limit_price:.2f} qty={plan.shares} "
                   f"stop={plan.stop_price:.2f}")
        self._watching.append((pos, plan))
        return pos

    def _log_watch(self, pos: Position, event_type: str, price: float):
        """Persist a watch transition under `{key}:WATCH`. The snapshot's state is
        forced to CANCELLED (terminal) ON THE COPY ONLY so load_open_snapshots()
        can never resurrect a watch as a phantom id-less PENDING_ENTRY (which
        adopt()/_on_entry_tick would then kill); the watch's real status is the
        WATCH_* event chain. resolve_orphan stays safe against these snapshots
        because it requires _find_entry_order(main key), which a pre-placement
        watch by definition does not have."""
        snap = replace(pos)
        snap.state = PositionState.CANCELLED
        self.db.log(snap, event_type, price, None,
                    key_override=f"{pos.order_key}:WATCH")

    @staticmethod
    def _parse_watch_meta(event_type: str) -> dict:
        """'WATCH_ARMED:pivot=100.0000,basis=contraction+atr' -> {...}. Missing or
        malformed fields simply drop out; callers fail closed on absent pivot."""
        out = {}
        if ":" not in event_type:
            return out
        for part in event_type.split(":", 1)[1].split(","):
            if "=" in part:
                k, v = part.split("=", 1)
                out[k.strip()] = v.strip()
        return out

    def _watch_tick(self):
        """One pass over active watches. UNKNOWN/zero quote holds (§4.5.3 — a
        failed read is never a trigger). last >= pivot fires exactly once: the
        watch is removed BEFORE placing so no code path can double-place."""
        if not self._watching:
            return
        if not hasattr(self, "_quote_unknown"):
            self._quote_unknown = {}
        for pos, plan in list(self._watching):
            q = self.broker.get_quote(pos.ticker, pos.exchange)
            last = float((q or {}).get("last") or 0)
            if last <= 0:
                # §4.5.3 still holds — a failed read is NEVER a trigger. But a
                # silent hold is indistinguishable from "the market never
                # reached the pivot", which is the exact signal the soak reads.
                # Count consecutive UNKNOWNs and say so ONCE per watch.
                n = self._quote_unknown.get(pos.order_key, 0) + 1
                self._quote_unknown[pos.order_key] = n
                if n == 20:
                    self.alert(f"{pos.ticker} QUOTE UNKNOWN x{n} consecutive "
                               f"(exchange={pos.exchange}) — watch is HELD, not "
                               f"triggered. A wrong exchange code or a dead feed "
                               f"looks identical to 'never reached pivot'. "
                               f"MANUAL CHECK ADVISED.")
                continue
            self._quote_unknown.pop(pos.order_key, None)
            if last < plan.pivot:
                continue
            # --- PATCH AF (S2 breakout volume) --- the comparison ABOVE is
            # deliberately unchanged: `<`, so an exact pivot touch still
            # triggers. The 2026-09-04 draft made it `<=` and broke 29 checks;
            # touch-vs-exceed is a strategy decision, not an operator.
            #
            # This runs only past the pivot, never on an ordinary poll.
            vol_note = ""
            if self.breakout_volume_provider is not None or self.require_breakout_volume:
                v_ok, v_why = self.breakout_volume_verdict(plan)
                if self.require_breakout_volume:
                    if not v_ok:
                        self._breakout_held(pos, v_why)
                        continue
                    vol_note = f" volume-confirmed ({v_why})"
                else:
                    # DIAGNOSTIC ONLY, and permanently so. A non-ok verdict here
                    # is a units mismatch (session-cumulative vs a full-day
                    # average), NOT a statement about the stock -- see
                    # breakout_volume_verdict. The enforcement flag is locked
                    # out in cli.py (E9 LOCKOUT); these lines are NOT a reason
                    # to re-enable it. Minervini's rule is a DAILY-BAR rule and
                    # is a different rule: backtest it with 06_sweep --param
                    # entrystyle, which switches Candidate.trade_signal.
                    vol_note = (" [volume ok: %s]" % v_why) if v_ok else \
                               (" [volume UNITS-MISMATCH: %s]" % v_why)
            self._vol_held.pop(pos.order_key, None)
            # --- end PATCH AF (S2 breakout volume) ---
            # --- PATCH AK (trigger extension) --- P0.3 remnant. Runs only past
            # the pivot. Reuses AF's hold reporter deliberately: both are the
            # same event, "the breakout was reached and not taken", and the
            # volume branch above `continue`s so the two never interleave.
            e_ok, e_why = self.trigger_extension_verdict(plan, last)
            if not e_ok:
                self._breakout_held(pos, e_why)
                continue
            ext_note = f" [{e_why}]"
            # --- end PATCH AK (trigger extension) ---
            self._watching.remove((pos, plan))
            self.alert(f"{pos.ticker} TRIGGERED last={last:.2f} >= pivot="
                       f"{plan.pivot:.2f}{vol_note}{ext_note} — placing BUY "
                       f"{plan.shares}@{plan.limit_price:.2f}")
            placed = self._arm_one(plan, pos.last_roll_date, pos=pos)
            if placed is not None:
                self._pending.append(placed)
                # LOGGED AFTER THE ORDER EXISTS, deliberately. A crash in this
                # window leaves the watch ARMED on disk, and recover_watches
                # closes it idempotently off the ORDER_SENT marker -> the order
                # is adopted. Logging TRIGGERED first (the previous order) meant
                # a crash here left NO watch to restore and NO order to adopt:
                # the breakout was silently lost. Both windows now fail safe.
                self._log_watch(pos, f"WATCH_TRIGGERED:last={last:.4f}", last)
            else:
                self._log_watch(pos, "WATCH_CANCELLED:place_rejected",
                                plan.limit_price)
                # a rejected breakout entry must never be silent
                self.alert(f"{pos.ticker} BREAKOUT LOST — broker rejected the "
                           f"entry order at the trigger; watch abandoned for "
                           f"today (no retry, to avoid a reject loop). "
                           f"MANUAL CHECK ADVISED.")

    def recover_watches(self, session_date: str) -> list:
        """Rehydrate watches after a restart. For each `{key}:WATCH` thread whose
        LATEST event is WATCH_ARMED:
          * order already placed (ORDER_SENT exists for the main key) -> close the
            watch thread idempotently; normal recovery owns the order.
          * stale session -> WATCH_EXPIRED, loud. Watches are day orders.
          * same session -> restore the watch (same trigger, same capped limit).
        Returns the restored list."""
        with self._lock:
            rows = self.db.conn.execute(
                "SELECT order_key, event_type, payload FROM position_events "
                "WHERE id IN (SELECT MAX(id) FROM position_events "
                "WHERE order_key LIKE '%:WATCH' GROUP BY order_key)").fetchall()
            restored = []
            have = ({p.order_key for p, _ in self._watching}
                    | {p.order_key for p in self._pending})
            for _wkey, etype, payload in rows:
                if not etype.startswith("WATCH_ARMED") or not payload:
                    continue
                pos = Position.from_dict(json.loads(payload))
                pos.state = PositionState.PENDING_ENTRY   # snapshot stored terminal
                if pos.order_key in have:
                    continue
                if self._find_entry_order(pos.order_key):
                    self._log_watch(pos, "WATCH_TRIGGERED:recovered(order already "
                                         "placed)", pos.entry_price)
                    continue
                meta = self._parse_watch_meta(etype)
                pivot = float(meta.get("pivot") or 0)
                if pos.last_roll_date != session_date:
                    self._log_watch(pos, f"WATCH_EXPIRED:stale({pos.last_roll_date})",
                                    pos.entry_price)
                    self.alert(f"{pos.ticker} watch EXPIRED — armed for "
                               f"{pos.last_roll_date}, today is {session_date}. "
                               f"Re-screen and re-arm; signals are day orders.")
                    continue
                if pivot <= 0:
                    self._log_watch(pos, "WATCH_EXPIRED:no pivot in record",
                                    pos.entry_price)
                    self.alert(f"{pos.ticker} watch record lacks a pivot — expired "
                               f"(fail closed), investigate")
                    continue
                limit = float(pos.entry_price)
                stop = float(pos.stop_loss_price)
                plan = EntryPlan(
                    ticker=pos.ticker, exchange=pos.exchange, limit_price=limit,
                    shares=int(pos.live_order_qty), stop_price=stop,
                    est_risk_per_share=round(limit - stop, 4),
                    est_notional=round(int(pos.live_order_qty) * limit, 2),
                    rank_score=0.0, atr_mult=0.0, order_key=pos.order_key,
                    stop_basis=meta.get("basis", "contraction+atr"), pivot=pivot)
                self._watching.append((pos, plan))
                restored.append(pos)
                self.alert(f"{pos.ticker} watch RESTORED pivot={pivot:.2f} "
                           f"limit={limit:.2f} qty={plan.shares}")
            return restored

    def expire_watches(self, reason: str) -> int:
        """Expire ALL active watches (session close / operator action). Loud."""
        with self._lock:
            n = 0
            for pos, plan in list(self._watching):
                self._watching.remove((pos, plan))
                self._log_watch(pos, f"WATCH_EXPIRED:{reason}", plan.limit_price)
                self.alert(f"{pos.ticker} watch EXPIRED — {reason} (pivot "
                           f"{plan.pivot:.2f} never triggered)")
                n += 1
            return n

    # ===================================================================
    # Driving pending entries to a confirmed fill
    # ===================================================================
    def poll(self, positions=None) -> list:
        """Advance the watch tick, then every pending entry, one step. Call each
        run-loop cycle while the session is open. Returns the still-pending list."""
        with self._lock:
            self._watch_tick()
            for pos in (positions if positions is not None else list(self._pending)):
                if pos.state == PositionState.PENDING_ENTRY:
                    self._on_entry_tick(pos)
            self._pending = [p for p in self._pending
                             if p.state == PositionState.PENDING_ENTRY]
            return list(self._pending)

    def _on_entry_tick(self, pos: Position):
        if pos.state != PositionState.PENDING_ENTRY:
            return
        if not pos.live_order_id:
            self.alert(f"{pos.ticker}: PENDING_ENTRY with no live order — cancelling")
            self._cancel(pos, "no live order id")
            return

        # 1) POSITIVE-evidence fill count (qty is the authority).
        filled = self.broker.get_fills(pos.live_order_id)
        if filled is None:
            return                                  # UNKNOWN -> hold, never assume
        newly = filled - pos.live_order_filled
        if newly > 0:
            pos.live_order_filled = filled
            self.db.log(pos, "ENTRY_FILL", pos.entry_price, pos.live_order_id)
        target = pos.live_order_qty
        if pos.live_order_filled >= target:
            return self._finalize_fill(pos)         # fully filled -> FILLED

        # 2) partial / none so far -> inspect the book.
        status = self.broker.get_order_status(pos.live_order_id)
        if status == UNKNOWN:
            return
        if status == RESTING:
            pos.awaiting_settle = False
            if ((self.clock() - pos.live_order_ts) >= self.entry_timeout
                    and not pos.cancel_requested):
                self.broker.cancel_order(pos.ticker, pos.live_order_id,
                                         target - pos.live_order_filled, pos.exchange)
                pos.cancel_requested = True
                self.db.log(pos, "ENTRY_TIMEOUT_CANCEL", pos.entry_price, pos.live_order_id)
            return                                  # let cancel/fill resolve next tick

        # status == GONE ---------------------------------------------------
        if pos.cancel_requested:
            # WE cancelled it: fills already counted, remainder genuinely cancelled.
            if pos.live_order_filled > 0:
                return self._finalize_fill(pos)     # partial entry IS a real position
            return self._cancel(pos, "timeout: cancelled, no fill")

        # Uncancelled order left the book: filled vs expired/external-cancel is
        # AMBIGUOUS. Do NOT guess. Open a bounded settle window and resolve from
        # positive evidence (executions catching up, or a holdings increase).
        if not pos.awaiting_settle:
            pos.awaiting_settle = True
            pos.settle_ts = self.clock()
            self.db.log(pos, "ENTRY_SETTLE_WAIT", pos.entry_price, pos.live_order_id)
            return
        held = self.broker.get_holding(pos.ticker, pos.exchange)
        baseline = self._baseline.get(pos.order_key)
        if held is not None and baseline is not None:
            # credit only THIS order's shares: holdings now, minus what the account
            # already held when we armed. A pre-existing same-ticker position can no
            # longer be misread as our fill (§3.9.2). baseline is unknown after a
            # crash (adopt didn't capture it) -> we skip this and rely on executions
            # + the settle timeout, never guessing from raw holdings.
            mine = int(held) - int(baseline)
            if mine > 0:
                pos.live_order_filled = max(pos.live_order_filled, min(mine, target))
                self.db.log(pos, "ENTRY_HELD_CONFIRMED", pos.entry_price, pos.live_order_id)
                return self._finalize_fill(pos)
        if (self.clock() - pos.settle_ts) >= SETTLE_SECS:
            # settle elapsed with no fill evidence -> treat as expiry/cancel.
            if pos.live_order_filled > 0:
                return self._finalize_fill(pos)     # some executions did land
            return self._cancel(pos, "gone + settle: no fill evidence (expired)")
        return                                      # keep waiting for evidence

    # ---- terminal transitions ----
    def _finalize_fill(self, pos: Position):
        """PENDING_ENTRY -> FILLED. Freezes entry_price and initial_risk_per_share
        from the REAL fill, clears entry-order tracking, and hands off to on_fill."""
        qty = pos.live_order_filled
        if qty <= 0:
            return self._cancel(pos, "finalize with 0 fill")

        limit = pos.entry_price                      # provisional (== the BUY limit)
        stop = pos.stop_loss_price
        entry_price = limit                          # conservative default
        vwap = self._fill_vwap(pos.live_order_id)
        if vwap is not None and vwap > stop:         # trust VWAP only if sane vs stop
            entry_price = round(vwap, 2)

        risk = entry_price - stop
        if risk <= 0:
            # Should be impossible: limit = pivot*(1+chase) > base_low ~ stop, and a
            # BUY limit fills at/below the limit. If we somehow land here, fall back
            # to the limit (which is > stop by construction) so R is well-defined.
            entry_price = limit
            risk = entry_price - stop
            self.alert(f"{pos.ticker}: fill price <= stop; using limit {limit} for entry")

        pos.shares = int(qty)
        pos.entry_price = float(entry_price)
        pos.initial_risk_per_share = round(entry_price - stop, 4)   # FROZEN
        pos.state = PositionState.FILLED
        pos.days_held = 0
        # clear all entry-order tracking so the exit monitor starts from clean state
        pos.live_order_id = None
        pos.live_order_qty = 0
        pos.live_order_filled = 0
        pos.live_order_ts = 0.0
        pos.cancel_requested = False
        pos.awaiting_settle = False
        pos.settle_ts = 0.0
        self.db.log(pos, "FILLED", entry_price, None)
        self.alert(f"{pos.ticker} FILLED {qty}@{entry_price:.2f} stop={stop:.2f} "
                   f"R/sh={pos.initial_risk_per_share:.2f} — handing to monitor")
        try:
            self.on_fill(pos)
        except Exception as ex:
            self.alert(f"{pos.ticker}: on_fill handoff error: {ex}")

    def _cancel(self, pos: Position, reason: str):
        pos.state = PositionState.CANCELLED
        pos.live_order_id = None
        pos.live_order_qty = 0
        pos.live_order_filled = 0
        pos.cancel_requested = False
        pos.awaiting_settle = False
        self.db.log(pos, f"ENTRY_CANCELLED:{reason}", pos.entry_price)
        self.alert(f"{pos.ticker} entry CANCELLED — {reason}")

    def resolve_orphan(self, ticker: str, held: int,
                       exchange: Optional[str] = None) -> Optional[Position]:
        """Reconcile a broker holding with NO live local record against our own event
        log. If the newest snapshot for `ticker` is a recent, ARMED entry carrying a
        valid stop, this is a LATE FILL of an order we already ruled expired (the mock's
        fill latency exceeds the settle window). Rebuild the FILLED Position with the
        STOP WE RECORDED — confirmation against our log, not inference — and hand it to
        on_fill so the exit monitor manages it (and arms the stop). Returns the adopted
        Position, or None if there's no matching armed record / it's too stale / it lacks
        a usable stop; in those cases the caller keeps its alert-only behaviour.
        Wired into ExecutionMonitor via orphan_resolver, so it fires on recover() AND on
        the periodic/watchdog reconcile — a late fill gets a stop without a restart."""
        if held <= 0:
            return None
        snap = self.db.last_entry_snapshot(ticker)
        if snap is None:
            return None                          # no record at all -> genuine unknown
        prior, age_days = snap

        armed_id = self._find_entry_order(prior.order_key)
        if armed_id is None:
            return None                          # never actually placed -> not our fill

        stop = float(prior.stop_loss_price or 0.0)
        limit = float(prior.entry_price or 0.0)
        if stop <= 0 or limit <= stop:
            self.alert(f"orphan {ticker}: armed record lacks a usable stop "
                       f"(entry={limit} stop={stop}) — NOT adopting, investigate")
            return None
        if age_days > self.orphan_adopt_max_age_days:
            self.alert(f"orphan {ticker}: newest armed record is {age_days:.1f}d old "
                       f"(> {self.orphan_adopt_max_age_days}d) — NOT adopting, investigate")
            return None

        # Entry price: prefer real VWAP if the broker still reports the order's fills,
        # else the BUY limit. The limit is >= the actual fill for a marketable BUY, so
        # using it only UNDER-states R (conservative); the stop is unaffected either way.
        entry_price = limit
        vwap = self._fill_vwap(armed_id)
        if vwap is not None and vwap > stop:
            entry_price = round(vwap, 2)
        risk = round(entry_price - stop, 4)

        armed_qty = prior.live_order_qty or 0
        if armed_qty and held != armed_qty:
            self.alert(f"orphan {ticker}: broker qty {held} != armed qty {armed_qty} — "
                       f"adopting broker truth (exit sells are clamped to holdings)")

        pos = Position(
            ticker=ticker, state=PositionState.FILLED, shares=int(held),
            entry_price=float(entry_price), stop_loss_price=stop,
            initial_risk_per_share=risk,
            exchange=(exchange or prior.exchange or "NAS"),
            days_held=0, last_roll_date=prior.last_roll_date or "",
            order_key=prior.order_key)
        self.db.log(pos, f"ENTRY_LATE_FILL_ADOPTED:held={held},armed={armed_qty},"
                         f"age={age_days:.2f}d", entry_price, armed_id)
        self.alert(f"{ticker} LATE FILL ADOPTED {held}@{entry_price:.2f} stop={stop:.2f} "
                   f"R/sh={risk:.2f} (armed order {armed_id}) — handing to monitor")
        try:
            self.on_fill(pos)
        except Exception as ex:
            self.alert(f"{ticker}: on_fill (orphan adopt) handoff error: {ex}")
        return pos

    def _fill_vwap(self, order_id) -> Optional[float]:
        """Best-effort average fill price. Uses broker.get_fills_detail if present;
        returns None otherwise (finalize then falls back to the limit)."""
        fn = getattr(self.broker, "get_fills_detail", None)
        if not callable(fn):
            return None
        d = fn(order_id)
        if not d:
            return None
        _qty, vwap = d
        return vwap if vwap and vwap > 0 else None

    # ===================================================================
    # Crash recovery — RE-ADOPT resting entries, resolve once. NEVER re-place.
    # ===================================================================
    def adopt(self, pending_positions) -> list:
        """Take rehydrated PENDING_ENTRY snapshots (from the event store) and
        resolve each against the broker exactly once. H2: rebase monotonic timers
        so the first post-recovery tick sees a sane elapsed. Returns those still
        pending (RESTING / awaiting more fills); FILLED ones are handed off via
        on_fill, CANCELLED ones dropped."""
        with self._lock:
            now = self.clock()
            adopted = []
            for pos in pending_positions:
                if pos.state != PositionState.PENDING_ENTRY:
                    continue
                if pos.live_order_id:
                    pos.live_order_ts = now
                    if pos.awaiting_settle:
                        pos.settle_ts = now
                    self._on_entry_tick(pos)         # resolve against the broker
                else:
                    self._cancel(pos, "recovered PENDING_ENTRY without order id")
                if pos.state == PositionState.PENDING_ENTRY:
                    adopted.append(pos)
            # merge into ownership without duplicating by order_key
            have = {p.order_key for p in self._pending}
            for p in adopted:
                if p.order_key not in have:
                    self._pending.append(p)
            return adopted

    # ---- buying power ----
    def _buying_power(self) -> Optional[float]:
        if not self._bp_provider:
            return None
        try:
            bp = self._bp_provider()
        except Exception as ex:
            self.alert(f"buying_power_provider error: {ex}")
            return None
        if bp is None:
            return None
        try:
            return float(bp)
        except (TypeError, ValueError):
            return None


# =====================================================================
# Optional broker extensions (NEW I/O — VERIFY before live trust)
# =====================================================================
# These add the two reads the entry half would *like* but does not NEED for
# safety (fill price for a better entry_price; cash for the buying-power gate).
# They are on a SUBCLASS so engine_v2.KISBroker stays pristine/verified. Run
# them through kis_contract_verify.py (§7.3) before trusting them live; until
# then EntryManager degrades safely (limit-as-entry_price; fail-safe on cash).

class KISBrokerWithEntry(KISBroker):
    def get_fills_detail(self, order_id):
        """(cumulative_filled_qty, vwap) for one order, or None on UNKNOWN.
        Same inquire-ccnl contract as get_fills, but also reads the execution
        price. # VERIFY the price field name against a real fill."""
        from kistrader.core.engine_v2 import TR_FILLS_MOCK, TR_FILLS_LIVE
        tr = TR_FILLS_MOCK if self.is_mock else TR_FILLS_LIVE
        today = time.strftime("%Y%m%d")
        pdno = "" if self.is_mock else "%"
        excg = "" if self.is_mock else "NASD"
        res = self._request("GET",
            f"{self.base_url}/uapi/overseas-stock/v1/trading/inquire-ccnl",
            headers=self._headers(tr),
            params={"CANO": self.cano, "ACNT_PRDT_CD": self.acnt_prdt_cd,
                    "PDNO": pdno, "ORD_STRT_DT": today, "ORD_END_DT": today,
                    "SLL_BUY_DVSN": "00", "CCLD_NCCS_DVSN": "00",
                    "OVRS_EXCG_CD": excg, "SORT_SQN": "DS",
                    "ORD_DT": "", "ORD_GNO_BRNO": "", "ODNO": "",
                    "CTX_AREA_FK200": "", "CTX_AREA_NK200": ""})
        if self._failed(res):
            return None
        tot_qty, tot_val = 0, 0.0
        for row in (res.get("output") or []):
            if str(row.get("odno")) != str(order_id):
                continue
            q = int(row.get("ft_ccld_qty", row.get("ccld_qty", 0)) or 0)
            # # VERIFY: execution unit price field on overseas inquire-ccnl
            px = float(row.get("ft_ccld_unpr3", row.get("ft_ccld_unpr", row.get("ccld_unpr", 0))) or 0)
            tot_qty += q
            tot_val += q * px
        if tot_qty <= 0:
            return (0, 0.0)
        return (tot_qty, tot_val / tot_qty)

    def list_open_order_tickers(self) -> Optional[dict]:
        """{TICKER -> [order_id, ...]} for every RESTING (unfilled) order on the
        account, or None on any transport/API failure (== UNKNOWN, caller must
        fail safe). This is the backstop that closes the crash-orphan double-BUY
        window (§3.9.1): an entry order that was placed but whose DB log never
        committed is invisible to holdings and to _pending, but it IS visible
        here as a resting order.

        Contract reuse: same endpoint/container as get_order_status (inquire-nccs,
        res['output'], row['odno']) — that odno parsing is already verified. The
        ticker is row['pdno'], the SAME field place_limit_order sends as PDNO, so
        the ticker read inherits that verification. Paginated like _balance_rows
        because MISSING a resting order is exactly the failure we're preventing."""
        from kistrader.core.engine_v2 import (TR_UNFILLED_MOCK, TR_UNFILLED_LIVE,
                               MAX_BALANCE_PAGES)
        tr = TR_UNFILLED_MOCK if self.is_mock else TR_UNFILLED_LIVE
        out: dict = {}
        fk, nk, cont = "", "", ""
        for _ in range(MAX_BALANCE_PAGES):
            res, resp_cont = self._request_paged("GET",
                f"{self.base_url}/uapi/overseas-stock/v1/trading/inquire-nccs",
                headers=self._headers(tr, cont),
                params={"CANO": self.cano, "ACNT_PRDT_CD": self.acnt_prdt_cd,
                        "OVRS_EXCG_CD": "NASD", "SORT_SQN": "DS",
                        "CTX_AREA_FK200": fk, "CTX_AREA_NK200": nk})
            if self._failed(res):
                return None                      # UNKNOWN — do not report a partial view
            for row in (res.get("output") or []):
                tkr = str(row.get("pdno", "")).strip().upper()   # pdno == PDNO (ticker)
                oid = str(row.get("odno", "")).strip()
                if tkr and oid:
                    out.setdefault(tkr, []).append(oid)
            if resp_cont not in ("F", "M"):      # no more pages
                return out
            fk = (res.get("ctx_area_fk200") or "").strip()
            nk = (res.get("ctx_area_nk200") or "").strip()
            cont = "N"
        return out                               # page cap hit; return what we have


def make_kis_buying_power_provider(broker: KISBroker, excg="NASD",
                                   fallback_item="AAPL", alert=None):
    """Reference buying-power provider (USD). Returns a closure () -> Optional[float].
    # VERIFY heavily: KIS overseas 'inquire-psamount' is per-item and its TR id /
    # field names must be confirmed against the examples repo before live trust.
    Until verified, prefer injecting your own provider; on ANY failure this
    returns None so EntryManager fails safe (refuses to arm)."""
    TR_PSAMT_MOCK, TR_PSAMT_LIVE = "VTTS3007R", "TTTS3007R"    # # VERIFY

    # A None from here becomes a BATCH-WIDE refusal in arm_today, so the
    # reason is worth more than the policy message that follows it. Measured
    # 2026-09-16: three refusals (09-08, 09-10 cost MPC, 09-15 cost HALO)
    # were all HTTP_TIMEOUT truncating a healthy call, and each took a live
    # probe to explain days later. Never raises: a broken alert must not
    # turn a refusal into a crash.
    def _say(msg: str) -> None:
        if alert:
            try:
                alert(msg)
            except Exception:                             # noqa: BLE001
                pass

    def _provider() -> Optional[float]:
        try:
            tr = TR_PSAMT_MOCK if broker.is_mock else TR_PSAMT_LIVE
            res = broker._request("GET",
                f"{broker.base_url}/uapi/overseas-stock/v1/trading/inquire-psamount",
                headers=broker._headers(tr),
                params={"CANO": broker.cano, "ACNT_PRDT_CD": broker.acnt_prdt_cd,
                        "OVRS_EXCG_CD": excg, "OVRS_ORD_UNPR": "0",
                        "ITEM_CD": fallback_item})          # # VERIFY param set
            if broker._failed(res):
                _say("buying power: inquire-psamount failed "
                     "(rt_cd=%s transport=%s): %s"
                     % (res.get("rt_cd"), bool(res.get("_transport_error")),
                        str(res.get("msg1") or "")[:160]))
                return None
            out = res.get("output", {}) or {}
            # # VERIFY: the USD orderable-amount field name
            for k in ("ord_psbl_frcr_amt", "frcr_ord_psbl_amt1", "ovrs_ord_psbl_amt"):
                if k in out:
                    return float(out[k] or 0)
            _say("buying power: none of the expected USD fields are in "
                 "inquire-psamount output; got %s" % (sorted(out.keys())[:12],))
            return None
        except Exception as ex:                           # noqa: BLE001
            _say("buying power: provider raised %s: %s"
                 % (type(ex).__name__, str(ex)[:160]))
            return None
    return _provider
