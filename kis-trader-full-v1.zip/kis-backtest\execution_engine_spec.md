# Execution Engine — Design Spec (v1-full)

This is the fixed contract for the execution layer that sits on top of the existing
3-stage screener. Every decision below carries its rationale so it doesn't get
relitigated later. Numbers are starting values for the mock forward test; the **v2
Roadmap** at the end lists what gets tuned with the data this test produces.

The engine has three parts. The most important framing point up front:

> **Part 3 is not last.** Because KIS's US Open API is limit-only and (pending
> verification) has no native resting stop, both entries and stops are *emulated* by
> a price monitor running during US hours (~23:30–06:00 KST, while you sleep). The
> monitor **is** the execution layer, not a safety bolt-on. So a minimal fail-safe
> (persistent state + restartable monitor) is a *prerequisite* for Part 1's order
> semantics. Decide the fail-safe architecture now; build it in tandem with the broker.

---

## Upstream context (already built — verify, don't rebuild)

```
Universe → Stage 1 (8 Trend Template, pass/fail)
        → Stage 2 (Hybrid Catalyst, score)
        → Stage 3 (VCP engine, pass/fail)   ← qualification gate only
        → [EXECUTION ENGINE]
```

- **RS Rating**: IBD-style two-pass percentile, recency-weighted
  (0.4×3mo + 0.2×6mo + 0.2×9mo + 0.2×12mo), threshold ≥ 70, per-universe benchmarks.
- **VCP is a binary gate**, never a ranking input — it answers "is this a valid base,"
  not "how good," so forcing it into a score would only add noise.
- **TODO / verify before building**: confirm the Stage 2 → Stage 3 handoff actually
  passes data. The execution engine consumes Stage 3 output; if that wire is missing,
  nothing downstream runs.

---

## PART 1 — Decision Engine (pure functions, testable today)

All of Part 1 is deterministic functions over the pipeline's output schema. Build and
unit-test these first, against real screener output, before any broker code exists.

**Core architectural shift (v1-full):** rank *selects and orders*; **risk *sizes*.**
Position size is no longer rank-weighted — it's set by equal-R sizing. Rank only decides
*which* names and *in what priority* they fill the budget.

### 1.1 Market Regime Filter (the missing pillar — now mandatory)

- **Rule**: per-universe 50/200 MA gate. A universe is "risk-on" only when its index is
  above its 50-day MA **and** 50-day > 200-day.
- **Why it's not redundant with the 8 conditions**: the 8 are per-*stock* (selection);
  the regime gate is per-*market* (deployment). A leader can pass all 8 of its own
  conditions while its index rolls over — that's literally what a market top looks like.
  The 8 conditions structurally cannot emit "hold cash"; something must set total
  exposure. This is O'Neil's **M (Market Direction)** / Minervini's market-timing overlay
  — a separate pillar the framework already assumes.
- **Per-universe** because S&P 500, US small/mid, MSCI ex-US (EFA), and Korea can be in
  different regimes simultaneously. Benchmarks are already wired per universe.
- **It defines D** (deployment ceiling, §1.3). Delete it and the allocation budget
  becomes undefined. Not optional.

### 1.2 Ranking

- **RS Percentile**: universe-wide (existing).
- **Stage 2 Percentile**: computed across **all Stage-2-scored names** (same
  universe-wide reference frame as RS), *not* among VCP survivors only — a percentile
  over N=4 survivors is degenerate.
  - **Fallback**: if fewer than ~6 names clear all three stages, skip percentiles
    entirely and rank survivors by raw `2×RS + Stage2`.
- **Portfolio Rank Score** = `2 × RS_percentile + Stage2_percentile` (max 300).
- **Tie-break**: higher RS wins (RS is the declared primary factor).
- Only the *ordering* matters; the absolute score has no intrinsic meaning.

### 1.3 Allocation & Sizing (R-based)

Two ceilings and one sizing rule. **Both ceilings are required** — regime gating sets the
*level* of the budget; normalization keeps the *sum* under it. Neither alone bounds
exposure (8 names × 20% = 160% if you skip normalization).

- **Concentration `N_max = 8`**. More positions → more trades → more forward-test data.
  Concentrate to 5 only once the system is trusted.
- **Deployment ceiling `D`**: regime-gated. `D = 100%` only when that universe is risk-on;
  scaled down (e.g. 50%) or 0 otherwise. **`D` is a ceiling, not a target** — with the
  20% per-name cap, fewer than 5 qualifiers means you *cannot* be fully invested
  (3 × 20% = 60% max). Idle cash on thin days is the design working, not a bug.
- **Per-name cap**: 20% of equity (a backstop — see note below on why it's slack at
  these params).
- **Equal-R sizing** — the heart of v1-full:
  - Risk a fixed fraction `R` of equity per trade. **`R = 0.75%`** to start.
  - **ATR stop width — adaptive multiplier, tied to base tightness** (Issue 1):
    `stop_dist = clamp( m × ATR(14), 5%, 8% )` of entry price, where the multiplier `m`
    is a **function of the VCP final-contraction depth** (already computed by the VCP
    engine), not a fixed guess and not a free per-stock number:
    - `m = clamp( map(final_contraction_depth → multiplier), 1.3, 2.5 )`
    - Tight base (final contraction ~3–5%) → snug `m ≈ 1.3`: a move past that genuinely
      breaks the thesis, so don't give it slack.
    - Loose base (final contraction ~8–12%) → wide `m ≈ 2.2–2.5`: or you get noise-stopped.
    - Suggested linear map: `m = 1.3 + (depth − 0.03)/(0.12 − 0.03) × (2.5 − 1.3)`,
      clamped — i.e. interpolate 1.3→2.5 as depth runs 3%→12%. Tune the endpoints with
      forward-test data.
    - Rationale: `m` is anchored to *actual base structure* rather than a constant or a
      vibe. **The absolute clamp on `stop_dist` ([5%, 8%]) stays** — a pathologically
      loose base can't manufacture a huge stop; it just gets a tiny position or skips,
      so per-name risk is still bounded.
  - `shares = floor( (R × equity) / (stop_dist_per_share) )`.
  - Consequence: wider stop (volatile name) → smaller position; both risk the *same
    dollars*. This is what makes volatile winners *safe* — room to breathe on the stop,
    less capital so swings don't dominate the account. If a name needs > 8% to avoid
    being noise-stopped, it gets a tiny position or hits the skip rule — Minervini's
    "shrink size or pass when volatility is too high," not "widen the stop recklessly."

- **Fill algorithm** (reconciles rank-selects with risk-sizes):
  1. Compute regime per universe → `D`.
  2. Rank qualified names; take top `N_max`.
  3. Walk the queue **in rank order**; size each by equal-R (capped at 20%).
  4. Accumulate until the budget is used: if the next name's size exceeds the remaining
     `D` budget, take `min(equalR_size, remaining_budget)` for that name, then stop.
     (A truncated last name is *under*-risked, which is fine — risk only goes down.)
  - Guarantees: `Σ size ≤ D`, each name ≤ its equal-R risk, each ≤ 20%, count ≤ `N_max`.
  - **Truncation tagging** (Issue: hit-rate/P&L decoupling): a budget-truncated position
    risks *less* than R (a 15%-equal-R name squeezed into 5% leftover budget risks ~0.25%,
    not 0.75%). Mathematically safe, but it **decouples win-rate from dollar P&L** — and the
    truncated names are non-random (they're the *lowest-ranked* survivors, since they're last
    in the fill queue), so they're a lower-quality, under-weighted slice. Two safeguards:
    - **Tag truncated fills** with a boolean in the event log so forward-test stats can be run
      with and without them (confirm the tail isn't secretly carrying or hiding the edge).
    - **Judge on R, not raw win-rate**: report **average R and expectancy**
      (`win% × avgWinR − loss% × avgLossR`). R-multiples are size-invariant, so a truncated
      +3R is still +3R and the decoupling mostly vanishes. (This is one more reason the whole
      spec measures in R.)

- **Skip rule**: if one share's cost > 20% × equity, or the computed size rounds to 0
  shares, don't buy. Fractional shares not permitted.

> **Internal-consistency note**: at `R = 0.75%` with a 5% stop floor, max position =
> `0.75/5 = 15%`, so the 20% per-name cap never binds — the binding constraints are
> equal-R (per name) and `D` (on the sum). The 20% cap is a guardrail that only
> activates if you later raise `R` above ~1.0% or lower the stop floor. This is
> expected; it means the numbers cohere.

### 1.4 Entry / Order Generation

- **Emulated buy-stop**: monitor price; when it crosses `Pivot × 1.0025`, fire a **LIMIT**
  buy at `Pivot × 1.0025 × 1.02`. That single limit enforces **both** the breakout
  trigger and the 2% max-chase cap, and sits well inside KIS's ±10% band.
  - A resting limit-*buy* cannot emulate a stop (a limit above market fills immediately
    at the lower market price — wrong side), which is *why* the monitor is mandatory.
- **TIF**: day-only, re-armed each session if the name is still in a readiness tier.
  (You want the breakout *today* on volume, not a stale multi-day fill on a weak poke.)
- **Volume**: trigger on **price only** (engineering-stable — estimating full-day volume
  from a partial morning session is noisy). **But log** volume-at-trigger and EOD volume
  vs the 50-day average. Minervini wants the breakout on volume ~+40–50% above average;
  this lets the forward test *measure* whether a volume gate helps instead of assuming.
- **Free protection**: a volatile name that gaps > 2% over the pivot at the open won't
  fill (the +2% limit can't reach it) — the most extended, most dangerous entries
  auto-skip.

### 1.5 Exits — countable triggers

Keeping exits to a small set of countable reasons is what keeps forward-test attribution
readable. v1 has four: stop / stall / **3R partial** / **trail** (the last two are the two
legs of one runner, so attribution stays clean).

> **How an emulated exit is *priced* (Issue: gap-down)** — every exit below is a *signal*
> ("get out"); pricing it is a separate problem, because KIS is limit-only. A limit at the
> stale stop level (e.g. $90 when the stock opened at $80) is a buy-side order above the
> market — it sits on the book and **never fills**, so the "stop" is fiction. The exit must
> cross the spread:
> - Price off the **live bid**, not the stop level: `limit = current_bid × (1 − slip)`,
>   `slip ≈ 1–2%` (marketable limit — accept slippage to *guarantee* the exit).
> - **Re-pricing loop, not fire-and-forget** (this is what makes it unattended-safe): send →
>   if unfilled after N seconds, `cancel` and re-send at the new (lower) bid → repeat, with
>   a hard cap on attempts. In a fast tape the bid keeps dropping; a single marketable limit
>   can be left behind, and an unattended system can't notice a partial/zero fill on its own.
> - **Clamp to KIS's ±10% band** so the aggressive limit isn't venue-rejected.
> - **Structural honesty**: even priced perfectly you fill near the *opened* price, not the
>   stop. `−1R` holds only in calm tape; on a gap the realized loss is `−2R`/`−3R`/whatever
>   the gap is. This is not codable away — it's the cost of no native stop, and the single
>   biggest reason the §2 native-stop verification is the highest-leverage unknown. If KIS
>   exposes a real resting stop, this entire pricing loop disappears.

- **Initial stop**: `−1R` = the ATR stop distance from §1.3, off the *filled* entry. The
  stop is a *trigger level* watched by the monitor; when price closes/trades through it the
  monitor fires an exit **priced by the marketable-limit loop above**, not a resting limit
  at `−1R`.
- **Trail (middle-game) — closes the "Purgatory" round-trip hole** (Issue): a position can
  survive the day-10 stall (it's positive, ≥ ~1R) yet sit at, say, +1.5R for days with the
  3R partial not yet hit — under the original design *nothing* governed it but the −1R hard
  stop, so a market roll-over could ride it all the way from +1.5R back to −1R (the most
  demoralizing loss pattern there is). Fix: **the EMA trail arms for *any* positive position
  once it has passed the day-10 stall window**, not only after the 3R partial. So:
  - Pre-day-10, below +1R → the **stall clock** governs.
  - **Day-10+, any positive position → EMA trail is active** (exit on a decisive close below
    the 21-day EMA), regardless of whether +3R has been reached.
  - This collapses the middle game into the trail you already designed — no new mechanism,
    just a wider *arming* window. (Chosen over a fixed "+2R → breakeven" because that still
    leaves a dead band below 2R that can bleed to −1R; trailing every survivor leaves no
    band.)
  - **Precedence around day 10** (so two rules can't fire on one bar): the stall check runs
    first on the day-10 close; if the position survives, the trail takes ownership from the
    *next* session onward.
- **Profit handling — 3R partial + EMA-trailed remainder** (Issue 4): a single `3R` cap is
  the biggest *signal* weakness in the system. A leader that runs 6R / 9R / 15R / 20R and
  gets sold at 3R doesn't just underperform — it breaks the **math**, because the fat
  right tail is what pays for the pile of `−1R` losers. A hard `3R` cap structurally caps
  expectancy at mediocre no matter how good the selection. So instead of capping:
  - At **`+3R`**: sell a **partial** (⅓–½ of the position) to lock realized R and cut open
    risk. Move the stop on the remainder to **breakeven** at this point.
  - **Trail the remainder** beneath the **21-day EMA** (10-day if you want it tighter);
    exit the rest on a **decisive close below**. This lets the winner run to 6R+ while the
    early partial has already de-risked the trade.
  - Why this is v1, not deferred to v2: it's the same EMA-trail you'd build for v2 anyway,
    and a `3R` partial + EMA-trailed remainder is still only two exit reasons on the
    runner — readable. The *pure* trail (no partial) and tuning the EMA length stay v2,
    placed with logged data.
  - Calm vs volatile is still handled automatically: `3R` ≈ +15% on a calm name, ≈ +24%
    on a volatile one (wider stop → wider R), so the partial scales with the stock's own
    volatility.
- **Stall exit** (time axis): if the position is **below ~1R at the day-10 close**, sell
  **next session's open**.
  - Threshold in **R** (volatility-adjusted: calm bar ~5%, volatile bar ~8%); **clock
    fixed in sessions** (~10 trading days — time-to-follow-through is a strategy constant,
    don't volatility-adjust both axes or you over-fit).
  - Measured on **closes**, executed **next open** — this is the *only* buffer, and it's
    free: a single intraday wick can't trigger an exit, and the stock gets one more close
    to redeem itself.
  - **No tolerance/grace band.** The horizon N already *is* the grace period; a band on
    top reintroduces the dead-money slot occupancy the rule exists to kill and forks the
    exit accounting.
  - Note: the stall only applies *before* the `+3R` partial. Once a position has taken its
    3R partial and is trailing, it's a confirmed winner and is governed by the trail, not
    the stall clock.
  - Rationale: a clean VCP breakout is institutional accumulation in motion; no
    follow-through within ~2 weeks means the base is failing in slow motion. Frees the
    slot; never touches a real winner (anything up 20% in a week obviously isn't stalling).

- **Additive-only** portfolio: held names exit only via the three triggers; new buys fill
  leftover slots. **No daily rebalance** — matches "let winners run," avoids turnover from
  re-ranking noise. (Caveat: a stagnant name that never hits stop/target/stall still
  occupies a slot — a capital-efficiency leak, not a risk hole. The stall exit mostly
  handles it; v2 tightens it.)

### 1.6 Position State Machine (the real heart of the engine)

The three edge-case fixes above (gap-down pricing, Purgatory trail, truncation) all live in
the **monitor**, not the strategy — which is the tell that the actual engine is an
order-management state machine, not a screener. The strategy fits on a page; faithfully
executing it under a limit-only broker with no native stop, while you sleep, is 80% of the
work. Every position is exactly one state at all times; the monitor's job each cycle is to
evaluate the current state's exit/transition conditions and act.

**States and transitions:**

```
                          ┌──────────────────────────────────────────────┐
                          │                                              │
   (ranked, sized)        ▼                                              │
   ─────────────► PENDING_ENTRY ──fill──► FILLED ──day-10 close survives──┤
                     │                      │                            │
            day-only TIF expires      below +1R @ day-10                 │
            or chase unmet                  │                           ▼
                     │                      ▼                       TRAILING ──┐
                     ▼                  EXITING (stall) ◄──┐         │  ▲       │
                  CANCELLED                 │             │   +3R reached      │
                     │                      │        below 21EMA close /       │
                     ▼                      ▼         stop hit  │     │ remainder
                  CLOSED                  CLOSED ◄──────────────┴─────┘  trails
                                            ▲                  PARTIAL_TAKEN ───┘
                                            │   (⅓–½ sold, breakeven stop,
                  any state, −1R hit ───────┘    remainder → TRAILING)
```

| State | Meaning | Monitor watches for | → goes to |
|---|---|---|---|
| `PENDING_ENTRY` | sized, breakout limit armed (`Pivot×1.0025×1.02`, day-only) | fill / TIF expiry / chase unmet | `FILLED` or `CANCELLED` |
| `CANCELLED` | entry never filled this session | (re-arm next session if still in readiness tier) | `CLOSED` or back to `PENDING_ENTRY` |
| `FILLED` | in position, pre-day-10, governed by stall clock + −1R stop | −1R stop trigger / day-10 close below +1R / day-10 survive / +3R | `EXITING` / `TRAILING` / `PARTIAL_TAKEN` |
| `TRAILING` | day-10 survivor (any positive), trailing 21-EMA, −1R still under | decisive close < 21EMA / −1R / +3R | `EXITING` / `PARTIAL_TAKEN` |
| `PARTIAL_TAKEN` | +3R partial sold, remainder trailing, stop at breakeven | decisive close < 21EMA / breakeven stop | `EXITING` |
| `EXITING` | exit signal fired; **marketable-limit re-pricing loop running** (§1.5) | fill confirmation / re-price timeout → cancel+resend | `CLOSED` |
| `CLOSED` | flat; event log finalized for the trade | — | terminal |

**Invariants that make it survive unattended** (these are *not* optional decoration — they
are the difference between "runs my logic" and "safe to leave alone overnight"):

- **The −1R hard stop is checked in *every* live state** (`FILLED`, `TRAILING`,
  `PARTIAL_TAKEN`) — it's the floor under the whole machine, never disarmed until `CLOSED`.
- **One state per position, persisted in the SQLite event log** (§3) on every transition, so
  a crash-restart rebuilds exact state by replay — no position is ever in an ambiguous limbo.
- **`EXITING` is idempotent**: the deterministic order key (§3) means a crash mid-loop
  resumes the *same* exit, never double-fires a sell.
- **On boot, reconcile before transitioning**: pull KIS's real positions/orders (broker is
  truth, §3), match against the persisted state, *then* let the machine resume — a fill that
  happened during a crash window is absorbed, not missed.
- **Precedence is explicit** (no double-fire on one bar): on the day-10 close the stall check
  runs *before* the trail takes ownership; the −1R stop, being a trade-through, preempts all
  close-based rules within a bar.

---

## PART 2 — Broker Layer (KIS)

- **Repo**: `koreainvestment/open-trading-api` → folders `examples_llm/overseas_stock`
  (single-function files) and `examples_user/overseas_stock` (integrated). Working US
  reference: `geongi-im/kis-us-auto-trading` (order tracking, US market-hours mgmt,
  WebSocket).
- **Auth**: OAuth2 — appkey/secret → access token (~24h validity), refresh before expiry.
- **Cash only — NO CREDIT.** Buying power = settled cash; no margin math; automatically
  consistent with `D ≤ 100%`. KIS US auto-settles and permits 재매매 (trade before
  settlement), so a cash account won't hit US-domestic-style good-faith/freeride
  violations — sell A / buy B same session is fine.
- **USD-funded**: book everything in USD; **pre-fund USD** so each trade isn't a fresh
  KRW→USD conversion (avoids the 통합증거금 per-trade spread). FX is out of engine scope —
  it's a won-vs-dollar question, not an engine question.
- **Order types**: limit only (KIS has no US market order regardless).
- **Constraints**: orders rejected if > ~±10% from current price; **rate limit
  ~20 calls/sec**.
- **Monitor feed**: use the **WebSocket real-time feed** (pushes fills + quotes), not REST
  polling — sidesteps the 20/sec cap and makes the monitor event-driven and robust.
- **Reserved orders (예약주문)** exist for pre-session placement if needed.

> ### ⚠ The one verification that flips half the fail-safe design
> Before building, confirm in the KIS `overseas_stock` order spec whether US trading
> supports **any native stop / conditional order** via the API (they have been adding
> overseas conditional features; current state unknown).
> - **If yes** → rest the protective stop at the broker; the dead-man problem mostly
>   dissolves (protection no longer depends on your monitor surviving the night).
> - **If no** → the monitor is your *only* protection; monitor uptime must be engineered
>   hard before any live capital. Everything in §3 dead-man hinges on this answer.

---

## PART 3 — Fail-safe (decide architecture now, build with Part 2)

- **Source of truth on restart**: **broker is truth; the DB is intent/cache.** On boot,
  pull KIS's actual balance + open orders, diff against what the DB expected, reconcile,
  *then* act. This is what prevents double-orders and orphaned positions.
- **State store**: **SQLite as an append-only event log** — one immutable table of every
  intent / ack / fill / cancel, plus a derived positions table rebuildable by replay.
  Single file, ACID, perfect for reboot-and-continue, full audit trail for debugging.
- **Idempotency**: deterministic order key per `ticker+date+intent`, persisted
  **pre-send**; on restart, check whether that key already has a broker ack before
  resending.
- **Dead-man protection**: heartbeat. For **mock money**, a dead monitor costs a data
  point, not money — acceptable, don't lose sleep over it now. Before **live capital**
  it's unresolved, and the fix is **monitor uptime**, not a louder alarm (an email won't
  wake you at 3am — correct, so don't rely on alerting as protection). Uptime =
  Naver Cloud + systemd + watchdog, *plus* the native-stop verification above.
- **Hosting**: **Naver Cloud** — in Korea, so low latency to KIS and no cross-border
  weirdness. An always-on VM ≠ an always-on process: run the monitor under **systemd**
  (restart-on-crash) with a **watchdog**. Confirm outbound egress is open to both KIS and
  the US data sources the screener uses.
- **Reporting (so you never log in daily)**: a pushed **daily/weekly digest** read from
  the event log — fills, P&L, errors → Telegram/email. The system reports to you; you
  don't go look.

---

## Build sequence

1. **Lock this spec** (done).
2. **Part 1 decision engine** as pure functions — ranking, regime gate, budget allocation,
   equal-R sizing, exit logic — unit-tested against real screener output. No broker needed.
3. **Verify** the KIS native-stop question (§2 warning) and the Stage 2→3 handoff.
4. **Part 2 broker layer**: quotes + limit orders + balance, from `overseas_stock` examples.
5. **Part 3 fail-safe monitor** (SQLite event log + reconciliation) — built *in tandem*
   with Part 2.
6. **Wire monitor → WebSocket** feed.
7. **Forward test** ~3 months on KIS 모의투자 (mock). Measure everything in **R** (so
   expectancy is comparable across calm and volatile names). Then set v2 knobs from data.

---

## v2 Roadmap (tune with forward-test data — do not guess now)

- **Trail refinement** (the partial + EMA-trail hybrid itself is now **v1**, §1.5): tune
  the EMA length (21 vs 10), the partial fraction (⅓ vs ½), and test a *pure* trail with
  no partial — all placed with logged price/volume data once the forward test shows how
  the runners actually behave.
- **Volume gate at trigger** — enable only if the logged data shows volume-confirmed
  breakouts meaningfully outperform.
- **Graduated stall bar** ("no new closing high in N sessions," or a ramping requirement
  across the window) — your SMA-style instinct, placed with data.
- **Pyramiding / scale-in** (pilot buy, add on confirmation) — Minervini-faithful, but
  muddies attribution, so v2.
- **Rank displacement** — let a far-higher-ranked fresh name bump a stalling held name.
  Reintroduces turnover; back pocket.
- **Concentrate `N_max` 8 → 5** once the system is trusted.

---

## Open TODOs flagged across the design

- [ ] Verify Stage 2 → Stage 3 data handoff is wired.
- [ ] Verify KIS US API native stop/conditional order support (pivotal — see §2).
- [ ] Pre-fund USD on the KIS account; confirm it's not auto-converting per trade.
- [ ] Confirm Naver Cloud egress to KIS + US data sources.
- [ ] (Carried from screener work) pin the Gemini model alias to a dated string before testing.
