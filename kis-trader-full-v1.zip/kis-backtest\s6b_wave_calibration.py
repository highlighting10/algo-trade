#!/usr/bin/env python3
r"""
s6b_wave_calibration.py -- what ZigZag threshold makes a "wave" mean a VCP
contraction?

TARGET REPO: kis-backtest.  READ-ONLY: writes no pickle, touches no checkpoint,
edits no file. It varies the engine's OWN config field and observes.

THE QUESTION

`s6_wavecount_probe.py` measured, over 17,294 scored name-sessions:

    in the scoring budget {2,3,4,5}     37.5%
    >= 6 waves                          45.6%
    >= 10 waves                         33.0%
    maximum wave count                     44

`_build_waves` is not defective -- it walks CONFIRMED ZigZag pivots and never
repaints. The counts come from the threshold it is handed:

    threshold = max(ATR20 * atr_multiplier, Close * min_pct)     # 1.5, 0.015

At 1.5x ATR over a base that can run to `max_base_lookback = 252` bars, a
confirmed reversal every ~6 bars is exactly what that setting is FOR. It is a
swing detector. A VCP contraction is a base's MAJOR pullback, not every 1.5-ATR
wiggle. That is a granularity mismatch, not a bug -- and the knob already
exists, so this needs no code change:

    VCPConfig: "Defaults reproduce V4 behaviour EXACTLY, so later optimisation
                only varies fields here -- no code edits."

`signals.generate_signals(..., vcp_config=...)` threads a config straight
through, and `generate_signals_by_population(**kw)` forwards it. So this probe
passes a real `VCPConfig` per arm. NO MONKEY-PATCHING of behaviour: the only
patch is an observer on the scoring stage, restored in a finally.

WHAT IT REPORTS, PER atr_multiplier

  * share of scored names in the DOCTRINAL band 2-6 contractions
  * share in the CURRENT scoring budget {2,3,4,5}
  * share at >= 7 (not a VCP by count) and the tail maximum
  * median / p95 wave count
  * share with contraction_quality == 1.0 -- every contraction shallower than
    the last, which is the definition of the pattern. This is the sharpest
    calibration signal in the output: a threshold that resolves real
    contractions should produce a real population of clean sequences.
  * share clearing the frozen threshold 75 -- a WARNING metric. If a coarser
    ZigZag balloons the qualifying pool, the recalibration is not "cleaner
    counts", it is a looser screen wearing that name.

HOW TO PICK

The target is the doctrine: modal count inside 2-6, a thin tail above it, and a
non-trivial population of quality==1.0 sequences -- WITHOUT the qualifying pool
exploding. If no setting gives all three, say so; that is a real result about
the base-detection design, not a tuning failure.

WHAT THIS DOES NOT DO

It does not tell you the recalibrated screen TRADES better. `atr_multiplier`
moves every score in the system, which is a larger change than anything in
Phase B. Any candidate setting has to be reproduced against the frozen set and
swept on its own before it is trusted. Calibrate here; decide elsewhere.

COST

One full sampled scan per arm. At --every 20 that was 14.1 min for 109 sessions
x 1506 tickers, so four arms is roughly an hour. Use --every 40 for a first look
(~7 min per arm); the DISTRIBUTION is what is being measured and it is stable
under sampling.

Usage (from the kis-backtest root, with its venv active):

    python s6b_wave_calibration.py                          # 1.5 2.5 3.5 5.0
    python s6b_wave_calibration.py --every 40               # faster first look
    python s6b_wave_calibration.py --atr-mult 1.5 2.0 2.5
    python s6b_wave_calibration.py --csv s6b_calib.csv
"""
from __future__ import annotations

import argparse
import os
import pathlib
import sys
import time
from collections import Counter


def _pct(n, d):
    return (n / d * 100.0) if d else 0.0


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", default=".")
    ap.add_argument("--every", type=int, default=20,
                    help="sample every Nth session (default 20). A DISTRIBUTION "
                         "sample, not a census.")
    ap.add_argument("--start", default="2018-01-01")
    ap.add_argument("--end", default=None)
    ap.add_argument("--atr-mult", type=float, nargs="+",
                    default=[1.5, 2.5, 3.5, 5.0],
                    help="ZigZag ATR multipliers to compare. 1.5 is the shipped "
                         "value and MUST be included as the control.")
    ap.add_argument("--contraction-ratio", type=float, nargs="+",
                    default=None,
                    help="E11 adaptive arms: threshold = prior wave depth * this "
                         "ratio (vcp_engine _zigzag_pivots). Each runs at the "
                         "SHIPPED atr_multiplier, which once the ratio is live "
                         "seeds only the first wave. Omit for the fixed sweep.")
    ap.add_argument("--min-pct", type=float, default=0.015,
                    help="the other half of the threshold: "
                         "max(ATR20*mult, Close*min_pct). Held fixed; it is a "
                         "floor for quiet names and stops binding as mult rises.")
    ap.add_argument("--threshold", type=float, default=75.0)
    ap.add_argument("--csv", default=None)
    a = ap.parse_args()

    if 1.5 not in a.atr_mult:
        print("[calib] REFUSING: 1.5 is the shipped atr_multiplier and must be "
              "in --atr-mult as the control. A calibration with no control "
              "cannot be read.")
        return 2

    root = os.path.abspath(a.repo)
    sys.path.insert(0, root)
    os.chdir(root)

    import pandas as pd
    import vcp_engine as ve
    from signals import (PITBars, generate_signals_by_population,
                         populations_from_universe)

    base_cfg = ve.VCPConfig()
    print("=" * 86)
    print("  S6b -- ZigZag calibration: what threshold makes a wave a CONTRACTION?")
    print("=" * 86)
    print(f"  shipped   atr_multiplier={base_cfg.atr_multiplier} "
          f"min_pct={base_cfg.min_pct} advance_min_pct={base_cfg.advance_min_pct} "
          f"max_base_lookback={base_cfg.max_base_lookback}")
    print(f"  scoring budget wave_count_points={base_cfg.wave_count_points}  "
          f"(doctrine is 2-6 contractions)")
    arms = [(m, None) for m in a.atr_mult]
    arms += [(base_cfg.atr_multiplier, r) for r in (a.contraction_ratio or [])]
    print(f"  arms      atr_multiplier in {a.atr_mult}, min_pct held at {a.min_pct}")
    if a.contraction_ratio:
        print(f"  E11       contraction_ratio in {a.contraction_ratio}, each at "
              f"atr_multiplier={base_cfg.atr_multiplier:g}")
        print(f"            (with the ratio live the ATR branch seeds only the "
              f"FIRST wave, so holding it fixed isolates the threshold SHAPE)")

    # ---- observer: records, changes nothing ------------------------------
    REC = []
    _o34 = ve.VCPAnalyzerV4.stage_3_and_4_contractions
    _orep = ve.VCPAnalyzerV4.generate_report

    def _s34(self, waves):
        s, d = _o34(self, waves)
        self._cal = d
        return s, d

    def _rep(self, *args, **kw):
        self._cal = None
        rep = _orep(self, *args, **kw)
        d = getattr(self, "_cal", None)
        if rep and isinstance(d, dict):
            REC.append((int(d.get("wave_count") or 0),
                        float(d.get("contraction_quality") or 0.0),
                        float(rep.get("Score") or 0.0)))
        return rep

    ve.VCPAnalyzerV4.stage_3_and_4_contractions = _s34
    ve.VCPAnalyzerV4.generate_report = _rep

    rows = []
    try:
        warm = pd.Timestamp(a.start) - pd.DateOffset(years=3)
        bars = {}
        for p in pathlib.Path("data/bars").glob("*.parquet"):
            df = pd.read_parquet(p)
            if getattr(df.index, "tz", None) is not None:
                df.index = df.index.tz_localize(None)
            df = df.loc[df.index >= warm]
            if not df.empty:
                bars[p.stem] = df
        if "^GSPC" not in bars:
            print("  FATAL: ^GSPC missing from data/bars.")
            return 2
        cal = PITBars(bars).calendar()
        lo = pd.Timestamp(a.start)
        hi = pd.Timestamp(a.end) if a.end else cal[-1]
        scan = cal[(cal >= lo) & (cal <= hi)][::a.every]
        if not len(scan):
            print("  FATAL: no sessions in the requested window.")
            return 2
        pops = populations_from_universe("data/universe.csv")
        have = set(bars)
        pops = {k: [t for t in v if t in have] for k, v in pops.items()}
        per = len(scan) * len(bars)
        print(f"  {len(bars)} tickers, {len(scan)} sessions "
              f"{scan[0].date()}..{scan[-1].date()} every {a.every}")
        _fx = sum(1 for _m, _r in arms if _r is None)
        print(f"  ~{per/60000:.0f}-{per/20000:.0f} min per FIXED arm; adaptive "
              f"arms measured ~2x that (2026-09-10)")
        print(f"  {len(arms)} arm(s): {_fx} fixed + {len(arms) - _fx} adaptive")
        print()

        for mult, ratio in arms:
            REC.clear()
            cfg = ve.VCPConfig(atr_multiplier=mult, min_pct=a.min_pct,
                               contraction_ratio=ratio)
            label = (f"atr_multiplier={mult:g}" if ratio is None else
                     f"contraction_ratio={ratio:g} (atr seed {mult:g})")
            print("-" * 86)
            print(f"  ARM {label}"
                  + ("   <- SHIPPED CONTROL"
                     if ratio is None and mult == base_cfg.atr_multiplier
                     else ""))
            t0 = time.time()
            generate_signals_by_population(
                bars, scan, pops, emit_threshold=0.0, vcp_config=cfg,
                checkpoint_dir=None, resume=False, log=lambda *_a, **_k: None)
            dt = time.time() - t0
            if not REC:
                print("    NO RECORDS -- nothing scored at this setting.")
                continue
            n = len(REC)
            hist = Counter(w for w, _q, _s in REC)
            band = sum(v for k, v in hist.items() if 2 <= k <= 6)
            budget = sum(v for k, v in hist.items() if 2 <= k <= 5)
            low = sum(v for k, v in hist.items() if k <= 1)
            high = sum(v for k, v in hist.items() if k >= 7)
            counts = sorted(w for w, _q, _s in REC)
            med = counts[n // 2]
            p95 = counts[int(n * 0.95)]
            mode = max(hist, key=lambda k: hist[k])
            clean = sum(1 for w, q, _s in REC if w >= 2 and q >= 0.999)
            clears = sum(1 for _w, _q, s in REC if s >= a.threshold)
            rows.append(dict(mult=mult, ratio=ratio,
                             n=n, mode=mode, med=med, p95=p95,
                             mx=max(hist), band=band, budget=budget, low=low,
                             high=high, clean=clean, clears=clears,
                             mins=dt / 60))
            print(f"    {n:,} scored in {dt/60:.1f} min | mode={mode} "
                  f"median={med} p95={p95} max={max(hist)}")
            print(f"    doctrinal band 2-6 : {band:6,} ({_pct(band,n):5.1f}%)"
                  f"    current budget 2-5 : {budget:6,} ({_pct(budget,n):5.1f}%)")
            print(f"    <=1 wave           : {low:6,} ({_pct(low,n):5.1f}%)"
                  f"    >=7 waves          : {high:6,} ({_pct(high,n):5.1f}%)")
            print(f"    quality==1.0       : {clean:6,} ({_pct(clean,n):5.1f}%)"
                  f"    clears {a.threshold:g}        : {clears:6,} "
                  f"({_pct(clears,n):5.1f}%)")
            if a.csv:
                import csv as _csv
                first = not os.path.exists(a.csv)
                with open(a.csv, "a", newline="", encoding="utf-8") as fh:
                    w = _csv.writer(fh)
                    if first:
                        w.writerow(["atr_multiplier", "contraction_ratio",
                                    "wave_count", "contraction_quality",
                                    "score"])
                    w.writerows([mult, "" if ratio is None else ratio, x, y, z]
                                for x, y, z in REC)
    finally:
        ve.VCPAnalyzerV4.stage_3_and_4_contractions = _o34
        ve.VCPAnalyzerV4.generate_report = _orep

    if not rows:
        print("\n  nothing to compare.")
        return 1

    print()
    print("=" * 86)
    print("  COMPARISON   (target: mode inside 2-6, thin >=7 tail, a real")
    print("                quality==1.0 population, WITHOUT the pool exploding)")
    print("=" * 86)
    print(f"  {'mult':>5} {'ratio':>6} {'mode':>5} {'med':>4} {'p95':>4} "
          f"{'max':>4} "
          f"{'2-6':>7} {'2-5':>7} {'<=1':>7} {'>=7':>7} {'q=1.0':>7} "
          f"{'clears':>7}")
    base = next((r for r in rows
                 if r["mult"] == 1.5 and r["ratio"] is None), None)
    for r in rows:
        _rt = "-" if r["ratio"] is None else format(r["ratio"], "g")
        print(f"  {r['mult']:5g} {_rt:>6} {r['mode']:5d} {r['med']:4d} "
              f"{r['p95']:4d} {r['mx']:4d} "
              f"{_pct(r['band'], r['n']):6.1f}% {_pct(r['budget'], r['n']):6.1f}% "
              f"{_pct(r['low'], r['n']):6.1f}% {_pct(r['high'], r['n']):6.1f}% "
              f"{_pct(r['clean'], r['n']):6.1f}% "
              f"{_pct(r['clears'], r['n']):6.1f}%")
    if base:
        print(f"\n  control (1.5) for reference: "
              f"2-6 {_pct(base['band'], base['n']):.1f}%, "
              f">=7 {_pct(base['high'], base['n']):.1f}%, "
              f"q=1.0 {_pct(base['clean'], base['n']):.1f}%, "
              f"clears {_pct(base['clears'], base['n']):.1f}%")
        for r in rows:
            if r["mult"] == 1.5 and r["ratio"] is None:
                continue
            g = _pct(r['clears'], r['n']) / max(_pct(base['clears'], base['n']),
                                                1e-9)
            if g > 1.5:
                _arm = (f"atr_multiplier={r['mult']:g}" if r["ratio"] is None
                        else f"contraction_ratio={r['ratio']:g}")
                print(f"  ** {_arm} multiplies the "
                      f"qualifying pool by {g:.1f}x. That is a LOOSER SCREEN, "
                      f"not just cleaner counts -- do not read it as free.")
    print()
    print("  NEXT, and not in the same step: a candidate setting changes EVERY")
    print("  score in the system. Reproduce the frozen set under it, then sweep")
    print("  it on its own, before anything downstream is believed.")
    if a.csv:
        print(f"\n  raw records -> {a.csv}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
