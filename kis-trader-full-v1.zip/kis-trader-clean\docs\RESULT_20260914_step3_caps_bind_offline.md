# RESULT — 2026-09-14: 4A step 3, the downstream caps made to bind offline

**Question.** `n_max`, the portfolio exposure ceiling and dedup had never fired against a real CSV.
Real screener output cannot reach them — the bar store measured **at most one armable name per
session** (`RESULT_20260911_emit_bar_yield_measured` §8) — and `make_plumbing_csv.py` quoted every
ticker through `KISBrokerWithEntry`, so with no KIS credentials on this machine it had never run at
all. Can the caps be exercised with no credentials, and do they fire where the code says?

**Answer.** Yes for two of the three caps and for dedup; two other guards stay untestable for
reasons that are structural, not incidental. Commits `df0b9be` (`--offline`) and `107b874`
(gitignore).

---

## What was built

`--offline` on `make_plumbing_csv.py`, not a new script — that file already owns every rule that
makes plumbing mode safe (refuses `candidates.csv`, refuses a directory a real screener's
`regime.json` owns, writes its own sidecar with the real `VCP_SCORE_THRESHOLD` and
`degraded_threshold=None`). Offline skips `.env`, `Config`, the broker and `TradableUniverse`
entirely and fabricates the price from `crc32(ticker)` mapped into 50.00–250.00.

`crc32`, not `hash()`: `hash()` is salted per process, so the same ticker list would write a
different CSV every run and a diff would mean nothing. Because the prices are stable, the sandbox
run and the box run below agree **to the dollar** — which is what makes the box run a check rather
than a repetition.

Mode is visible in three places so no log can be mistaken for strategy evidence: a banner on every
run, rows named `(PLUMBING OFFLINE)`, and the sidecar screener `PLUMBING_OFFLINE`.

---

## `--stop-pct`, and why it is not a realism knob

At the shipped 5% stop, **`n_max` is unreachable at any row count.** Sizing is risk-limited:
`shares = 0.85% * equity / risk_per_share`, so a position's notional is about
`0.0085 * limit / risk_per_share` of equity. At a 5% stop that is 14.3%, seven of those fill the
100% ceiling, `plans` never reaches 8, and the `n_max` branch is dead code from the fixture's point
of view. A wider stop makes each position smaller: at 7% it is 10.7%, eight fit, and `n_max` fires
on the ninth.

So `--stop-pct` decides **which cap binds first**. Default stays 0.05 — geometry byte-identical to
the live path. Capped at 0.09 because `DecisionConfig.max_stop_pct` is 0.10 and a stop at or past it
is rejected per-candidate, which tests the stop gate rather than the caps.

---

## Measured (box, 11 rows, NVDA deliberately twice)

| run | plans | total notional | rejections |
|---|---|---|---|
| `--stop-pct 0.07` | 8 | 180,939 (85.5% of equity), risk 6.77% | QCOM, TXN → `n_max 8 reached`; NVDA → `duplicate: already held/pending/selected` |
| default 0.05 | 7 | 211,470 (99.9%), risk 5.94% | ORCL, QCOM, TXN → `exposure ceiling: 241561 > 211710`; NVDA → `duplicate` |

Contract side: 11 of 11 rows accepted, 0 rejected, 11 catalyst-evidence notes (reported, not
dropped — `REQUIRE_CATALYST_EVIDENCE` is False). Every plan is `contraction+atr` at `xATR 1.30`, so
the ATR floor is present but not binding at either stop width — as intended by the geometry.

Identical to the sandbox figures measured before delivery, including the three ceiling numbers
(241561 / 241622 / 241645).

---

## A property of the fixture, not of the strategy

Every plumbing row carries the same invented `vcp_score=88.0`, and ranking is `vcp_only`. So every
candidate ties on rank and the tie-break — ticker ascending — decides the whole selection. The eight
accepted names in run (a) are simply the first eight alphabetically; ORCL is in and QCOM is out for
no reason but its name.

That is correct behaviour (`I8b: exact rank tie falls to ticker ascending`) and it is exactly what a
cap test wants — a deterministic order. It must not be read as ranking evidence. Any future run that
wants to exercise *ranking* has to vary the scores.

---

## What is still NOT tested, and why

Two guards sit in the same `plan()` loop and did not fire. Neither is an oversight in this step:

**Sector cap.** `DecisionConfig.sector_cap` is `0` — off by declaration (PATCH F, 2026-08-25), and
`sector_of` is injected by the pipeline, so every plan here carries `sector=""`. Two independent
reasons it cannot fire. `plan_probe` says so on every run. Testing it needs a decision first: is a
cap nobody enabled worth wiring?

**`max_open_positions`.** Also 8, and checked immediately *after* `n_max` in the same loop. With
`open_position_count = 0` — which is what `plan_probe`'s `AccountState(equity, cash)` gives — both
fire at the same count and `n_max` always wins the label. It can only bind when positions are
already live, which needs the broker. So the reason string `max_open_positions 8 reached` has never
been produced by anything.

Both belong in the honest column: exercised-by-nothing, not passed.

### CORRECTION, 2026-09-14 — the box had already produced it, that same day

The last sentence above is **false**, and the box's own alert log says so:

```
2026-09-14 13:30:41,218 WARN | arm reject: TWLO — max_open_positions 8 reached
2026-09-14 13:30:41,218 WARN | arm reject: CRL  — max_open_positions 8 reached
2026-09-14 13:30:41,219 WARN | arm_today: 29 candidates -> 1 planned -> 1 armed (1 watching, 0 order(s) live)
```

The *mechanism* above is right and is exactly what produced this: the box holds **7 live
positions**, so `open_position_count = 7`. The first candidate passes (`7 + 0 < 8`) and is planned;
every candidate after it hits `7 + 1 >= 8` and takes the `max_open_positions` label. `n_max` never
gets a chance, because `len(plans)` never reaches 8. Offline, with `open_position_count = 0`, the
two swap places — which is what the paragraph correctly derives.

What was wrong was the claim about the world, not the claim about the code. **`max_open_positions`
is exercised, by the live box, on a commit that predates all of this work** (`6869ec7`, 09-08).
Moving it out of the exercised-by-nothing column:

| guard | status |
|---|---|
| `n_max` | bound offline at `--stop-pct 0.07` |
| exposure ceiling | bound offline at the default stop |
| dedup | bound offline, and live (`HUM`, `LFST`, `INSW` today) |
| `max_open_positions` | **bound live, 2026-09-14 13:30 UTC** |
| `sector_cap` | still exercised by nothing — `0` by declaration, no `sector_of` injected |

Note these box lines carry **no `[rs=.. s2=.. vcp=..]` suffix**: 4A step 1 (`f80eb79`, `bc17594`)
is on `main` and not yet deployed. That is the deploy's own before-picture.

The process error is the one this project keeps paying for: I asserted "never produced by
anything" from the laptop, while the one machine that could produce it was running, logging, and
reachable. Checking cost one `tail`.

---

## Where this leaves 4A

Steps 1–3 are done and are the whole credential-free half:

1. scores logged with every arm rejection (`f80eb79`) and **asserted** (`bc17594`)
2. plumbing CSV gets its own regime sidecar (`f80eb79`)
3. the caps bind, measured (`df0b9be`)

Steps 4–6 — arm → watch → fill → manage → exit on N concurrent positions — need KIS credentials and
cannot start on this machine. 4B (`us_small_v21 --emit-candidates` → `run --once --arm`) needs Gemini
as well.

One thing the offline CSV is now ready for: the moment credentials exist, it is also the multi-position
arm fixture. `$env:KIS_CANDIDATES="plumbing\plumbing_candidates.csv"` plus
`run --once --arm --no-open-order-check` drives the identical downstream path with eight names —
which is Step 4's PLUMBING mode, with the bars untouched and the mode named in every log line.


---

## CORRECTION, same night: the equity is wrong, so the NUMBERS are laptop fiction

Every figure above uses `plan_probe`'s default `--equity 211710`. **The box runs
`KIS_EQUITY_USD = 31650`**, corrected on 2026-08-19 after the old figure produced
$20k positions on an account that could fund one (`MASTER_HANDOFF_20260822` §2;
`cloud_provisioning.md` §9, which also notes it is orderable *cash*, not equity).

211,710 is **6.7× the real account.** What survives and what does not:

- **The mechanism survives.** `n_max`, the exposure ceiling and dedup all fire,
  in the order the code says, for the reasons the code gives. That was the
  question this step existed to answer.
- **The arithmetic survives.** Sizing is risk-limited, so notional as a *fraction
  of equity* is invariant: 14.3% per position at a 5% stop, 10.7% at 7%. Which
  cap binds first still follows from the stop width, not from the account size.
- **The counts and dollars do not describe the box.** At 31,650 the same rows
  produce roughly 4,500 per position and the ceiling binds around the seventh
  the same way — but every absolute number printed above (180,939 / 211,470 /
  241,561) is 6.7× too large to be read as the real account.

Re-run with `--equity 31650` before quoting any of this at the box. Nothing about
the conclusion changes; the receipts do.
