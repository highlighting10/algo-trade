"""
03_gate.py -- THE GATE. Reproduce known production VCP scores, or stop.

Runs one signal pass dated 2026-08-05 and compares against the scores the real
screeners produced on the box that day (seed doc S8). If these do not reproduce,
the extraction is measuring a different engine and EVERY downstream number is void.

Run this before generating full signals. Debug here, not after a 3-hour run.
"""
import pathlib as _pl
import sys as _sys
_sys.path.insert(0, str(_pl.Path(__file__).resolve().parent.parent))
import argparse
import hashlib
import io
import json
import pathlib
import sys

import pandas as pd

from signals import (PITBars, generate_signals_by_population,
                     populations_from_universe)

# EMPIRICAL, not assumed. 03d_asof.py swept 18 sessions x 2 window modes: 8 of the
# 10 seed-doc scores reproduce EXACTLY (to 0.01) at as-of 2026-08-03, and 0 of 10
# at every date from 2026-07-15 through 2026-07-31. The run LABELLED 2026-08-05
# used data through 2026-08-03's close. Override with --asof if that changes.
GATE_DATE = pd.Timestamp("2026-08-03")
LABELLED_RUN_DATE = pd.Timestamp("2026-08-05")
# BRKR and LFST did not reproduce against the box doc at any tested date. That
# was a property of the BOX DOC, not of the engine -- pinned from THIS engine
# there is nothing unresolved, so the constant is GONE rather than left at
# module level for main() to overwrite on every path. Dead state that still
# reads like a live tolerance is how a widened gate ships by accident: a later
# edit "restoring" a name here would change nothing and look like it had.
# main() binds KNOWN_UNRESOLVED = () from the pin.

# --- re-pin 2026-09-10 -------------------------------------------------------
# The ten below are the ORIGINAL anchor: the 2026-08-05 cold run on the box,
# threshold 55, at as-of 2026-08-03. Kept, not overwritten, per
# DESIGN_20260905_replacement_anchor sec.4 -- the old values stay in the file so
# the delta is legible.
#
# They can no longer reproduce, deliberately. Two subtractive scoring changes
# landed 2026-09-10:
#   tol  contraction_mode 'general' (1.10) -> 'strict' (1.00); at 1.10 an
#        EXPANDING sequence 20 -> 22 -> 24 scored contraction_quality 1.000.
#   3b   stage 3/4 gains a final-contraction tightness factor in [0, 1], zero
#        point DERIVED at 9.10% from max_stop_pct.
# Both can only REDUCE a score, so every moved name moved DOWN.
#
# WHAT THIS GATE NOW MEANS. Before: "the extraction reproduces the box's
# 2026-08-05 production output." After: "the extraction reproduces THIS engine,
# end to end." The first property is spent -- spent by the engine change, not by
# this file. What survives is not covered anywhere else: this runs the whole
# path (signals.py, the sp500 / us_small split, the RS percentile), while
# engine_reference.py execs the engine BLOCK alone with a default config and 03f
# is engine-independent by design. That composition gap is exactly what let a
# tolerance change land green while production ran the old value.
EXPECTED_PRE_ZIGZAG = {
    "NTAP": 73.55, "UNH": 67.58, "NUE": 59.83, "STT": 58.64, "HPE": 58.25,
    "BRKR": 72.00, "PTGX": 62.54, "IRDM": 58.66, "OKTA": 58.29, "LFST": 57.07,
}
# The live pin is a DATA file this tool writes from a real run, never ten floats
# hand-copied out of a terminal -- same convention as engine_reference.json and
# harness_anchor.json. Absent + no --repin is FATAL: the gate never silently
# adopts what it happens to see.
PIN = pathlib.Path(__file__).resolve().parent / "gate_expected.json"
TOLERANCE = 0.01


# --- repin block --- pure helpers; exercised by apply_03gate_repin.py --verify
def _block_sha(engine_path):
    """sha of the SAME slice engine_reference.py execs, so the pin records which
    engine produced it and a stale pin says so instead of blaming the harness."""
    with io.open(engine_path, "r", encoding="utf-8") as fh:
        src = fh.read()
    _end = "VCPAnalyzerV3 = VCPAnalyzerV4"
    i = src.index("def safe_divide(")
    # INCLUDE the end marker. engine_reference.py:245 slices
    # hb[i : j + len(BLOCK_END)] and hashes THAT, so including it makes this
    # digest byte-identical to the `harness` sha engine_reference prints and
    # freezes into engine_reference.json. Two anchors printing the same 16
    # characters corroborate each other by inspection; two differing by a slice
    # boundary look like disagreement and cost someone an investigation at the
    # worst possible moment -- while deciding whether an engine moved.
    j = src.index(_end) + len(_end)
    return hashlib.sha256(src[i:j].encode("utf-8")).hexdigest()[:16]


def _pin_moved(scores, pre, tol):
    return {t: [pre[t], scores[t]] for t in sorted(scores)
            if t in pre and abs(scores[t] - pre[t]) > tol}


def _write_pin(path, asof, sha, scores, pre, tol):
    moved = _pin_moved(scores, pre, tol)
    payload = {
        "asof": str(asof),
        "engine_block_sha": sha,
        "scores": {t: round(float(scores[t]), 2) for t in sorted(scores)},
        "moved_from_pre_zigzag": moved,
    }
    with io.open(str(path), "w", encoding="utf-8", newline="\n") as fh:
        json.dump(payload, fh, indent=2)
        fh.write("\n")
    return moved


def _read_pin(path):
    with io.open(str(path), "r", encoding="utf-8") as fh:
        d = json.load(fh)
    return {t: float(v) for t, v in d["scores"].items()}, d
# --- end repin block ---------------------------------------------------------


def load_bars(tickers):
    bars = {}
    for t in tickers:
        p = pathlib.Path(f"data/bars/{t}.parquet")
        if p.exists():
            bars[t] = pd.read_parquet(p)
    return bars


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--asof", default=str(GATE_DATE.date()))
    ap.add_argument("--require", type=int, default=None,
                    help="exact matches needed to pass. Default: ALL of them, "
                         "because the pin comes from this engine.")
    ap.add_argument("--repin", action="store_true",
                    help="write scripts/gate_expected.json from THIS run. "
                         "Refuses to overwrite an existing pin without --force.")
    ap.add_argument("--force", action="store_true",
                    help="allow --repin to overwrite an existing pin FILE.")
    ap.add_argument("--accept-drift", action="store_true",
                    help="allow --repin to overwrite an existing pin's SCORES. "
                         "Separate from --force on purpose: overwriting the "
                         "file and overwriting the numbers are different "
                         "claims, and only the second can hide a regression.")
    args = ap.parse_args()

    engine = pathlib.Path(__file__).resolve().parent.parent / "vcp_engine.py"
    sha_now = _block_sha(str(engine))
    if PIN.exists():
        EXPECTED, _meta = _read_pin(PIN)
        KNOWN_UNRESOLVED = ()
        _pin_asof = _meta.get("asof")
        # kept separately: EXPECTED is rebound on the --repin path below, and
        # the drift check needs the pin being REPLACED, not the new baseline.
        _replacing = dict(EXPECTED)
        print(f"[gate] pin {PIN.name}: {len(EXPECTED)} score(s), "
              f"as-of {_meta.get('asof')}, engine {_meta.get('engine_block_sha')}")
        if _meta.get("engine_block_sha") != sha_now:
            print(f"[gate] NOTE: the engine block moved since this pin "
                  f"({_meta.get('engine_block_sha')} -> {sha_now}). A mismatch "
                  f"below is an ENGINE change, not a harness one -- check "
                  f"engine_reference.py --verify before 03e_ticker.py.")
    elif args.repin:
        EXPECTED, KNOWN_UNRESOLVED = dict(EXPECTED_PRE_ZIGZAG), ()
        _pin_asof = None
        _replacing = None
    else:
        print(f"[gate] FATAL: no pin at {PIN}. The in-file EXPECTED_PRE_ZIGZAG "
              f"is the SPENT 2026-08-05 anchor and cannot reproduce after the "
              f"tol + 3b scoring changes.")
        print("[gate] Re-pin deliberately:  python scripts/03_gate.py --repin")
        sys.exit(1)
    if args.require is None:
        args.require = len(EXPECTED)
    asof = pd.Timestamp(args.asof)          # local; never rebind the module global
    names = sorted(EXPECTED) + ["^GSPC"]
    # RS is a percentile over the SCANNED POPULATION, so the gate must scan the
    # full universe -- scoring only these 10 names would give every one of them a
    # different RS rating and the VCP scores would not match.
    uni = pd.read_csv("data/universe.csv")["ticker"].astype(str).tolist()
    bars = load_bars(sorted(set(uni + names)))
    missing = [t for t in names if t not in bars]
    if missing:
        print(f"[gate] FATAL: no bars for {missing}. Run 02_download.py first.")
        sys.exit(1)
    print(f"[gate] {len(bars)} ticker(s) loaded")

    cal = PITBars(bars).calendar()
    if asof not in cal:
        prior = cal[cal <= asof]
        if not len(prior):
            print(f"[gate] FATAL: no sessions on or before {asof.date()}")
            sys.exit(1)
        print(f"[gate] {asof.date()} is not a session; using {prior[-1].date()}")
        gate_date = prior[-1]
    else:
        gate_date = asof

    # A pin is a score at ONE as-of. Compared against a run at any other
    # session, all ten mismatch for the ordinary reason that prices moved, and
    # the failure text blames the engine. DESIGN_20260905_replacement_anchor
    # sec.4: "a single failing number cannot tell you whether the bars moved or
    # the engine did, and those need opposite responses -- revert versus
    # describe." Refuse instead of printing a misleading table. Skipped under
    # --repin so re-pinning at a new date stays possible.
    if _pin_asof is not None and not args.repin and str(gate_date.date()) != _pin_asof:
        print(f"[gate] FATAL: {PIN.name} is pinned at as-of {_pin_asof}; this "
              f"run resolved to {gate_date.date()}. A pin only ever compares a "
              f"session to itself.")
        print("[gate] Run at the pinned date, or move the pin deliberately:")
        print(f"[gate]   python scripts/03_gate.py --asof {gate_date.date()} "
              f"--repin --force")
        sys.exit(1)

    # Production scans sp500 and sp400+600 as SEPARATE runs, each with its own
    # RS percentile. Pooling them changes every rating and drops names that would
    # have cleared RS>=70 within their own universe.
    pops = populations_from_universe("data/universe.csv")
    have = set(bars)
    pops = {k: [t for t in v if t in have] for k, v in pops.items()}
    print("[gate] populations: " + ", ".join(f"{k}={len(v)}" for k, v in pops.items()))
    sigs = generate_signals_by_population(bars, [gate_date], pops, emit_threshold=0.0)

    got = {c.ticker: c.vcp_score for c in sigs.get(gate_date, [])}

    if args.repin:
        if PIN.exists() and not args.force:
            print(f"[gate] REFUSING to overwrite {PIN.name} without --force.")
            sys.exit(1)
        absent_now = [t for t in EXPECTED_PRE_ZIGZAG if t not in got]
        if absent_now:
            print(f"[gate] REFUSING to pin: not emitted this run: {absent_now}. "
                  f"A pin missing names is worse than no pin.")
            sys.exit(1)
        scores = {t: got[t] for t in EXPECTED_PRE_ZIGZAG}

        # `moved` below is measured against EXPECTED_PRE_ZIGZAG, a frozen
        # historical constant -- 9 by construction, forever, whatever this run
        # produced. It says nothing about the pin this write destroys. When
        # forcing over an existing pin, THAT is the number that matters: a
        # forced overwrite of an anchor is exactly where a regression gets
        # frozen and then believed by every later run.
        # Skipped across as-ofs: scores from two different sessions are not
        # comparable and a diff there is noise, not evidence.
        _same_session = _pin_asof is None or _pin_asof == str(gate_date.date())
        drift = _pin_moved(scores, _replacing, TOLERANCE) if _replacing else {}
        if _replacing and _same_session:
            if drift and not args.accept_drift:
                print(f"\n[gate] REFUSING: {len(drift)} score(s) differ from "
                      f"the pin being replaced.")
                print(f"[gate] {'ticker':8} {'old pin':>9} {'now':>9}   delta")
                for t in sorted(drift):
                    o, n = drift[t]
                    print(f"[gate] {t:8} {o:9.2f} {n:9.2f}   {n - o:+.2f}")
                print("[gate] If the engine changed on purpose, say so: "
                      "--repin --force --accept-drift.")
                print("[gate] If it did not, this is a regression -- do not "
                      "pin over it.")
                sys.exit(1)
            print(f"[gate] drift vs the pin being replaced: {len(drift)} "
                  f"score(s)" + (" -- ACCEPTED via --accept-drift" if drift
                                 else " (the scores are unchanged)"))
        elif _replacing:
            print(f"[gate] pin was as-of {_pin_asof}, this run is "
                  f"{gate_date.date()} -- scores are not comparable across "
                  f"sessions, so no drift check.")

        moved = _write_pin(PIN, gate_date.date(), sha_now, scores,
                           EXPECTED_PRE_ZIGZAG, TOLERANCE)
        print(f"\n[gate] RE-PINNED {len(scores)} score(s) -> {PIN.name}")
        print(f"[gate] {'ticker':8} {'pre-3b':>9} {'now':>9}   delta")
        for t in sorted(moved):
            a, b = moved[t]
            print(f"[gate] {t:8} {a:9.2f} {b:9.2f}   {b - a:+.2f}")
        # Two baselines, adjacent and labelled by the question each answers.
        # Separated by a screen they get read as one number and the wrong one
        # gets trusted -- which cost two stops in one session before this.
        print(f"[gate] vs the spent 2026-08-05 anchor : {len(moved)} differ, "
              f"{len(scores) - len(moved)} same")
        print("[gate]     FIXED baseline, frozen in the source. Says the tol +")
        print("[gate]     3b change landed. Constant from here on -- if it ever")
        print("[gate]     read 0, the engine change would have done nothing.")
        if _replacing is None:
            print("[gate] vs the pin just replaced       : n/a, first pin")
        else:
            print(f"[gate] vs the pin just replaced       : {len(drift)} differ")
            print("[gate]     THIS is the safety number. 0 means the write")
            print("[gate]     changed nothing but metadata.")
        print(f"[gate] engine_block_sha {sha_now}. Commit the pin WITH the "
              f"engine change, never separately.")
        return
    print(f"\n[gate] {'ticker':8} {'expected':>9} {'got':>9}   verdict")
    ok = bad = absent = 0
    for t, exp in sorted(EXPECTED.items()):
        if t not in got:
            print(f"[gate] {t:8} {exp:9.2f} {'-':>9}   NOT EMITTED")
            absent += 1
        elif abs(got[t] - exp) <= TOLERANCE:
            print(f"[gate] {t:8} {exp:9.2f} {got[t]:9.2f}   match")
            ok += 1
        else:
            print(f"[gate] {t:8} {exp:9.2f} {got[t]:9.2f}   MISMATCH "
                  f"(delta {got[t]-exp:+.2f})")
            bad += 1

    misses = [t for t in EXPECTED
              if t not in got or abs(got[t] - EXPECTED[t]) > TOLERANCE]
    print(f"\n[gate] {ok} match, {bad} mismatch, {absent} not emitted "
          f"(need {args.require})")

    if ok >= args.require and all(t in KNOWN_UNRESOLVED for t in misses):
        print(f"[gate] PASSED at as-of {gate_date.date()} against "
              f"{PIN.name}, engine {sha_now}.")
        print("[gate] What that proves: the extraction reproduces THIS engine "
              "end to end -- signals.py, the population split and the RS "
              "percentile included, which engine_reference.py cannot see.")
        print(f"[gate] What it no longer proves: the box's "
              f"{LABELLED_RUN_DATE.date()} production output. The tol + 3b "
              f"scoring changes spent that, deliberately.")
        if misses:
            print(f"[gate] Still unexplained: {misses}. These are the KNOWN "
                  f"unresolved names, not a widened tolerance.")
            print("[gate] Run 03e_ticker.py on them before trusting small-cap "
                  "results.")
        return

    if bad or absent:
        print("[gate] ----------------------------------------------------------")
        print(f"[gate] GATE FAILED ({ok}/{args.require} required). Misses: {misses}")
        print("[gate] Already ruled out by the 03b/03c/03d diagnostics:")
        print("[gate]   - corporate actions rescaling adjusted history")
        print("[gate]   - window length (tail(N)) and window mode (calendar)")
        print("[gate] Still worth checking:")
        print("[gate]   1. as-of date -- rerun 03d_asof.py; the effective data date")
        print("[gate]      differs from the labelled run date.")
        print("[gate]   2. Population split -- production scans sp500 and")
        print("[gate]      sp400+600 separately; RS is a percentile per universe.")
        print("[gate]   3. The bars themselves -- 03e_ticker.py, then compare")
        print("[gate]      Latest_Close against the box's candidates.csv.")
        sys.exit(1)
    print("[gate] PASSED -- the extraction reproduces production. Proceed to 04.")


if __name__ == "__main__":
    main()
