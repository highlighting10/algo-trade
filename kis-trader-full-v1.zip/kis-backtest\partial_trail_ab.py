#!/usr/bin/env python3
"""
partial_trail_ab -- does Minervini's exit ladder beat the frozen one?

THE QUESTION

  frozen    sell 1/3 at +3R, breakeven, trail the runner on EMA21
  Minervini sell 1/2 at +2R, breakeven, trail the runner on SMA50

Both bank the SAME 1.00 R at the trigger (1/3 x 3 = 1/2 x 2). What changes is
how OFTEN the trigger fires and how much is left running. That is an empirical
question and this measures it.

NO HARNESS EDIT IS NEEDED. R_PARTIAL_MULTIPLE and PARTIAL_FRACTION are read as
module globals inside run(), and _ema is called once as _ema(df["Close"]), so
all three can be swapped at runtime and restored afterwards. Nothing on disk
changes. Verify that for yourself: the file's sha256 is printed before and after.

FOUR RUNS, one variable at a time plus the combination:

  A  3R / one third / EMA21     the frozen set -- the control
  B  2R / one half  / EMA21     Minervini's partial only
  C  3R / one third / SMA50     Minervini's trail only
  D  2R / one half  / SMA50     both

READ IT AGAINST THE NOISE FLOOR. Rev 3 sec.4: SE = 1.95/sqrt(n), about 0.138 R
at n=200. A difference smaller than that is not evidence, and this script says
so on every row.

LIMIT -- READ THIS BEFORE QUOTING ANY NUMBER

This measures the HARNESS at those settings. F8 proved the harness reproduces
engine_v2's exits at the FROZEN constants only. It says nothing about whether
the two agree at 2R / one half / SMA50. Treat any result here as a reason to
run F8 at the new constants, never as a production decision on its own.

USAGE (from the kis-backtest root, venv active)

    python partial_trail_ab.py
"""
from __future__ import annotations

import argparse
import hashlib
import math
import os
import pathlib
import pickle
import sys
import time

FROZEN = dict(rank_mode="vcp_only", vcp_threshold=75.0, stall_day=252,
              regime_ma=20, risk_per_trade_pct=0.0085, max_position_pct=0.25)

# label -> (R_PARTIAL_MULTIPLE, PARTIAL_FRACTION, trail kind, trail length)
ARMS = [
    ("A  3R / 1-3 / EMA21   (frozen)", 3.0, 1.0 / 3.0, "ema", 21),
    ("B  2R / 1-2 / EMA21   (partial)", 2.0, 0.5, "ema", 21),
    ("C  3R / 1-3 / SMA50   (trail)", 3.0, 1.0 / 3.0, "sma", 50),
    ("D  2R / 1-2 / SMA50   (both)", 2.0, 0.5, "sma", 50),
]
# expectancy_R is the RUNNER leg's per-share R -- the partial's proceeds never
# enter a Trade, so changing the partial is INVISIBLE in it. Measured on a
# fixture: A vs B moved total_return 8.52 -> 6.79 while expectancy_R did not
# budge. expectancy_R_weighted (patch 1, commit e607db9) is the one that sees
# both legs, and it is what the verdict below is computed from.
KEYS = ("num_trades", "win_rate_pct", "expectancy_R", "expectancy_R_weighted",
        "total_return_pct", "max_drawdown_pct", "avg_mfe_R", "giveback_R",
        "pct_reaching_2R", "pct_reaching_3R")
VERDICT_KEY = "expectancy_R_weighted"


def sha(path):
    return hashlib.sha256(open(path, "rb").read()).hexdigest()[:16]


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", default=".")
    ap.add_argument("--bars", default="data/bars")
    ap.add_argument("--signals", default="data/signals.pkl")
    ap.add_argument("--sectors", default="data/sectors.csv")
    a = ap.parse_args()

    root = os.path.abspath(a.repo)
    sys.path.insert(0, root)
    hpath = os.path.join(root, "minervini_backtest.py")
    if not os.path.isfile(hpath):
        print("FATAL: no minervini_backtest.py under %r" % root)
        return 2
    before = sha(hpath)

    import pandas as pd
    import minervini_backtest as m

    print("=" * 78)
    print("  PARTIAL + TRAIL A/B -- frozen ladder vs Minervini's")
    print("=" * 78)
    print("  harness      : %s  sha %s" % (hpath, before))
    print("  base (shared by all four): %s" % FROZEN)

    bars_dir = pathlib.Path(a.bars)
    if not bars_dir.is_dir():
        print("FATAL: no bar directory at %r" % str(bars_dir))
        return 2
    t0 = time.time()
    bars = {p.stem: pd.read_parquet(p) for p in bars_dir.glob("*.parquet")}
    prices = {t: d for t, d in bars.items() if t != "^GSPC"}
    bench = bars.get("^GSPC")
    if bench is None:
        print("FATAL: no ^GSPC bars; regime_ma=20 fails closed without it.")
        return 2
    with open(a.signals, "rb") as f:
        signals = pickle.load(f)["signals"]
    smap = m.load_sector_map(a.sectors)
    ds = sorted(signals)
    print("  bars %d (+^GSPC) in %.1fs   signals %d dates %s..%s"
          % (len(prices), time.time() - t0, len(signals),
             ds[0].date(), ds[-1].date()))

    base = m.BacktestConfig(
        rank_mode=FROZEN["rank_mode"], equity_mode="compounding",
        entry_mode="pivot_limit", ambiguity_mode="worst",
        vcp_threshold=FROZEN["vcp_threshold"], stall_day=FROZEN["stall_day"],
        regime_ma=FROZEN["regime_ma"], sector_map=smap,
        decision=m.DecisionConfig(
            risk_per_trade_pct=FROZEN["risk_per_trade_pct"],
            max_position_pct=FROZEN["max_position_pct"]),
        benchmark_close=bench["Close"])

    # ---- swap the three constants per arm, ALWAYS restore ------------------ #
    keep = (m.R_PARTIAL_MULTIPLE, m.PARTIAL_FRACTION, m._ema)
    res = {}
    try:
        for label, mult, frac, kind, span in ARMS:
            m.R_PARTIAL_MULTIPLE = mult
            m.PARTIAL_FRACTION = frac
            if kind == "sma":
                # rolling().mean() leaves NaN over the warm-up. A NaN comparison
                # is False, so the trail simply does not fire there -- it never
                # invents an exit. min_periods is left at the default for that
                # reason: fewer bars must mean "no signal", not "a signal off
                # three bars".
                m._ema = (lambda close, span=span:
                          close.rolling(span).mean())
            else:
                m._ema = (lambda close, span=span:
                          close.ewm(span=span, adjust=False).mean())
            t = time.time()
            _eq, _tr, stats, _dr, diag = m.run(prices, signals, base)
            stats = dict(stats)
            stats["partials_taken"] = diag.get("partials_taken", 0)
            res[label] = stats
            print("  ran %-34s %6.1fs  %4d trades  %3d partial(s)"
                  % (label, time.time() - t, stats["num_trades"],
                     stats["partials_taken"]))
    finally:
        m.R_PARTIAL_MULTIPLE, m.PARTIAL_FRACTION, m._ema = keep

    after = sha(hpath)
    print("  harness sha after: %s  %s" % (after, "UNCHANGED" if after == before
                                           else "** FILE WAS MODIFIED **"))
    if after != before:
        print("  Something wrote to the harness. Do not trust these numbers.")
        return 1

    print("\n" + "=" * 78)
    labels = [x[0] for x in ARMS]
    print("  %-18s" % "" + "".join("%14s" % l.split()[0] for l in labels))
    for k in KEYS + ("partials_taken",):
        row = ""
        for l in labels:
            v = res[l].get(k, "-")
            cell = ("%.3f" % v) if isinstance(v, float) else str(v)
            row += "%14s" % (cell[:11] + "..." if len(cell) > 14 else cell)
        print("  %-18s%s" % (k, row))

    print("=" * 78)
    ctrl = res[labels[0]]
    se = 1.95 / math.sqrt(max(ctrl["num_trades"], 1))
    key = VERDICT_KEY if VERDICT_KEY in ctrl else "expectancy_R"
    if key != VERDICT_KEY:
        print("  *** WARNING: this harness has no %s. It predates commit" % VERDICT_KEY)
        print("  *** e607db9 (patch 1). expectancy_R CANNOT see a change to the")
        print("  *** partial -- the leg it books is the runner only. The verdict")
        print("  *** below is therefore BLIND to arms B and D. Apply patch 1.")
    print("  control n=%d -> SE = 1.95/sqrt(n) = %.3f R   judged on %s"
          % (ctrl["num_trades"], se, key))
    for l in labels[1:]:
        d = res[l][key] - ctrl[key]
        print("  %-34s %+.3f R  (%s)"
              % (l, d, "INSIDE the noise floor" if abs(d) < se
                 else "outside the floor -- still needs split-sample"))
    print()
    print("  How much more often would a 2R trigger fire?")
    print("    reached 2R %.1f%%   vs   reached 3R %.1f%%   (control)"
          % (ctrl.get("pct_reaching_2R", 0.0), ctrl.get("pct_reaching_3R", 0.0)))
    print()
    print("  HARNESS ONLY. F8 validated engine_v2 against this harness at the")
    print("  FROZEN constants. Nothing here is evidence about production at")
    print("  2R / one half / SMA50. Re-run F8 at the new constants first.")
    print("=" * 78)
    return 0


if __name__ == "__main__":
    sys.exit(main())
