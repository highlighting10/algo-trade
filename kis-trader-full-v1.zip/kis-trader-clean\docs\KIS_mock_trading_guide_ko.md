# KIS 모의투자 연동 가이드 (kistrader 패키지)

> 이 문서는 **`kistrader` 패키지**를 한국투자증권 **모의투자(paper)** 계좌에 연결해,
> 미국 주식 주문이 `PENDING_ENTRY → FILLED → 종료 엔진 인계`까지 도는 것을 확인하기
> 위한 실습 런북입니다. 이제는 흩어진 스크립트 대신 **명령어 3개**(`kistrader test` /
> `verify` / `run`)로 진행합니다.
>
> 모의투자라 실제 돈은 나가지 않지만, **쓰기 경로(주문/취소)와 일부 조회 필드는 아직
> 실계좌로 검증되지 않았습니다.** 그래서 "한 종목·최소 수량"으로 조심스럽게 밟습니다.

---

## 0. 준비물 한눈에

| 항목 | 값 / 메모 |
|---|---|
| 모의 REST 도메인 | `https://openapivts.koreainvestment.com:29443` (코드에 반영됨) |
| 모의투자 앱키/시크릿 | 실전과 **별도 발급** (§1) |
| 계좌번호 | 앞 8자리 = `KIS_CANO`, 뒤 2자리 = 상품코드 `KIS_PRDT`(보통 `01`) |
| 파이썬 | 3.10+ |
| 실행 시점 | 미국 정규장(한국시간 밤~새벽, §10) |
| 핵심 명령 | `kistrader test` → `kistrader verify` → `kistrader run` |

---

## 1. 모의투자 신청 & 앱키 발급

**순서가 중요합니다. 모의투자 계좌를 먼저 신청하고, 그 다음 앱키를 발급합니다.**

1. **한국투자증권 계좌 개설** (있으면 생략).
2. **모의투자 신청** — 홈페이지 `[트레이딩] → [모의투자] → [주식/선물옵션 모의투자] →
   [모의투자안내]`.
   - ⚠ **리그 구분에서 반드시 `해외주식`을 포함해 선택하세요.** 이 시스템은 미국 주식을
     거래하므로 국내주식만 선택하면 해외 주문이 되지 않습니다.
3. **KIS Developers 신청 & 앱키 발급** — `[트레이딩] → [Open API] → [KIS Developers]`.
   신청 시 **`모의투자계좌`를 선택**하고 방금 만든 모의 계좌를 입력 → **모의투자용
   `App Key` / `App Secret`** 발급(실전용과 값이 다름).
4. **계좌번호 확인** — 예 `50123456-01` → `KIS_CANO="50123456"`, `KIS_PRDT="01"`.

> 모의투자는 일부 API가 지원되지 않고 **REST 호출 제한이 실전보다 낮습니다.** 또한
> **3개월 이상 미거래 시 서비스가 자동 해지**될 수 있습니다.

---

## 2. 설치

압축을 풀고 프로젝트 루트(`kis-trader/`)에서:

```bash
python -m venv .venv
# Windows PowerShell:
.venv\Scripts\Activate.ps1
# (mac/Linux: source .venv/bin/activate)

pip install -e .            # kistrader 명령 + 기본 의존성(requests) 설치
pip install -e ".[trail]"   # + yfinance/pandas (EMA-트레일/정체청산 프로바이더용)
```

> 설치 없이도 루트에서 `python -m kistrader.cli ...` 로 동일하게 실행됩니다.

---

## 3. 설정 (.env)

루트의 `.env.example` 를 복사해 `.env` 를 만들고 **모의용** 값으로 채웁니다
(`.env` 는 git 에서 제외됨):

```ini
KIS_APP_KEY=발급받은_모의_앱키
KIS_APP_SECRET=발급받은_모의_앱시크릿
KIS_CANO=50123456
KIS_PRDT=01
KIS_MOCK=1
KIS_EQUITY_USD=100000       # 사이징 기준 계좌자본(USD). 미국 주가가 USD이므로 USD로!
# 선택:
# KIS_DB=kis_engine_state.db
# KIS_CANDIDATES=candidates.csv
```

> **통화 주의**: 사이징에 쓰는 `KIS_EQUITY_USD` 는 반드시 **USD** 기준입니다(모의 계좌가
> 원화로 채워져 있어도, 미국 주가와 통화를 맞춰야 함).

---

## 4. 코드 무결성 확인 — `kistrader test`

계좌·네트워크 없이(가짜 브로커) 코드가 온전한지부터 확인합니다.

```bash
kistrader test
```

기대: `PASSED 85 / 85` (단위) + `PASSED 17 / 17` (통합). 실패하면 설치가 꼬인 것이니
`.venv` 재활성화 후 `pip install -e .` 를 다시 하세요.

---

## 5. 인증·읽기 빠른 확인 (선택)

`kistrader verify`(§6)가 토큰·시세까지 한 번에 확인하지만, 키만 먼저 점검하려면:

```bash
python -c "from kistrader.config import Config; from kistrader.core.engine_v2 import KISBroker; \
c=Config.from_env(); b=KISBroker(c.app_key,c.app_secret,c.cano,acnt_prdt_cd=c.acnt_prdt_cd,is_mock=True); \
print('token OK:', bool(b._ensure_token())); print('AAPL:', b.get_quote('AAPL','NAS'))"
```

- `token OK: True` → 키 정상. 실패 시 실전 키를 모의에 쓴 경우가 대부분입니다.
- 시세 `last` 가 0이 아니면 조회 정상(모의는 지연 시세일 수 있음).

---

## 6. 쓰기 경로 & 필드 검증 — `kistrader verify` (월요일 미국장)

**여기서부터 실제 모의 주문이 나갑니다.** 기본 실행은 체결 위험이 없도록 **시세의 절반**
지정가 매수를 넣어 `접수 → RESTING → 취소 → GONE` 만 확인하고, 아직 미검증인 **3개 필드
이름을 원시 응답으로 덤프**합니다.

```bash
kistrader verify                # 읽기 + 미체결 쓰기 경로 (체결 없음, 안전)
kistrader verify --allow-fill   # 체결 경로까지 (모의 현금 소액 사용, 1주 잔여)
```

확인 포인트:
- `place_limit_order (resting)` → `RESTING` → 취소 후 `GONE` = 쓰기 경로 OK
- 출력의 **RAW 덤프**에서 3개 필드 이름 확인:
  1. 체결가 `ft_ccld_unpr` (get_fills_detail)
  2. 매수여력 USD 필드 (inquire-psamount)
  3. 미체결 종목코드 `pdno` (inquire-nccs)
- 이름이 다르면 해당 파일에서 한 줄만 고치면 됩니다(대개 `# VERIFY` 주석 근처).

---

## 7. candidates.csv 준비

파이프라인 입력은 `candidates.csv` 입니다. `sp500_v21.py` / `us_small_v21.py` 는 이미
**§1.6 패치 적용**이라 실제 종가·ATR를 내보냅니다. 연동 스모크용으로는 현재 시세를 읽어
**바로 체결되도록** 한 종목 CSV를 만드는 게 빠릅니다:

```python
from kistrader.config import Config
from kistrader.entry.entry_manager import KISBrokerWithEntry
from kistrader.entry.screen_contract import Candidate, write_candidates

c = Config.from_env()
b = KISBrokerWithEntry(c.app_key, c.app_secret, c.cano, acnt_prdt_cd=c.acnt_prdt_cd, is_mock=True)

TICKER, EXCH, DATE = "AAPL", "NAS", "2026-07-06"
last  = b.get_quote(TICKER, EXCH)["last"]
pivot = round(last * 0.99, 2)          # 피벗을 시세 살짝 아래로 → 돌파 상태로 간주되어 체결

cand = Candidate(
    ticker=TICKER, exchange=EXCH, rs_rating=90, stage2_score=70, vcp_score=88,
    pivot=pivot, base_high=round(pivot, 2), base_low=round(pivot*0.90, 2),
    depth_pct=0.10, last_close=round(last, 2), atr=round(last*0.02, 2),
    trade_signal=True, session_date=DATE, name="Apple", close_known=True)
print("작성:", write_candidates("candidates.csv", [cand]), "건  pivot=", pivot, " last=", last)
```

> 포인트: `close_known=True` 여야 확장 가드가 돌고 아밍됩니다. 진입 지정가는
> `pivot × (1+0.5%)` 로 계산되므로, 피벗을 시세 아래로 두면 지정가가 시세 근처가 되어
> **바로 체결**되는 걸 볼 수 있습니다. 반대로 피벗을 시세 위로 두면 **RESTING** 대기하다가
> 가격이 올라오면 체결됩니다(실전형 돌파).

---

## 8. 파이프라인 실행 — `kistrader run` (미국 장중)

먼저 **한 사이클 스모크**로 진행을 눈으로 확인합니다. 매수여력 엔드포인트를 아직 검증하지
않았다면(§6 전) `--no-bp-gate` 로 현금 게이트를 끄고 상수 자본(USD)만으로 돌립니다:

```bash
kistrader run --once --arm --no-bp-gate
```

정상 흐름 예(로그 alert):
```
arm_today: 1 candidates -> 1 planned -> 1 armed
MU FILLED 3@... stop=... — handing to monitor      ← 체결되어 종료 엔진으로 인계
```

`verify` 로 매수여력 필드를 확인한 뒤에는 게이트를 켜고 **지속 루프**로 포워드 테스트를
시작합니다:

```bash
kistrader run --arm            # 매수여력 게이트 ON, 무한 루프(종료 엔진이 계속 관리)
```

- `--arm` : 시작 시 오늘의 아밍(매수) 1회 실행. **자동 관리는 안전하지만 자동 매수는
  항상 명시적으로** 누르는 설계입니다.
- `--no-trail` : yfinance 기반 EMA/종가 프로바이더 없이 실행(트레일/정체청산 비활성).
- `--no-bp-gate` : 매수여력 게이트 끄기(§6 검증 전 스모크용).
- 진입 폴링/주문은 **미국 정규장**에만 의미가 있습니다(§10).

---

## 9. 관찰 & 검증 (이벤트 로그)

모든 상태 전이는 SQLite 이벤트 로그(`KIS_DB`, 기본 `kis_engine_state.db`)에 남습니다.

```python
import sqlite3
c = sqlite3.connect("kis_engine_state.db")
for row in c.execute("SELECT id, ticker, order_key, event_type, state_to, shares, price "
                     "FROM position_events ORDER BY id DESC LIMIT 25"):
    print(row)
```

정상 순서: `ORDER_SENT → ENTRY_ARMED(PENDING_ENTRY) → ENTRY_FILL → FILLED →`(이후 종료
엔진의 `EXIT_BEGIN`/`ORDER_WORKING`/`CLOSED` 등). ATR 없이 구조적 스탑만 잡히면
`stop_basis=structural-only` 경고가 alert로 찍힙니다(무음이 아니라 표시됨).

---

## 10. 미국장 운영 시간 (한국시간, KST)

| 미국 시간대 | 미국 정규장 | 한국시간(KST) |
|---|---|---|
| 서머타임(EDT, 3~11월) | 09:30–16:00 ET | **22:30–05:00** |
| 표준시(EST, 11~3월) | 09:30–16:00 ET | **23:30–06:00** |

- 진입 주문/폴링은 이 시간대에 실행하세요. 장 밖에서는 접수 거부/예약 처리되어 흐름이
  달라집니다.
- 거래가능 게이트 마스터파일의 최초 갱신(`kis_tradable_universe --refresh`)은 네 PC에서
  한 번 돌려두세요.

---

## 11. 모의투자 특이사항 & 위험

- **낮은 rate limit**: 모의는 초당 호출 제한이 낮습니다. `EGW00201`(거래건수 초과)이 뜨면
  `kistrader/core/engine_v2.py` 상단 상수를 낮추세요:
  ```python
  REST_RATE_HZ = 3     # 8 → 3
  REST_BURST   = 4     # 10 → 4
  ```
- **미검증 I/O(안전한 폴백 있음)**: `get_fills_detail` 체결가 필드, 매수여력 조회는 §6에서
  확인합니다. 미확인 시 진입가는 지정가로 보수적 폴백되고, 매수여력 게이트는 **읽지 못하면
  아밍을 거부**(fail-safe)합니다. 그래서 첫 스모크는 `--no-bp-gate` 로 우회합니다.
- **강제 종료 시**: 접수와 로그 사이 아주 좁은 창에서 프로세스가 죽으면 기록 없는 미체결
  매수가 남을 수 있으나, 다음 아밍에서 **미추적 미체결 주문은 자동 디덥·거부**됩니다(§3.9.1).
  그래도 강제 종료했다면 모의 앱/HTS에서 미체결 주문을 한 번 확인하세요.
- **3개월 미거래 시 서비스 자동 해지** 가능 — 포워드 테스트 중 간헐 호출 유지 권장.

---

## 12. 트러블슈팅

| 증상 | 원인 / 조치 |
|---|---|
| `missing required env var ...` | `.env` 미작성/미로딩. §3대로 작성하고 프로젝트 루트에서 실행. |
| `token issuance failed` | 실전 키를 모의에 사용. 모의용 키 확인. |
| `EGW00201` (거래건수 초과) | rate limit 초과 → §11대로 `REST_RATE_HZ` 낮추기. |
| 주문 `ok:False`, 장시간 메시지 | 미국 장 밖. §8·§10 시간대에 실행. |
| 아밍 0건, 사유 `last_close unavailable` | 후보의 `close_known=False`. CSV에 실제 종가+`close_known=True`(§7). |
| 아밍 0건, 사유 `too extended` | 종가가 피벗 +5% 초과. §7의 pivot/last_close 조정. |
| 아밍 0건, `buying power unknown (fail-safe)` | 매수여력 미검증. 첫 스모크는 `--no-bp-gate`, 이후 `kistrader verify`로 확인. |
| 체결 안 됨(계속 RESTING) | 피벗이 시세보다 높아 지정가 미달. §7처럼 피벗을 시세 아래로. |

---

## 13. 요약 체크리스트

- [ ] 모의투자 신청(해외주식 리그 포함) + 모의용 앱키 발급
- [ ] `pip install -e .` (필요시 `".[trail]"`)
- [ ] `.env` 작성(모의 키 + `KIS_EQUITY_USD`)
- [ ] `kistrader test` → 85/85 + 17/17
- [ ] (선택) §5 토큰/시세 빠른 확인
- [ ] `kistrader verify` (미국장) — 접수→RESTING→취소→GONE + 3개 필드 확인
- [ ] `candidates.csv` 준비(§7)
- [ ] `kistrader run --once --arm --no-bp-gate` (미국장) — 아밍→체결→인계 확인
- [ ] `kistrader run --arm` — 지속 포워드 루프 시작
- [ ] 이벤트 로그(§9)로 상태 전이 확인
