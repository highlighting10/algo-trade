#!/usr/bin/env python3
"""
patch_screener_tee.py -- make the run-log tee unable to kill a run.

FOUND BY: pytest, on Windows, running the Phase 3b harness.

    OSError: [WinError 6] The handle is invalid
      screeners/sp500_v21.py:292 in _Tee.write -> st.flush()

Direct runs pass; only pytest fails. That is not a test problem. pytest's default
fd-level capture redirects file descriptors 1/2, which leaves `sys.__stdout__`
pointing at a handle the process can no longer write to -- and `_Tee` calls
`.flush()` on it with no error handling, so the whole run dies.

THREE DEFECTS, all in ~15 lines

1. _Tee.write / _Tee.flush have NO error handling. Any stream that fails takes
   the entire screener down. Production paths that produce exactly this: a
   broken stdout pipe (supervisor.py dies, or the operator pipes the run into
   `head`), and a console-less process (pythonw, a service).

2. It tees onto sys.__stdout__ -- the ORIGINAL process stdout -- rather than
   sys.stdout. That deliberately bypasses any redirection already in place,
   which is what makes it break under capture, and what would make it ignore a
   wrapper installed by a caller.

3. The error handler cannot report its own error. sys.stdout is replaced BEFORE
   the print that may fail, so the `except` branch's print goes through the
   same broken tee and raises again. The traceback shows exactly this:
   "During handling of the above exception, another exception occurred."

THE FIX
_Tee drops a stream that fails instead of raising, and _setup_run_log opens the
file BEFORE swapping stdout, so a failure is reported on a stream that still
works. `write` also returns a character count, which file-like consumers expect,
and `isatty` is forwarded so colour/progress libraries behave.

The docstring already promised "best-effort"; this makes the tee itself
best-effort too, not just the file open.

Usage:  python patch_screener_tee.py <repo-root>
"""
from __future__ import annotations

import os
import sys

OLD = '''class _Tee:
    """Duplicate writes to several streams (console + a run-log file)."""
    def __init__(self, *streams):
        self._streams = streams
    def write(self, data):
        for st in self._streams:
            st.write(data)
            st.flush()
    def flush(self):
        for st in self._streams:
            st.flush()


def _setup_run_log(prefix):
    """Tee stdout for this run into runs/<prefix>_<timestamp>.log. Best-effort:
    if the file can't be opened the run simply continues console-only."""
    try:
        os.makedirs("runs", exist_ok=True)
        path = os.path.join("runs", f"{prefix}_{time.strftime('%Y-%m-%d_%H%M%S')}.log")
        logf = open(path, "a", encoding="utf-8")
        sys.stdout = _Tee(sys.__stdout__, logf)
        print(f"[log] recording this run to {path}")
    except Exception as e:
        print(f"[log] could not open run log ({e}); continuing console-only.")
'''

NEW = '''class _Tee:
    """Duplicate writes to several streams (console + a run-log file).

    A stream that fails is DROPPED, never allowed to raise. Logging is a
    convenience; it must not be able to kill a screener run. The failure modes
    this actually protects against are real: a broken stdout pipe (the parent
    process dies, or the run is piped into something that exits early), a
    console-less process, and a file descriptor that has been redirected out
    from under the original stream -- which is how this was found, as
    `OSError: [WinError 6] The handle is invalid` from a bare `st.flush()`.
    """
    def __init__(self, *streams):
        self._streams = [s for s in streams if s is not None]

    def _each(self, op):
        dead = []
        for st in self._streams:
            try:
                op(st)
            except Exception:                 # noqa: BLE001 — see the docstring
                dead.append(st)
        if dead:
            self._streams = [s for s in self._streams if s not in dead]

    def write(self, data):
        self._each(lambda st: (st.write(data), st.flush()))
        return len(data)                      # file-like consumers expect a count

    def flush(self):
        self._each(lambda st: st.flush())

    def isatty(self):
        return any(getattr(s, "isatty", lambda: False)() for s in self._streams)


def _setup_run_log(prefix):
    """Tee stdout for this run into runs/<prefix>_<timestamp>.log.

    Best-effort in BOTH directions: an unopenable log leaves the run
    console-only, and a console stream that cannot be written is dropped by
    _Tee rather than crashing the screener.

    Tees onto the CURRENT sys.stdout, not sys.__stdout__: the original handle
    may have been redirected out from under the process, and a caller that has
    deliberately wrapped stdout should be respected, not bypassed.

    The file is opened BEFORE stdout is swapped, so if the open fails the error
    is reported on a stream that still works -- previously the handler's own
    print went through the half-installed tee and raised again.
    """
    original = sys.stdout
    try:
        os.makedirs("runs", exist_ok=True)
        path = os.path.join("runs", f"{prefix}_{time.strftime('%Y-%m-%d_%H%M%S')}.log")
        logf = open(path, "a", encoding="utf-8")
    except Exception as e:
        print(f"[log] could not open run log ({e}); continuing console-only.")
        return
    sys.stdout = _Tee(original, logf)
    print(f"[log] recording this run to {path}")
'''


def main(root):
    changed = 0
    for name in ("sp500_v21.py", "us_small_v21.py"):
        p = os.path.join(root, "screeners", name)
        if not os.path.isfile(p):
            raise SystemExit(f"REFUSING: not found: {p}")
        with open(p, encoding="utf-8") as f:
            s = f.read()
        if "def _each(self, op):" in s:
            print(f"  -- {name}: already patched, skipped")
            continue
        n = s.count(OLD)
        if n != 1:
            raise SystemExit(f"REFUSING: {name}: anchor matched {n} times, expected 1")
        with open(p, "w", encoding="utf-8", newline="") as f:
            f.write(s.replace(OLD, NEW))
        print(f"  ok  {name}: _Tee drops dead streams; _setup_run_log opens before swapping")
        changed += 1
    if not changed:
        raise SystemExit("REFUSING: nothing to do (both already patched).")
    print("\nAPPLIED. Verify with:  python -m pytest -q")
    return 0


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("usage: python patch_screener_tee.py <repo-root>")
    sys.exit(main(sys.argv[1]))
