#!/usr/bin/env python3
r"""
s6_wavecount_probe.py -- S6a. How many six-wave VCPs are there, actually?

TARGET REPO: kis-backtest.  READ-ONLY: writes no pickle, touches no checkpoint,
patches nothing on disk. It monkey-patches the analyzer IN MEMORY to observe,
and restores it in a finally.

WHY THIS EXISTS -- S6 is not the one-line change the plan calls it

PLAN sec.4 lists S6 as "one dict entry":

    # vcp_engine.py:120
    wave_count_points: dict = field(default_factory=lambda: {4: 15, 3: 13, 5: 10, 2: 8})

A six-wave VCP scores `get(6, 0) = 0` on stage 3/4 and forfeits the full
15-point budget. Normalised (`final = raw / max_score * 100`, max_score = 104.0)
that is 15/104*100 = **14.42 of 100** -- exactly the figure the ledger records.

But VCP scoring happens in the SIGNAL PASS, not the backtest.
`signals.py::_to_candidate` keeps only the total:

    vcp_score=float(_num(rep.get("Score"))),

`BTCandidate` carries no wave count and no per-stage sub-score, so the emitted
score cannot be re-derived offline. Changing `wave_count_points` therefore means
re-running `04_signals.py` -- "THE EXPENSIVE STEP", ~1-3 hours for a full daily
pass -- ONCE PER ARM. Four arms is four of those.

And six-wave names are currently INVISIBLE: forfeiting 14.42 points puts them
below threshold 75, so they never emit and nothing in signals_daily.pkl records
that they existed.

WHAT THIS PROBE DOES INSTEAD -- one SAMPLED pass, minutes not hours

It runs the real `generate_signals_by_population` over every Nth session
(default 20) and records, for every SCORED name, the wave count and the exact
counterfactual score.

THE COUNTERFACTUAL IS EXACT, NOT ESTIMATED. Two facts make it so:

  1. stage 3/4 is `score = base_points * quality_ratio`, and for n=6
     base_points is 0, so its current contribution is exactly ZERO.
  2. `max_score = 104.0` is a CONFIG CONSTANT, independent of
     wave_count_points, so the normalising denominator does not move.

Therefore, for a six-wave name scoring `S` with contraction quality `q`, giving
`wave_count_points[6] = P` yields

    S_new = min(S + P * q * 100 / 104, 100)

with no re-run required. The probe reports how many six-wave names would cross
the threshold at P in {5, 8, 10}.

HOW TO READ THE OUTPUT

  * "six-wave names scored" near zero  -> S6 is IMMATERIAL. Close it, record the
    forfeit as a scoring asymmetry that never binds, and do NOT spend four
    expensive signal regenerations on it.
  * a material count that CROSSES the threshold -> S6b is earned: run the real
    arms, and land the dict change in BOTH screeners as well as the harness
    engine (test_screener_harness S13, patch I2, is what catches doing one).

The probe cannot tell you whether those trades would be GOOD. It sizes the
question; it does not answer it.

CAVEAT ON SAMPLING. Every Nth session is a fair sample of the wave-count
DISTRIBUTION, not a census. Counts scale by ~N; treat them as an order of
magnitude, which is all a go/no-go needs.

Usage (from the kis-backtest root, with its venv active):

    python s6_wavecount_probe.py                     # every 20th session, 2018+
    python s6_wavecount_probe.py --every 5           # denser, slower
    python s6_wavecount_probe.py --csv s6_waves.csv  # dump the raw records
"""
from __future__ import annotations

import argparse
import os
import pathlib
import sys
import time
from collections import Counter


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", default=".")
    ap.add_argument("--every", type=int, default=20,
                    help="sample every Nth session (default 20). This is a "
                         "DISTRIBUTION sample, not a census -- counts scale ~N.")
    ap.add_argument("--start", default="2018-01-01",
                    help="Rev 3's window start; signals_daily.pkl begins here")
    ap.add_argument("--end", default=None)
    ap.add_argument("--threshold", type=float, default=75.0,
                    help="the frozen VCP_SCORE_THRESHOLD")
    ap.add_argument("--points", type=float, nargs="+", default=[5.0, 8.0, 10.0],
                    help="candidate values for wave_count_points[6]")
    ap.add_argument("--csv", default=None,
                    help="optional path to dump every scored record")
    a = ap.parse_args()

    root = os.path.abspath(a.repo)
    sys.path.insert(0, root)
    os.chdir(root)          # signals.py and its helpers use relative data paths

    import pandas as pd
    import vcp_engine as ve
    from signals import (PITBars, generate_signals_by_population,
                         populations_from_universe)

    print("=" * 78)
    print("  S6a -- six-wave VCP sizing probe   (READ-ONLY, no pickle written)")
    print("=" * 78)

    cfg_pts = ve.VCPConfig().wave_count_points if hasattr(ve, "VCPConfig") else None
    if cfg_pts is None:                       # config class name may differ
        import dataclasses
        for _n in dir(ve):
            _o = getattr(ve, _n)
            if dataclasses.is_dataclass(_o) and "wave_count_points" in {
                    f.name for f in dataclasses.fields(_o)}:
                cfg_pts = _o().wave_count_points
                break
    if cfg_pts is None:
        print("  FATAL: could not locate wave_count_points on any engine config "
              "dataclass. The engine has changed; re-read vcp_engine.py.")
        return 2
    max_score = None
    import dataclasses
    for _n in dir(ve):
        _o = getattr(ve, _n)
        if dataclasses.is_dataclass(_o) and "max_score" in {
                f.name for f in dataclasses.fields(_o)}:
            max_score = float(_o().max_score)
            break
    if not max_score:
        print("  FATAL: could not read max_score off the engine config.")
        return 2

    print(f"  wave_count_points : {cfg_pts}")
    print(f"  max_score         : {max_score}")
    top = max(cfg_pts.values())
    print(f"  a 6-wave base forfeits the whole {top:g}-point budget = "
          f"{top / max_score * 100:.2f} of 100")
    if cfg_pts.get(6):
        print(f"  NOTE wave_count_points already has a 6 entry ({cfg_pts[6]}). "
              f"This probe assumes the CURRENT contribution is 0 and will "
              f"OVERSTATE the counterfactual. Fix the arithmetic before "
              f"trusting it.")

    # ---- observe, do not modify -------------------------------------------
    REC = []
    _orig_s34 = ve.VCPAnalyzerV4.stage_3_and_4_contractions
    _orig_rep = ve.VCPAnalyzerV4.generate_report

    def _s34(self, waves):
        score, detail = _orig_s34(self, waves)
        self._s6_detail = detail
        return score, detail

    def _rep(self, *args, **kw):
        self._s6_detail = None
        rep = _orig_rep(self, *args, **kw)
        d = getattr(self, "_s6_detail", None)
        if rep and isinstance(d, dict):
            REC.append((int(d.get("wave_count") or 0),
                        float(d.get("wave_count_points") or 0.0),
                        float(d.get("contraction_quality") or 0.0),
                        float(rep.get("Score") or 0.0)))
        return rep

    # VCPAnalyzerV3 is an alias for the same class object, so this covers both.
    ve.VCPAnalyzerV4.stage_3_and_4_contractions = _s34
    ve.VCPAnalyzerV4.generate_report = _rep

    try:
        warm = pd.Timestamp(a.start) - pd.DateOffset(years=3)
        bars = {}
        for p in pathlib.Path("data/bars").glob("*.parquet"):
            df = pd.read_parquet(p)
            if getattr(df.index, "tz", None) is not None:
                df.index = df.index.tz_localize(None)
            df = df.loc[df.index >= warm]
            if not df.empty:
                bars[p.stem] = df
        if "^GSPC" not in bars:
            print("  FATAL: ^GSPC missing from data/bars. Run 02_download.py.")
            return 2
        print(f"  {len(bars)} ticker(s) loaded, history trimmed to "
              f">= {warm.date()}")

        cal = PITBars(bars).calendar()
        lo = pd.Timestamp(a.start)
        hi = pd.Timestamp(a.end) if a.end else cal[-1]
        scan = cal[(cal >= lo) & (cal <= hi)][::a.every]
        if not len(scan):
            print("  FATAL: no sessions in the requested window.")
            return 2
        print(f"  sampling {len(scan)} session(s) {scan[0].date()}"
              f"..{scan[-1].date()}, every {a.every}")
        print(f"  rough estimate {len(scan) * len(bars) / 60000:.0f}-"
              f"{len(scan) * len(bars) / 20000:.0f} min "
              f"(a FULL daily pass would be "
              f"{len(cal[(cal >= lo) & (cal <= hi)]) * len(bars) / 60000:.0f}-"
              f"{len(cal[(cal >= lo) & (cal <= hi)]) * len(bars) / 20000:.0f} min "
              f"-- and S6b needs one PER ARM)")

        pops = populations_from_universe("data/universe.csv")
        have = set(bars)
        pops = {k: [t for t in v if t in have] for k, v in pops.items()}
        print("  populations: " + ", ".join(f"{k}={len(v)}"
                                            for k, v in pops.items()))
        print()
        t0 = time.time()
        # checkpoint_dir=None / resume=False: this probe must not read or write
        # the checkpoints the real signal pass uses.
        generate_signals_by_population(bars, scan, pops, emit_threshold=0.0,
                                       checkpoint_dir=None, resume=False)
        dt = time.time() - t0
    finally:
        ve.VCPAnalyzerV4.stage_3_and_4_contractions = _orig_s34
        ve.VCPAnalyzerV4.generate_report = _orig_rep

    if not REC:
        print("\n  NO RECORDS. Nothing was scored -- check the window and the "
              "universe before reading anything into this.")
        return 1

    print("\n" + "=" * 78)
    print(f"  {len(REC):,} scored name-sessions in {dt/60:.1f} min")
    print("=" * 78)

    hist = Counter(w for w, _b, _q, _s in REC)
    print("  wave-count distribution among SCORED names:")
    for n in sorted(hist):
        pts = cfg_pts.get(n, 0)
        print(f"    {n:2d} waves  {hist[n]:7,}  ({hist[n]/len(REC)*100:5.2f}%)"
              f"   base_points={pts:g}"
              + ("   <-- FORFEITS THE BUDGET" if not pts and n >= 2 else ""))

    cur_pass = sum(1 for _w, _b, _q, s in REC if s >= a.threshold)
    print(f"\n  currently clearing threshold {a.threshold:g}: {cur_pass:,} "
          f"({cur_pass/len(REC)*100:.2f}% of scored)")

    six = [(q, s) for w, _b, q, s in REC if w == 6]
    print(f"\n  SIX-WAVE names scored: {len(six):,} "
          f"({len(six)/len(REC)*100:.2f}% of scored)")
    if not six:
        print("  -> ZERO six-wave bases in this sample. S6 is IMMATERIAL: the "
              "14.42-point forfeit never binds.")
        print("  -> Close S6 without running the arms. Record it as a scoring "
              "asymmetry with no population.")
    else:
        six_now = sum(1 for _q, s in six if s >= a.threshold)
        print(f"  of those, already clearing {a.threshold:g}: {six_now:,}")
        print(f"\n  counterfactual  S_new = min(S + P*q*100/{max_score:g}, 100)")
        print(f"  {'P':>5}  {'newly clears':>13}  {'total 6-wave clearing':>22}"
              f"  {'% of all clearing':>18}")
        for P in a.points:
            newly = sum(1 for q, s in six
                        if s < a.threshold
                        and min(s + P * q * 100.0 / max_score, 100.0) >= a.threshold)
            tot = six_now + newly
            denom = cur_pass + newly
            print(f"  {P:5g}  {newly:13,}  {tot:22,}"
                  f"  {(tot/denom*100 if denom else 0):17.2f}%")
        print("\n  READ IT AS A GO/NO-GO, not as a result:")
        print("    a handful of names across the window -> close S6, no arms.")
        print("    a material share -> S6b is earned. Land the dict change in")
        print("    BOTH screeners as well as vcp_engine.py; test_screener_harness")
        print("    S13 (patch I2) is what catches landing it in one file only.")
        print("    This probe sizes the question. It cannot say the extra trades")
        print("    would be GOOD -- only the arms can.")

    if a.csv:
        import csv as _csv
        with open(a.csv, "w", newline="", encoding="utf-8") as fh:
            w = _csv.writer(fh)
            w.writerow(["wave_count", "base_points", "contraction_quality",
                        "score"])
            w.writerows(REC)
        print(f"\n  raw records -> {a.csv}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
