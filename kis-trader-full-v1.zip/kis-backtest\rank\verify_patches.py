#!/usr/bin/env python3
"""
VERIFY PATCH 1 -- prove it is behaviour-preserving, and prove the new number is
the right number.

Runs the SAME scenario through the original harness and the patched one and
asserts:

  1. every summary key that existed before is IDENTICAL -- to the last decimal,
     including expectancy_R, which scripts/06_sweep.py's FALLACY-4 test depends
     on being position-size invariant;
  2. every Trade's original fields are identical;
  3. on a PARTIALLED trade, expectancy_R_weighted matches hand arithmetic and
     differs from expectancy_R by exactly the amount the partial leg is worth;
  4. on a NON-partialled trade the two metrics are EQUAL, because there is no
     second leg -- if they ever differ there, the helper is wrong.

Needs no pristine copy: it reads the PATCHED file and reconstructs the original
in memory by reversing patch_1's edits, so what it compares is exactly what is
on disk right now.

Run from the kis-backtest root, after patch 1:

    python rank\\verify_patches.py
"""
from __future__ import annotations

import importlib.util
import os
import sys

import pandas as pd

ENTRY, STOP = 100.0, 90.0
PIVOT, CONTRACTION_LOW, ATR = 99.5025, 90.452261, 0.5
WARMUP = 30
EQUITY = 30.5 * 10 / 0.0085          # floors to exactly 30 shares


def build_pair(live_path):
    """Return (original_src, patched_src) from the LIVE file.

    Reverses patch_1's edits in memory rather than trusting a saved copy -- the
    thing under test is what is on disk, not what someone remembered to keep.
    """
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    from patch_1_weighted_expectancy import EDITS, MARK
    with open(live_path, encoding="utf-8") as fh:
        patched = fh.read()
    if MARK not in patched:
        raise SystemExit(
            f"{live_path} does not carry patch 1. Apply it first:\n"
            f"  python rank\\patch_1_weighted_expectancy.py --file {live_path}")
    original = patched
    for label, anchor, repl in EDITS:
        if original.count(repl) != 1:
            raise SystemExit(f"cannot reconstruct the original: {label!r} "
                             f"appears {original.count(repl)} times, expected 1")
        original = original.replace(repl, anchor)
    return original, patched


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, os.path.abspath(path))
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


def frame(bars):
    rows, idx = [], []
    for i in range(WARMUP):
        idx.append(pd.Timestamp("2025-01-01") + pd.Timedelta(days=i))
        rows.append((99.0, 99.0, 99.0, 99.0, 1_000_000.0))
    for j, (o, h, l, c) in enumerate(bars):
        idx.append(pd.Timestamp("2025-01-01") + pd.Timedelta(days=WARMUP + j))
        rows.append((o, h, l, c, 1_000_000.0))
    return pd.DataFrame(rows, index=pd.DatetimeIndex(idx),
                        columns=["Open", "High", "Low", "Close", "Volume"])


def run_one(m, bars):
    df = frame(bars)
    m._ema = lambda close, span=m.EMA_LEN: pd.Series(
        [float("nan")] * len(df), index=df.index, dtype=float)
    cand = m.BTCandidate(
        ticker="TST", exchange="NAS", pivot=PIVOT, contraction_low=CONTRACTION_LOW,
        atr=ATR, last_close=99.0, rs_rating=90, vcp_score=90.0,
        session_date=str(df.index[WARMUP - 1].date()), close_known=True,
        trade_signal=True)
    cfg = m.BacktestConfig(
        rank_mode="vcp_only", equity_mode="fixed", starting_equity=EQUITY,
        entry_mode="pivot_limit", ambiguity_mode="worst", vcp_threshold=0.0,
        stall_day=252, stall_mode="legacy", be_trigger_r=None, regime_ma=None,
        slippage_bps=0.0, broker_commission_pct=0.0, sec_fee_pct=0.0,
        taf_per_share=0.0, taf_cap_per_trade=0.0, allow_missing_sector_map=True,
        decision=m.DecisionConfig(risk_per_trade_pct=0.0085, max_position_pct=0.25))
    _eq, trades, stats, _drops, _diag = m.run({"TST": df}, {df.index[WARMUP - 1]: [cand]}, cfg)
    return trades, stats


PASS, FAIL = [], []


def check(name, cond, detail=""):
    (PASS if cond else FAIL).append(name)
    print(f"  [{'PASS' if cond else 'FAIL'}] {name}" + (f"   ({detail})" if detail and not cond else ""))


SCENARIOS = {
    # +3R partial at 130, runner stopped at breakeven 100 -> the maximal gap
    "partialled": [(100, 105, 98, 104), (105, 132, 104, 130), (125, 126, 99, 101)],
    # never reaches +3R; stopped out. No second leg, so the metrics must agree.
    "not partialled": [(100, 105, 98, 104), (104, 106, 88, 92)],
}


def main():
    import argparse, tempfile
    ap = argparse.ArgumentParser()
    ap.add_argument("--file", default="minervini_backtest.py")
    a = ap.parse_args()
    if not os.path.isfile(a.file):
        print(f"FATAL: no such file {a.file!r} -- run from the kis-backtest root.")
        return 2
    original, patched = build_pair(a.file)
    tmp = tempfile.mkdtemp(prefix="verify_p1_")
    po = os.path.join(tmp, "mb_orig.py"); pp = os.path.join(tmp, "mb_patched.py")
    for path, src in ((po, original), (pp, patched)):
        with open(path, "w", encoding="utf-8", newline="\n") as fh:
            fh.write(src)
    print(f"  reconstructed the pre-patch original in {tmp}")
    A = load(po, "mb_orig"); B = load(pp, "mb_patched")

    print("=" * 74)
    print("  VERIFY PATCH 1 -- behaviour-preserving?")
    print("=" * 74)

    for label, bars in SCENARIOS.items():
        print(f"\n  scenario: {label}")
        ta, sa = run_one(A, bars)
        tb, sb = run_one(B, bars)

        check(f"{label}: same trade count", len(ta) == len(tb), f"{len(ta)} vs {len(tb)}")
        if not ta or not tb:
            check(f"{label}: produced a trade", False, "no trade -- fixture broken")
            continue

        shared = [k for k in sa if k in sb]
        diffs = [k for k in shared if sa[k] != sb[k]]
        check(f"{label}: all {len(shared)} pre-existing summary keys unchanged",
              not diffs, f"differ: {diffs}")

        a, b = ta[0], tb[0]
        same_trade = all(getattr(a, f) == getattr(b, f) for f in
                         ("ticker", "entry_date", "exit_date", "entry_price",
                          "exit_price", "shares", "reason", "r_at_exit",
                          "max_r_seen", "days_held", "risk_per_share"))
        check(f"{label}: Trade fields unchanged", same_trade)

        pq = getattr(b, "partial_qty", 0)
        runner = b.shares
        total = runner + pq
        want = ((pq * (getattr(b, "partial_fill", 0.0) - b.entry_price)
                 + runner * (b.exit_price - b.entry_price))
                / (total * b.risk_per_share)) if b.risk_per_share > 0 else b.r_at_exit
        print(f"        entry {b.entry_price}  partial {pq} @ "
              f"{getattr(b,'partial_fill',0.0)}  runner {runner} @ {b.exit_price}")
        print(f"        expectancy_R          = {sb['expectancy_R']}")
        print(f"        expectancy_R_weighted = {sb['expectancy_R_weighted']}   "
              f"(hand arithmetic {round(want,3)})")
        check(f"{label}: weighted matches hand arithmetic",
              abs(sb["expectancy_R_weighted"] - round(want, 3)) < 1e-9,
              f"{sb['expectancy_R_weighted']} vs {round(want,3)}")
        check(f"{label}: partialled_trades counted",
              sb["partialled_trades"] == (1 if pq > 0 else 0))

        if pq == 0:
            check(f"{label}: NO second leg -> the two metrics are equal",
                  abs(sb["expectancy_R"] - sb["expectancy_R_weighted"]) < 1e-9,
                  f"{sb['expectancy_R']} vs {sb['expectancy_R_weighted']}")
        else:
            check(f"{label}: partial leg makes them differ",
                  abs(sb["expectancy_R"] - sb["expectancy_R_weighted"]) > 1e-6,
                  "they are equal, so the partial leg is not being counted")

    print("\n" + "=" * 74)
    print(f"  PASSED {len(PASS)} / {len(PASS) + len(FAIL)}")
    if FAIL:
        print("  FAILED: " + "; ".join(FAIL))
    print("=" * 74)
    return 1 if FAIL else 0


if __name__ == "__main__":
    sys.exit(main())
