"""
signals.py -- point-in-time signal generation for the Step-5 backtest.

Turns stored daily bars into `BTCandidate` objects, one batch per simulated
session date T, by running the SAME Stage-1 + VCP code production runs
(`vcp_engine.py`, a verbatim extraction).

THE LOOK-AHEAD CONTRACT
-----------------------
Every slice ends at T inclusive. Nothing after T is visible, ever. Two different
windows come off the same T, because production uses two:

    Stage 1 (trend template + RS)  ->  trailing '1y', rejects below 221 rows
    Stage 3 (VCP engine)           ->  trailing '2y'

RS RATING IS A POPULATION STATISTIC
-----------------------------------
`compute_rs_ratings` converts each name's weighted return into a PERCENTILE across
the scanned population. It is therefore recomputed from scratch at every T over
whatever universe was live at that T -- it is not a per-ticker value that can be
cached. Change the universe and every RS rating changes.

WHAT THIS MODULE DOES NOT DO
----------------------------
* Stage 2 (catalyst) is CUT -- lookahead via current fundamentals, and the Gemini
  half is unbacktestable. `stage2_score` stays 0.0 and `rank_mode` never reads it.
* It does not fix survivorship bias. If `universe_at` returns today's constituents
  for a 2015 date, the output is survivorship-biased and every downstream number
  is an optimistic ceiling. Feed it a point-in-time universe when one exists.
"""
from __future__ import annotations

import pathlib as _pl
from typing import Callable, Dict, List, Optional

import numpy as np
import pandas as pd

import vcp_engine as ve
from minervini_backtest import BTCandidate

# Production defaults, mirrored from sp500_v21.py. Do not tune here -- these are
# inputs to the backtest, not decisions taken inside it.
RS_RATING_THRESHOLD = 70
STAGE1_MIN_ROWS = 221
STAGE1_PERIOD = "1y"
VCP_PERIOD = "2y"
VCP_BENCHMARK = "^GSPC"

_PERIOD_SESSIONS = {"1y": 252, "2y": 504, "6mo": 126, "3mo": 63, "max": 10 ** 6}

# yfinance's period= is a CALENDAR window, not a session count: history(period="2y")
# on 2026-08-05 starts at 2024-08-05. Slicing tail(504) instead starts at
# 2024-08-01, adding bars at the FRONT of the window -- and the base detector is
# sensitive to the front edge, because an extra early high can expose a competing
# earlier base and move Base_Start_Bar by hundreds of bars. "calendar" reproduces
# what the production screener actually calls; "sessions" is the old behaviour,
# kept so 03c_window.py can compare them.
_PERIOD_OFFSETS = {
    "1y": pd.DateOffset(years=1),
    "2y": pd.DateOffset(years=2),
    "6mo": pd.DateOffset(months=6),
    "3mo": pd.DateOffset(months=3),
}


class PITBars:
    """Point-in-time bar server. Holds full history; serves only <= T.

    The whole look-ahead guard lives here, in one place, so no caller can leak
    the future by accident."""

    def __init__(self, bars: Dict[str, pd.DataFrame], period_mode: str = "calendar"):
        if period_mode not in ("calendar", "sessions"):
            raise ValueError("period_mode must be 'calendar' or 'sessions'")
        self.period_mode = period_mode
        self.bars = {}
        for t, df in bars.items():
            df = df.sort_index()
            if getattr(df.index, "tz", None) is not None:
                # Ticker().history() is tz-aware, yf.download() is not. Mixing
                # them makes `d in df.index` silently miss. Normalise once.
                df = df.tz_localize(None)
            self.bars[t] = df
        self.T: Optional[pd.Timestamp] = None

    def set_date(self, T):
        self.T = pd.Timestamp(T)

    def fetch(self, ticker: str, period: str) -> Optional[pd.DataFrame]:
        """The callable injected into vcp_engine. Signature matches the
        screener's _fetch_history(ticker, period)."""
        if self.T is None:
            raise RuntimeError("PITBars.set_date(T) must be called before fetch()")
        df = self.bars.get(ticker)
        if df is None or df.empty:
            return None
        window = df.loc[:self.T]
        if window.empty:
            return None
        if self.period_mode == "calendar":
            off = _PERIOD_OFFSETS.get(period)
            if off is None:
                return window.copy()                      # "max"
            return window.loc[window.index >= (self.T - off)].copy()
        n = _PERIOD_SESSIONS.get(period, 252)
        return window.tail(n).copy()

    def calendar(self) -> pd.DatetimeIndex:
        idx = set()
        for df in self.bars.values():
            idx |= set(df.index)
        return pd.DatetimeIndex(sorted(idx))


def generate_signals(bars: Dict[str, pd.DataFrame],
                     dates,
                     universe_at: Callable[[pd.Timestamp], List[str]],
                     *,
                     vcp_config=None,
                     emit_threshold: float = 0.0,
                     rs_threshold: int = RS_RATING_THRESHOLD,
                     log=print) -> Dict[pd.Timestamp, List[BTCandidate]]:
    """{date: [BTCandidate]} for the harness.

    `universe_at(T)` -> tickers that were in the index at T. Pass a constant
    lambda for a survivorship-biased run; pass real PIT membership when you have
    it. Either way the choice is explicit and appears in the run log.

    `emit_threshold` is 0.0 on purpose: emit EVERYTHING scored and let
    `BacktestConfig.vcp_threshold` do the filtering, so one signal pass can feed a
    whole threshold sweep. Filtering here would silently fix parked parameter #1.
    """
    server = PITBars(bars)
    ve.set_fetcher(server.fetch)
    analyzer_cfg = vcp_config or ve.VCPConfig()

    out: Dict[pd.Timestamp, List[BTCandidate]] = {}
    stats = {"dates": 0, "scanned": 0, "stage1_pass": 0, "rs_pass": 0,
             "vcp_scored": 0, "emitted": 0}
    reasons: Dict[str, int] = {}

    for T in pd.DatetimeIndex([pd.Timestamp(d) for d in dates]):
        server.set_date(T)
        tickers = list(universe_at(T))
        if not tickers:
            continue
        stats["dates"] += 1

        # ---- Stage 1: structural pass + raw RS score, per ticker -------------
        # Return shape (verified against the extraction, NOT assumed):
        #   (structural_pass, current_price, high_20d, stock_6m_return,
        #    raw_rs_score, status)
        # raw_rs_score is index 4. It is populated even when structural_pass is
        # False, because RS is a percentile over EVERY successfully scored name,
        # not just the survivors -- see compute_rs_ratings' docstring.
        raw_scores, survivors = {}, []
        for t in tickers:
            stats["scanned"] += 1
            try:
                res = ve.check_minervini_technicals(t)
            except Exception as e:                       # never abort the batch
                reasons["exception"] = reasons.get("exception", 0) + 1
                log(f"[signals] {T.date()} {t}: {type(e).__name__}: {e}")
                continue
            structural_pass, raw_rs, status = res[0], res[4], res[5]
            if raw_rs is not None:
                raw_scores[t] = raw_rs                   # scored even if it fails
            if not structural_pass:
                reasons[status] = reasons.get(status, 0) + 1
                continue
            stats["stage1_pass"] += 1
            survivors.append(t)

        if not survivors or not raw_scores:
            continue

        # ---- RS Rating: percentile ACROSS THE POPULATION SCANNED AT THIS T ---
        ratings = ve.compute_rs_ratings(raw_scores)

        # ---- Stage 3: VCP, only on names clearing the RS gate ----------------
        # The benchmark slice is identical for every ticker on this date, so hoist
        # it out of the loop -- it was being recomputed once per scored name.
        index_df = server.fetch(VCP_BENCHMARK, VCP_PERIOD)
        todays: List[BTCandidate] = []
        for t in survivors:
            rs = ratings.get(t)
            if rs is None or rs < rs_threshold:
                reasons["rs_below_threshold"] = reasons.get("rs_below_threshold", 0) + 1
                continue
            stats["rs_pass"] += 1
            df = server.fetch(t, VCP_PERIOD)
            if df is None or df.empty:
                reasons["vcp_no_data"] = reasons.get("vcp_no_data", 0) + 1
                continue
            try:
                rep = ve.VCPAnalyzerV4(df, index_df=index_df,
                                       config=analyzer_cfg).generate_report()
            except Exception as e:
                reasons["vcp_exception"] = reasons.get("vcp_exception", 0) + 1
                log(f"[signals] {T.date()} {t}: VCP {type(e).__name__}: {e}")
                continue
            if not rep:
                reasons["vcp_no_report"] = reasons.get("vcp_no_report", 0) + 1
                continue
            stats["vcp_scored"] += 1

            c = _to_candidate(t, rep, int(rs), T)
            if c is None:
                reasons["incomplete_report"] = reasons.get("incomplete_report", 0) + 1
                continue
            if c.vcp_score < emit_threshold:
                continue
            todays.append(c)

        if todays:
            out[T] = todays
            stats["emitted"] += len(todays)

    log(f"[signals] {stats['dates']} session(s); scanned {stats['scanned']}, "
        f"stage1 {stats['stage1_pass']}, rs>= {rs_threshold} {stats['rs_pass']}, "
        f"vcp scored {stats['vcp_scored']}, emitted {stats['emitted']}")
    for k, v in sorted(reasons.items(), key=lambda kv: -kv[1]):
        log(f"[signals]   dropped {v:6} x {k}")
    return out


def _to_candidate(ticker: str, rep: dict, rs: int, T) -> Optional[BTCandidate]:
    """Map a VCP report onto the entry contract. Fails CLOSED: a report missing
    pivot or the contraction low cannot produce the production stop, so it is
    dropped rather than patched with a fabricated anchor.

    SCHEMA NOTE (verified against the extracted engine, not assumed): the
    geometry lives NESTED under rep["Extracted_Pattern"] -- Pivot, Wave_Lows,
    Wave_Highs, Base_Low, Latest_Close, Latest_ATR. Only Score, Grade and
    Trade_Signal_Active sit at the top level. Reading the top level for pivot
    silently yields None and drops every name.

    Confirmed on a live report: Pivot == Wave_Highs[-1], and
    (Pivot - Wave_Lows[-1]) / Pivot == Wave_Depths_Pct[-1] -- so contraction_low
    is Wave_Lows[-1], exactly as decision_engine documents.
    """
    pat = rep.get("Extracted_Pattern") or {}

    def _get(key):
        return pat.get(key, rep.get(key))

    pivot = _num(_get("Pivot"))
    lows = _get("Wave_Lows") or []
    contraction_low = _num(lows[-1]) if len(lows) else 0.0
    if pivot <= 0 or contraction_low <= 0:
        return None
    close = _num(_get("Latest_Close"))
    return BTCandidate(
        ticker=ticker, exchange="NAS",
        pivot=pivot,
        contraction_low=contraction_low,
        atr=max(_num(_get("Latest_ATR")), 0.0),
        last_close=close,
        close_known=close > 0,
        rs_rating=int(rs),
        vcp_score=float(_num(rep.get("Score"))),
        trade_signal=bool(rep.get("Trade_Signal_Active", False)),
        session_date=str(pd.Timestamp(T).date()),
        name=str(rep.get("Grade", "")),
    )


def _num(v) -> float:
    try:
        f = float(v)
    except (TypeError, ValueError):
        return 0.0
    return 0.0 if (np.isnan(f) or np.isinf(f)) else f


def shift_signal_dates(signals: Dict, calendar, lag: int = 0) -> Dict:
    """Deliver signals computed from data through T on session T+lag instead.

    WHY THIS EXISTS. Production runs the screener BEFORE the US open: it screens
    on session D-1's close, arms for D, and watches the pivot intraday during D.
    The harness already matches that -- generate_signals screens on T's close and
    the harness arms and fills during T+1, so backtest T == production D-1, with
    no look-ahead. lag=0 is therefore the faithful default.

    BUT the 2026-08-05 gate run empirically used data through 2026-08-03, one
    session staler than the design. The likely cause is that yfinance had not yet
    published the settled daily bar for the prior session when the box fetched --
    a publication delay, not a design lag. If that happens routinely, production
    is deciding on staler data than the backtest, and every backtest result is
    optimistic by one session of information.

    lag=1 models that. Run both and compare: if the results differ materially,
    the publication delay is a real risk that needs pinning down on the box
    before any parameter conclusion is trusted.
    """
    if not lag:
        return signals
    cal = pd.DatetimeIndex(sorted(calendar))
    out: Dict = {}
    dropped = 0
    for T, cands in signals.items():
        pos = cal.searchsorted(pd.Timestamp(T))
        j = pos + lag
        if j < len(cal):
            out[cal[j]] = cands
        else:
            dropped += 1                      # falls off the end of the window
    if dropped:
        print(f"[signals] lag={lag}: {dropped} signal date(s) fell past the end "
              f"of the calendar and were dropped")
    return out


def generate_signals_by_population(bars: Dict[str, pd.DataFrame],
                                   dates,
                                   populations: Dict[str, List[str]],
                                   checkpoint_dir: Optional[str] = None,
                                   resume: bool = True,
                                   **kw) -> Dict[pd.Timestamp, List[BTCandidate]]:
    """Run generate_signals ONCE PER POPULATION and union the results.

    This is not cosmetic. Production runs sp500_v21.py over the S&P 500 and
    us_small_v21.py over the S&P 400+600 as two SEPARATE screener runs, so
    `compute_rs_ratings` computes its percentile within each universe
    independently; candidate_emit then unions both into one candidates.csv.

    Pooling them into a single scan changes every RS rating, which changes which
    names clear the RS>=70 gate. A mid-cap ranked against mega-caps loses
    percentile it would have kept among its own universe. The VCP SCORE itself is
    unaffected -- VCPAnalyzerV4 never sees the rating, only price vs ^GSPC -- so
    the symptom is names silently missing, not names mis-scored.

    Duplicate tickers across populations keep the higher VCP score, matching
    candidate_emit's defensive dedupe.
    """
    import hashlib
    import pickle

    merged: Dict[pd.Timestamp, List[BTCandidate]] = {}
    dates_list = [pd.Timestamp(d) for d in dates]
    for name, tickers in populations.items():
        kw.setdefault("log", print)
        log = kw["log"]
        # signature so a stale checkpoint from a DIFFERENT run is never reused
        sig = hashlib.sha1(
            ("|".join(sorted(tickers)) + "#" +
             "|".join(str(d.date()) for d in dates_list)).encode()).hexdigest()[:12]
        cp = _pl.Path(checkpoint_dir) / f"signals_{name}.pkl" if checkpoint_dir else None

        sub = None
        if resume and cp is not None and cp.exists():
            try:
                with open(cp, "rb") as f:
                    blob = pickle.load(f)
                if blob.get("sig") == sig:
                    sub = blob["signals"]
                    log(f"[signals] RESUMED '{name}' from {cp} "
                        f"({len(sub)} date(s)) -- delete it to force a rescan")
                else:
                    log(f"[signals] checkpoint for '{name}' is from a different "
                        f"run (universe or dates changed) -- rescanning")
            except Exception as e:
                log(f"[signals] unreadable checkpoint for '{name}' ({e}) -- rescanning")

        if sub is None:
            log(f"[signals] === population '{name}': {len(tickers)} ticker(s) ===")
            sub = generate_signals(bars, dates, constant_universe(list(tickers)), **kw)
            if cp is not None:
                cp.parent.mkdir(parents=True, exist_ok=True)
                with open(cp, "wb") as f:
                    pickle.dump({"sig": sig, "signals": sub}, f)
                log(f"[signals] checkpointed '{name}' -> {cp}")

        for d, cands in sub.items():
            merged.setdefault(d, []).extend(cands)

    out: Dict[pd.Timestamp, List[BTCandidate]] = {}
    for d, cands in merged.items():
        best: Dict[str, BTCandidate] = {}
        for c in cands:
            if c.ticker not in best or c.vcp_score > best[c.ticker].vcp_score:
                best[c.ticker] = c
        out[d] = list(best.values())
    return out


def populations_from_universe(path: str = "data/universe.csv") -> Dict[str, List[str]]:
    """Group data/universe.csv into the two populations production actually scans:
    sp500 alone, and sp400+sp600 together (what us_small_v21.py covers)."""
    df = pd.read_csv(path)
    groups: Dict[str, List[str]] = {"sp500": [], "us_small": []}
    for t, ix in zip(df["ticker"].astype(str), df["index"].astype(str)):
        groups["sp500" if ix == "sp500" else "us_small"].append(t)
    return {k: v for k, v in groups.items() if v}


def constant_universe(tickers: List[str]) -> Callable:
    """Survivorship-BIASED universe: today's constituents at every date. Use only
    until a point-in-time membership source exists; results are a ceiling."""
    fixed = list(tickers)
    return lambda T: fixed


def pit_universe(constituents_by_date: Dict) -> Callable:
    """Point-in-time universe from {date: [tickers]}. Uses the most recent
    snapshot at or before T."""
    snaps = sorted(pd.Timestamp(d) for d in constituents_by_date)
    lookup = {pd.Timestamp(d): list(v) for d, v in constituents_by_date.items()}

    def _at(T):
        T = pd.Timestamp(T)
        prior = [s for s in snaps if s <= T]
        return lookup[prior[-1]] if prior else []
    return _at
