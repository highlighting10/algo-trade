#!/usr/bin/env python3
"""
sector_cap_probe -- is the per-sector cap live in the forward test?

WHY THIS EXISTS

DecisionConfig.sector_cap defaults to 2, and every backtest sweep enforces it
against a real data/sectors.csv. Whether PRODUCTION enforces it is a different
question, because the cap is guarded by

    if cfg.sector_cap and plan.sector:

and plan.sector comes from `account.sector_of(...) if account.sector_of else ""`.
So the cap is only reachable when something passes sector_of into build_pipeline.

This does not read the code and reason about it. It CONSTRUCTS the account state
exactly as cli.py's cmd_run does (sector_of=None), runs the real DecisionEngine,
and looks at what came out.

It reports two cases and they must DISAGREE. If they ever agree, this probe has
stopped measuring anything and should not be trusted:

    [A] sector_of=None      -- what cmd_run builds  -> cap must NOT bind
    [B] sector_of supplied  -- a map is present     -> cap MUST bind

Exit code
    0  the two cases differ, i.e. the probe is still discriminating
    1  they agree -> the probe is broken, or the wiring changed. Read it.
    2  could not import the production package

Usage (from anywhere):

    python sector_cap_probe.py --prod-root C:\\Users\\user\\kis-trader-clean
"""
from __future__ import annotations

import argparse
import os
import sys

NAMES = ["AAA", "BBB", "CCC", "DDD"]
EQUITY = 211710.0


def _ascii(s):
    """cp949 consoles cannot print the em-dash production uses in its rejection
    text. Never let an encoding error stand in for a diagnosis."""
    return str(s).encode("ascii", "replace").decode("ascii")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--prod-root", default=".",
                    help="repo root holding the kistrader package")
    a = ap.parse_args()

    root = os.path.abspath(a.prod_root)
    if not os.path.isdir(os.path.join(root, "kistrader")):
        print("FATAL: no kistrader package under %r" % root)
        return 2
    sys.path.insert(0, root)

    try:
        import kistrader
        from kistrader.entry import decision_engine as DE
        from kistrader.entry.decision_engine import (
            DecisionEngine, DecisionConfig, AccountState)
        from kistrader.entry.screen_contract import Candidate
    except Exception as e:                       # noqa: BLE001
        print("FATAL: cannot import production modules: %s" % e)
        return 2

    # WHICH decision_engine did we just measure? kis-backtest ships a VENDORED
    # kistrader package, and 06_sweep.py deliberately imports that one. A number
    # from this probe means nothing without saying which engine produced it --
    # carry the configuration with every number.
    print("  kistrader package : %s" % kistrader.__file__)
    print("  decision_engine   : %s" % DE.__file__)
    vendored = os.path.normcase(os.path.abspath(root)) not in \
        os.path.normcase(os.path.abspath(DE.__file__))
    if vendored:
        print("  *** NOT the tree passed as --prod-root. This is a DIFFERENT")
        print("  *** decision_engine (vendored?). Fix sys.path before reading on.")
        return 1
    print("  -> production copy under --prod-root, as intended")

    def cand(t):
        # Geometry chosen so the candidate survives EVERY other gate: a known
        # close, a usable ATR, a contraction_low below the pivot. If any of
        # these is dropped the engine rejects before the cap is ever consulted
        # and the probe silently measures nothing -- see the assertion below.
        return Candidate(ticker=t, exchange="NAS", rs_rating=90,
                         stage2_score=80.0, vcp_score=90.0, pivot=100.0,
                         base_high=100.0, base_low=90.0, contraction_low=95.0,
                         depth_pct=0.10, last_close=99.0, atr=1.0,
                         trade_signal=True, session_date="2026-08-21",
                         name=t, close_known=True)

    cs = [cand(n) for n in NAMES]
    sect = dict.fromkeys(NAMES, "Technology")
    cfg = DecisionConfig()
    eng = DecisionEngine(cfg)

    print("=" * 70)
    print("  DecisionConfig().sector_cap = %r" % cfg.sector_cap)
    print("  %d candidates, ALL in one sector" % len(NAMES))
    print("=" * 70)

    # ---- [A] the live wiring -------------------------------------------- #
    pa, ra = eng.plan(cs, AccountState(equity=EQUITY, cash=EQUITY,
                                       sector_of=None))
    cap_a = [r.reason for r in ra if "sector" in r.reason]
    print("\n[A] sector_of=None   <- EXACTLY what cli.py cmd_run builds")
    print("    planned              : %s" % [p.ticker for p in pa])
    print("    plan.sector values   : %s" % [p.sector for p in pa])
    print("    sector-cap rejections: %s" % (cap_a or "NONE"))

    # ---- [B] with a map -------------------------------------------------- #
    pb, rb = eng.plan(cs, AccountState(equity=EQUITY, cash=EQUITY,
                                       sector_of=lambda t: sect.get(t, "")))
    cap_b = [r.reason for r in rb if "sector" in r.reason]
    print("\n[B] sector_of supplied, all four Technology")
    print("    planned              : %s" % [p.ticker for p in pb])
    print("    sector-cap rejections: %s" % (cap_b or "NONE"))

    # ---- is cli.py able to pass it at all? -------------------------------- #
    cli = os.path.join(root, "kistrader", "cli.py")
    with open(cli, encoding="utf-8") as fh:
        src = fh.read()
    mentions = "sector" in src
    print("\n[C] the string 'sector' occurs anywhere in cli.py: %s" % mentions)

    # ---- the probe must be able to fail ----------------------------------- #
    print("\n" + "=" * 70)
    if not pa and not pb:
        print("  BROKEN: nothing planned in EITHER case. The fixture is being")
        print("  rejected upstream of the cap, so this run measured nothing.")
        # Rejection strings come from production and contain non-ASCII (an
        # em-dash, Korean). A cp949 console raises UnicodeEncodeError on those,
        # which would replace a diagnosis with a traceback.
        for r in ra[:3]:
            print("  reject: %s" % _ascii(r.reason))
        return 1
    if len(pa) == len(pb):
        print("  BROKEN or CHANGED: [A] and [B] agree (%d planned each)."
              % len(pa))
        print("  Either the wiring changed or the probe stopped discriminating.")
        return 1

    print("  [A] %d planned, [B] %d planned -- the cap binds ONLY in [B]."
          % (len(pa), len(pb)))
    print("  => sector_cap is INERT in the live forward test.")
    print("  The backtest enforces it (06_sweep hard-loads data/sectors.csv);")
    print("  production does not. That asymmetry is a DECISION, not a bug fix.")
    print("=" * 70)
    return 0


if __name__ == "__main__":
    sys.exit(main())
