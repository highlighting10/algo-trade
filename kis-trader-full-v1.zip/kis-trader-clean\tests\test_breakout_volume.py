#!/usr/bin/env python3
"""
S2 — live breakout volume confirmation.  THE WIRING IS THE TEST.
=================================================================

`REVIEW_20260904_minervini_capital_patches` sec.2 found a defect that all 449
existing checks passed straight through:

    build_pipeline(... breakout_volume_provider=None, require_breakout_volume=True)

A gate switched on ahead of the data source that feeds it. In production nothing
would ever arm; the suite would never notice, because
`grep -c build_pipeline tests/test_pipeline_e2e.py` returns **0** — the e2e suite
constructs `EntryManager` directly, where the flag defaults False. 100 e2e checks
pass over wiring production does not use.

So half of this suite tests the WIRING rather than the logic, and that half is
what would have failed on the 2026-09-04 patch.

Run:  python tests/test_breakout_volume.py
      python -m pytest -q tests/test_breakout_volume.py
"""
from __future__ import annotations

import os
import sys
import tempfile

_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.dirname(_HERE)
for _p in (_ROOT, _HERE):
    if _p not in sys.path:
        sys.path.insert(0, _p)

from kistrader.core.engine_v2 import EventStore                       # noqa: E402
from kistrader.entry.decision_engine import (AccountState,            # noqa: E402
                                             DecisionConfig,
                                             DecisionEngine, EntryPlan)
from kistrader.entry.entry_manager import EntryManager                # noqa: E402
from kistrader.entry.pipeline import build_pipeline                   # noqa: E402
from kistrader.entry.screen_contract import Candidate                 # noqa: E402

FAIL: list = []
_N = [0]


def check(name, cond, detail=""):
    _N[0] += 1
    print(f"  [{'PASS' if cond else 'FAIL'}] {name}   {detail}")
    if not cond:
        FAIL.append(name)


class _StubBroker:
    """EntryManager touches the broker only when it ARMS. This suite exercises
    the verdict and the wiring, so a stub is honest — the full
    arm -> trigger -> fill path is covered by test_entry_half I15."""
    is_mock = True


def _mgr(tmp, tag, **kw):
    return EntryManager(_StubBroker(), EventStore(os.path.join(tmp, tag + ".db")),
                        alert=lambda m: None, **kw)


def _plan(avg_vol_50=1_000_000.0):
    return EntryPlan(ticker="TEST", exchange="NAS", limit_price=100.5, shares=10,
                     stop_price=95.0, est_risk_per_share=5.5, est_notional=1005.0,
                     rank_score=88.0, atr_mult=2.0, order_key="TEST:2026-09-08",
                     pivot=100.0, avg_vol_50=avg_vol_50)


def main() -> int:
    tmp = tempfile.mkdtemp()
    print("=" * 64)
    print("S2 — LIVE BREAKOUT VOLUME CONFIRMATION")
    print("=" * 64)

    print("A  defaults — the gate stays OFF until something can answer it")
    m = _mgr(tmp, "a")
    check("require_breakout_volume defaults False", m.require_breakout_volume is False)
    check("no provider by default", m.breakout_volume_provider is None)
    check("multiple defaults to 1.5", m.breakout_volume_multiple == 1.5)

    print("B  the denominator travels WITH the plan, exactly as pivot does")
    check("EntryPlan carries avg_vol_50", _plan(2e6).avg_vol_50 == 2e6)
    c = Candidate(ticker="TEST", exchange="NAS", rs_proxy=90, stage2_score=70.0,
                  vcp_score=88.0, pivot=100.0, base_high=110.0, base_low=90.0,
                  depth_pct=0.18, last_close=99.0, atr=2.0,
                  session_date="2026-09-08", contraction_low=96.0,
                  avg_vol_50=1_234_567.0)
    acct = AccountState(equity=100_000.0, cash=100_000.0)
    p, rej = DecisionEngine(DecisionConfig())._plan_one(c, acct)
    check("plan carries the candidate's avg_vol_50 into the EntryPlan",
          p is not None and p.avg_vol_50 == 1_234_567.0,
          ("rejected: %s" % rej.reason) if p is None else str(p.avg_vol_50))

    print("C  the verdict — every branch fails CLOSED")
    m = _mgr(tmp, "c1", require_breakout_volume=True)
    ok, why = m.breakout_volume_verdict(_plan())
    check("no provider -> NOT confirmed", not ok)
    check("...reason names the provider", "provider" in why.lower(), why[:56])

    m = _mgr(tmp, "c2", require_breakout_volume=True,
             breakout_volume_provider=lambda t, e: 5_000_000.0)
    ok, why = m.breakout_volume_verdict(_plan(0.0))
    check("avg_vol_50 UNKNOWN (0.0) -> NOT confirmed", not ok)
    check("...reason names avg_vol_50", "avg_vol_50" in why, why[:56])

    m = _mgr(tmp, "c3", require_breakout_volume=True,
             breakout_volume_provider=lambda t, e: None)
    ok, why = m.breakout_volume_verdict(_plan())
    check("provider returns UNKNOWN -> NOT confirmed", not ok)
    check("...UNKNOWN is distinguishable from 'too thin'",
          "unknown" in why.lower(), why[:56])

    def _boom(t, e):
        raise RuntimeError("feed died")
    m = _mgr(tmp, "c4", require_breakout_volume=True, breakout_volume_provider=_boom)
    ok, why = m.breakout_volume_verdict(_plan())
    check("a raising provider is caught, never propagated", not ok)

    m = _mgr(tmp, "c5", require_breakout_volume=True,
             breakout_volume_provider=lambda t, e: 1_500_000.0)
    ok, why = m.breakout_volume_verdict(_plan(1_000_000.0))
    check("volume exactly 1.5x average -> CONFIRMED", ok, why[:56])

    m = _mgr(tmp, "c6", require_breakout_volume=True,
             breakout_volume_provider=lambda t, e: 1_499_999.0)
    ok, why = m.breakout_volume_verdict(_plan(1_000_000.0))
    check("a hair under 1.5x -> NOT confirmed", not ok)
    check("...reason carries both numbers",
          "1499999" in why.replace(",", "") and "1000000" in why.replace(",", ""),
          why[:56])

    m = _mgr(tmp, "c7", require_breakout_volume=True, breakout_volume_multiple=1.0,
             breakout_volume_provider=lambda t, e: 1_000_000.0)
    ok, _w = m.breakout_volume_verdict(_plan(1_000_000.0))
    check("the multiple is configurable", ok)

    print("D  THE WIRING — the half the 2026-09-04 patch would have failed")
    kw = dict(app_key="k", app_secret="s", cano="12345678", is_mock=True,
              candidates_path=os.path.join(tmp, "c.csv"))

    _l, ctx = build_pipeline(db_path=os.path.join(tmp, "p1.db"), **kw)
    check("default: gate OFF at the manager",
          ctx["entry"].require_breakout_volume is False)
    check("default: no provider", ctx["entry"].breakout_volume_provider is None)

    _l, ctx = build_pipeline(db_path=os.path.join(tmp, "p2.db"),
                             breakout_volume=True, **kw)
    check("breakout_volume=True wires a provider off the broker",
          callable(ctx["entry"].breakout_volume_provider))
    check("...but does NOT enforce yet (diagnostic first)",
          ctx["entry"].require_breakout_volume is False)

    _l, ctx = build_pipeline(db_path=os.path.join(tmp, "p3.db"),
                             breakout_volume=True,
                             require_breakout_volume=True, **kw)
    check("enforcement is opt-in and reaches the manager",
          ctx["entry"].require_breakout_volume is True)
    check("...and a provider is present WHENEVER it is enforced",
          ctx["entry"].breakout_volume_provider is not None)

    try:
        build_pipeline(db_path=os.path.join(tmp, "p4.db"),
                       require_breakout_volume=True, **kw)
        check("require without a provider is REFUSED at build time", False,
              "it built -- this is the 2026-09-04 defect")
    except ValueError as e:
        check("require without a provider is REFUSED at build time", True,
              str(e)[:52])

    # --- PATCH AK (trigger extension) ---
    print("E  PATCH AK — extension at the TRIGGER, not at plan time")
    m = _mgr(tmp, "e1")
    check("max_trigger_extension_pct defaults None (log only)",
          m.max_trigger_extension_pct is None)
    ok, why = m.trigger_extension_verdict(_plan(), 104.0)
    check("unenforced verdict is ok and still carries the number",
          ok is True and "+4.00%" in why, why)
    m = _mgr(tmp, "e2", max_trigger_extension_pct=0.05)
    ok, why = m.trigger_extension_verdict(_plan(), 104.0)
    check("4% below a 5% bar passes", ok is True, why)
    ok, why = m.trigger_extension_verdict(_plan(), 112.0)
    check("12% above a 5% bar is HELD", ok is False, why)
    ok, why = m.trigger_extension_verdict(_plan(), 105.0)
    check("exactly at the bar passes (> not >=, same as the plan-time check)",
          ok is True, why)
    _l, ctx = build_pipeline(db_path=os.path.join(tmp, "p5.db"),
                             max_trigger_extension_pct=0.05, **kw)
    check("the value reaches the manager through build_pipeline",
          ctx["entry"].max_trigger_extension_pct == 0.05)

    print("=" * 64)
    print(f"PASSED {_N[0] - len(FAIL)} / {_N[0]}")
    print("=" * 64)
    return 1 if FAIL else 0


def test_zz_all_checks_passed():
    """Terminal guard. check() never raises, so without this pytest would report
    this file as passed no matter how many checks failed."""
    main()
    assert not FAIL, f"{len(FAIL)} failed check(s): " + "; ".join(FAIL)


if __name__ == "__main__":
    raise SystemExit(main())
