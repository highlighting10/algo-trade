#!/usr/bin/env python3
"""
Decision engine — ranking, selection, sizing, stop derivation  (§3.1-3.4)
=========================================================================

Pure and deterministic: Candidates + a snapshot of the account -> EntryPlans.
NO broker, NO clock, NO I/O. Everything here is unit-testable in isolation; the
stateful, broker-touching arming lives in entry_manager.py (§3.5-3.7).

Pipeline:
  1. rank    (§3.1)  score = 2*RS% + Stage2%
  2. select  (§3.2)  drop dupes/held; take Top-N under sector + exposure caps
  3. stop    (§3.4)  final-contraction low, floored by adaptive ATR; risk cap
  4. size    (§3.3)  equal-R: shares = floor(risk_$ / risk_per_share)

Stop regime (v3, Minervini): the stop anchors on the FINAL CONTRACTION's low
(Candidate.contraction_low = Wave_Lows[-1]), the same structure the pivot comes
from. The previous whole-base anchor (base_low) mixed two structures in one
trade and rejected real VCPs as "too wide" (probe 2026-07-18: 3/21 -> 10/21
armable); it is DELETED, not config-gated — git is the rollback. base_low /
base_high / depth_pct remain in the schema as whole-base geometry (validation +
audit) and are NOT read here for the stop.

Every policy number is a field on DecisionConfig with an inline rationale, so
the trading policy is one object you tune — not magic constants buried in code.
The DEFAULTS ARE STARTING POINTS; treat risk_per_trade_pct, the ATR band, and
the exposure/sector caps as decisions to confirm, not settled truth.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Callable, Optional

from kistrader.entry.screen_contract import Candidate, make_order_key


# ---------------------------------------------------------------------------
# Config — the whole trading policy in one place (mirrors VCPConfig's style).
# ---------------------------------------------------------------------------

@dataclass
class DecisionConfig:
    # -- §3.1 rank -----------------------------------------------------------
    # RANKING = vcp_only. rank_mode never took effect before the Phase 1 fix:
    # plan() re-sorts on rank_score, so a mode the score could not express was
    # silently ignored and every historical sweep ranked on 2*RS.
    # vcp_only won all four cost levels by 5.79-8.62 return-%.
    rs_weight: float = 0.0            # score = rs_weight*RS% + stage2_weight*Stage2%
    stage2_weight: float = 0.0        #         + vcp_weight*VCP%
    vcp_weight: float = 1.0           # the ONLY active ranking term (vcp_only).
                                      # Set with rs_weight=stage2_weight=0.0 for
                                      # the frozen vcp_only ranking (Phase 2).

    # -- §3.2 selection ------------------------------------------------------
    n_max: int = 8                    # max concurrent NEW arms this pass
    max_open_positions: int = 8       # hard cap on total live positions (new + existing)
    sector_cap: int = 0               # PATCH F 2026-08-25 -- OFF BY DECLARATION.
    # Was 2, but inert: cli.py never passes sector_of, so plan.sector is "" and
    # the guard below never fired. Off by accident is one wired field away from
    # on at a value nobody chose. Rev 3 has no sector cap and SEPA has no
    # diversification element. 0/None => no cap.
    max_portfolio_exposure_pct: float = 1.00   # sum of entry notional / equity ceiling
    require_trade_signal: bool = False # if True, only arm names the screener marks as a
                                       # VOLUME-CONFIRMED breakout (close > pivot on
                                       # >= breakout_vol_mult * Avg_Vol_50)

    # -- §3.3 sizing ---------------------------------------------------------
    risk_per_trade_pct: float = 0.0085  # equal-R: risk 0.85% of equity per trade
                                        # (below Minervini's 1.25-2.5% band; raising
                                        #  it to index parity scales max drawdown to
                                        #  -51%..-64%. BACKTEST decision.)
    min_shares: int = 1                 # below this, skip (position too small to bother)
    max_position_pct: float = 0.25      # single-name notional cap as frac of equity
                                        # (25 vs 30 differ by 0.033 R -- inside the
                                        #  +/-0.19 R noise floor; the cap stops
                                        #  binding above ~35%)

    # -- §3.4 stop derivation ------------------------------------------------
    stop_buffer_pct: float = 0.005      # place the stop this far BELOW contraction_low
    # adaptive ATR multiple: the ATR term is a *floor on risk* (stops us being
    # noise-stopped by a too-tight structural stop). The lerp maps CONTRACTION
    # depth -> mult, clamped to the band.
    # ⚠ BACKTEST QUESTION #2: this band (0.08..0.25) was calibrated for
    # WHOLE-BASE depths (10-54%). Final-contraction depths run ~5-12%, so the
    # lerp pins at atr_mult_min for nearly every real candidate — the floor
    # degrades from adaptive to a constant noise-guard (still BINDS on ultra-
    # tight contractions of volatile names, which is its stated job; verified
    # 2026-07-18). Recalibrating the band is a DATA decision — do not pick new
    # numbers in a code session.
    atr_mult_min: float = 1.3
    atr_mult_max: float = 2.5
    depth_shallow: float = 0.08         # depth mapped to atr_mult_min
    depth_deep: float = 0.25            # depth mapped to atr_mult_max
    max_stop_pct: float = 0.10          # reject if implied risk > 10% of entry
                                        # (final contraction too wide to size sanely;
                                        #  10% is Minervini's doctrinal ceiling)

    # -- entry price ---------------------------------------------------------
    # limit = pivot*(1+entry_chase_pct), anchored on the pivot, not last_close.
    # ⚠ HONEST NOTE (§4, handoff 2026-07-18): this limit is currently PLACED AT
    # ARM TIME as a plain KIS limit order. A buy limit above the market is
    # marketable and FILLS IMMEDIATELY at the ask — it does NOT rest waiting for
    # a breakout. KIS's overseas open API has no stop/conditional order type, so
    # the breakout TRIGGER must be a software pivot-watch in entry_manager
    # (pending). Until that lands, arming a below-pivot name buys it at market.
    entry_chase_pct: float = 0.005      # 0.5% max chase above pivot
    max_extension_pct: float = 0.05     # reject if last_close > pivot*(1+this)

    # -- §1.6 coupling safety --------------------------------------------------
    # These make a MISSING screener input fail loudly, never silently. Missing
    # last_close means the extension guard cannot run: fail closed (reject) by
    # default. Missing ATR means a contraction-only stop: allowed by default but
    # LABELLED (stop_basis); flip require_atr to reject instead. Missing
    # contraction_low means NO stop anchor exists: ALWAYS fail closed (there is
    # no degrade target that isn't the deleted base anchor).
    allow_missing_close: bool = False   # True => arm even without a verifiable close (dry-run only)
    require_atr: bool = False           # True => reject when ATR is unavailable/zero


# ---------------------------------------------------------------------------
# Inputs / outputs
# ---------------------------------------------------------------------------

@dataclass
class AccountState:
    """Snapshot the decision engine reads. The manager fills this from the
    broker (equity/cash/holdings) and the live position list before each pass."""
    equity: float                       # total account equity ($) for R sizing
    cash: float                         # available cash ($); advisory — the enforced
                                        # cash gate is EntryManager's buying-power check
    held_tickers: frozenset = frozenset()   # currently held (broker holdings)
    pending_tickers: frozenset = frozenset() # already armed / PENDING_ENTRY / open order
    open_position_count: int = 0        # live positions already under management
    open_notional: float = 0.0          # $ already deployed (for exposure ceiling)
    sector_counts: dict = field(default_factory=dict)  # sector -> current count
    sector_of: Optional[Callable[[str], str]] = None   # ticker -> sector (optional)

    def existing(self) -> frozenset:
        return self.held_tickers | self.pending_tickers


@dataclass
class EntryPlan:
    """A sized, ready-to-arm order. The manager turns this into a PENDING_ENTRY
    Position and a BUY limit. stop_price is FIXED here; the actual entry (and thus
    initial_risk_per_share) is frozen from the real fill at arming time."""
    ticker: str
    exchange: str
    limit_price: float                  # BUY limit
    shares: int
    stop_price: float                   # synthetic stop the exit engine will enforce
    est_risk_per_share: float           # limit - stop (frozen for real at fill)
    est_notional: float                 # shares * limit
    rank_score: float
    atr_mult: float
    order_key: str
    sector: str = ""
    stop_basis: str = "contraction+atr"  # or "contraction-only" when ATR is unavailable
    pivot: float = 0.0                   # breakout trigger level (candidate's pivot);
                                         # the entry manager WATCHES this and only
                                         # places the BUY limit once last >= pivot
    # --- PATCH AF (S2 breakout volume) --- the DENOMINATOR travels with the
    # plan for the same reason `pivot` does: the entry manager needs it at
    # WATCH time, and a ticker-keyed lookup would go stale across sessions.
    # 0.0 => UNKNOWN, and an unknown denominator HOLDS the breakout.
    avg_vol_50: float = 0.0
    # --- end PATCH AF (S2 breakout volume) ---

    def est_risk_dollars(self) -> float:
        return self.shares * self.est_risk_per_share


@dataclass
class Rejection:
    ticker: str
    reason: str


def _lerp_clamped(x, x0, y0, x1, y1) -> float:
    """Linear map x in [x0,x1] -> [y0,y1], clamped at both ends."""
    if x1 == x0:
        return y0
    t = (x - x0) / (x1 - x0)
    t = max(0.0, min(1.0, t))
    return y0 + t * (y1 - y0)


class DecisionEngine:
    def __init__(self, config: Optional[DecisionConfig] = None):
        self.cfg = config or DecisionConfig()

    # ---- §3.1 -------------------------------------------------------------
    def rank_score(self, c: Candidate) -> float:
        return (self.cfg.rs_weight * c.rs_proxy
                + self.cfg.stage2_weight * c.stage2_score
                + self.cfg.vcp_weight * c.vcp_score)

    # ---- §3.4 -------------------------------------------------------------
    def atr_multiple(self, depth_pct: float) -> float:
        """depth here is the FINAL CONTRACTION's depth (pivot -> contraction_low),
        not the whole base's — the floor scales with the structure being traded."""
        cfg = self.cfg
        return _lerp_clamped(depth_pct, cfg.depth_shallow, cfg.atr_mult_min,
                             cfg.depth_deep, cfg.atr_mult_max)

    def entry_limit(self, c: Candidate) -> float:
        """BUY limit = pivot * (1 + chase), anchored on the pivot. NOTE: placed
        as a plain limit this is marketable whenever the market is below it and
        fills immediately — the breakout TRIGGER is a pending software
        pivot-watch (see DecisionConfig entry-price note / handoff §4)."""
        return round(c.pivot * (1.0 + self.cfg.entry_chase_pct), 2)

    def contraction_depth(self, c: Candidate) -> float:
        """Depth of the FINAL contraction: (pivot - contraction_low) / pivot.
        Derived, not stored — single source of truth; pivot == Wave_Highs[-1]
        (verified 21/21), so this is the depth of the structure the stop and the
        entry both come from."""
        return (c.pivot - c.contraction_low) / c.pivot

    def derive_stop(self, c: Candidate, entry_ref: float):
        """Return (stop_price, atr_mult) or raise ValueError.
        stop = min(structural, ATR-floor): the final contraction's low sets the
        level (Minervini), the ATR floor guarantees the stop isn't tighter than
        volatility noise. Risk beyond max_stop_pct of entry means the FINAL
        CONTRACTION is too wide to size sanely -> reject upstream."""
        cfg = self.cfg
        if c.contraction_low <= 0:                 # backstop; _plan_one rejects first
            raise ValueError("contraction_low unavailable (no stop anchor)")
        structural = c.contraction_low * (1.0 - cfg.stop_buffer_pct)
        mult = self.atr_multiple(self.contraction_depth(c))
        if c.atr > 0:
            vol_floor = entry_ref - mult * c.atr
            stop = min(structural, vol_floor)     # lower stop => risk floored by ATR
        else:
            stop = structural                      # no ATR: contraction-only (degraded)
        stop = round(stop, 2)
        if stop <= 0 or stop >= entry_ref:
            raise ValueError(f"non-positive risk (stop {stop} vs entry {entry_ref})")
        risk_pct = (entry_ref - stop) / entry_ref
        if risk_pct > cfg.max_stop_pct:
            raise ValueError(f"risk {risk_pct:.1%} > max_stop_pct {cfg.max_stop_pct:.1%} "
                             f"(final contraction too wide)")
        return stop, mult

    # ---- §3.3 -------------------------------------------------------------
    def size(self, entry_ref: float, stop: float, equity: float) -> int:
        """Equal-R: risk a fixed fraction of equity per trade."""
        risk_per_share = entry_ref - stop
        if risk_per_share <= 0:
            return 0
        risk_dollars = equity * self.cfg.risk_per_trade_pct
        shares = int(math.floor(risk_dollars / risk_per_share))
        # single-name notional cap
        if self.cfg.max_position_pct > 0 and entry_ref > 0:
            cap_shares = int(math.floor((equity * self.cfg.max_position_pct) / entry_ref))
            shares = min(shares, cap_shares)
        return max(0, shares)

    # ---- per-candidate plan (no caps/dedup; that's select's job) ----------
    def _plan_one(self, c: Candidate, account: AccountState):
        cfg = self.cfg
        if not c.is_valid():
            return None, Rejection(c.ticker, "invalid candidate: " + "; ".join(c.problems()))
        if cfg.require_trade_signal and not c.trade_signal:
            return None, Rejection(c.ticker, "no breakout signal (require_trade_signal)")

        # extension guard: don't chase a name that already ran past the pivot.
        # This guard NEEDS a real last_close. A missing close can't be waved
        # through silently (that was the coupling hazard) — fail CLOSED unless the
        # operator has explicitly opted into a degraded dry run.
        if not c.close_known:
            if not cfg.allow_missing_close:
                return None, Rejection(c.ticker,
                    "last_close unavailable — extension guard cannot run; apply the "
                    "screener §1.6 patch (Latest_Close) or set allow_missing_close=True")
            # opted-in override: guard intentionally skipped (conscious degrade)
        else:
            ceiling = c.pivot * (1.0 + cfg.max_extension_pct)
            if c.last_close > ceiling:
                return None, Rejection(c.ticker,
                    f"too extended: close {c.last_close:.2f} > pivot+{cfg.max_extension_pct:.0%} "
                    f"({ceiling:.2f})")

        # stop anchor (v3): the strategy's stop hangs from the FINAL contraction's
        # low. No anchor -> no stop -> ALWAYS fail closed (a fabricated anchor
        # would silently reproduce the deleted base-anchor regime).
        if c.contraction_low <= 0:
            return None, Rejection(c.ticker,
                "contraction_low unavailable — cannot place the final-contraction "
                "(Minervini) stop; regenerate candidates with schema v3 "
                "(screener Wave_Lows[-1])")

        entry = self.entry_limit(c)

        # ATR floor: missing/zero ATR degrades to a contraction-only stop. That is
        # a valid (blunter) stop, so we ALLOW it by default but LABEL it via
        # stop_basis so the degrade is visible in the plan and the event log,
        # never silent. require_atr forces a reject instead.
        atr_ok = c.atr > 0
        if not atr_ok and cfg.require_atr:
            return None, Rejection(c.ticker,
                "ATR unavailable — contraction-only stop disabled by require_atr; apply "
                "the screener §1.6 patch (Latest_ATR)")
        try:
            stop, mult = self.derive_stop(c, entry)
        except ValueError as e:
            return None, Rejection(c.ticker, f"stop: {e}")
        stop_basis = "contraction+atr" if atr_ok else "contraction-only"

        shares = self.size(entry, stop, account.equity)
        if shares < cfg.min_shares:
            return None, Rejection(c.ticker, f"size {shares} < min_shares {cfg.min_shares}")
        sector = account.sector_of(c.ticker) if account.sector_of else ""
        plan = EntryPlan(
            ticker=c.ticker, exchange=c.exchange, limit_price=entry, shares=shares,
            stop_price=stop, est_risk_per_share=round(entry - stop, 4),
            est_notional=round(shares * entry, 2), rank_score=self.rank_score(c),
            atr_mult=round(mult, 3), order_key=make_order_key(c.ticker, c.session_date),
            sector=sector, stop_basis=stop_basis, pivot=float(c.pivot),
            # --- PATCH AF (S2 breakout volume) ---
            avg_vol_50=float(getattr(c, "avg_vol_50", 0.0) or 0.0))
            # --- end PATCH AF (S2 breakout volume) ---
        return plan, None

    # ---- §3.2 selection: dedup + Top-N + sector/exposure caps -------------
    def plan(self, candidates, account: AccountState):
        """candidates -> (plans, rejections). Deterministic ordering: rank desc,
        then ticker asc as a stable tiebreak. Caps applied greedily in that order.
        Returns EntryPlans that respect dedup, N_max, max_open_positions, the
        per-sector cap, and the portfolio-exposure ceiling."""
        cfg = self.cfg
        rejections: list = []

        # stable, deterministic priority
        ordered = sorted(candidates, key=lambda c: (-self.rank_score(c), c.ticker))

        existing = set(account.existing())
        # running tallies, seeded from what's already live
        n_open = account.open_position_count
        exposure = account.open_notional
        equity = max(account.equity, 1e-9)
        sector_counts = dict(account.sector_counts)
        exposure_ceiling = cfg.max_portfolio_exposure_pct * equity

        plans: list = []
        seen_this_pass = set()

        for c in ordered:
            # --- §3.6-style dedup (structural; the manager re-checks vs the broker) ---
            if c.ticker in existing or c.ticker in seen_this_pass:
                rejections.append(Rejection(c.ticker, "duplicate: already held/pending/selected"))
                continue

            plan, rej = self._plan_one(c, account)
            if rej:
                rejections.append(rej)
                continue

            # --- caps ---
            if len(plans) >= cfg.n_max:
                rejections.append(Rejection(c.ticker, f"n_max {cfg.n_max} reached"))
                continue
            if n_open + len(plans) >= cfg.max_open_positions:
                rejections.append(Rejection(c.ticker,
                    f"max_open_positions {cfg.max_open_positions} reached"))
                continue
            if cfg.sector_cap and plan.sector:
                if sector_counts.get(plan.sector, 0) >= cfg.sector_cap:
                    rejections.append(Rejection(c.ticker,
                        f"sector cap {cfg.sector_cap} reached for {plan.sector}"))
                    continue
            if exposure + plan.est_notional > exposure_ceiling:
                rejections.append(Rejection(c.ticker,
                    f"exposure ceiling: {exposure + plan.est_notional:.0f} > "
                    f"{exposure_ceiling:.0f}"))
                continue

            # accept
            plans.append(plan)
            seen_this_pass.add(c.ticker)
            exposure += plan.est_notional
            if plan.sector:
                sector_counts[plan.sector] = sector_counts.get(plan.sector, 0) + 1

        return plans, rejections
