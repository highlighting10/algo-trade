"""
04_signals.py -- generate signals once, cache to disk. THE EXPENSIVE STEP.

Every later script loads data/signals.pkl. Do not regenerate for each sweep.

emit_threshold is 0.0 on purpose: emit EVERYTHING scored and let
BacktestConfig.vcp_threshold filter later, so one pass feeds the whole sweep.
Filtering here would silently decide parked parameter #1.

Usage:
    python scripts/04_signals.py                 # weekly rescan, full history
    python scripts/04_signals.py --every 1       # every session (slow)
    python scripts/04_signals.py --start 2016-01-01
"""
import pathlib as _pl
import sys as _sys
_sys.path.insert(0, str(_pl.Path(__file__).resolve().parent.parent))
import argparse
import pathlib
import pickle
import time

import pandas as pd

from signals import (PITBars, generate_signals_by_population,
                     populations_from_universe, shift_signal_dates)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--every", type=int, default=5,
                    help="rescan every N sessions (default 5 = weekly)")
    ap.add_argument("--start", default="2015-01-01")
    ap.add_argument("--end", default=None)
    ap.add_argument("--out", default="data/signals.pkl")
    ap.add_argument("--lag", type=int, default=0,
                    help="extra sessions between the data cutoff and the fill "
                         "session. 0 = production design (screen on D-1 close, "
                         "arm for D). 1 = models a yfinance publication delay, "
                         "which the 2026-08-05 gate run appears to have hit.")
    ap.add_argument("--no-resume", action="store_true",
                    help="ignore checkpoints and rescan every population")
    args = ap.parse_args()

    # MEMORY. Loading full history (some names go back to the 1980s) for 1500
    # tickers is what pushed the previous run to 13 GB and got it killed. The
    # scan only ever looks back 2 years from the earliest scan date, so anything
    # before that is dead weight. 3 years of headroom is generous.
    warm = pd.Timestamp(args.start) - pd.DateOffset(years=3)
    bars, trimmed_rows, kept_rows = {}, 0, 0
    for p in pathlib.Path("data/bars").glob("*.parquet"):
        df = pd.read_parquet(p)
        if getattr(df.index, "tz", None) is not None:
            df.index = df.index.tz_localize(None)
        n0 = len(df)
        df = df.loc[df.index >= warm]
        if df.empty:
            continue
        trimmed_rows += n0 - len(df)
        kept_rows += len(df)
        bars[p.stem] = df
    print(f"[signals] trimmed history to >= {warm.date()}: kept {kept_rows:,} rows, "
          f"dropped {trimmed_rows:,} rows before the warm-up window")
    if "^GSPC" not in bars:
        raise SystemExit("[signals] FATAL: ^GSPC missing. Run 02_download.py.")
    print(f"[signals] {len(bars)} ticker(s) loaded")

    cal = PITBars(bars).calendar()
    lo = pd.Timestamp(args.start)
    hi = pd.Timestamp(args.end) if args.end else cal[-1]
    scan = cal[(cal >= lo) & (cal <= hi)][::args.every]
    print(f"[signals] scanning {len(scan)} session(s) from {scan[0].date()} "
          f"to {scan[-1].date()}, every {args.every} session(s)")
    print(f"[signals] this is the slow step -- expect roughly "
          f"{len(scan) * len(bars) / 60000:.0f}-{len(scan) * len(bars) / 20000:.0f} minutes")

    t0 = time.time()
    pops = populations_from_universe("data/universe.csv")
    have = set(bars)
    pops = {k: [t for t in v if t in have] for k, v in pops.items()}
    print("[signals] populations: " + ", ".join(f"{k}={len(v)}" for k, v in pops.items()))
    sigs = generate_signals_by_population(bars, scan, pops, emit_threshold=0.0,
                                          checkpoint_dir="data/checkpoints",
                                          resume=not args.no_resume)
    if args.lag:
        sigs = shift_signal_dates(sigs, cal, args.lag)
        print(f"[signals] delivery lag {args.lag} session(s) applied")
    dt = time.time() - t0

    pathlib.Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    with open(args.out, "wb") as f:
        pickle.dump({"signals": sigs, "scan_dates": list(scan),
                     "every": args.every, "lag": args.lag,
                     "generated": pd.Timestamp.now()}, f)

    total = sum(len(v) for v in sigs.values())
    print(f"\n[signals] {total} candidate(s) across {len(sigs)} date(s) "
          f"in {dt/60:.1f} min -> {args.out}")
    if total == 0:
        raise SystemExit(
            "[signals] ZERO candidates. That is a red flag, not a result. Check the "
            "drop counts above: 'incomplete_report' in bulk means the report schema "
            "moved; 'rs_below_threshold' in bulk means the scanned universe is too "
            "small for the percentile to clear 70.")

    scores = [c.vcp_score for v in sigs.values() for c in v]
    s = pd.Series(scores)
    print("[signals] VCP score distribution across all emissions:")
    for q in (0.50, 0.75, 0.90, 0.95, 0.99, 1.00):
        print(f"[signals]   p{int(q*100):>3} = {s.quantile(q):6.2f}")
    for thr in (55, 60, 65, 70, 75, 80, 85):
        n = int((s >= thr).sum())
        print(f"[signals]   >= {thr}: {n} emission(s)"
              + ("   <-- production threshold" if thr == 80 else ""))
    if (s >= 80).sum() == 0:
        print("[signals] NOTE: nothing clears 80 in this window. That is exactly the "
              "observation that motivated this backtest -- not an error.")


if __name__ == "__main__":
    main()
