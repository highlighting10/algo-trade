#!/usr/bin/env python3
"""
Screener -> decision-engine output contract  (checklist §1.6)
=============================================================

The screener suite currently emits only `Ticker|vcp score|outcome|pivot`
(RESULTS_HEADER). That is enough for a human-readable table but NOT enough to
arm a trade: the decision engine needs RS%, the catalyst (Stage-2) score, the
base geometry (pivot / contraction low), and an ATR to size the position and
derive a stop. This module is the *formal, stable* schema that closes that gap —
one `Candidate` per name, plus a CSV/JSON round-trip the decision engine consumes.

Field provenance (all already computed inside the screener today):
  ticker, name       -- Stage 1 universe row
  exchange           -- kis_tradable_universe.resolve(ticker)  (NAS/NYS/AMS)
  rs_proxy          -- compute_rs_proxy()  (IBD percentile, 1..99)
  stage2_score       -- catalyst score  (math floor 0-45 + Gemini 0-55 -> 0..100)
  vcp_score          -- VCPAnalyzerV4.generate_report()['Score']  (0..100)
  pivot              -- report['Extracted_Pattern']['Pivot']      (LOCKED;
                        == Wave_Highs[-1], the final contraction's high —
                        verified 21/21 on live reports 2026-07-18)
  base_high          -- report['Extracted_Pattern']['Base_High']
  base_low           -- report['Extracted_Pattern']['Base_Low']  (whole base's
                        absolute floor; falls back to min(Wave_Lows))
  contraction_low    -- report['Extracted_Pattern']['Wave_Lows'][-1]  (the FINAL
                        contraction's low — the Minervini stop anchor, v3)
  depth_pct          -- (base_high - base_low) / base_high         (0..1, WHOLE base)
  last_close         -- latest bar Close
  atr                -- latest ATR20 (absolute $)
  trade_signal       -- report['Trade_Signal_Active']  (close > pivot on
                        breakout-multiple volume — a volume-confirmed breakout)

v3 (2026-07-18): added `contraction_low`. The stop moved from the whole base's
floor to the FINAL CONTRACTION's low (Minervini doctrine): `pivot` was already
the final contraction's high, so entering off the final contraction while
stopping off the whole base mixed two structures in one trade — and rejected
real VCPs as "too wide" (probe 2026-07-18: 3/21 -> 10/21 armable). base_high /
base_low / depth_pct KEEP their whole-base meanings (validation + audit trail);
only the stop anchor moved. On Base_Low vs min(Wave_Lows): Base_Low can be
genuinely lower (observed 2/21 — AMAT, URI), but since v3 neither drives the
stop; the fallback remains for base-geometry purposes only.

On MISSING inputs the contract does NOT paper over gaps silently — that was the
coupling hazard (defaulting last_close to the pivot made the extension guard
pass by construction; atr==0 quietly dropped the ATR stop-floor). Instead:

  * a missing Latest_Close leaves last_close unset and marks close_known=False.
    The decision engine FAILS CLOSED unless allow_missing_close=True.
  * a missing Latest_ATR sets atr=0.0 -> a contraction-only stop, LABELLED via
    stop_basis. Set require_atr=True to reject instead.
  * a missing Wave_Lows leaves contraction_low=0.0 (UNKNOWN). It is NEVER
    copied from base_low — that would silently reproduce the deleted base-anchor
    behavior. The decision engine FAILS CLOSED (cannot place the strategy's stop).

The schema is intentionally flat and versioned (SCHEMA_VERSION) so a change is
detectable by the consumer instead of silently mis-parsed. FIELDS is append-only.
"""
from __future__ import annotations

import csv
import datetime as _dt
import json
import math
import os
from dataclasses import dataclass, asdict
from typing import Optional


# ---------------------------------------------------------------------------
# Strategy gate — the ONE declaration, shared by both screeners and the trader
# ---------------------------------------------------------------------------
# Stage-3 VCP bar. FINAL pick = Stage 1 AND Stage 2 AND VCP >= this value.
#
# It lives here rather than in either screener because it used to be declared
# twice, once per screener, each with a comment claiming the other mirrored it.
# Two literals are not a single source of truth. Both screeners write the SAME
# candidates.csv, so a divergence would screen half the universe at a bar nobody
# chose, silently. This module is the existing contract boundary between the
# screener suite and the entry half and carries no heavy imports, so both sides
# can read it freely.
#
# 75, from the paired band analysis: names scoring 70-75 are +0.32 R each
# in H1 and -0.35 R each in H2. 75 was the only positive threshold that was
# cost-monotone in BOTH halves, with zero negative cells.
#
# CHANGING THIS NUMBER CHANGES THE STRATEGY. It decides which names reach
# candidates.csv at all. It is a BACKTEST decision — never pick a new value in a
# code session. --emit-threshold lowers ONLY the emit filter for supervised
# plumbing tests and leaves this bar untouched.
VCP_SCORE_THRESHOLD = 75


SCHEMA_VERSION = 4   # v4: avg_vol_50 (S2 breakout-volume denominator)
                     #     + catalyst_evidence (P1.7 evidence test)
                     # v3: contraction_low (Minervini stop anchor)
                     # v2: close_known provenance flag (§1.6 coupling fix)

# --- PATCH AD (schema v4) --- diagnostic first, flag second.
# The screeners emit no catalyst tokens yet, so enforcing on the day this lands
# would reject every candidate. While this is False the validator still runs on
# every row and every would-be rejection is reported through read_candidates'
# `on_note`; nothing is dropped. Read those notes for a few sessions, THEN flip.
REQUIRE_CATALYST_EVIDENCE = False
# --- end PATCH AD (schema v4) ---

# Column order for CSV. Stable: append-only if you ever extend it, and bump
# SCHEMA_VERSION so read_candidates can reject an unknown layout loudly.
FIELDS = [
    "schema_version", "session_date", "ticker", "name", "exchange",
    "rs_proxy", "stage2_score", "vcp_score",
    "pivot", "base_high", "base_low", "depth_pct",
    "last_close", "atr", "trade_signal", "close_known",
    "contraction_low",
    # --- PATCH AD (schema v4) --- appended, never inserted: FIELDS is
    # append-only by the contract stated above, and CSV readers key on names.
    "avg_vol_50", "catalyst_evidence",
    # --- end PATCH AD (schema v4) ---
]


# --- PATCH AD (schema v4) --- the evidence test lives in its own module and
# imports nothing from kistrader, so this cannot create a cycle.
from kistrader.entry.catalyst_evidence import validate_evidence   # noqa: E402
# --- end PATCH AD (schema v4) ---


def make_order_key(ticker: str, session_date: str) -> str:
    """Deterministic trade id carried from entry through exit. Matches the exit
    engine's convention ('MU:2026-06-29') so one position keeps ONE order_key
    across its whole lifecycle and the event store groups it under that key."""
    return f"{ticker.strip().upper()}:{session_date}"


def _finite(x, default=0.0) -> float:
    try:
        v = float(x)
    except (TypeError, ValueError):
        return default
    return v if math.isfinite(v) else default


@dataclass
class Candidate:
    """One screener-cleared name, fully specified for the decision engine.

    A Candidate is a *fact sheet*, not a decision: it says nothing about size,
    stop, or whether we will actually trade it. The decision engine turns a
    ranked, capped subset of Candidates into EntryPlans.
    """
    ticker: str
    exchange: str                 # NAS / NYS / AMS  (from the tradability gate)
    rs_proxy: int                # 1..99
    stage2_score: float           # 0..100  (catalyst)
    vcp_score: float              # 0..100
    pivot: float                  # LOCKED breakout trigger (final contraction's high)
    base_high: float              # whole base's high        (geometry/audit)
    base_low: float               # whole base's floor       (geometry/audit; NOT the stop)
    depth_pct: float              # 0..1  WHOLE-base depth   (geometry/audit)
    last_close: float
    atr: float = 0.0              # absolute ATR20 ($); 0.0 => contraction-only stop
    trade_signal: bool = False    # volume-confirmed breakout on the last bar
    session_date: str = ""        # YYYY-MM-DD
    name: str = ""
    close_known: bool = True      # False => last_close absent (extension guard can't run)
    contraction_low: float = 0.0  # FINAL contraction's low = Wave_Lows[-1];
                                  # 0.0 => UNKNOWN (engine fails closed: no stop anchor)
    # --- PATCH AD (schema v4) ---
    avg_vol_50: float = 0.0       # 50-day average volume (shares). 0.0 => UNKNOWN.
                                  # The DENOMINATOR for live breakout confirmation.
                                  # KIS cannot supply it: I3 showed inquire-price
                                  # carries tvol (today) and pvol (ONE prior day),
                                  # so the baseline is the screener's job.
    catalyst_evidence: str = ""    # ";"-separated tokens from catalyst_evidence.py,
                                  # optionally "| free note". "" => absent.
    # --- end PATCH AD (schema v4) ---
    schema_version: int = SCHEMA_VERSION

    def order_key(self) -> str:
        return make_order_key(self.ticker, self.session_date)

    # ---- validation: a Candidate that can't be safely sized is rejected here,
    #      not deep inside the sizer where the failure mode is a bad share count.
    def problems(self) -> list:
        p = []
        if not self.ticker:
            p.append("empty ticker")
        if self.exchange not in ("NAS", "NYS", "AMS"):
            p.append(f"bad exchange {self.exchange!r}")
        if not (1 <= self.rs_proxy <= 99):
            p.append(f"rs_proxy out of range: {self.rs_proxy}")
        if not (0 <= self.stage2_score <= 100):
            p.append(f"stage2_score out of range: {self.stage2_score}")
        if not (0 <= self.vcp_score <= 100):
            p.append(f"vcp_score out of range: {self.vcp_score}")
        if self.pivot <= 0:
            p.append("pivot <= 0")
        if self.base_low <= 0 or self.base_high <= 0:
            p.append("base_low/base_high <= 0")
        if self.base_low >= self.base_high:
            p.append("base_low >= base_high")
        if not (0.0 <= self.depth_pct < 1.0):
            p.append(f"depth_pct out of range: {self.depth_pct}")
        # --- PATCH AD (schema v4) --- 0.0 is UNKNOWN and allowed, like atr and
        # contraction_low. Negative is impossible and means a parse went wrong.
        if self.avg_vol_50 < 0:
            p.append(f"avg_vol_50 negative: {self.avg_vol_50}")
        # --- end PATCH AD (schema v4) ---
        # last_close is only required to be positive when it is actually KNOWN.
        # An unknown close is not "invalid data" — it's a missing input the
        # decision engine handles explicitly (fail-closed on the extension guard),
        # so we don't want it to look like a corrupt row here.
        if self.close_known and self.last_close <= 0:
            p.append("last_close <= 0")
        if self.atr < 0:
            p.append("atr < 0")
        # contraction_low: 0.0 is a legal UNKNOWN (engine fails closed). A
        # PRESENT value must sit below the pivot — a wave low at/above its own
        # wave's high (pivot == Wave_Highs[-1], verified 21/21) is corrupt.
        # NOTE deliberately NOT checked: contraction_low vs base_low. The two
        # are measured over slightly different windows in the screener, so the
        # final wave's low can legitimately undercut the whole base's floor by
        # cents (observed 3/21 on 2026-07-20: VLO, SWK, ADM) — and a final
        # contraction undercutting prior lows is the classic SHAKEOUT, a
        # feature of strong bases, not corruption. An earlier version of this
        # check dropped exactly those setups.
        if self.contraction_low < 0:
            p.append("contraction_low < 0")
        elif self.contraction_low > 0:
            if self.pivot > 0 and self.contraction_low >= self.pivot:
                p.append("contraction_low >= pivot (corrupt wave geometry)")
        return p

    def is_valid(self) -> bool:
        return not self.problems()

    def to_row(self) -> dict:
        d = asdict(self)
        d["trade_signal"] = int(bool(self.trade_signal))
        d["close_known"] = int(bool(self.close_known))
        return d


def candidate_from_report(ticker: str, exchange: str, rs_proxy: int,
                          stage2_score: float, report: dict, session_date: str,
                          name: str = "", last_close: Optional[float] = None,
                          atr: Optional[float] = None,
                          # --- PATCH AD (schema v4) --- both DEFAULT to absent,
                          # so a screener that has not been taught to fill them
                          # still produces a valid v4 row. That is the intended
                          # diagnostic state, not an oversight.
                          avg_vol_50: Optional[float] = None,
                          catalyst_evidence: str = "",
                          # --- end PATCH AD (schema v4) ---
                          ) -> Candidate:
    """Build a Candidate from a VCP generate_report() dict + the Stage-1/2 scores.

    `report` is exactly what VCPAnalyzerV4.generate_report() returns. The §1.6
    keys (Latest_Close / Latest_ATR / Base_Low) are used when present; the v3
    stop anchor comes from Wave_Lows[-1] (the final contraction's low). Absent
    inputs propagate as UNKNOWN (close_known=False / atr=0.0 /
    contraction_low=0.0) and the decision engine handles each explicitly —
    fail-closed for close and contraction_low, labelled degrade for atr.
    """
    ep = report.get("Extracted_Pattern", {}) or {}
    pivot = _finite(ep.get("Pivot", 0.0))
    base_high = _finite(ep.get("Base_High", 0.0))

    base_low = _finite(ep.get("Base_Low", 0.0))
    lows_raw = ep.get("Wave_Lows") or []
    if base_low <= 0:
        lows = [_finite(x) for x in lows_raw if _finite(x) > 0]
        base_low = min(lows) if lows else 0.0

    # v3 stop anchor: the FINAL contraction's low. Waves are chronological
    # (Pivot == Wave_Highs[-1], verified 21/21), so [-1] is the final one.
    # Absent/garbage -> 0.0 (UNKNOWN); never fabricated from base_low.
    contraction_low = _finite(lows_raw[-1]) if lows_raw else 0.0
    if contraction_low < 0:
        contraction_low = 0.0

    # last_close: prefer the caller's value, then the screener field. We do NOT
    # fall back to the pivot — a fabricated close would silently satisfy the
    # extension guard. If we have no real close, we say so (close_known=False)
    # and let the decision engine decide (fail-closed by default).
    if last_close is None:
        close_val = _finite(ep.get("Latest_Close", 0.0))
        close_known = close_val > 0
        last_close = close_val
    else:
        last_close = _finite(last_close)
        close_known = last_close > 0

    if atr is None:
        atr = _finite(ep.get("Latest_ATR", 0.0))   # absent -> 0.0 -> contraction-only

    # --- PATCH AD (schema v4) --- same shape as atr: caller wins, then the
    # screener field, then UNKNOWN. Never fabricated -- a fake denominator would
    # silently satisfy the breakout-volume gate, which is the whole failure this
    # column exists to prevent.
    if avg_vol_50 is None:
        avg_vol_50 = _finite(ep.get("Avg_Vol_50", 0.0))
    avg_vol_50 = max(0.0, _finite(avg_vol_50))
    # --- end PATCH AD (schema v4) ---

    depth = 0.0
    if base_high > 0 and 0 < base_low < base_high:
        depth = (base_high - base_low) / base_high

    return Candidate(
        ticker=ticker.strip().upper(),
        exchange=exchange,
        rs_proxy=int(rs_proxy),
        stage2_score=_finite(stage2_score),
        vcp_score=_finite(report.get("Score", 0.0)),
        pivot=pivot,
        base_high=base_high,
        base_low=base_low,
        depth_pct=depth,
        last_close=_finite(last_close),
        atr=_finite(atr),
        trade_signal=bool(report.get("Trade_Signal_Active", False)),
        session_date=session_date,
        name=name,
        close_known=close_known,
        contraction_low=contraction_low,
        # --- PATCH AD (schema v4) ---
        avg_vol_50=avg_vol_50,
        catalyst_evidence=str(catalyst_evidence or ""),
        # --- end PATCH AD (schema v4) ---
    )


# ---------------------------------------------------------------------------
# Serialization — a stable CSV/JSON the decision engine reads. Fail-CLOSED on a
# malformed row (skip + collect), so one bad line never poisons the batch.
# ---------------------------------------------------------------------------

def write_candidates(path: str, candidates) -> int:
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=FIELDS)
        w.writeheader()
        n = 0
        for c in candidates:
            w.writerow(c.to_row())
            n += 1
    return n


def read_candidates(path: str, on_bad=None, on_note=None) -> list:
    """Read candidates.csv -> [Candidate]. Malformed/out-of-range rows are
    skipped (reported via on_bad(row, reasons)) rather than raising, so a single
    corrupt line can't abort the whole arming run. schema_version is checked
    STRICTLY per row: a v2 file fails loudly with the true reason (stale layout),
    never limps in with contraction_low silently unknown."""
    out = []
    with open(path, newline="", encoding="utf-8") as f:
        r = csv.DictReader(f)
        if r.fieldnames and "schema_version" in r.fieldnames:
            pass  # layout looks current; per-row version is checked below too
        for row in r:
            try:
                ver = int(row.get("schema_version", SCHEMA_VERSION))
                if ver != SCHEMA_VERSION:
                    raise ValueError(f"schema_version {ver} != {SCHEMA_VERSION}")
                c = Candidate(
                    ticker=str(row["ticker"]).strip().upper(),
                    exchange=str(row["exchange"]).strip().upper(),
                    rs_proxy=int(float(row["rs_proxy"])),
                    stage2_score=float(row["stage2_score"]),
                    vcp_score=float(row["vcp_score"]),
                    pivot=float(row["pivot"]),
                    base_high=float(row["base_high"]),
                    base_low=float(row["base_low"]),
                    depth_pct=float(row["depth_pct"]),
                    last_close=float(row["last_close"]),
                    atr=float(row.get("atr", 0.0) or 0.0),
                    trade_signal=bool(int(float(row.get("trade_signal", 0) or 0))),
                    session_date=str(row.get("session_date", "")).strip(),
                    name=str(row.get("name", "")).strip(),
                    # absent provenance column -> assume UNKNOWN (safe: engine fails closed)
                    close_known=bool(int(float(row.get("close_known", 0) or 0))),
                    # v3 column is REQUIRED at v3 (KeyError -> on_bad); 0.0 = UNKNOWN
                    contraction_low=float(row["contraction_low"]),
                    # --- PATCH AD (schema v4) --- both columns are REQUIRED at
                    # v4 (KeyError -> on_bad), same as contraction_low at v3.
                    # An EMPTY VALUE is allowed; a MISSING COLUMN is a layout
                    # error and must fail loudly rather than default silently.
                    avg_vol_50=float(row["avg_vol_50"] or 0.0),
                    catalyst_evidence=str(row["catalyst_evidence"] or ""),
                    # --- end PATCH AD (schema v4) ---
                )
            except (KeyError, ValueError, TypeError) as e:
                if on_bad:
                    on_bad(row, [str(e)])
                continue
            probs = c.problems()
            if probs:
                if on_bad:
                    on_bad(row, probs)
                continue
            # --- PATCH AD (schema v4) --- the evidence test, run on every row.
            # While REQUIRE_CATALYST_EVIDENCE is False this REPORTS and does not
            # reject: `on_note` exists precisely so a diagnostic rollout is not
            # indistinguishable from a rejection in the log.
            ok_ev, why_ev, _cats = validate_evidence(c.catalyst_evidence)
            if not ok_ev:
                if REQUIRE_CATALYST_EVIDENCE:
                    if on_bad:
                        on_bad(row, why_ev)
                    continue
                if on_note:
                    on_note(row, why_ev)
            # --- end PATCH AD (schema v4) ---
            out.append(c)
    return out


# ---------------------------------------------------------------------------
# regime.json — the global-regime sidecar written beside candidates.csv
# ---------------------------------------------------------------------------
REGIME_SCHEMA_VERSION = 1
REGIME_FILENAME = "regime.json"

# How stale the benchmark BAR may be, in calendar days, relative to the session
# it is used for. The screener runs pre-open, so the newest completed daily bar
# is normally the prior session -- 1 day, or 3 over a weekend, more across a
# holiday. 5 covers a long weekend plus a holiday; beyond that the fetch is
# suspect. This matters because the screener's _fetch_history() silently falls
# back to a pickled cache when the provider returns empty, so a "successful"
# fetch can carry a bar from days ago.
REGIME_MAX_BAR_AGE_DAYS = 5


def regime_path_for(candidates_path: str) -> str:
    """The sidecar always sits beside candidates.csv, so one path setting
    configures both and they cannot drift apart."""
    return os.path.join(os.path.dirname(os.path.abspath(candidates_path)),
                        REGIME_FILENAME)


def _regime_state(close, ma) -> str:
    if close is None or ma is None or close != close or ma != ma:   # incl. NaN
        return "unavailable"
    return "risk_on" if float(close) >= float(ma) else "risk_off"


def write_regime(path: str, *, session_date: str, screener: str,
                 vcp_threshold, benchmark: str, regime_ma,
                 benchmark_close, benchmark_ma, bar_date,
                 emitted: int = 0, degraded_threshold=None, log=print) -> dict:
    """Merge this screener's contribution into the sidecar and write it.

    Merge policy mirrors candidates.csv: an existing file for the SAME
    session_date is merged into (so sp500 and us_small union); any other date is
    stale and discarded. Unlike the CSV there is no last-writer-wins on the
    benchmark block -- if the second screener reports a different close, MA, bar
    date, regime_ma or benchmark symbol, the disagreement is RECORDED and
    read_regime() will refuse the file. Two screeners minutes apart pre-open see
    the same completed daily bar; if they do not, one of them was served a cache."""
    session_date = str(session_date).strip()
    bench_block = {
        "benchmark": benchmark,
        "regime_ma": regime_ma,
        "benchmark_close": None if benchmark_close is None else float(benchmark_close),
        "benchmark_ma": None if benchmark_ma is None else float(benchmark_ma),
        "bar_date": None if bar_date is None else str(bar_date).strip(),
    }
    doc = None
    if os.path.exists(path):
        try:
            with open(path, "r", encoding="utf-8") as fh:
                old = json.load(fh)
            if (old.get("schema_version") == REGIME_SCHEMA_VERSION
                    and str(old.get("session_date", "")).strip() == session_date):
                doc = old
            else:
                log(f"[regime] existing {path} is for "
                    f"{old.get('session_date')!r} (schema "
                    f"{old.get('schema_version')!r}) — discarding as stale")
        except Exception as e:
            log(f"[regime] could not read existing {path} ({e}) — rewriting fresh")

    if doc is None:
        doc = {"schema_version": REGIME_SCHEMA_VERSION,
               "session_date": session_date,
               "screeners": {}, "disagreements": []}
        doc.update(bench_block)
    else:
        others = set(doc.get("screeners", {})) - {str(screener)}
        if not others:
            # A RE-RUN by the only screener that has written today replaces its
            # own contribution. A screener is not disagreeing with itself, and a
            # re-run after a failed first attempt legitimately carries a newer
            # bar. Disagreement detection is a CROSS-screener check.
            doc.update(bench_block)
            doc["disagreements"] = []
            bench_block = {}
        for k, v in bench_block.items():
            prev = doc.get(k)
            same = (prev == v) or (isinstance(prev, float) and isinstance(v, float)
                                   and abs(prev - v) < 1e-9)
            if not same:
                msg = (f"{screener}: {k}={v!r} but "
                       f"{'/'.join(doc.get('screeners', {})) or 'an earlier run'} "
                       f"wrote {prev!r}")
                doc.setdefault("disagreements", []).append(msg)
                log(f"[regime] DISAGREEMENT — {msg}")

    doc["state"] = _regime_state(doc.get("benchmark_close"), doc.get("benchmark_ma"))
    doc.setdefault("screeners", {})[str(screener)] = {
        "vcp_threshold": None if vcp_threshold is None else float(vcp_threshold),
        "degraded_threshold": (None if degraded_threshold is None
                               else float(degraded_threshold)),
        "emitted": int(emitted),
    }

    # PID-scoped: two screeners running concurrently must not race on one
    # temp file. os.replace stays atomic.
    tmp = f"{path}.{os.getpid()}.tmp"
    with open(tmp, "w", encoding="utf-8", newline="") as fh:
        json.dump(doc, fh, indent=2, sort_keys=True)
    os.replace(tmp, path)                      # atomic; never a half-written gate
    return doc


def read_regime(path: str, session_date: str, *,
                max_bar_age_days: int = REGIME_MAX_BAR_AGE_DAYS,
                expected_threshold=None, expected_regime_ma=None):
    """Return (benchmark_close, benchmark_ma, meta).

    FAILS CLOSED: (None, None, meta) on missing, unreadable, wrong schema, wrong
    session date, absent/implausible bar date, recorded disagreement, or a
    --emit-threshold degraded run. meta['reason'] always says which, and
    meta['validated'] says the HANDSHAKE passed (checks that do not involve
    the benchmark); meta['usable'] says that AND a fresh benchmark is present.
    A caller running with the regime gate OFF must still refuse on
    validated=False -- see ExposureController.decide(handshake_ok=...).

    Pass the (None, None) straight to ExposureController.decide(): it fails
    closed to UNAVAILABLE -> exposure 0.0, which blocks NEW entries only. Exits
    keep running, matching the backtest, where the gate empties `eligible` and
    leaves open positions alone."""
    # PATCH F2: two booleans, not one.
    #   validated -- the HANDSHAKE passed: this sidecar describes a screener run
    #                we can trust (schema, session, no disagreement, no
    #                --emit-threshold, threshold matches, someone wrote it).
    #                TRUE even when no benchmark is present, which is exactly
    #                the case when the regime gate is switched off.
    #   usable    -- validated AND a fresh benchmark is present. Unchanged
    #                meaning; still what the regime verdict needs.
    meta = {"usable": False, "validated": False, "reason": "", "path": path,
            "doc": None}

    def _no(reason):
        meta["reason"] = reason
        return None, None, meta

    if not os.path.exists(path):
        return _no(f"no regime sidecar at {path} — screener has not run, or ran "
                   f"without regime values")
    try:
        with open(path, "r", encoding="utf-8") as fh:
            doc = json.load(fh)
    except Exception as e:
        return _no(f"regime sidecar unreadable ({e})")
    meta["doc"] = doc

    if doc.get("schema_version") != REGIME_SCHEMA_VERSION:
        return _no(f"regime schema {doc.get('schema_version')!r}, expected "
                   f"{REGIME_SCHEMA_VERSION}")
    got_date = str(doc.get("session_date", "")).strip()
    if got_date != str(session_date).strip():
        return _no(f"regime is for {got_date!r}, today is {session_date!r} — STALE")
    if (expected_regime_ma is not None
            and doc.get("regime_ma") != expected_regime_ma):
        return _no(f"sidecar regime_ma is {doc.get('regime_ma')!r} but this trader "
                   f"is configured for {expected_regime_ma!r}. The MA in the file "
                   f"was computed on the SCREENER's window; consuming it here "
                   f"would gate on one window while logging another")
    if doc.get("disagreements"):
        return _no("screeners disagree about the benchmark: "
                   + "; ".join(doc["disagreements"]))

    for name, info in (doc.get("screeners") or {}).items():
        if info.get("degraded_threshold") is not None:
            return _no(f"{name} ran with --emit-threshold "
                       f"{info['degraded_threshold']} — a supervised plumbing run "
                       f"must never arm")
        if (expected_threshold is not None
                and info.get("vcp_threshold") != expected_threshold):
            return _no(f"{name} applied vcp_threshold "
                       f"{info.get('vcp_threshold')!r}, expected "
                       f"{expected_threshold!r}")
    if not (doc.get("screeners") or {}):
        return _no("regime sidecar names no screener — nothing wrote it")

    # PATCH F2 -- every HANDSHAKE check above has passed. Everything
    # below is about the BENCHMARK, which only matters when a regime
    # is actually being computed. A caller with the gate off must
    # still be refused on any failure ABOVE this line.
    meta["validated"] = True

    # PATCH F4 -- the sidecar records regime_ma=null: the screener ran with the
    # gate deliberately OFF. Everything above is the handshake and it passed;
    # there is no benchmark and none is expected. Returning here rather than
    # falling into the check below keeps the trader's healthy-day line honest --
    # otherwise RISK_ON is announced with the reason "benchmark unavailable".
    #
    # A trader that still expects a gate never reaches this: check 5 above
    # already refused the mismatch.
    if doc.get("regime_ma") is None:
        meta["reason"] = ("regime gate OFF in the sidecar (regime_ma=null); "
                          "screener handshake OK for "
                          + "/".join(doc.get("screeners", {})))
        return None, None, meta

    close, ma = doc.get("benchmark_close"), doc.get("benchmark_ma")
    if close is None or ma is None:
        return _no(f"benchmark unavailable in the sidecar (state="
                   f"{doc.get('state')!r})")

    bar = str(doc.get("bar_date") or "").strip()
    if not bar:
        return _no("no benchmark bar_date — cannot tell a fresh fetch from a "
                   "cached one")
    try:
        d_bar = _dt.date.fromisoformat(bar)
        d_ses = _dt.date.fromisoformat(str(session_date).strip())
    except ValueError:
        return _no(f"unparseable dates (bar={bar!r}, session={session_date!r})")
    age = (d_ses - d_bar).days
    if age < 0:
        return _no(f"benchmark bar {bar} is AFTER the session {session_date}")
    if age > max_bar_age_days:
        return _no(f"benchmark bar {bar} is {age} days before {session_date} "
                   f"(max {max_bar_age_days}) — probably a cached frame")

    meta["usable"] = True
    meta["reason"] = (f"{doc.get('benchmark')} close {close} vs "
                      f"ma{doc.get('regime_ma')} {ma} (bar {bar}, state "
                      f"{doc.get('state')})")
    return float(close), float(ma), meta


def write_candidates_json(path: str, candidates) -> int:
    payload = {"schema_version": SCHEMA_VERSION,
               "candidates": [asdict(c) for c in candidates]}
    with open(path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2)
    return len(candidates)


def read_candidates_json(path: str, on_bad=None) -> list:
    with open(path, encoding="utf-8") as f:
        payload = json.load(f)
    if payload.get("schema_version") != SCHEMA_VERSION:
        raise ValueError(f"schema_version {payload.get('schema_version')} "
                         f"!= {SCHEMA_VERSION}")
    out = []
    for d in payload.get("candidates", []):
        d = dict(d)
        d.setdefault("close_known", False)       # absent -> UNKNOWN (engine fails closed)
        d.setdefault("contraction_low", 0.0)     # absent -> UNKNOWN (engine fails closed)
        # --- PATCH AD (schema v4) ---
        d.setdefault("avg_vol_50", 0.0)          # absent -> UNKNOWN
        d.setdefault("catalyst_evidence", "")    # absent -> no evidence
        # --- end PATCH AD (schema v4) ---
        try:
            c = Candidate(**d)
        except TypeError as e:
            if on_bad:
                on_bad(d, [str(e)])
            continue
        probs = c.problems()
        if probs:
            if on_bad:
                on_bad(d, probs)
            continue
        out.append(c)
    return out
