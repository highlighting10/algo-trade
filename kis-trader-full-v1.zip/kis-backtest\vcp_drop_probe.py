#!/usr/bin/env python3
r"""
vcp_drop_probe.py -- WHY does the scored population grow with contraction_ratio?

TARGET REPO: kis-backtest. READ-ONLY: writes no file, touches no checkpoint,
edits nothing. Runs a handful of sessions, not a sweep.

THE QUESTION
------------
`RESULT_20260910_E11_ratio_boundary_answered` sec.6: the scored population goes
8,690 (shipped) -> 12,381 (r=0.7) -> 12,841 (r=0.9) on an identical sample, and
only ~3,617 of that is `>=7` names moving into 2-6. About 4,151 name-sessions
score under the adaptive threshold that scored nothing under the shipped one.

Every percentage in both sweeps has that as its denominator, so this is not a
loose end -- it decides whether the sweeps are readable at all.

WHAT THE CODE SAYS BEFORE ANY MEASUREMENT
-----------------------------------------
s6b records a name only when `generate_report` RETURNS and
`stage_3_and_4_contractions` ran. Walking every way a name fails to be recorded:

    check_minervini_technicals fails      threshold-independent (defined OUTSIDE
                                          the engine block, never reaches ZigZag)
    rs < rs_threshold                     threshold-independent
    vcp_no_data                           threshold-independent
    generate_report early-returns
      'Reject (Invalid Data)'             threshold-independent
      'Reject (No Base)'                  threshold-independent -- base_df comes
                                          from _find_base_start, computed BEFORE
                                          _build_waves (vcp_engine extract())
    _to_candidate -> None                 fires AFTER the record is appended
    generate_report RAISES                *** the only threshold-dependent one ***

signals.py:199 catches that as `vcp_exception` and `continue`s. Stages 5-12 all
consume `waves`, so a 112-wave list and a 2-wave list take different paths.

HYPOTHESIS: the shipped threshold crashes the engine on high-wave-count names,
and the adaptive threshold crashes it less. If true, the control's 8,690 is the
most crash-damaged denominator of the seven arms.

This probe does NOT swallow the exception. It classifies every name and prints
the actual traceback, so the answer is a named bug rather than a count.

USAGE (from the kis-backtest root, venv active)
-----------------------------------------------
    python vcp_drop_probe.py                          # last session, r=0.7 vs shipped
    python vcp_drop_probe.py --sessions 3
    python vcp_drop_probe.py --asof 2026-08-03        # the gate/anchor date
    python vcp_drop_probe.py --ratio 0.4 0.7 0.9 --show 5
"""
from __future__ import annotations

import argparse
import os
import pathlib
import sys
import traceback
from collections import Counter


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", default=".")
    ap.add_argument("--clean", default=os.path.join("..", "kis-trader-clean"),
                    help="production tree. The emit bar is a PRODUCTION "
                         "parameter and this repo's vendored kistrader is not "
                         "it -- see --sessions 1 on 2026-09-11, where the "
                         "vendored screen_contract had no VCP_SCORE_THRESHOLD.")
    ap.add_argument("--sessions", type=int, default=1,
                    help="how many trailing sessions to scan (default 1)")
    ap.add_argument("--asof", default=None,
                    help="scan this single session instead of the trailing N")
    ap.add_argument("--tol", type=float, nargs="+", default=None,
                    help="contraction tolerance arms. The quality test is "
                         "depths[i] <= depths[i-1] * tol, so tol > 1.0 counts an "
                         "EXPANDING wave as a contraction. Shipped default is "
                         "'general' = 1.10. Each value runs at the shipped "
                         "contraction_ratio, so the tolerance is isolated.")
    # nargs="*" so `--ratio` with no values runs the tol arms against the
    # shipped control alone. nargs="+" refuses that and argparse errors.
    ap.add_argument("--ratio", type=float, nargs="*", default=[0.7],
                    help="contraction_ratio arms. The shipped engine (None) is "
                         "ALWAYS run first as the control.")
    ap.add_argument("--explain", type=int, default=0,
                    help="list up to N FLIPPED tickers (No Base under the "
                         "shipped engine, scored under this arm) with the base "
                         "geometry each one got.")
    ap.add_argument("--show", type=int, default=3,
                    help="tracebacks to print per distinct exception type")
    a = ap.parse_args()

    root = os.path.abspath(a.repo)
    sys.path.insert(0, root)
    os.chdir(root)

    import pandas as pd
    import vcp_engine as ve
    from signals import (PITBars, RS_RATING_THRESHOLD, VCP_BENCHMARK,
                         VCP_PERIOD, populations_from_universe)
    # The BINDING gate. Verified byte-identical between the vendored and
    # production decision_engine (7 constants + derive_stop / contraction_depth
    # / atr_multiple / entry_limit), so either copy replays the same rule --
    # but stamp which one, per RANK_CLOSED_20260822's convention.
    from kistrader.entry import decision_engine as DE
    _ENG = DE.DecisionEngine(DE.DecisionConfig())
    _CFG = _ENG.cfg

    class _C(object):
        """Duck-typed candidate: derive_stop reads exactly these three."""
        __slots__ = ("pivot", "contraction_low", "atr")

        def __init__(self, pivot, contraction_low, atr):
            self.pivot, self.contraction_low, self.atr = pivot, contraction_low, atr

    def _replay_stop(pivot, contraction_low, atr):
        """Return (risk_pct, ok, why) by calling production's own derive_stop."""
        if not (pivot > 0 and contraction_low > 0):
            return None, False, "no anchor"
        c = _C(float(pivot), float(contraction_low), float(atr or 0.0))
        entry = _ENG.entry_limit(c)
        try:
            stop, _mult = _ENG.derive_stop(c, entry)
        except ValueError as e:
            msg = str(e)
            why = ("risk > max_stop_pct" if "max_stop_pct" in msg
                   else "non-positive risk")
            # recover the number the gate computed, for the distribution
            structural = c.contraction_low * (1.0 - _CFG.stop_buffer_pct)
            return ((entry - structural) / entry if entry > 0 else None), False, why
        return (entry - stop) / entry, True, "" 

    bars = {}
    for p in pathlib.Path("data/bars").glob("*.parquet"):
        df = pd.read_parquet(p)
        if getattr(df.index, "tz", None) is not None:
            df.index = df.index.tz_localize(None)
        if not df.empty:
            bars[p.stem] = df
    if VCP_BENCHMARK not in bars:
        print("  FATAL: %s missing from data/bars." % VCP_BENCHMARK)
        return 2

    cal = PITBars(bars).calendar()
    if a.asof:
        T0 = pd.Timestamp(a.asof)
        scan = cal[cal <= T0][-1:]
    else:
        scan = cal[-a.sessions:]
    if not len(scan):
        print("  FATAL: no sessions in range.")
        return 2

    pops = populations_from_universe("data/universe.csv")
    have = set(bars)
    pops = {k: [t for t in v if t in have] for k, v in pops.items()}

    print("=" * 86)
    print("  VCP DROP PROBE -- what happens to every RS-passing name?")
    print("=" * 86)
    print("  %d tickers, %d session(s) %s..%s"
          % (len(bars), len(scan), scan[0].date(), scan[-1].date()))
    print("  populations: " + ", ".join("%s=%d" % (k, len(v))
                                        for k, v in pops.items()))
    _d = ve.VCPConfig()
    print("  arms: shipped(None) + ratio %s + tol %s"
          % (a.ratio or [], a.tol or []))
    print("  shipped contraction tolerance: %s = %g   (tol > 1.0 counts an "
          "EXPANDING wave as a contraction)"
          % (_d.contraction_mode, _d.contraction_modes[_d.contraction_mode]))
    print("  stop gate: %s" % os.path.abspath(DE.__file__))
    print("             max_stop_pct=%.1f%%  stop_buffer=%.1f%%  chase=%.1f%%"
          % (100 * _CFG.max_stop_pct, 100 * _CFG.stop_buffer_pct,
             100 * _CFG.entry_chase_pct))
    print()

    rows = []
    # one knob per arm, never two -- two knobs in one arm is un-attributable
    _arms = ([(None, None)]
             + [(r, None) for r in (a.ratio or [])]
             + [(None, t) for t in (a.tol or [])])
    for ratio, tol in _arms:
        _kw = {}
        if ratio is not None:
            _kw["contraction_ratio"] = ratio
        if tol is not None:
            # contraction_modes is a plain config dict, so an arbitrary
            # tolerance needs no engine change (verified against VCPConfig).
            _kw["contraction_modes"] = {"probe": float(tol)}
            _kw["contraction_mode"] = "probe"
        cfg = ve.VCPConfig(**_kw)
        server = PITBars(bars)
        ve.set_fetcher(server.fetch)

        tally = Counter()
        # keyed by (ticker, session) NOT ticker: over several sessions the same
        # name recurs, and a ticker-keyed dict would silently report n < SCORED.
        geo = {}                        # (ticker, T) -> (base_bars, depth_frac)
        excs = {}                       # "Type: msg" -> [(ticker, traceback)]
        for T in scan:
            server.set_date(T)
            index_df = server.fetch(VCP_BENCHMARK, VCP_PERIOD)
            for _pname, tickers in pops.items():
                raw_scores, survivors = {}, []
                for t in tickers:
                    try:
                        res = ve.check_minervini_technicals(t)
                    except Exception:
                        tally["stage1_exception"] += 1
                        continue
                    if res[4] is not None:
                        raw_scores[t] = res[4]
                    if res[0]:
                        survivors.append(t)
                    else:
                        tally["stage1_fail"] += 1
                if not survivors or not raw_scores:
                    continue
                ratings = ve.compute_rs_ratings(raw_scores)
                for t in survivors:
                    rs = ratings.get(t)
                    if rs is None or rs < RS_RATING_THRESHOLD:
                        tally["rs_below_threshold"] += 1
                        continue
                    df = server.fetch(t, VCP_PERIOD)
                    if df is None or df.empty:
                        tally["vcp_no_data"] += 1
                        continue
                    try:
                        rep = ve.VCPAnalyzerV4(df, index_df=index_df,
                                               config=cfg).generate_report()
                    except Exception as e:
                        key = "%s: %s" % (type(e).__name__, e)
                        tally["EXCEPTION"] += 1
                        excs.setdefault(key, []).append((t, traceback.format_exc()))
                        continue
                    if not rep:
                        tally["falsy_report"] += 1
                        continue
                    grade = rep.get("Grade", "")
                    if grade == "Reject (Invalid Data)":
                        tally["early_invalid_data"] += 1
                    elif grade == "Reject (No Base)":
                        tally["early_no_base"] += 1
                    else:
                        tally["SCORED"] += 1
                        ep = rep.get("Extracted_Pattern") or {}
                        bh = float(ep.get("Base_High") or 0.0)
                        bl = float(ep.get("Base_Low") or 0.0)
                        lows = ep.get("Wave_Lows") or []
                        piv = float(ep.get("Pivot") or 0.0)
                        clow = float(lows[-1]) if lows else 0.0
                        risk, ok, why = _replay_stop(
                            piv, clow, ep.get("Latest_ATR"))
                        mt = rep.get("Metrics") or {}
                        # THIRD subtraction, previously unmodelled here:
                        # decision_engine._plan_one rejects
                        # close > pivot*(1+max_extension_pct) -- a name that has
                        # already run is not entered. Names at the emit bar are
                        # exactly the ones most likely to have run, so this is
                        # not a rounding effect on the number that matters.
                        _cv = float(ep.get("Latest_Close") or 0.0)
                        _ext = (_cv > 0
                                and _cv <= piv * (1.0 + _CFG.max_extension_pct))
                        geo[(t, T)] = dict(
                            close_v=_cv, ext_ok=_ext, pop=_pname,
                            bars=len(df) - int(ep.get("Base_Start_Bar") or 0),
                            depth=((bh - bl) / bh) if bh > 0 else None,
                            score=float(rep.get("Score") or 0.0),
                            # engine's own formula, vcp_engine.py:897.
                            # THREE factors since 3b: base_points *
                            # quality_ratio * tightness. NOT `or 1.0` -- a
                            # genuine tightness of 0.0 is falsy, and those are
                            # the names 3b exists to score, so the key is
                            # tested for ABSENCE (pre-3b engine, or the n < 2
                            # early return, which returns neither key).
                            s34=(float(mt.get("wave_count_points") or 0.0)
                                 * float(mt.get("contraction_quality") or 0.0)
                                 * (1.0 if mt.get("final_tightness") is None
                                    else float(mt.get("final_tightness")))),
                            risk=risk, stop_ok=ok, stop_why=why)
                        tally["stop_PASS" if ok else "stop_REJECT"] += 1

        label = ("shipped" if (ratio is None and tol is None)
                 else ("ratio=%g" % ratio) if ratio is not None
                 else ("tol=%g" % tol))
        rows.append((label, tally, excs, geo))

        print("-" * 86)
        print("  ARM %s" % label)
        for k in ("SCORED", "EXCEPTION", "early_no_base", "early_invalid_data",
                  "falsy_report", "rs_below_threshold", "stage1_fail",
                  "stage1_exception", "vcp_no_data"):
            if tally.get(k):
                print("    %-20s %7d" % (k, tally[k]))
        if excs:
            print("    distinct exception(s):")
            for key, hits in sorted(excs.items(), key=lambda kv: -len(kv[1])):
                print("      %5d x  %s" % (len(hits), key))
                print("             first: %s" % ", ".join(
                    t for t, _tb in hits[:6]))

    print()
    print("=" * 86)
    print("  COMPARISON")
    print("=" * 86)
    print("  %-12s %8s %10s %12s %12s" %
          ("arm", "SCORED", "EXCEPTION", "no_base", "invalid_data"))
    for label, tally, _e, _g in rows:
        print("  %-12s %8d %10d %12d %12d" %
              (label, tally.get("SCORED", 0), tally.get("EXCEPTION", 0),
               tally.get("early_no_base", 0), tally.get("early_invalid_data", 0)))

    base = rows[0][1]
    base_geo = rows[0][3]
    print()
    if len(rows) < 2:
        print("  (single arm -- no vs-shipped comparison to make.)")
    for label, tally, _e, _g in rows[1:]:
        d_sc = tally.get("SCORED", 0) - base.get("SCORED", 0)
        d_ex = tally.get("EXCEPTION", 0) - base.get("EXCEPTION", 0)
        verdict = ("CONFIRMED -- the growth is fewer crashes"
                   if d_sc > 0 and d_sc == -d_ex else
                   "NOT explained by exceptions alone")
        print("  %s vs shipped: SCORED %+d, EXCEPTION %+d  -> %s"
              % (label, d_sc, d_ex, verdict))

    # ---- base geometry, against the engine's OWN declared band ----------
    import statistics as _st
    MIN_W, MAX_W, DEPTH_ZERO = 6.0, 20.0, 0.35      # vcp_engine.py:130-134

    def _geo_line(tag, items):
        if not items:
            print("    %-22s (none)" % tag)
            return
        wk = [r["bars"] / 5.0 for r in items]
        dp = [r["depth"] for r in items if r["depth"] is not None]
        inband = sum(1 for w in wk if MIN_W <= w <= MAX_W)
        credit = sum(1 for d in dp if d < DEPTH_ZERO)
        print("    %-22s n=%4d  median %5.1fw  in 6-20w %4d (%4.1f%%)"
              "   median depth %5.1f%%  < 35%% %4d (%4.1f%%)"
              % (tag, len(items), _st.median(wk), inband,
                 100.0 * inband / len(items),
                 100.0 * _st.median(dp) if dp else float("nan"),
                 credit, 100.0 * credit / max(1, len(dp))))

    print()
    print("=" * 86)
    print("  BASE GEOMETRY   (engine's own band: 6-20 weeks, depth < 35%;")
    print("                   min_base_bars=10 is only 2 weeks, so clearing the")
    print("                   No-Base rejection is NOT the same as having a base)")
    print("=" * 86)
    for label, _t, _e, g in rows:
        print("  ARM %s" % label)
        _geo_line("all SCORED", list(g.values()))
        if label != rows[0][0]:
            flipped = [k for k in g if k not in base_geo]
            _geo_line("FLIPPED from No Base", [g[k] for k in flipped])
            if a.explain and flipped:
                print("      flipped tickers (up to %d):" % a.explain)
                for k in sorted(flipped)[:a.explain]:
                    r = g[k]
                    print("        %-8s %s  %5.1f weeks   depth %5.1f%%   "
                          "stop %5.1f%% %s"
                          % (k[0], k[1].date(), r["bars"] / 5.0,
                             100.0 * r["depth"] if r["depth"] is not None
                             else float("nan"),
                             100.0 * r["risk"] if r["risk"] is not None
                             else float("nan"),
                             "OK" if r["stop_ok"] else ("X " + r["stop_why"])))

    # ---- THE BINDING GATE: replay max_stop_pct ---------------------------
    def _stop_line(tag, items):
        rk = [r["risk"] for r in items if r["risk"] is not None]
        if not rk:
            print("    %-22s (none)" % tag)
            return
        ok = sum(1 for r in items if r["stop_ok"])
        print("    %-22s n=%4d  median risk %5.1f%%  CLEARS max_stop_pct "
              "%4d (%4.1f%%)  rejected %4d"
              % (tag, len(items), 100.0 * _st.median(rk), ok,
                 100.0 * ok / len(items), len(items) - ok))

    print()
    print("=" * 86)
    print("  STOP GATE   (decision_engine.derive_stop replayed; max_stop_pct")
    print("               %.0f%%. FINDING_20260904: 79%% of new names died here.)"
          % (100 * _CFG.max_stop_pct))
    # The engine above is the VENDORED one (sys.path[0] is this repo). It is
    # dated 2026-07-20 against production's 2026-09-05 and DOES diverge on
    # ranking and sizing -- deliberately, and harness_snapshot.py guards that.
    # Nothing guarded the STOP path, which is the only part these numbers rest
    # on. Parsed from production, not imported: importing would shadow the
    # engine the probe is computing with, and the point is to compare them.
    _STOPK = ("stop_buffer_pct", "max_stop_pct", "entry_chase_pct",
              "max_extension_pct", "atr_mult_min", "atr_mult_max")
    import re as _re2
    _pde = os.path.join(os.path.abspath(a.clean), "kistrader", "entry",
                        "decision_engine.py")
    try:
        with open(_pde, "r", encoding="utf-8") as _dfh:
            _dsrc = _dfh.read()
        _pv = {}
        for _k in _STOPK:
            _mm = _re2.search(r"^\s+%s\s*:\s*float\s*=\s*([0-9.]+)" % _k,
                              _dsrc, _re2.M)
            if _mm:
                _pv[_k] = float(_mm.group(1))
        _miss = [k for k in _STOPK if k not in _pv]
        _diff = [(k, getattr(_CFG, k, None), _pv[k]) for k in _pv
                 if getattr(_CFG, k, None) != _pv[k]]
        if _miss:
            print("  stop-path parity: UNRESOLVED -- not found in production: %s"
                  % ", ".join(_miss))
        elif _diff:
            print("  stop-path parity: *** DIVERGED FROM PRODUCTION ***")
            for _k, _a, _b in _diff:
                print("      %-20s vendored=%-10s production=%s" % (_k, _a, _b))
            print("      These numbers describe the VENDORED rule, not the one")
            print("      that trades. Do not quote them until this is resolved.")
        else:
            print("  stop-path parity: OK -- all %d constants match %s"
                  % (len(_STOPK), _pde))
    except Exception as _e2:
        print("  stop-path parity: UNCHECKED (%s: %s)"
              % (type(_e2).__name__, _e2))
        print("      The numbers below assume the vendored stop path equals "
              "production's.")
    print("=" * 86)
    for label, _t, _e, g in rows:
        print("  ARM %s" % label)
        _stop_line("all SCORED", list(g.values()))
        if label != rows[0][0]:
            _stop_line("FLIPPED from No Base",
                       [g[k] for k in g if k not in base_geo])

    # ---- SCORE DISTRIBUTION vs the emit bar ------------------------------
    # The probe has recorded `score` per name-session since the GEO patch and
    # never summarised it. One live day (2026-09-11) topped out at 62.52 against
    # a bar of 75; this answers whether that is a typical day, from history
    # already on disk, instead of waiting for more days to happen.
    # The bar is a PRODUCTION parameter. sys.path[0] is this repo's root, so an
    # import resolves the VENDORED kistrader -- which on 2026-09-11 turned out
    # not to declare VCP_SCORE_THRESHOLD at all. Read the production file by
    # path and parse it, without importing: no sys.path mutation, no heavy
    # imports, and the path gets stamped so the reader knows which tree spoke.
    import re as _re
    _thr, _thr_src, _thr_why = None, "", ""
    _vthr, _vsrc = None, ""
    try:
        from kistrader.entry import screen_contract as _VSC
        _vthr = getattr(_VSC, "VCP_SCORE_THRESHOLD", None)
        _vsrc = os.path.abspath(_VSC.__file__)
    except Exception:
        pass
    _prod = os.path.join(os.path.abspath(a.clean), "kistrader", "entry",
                         "screen_contract.py")
    try:
        with open(_prod, "r", encoding="utf-8") as _pfh:
            _m = _re.search(r"^VCP_SCORE_THRESHOLD\s*=\s*([0-9.]+)",
                            _pfh.read(), _re.M)
        if not _m:
            raise ValueError("no VCP_SCORE_THRESHOLD in %s" % _prod)
        _thr = float(_m.group(1))
        _thr_src = _prod
    except Exception as _e:
        # No hardcoded fallback ON PURPOSE: a second literal for the bar is
        # exactly the "two declarations, each claiming the other mirrors it"
        # problem screen_contract was created to end.
        _thr_why = "%s: %s" % (type(_e).__name__, _e)

    def _dist_line(tag, scores):
        if not scores:
            print("    %-22s (none)" % tag)
            return
        s = sorted(scores)
        n = len(s)

        def _pct(p):
            return s[min(n - 1, int(round((p / 100.0) * (n - 1))))]

        print("    %-22s n=%4d  max %6.2f  p99 %6.2f  p95 %6.2f  median %6.2f"
              % (tag, n, s[-1], _pct(99), _pct(95), _st.median(s)))
        if _thr is None:
            return
        bands = [(_thr, None), (_thr - 5, _thr), (_thr - 10, _thr - 5),
                 (_thr - 15, _thr - 10), (None, _thr - 15)]
        parts = []
        for lo, hi in bands:
            k = sum(1 for x in s
                    if (lo is None or x >= lo) and (hi is None or x < hi))
            name = (">=%g" % lo if hi is None
                    else "<%g" % hi if lo is None
                    else "%g-%g" % (lo, hi))
            parts.append("%s: %d (%.1f%%)" % (name, k, 100.0 * k / n))
        print("      " + "   ".join(parts))
        over = sum(1 for x in s if x >= _thr)
        if over == 0:
            print("      NOTHING reaches the bar. Best name is %.2f, %.2f "
                  "points short." % (s[-1], _thr - s[-1]))

    print()
    print("=" * 86)
    print("  SCORE DISTRIBUTION   (vcp_score vs the emit bar. This probe SKIPS"
          " Stage 2,")
    print("                        so this is a SUPERSET of production: if the")
    print("                        max here is under the bar, production's is"
          " too.)")
    print("=" * 86)
    if _thr is None:
        print("  bar: UNAVAILABLE -- could not read VCP_SCORE_THRESHOLD from")
        print("       kistrader.entry.screen_contract (%s)." % _thr_why)
        print("       Bands omitted. No hardcoded fallback: a second literal for")
        print("       the strategy bar is the defect screen_contract exists to")
        print("       prevent.")
    else:
        print("  bar: VCP_SCORE_THRESHOLD = %g" % _thr)
        print("       from %s" % _thr_src)
        if _vthr is None:
            print("       the VENDORED screen_contract declares no "
                  "VCP_SCORE_THRESHOLD at all%s"
                  % (" (%s)" % _vsrc if _vsrc else ""))
        elif float(_vthr) != _thr:
            print("       *** the VENDORED copy says %s -- DIVERGED (%s)"
                  % (_vthr, _vsrc))
        else:
            print("       vendored copy agrees (%s)" % _vsrc)
    for label, _t, _e, g in rows:
        print("  ARM %s" % label)
        _dist_line("all SCORED", [r["score"] for r in g.values()])
        _dist_line("clears the stop gate",
                   [r["score"] for r in g.values() if r["stop_ok"]])
        # geo is keyed by (ticker, session) and consecutive sessions repeat the
        # same names, so a COUNT above the bar is name-sessions, not names. Ten
        # name-sessions is one ticker on ten days or ten tickers on one day, and
        # those mean opposite things. Name them.
        if _thr is not None:
            _at = sorted({k[0] for k, r in g.items() if r["score"] >= _thr})
            _atok = sorted({k[0] for k, r in g.items()
                            if r["score"] >= _thr and r["stop_ok"]})
            print("      at/above the bar: %d name-session(s), %d DISTINCT "
                  "ticker(s): %s" % (sum(1 for r in g.values()
                                         if r["score"] >= _thr),
                                     len(_at), ", ".join(_at) or "none"))
            print("      of those, sizable (clears the stop gate): %d ticker(s)"
                  ": %s" % (len(_atok), ", ".join(_atok) or "none"))
            _armable = sorted({k[0] for k, r in g.items()
                               if r["score"] >= _thr and r["stop_ok"]
                               and r["ext_ok"]})
            print("      and NOT too extended (close <= pivot+%.0f%%): %d "
                  "ticker(s) on AT LEAST ONE session: %s"
                  % (100 * _CFG.max_extension_pct, len(_armable),
                     ", ".join(_armable) or "none"))
            # The line above is a UNION over sessions: a ticker counts if ANY
            # session had it armable. On 07-27..08-07 that union read 2 while
            # 08-07 alone read 0 -- ROKU was above the bar and sizable but
            # already past pivot+5%. Both are true; only the per-session number
            # says how long Step 4 waits. Same error as the distinct-ticker one
            # (RESULT_20260911 sec.3), one layer further in.
            _per = {}
            for _k, _r in g.items():
                _per.setdefault(_k[1], 0)
                if (_r["score"] >= _thr and _r["stop_ok"] and _r["ext_ok"]):
                    _per[_k[1]] += 1
            if _per:
                _pv2 = sorted(_per.values())
                _z = sum(1 for _x in _pv2 if _x == 0)
                print("      PER SESSION armable: %d session(s), max %d, "
                      "median %.1f, ZERO on %d (%.0f%%)"
                      % (len(_pv2), _pv2[-1], _st.median(_pv2), _z,
                         100.0 * _z / len(_pv2)))
                print("      ^ this is the Step 4 wait, not the union above.")
            # RS is a percentile PER POPULATION, so sp500 and us_small are two
            # separate screens that happen to share a CSV. On 07-27..08-07 both
            # names above the bar were us_small -- and an sp500-only dry-run the
            # same week peaked at 62.52, which looked like a contradiction until
            # the populations were separated. Print the split, do not infer it.
            _bypop = {}
            for _k, _r in g.items():
                if _r["score"] >= _thr:
                    _bypop.setdefault(_r["pop"], set()).add(_k[0])
            print("      by population: " + ("; ".join(
                "%s: %d (%s)" % (_p, len(_v), ", ".join(sorted(_v)))
                for _p, _v in sorted(_bypop.items())) or "none"))
            print("      STILL NOT MODELLED HERE: Stage 2 catalyst, KIS "
                  "tradability. Both only subtract.")

    # ---- PAIRED: names scored under BOTH -- dilution cannot touch these -----
    print()
    print("=" * 86)
    print("  PAIRED DELTAS   (names scored in BOTH arms; new arrivals excluded,")
    print("                   so any movement here is geometry + wave points)")
    print("=" * 86)
    # A header box closed on an empty body is how this repo has been fooled
    # before (S13 printed a value it never asserted). rows[1:] is empty on a
    # single-arm run, so say that rather than print silence.
    if len(rows) < 2:
        print("  (single arm: %s. Paired deltas need a SECOND arm -- pass"
              % rows[0][0])
        print("   values to --ratio or --tol. Nothing is wrong with this run.)")
    for label, _t, _e, g in rows[1:]:
        both = [k for k in g if k in base_geo]
        if not both:
            print("  ARM %s   (no paired names)" % label)
            continue
        d_sc = [g[k]["score"] - base_geo[k]["score"] for k in both]
        d_34 = [g[k]["s34"] - base_geo[k]["s34"] for k in both]
        worse = sum(1 for x in d_sc if x < 0)
        tot, t34 = sum(d_sc), sum(d_34)
        # UNITS: s34 is RAW stage points (0-15); Score is normalised,
        # final = raw / max_score * 100. Comparing them raw inflates the share
        # by exactly max_score/100 -- which is what produced a "104%" that
        # should have been 100% by construction on the tol arms.
        _k34 = 100.0 / _d.max_score
        t34n = t34 * _k34
        print("  ARM %s   n=%d paired" % (label, len(both)))
        print("    median score delta      %+6.2f pct   (worse: %d, %.1f%%)"
              % (_st.median(d_sc), worse, 100.0 * worse / len(both)))
        print("    median stage-3/4 delta  %+6.2f pct   stage 3/4 explains %s "
              "of the total score movement"
              % (_st.median(d_34) * _k34,
                 ("%.0f%%" % (100.0 * t34n / tot)) if abs(tot) > 1e-9 else "n/a"))
        print("    (total score %+.1f pct, of which stage 3/4 %+.1f pct "
              "(%+.1f raw / %g), residual %+.1f = base geometry + the rest)"
              % (tot, t34n, t34, _d.max_score, tot - t34n))

    # the tracebacks last, so the counts stay readable above them
    for label, _t, excs, _g in rows:
        for key, hits in sorted(excs.items(), key=lambda kv: -len(kv[1])):
            print()
            print("=" * 86)
            print("  ARM %s -- %s   (%d name-session(s))" % (label, key, len(hits)))
            print("=" * 86)
            for _t2, tb in hits[:a.show]:
                print(tb)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
