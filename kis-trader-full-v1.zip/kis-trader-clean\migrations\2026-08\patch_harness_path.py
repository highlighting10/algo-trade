#!/usr/bin/env python3
"""
patch_harness_path.py -- make test_screener_harness.py self-locating.

THE SYMPTOM
    python tests\\test_screener_harness.py   ->  0/12, "No module named 'screeners'"
    python -m pytest -q                      ->  86 passed

Not a code failure. pytest puts the repo root on sys.path via pyproject's
`pythonpath = [".", "tests"]`; a direct run does not -- sys.path[0] is tests\\,
and `screeners` is NOT an installed package (pyproject's packages.find includes
only kistrader*). So `pip install -e .` makes every kistrader suite runnable
anywhere while leaving this one dependent on PYTHONPATH being set in that shell.

Which means the gate works until you open a new terminal. That is precisely the
failure mode this project keeps closing everywhere else.

THE FIX
The same three lines test_candidate_emit.py already uses -- resolve the repo root
from __file__ and put it, plus screeners/, on sys.path. No env var, no shell
state, works from any directory.

Usage:  python patch_harness_path.py <repo-root>
"""
from __future__ import annotations

import os
import sys

OLD = '''from __future__ import annotations

import os
import sys
import types

PASS, FAIL = [], []
'''

NEW = '''from __future__ import annotations

import os
import sys
import types

# Self-locating, like test_candidate_emit.py. `screeners` is not an installed
# package (pyproject packages.find includes only kistrader*), so a direct run --
# where sys.path[0] is tests/ -- cannot import it. pytest happens to work because
# pyproject sets pythonpath = [".", "tests"]. Depending on that difference means
# the suite runs green under one command and 0/12 under the other, in a shell
# that merely forgot an env var.
_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.dirname(_HERE)
for _p in (_ROOT, os.path.join(_ROOT, "screeners")):
    if _p not in sys.path:
        sys.path.insert(0, _p)

PASS, FAIL = [], []
'''


def main(root):
    p = os.path.join(root, "tests", "test_screener_harness.py")
    if not os.path.isfile(p):
        raise SystemExit(f"REFUSING: not found: {p}")
    with open(p, encoding="utf-8") as f:
        s = f.read()
    if "_ROOT = os.path.dirname(_HERE)" in s:
        raise SystemExit("REFUSING: already self-locating.")
    n = s.count(OLD)
    if n != 1:
        raise SystemExit(f"REFUSING: anchor matched {n} times, expected 1")
    with open(p, "w", encoding="utf-8", newline="") as f:
        f.write(s.replace(OLD, NEW))
    print("  ok  test_screener_harness.py: resolves the repo root from __file__")
    print("\nAPPLIED. The direct run no longer depends on PYTHONPATH being set.")
    return 0


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("usage: python patch_harness_path.py <repo-root>")
    sys.exit(main(sys.argv[1]))
