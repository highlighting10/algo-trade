#!/usr/bin/env python3
"""
emit_probe.py — prove the §1.6 report -> Candidate mapping on REAL screener output.
===================================================================================

PLUMBING MODE. This is a diagnostic, not a trading path. It never writes
candidates.csv and never places an order.

Why it exists: on a day where nothing clears VCP >= 80, `candidate_from_report()`
is never called on a real VCPAnalyzerV4 report — so the emitter's most important
half (field provenance, §1.6 absolutes, exchange resolution, geometry) stays
unproven on live data. Waiting for a real candidate day means discovering any
mapping bug on the one day you actually wanted to trade. This probe drives the
REAL engine on REAL tickers with the threshold lowered, writes to a SCRATCH file,
and reports exactly what the emitter produced.

Cost: zero Gemini quota (Stage 3 is free). yfinance history fetches only, and the
screener's own price_cache is used, so a re-run is nearly free.

What is real here and what is not:
  REAL  — price history, the VCP engine, generate_report(), the §1.6 keys,
          candidate_from_report(), the KIS tradable-universe gate, the CSV
          round-trip through read_candidates().
  FAKE  — rs_proxy and stage2_score (placeholders; those come from Stage 1/2,
          which the synthetic contract tests already cover). They are stamped
          with obviously-fake values so a probe row can never be mistaken for a
          real candidate.

Usage (from the repo root):
    python screeners\\emit_probe.py                        # tonight's near-misses
    python screeners\\emit_probe.py NTAP OKTA --threshold 60
    python screeners\\emit_probe.py --screener us_small RSI OKTA
"""
from __future__ import annotations

import argparse
import os
import sys

# Support both `python screeners\emit_probe.py` and `python -m screeners.emit_probe`
try:
    from candidate_emit import emit_candidates
except ImportError:
    from screeners.candidate_emit import emit_candidates

from kistrader.entry.screen_contract import read_candidates

FAKE_RS = 90            # placeholder — NOT a real Stage-1 rating
FAKE_CATALYST = 60.0    # placeholder — NOT a real Stage-2 score

# The five names emitted at VCP>=60 on 2026-07-17 and REJECTED by the decision
# engine for "base too wide" (max_stop_pct), plus JBHT as the control (it passes).
DEFAULT_TICKERS = ["DELL", "FTNT", "NTAP", "CASY", "DVA", "JBHT"]

# DecisionConfig defaults, mirrored here for the stop-anchor diagnostic.
CHASE = 0.005        # entry_chase_pct  -> entry = pivot * (1 + CHASE)
STOP_BUFFER = 0.005  # stop_buffer_pct  -> stop  = anchor * (1 - STOP_BUFFER)
MAX_STOP_PCT = 0.10  # max_stop_pct     -> reject if (entry-stop)/entry > this


ATR_MULT_MIN = 1.3   # DecisionConfig.atr_mult_min
ATR_MULT_MAX = 2.5   # DecisionConfig.atr_mult_max
DEPTH_SHALLOW = 0.08 # DecisionConfig.depth_shallow
DEPTH_DEEP = 0.25    # DecisionConfig.depth_deep


def _lerp_clamped(x, x0, y0, x1, y1):
    t = (x - x0) / (x1 - x0)
    t = max(0.0, min(1.0, t))
    return y0 + t * (y1 - y0)


def _derive_stop(entry, anchor, depth, atr):
    """Faithful replica of DecisionEngine.derive_stop() — INCLUDING the ATR floor.
    (The first version of this diagnostic omitted the floor and overstated which
    names would arm; the floor can drag the stop back DOWN past the anchor.)"""
    mult = _lerp_clamped(depth, DEPTH_SHALLOW, ATR_MULT_MIN, DEPTH_DEEP, ATR_MULT_MAX)
    structural = anchor * (1 - STOP_BUFFER)
    stop = min(structural, entry - mult * atr) if atr > 0 else structural
    stop = round(stop, 2)
    risk = (entry - stop) / entry if entry > 0 else 1.0
    return mult, structural, stop, risk, risk <= MAX_STOP_PCT


def _anchor_report(t, ep):
    """Does the STOP ANCHOR explain the 'base too wide' rejections?

    The candidate is internally inconsistent: `pivot` is the FINAL contraction's
    high, but `base_low` and `depth_pct` both describe the WHOLE base. So the
    entry comes off one structure and the stop off another. Three scenarios:

      A  anchor=Base_Low,      depth=whole base        (CURRENT behavior)
      B  anchor=Wave_Lows[-1], depth=whole base        (anchor fixed only)
      C  anchor=Wave_Lows[-1], depth=final contraction (both fixed -> Minervini)

    B matters because depth drives atr_multiple(): a whole-base depth inflates the
    multiple, so the ATR floor re-imposes the wide stop the anchor fix removed.

    Returns {'A':bool,'B':bool,'C':bool} or None if the report can't be read."""
    piv = float(ep.get("Pivot", 0) or 0)
    base_low = float(ep.get("Base_Low", 0) or 0)
    base_high = float(ep.get("Base_High", 0) or 0)
    atr = float(ep.get("Latest_ATR", 0) or 0)
    lows = [float(x) for x in (ep.get("Wave_Lows") or [])]
    highs = [float(x) for x in (ep.get("Wave_Highs") or [])]
    if piv <= 0 or not lows or base_low <= 0 or base_high <= 0:
        print(f"           anchor: SKIP (pivot={piv}, base_low={base_low}, lows={lows})")
        return None

    entry = round(piv * (1 + CHASE), 2)
    final_low = lows[-1]
    depth_base = (base_high - base_low) / base_high
    depth_final = (piv - final_low) / piv

    # ordering check — everything below assumes waves are chronological
    order_ok = bool(highs) and abs(highs[-1] - piv) < 0.01
    if not order_ok:
        print(f"           !! Pivot {piv:.2f} != Wave_Highs[-1] "
              f"{highs[-1] if highs else float('nan'):.2f} — wave order NOT confirmed; "
              f"treat B/C below as VOID for this name")
    if abs(min(lows) - base_low) > 0.01:
        print(f"           note: Base_Low {base_low:.2f} != min(Wave_Lows) {min(lows):.2f}")

    out = {}
    line = []
    for key, anchor, depth in (("A", base_low, depth_base),
                               ("B", final_low, depth_base),
                               ("C", final_low, depth_final)):
        mult, struct, stop, risk, arms = _derive_stop(entry, anchor, depth, atr)
        out[key] = arms
        line.append(f"{key} {risk:>5.1%} {'ARMS  ' if arms else 'REJECT'}")
    print(f"           depth: base {depth_base:>5.1%} / final {depth_final:>5.1%}   "
          f"entry {entry:>8.2f}   " + " | ".join(line))
    return out


def _load_screener(which):
    name = {"sp500": "sp500_v21", "us_small": "us_small_v21"}[which]
    try:
        return __import__(name)
    except ImportError:
        import importlib
        return importlib.import_module(f"screeners.{name}")


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("tickers", nargs="*", default=None,
                    help=f"tickers to probe (default: {' '.join(DEFAULT_TICKERS)})")
    ap.add_argument("--screener", choices=("sp500", "us_small"), default="sp500",
                    help="which screener's VCP engine/config to import (they are "
                         "ported verbatim; this only picks the module)")
    ap.add_argument("--threshold", type=float, default=0.0,
                    help="VCP threshold for THIS PROBE ONLY (default 0 = emit every "
                         "name that produced a report). Does not touch the screener's "
                         "real VCP_SCORE_THRESHOLD.")
    ap.add_argument("--out", default="emit_probe.csv",
                    help="scratch CSV path (default emit_probe.csv). NEVER use "
                         "candidates.csv here.")
    args = ap.parse_args()

    if os.path.basename(args.out).lower() == "candidates.csv":
        raise SystemExit("[probe] refusing to write candidates.csv — this is a "
                         "plumbing probe with FAKE rs/catalyst scores. Use a scratch path.")

    tickers = [t.upper() for t in (args.tickers or DEFAULT_TICKERS)]
    S = _load_screener(args.screener)

    print(f"[probe] engine={args.screener}  tickers={' '.join(tickers)}  "
          f"probe-threshold={args.threshold}  (real VCP_SCORE_THRESHOLD="
          f"{S.VCP_SCORE_THRESHOLD}, untouched)")
    print(f"[probe] rs_proxy={FAKE_RS} and stage2_score={FAKE_CATALYST} are FAKE "
          f"placeholders. Everything else is real.\n")

    print(f"[probe] fetching benchmark {S.VCP_BENCHMARK} ({S.VCP_LOOKBACK_PERIOD})...")
    index_df = S._flatten_columns(S._fetch_history(S.VCP_BENCHMARK, S.VCP_LOOKBACK_PERIOD))
    if index_df is None or index_df.empty:
        print("[probe] benchmark fetch failed — RS leg degraded (index_df=None)")
        index_df = None

    stage3, s1_rows, s2_rows = [], [], []
    anchor_tally = []
    for i, t in enumerate(tickers, 1):
        print(f"  [{i}/{len(tickers)}] {t:<6} fetching {S.VCP_LOOKBACK_PERIOD}...", flush=True)
        df = S._flatten_columns(S._fetch_history(t, S.VCP_LOOKBACK_PERIOD))
        if df is None or df.empty:
            print(f"           price fetch failed [skip]")
            continue
        try:
            report = S.VCPAnalyzerV4(df=df, index_df=index_df,
                                     contraction_mode=S.VCP_CONTRACTION_MODE).generate_report()
        except Exception as e:
            print(f"           engine error ({type(e).__name__}: {e}) [skip]")
            continue

        ep = report.get("Extracted_Pattern", {}) or {}
        have = [k for k in ("Base_Low", "Latest_Close", "Latest_ATR") if k in ep]
        miss = [k for k in ("Base_Low", "Latest_Close", "Latest_ATR") if k not in ep]
        print(f"           VCP {report.get('Score', 0)} ({report.get('Grade', '?')})  "
              f"§1.6 keys present: {have or 'NONE'}" + (f"  MISSING: {miss}" if miss else ""))
        v = _anchor_report(t, ep)
        if v:
            anchor_tally.append((t, float(report.get("Score", 0) or 0), v))

        stage3.append((t, f"{t} (probe)", report))
        s1_rows.append((t, f"{t} (probe)", 0.0, 0.0, 0.0, FAKE_RS, 0.0))
        s2_rows.append((t, f"{t} (probe)", FAKE_CATALYST))

    if not stage3:
        raise SystemExit("\n[probe] no reports produced — nothing to map. Check network/tickers.")

    if anchor_tally:
        n = len(anchor_tally)
        print(f"\n[probe] --- stop-anchor distribution ({n} name(s)) ---")
        print(f"  A  anchor=Base_Low       depth=whole base        (CURRENT): "
              f"{sum(v['A'] for _, _, v in anchor_tally):>3}/{n} arm")
        print(f"  B  anchor=Wave_Lows[-1]  depth=whole base        (anchor only): "
              f"{sum(v['B'] for _, _, v in anchor_tally):>3}/{n} arm")
        print(f"  C  anchor=Wave_Lows[-1]  depth=final contraction (MINERVINI): "
              f"{sum(v['C'] for _, _, v in anchor_tally):>3}/{n} arm")
        flips = [t for t, _, v in anchor_tally if v["C"] and not v["A"]]
        stuck = [t for t, _, v in anchor_tally if not v["C"]]
        if flips:
            print(f"  A->C flips to ARMS: {' '.join(flips)}")
        if stuck:
            print(f"  reject even under C (genuinely wide final contraction): {' '.join(stuck)}")
        print(f"  NOTE: B vs C shows why the anchor alone is not enough — a whole-base "
              f"depth inflates\n        atr_multiple(), so the ATR floor re-imposes the "
              f"wide stop the anchor fix removed.")

    print(f"\n[probe] --- emitter (real universe gate, real schema) ---")
    n = emit_candidates(stage3_results=stage3, passed_stocks=s1_rows,
                        stage2_passed=s2_rows, out_path=args.out,
                        vcp_threshold=args.threshold, session_date="1900-01-01",
                        source="emit_probe(FAKE rs/catalyst)")

    print(f"\n[probe] --- read back through read_candidates() ---")
    bad = []
    cands = read_candidates(args.out, on_bad=lambda r, w: bad.append((r.get("ticker"), w)))
    for c in cands:
        flags = []
        if not c.close_known:
            flags.append("close_known=FALSE -> engine fails closed")
        if c.atr == 0.0:
            flags.append("atr=0 -> structural-only stop")
        print(f"  {c.ticker:<7} {c.exchange}  vcp={c.vcp_score:<6} pivot={c.pivot:<9.2f} "
              f"close={c.last_close:<9.2f} atr={c.atr:<7.2f} "
              f"base=[{c.base_low:.2f},{c.base_high:.2f}] depth={c.depth_pct:.3f} "
              f"signal={int(c.trade_signal)}" + (("  << " + "; ".join(flags)) if flags else ""))
    for t, w in bad:
        print(f"  {t}: REJECTED BY read_candidates -> {w}")

    print(f"\n[probe] {n} row(s) written to {args.out}, {len(cands)} read back clean, "
          f"{len(bad)} rejected.")
    print(f"[probe] Sanity to eyeball: close within the base's neighbourhood, atr a "
          f"few % of price, base_low < base_high, depth 0..1, exchange NAS/NYS/AMS.")
    print(f"[probe] {args.out} is scratch — delete it, and never feed it to --arm.")


if __name__ == "__main__":
    main()
