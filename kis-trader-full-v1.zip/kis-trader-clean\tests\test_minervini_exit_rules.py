#!/usr/bin/env python3
"""
Phase E stage 0 suite -- the sell-signal observer and its only consumer.
=======================================================================

The draft this replaces shipped four pytest-style functions into a repo whose
runner is `kistrader.cli test`, and that runner executes a FIXED TUPLE of
modules through `runpy.run_module(..., "__main__")`.  `test_minervini_exit_rules`
was not in the tuple, and the file had no `__main__`, so **the tests never ran**
-- not under the runner, and not on the box, which has no pytest installed.
PATCH G2's own comment in `cli.py` already records the lesson: *"A suite outside
this tuple is a suite nobody runs."*

This file is in the tuple, and it drives both halves of stage 0:

  * `kistrader.core.minervini_exit_rules` -- the signals themselves, pure.
  * `kistrader.entry.close_log`           -- the I5 log that records them, which
                                             has had a self-test since it was
                                             written and was likewise never in
                                             the tuple.

Run:  python tests/test_minervini_exit_rules.py     (or via kistrader.cli test)
"""


def main() -> int:
    from kistrader.core import minervini_exit_rules
    from kistrader.entry import close_log

    rc = 0
    for mod in (minervini_exit_rules, close_log):
        rc = max(rc, mod._self_test() or 0)
    return rc


if __name__ == "__main__":
    raise SystemExit(main())
