"""Centralized configuration — everything the runtime needs, read from the
environment (never hard-coded). Optionally loads a local .env file first.

Env vars (see .env.example):
  KIS_APP_KEY, KIS_APP_SECRET, KIS_CANO         (required)
  KIS_PRDT           account product code        (default "01")
  KIS_MOCK           "1"/"0" — mock vs live       (default "1" = mock)
  KIS_EQUITY_USD     account equity in USD for sizing (required for `run`)
  KIS_DB             SQLite event-store path      (default kis_engine_state.db)
  KIS_CANDIDATES     candidates.csv path          (default candidates.csv)
"""
from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Optional


def load_dotenv(path: str = ".env") -> None:
    """Minimal .env loader (no dependency). KEY=VALUE per line; # comments and
    blank lines ignored. Does not overwrite vars already set in the environment."""
    if not os.path.isfile(path):
        return
    with open(path, encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            k, v = k.strip(), v.strip().strip('"').strip("'")
            os.environ.setdefault(k, v)


@dataclass
class Config:
    app_key: str
    app_secret: str
    cano: str
    acnt_prdt_cd: str = "01"
    is_mock: bool = True
    equity_usd: Optional[float] = None
    open_order_check: bool = True
    db_path: str = "kis_engine_state.db"
    candidates_path: str = "candidates.csv"

    @classmethod
    def from_env(cls, dotenv: str = ".env") -> "Config":
        load_dotenv(dotenv)

        def req(k: str) -> str:
            v = os.environ.get(k)
            if not v:
                raise SystemExit(f"missing required env var {k} (see .env.example)")
            return v

        eq = os.environ.get("KIS_EQUITY_USD")
        mock = os.environ.get("KIS_MOCK", "1").lower() not in ("0", "false", "no")
        ooc = os.environ.get("KIS_OPEN_ORDER_CHECK", "1").lower() not in ("0", "false", "no")
        return cls(
            app_key=req("KIS_APP_KEY"),
            app_secret=req("KIS_APP_SECRET"),
            cano=req("KIS_CANO"),
            acnt_prdt_cd=os.environ.get("KIS_PRDT", "01"),
            is_mock=mock,
            equity_usd=float(eq) if eq else None,
            open_order_check=ooc,
            db_path=os.environ.get("KIS_DB", "kis_engine_state.db"),
            candidates_path=os.environ.get("KIS_CANDIDATES", "candidates.csv"),
        )
