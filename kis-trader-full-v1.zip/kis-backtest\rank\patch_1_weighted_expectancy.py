#!/usr/bin/env python3
"""
PATCH 1 -- add a share-weighted expectancy ALONGSIDE the existing one.

THE PROBLEM

`_summarize` reports `expectancy_R = mean(t.r_at_exit)`, and `r_at_exit` is the
RUNNER leg's per-share R -- computed after `pos.shares` was already reduced by
the +3R partial. The partial's proceeds go to `cash` and, by the harness's own
comment at line ~699, "NEVER appear in any Trade record". So `expectancy_R` is
the mean per-share R of the runner, which is a different quantity from the R the
account earned per unit of risk:

    runner r_at_exit    booked    share-weighted    error
             -1.000     -1.000            0.333    -1.333
              0.000      0.000            1.000    -1.000
              3.000      3.000            3.000     0.000
              3.398      3.398            3.265    +0.133

The crossover is at runner-R 3.0: below it the label understates, above it it
overstates. Rev 3's EMA_BREAK mean exit is +3.398R and STOP_HIT is -1.071R, so
the two populations are biased in OPPOSITE directions.

WHY THIS PATCH ADDS RATHER THAN REPLACES

`scripts/06_sweep.py` line 31 depends on the per-share property, deliberately:

    # FALLACY-4 TEST. expectancy_R is per-share, so max_position_pct CANNOT
    # change r for a fixed trade set. Any response must come from the exposure
    # ceiling admitting a DIFFERENT set.

That is a falsification test, and it only works because `expectancy_R` is
position-size invariant. `expectancy_R_weighted` is NOT invariant -- the
partial is `int(shares/3)`, so truncation makes the split move slightly with
share count. **FALLACY-4 must keep using `expectancy_R`.** Replacing the field
would silently break a working guard, so this patch leaves it byte-identical
and adds two new keys next to it.

WHAT CHANGES

  BTPosition   + partial_qty, partial_fill            (recorded when the partial fires)
  Trade        + partial_qty, partial_fill            (carried into the trade log)
  the partial  records qty and fill on the position
  close_position passes them through
  _summarize   + expectancy_R_weighted, partialled_trades

Every existing field keeps its value. Verified by `verify_patches.py`, which
runs the same scenario through the original and the patched harness and asserts
`expectancy_R` is unchanged to the last decimal.

    python patch_1_weighted_expectancy.py --file ..\\minervini_backtest.py
    python patch_1_weighted_expectancy.py --file ..\\minervini_backtest.py --revert
"""
from __future__ import annotations

import argparse
import os
import sys

MARK = "# --- PATCH 1: share-weighted expectancy ---"

EDITS = [
    # (label, anchor, replacement)
    ("BTPosition: record the partial",
     """    days_held: int = 0
    partial_done: bool = False
    last_roll_date: Optional[pd.Timestamp] = None""",
     """    days_held: int = 0
    partial_done: bool = False
    # --- PATCH 1: share-weighted expectancy ---
    # The +3R partial's proceeds go to cash and never reach a Trade, so a
    # share-weighted R cannot be reconstructed afterwards. Record the leg here.
    partial_qty: int = 0
    partial_fill: float = 0.0
    last_roll_date: Optional[pd.Timestamp] = None"""),

    ("Trade: carry the partial leg",
     """    # Needed to compute UNCENSORED forward MFE. max_r_seen only covers the actual
    # hold, so a trade cut at day 10 cannot show a move that happened on day 25 --
    # it conflates "the move was not there" with "we left before it happened".
    risk_per_share: float = 0.0""",
     """    # Needed to compute UNCENSORED forward MFE. max_r_seen only covers the actual
    # hold, so a trade cut at day 10 cannot show a move that happened on day 25 --
    # it conflates "the move was not there" with "we left before it happened".
    risk_per_share: float = 0.0
    # --- PATCH 1: share-weighted expectancy ---
    # `shares` above is the RUNNER count. These two make the whole position
    # reconstructible: original size = shares + partial_qty.
    partial_qty: int = 0
    partial_fill: float = 0.0"""),

    ("the partial records its leg",
     """                    fill = slip_sell(partial_level)
                    cash += qty * fill - sell_cost(qty * fill, qty)
                    pos.shares -= qty
                    pos.partial_done = True""",
     """                    fill = slip_sell(partial_level)
                    cash += qty * fill - sell_cost(qty * fill, qty)
                    pos.shares -= qty
                    pos.partial_qty = qty       # --- PATCH 1 ---
                    pos.partial_fill = fill     # --- PATCH 1 ---
                    pos.partial_done = True"""),

    ("close_position passes it through",
     """        trades.append(Trade(tkr, pos.entry_date, date, pos.entry_price, fill,
                            pos.shares, reason, round(pos.r_multiple(fill), 3),
                            round(pos.max_r_seen, 3), pos.days_held,
                            round(pos.initial_risk_per_share, 6)))""",
     """        trades.append(Trade(tkr, pos.entry_date, date, pos.entry_price, fill,
                            pos.shares, reason, round(pos.r_multiple(fill), 3),
                            round(pos.max_r_seen, 3), pos.days_held,
                            round(pos.initial_risk_per_share, 6),
                            pos.partial_qty,                    # --- PATCH 1 ---
                            round(pos.partial_fill, 6)))        # --- PATCH 1 ---"""),

    ("_summarize: the weighted metric, ADDED not substituted",
     """        "expectancy_R": round(float(np.mean([t.r_at_exit for t in trades])), 3) if trades else 0.0,""",
     """        "expectancy_R": round(float(np.mean([t.r_at_exit for t in trades])), 3) if trades else 0.0,
        # --- PATCH 1: share-weighted expectancy ---
        # expectancy_R above is the RUNNER leg's per-share R and is position-size
        # INVARIANT, which scripts/06_sweep.py's FALLACY-4 test depends on. Do not
        # substitute this for it. This one includes the +3R partial leg, so it is
        # what the account earned per unit of risk -- and it is NOT size-invariant,
        # because the partial is int(shares/3).
        "expectancy_R_weighted": (round(float(np.mean(
            [_weighted_r(t) for t in trades])), 3) if trades else 0.0),
        "partialled_trades": sum(1 for t in trades if getattr(t, "partial_qty", 0) > 0),"""),

    ("_summarize: the helper",
     """def _summarize(equity: pd.Series, trades: List[Trade]) -> dict:""",
     """def _weighted_r(t: "Trade") -> float:
    \"\"\"--- PATCH 1 --- Share-weighted R across BOTH legs.

    t.shares is the runner; t.partial_qty is what the +3R partial sold. Original
    size is their sum. A trade that never partialled returns exactly r_at_exit,
    so this is identical to the old number for every non-partialled trade.
    \"\"\"
    pq = getattr(t, "partial_qty", 0) or 0
    total = t.shares + pq
    if t.risk_per_share <= 0 or total <= 0:
        return float(t.r_at_exit)
    pnl = (pq * (getattr(t, "partial_fill", 0.0) - t.entry_price)
           + t.shares * (t.exit_price - t.entry_price))
    return pnl / (total * t.risk_per_share)


def _summarize(equity: pd.Series, trades: List[Trade]) -> dict:"""),
]


def apply(path, revert=False):
    with open(path, encoding="utf-8") as fh:
        src = fh.read()

    already = MARK in src
    if revert:
        if not already:
            print("PATCH 1 is not applied; nothing to revert.")
            return 1
        for label, anchor, repl in EDITS:
            if src.count(repl) != 1:
                print(f"  [FAIL] cannot revert {label!r}: patched text found "
                      f"{src.count(repl)} times, expected 1")
                return 1
            src = src.replace(repl, anchor)
        _write(path, src)
        print("PATCH 1 reverted. File is byte-identical to the original.")
        return 0

    if already:
        print("PATCH 1 is ALREADY APPLIED. Refusing to run twice (standing rule 4).")
        return 1

    for label, anchor, repl in EDITS:
        n = src.count(anchor)
        if n != 1:
            print(f"  [FAIL] anchor for {label!r} matched {n} times, expected 1.")
            print("         Refusing to patch. Nothing has been written.")
            return 1
    for label, anchor, repl in EDITS:
        src = src.replace(anchor, repl)
        print(f"  [ OK ] {label}")

    _write(path, src)
    print(f"\nPATCH 1 applied to {path}")
    print("Now run:  python verify_patches.py")
    return 0


def _write(path, src):
    # UTF-8, no BOM, LF -- Set-Content -Encoding UTF8 would corrupt this file
    with open(path, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(src)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--file", default="minervini_backtest.py")
    ap.add_argument("--revert", action="store_true")
    args = ap.parse_args()
    if not os.path.isfile(args.file):
        print(f"FATAL: no such file {args.file!r}")
        return 2
    return apply(args.file, revert=args.revert)


if __name__ == "__main__":
    sys.exit(main())
