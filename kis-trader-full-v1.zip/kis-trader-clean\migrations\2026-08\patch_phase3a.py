#!/usr/bin/env python3
"""
patch_phase3a.py -- PHASE 3a: the regime.json provenance artifact.

INERT COMMIT. Nothing reads regime.json yet, and nothing writes it either until
3b passes benchmark values in. This lands the contract and its tests first so
3b and 3c have something already proven to build on.

WHY A SIDECAR (Option C)
candidates.csv is a flat CSV of Candidate rows with no header block, and the
regime is a GLOBAL property, so it does not belong on every row. Option B
(emit zero rows when the regime is off) needs no schema change but leaves the
trader unable to tell "regime off" from "nothing qualified" -- and covering that
with a log line means writing a marker file anyway, which is this artifact
without a schema.

WHAT IT CARRIES
  session_date, benchmark, regime_ma, benchmark_close, benchmark_ma, the BAR's
  own date, the writer's computed state, and per screener: the vcp_threshold
  ACTUALLY APPLIED, whether the run was --emit-threshold degraded, and how many
  rows it emitted.

THREE THINGS IT CLOSES
  1. Trader can distinguish regime-off from nothing-qualified, with a reason.
  2. The --emit-threshold degrade becomes visible. Today a degraded run produces
     a candidates.csv byte-indistinguishable from a real one; the only record is
     stdout. read_regime() reports a degraded run as UNUSABLE, so a supervised
     plumbing run cannot arm anything.
  3. Two screeners disagreeing about the benchmark (one silently served a stale
     cached frame by _fetch_history) becomes a hard failure instead of
     last-writer-wins.

FAIL CLOSED ON READ. Missing, stale, malformed, wrong schema, disagreeing, or
degraded all return (None, None) with a reason -- which ExposureController turns
into UNAVAILABLE -> exposure 0.0 -> no new entries. Exits are untouched, which
matches the backtest: the gate empties `eligible` and leaves positions alone.

Anchors are asserted; edits are applied bottom-up within each file.

Usage:  python patch_phase3a.py <repo-root>
"""
from __future__ import annotations

import os
import sys

CONTRACT_BLOCK = '''# ---------------------------------------------------------------------------
# regime.json — the global-regime sidecar written beside candidates.csv
# ---------------------------------------------------------------------------
REGIME_SCHEMA_VERSION = 1
REGIME_FILENAME = "regime.json"

# How stale the benchmark BAR may be, in calendar days, relative to the session
# it is used for. The screener runs pre-open, so the newest completed daily bar
# is normally the prior session -- 1 day, or 3 over a weekend, more across a
# holiday. 5 covers a long weekend plus a holiday; beyond that the fetch is
# suspect. This matters because the screener's _fetch_history() silently falls
# back to a pickled cache when the provider returns empty, so a "successful"
# fetch can carry a bar from days ago.
REGIME_MAX_BAR_AGE_DAYS = 5


def regime_path_for(candidates_path: str) -> str:
    """The sidecar always sits beside candidates.csv, so one path setting
    configures both and they cannot drift apart."""
    return os.path.join(os.path.dirname(os.path.abspath(candidates_path)),
                        REGIME_FILENAME)


def _regime_state(close, ma) -> str:
    if close is None or ma is None or close != close or ma != ma:   # incl. NaN
        return "unavailable"
    return "risk_on" if float(close) >= float(ma) else "risk_off"


def write_regime(path: str, *, session_date: str, screener: str,
                 vcp_threshold, benchmark: str, regime_ma,
                 benchmark_close, benchmark_ma, bar_date,
                 emitted: int = 0, degraded_threshold=None, log=print) -> dict:
    """Merge this screener's contribution into the sidecar and write it.

    Merge policy mirrors candidates.csv: an existing file for the SAME
    session_date is merged into (so sp500 and us_small union); any other date is
    stale and discarded. Unlike the CSV there is no last-writer-wins on the
    benchmark block -- if the second screener reports a different close, MA, bar
    date, regime_ma or benchmark symbol, the disagreement is RECORDED and
    read_regime() will refuse the file. Two screeners minutes apart pre-open see
    the same completed daily bar; if they do not, one of them was served a cache."""
    session_date = str(session_date).strip()
    bench_block = {
        "benchmark": benchmark,
        "regime_ma": regime_ma,
        "benchmark_close": None if benchmark_close is None else float(benchmark_close),
        "benchmark_ma": None if benchmark_ma is None else float(benchmark_ma),
        "bar_date": None if bar_date is None else str(bar_date).strip(),
    }
    doc = None
    if os.path.exists(path):
        try:
            with open(path, "r", encoding="utf-8") as fh:
                old = json.load(fh)
            if (old.get("schema_version") == REGIME_SCHEMA_VERSION
                    and str(old.get("session_date", "")).strip() == session_date):
                doc = old
            else:
                log(f"[regime] existing {path} is for "
                    f"{old.get('session_date')!r} (schema "
                    f"{old.get('schema_version')!r}) — discarding as stale")
        except Exception as e:
            log(f"[regime] could not read existing {path} ({e}) — rewriting fresh")

    if doc is None:
        doc = {"schema_version": REGIME_SCHEMA_VERSION,
               "session_date": session_date,
               "screeners": {}, "disagreements": []}
        doc.update(bench_block)
    else:
        others = set(doc.get("screeners", {})) - {str(screener)}
        if not others:
            # A RE-RUN by the only screener that has written today replaces its
            # own contribution. A screener is not disagreeing with itself, and a
            # re-run after a failed first attempt legitimately carries a newer
            # bar. Disagreement detection is a CROSS-screener check.
            doc.update(bench_block)
            doc["disagreements"] = []
            bench_block = {}
        for k, v in bench_block.items():
            prev = doc.get(k)
            same = (prev == v) or (isinstance(prev, float) and isinstance(v, float)
                                   and abs(prev - v) < 1e-9)
            if not same:
                msg = (f"{screener}: {k}={v!r} but "
                       f"{'/'.join(doc.get('screeners', {})) or 'an earlier run'} "
                       f"wrote {prev!r}")
                doc.setdefault("disagreements", []).append(msg)
                log(f"[regime] DISAGREEMENT — {msg}")

    doc["state"] = _regime_state(doc.get("benchmark_close"), doc.get("benchmark_ma"))
    doc.setdefault("screeners", {})[str(screener)] = {
        "vcp_threshold": None if vcp_threshold is None else float(vcp_threshold),
        "degraded_threshold": (None if degraded_threshold is None
                               else float(degraded_threshold)),
        "emitted": int(emitted),
    }

    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8", newline="") as fh:
        json.dump(doc, fh, indent=2, sort_keys=True)
    os.replace(tmp, path)                      # atomic; never a half-written gate
    return doc


def read_regime(path: str, session_date: str, *,
                max_bar_age_days: int = REGIME_MAX_BAR_AGE_DAYS,
                expected_threshold=None):
    """Return (benchmark_close, benchmark_ma, meta).

    FAILS CLOSED: (None, None, meta) on missing, unreadable, wrong schema, wrong
    session date, absent/implausible bar date, recorded disagreement, or a
    --emit-threshold degraded run. meta['reason'] always says which, and
    meta['usable'] is the single boolean callers should branch on.

    Pass the (None, None) straight to ExposureController.decide(): it fails
    closed to UNAVAILABLE -> exposure 0.0, which blocks NEW entries only. Exits
    keep running, matching the backtest, where the gate empties `eligible` and
    leaves open positions alone."""
    meta = {"usable": False, "reason": "", "path": path, "doc": None}

    def _no(reason):
        meta["reason"] = reason
        return None, None, meta

    if not os.path.exists(path):
        return _no(f"no regime sidecar at {path} — screener has not run, or ran "
                   f"without regime values")
    try:
        with open(path, "r", encoding="utf-8") as fh:
            doc = json.load(fh)
    except Exception as e:
        return _no(f"regime sidecar unreadable ({e})")
    meta["doc"] = doc

    if doc.get("schema_version") != REGIME_SCHEMA_VERSION:
        return _no(f"regime schema {doc.get('schema_version')!r}, expected "
                   f"{REGIME_SCHEMA_VERSION}")
    got_date = str(doc.get("session_date", "")).strip()
    if got_date != str(session_date).strip():
        return _no(f"regime is for {got_date!r}, today is {session_date!r} — STALE")
    if doc.get("disagreements"):
        return _no("screeners disagree about the benchmark: "
                   + "; ".join(doc["disagreements"]))

    for name, info in (doc.get("screeners") or {}).items():
        if info.get("degraded_threshold") is not None:
            return _no(f"{name} ran with --emit-threshold "
                       f"{info['degraded_threshold']} — a supervised plumbing run "
                       f"must never arm")
        if (expected_threshold is not None
                and info.get("vcp_threshold") != expected_threshold):
            return _no(f"{name} applied vcp_threshold "
                       f"{info.get('vcp_threshold')!r}, expected "
                       f"{expected_threshold!r}")
    if not (doc.get("screeners") or {}):
        return _no("regime sidecar names no screener — nothing wrote it")

    close, ma = doc.get("benchmark_close"), doc.get("benchmark_ma")
    if close is None or ma is None:
        return _no(f"benchmark unavailable in the sidecar (state="
                   f"{doc.get('state')!r})")

    bar = str(doc.get("bar_date") or "").strip()
    if not bar:
        return _no("no benchmark bar_date — cannot tell a fresh fetch from a "
                   "cached one")
    try:
        d_bar = _dt.date.fromisoformat(bar)
        d_ses = _dt.date.fromisoformat(str(session_date).strip())
    except ValueError:
        return _no(f"unparseable dates (bar={bar!r}, session={session_date!r})")
    age = (d_ses - d_bar).days
    if age < 0:
        return _no(f"benchmark bar {bar} is AFTER the session {session_date}")
    if age > max_bar_age_days:
        return _no(f"benchmark bar {bar} is {age} days before {session_date} "
                   f"(max {max_bar_age_days}) — probably a cached frame")

    meta["usable"] = True
    meta["reason"] = (f"{doc.get('benchmark')} close {close} vs "
                      f"ma{doc.get('regime_ma')} {ma} (bar {bar}, state "
                      f"{doc.get('state')})")
    return float(close), float(ma), meta


'''


def edit(text, old, new, label):
    n = text.count(old)
    if n != 1:
        raise SystemExit(f"REFUSING: anchor for {label} matched {n} times, expected 1")
    print(f"  ok  {label}")
    return text.replace(old, new)


def read(p):
    with open(p, encoding="utf-8") as f:
        return f.read()


def write(p, s):
    with open(p, "w", encoding="utf-8", newline="") as f:
        f.write(s)


def main(root):
    sc = os.path.join(root, "kistrader", "entry", "screen_contract.py")
    ce = os.path.join(root, "screeners", "candidate_emit.py")
    tc = os.path.join(root, "tests", "test_candidate_emit.py")
    for p in (sc, ce, tc):
        if not os.path.isfile(p):
            raise SystemExit(f"REFUSING: not found: {p}")

    s_sc, s_ce, s_tc = read(sc), read(ce), read(tc)
    if "VCP_SCORE_THRESHOLD" not in s_sc:
        raise SystemExit("REFUSING: D3a has not been applied.")
    if "write_regime" in s_sc or "regime_path" in s_ce:
        raise SystemExit("REFUSING: Phase 3a appears to be applied already.")

    # ---------------- screen_contract.py ----------------
    print(f"screen_contract.py  ({sc})")
    s_sc = edit(s_sc, "def write_candidates_json(path: str, candidates) -> int:",
                CONTRACT_BLOCK + "def write_candidates_json(path: str, candidates) -> int:",
                "regime sidecar contract (write_regime / read_regime)")
    if "\nimport datetime as _dt\n" not in s_sc:
        s_sc = edit(s_sc, "\nimport csv\n", "\nimport csv\nimport datetime as _dt\n",
                    "import datetime as _dt")
    if "\nimport os\n" not in s_sc:
        s_sc = edit(s_sc, "\nimport math\n", "\nimport math\nimport os\n", "import os")

    # ---------------- candidate_emit.py (bottom-up) ----------------
    print(f"candidate_emit.py  ({ce})")
    s_ce = edit(s_ce, "    n_written = write_candidates(out_path, merged)\n",
                "    n_written = write_candidates(out_path, merged)\n"
                "\n"
                "    # ---- regime provenance sidecar (Phase 3a) ------------------------------------\n"
                "    # Written only when the caller supplies regime values, so a screener that has\n"
                "    # not been taught the gate yet changes nothing. Its ABSENCE is what makes the\n"
                "    # trader fail closed, which is the correct direction.\n"
                "    if regime_ma is not None:\n"
                "        name, _, tail = str(source).partition(\" \")\n"
                "        degraded = None\n"
                "        if \"DEGRADED@\" in tail:\n"
                "            try:\n"
                "                degraded = float(tail.split(\"DEGRADED@\", 1)[1].split()[0])\n"
                "            except (IndexError, ValueError):\n"
                "                degraded = -1.0        # unparseable, but still a degraded run\n"
                "        rp = regime_path or regime_path_for(out_path)\n"
                "        doc = write_regime(rp, session_date=session_date, screener=name,\n"
                "                           vcp_threshold=vcp_threshold, benchmark=benchmark,\n"
                "                           regime_ma=regime_ma,\n"
                "                           benchmark_close=benchmark_close,\n"
                "                           benchmark_ma=benchmark_ma,\n"
                "                           bar_date=benchmark_bar_date,\n"
                "                           emitted=n_written, degraded_threshold=degraded,\n"
                "                           log=log)\n"
                "        log(f\"[regime] {doc['state']} — {benchmark} close={benchmark_close} \"\n"
                "            f\"ma{regime_ma}={benchmark_ma} bar={benchmark_bar_date} -> {rp}\")\n",
                "write the regime sidecar after the CSV")
    s_ce = edit(s_ce,
                "                    universe=None,\n"
                "                    source: str = \"screener\",\n"
                "                    log=print) -> int:\n",
                "                    universe=None,\n"
                "                    source: str = \"screener\",\n"
                "                    benchmark: str = \"^GSPC\",\n"
                "                    regime_ma: Optional[int] = None,\n"
                "                    benchmark_close: Optional[float] = None,\n"
                "                    benchmark_ma: Optional[float] = None,\n"
                "                    benchmark_bar_date: Optional[str] = None,\n"
                "                    regime_path: Optional[str] = None,\n"
                "                    log=print) -> int:\n",
                "emit_candidates: regime kwargs")
    s_ce = edit(s_ce,
                "from kistrader.entry.screen_contract import (Candidate, candidate_from_report,\n"
                "                                             read_candidates, write_candidates)\n",
                "from kistrader.entry.screen_contract import (Candidate, candidate_from_report,\n"
                "                                             read_candidates, write_candidates,\n"
                "                                             regime_path_for, write_regime)\n",
                "import the sidecar writers")

    # ---------------- tests ----------------
    print(f"test_candidate_emit.py  ({tc})")
    s_tc = edit(s_tc,
                "ALL = [v for k, v in sorted(globals().items()) if k.startswith(\"test_\")]\n",
                REGIME_TESTS
                + "ALL = [v for k, v in sorted(globals().items()) if k.startswith(\"test_\")]\n",
                "append the regime sidecar tests")

    write(sc, s_sc); write(ce, s_ce); write(tc, s_tc)
    print("\nPHASE 3a APPLIED (inert — nothing reads or writes the sidecar yet).")
    return 0


REGIME_TESTS = '''# --------------------------------------------------------- regime sidecar ----
# Phase 3a. The artifact exists; 3b makes the screeners fill it and 3c makes the
# trader read it. These tests are the contract both halves are written against.

def _regime_env():
    from kistrader.entry.screen_contract import regime_path_for
    d = tempfile.mkdtemp()
    csv_path = os.path.join(d, "candidates.csv")
    return d, csv_path, regime_path_for(csv_path)


def test_regime_sidecar_sits_beside_candidates():
    _d, csv_path, rp = _regime_env()
    assert os.path.dirname(rp) == os.path.dirname(os.path.abspath(csv_path)), rp
    assert os.path.basename(rp) == "regime.json", rp


def test_regime_write_read_roundtrip():
    from kistrader.entry.screen_contract import write_regime, read_regime
    _d, _csv, rp = _regime_env()
    write_regime(rp, session_date="2026-08-14", screener="sp500_v21",
                 vcp_threshold=75.0, benchmark="^GSPC", regime_ma=20,
                 benchmark_close=5432.10, benchmark_ma=5400.00,
                 bar_date="2026-08-13", emitted=3, log=lambda m: None)
    close, ma, meta = read_regime(rp, "2026-08-14")
    assert meta["usable"], meta["reason"]
    assert close == 5432.10 and ma == 5400.00, (close, ma)
    assert meta["doc"]["state"] == "risk_on", meta["doc"]["state"]
    assert meta["doc"]["screeners"]["sp500_v21"]["vcp_threshold"] == 75.0


def test_regime_state_is_computed_not_asserted():
    from kistrader.entry.screen_contract import write_regime
    _d, _csv, rp = _regime_env()
    doc = write_regime(rp, session_date="2026-08-14", screener="sp500_v21",
                       vcp_threshold=75.0, benchmark="^GSPC", regime_ma=20,
                       benchmark_close=5300.0, benchmark_ma=5400.0,
                       bar_date="2026-08-13", log=lambda m: None)
    assert doc["state"] == "risk_off", doc["state"]
    doc = write_regime(rp, session_date="2026-08-14", screener="sp500_v21",
                       vcp_threshold=75.0, benchmark="^GSPC", regime_ma=20,
                       benchmark_close=5400.0, benchmark_ma=5400.0,
                       bar_date="2026-08-13", log=lambda m: None)
    assert doc["state"] == "risk_on", "close == ma is RISK_ON (>=), not off"


def test_regime_cross_screener_merge():
    from kistrader.entry.screen_contract import write_regime, read_regime
    _d, _csv, rp = _regime_env()
    common = dict(session_date="2026-08-14", benchmark="^GSPC", regime_ma=20,
                  benchmark_close=5432.10, benchmark_ma=5400.00,
                  bar_date="2026-08-13", log=lambda m: None)
    write_regime(rp, screener="sp500_v21", vcp_threshold=75.0, emitted=3, **common)
    write_regime(rp, screener="us_small_v21", vcp_threshold=75.0, emitted=5, **common)
    close, ma, meta = read_regime(rp, "2026-08-14")
    assert meta["usable"], meta["reason"]
    assert set(meta["doc"]["screeners"]) == {"sp500_v21", "us_small_v21"}
    assert meta["doc"]["screeners"]["us_small_v21"]["emitted"] == 5
    assert meta["doc"]["disagreements"] == []


def test_regime_disagreement_fails_closed():
    """Both screeners see the same completed daily bar pre-open. If they do not,
    one was served a cached frame by _fetch_history -- refuse, do not average."""
    from kistrader.entry.screen_contract import write_regime, read_regime
    _d, _csv, rp = _regime_env()
    base = dict(session_date="2026-08-14", benchmark="^GSPC", regime_ma=20,
                benchmark_ma=5400.00, bar_date="2026-08-13", log=lambda m: None)
    write_regime(rp, screener="sp500_v21", vcp_threshold=75.0,
                 benchmark_close=5432.10, **base)
    write_regime(rp, screener="us_small_v21", vcp_threshold=75.0,
                 benchmark_close=5399.00, **base)
    close, ma, meta = read_regime(rp, "2026-08-14")
    assert (close, ma) == (None, None), (close, ma)
    assert "disagree" in meta["reason"], meta["reason"]


def test_regime_same_screener_rerun_replaces():
    """A screener re-running after a failed first attempt must REPLACE its own
    contribution, not be flagged as disagreeing with itself. Cross-screener
    disagreement (test_regime_disagreement_fails_closed) is unaffected."""
    from kistrader.entry.screen_contract import write_regime, read_regime
    _d, _csv, rp = _regime_env()
    common = dict(session_date="2026-08-14", screener="sp500_v21",
                  vcp_threshold=75.0, benchmark="^GSPC", regime_ma=20,
                  log=lambda m: None)
    write_regime(rp, benchmark_close=None, benchmark_ma=None, bar_date=None,
                 emitted=0, **common)                       # failed fetch
    close, ma, meta = read_regime(rp, "2026-08-14")
    assert (close, ma) == (None, None), "first attempt is unusable"
    write_regime(rp, benchmark_close=5432.10, benchmark_ma=5400.00,
                 bar_date="2026-08-13", emitted=3, **common)   # successful re-run
    close, ma, meta = read_regime(rp, "2026-08-14")
    assert meta["usable"], meta["reason"]
    assert (close, ma) == (5432.10, 5400.00), (close, ma)
    assert meta["doc"]["disagreements"] == [], meta["doc"]["disagreements"]
    assert meta["doc"]["screeners"]["sp500_v21"]["emitted"] == 3


def test_regime_stale_session_fails_closed():
    from kistrader.entry.screen_contract import write_regime, read_regime
    _d, _csv, rp = _regime_env()
    write_regime(rp, session_date="2026-08-13", screener="sp500_v21",
                 vcp_threshold=75.0, benchmark="^GSPC", regime_ma=20,
                 benchmark_close=5432.10, benchmark_ma=5400.00,
                 bar_date="2026-08-12", log=lambda m: None)
    close, ma, meta = read_regime(rp, "2026-08-14")
    assert (close, ma) == (None, None)
    assert "STALE" in meta["reason"], meta["reason"]


def test_regime_missing_and_malformed_fail_closed():
    from kistrader.entry.screen_contract import read_regime
    d, _csv, rp = _regime_env()
    close, ma, meta = read_regime(rp, "2026-08-14")
    assert (close, ma) == (None, None) and "no regime sidecar" in meta["reason"]
    with open(rp, "w", encoding="utf-8") as fh:
        fh.write("{not json")
    close, ma, meta = read_regime(rp, "2026-08-14")
    assert (close, ma) == (None, None) and "unreadable" in meta["reason"]
    with open(rp, "w", encoding="utf-8") as fh:
        fh.write('{"schema_version": 99, "session_date": "2026-08-14"}')
    close, ma, meta = read_regime(rp, "2026-08-14")
    assert (close, ma) == (None, None) and "schema" in meta["reason"]


def test_regime_bar_age_guard():
    """_fetch_history silently substitutes a pickled cache when the provider
    returns empty, so a 'successful' fetch can carry a bar from days ago."""
    from kistrader.entry.screen_contract import write_regime, read_regime
    _d, _csv, rp = _regime_env()
    common = dict(session_date="2026-08-14", screener="sp500_v21",
                  vcp_threshold=75.0, benchmark="^GSPC", regime_ma=20,
                  benchmark_close=5432.10, benchmark_ma=5400.00,
                  log=lambda m: None)
    write_regime(rp, bar_date="2026-08-11", **common)          # 3 days: long weekend
    assert read_regime(rp, "2026-08-14")[2]["usable"]
    write_regime(rp, bar_date="2026-08-01", **common)          # 13 days: cached
    close, ma, meta = read_regime(rp, "2026-08-14")
    assert (close, ma) == (None, None) and "cached frame" in meta["reason"], meta["reason"]
    write_regime(rp, bar_date="2026-08-20", **common)          # future
    assert "AFTER the session" in read_regime(rp, "2026-08-14")[2]["reason"]
    write_regime(rp, bar_date=None, **common)
    assert "bar_date" in read_regime(rp, "2026-08-14")[2]["reason"]


def test_regime_degraded_run_never_arms():
    """--emit-threshold is documented as supervised plumbing only, and today its
    CSV is byte-indistinguishable from a real run. The sidecar makes it visible
    and refuses it."""
    from kistrader.entry.screen_contract import write_regime, read_regime
    _d, _csv, rp = _regime_env()
    write_regime(rp, session_date="2026-08-14", screener="sp500_v21",
                 vcp_threshold=75.0, degraded_threshold=70.0, benchmark="^GSPC",
                 regime_ma=20, benchmark_close=5432.10, benchmark_ma=5400.00,
                 bar_date="2026-08-13", log=lambda m: None)
    close, ma, meta = read_regime(rp, "2026-08-14")
    assert (close, ma) == (None, None)
    assert "emit-threshold" in meta["reason"], meta["reason"]


def test_regime_threshold_mismatch_detected():
    from kistrader.entry.screen_contract import write_regime, read_regime
    _d, _csv, rp = _regime_env()
    write_regime(rp, session_date="2026-08-14", screener="us_small_v21",
                 vcp_threshold=70.0, benchmark="^GSPC", regime_ma=20,
                 benchmark_close=5432.10, benchmark_ma=5400.00,
                 bar_date="2026-08-13", log=lambda m: None)
    _c, _m, meta = read_regime(rp, "2026-08-14", expected_threshold=75.0)
    assert not meta["usable"] and "applied vcp_threshold" in meta["reason"], meta["reason"]


def test_regime_unavailable_benchmark_fails_closed():
    from kistrader.entry.screen_contract import write_regime, read_regime
    _d, _csv, rp = _regime_env()
    doc = write_regime(rp, session_date="2026-08-14", screener="sp500_v21",
                       vcp_threshold=75.0, benchmark="^GSPC", regime_ma=20,
                       benchmark_close=None, benchmark_ma=None,
                       bar_date=None, log=lambda m: None)
    assert doc["state"] == "unavailable", doc["state"]
    close, ma, meta = read_regime(rp, "2026-08-14")
    assert (close, ma) == (None, None) and "benchmark unavailable" in meta["reason"]


def test_emit_writes_the_sidecar():
    """End to end through emit_candidates, the way 3b will call it."""
    from kistrader.entry.screen_contract import read_regime
    d, csv_path, rp = _regime_env()
    n = emit_candidates(stage3_results=[("AAPL", "Apple", rep(score=91))],
                        passed_stocks=[s1("AAPL", 95)],
                        stage2_passed=[("AAPL", "Apple", 72.5)],
                        out_path=csv_path, vcp_threshold=75.0,
                        session_date="2026-08-14", universe=UNIVERSE,
                        source="sp500_v21", benchmark="^GSPC", regime_ma=20,
                        benchmark_close=5432.10, benchmark_ma=5400.00,
                        benchmark_bar_date="2026-08-13", log=lambda m: None)
    assert n == 1, n
    close, ma, meta = read_regime(rp, "2026-08-14")
    assert meta["usable"], meta["reason"]
    assert meta["doc"]["screeners"]["sp500_v21"]["emitted"] == 1
    assert meta["doc"]["screeners"]["sp500_v21"]["vcp_threshold"] == 75.0


def test_emit_records_a_degraded_run():
    from kistrader.entry.screen_contract import read_regime
    d, csv_path, rp = _regime_env()
    emit_candidates(stage3_results=[("AAPL", "Apple", rep(score=91))],
                    passed_stocks=[s1("AAPL", 95)],
                    stage2_passed=[("AAPL", "Apple", 72.5)],
                    out_path=csv_path, vcp_threshold=70.0,
                    session_date="2026-08-14", universe=UNIVERSE,
                    source="sp500_v21 DEGRADED@70", benchmark="^GSPC", regime_ma=20,
                    benchmark_close=5432.10, benchmark_ma=5400.00,
                    benchmark_bar_date="2026-08-13", log=lambda m: None)
    _c, _m, meta = read_regime(rp, "2026-08-14")
    assert not meta["usable"] and "emit-threshold" in meta["reason"], meta["reason"]


def test_emit_without_regime_values_writes_nothing():
    """Phase 3a is inert: a screener that has not been taught the gate yet must
    not produce a sidecar. Its absence is what makes the trader fail closed."""
    d, csv_path, rp = _regime_env()
    emit_candidates(stage3_results=[("AAPL", "Apple", rep(score=91))],
                    passed_stocks=[s1("AAPL", 95)],
                    stage2_passed=[("AAPL", "Apple", 72.5)],
                    out_path=csv_path, vcp_threshold=75.0,
                    session_date="2026-08-14", universe=UNIVERSE,
                    log=lambda m: None)
    assert os.path.exists(csv_path), "the CSV must still be written"
    assert not os.path.exists(rp), "no regime values passed -> no sidecar"


'''


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("usage: python patch_phase3a.py <repo-root>")
    sys.exit(main(sys.argv[1]))
