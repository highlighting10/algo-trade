#!/usr/bin/env python3
"""
I5 -- per-held-position close observation log.  TRADES NOTHING.
================================================================

`PLAN_20260828` sec.4 Day 1:

    I4 -> I5   extend DailyCloseEMAProvider to OHLCV, then log per held position
               per close: close-vs-pivot (from the WATCH event, accepting
               finding #3's blind spot), distribution score, churning score, and
               the eventual trade outcome.  **Trades nothing.**  Weeks of
               sessions before it is worth reading.

WHY THIS EXISTS AND WHAT IT IS FOR

68% of trades (154/225) exit on `STOP_HIT` -- a level fixed at entry, with no
deterioration signal.  S3 tested cutting a failed breakout and it failed 0/16
cells with monotone harm, which makes the counter-prior dispositive:
`RESULT_20260828_S3_failed_breakout` sec.5 records that the way to earn a
deterioration exit is now *"the instrumentation route (I4 -> I5: log why the 68%
die, trade nothing), not another exit sweep."*

This is that instrument.  It answers nothing on its own.  It accumulates the
rows that a later analysis can ask: did the names that eventually stopped out
look different, at the close, from the ones that ran?

DESIGN RULES, all three load-bearing

  1. **It cannot affect trading.**  Nothing in the exit path reads it, every
     public method swallows its own exceptions, and the caller in `run_loop`
     wraps it again.  A broken log is a missing row, never a missed exit.
  2. **The column set never varies.**  Every row carries every column; a value
     that could not be computed is blank, not absent.  A log whose shape drifts
     across weeks cannot be read as one table, and weeks is the unit here.
  3. **The outcome is NOT written at close time.**  You do not know it yet.
     `order_key` is the join key; the outcome comes from the event store when
     the analysis runs.  Writing a guess would poison the only question the log
     exists to answer.

THE PIVOT, AND ITS KNOWN BLIND SPOT

`close_vs_pivot_pct` needs the pivot, which lives only in the
`WATCH_ARMED:pivot=...` event under `{order_key}:WATCH`.  PLAN finding #3: on
the crash re-arm path `arm_batch` calls `_arm_one` directly and writes **zero**
watch events, so the pivot is unrecoverable for those positions.  The plan says
to accept that.  This module does: `pivot_lookup` returns None, the two pivot
columns are blank, and the row is still written.  A blank pivot column is a
recorded gap; a skipped row is a silent one.

USE

    from kistrader.entry.close_log import CloseLog, make_event_store_pivot_lookup
    log = CloseLog(provider, pivot_lookup=make_event_store_pivot_lookup(store))
    loop = RunLoop(..., close_log=log)

`provider` must be a `DailyCloseEMAProvider` built WITH `fetch_daily_bars=`
(patch Z / I4).  Without it the OHLCV columns are blank and the log degrades to
close + ema, which is still a usable series.

SELF-TEST

    python -m kistrader.entry.close_log
"""
from __future__ import annotations

import csv
import os
from typing import Callable, Optional

from kistrader.core.minervini_exit_rules import OBSERVATION_FIELDS, observe

# Stable from day one.  Append only at the END, and never reorder: a reader
# that has been accumulating for weeks joins on position, not on hope.
#
# PHASE E stage 0 appended OBSERVATION_FIELDS -- the named Minervini sell
# signals -- at the END, which is the one change this tuple permits.  They are
# RECORDED, never acted on; see kistrader/core/minervini_exit_rules.py.  A file
# already written under the old column set is rotated aside once rather than
# continued ragged; see `_rotate_if_header_changed`.
COLUMNS = (
    "session_date", "ticker", "order_key", "state", "days_held",
    "entry_price", "stop_loss_price", "shares", "initial_risk_per_share",
    "close", "ema", "close_vs_ema_pct",
    "pivot", "close_vs_pivot_pct", "r_multiple",
    "volume", "avg_volume", "volume_ratio", "range_pct", "close_location",
) + OBSERVATION_FIELDS

DEFAULT_PATH = os.path.join("runs", "close_observations.csv")


def make_event_store_pivot_lookup(db) -> Callable[[str], Optional[float]]:
    """order_key -> pivot, read from `WATCH_ARMED:pivot=...` under
    `{order_key}:WATCH` (see EntryManager._log_watch / _parse_watch_meta).

    Returns None for anything it cannot answer, including PLAN finding #3's
    crash re-arm path, which writes no watch event at all."""
    def _lookup(order_key: str) -> Optional[float]:
        if not order_key:
            return None
        try:
            row = db.conn.execute(
                "SELECT event_type FROM position_events WHERE order_key=? AND "
                "event_type LIKE 'WATCH_ARMED%' ORDER BY id DESC LIMIT 1",
                ("%s:WATCH" % order_key,)).fetchone()
        except Exception:
            return None
        if not row or not row[0] or ":" not in row[0]:
            return None
        for part in row[0].split(":", 1)[1].split(","):
            if "=" not in part:
                continue
            k, v = part.split("=", 1)
            if k.strip() == "pivot":
                try:
                    return float(v.strip())
                except ValueError:
                    return None
        return None
    return _lookup


class CloseLog:
    """One CSV row per held position per close.  Read-only with respect to
    trading; every method fails soft."""

    def __init__(self, provider, path: str = DEFAULT_PATH,
                 pivot_lookup: Optional[Callable[[str], Optional[float]]] = None,
                 alert: Optional[Callable[[str], None]] = None,
                 avg_window: int = 50):
        self.provider = provider
        self.path = path
        self.pivot_lookup = pivot_lookup or (lambda _k: None)
        self.alert = alert or (lambda m: None)
        self.avg_window = avg_window
        self._header_done = False

    # -- pure: build the row, touch no disk -------------------------------
    def row(self, pos, session_date: str) -> dict:
        """Never raises.  A field that cannot be computed is None, and None is
        written as an empty cell."""
        def safe(fn, *a):
            try:
                return fn(*a)
            except Exception:
                return None

        t = getattr(pos, "ticker", None)
        key = getattr(pos, "order_key", "") or ""
        close = safe(self.provider.close, t) if t else None
        ema = safe(self.provider.ema, t) if t else None
        pivot = safe(self.pivot_lookup, key)
        entry = getattr(pos, "entry_price", None)
        risk = getattr(pos, "initial_risk_per_share", None)

        def pct(a, b):
            """(a - b) / b, or None."""
            try:
                if a is None or b is None or float(b) == 0.0:
                    return None
                return (float(a) - float(b)) / float(b)
            except (TypeError, ValueError):
                return None

        state = getattr(pos, "state", None)
        r = None
        if close is not None and hasattr(pos, "r_multiple"):
            r = safe(pos.r_multiple, float(close))

        # OHLCV.  Blank when the provider was built without a bars fetch, which
        # is the documented I4 degrade rather than an error.
        ohlcv = {}
        for name in ("volume", "range_pct", "close_location"):
            fn = getattr(self.provider, name, None)
            ohlcv[name] = safe(fn, t) if (fn and t) else None
        avg_fn = getattr(self.provider, "avg_volume", None)
        ratio_fn = getattr(self.provider, "volume_ratio", None)
        ohlcv["avg_volume"] = safe(avg_fn, t, self.avg_window) if (avg_fn and t) else None
        ohlcv["volume_ratio"] = safe(ratio_fn, t, self.avg_window) if (ratio_fn and t) else None

        # PHASE E stage 0 -- the named Minervini sell signals, RECORDED ONLY.
        # `observe` never raises and answers None for anything it cannot see, so
        # a provider without a bars fetch simply leaves these columns blank, the
        # same documented I4 degrade as the OHLCV block above.
        bars_fn = getattr(self.provider, "bars", None)
        signals = observe(safe(bars_fn, t) if (bars_fn and t) else None,
                          getattr(pos, "days_held", 0) or 0,
                          pivot=pivot, ema=ema,
                          avg_volume_50=ohlcv["avg_volume"])

        row = {
            "session_date": session_date,
            "ticker": t,
            "order_key": key,
            "state": getattr(state, "value", state),
            "days_held": getattr(pos, "days_held", None),
            "entry_price": entry,
            "stop_loss_price": getattr(pos, "stop_loss_price", None),
            "shares": getattr(pos, "shares", None),
            "initial_risk_per_share": risk,
            "close": close,
            "ema": ema,
            "close_vs_ema_pct": pct(close, ema),
            "pivot": pivot,
            "close_vs_pivot_pct": pct(close, pivot),
            "r_multiple": r,
            "volume": ohlcv["volume"],
            "avg_volume": ohlcv["avg_volume"],
            "volume_ratio": ohlcv["volume_ratio"],
            "range_pct": ohlcv["range_pct"],
            "close_location": ohlcv["close_location"],
        }
        row.update({k: signals.get(k) for k in OBSERVATION_FIELDS})
        return row

    # -- effectful: append one row ----------------------------------------
    def _rotate_if_header_changed(self) -> None:
        """A log written under an older COLUMNS is moved aside, ONCE.

        `csv.DictWriter` writes values in `fieldnames` order and never revisits
        a header that is already on disk, so appending new columns to an
        existing file silently produces a ragged CSV: 20-column header, 30-column
        rows, and no error anywhere.  The rows are the whole point of this file,
        so the old ones are preserved under `<path>.pre_<n>cols` and a fresh file
        with the new header is started beside them."""
        if not os.path.exists(self.path) or os.path.getsize(self.path) == 0:
            return
        with open(self.path, encoding="utf-8", newline="") as fh:
            head = next(csv.reader(fh), None)
        if head == list(COLUMNS):
            return
        keep = "%s.pre_%dcols" % (self.path, len(head or []))
        n = 1
        while os.path.exists(keep):                # never overwrite an archive
            keep = "%s.pre_%dcols.%d" % (self.path, len(head or []), n)
            n += 1
        os.rename(self.path, keep)
        self.alert("close_log: column set changed; previous log kept at %s" % keep)

    def record(self, pos, session_date: str) -> Optional[dict]:
        """Build and append.  Returns the row, or None if it could not be
        written.  Never raises: the caller is the run loop."""
        try:
            r = self.row(pos, session_date)
        except Exception as ex:
            self.alert("close_log: row build failed: %s" % ex)
            return None
        try:
            d = os.path.dirname(os.path.abspath(self.path))
            if d and not os.path.isdir(d):
                os.makedirs(d, exist_ok=True)
            if not self._header_done:
                self._rotate_if_header_changed()
            need_header = (not self._header_done and
                           (not os.path.exists(self.path) or
                            os.path.getsize(self.path) == 0))
            with open(self.path, "a", encoding="utf-8", newline="") as fh:
                w = csv.DictWriter(fh, fieldnames=list(COLUMNS),
                                   extrasaction="ignore")
                if need_header:
                    w.writeheader()
                w.writerow({k: ("" if r.get(k) is None else r.get(k))
                            for k in COLUMNS})
            self._header_done = True
            return r
        except Exception as ex:
            self.alert("close_log: write failed (%s): %s" % (self.path, ex))
            return None


# --------------------------------------------------------------------------
# self-test -- offline, no broker, no network, writes to a temp dir
# --------------------------------------------------------------------------
def _self_test() -> int:
    import tempfile
    from dataclasses import dataclass

    ok = [0, 0]

    def check(name, cond, detail=""):
        ok[1] += 1
        if cond:
            ok[0] += 1
        print("  [%s] %s   %s" % ("PASS" if cond else "FAIL", name, detail))

    @dataclass
    class P:
        ticker: str = "AAA"
        order_key: str = "AAA:2026-08-31"
        shares: int = 100
        entry_price: float = 100.0
        stop_loss_price: float = 94.0
        initial_risk_per_share: float = 6.0
        days_held: int = 12
        state: str = "FILLED"

        def r_multiple(self, price):
            return (price - self.entry_price) / self.initial_risk_per_share

    def _bar(o, h, l, c, v):
        return {"open": o, "high": h, "low": l, "close": c, "volume": v}

    # Eight quiet sessions then one climax bar: biggest gain, widest range and
    # heaviest volume of the move, all at once.
    CLIMAX_BARS = ([_bar(100, 101, 99, 100, 1_000_000)] * 8 +
                   [_bar(101, 112, 100, 110, 3_000_000)])

    class Prov:
        def close(self, t): return 92.0
        def ema(self, t): return 100.0
        def volume(self, t): return 3_000_000.0
        def avg_volume(self, t, n=50): return 1_000_000.0
        def volume_ratio(self, t, n=50): return 3.0
        def range_pct(self, t): return 0.2174
        def close_location(self, t): return 0.10
        def bars(self, t): return CLIMAX_BARS

    class Blind:                       # provider built WITHOUT a bars fetch
        def close(self, t): return 92.0
        def ema(self, t): return 100.0
        def volume(self, t): return None
        def avg_volume(self, t, n=50): return None
        def volume_ratio(self, t, n=50): return None
        def range_pct(self, t): return None
        def close_location(self, t): return None

    class Boom:                        # every accessor explodes
        def close(self, t): raise RuntimeError("net")
        def ema(self, t): raise RuntimeError("net")
        def volume(self, t): raise RuntimeError("net")
        def avg_volume(self, t, n=50): raise RuntimeError("net")
        def volume_ratio(self, t, n=50): raise RuntimeError("net")
        def range_pct(self, t): raise RuntimeError("net")
        def close_location(self, t): raise RuntimeError("net")

    print("=" * 62)
    print("I5 CLOSE OBSERVATION LOG -- self test")
    print("=" * 62)

    d = tempfile.mkdtemp()
    path = os.path.join(d, "runs", "obs.csv")

    lg = CloseLog(Prov(), path=path, pivot_lookup=lambda k: 99.50)
    r = lg.record(P(), "2026-08-31")
    check("row written", r is not None)
    check("close_vs_ema_pct is negative below the EMA",
          r and abs(r["close_vs_ema_pct"] - (92.0 - 100.0) / 100.0) < 1e-12)
    check("close_vs_pivot_pct uses the WATCH pivot",
          r and abs(r["close_vs_pivot_pct"] - (92.0 - 99.5) / 99.5) < 1e-12)
    check("r_multiple from the position's own method",
          r and abs(r["r_multiple"] - (92.0 - 100.0) / 6.0) < 1e-12)
    check("volume_ratio carried", r and r["volume_ratio"] == 3.0)
    check("close_location carried (0.10 = closed near the low)",
          r and r["close_location"] == 0.10)

    with open(path, encoding="utf-8") as fh:
        rows = list(csv.reader(fh))
    check("header written once, exact column set", rows[0] == list(COLUMNS))
    check("one data row", len(rows) == 2)
    check("every row has every column", len(rows[1]) == len(COLUMNS))

    lg.record(P(), "2026-09-01")
    with open(path, encoding="utf-8") as fh:
        rows = list(csv.reader(fh))
    check("append does not repeat the header", len(rows) == 3 and rows[0][0] == "session_date")

    # blind provider -> OHLCV blank, close/ema still present, row still written
    p2 = os.path.join(d, "blind.csv")
    r2 = CloseLog(Blind(), path=p2).record(P(), "2026-08-31")
    check("no bars fetch: OHLCV blank but the row is still written",
          r2 is not None and r2["volume"] is None and r2["close"] == 92.0)
    check("no pivot lookup: pivot columns blank, row still written",
          r2 is not None and r2["pivot"] is None and r2["close_vs_pivot_pct"] is None)

    # exploding provider -> every value None, still one row, never raises
    p3 = os.path.join(d, "boom.csv")
    r3 = CloseLog(Boom(), path=p3).record(P(), "2026-08-31")
    check("provider raising everywhere: still returns a row, never raises",
          r3 is not None and r3["close"] is None and r3["ticker"] == "AAA")
    with open(p3, encoding="utf-8") as fh:
        check("...and that row is on disk with the full column set",
              len(list(csv.reader(fh))[1]) == len(COLUMNS))

    # unwritable path -> None, no exception.  p2 is a real FILE, so using it as
    # a parent directory is a genuine failure; the first draft of this check
    # pointed at a path that makedirs happily created, and passed for the wrong
    # reason.
    bad = CloseLog(Prov(), path=os.path.join(p2, "nope.csv"))
    check("parent is a file -> None, not an exception", bad.record(P(), "x") is None)

    # the outcome column does not exist, deliberately
    check("no outcome column at close time (join on order_key later)",
          not any("outcome" in c for c in COLUMNS))

    # --- PHASE E stage 0: the sell signals are recorded, and only recorded ---
    check("climax bar records the three strength signals",
          r["climax_gain"] is True and r["climax_volume"] is True
          and r["climax_range"] is True)
    check("and labels the row SELL_INTO_STRENGTH",
          r["sell_verdict"] == "SELL_INTO_STRENGTH")
    check("no bars fetch -> signal columns blank, not False",
          r2["sell_verdict"] is None and r2["climax_gain"] is None)
    check("signal columns are appended at the END of COLUMNS",
          COLUMNS[-len(OBSERVATION_FIELDS):] == OBSERVATION_FIELDS)

    # an existing log written under the OLD column set is moved aside, not
    # continued ragged
    old = os.path.join(d, "old.csv")
    with open(old, "w", encoding="utf-8", newline="") as fh:
        wr = csv.writer(fh)
        wr.writerow(COLUMNS[:20])          # the pre-Phase-E header
        wr.writerow(["x"] * 20)
    lg2 = CloseLog(Prov(), path=old, alert=lambda m: None)
    lg2.record(P(), "2026-09-08")
    with open(old, encoding="utf-8") as fh:
        rows_new = list(csv.reader(fh))
    check("old-header log rotated aside; new file carries the new header",
          rows_new[0] == list(COLUMNS) and len(rows_new) == 2)
    check("...and the old rows are preserved, not deleted",
          os.path.exists(old + ".pre_20cols"))
    lg2.record(P(), "2026-09-09")
    with open(old, encoding="utf-8") as fh:
        check("rotation happens once, then it is a normal append",
              len(list(csv.reader(fh))) == 3)

    # pivot lookup that raises is swallowed
    r4 = CloseLog(Prov(), path=os.path.join(d, "pv.csv"),
                  pivot_lookup=lambda k: (_ for _ in ()).throw(RuntimeError("db"))
                  ).record(P(), "2026-08-31")
    check("pivot lookup raising -> blank pivot, row still written",
          r4 is not None and r4["pivot"] is None)

    print("=" * 62)
    print("PASSED %d / %d" % (ok[0], ok[1]))
    print("=" * 62)
    return 0 if ok[0] == ok[1] else 1


if __name__ == "__main__":
    raise SystemExit(_self_test())
