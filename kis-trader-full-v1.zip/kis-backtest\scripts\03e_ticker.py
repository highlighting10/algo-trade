"""
03e_ticker.py -- chase ONE ticker that reproduces at no as-of date.

BRKR and LFST survived every sweep: date, window length, window mode. Everything
that explains the other eight fails on these two, so the cause is different and
must be found, not absorbed into a wider tolerance.

BRKR is the sharper case: production graded it Tradable at 72.00, we get
"Reject (No Base)" with a competing_earlier_base warning. That is not a small
numeric drift -- the detector is finding a structurally different picture, which
usually means the BARS differ, not the maths.

This dumps everything needed to tell those apart:
  * bar hygiene: gaps, duplicates, zero/NaN volume, suspicious jumps
  * the report internals at several as-of dates
  * the raw tail so you can eyeball it against the box

THE DECISIVE TEST IS EXTERNAL and this script cannot do it for you: your box
wrote candidates.csv (and screener logs) on 2026-08-05 carrying Latest_Close per
name. Compare that number against `stored close` printed below for the same date.
If they differ, the bars differ, and no window or date tuning will ever fix it.

Usage:
    python scripts/03e_ticker.py --ticker BRKR
    python scripts/03e_ticker.py --ticker LFST --asof 2026-08-03
"""
import pathlib as _pl
import sys as _sys
_sys.path.insert(0, str(_pl.Path(__file__).resolve().parent.parent))

import argparse
import pathlib

import pandas as pd

import vcp_engine as ve
from signals import VCP_BENCHMARK

EXPECTED = {"BRKR": 72.00, "LFST": 57.07, "NTAP": 73.55, "UNH": 67.58,
            "NUE": 59.83, "STT": 58.64, "HPE": 58.25, "PTGX": 62.54,
            "IRDM": 58.66, "OKTA": 58.29}


def load(t):
    p = pathlib.Path(f"data/bars/{t}.parquet")
    if not p.exists():
        return None
    df = pd.read_parquet(p).sort_index()
    if getattr(df.index, "tz", None) is not None:
        df.index = df.index.tz_localize(None)
    return df


def hygiene(df):
    print(f"  rows={len(df)}  {df.index[0].date()} .. {df.index[-1].date()}")
    dupes = int(df.index.duplicated().sum())
    print(f"  duplicate index entries : {dupes}" + ("   <-- PROBLEM" if dupes else ""))
    nan_rows = int(df[["Open", "High", "Low", "Close"]].isna().any(axis=1).sum())
    print(f"  rows with NaN OHLC      : {nan_rows}" + ("   <-- PROBLEM" if nan_rows else ""))
    if "Volume" in df:
        zv = int((df["Volume"].fillna(0) <= 0).sum())
        print(f"  zero/NaN volume bars    : {zv}" + ("   <-- suspicious" if zv > 5 else ""))
    bad_hl = int((df["High"] < df["Low"]).sum())
    print(f"  High < Low              : {bad_hl}" + ("   <-- PROBLEM" if bad_hl else ""))
    oob = int(((df["Close"] > df["High"] + 1e-9) | (df["Close"] < df["Low"] - 1e-9)).sum())
    print(f"  Close outside [Low,High]: {oob}" + ("   <-- PROBLEM" if oob else ""))
    # calendar gaps longer than a long weekend
    gaps = df.index.to_series().diff().dt.days.fillna(0)
    big = gaps[gaps > 5]
    print(f"  calendar gaps > 5 days  : {len(big)}")
    for d, g in list(big.items())[:6]:
        print(f"      {d.date()}  gap {int(g)} days")
    # unadjusted-looking jumps: a split that was NOT back-adjusted shows here
    ret = df["Close"].pct_change().abs()
    jumps = ret[ret > 0.35]
    print(f"  daily |move| > 35%      : {len(jumps)}"
          + ("   <-- possible unadjusted split" if len(jumps) else ""))
    for d, v in list(jumps.items())[:6]:
        print(f"      {d.date()}  {v*100:.1f}%")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ticker", required=True)
    ap.add_argument("--asof", default="2026-08-03")
    args = ap.parse_args()
    t = args.ticker.upper()

    df = load(t)
    if df is None:
        raise SystemExit(f"[ticker] no bars for {t}")
    idx_df = load(VCP_BENCHMARK)
    exp = EXPECTED.get(t)

    print("=" * 76)
    print(f"BAR HYGIENE  {t}")
    print("=" * 76)
    hygiene(df)

    print("\n" + "=" * 76)
    print(f"REPORT ACROSS AS-OF DATES  (expected {exp})")
    print("=" * 76)
    anchor = pd.Timestamp(args.asof)
    cal = df.index
    pos = cal.searchsorted(anchor)
    for k in range(-4, 4):
        j = pos + k
        if not (0 <= j < len(cal)):
            continue
        T = cal[j]
        w = df.loc[:T]
        w = w.loc[w.index >= T - pd.DateOffset(years=2)]
        i = idx_df.loc[:T]
        i = i.loc[i.index >= T - pd.DateOffset(years=2)]
        try:
            rep = ve.VCPAnalyzerV4(w, index_df=i, config=ve.VCPConfig()).generate_report()
        except Exception as e:
            print(f"  {T.date()}  EXCEPTION {type(e).__name__}: {e}")
            continue
        if not rep:
            print(f"  {T.date()}  no report")
            continue
        pat = rep.get("Extracted_Pattern") or {}
        sc = rep.get("Score")
        d = f"{sc - exp:+.2f}" if isinstance(exp, float) and sc is not None else "n/a"
        print(f"  {T.date()}  score={sc:>6} d={d:>7} grade={rep.get('Grade')} "
              f"waves={pat.get('Wave_Count')} base_start={pat.get('Base_Start_Bar')} "
              f"rows={len(w)}")
        print(f"              warnings={rep.get('Base_Warnings')} "
              f"conf={rep.get('Base_Confidence')} pivot={pat.get('Pivot')}")

    print("\n" + "=" * 76)
    print("STORED BARS AROUND THE AS-OF DATE  (compare against the box)")
    print("=" * 76)
    lo = max(0, pos - 7)
    tail = df.iloc[lo:pos + 3]
    print(tail.to_string(float_format=lambda v: f"{v:,.4f}"))

    print("\n" + "=" * 76)
    print("THE TEST THAT SETTLES IT")
    print("=" * 76)
    print("  Open the box's candidates.csv / screener log for 2026-08-05 and find")
    print(f"  {t}'s Latest_Close. Compare it against the stored close above for the")
    print("  same session.")
    print("    same  -> bars agree; the divergence is in the engine's inputs")
    print("             elsewhere (config, benchmark series, or period handling)")
    print("    differ-> the bars differ. yfinance returned different numbers to the")
    print("             box than it returns to you now. No tuning fixes that, and")
    print("             the gate must be replaced with rank correlation + bounded")
    print("             median delta rather than exact reproduction.")


if __name__ == "__main__":
    main()
