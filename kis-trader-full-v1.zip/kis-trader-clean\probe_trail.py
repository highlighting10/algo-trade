#!/usr/bin/env python3
"""
probe_trail.py -- dump the full event trail for one order_key or ticker.

Answers "how did this position get the fields it has" from the log itself,
instead of inferring it. Read-only against a COPY of the event store.

    python probe_trail.py probe.db HPE
    python probe_trail.py probe.db HPE:2026-08-20
"""
from __future__ import annotations

import json
import os
import sqlite3
import sys

LIVE_NAME = "kis_engine_state.db"

# The fields that decide a close's R, plus the ones that say how it was born.
WATCH = ("state", "shares", "entry_price", "stop_loss_price",
         "initial_risk_per_share", "partial_done", "partial_filled",
         "exit_reason", "days_held")


def main(argv):
    if len(argv) < 3:
        raise SystemExit("usage: probe_trail.py <db> <ticker-or-order_key>")
    db, want = argv[1], argv[2]
    if not os.path.isfile(db):
        raise SystemExit(f"no such database: {db}")
    if os.path.basename(db) == LIVE_NAME:
        raise SystemExit(f"REFUSING: {db} is the live database name. Use a copy.")

    con = sqlite3.connect(f"file:{db}?mode=ro", uri=True)
    rows = con.execute(
        "SELECT id, ts, ticker, order_key, event_type, state_to, shares, "
        "price, broker_order_id, payload FROM position_events "
        "WHERE ticker = ? OR order_key = ? OR order_key LIKE ? "
        "ORDER BY id ASC", (want, want, want + ":%")).fetchall()
    if not rows:
        raise SystemExit(f"no events for {want!r}")

    print("=" * 100)
    print(f"EVENT TRAIL -- {want}   ({len(rows)} event(s), oldest first)")
    print("=" * 100)
    prev = {}
    for rid, ts, tkr, key, et, state, shares, price, boid, payload in rows:
        try:
            d = json.loads(payload) if payload else {}
        except Exception:                          # noqa: BLE001
            d = {}
        print(f"\n  #{rid}  {str(ts)[:19]}  {et}")
        print(f"      key={key}  state_to={state}  shares={shares}  "
              f"price={_n(price)}  broker_order_id={boid}")
        if not d:
            print("      (no payload)")
            prev = {}
            continue
        # Only print what CHANGED, so the one event that set a field is obvious.
        changed = [k for k in WATCH if k in d and d.get(k) != prev.get(k, object())]
        if changed:
            print("      " + "  ".join(f"{k}={_v(d[k])}" for k in changed))
        prev = d

    # The arithmetic behind initial_risk_per_share, spelled out.
    print("\n" + "-" * 100)
    for rid, ts, tkr, key, et, state, shares, price, boid, payload in rows:
        try:
            d = json.loads(payload) if payload else {}
        except Exception:                          # noqa: BLE001
            continue
        r = d.get("initial_risk_per_share")
        if r is None:
            continue
        try:
            rf = float(r)
        except (TypeError, ValueError):
            continue
        if rf <= 0:
            print(f"  #{rid} {et}: initial_risk_per_share={rf:+.4f} "
                  f"(entry={_n(d.get('entry_price'))}, "
                  f"stop_loss_price={_n(d.get('stop_loss_price'))})")
            print("      risk/share is frozen at fill as entry - INITIAL stop.")
            print("      <= 0 means the stop was AT or ABOVE the entry price.")
            print("      NOTE: stop_loss_price here is the CURRENT stop, which")
            print("      moves to breakeven after a confirmed partial -- it is")
            print("      not necessarily the initial stop this was frozen from.")
            break
    print("=" * 100)
    con.close()
    return 0


def _n(v):
    try:
        return "%.4f" % float(v)
    except (TypeError, ValueError):
        return str(v)


def _v(v):
    return "%.4f" % v if isinstance(v, float) else repr(v)


if __name__ == "__main__":
    sys.exit(main(sys.argv))
