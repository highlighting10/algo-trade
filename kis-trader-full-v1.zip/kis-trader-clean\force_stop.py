﻿"""force_stop.py  —  ONE-SHOT test helper (mock only).
Bumps the persisted stop of a managed position to just above the live price so the
next tick trips STOP_HIT and drives the full exit lifecycle on the mock.
Only the trigger is engineered; the SELL is banded around live price (marketable).
"""
import sys
from kistrader.config import Config, load_dotenv
from kistrader.core.engine_v2 import EventStore
from kistrader.entry.entry_manager import KISBrokerWithEntry

TICKER = (sys.argv[1] if len(sys.argv) > 1 else "NVDA").upper()
MARGIN = 1.01

def main() -> int:
    load_dotenv()
    c = Config.from_env()
    db = EventStore(c.db_path)
    open_positions = db.load_open_snapshots()
    pos = next((p for p in open_positions if p.ticker == TICKER), None)
    if pos is None:
        live = [p.ticker for p in open_positions]
        print(f"[force_stop] no live/managed {TICKER} snapshot to bump. managed: {live or 'none'}")
        return 2
    broker = KISBrokerWithEntry(c.app_key, c.app_secret, c.cano, is_mock=True)
    q = broker.get_quote(TICKER, pos.exchange)
    last = float(q.get("last") or 0)
    bid = float(q.get("bid") or 0)
    if last <= 0:
        print(f"[force_stop] refusing to bump: empty/zero quote for {TICKER} ({q}). Re-run.")
        return 3
    old_stop = pos.stop_loss_price
    new_stop = round(last * MARGIN, 2)
    pos.stop_loss_price = new_stop
    db.log(pos, f"FORCE_STOP_FOR_TEST:spot={last},bid={bid},old={old_stop},new={new_stop}", last)
    print(f"[force_stop] {TICKER}: spot={last}  bid={bid}")
    print(f"[force_stop] stop {old_stop} -> {new_stop} (persisted as FORCE_STOP_FOR_TEST)")
    print(f"[force_stop] shares(snapshot)={pos.shares}  state={pos.state.value}")
    print("[force_stop] DONE. Wait >=65s (KIS token limit) before the next kistrader command.")
    print("[force_stop] Then restart the loop the way it was started -- on the box: sudo systemctl start kistrader")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
s