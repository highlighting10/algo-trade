#!/usr/bin/env python3
"""
Minervini sell-signal OBSERVER (Phase E, stage 0).  TRADES NOTHING.
===================================================================

WHAT THIS IS, AND WHAT IT DELIBERATELY IS NOT

Minervini's selling doctrine has two families, and he names them that way:

    SELL INTO STRENGTH   the advance itself says the move is ending --
                         a climax run, the largest one-day gain of the move,
                         the widest daily range of the move, the heaviest
                         volume of the move, an exhaustion gap, price stretched
                         far above its own moving average.

    SELL INTO WEAKNESS   the stock breaks down -- a violation of the trailing
                         moving average on heavy volume, the worst down day of
                         the move, the heaviest down volume of the move, a
                         breakout that closes back under its pivot.

This module computes those signals and RECORDS them.  It executes nothing, it
returns no order, and no exit path imports it.  That restraint is not caution;
it is the project's own pre-registered decision:

    RESULT_20260828_S3_failed_breakout sec.5 -- a structural pre-stop exit was
    measured at 0 of 16 cells with a MONOTONE dose-response in the harmful
    direction (+0.380 R -> -0.069 R as the trigger got easier to fire).  Its
    closing sentence: the way to earn a deterioration exit is *"the
    instrumentation route (I4 -> I5: log why the 68% die, trade nothing), not
    another exit sweep."*

This is that instrument, extended from I5's raw quantities (volume ratio, range,
close location) to the NAMED signals the doctrine actually uses.  It exists so a
later sweep can ask a real question -- did the names that stopped out fire these
signals first, and how many sessions early? -- instead of shipping thresholds
nobody measured.

WHY THE SIGNALS ARE MOVE-RELATIVE, NOT ABSOLUTE

Minervini's climax rules are comparatives: the largest one-day gain SINCE THE
MOVE BEGAN, the heaviest volume SINCE THE MOVE BEGAN.  An absolute "+8% in a
day" is a different statistic that happens to fire on some of the same charts.
Every extreme below is therefore computed against the position's own bars since
the fill, not against a constant.  The only constants here are the four that
have no comparative form (how heavy is "heavy" volume, how far is "extended",
how many closes make a failure persistent, how long a move must be before
"largest of the move" means anything), and each is named and defended.

DATA CONTRACT

`observe()` takes daily bars as `DailyCloseEMAProvider` already normalises them
(dicts with open/high/low/close/volume, oldest first, any field possibly None).
Every signal is TRI-STATE, exactly as the broker layer is: True, False, or None
when the inputs to answer it were not available.  A None is written as a blank
cell, never as a False -- "we did not look" and "we looked and it did not fire"
are different rows, and the analysis this feeds must tell them apart.

Nothing here raises.  The caller that already swallows (close_log) gets a second
boundary for free, the same way run_loop wraps close_log.

SELF-TEST

    python -m kistrader.core.minervini_exit_rules
"""
from __future__ import annotations

from typing import Optional, Sequence

# --- the constants that have no comparative form --------------------------
# Each fires only IN ADDITION to a move-relative extreme, so it narrows an
# already-selective signal; none of them can fire on its own.

# A day can be the heaviest of a five-day-old position and still be a quiet day.
# Minervini's climax volume is heavy in absolute terms too.
CLIMAX_VOLUME_MULTIPLE = 2.0

# A moving-average violation only counts when volume confirms it.  This is the
# same multiple the entry half already uses for breakout volume
# (EntryManager.breakout_volume_multiple = 1.50), kept identical so that one
# number keeps one meaning across the system.
MA_VIOLATION_VOLUME_MULTIPLE = 1.50

# "Too far extended from the moving average."  Measured FROM THE EMA, which is
# the form the doctrine states.  The draft measured extension from the recent
# high, where price cannot exceed the high that contains it, so that branch was
# unreachable.
EXTENSION_FROM_EMA_PCT = 0.20

# S3 sec.3, the one asymmetry it told us to keep: fb_two_closes (170 trades,
# +0.101 R) beat fb_buf_1 (166 trades, +0.010 R) at the same firing rate --
# "persistence is a better filter than depth."  So a failure is two closes under
# the pivot, not one deeper close.
FAILED_BREAKOUT_CLOSES = 2

# "Largest since the move began" is not a statement about a two-bar move.
MIN_BARS_FOR_MOVE_EXTREME = 5

SELL_INTO_STRENGTH = ("climax_gain", "climax_volume", "climax_range",
                      "exhaustion_gap", "extended_from_ema")
SELL_INTO_WEAKNESS = ("failed_breakout", "ma_violation_on_volume",
                      "worst_down_day", "heaviest_down_volume")
SIGNALS = SELL_INTO_STRENGTH + SELL_INTO_WEAKNESS

VERDICTS = ("SELL_INTO_WEAKNESS", "SELL_INTO_STRENGTH", "HOLD")

# Column order for a log.  Append at the END if this ever grows; a reader that
# has been accumulating for weeks joins on position.
OBSERVATION_FIELDS = SIGNALS + ("sell_verdict",)

_BLANK = {k: None for k in OBSERVATION_FIELDS}


def _num(x) -> Optional[float]:
    """A usable float, or None.  NaN is not a value (NaN != NaN)."""
    try:
        v = float(x)
    except (TypeError, ValueError):
        return None
    return None if v != v else v


def observe(bars: Optional[Sequence], days_held: int = 0,
            pivot: Optional[float] = None, ema: Optional[float] = None,
            avg_volume_50: Optional[float] = None) -> dict:
    """Every sell signal for one position at one close.

    `bars`          daily bars oldest -> newest, the latest COMPLETED session
                    last, as DailyCloseEMAProvider.bars() returns them.
    `days_held`     sessions since the fill (Position.days_held).  The move's
                    window is the last days_held + 1 bars, plus one more so the
                    first held bar has a prior close to compare against.
                    KNOWN CEILING: day rolls come from the session clock, not
                    from the bar series, so a missing bar (a halt, a data gap)
                    shifts the window by one session.  That can only widen or
                    narrow the comparison set slightly; it cannot fabricate a
                    signal, because every extreme is still measured against
                    bars the position actually lived through.
    Returns a dict with every key in OBSERVATION_FIELDS, values True/False/None.
    """
    try:
        return _observe(bars, days_held, pivot, ema, avg_volume_50)
    except Exception:                       # an instrument must never raise
        return dict(_BLANK)


def _observe(bars, days_held, pivot, ema, avg_volume_50) -> dict:
    out = dict(_BLANK)
    if not bars:
        return out

    n = int(days_held or 0) + 1
    window = list(bars[-(n + 1):])          # +1 for the prior close
    if len(window) < 2:
        return out
    held = window[1:]                       # the fill bar onward
    latest = held[-1]

    closes = [_num(b.get("close")) for b in window]
    # gains[k] belongs to held[k]; None where either close is unusable, which is
    # also how a zero prior close is handled -- there is no division by zero.
    gains = [None if (p is None or not p or c is None) else (c - p) / p
             for p, c in zip(closes, closes[1:])]
    latest_gain = gains[-1]
    # "Largest SINCE the move began" compares the latest bar against the bars
    # BEFORE it, so every extreme below is a strict >.  Comparing against a set
    # that contains the latest bar itself makes a flat series -- every bar the
    # same width, the same volume -- report a climax on a tie.
    prior_gains = [g for g in gains[:-1] if g is not None]
    enough = len(held) >= MIN_BARS_FOR_MOVE_EXTREME

    vols = [_num(b.get("volume")) for b in held]
    have_vols = all(v is not None for v in vols)
    avg_vol = _num(avg_volume_50)
    ema_v = _num(ema)
    pivot_v = _num(pivot)
    close_v = _num(latest.get("close"))

    # ---- sell into strength ---------------------------------------------
    if enough and latest_gain is not None and prior_gains:
        out["climax_gain"] = latest_gain > 0 and latest_gain > max(prior_gains)

    if enough and have_vols and avg_vol and len(vols) >= 2:
        out["climax_volume"] = (vols[-1] > max(vols[:-1]) and
                                vols[-1] >= CLIMAX_VOLUME_MULTIPLE * avg_vol)

    ranges = []
    for b in held:
        h, l, c = _num(b.get("high")), _num(b.get("low")), _num(b.get("close"))
        ranges.append(None if (h is None or l is None or not c) else (h - l) / c)
    if enough and len(ranges) >= 2 and all(r is not None for r in ranges):
        out["climax_range"] = ranges[-1] > max(ranges[:-1])

    prior = held[-2] if len(held) >= 2 else window[-2]
    prior_high, latest_open = _num(prior.get("high")), _num(latest.get("open"))
    if prior_high is not None and latest_open is not None:
        out["exhaustion_gap"] = latest_open > prior_high

    if ema_v and close_v is not None:
        out["extended_from_ema"] = (close_v - ema_v) / ema_v >= EXTENSION_FROM_EMA_PCT

    # ---- sell into weakness ---------------------------------------------
    if pivot_v and pivot_v > 0:
        tail = [_num(b.get("close")) for b in held[-FAILED_BREAKOUT_CLOSES:]]
        if len(tail) == FAILED_BREAKOUT_CLOSES and all(c is not None for c in tail):
            out["failed_breakout"] = all(c < pivot_v for c in tail)

    if ema_v and close_v is not None and avg_vol and vols[-1] is not None:
        out["ma_violation_on_volume"] = (
            close_v < ema_v and vols[-1] >= MA_VIOLATION_VOLUME_MULTIPLE * avg_vol)

    if enough and latest_gain is not None and prior_gains:
        out["worst_down_day"] = latest_gain < 0 and latest_gain < min(prior_gains)

    if enough and have_vols and latest_gain is not None:
        prior_down_vols = [v for v, g in zip(vols[:-1], gains[:-1])
                           if g is not None and g < 0]
        if prior_down_vols:
            out["heaviest_down_volume"] = (latest_gain < 0 and
                                           vols[-1] > max(prior_down_vols))

    out["sell_verdict"] = verdict(out)
    return out


def verdict(signals: dict) -> Optional[str]:
    """One label for a row.  Weakness outranks strength: the doctrine treats a
    violation as mandatory and a climax as discretionary.  None when nothing
    could be evaluated at all -- that is a data gap, not a healthy position."""
    if any(signals.get(k) for k in SELL_INTO_WEAKNESS):
        return "SELL_INTO_WEAKNESS"
    if any(signals.get(k) for k in SELL_INTO_STRENGTH):
        return "SELL_INTO_STRENGTH"
    if all(signals.get(k) is None for k in SIGNALS):
        return None
    return "HOLD"


# --------------------------------------------------------------------------
# self-test -- pure, offline, no provider, no broker, no network
# --------------------------------------------------------------------------
def _self_test() -> int:
    ok = [0, 0]

    def check(name, cond, detail=""):
        ok[1] += 1
        if cond:
            ok[0] += 1
        print("  [%s] %s   %s" % ("PASS" if cond else "FAIL", name, detail))

    def bar(o, h, l, c, v):
        return {"open": o, "high": h, "low": l, "close": c, "volume": v}

    def series(last):
        """A quiet seven-bar base plus one bar under test.  days_held=7 makes
        the observation window the whole list."""
        base = [bar(100, 101, 99, 100, 1_000_000),
                bar(100, 101, 99, 101, 1_000_000),
                bar(101, 102, 100, 100, 1_000_000),
                bar(100, 101, 99, 101, 1_000_000),
                bar(101, 102, 100, 100, 1_000_000),
                bar(100, 101, 99, 100, 1_000_000),
                bar(100, 101, 99, 100, 1_000_000)]
        return base + [last]

    print("=" * 62)
    print("MINERVINI SELL-SIGNAL OBSERVER -- self test")
    print("=" * 62)

    # --- sell into strength ---
    r = observe(series(bar(101, 112, 100, 110, 3_000_000)), days_held=7,
                avg_volume_50=1_000_000)
    check("climax gain: biggest up day of the move fires", r["climax_gain"] is True)
    check("climax volume: heaviest of the move AND >= 2x the 50-day average",
          r["climax_volume"] is True)
    check("climax range: widest bar of the move fires", r["climax_range"] is True)
    check("verdict is SELL_INTO_STRENGTH", r["sell_verdict"] == "SELL_INTO_STRENGTH")

    r = observe(series(bar(101, 112, 100, 110, 1_200_000)), days_held=7,
                avg_volume_50=1_000_000)
    check("heaviest of the move but only 1.2x average -> NOT climax volume",
          r["climax_volume"] is False)

    r = observe(series(bar(103, 104, 102, 103, 1_000_000)), days_held=7)
    check("gap: open above the prior high fires", r["exhaustion_gap"] is True)
    r = observe(series(bar(100, 104, 99, 103, 1_000_000)), days_held=7)
    check("no gap: open at/below the prior high does not", r["exhaustion_gap"] is False)

    r = observe(series(bar(100, 101, 99, 121, 1_000_000)), days_held=7, ema=100.0)
    check("extension measured FROM THE EMA: +21% fires", r["extended_from_ema"] is True)
    r = observe(series(bar(100, 101, 99, 119, 1_000_000)), days_held=7, ema=100.0)
    check("+19% from the EMA does not", r["extended_from_ema"] is False)

    # --- sell into weakness ---
    s = series(bar(100, 101, 98, 98, 1_000_000))
    s[-2] = bar(100, 101, 98, 99, 1_000_000)
    r = observe(s, days_held=7, pivot=100.0)
    check("failed breakout needs TWO closes under the pivot (S3 sec.3)",
          r["failed_breakout"] is True)
    r = observe(series(bar(100, 101, 98, 98, 1_000_000)), days_held=7, pivot=100.0)
    check("one close under the pivot does NOT fire", r["failed_breakout"] is False)

    r = observe(series(bar(100, 101, 90, 91, 2_000_000)), days_held=7,
                ema=100.0, avg_volume_50=1_000_000)
    check("MA violation on 2x volume fires", r["ma_violation_on_volume"] is True)
    check("worst down day of the move fires", r["worst_down_day"] is True)
    check("heaviest down volume of the move fires", r["heaviest_down_volume"] is True)
    check("weakness outranks strength in the verdict",
          r["sell_verdict"] == "SELL_INTO_WEAKNESS")

    r = observe(series(bar(100, 101, 90, 91, 1_100_000)), days_held=7,
                ema=100.0, avg_volume_50=1_000_000)
    check("MA violation on 1.1x volume does NOT fire",
          r["ma_violation_on_volume"] is False)

    # --- tri-state, and the arithmetic hazards the draft carried ---
    r = observe(series(bar(100, 101, 99, 100, 1_000_000)), days_held=7)
    check("no EMA supplied -> extension is None, not False",
          r["extended_from_ema"] is None)
    check("no pivot supplied -> failed_breakout is None", r["failed_breakout"] is None)
    check("no avg volume -> climax_volume is None", r["climax_volume"] is None)
    check("a quiet bar with signals evaluated -> HOLD", r["sell_verdict"] == "HOLD")

    r = observe([bar(0, 0, 0, 0, 0), bar(0, 0, 0, 0, 0)], days_held=1)
    check("all-zero bars: no ZeroDivisionError and nothing fires",
          not any(r[k] is True for k in SIGNALS))
    flat = [bar(100, 101, 99, 100, 1_000_000)] * 9
    r = observe(flat, days_held=7)
    check("a perfectly flat series is not a climax on a tie",
          r["climax_range"] is False and r["climax_gain"] is False)
    r = observe(series(bar(None, None, None, None, None)), days_held=7)
    check("a bar of Nones does not raise", isinstance(r, dict))
    r = observe(series({"close": float("nan")}), days_held=7)
    check("a NaN close does not raise and does not become a signal",
          r["climax_gain"] is None)
    r = observe(None, days_held=7)
    check("no bars at all -> every field blank",
          all(r[k] is None for k in OBSERVATION_FIELDS))
    r = observe(series(bar(101, 112, 100, 110, 3_000_000)), days_held=1,
                avg_volume_50=1_000_000)
    check("a 2-bar move has no 'largest since the move began'",
          r["climax_gain"] is None and r["climax_range"] is None)

    # --- the restraint itself, pinned ---
    check("the verdict vocabulary contains no executable action",
          set(VERDICTS) == {"SELL_INTO_WEAKNESS", "SELL_INTO_STRENGTH", "HOLD"})
    r = observe(series(bar(100, 101, 90, 91, 2_000_000)), days_held=7,
                ema=100.0, avg_volume_50=1_000_000)
    check("even a firing row returns only a label, never an order",
          r["sell_verdict"] in VERDICTS and
          not any(k in r for k in ("action", "shares", "price", "order")))
    check("field names are unique and ordered",
          len(set(OBSERVATION_FIELDS)) == len(OBSERVATION_FIELDS))

    print("=" * 62)
    print("PASSED %d / %d" % (ok[0], ok[1]))
    print("=" * 62)
    return 0 if ok[0] == ok[1] else 1


if __name__ == "__main__":
    raise SystemExit(_self_test())
