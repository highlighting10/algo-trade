#!/usr/bin/env python3
"""plan_probe -- feed a real candidates.csv through the contract and the
decision engine, OFFLINE. No broker, no Gemini, no credentials.

WHY
---
Step 3's definition of done is that `run --arm` either arms a real candidate or
"cleanly rejects all with correct fail-closed reasons". The second half needs no
KIS access at all: `read_candidates()` and `DecisionEngine.plan()` are both pure.
This prints exactly what the trader would decide, and why, from a CSV alone.

That matters because on a machine with no API keys the credential-gated half of
Step 3 is unreachable, and "we cannot test it" is not the same as "it is
untested". This covers the part that was always testable.

WHAT IT DOES NOT COVER
----------------------
  * the KIS tradability gate (pipeline.arm_today) -- needs the broker
  * the regime.json handshake (read_regime) -- needs a screener-written sidecar
  * arming itself
  * SECTOR CAPS. `sector_of` is injected by the pipeline and is not a Candidate
    field, so every plan here carries sector="" and the sector cap can never
    fire. A cap that cannot fire is not a cap that passed.

Usage
-----
    python -m kistrader.tools.plan_probe candidates.csv
    python -m kistrader.tools.plan_probe emit_probe.csv --equity 211710
    python -m kistrader.tools.plan_probe candidates.csv --require-atr
"""
from __future__ import annotations

import argparse
import os
import re
import sys
from collections import Counter

from kistrader.entry.screen_contract import (SCHEMA_VERSION,
                                             VCP_SCORE_THRESHOLD,
                                             read_candidates)
from kistrader.entry.decision_engine import (AccountState, DecisionConfig,
                                             DecisionEngine)


def _family(reason: str) -> str:
    """Collapse digits so '<N> reached' and 'close 12.30 > pivot+5%' group by
    CAUSE rather than by value -- the same trick notifier.py uses for dedup."""
    return re.sub(r"[-+]?\d[\d,.]*", "N", reason)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("csv")
    ap.add_argument("--equity", type=float, default=211710.0,
                    help="account equity for R sizing and the exposure ceiling")
    ap.add_argument("--allow-missing-close", action="store_true",
                    help="DRY-RUN ONLY: arm without a verifiable close")
    ap.add_argument("--require-atr", action="store_true",
                    help="reject when ATR is unavailable instead of degrading")
    ap.add_argument("--show", type=int, default=25)
    a = ap.parse_args()

    if not os.path.isfile(a.csv):
        print("NOT FOUND: %s" % a.csv, file=sys.stderr)
        return 2

    bad, note = [], []
    cands = read_candidates(
        a.csv,
        on_bad=lambda r, w: bad.append((r.get("ticker", "?"), w)),
        on_note=lambda r, w: note.append((r.get("ticker", "?"), w)))

    cfg = DecisionConfig(allow_missing_close=a.allow_missing_close,
                         require_atr=a.require_atr)
    eng = DecisionEngine(cfg)
    acct = AccountState(equity=a.equity, cash=a.equity)
    plans, rejects = eng.plan(cands, acct)

    print("=" * 78)
    print("  PLAN PROBE -- %s" % os.path.abspath(a.csv))
    print("=" * 78)
    print("  schema v%d   emit bar VCP_SCORE_THRESHOLD=%s   equity $%s"
          % (SCHEMA_VERSION, VCP_SCORE_THRESHOLD, format(int(a.equity), ",")))
    print("  risk/trade %.2f%%  max_stop %.1f%%  chase %.2f%%  buffer %.2f%%  "
          "n_max %d" % (100 * cfg.risk_per_trade_pct, 100 * cfg.max_stop_pct,
                        100 * cfg.entry_chase_pct, 100 * cfg.stop_buffer_pct,
                        cfg.n_max))
    print("  allow_missing_close=%s  require_atr=%s"
          % (cfg.allow_missing_close, cfg.require_atr))
    print()
    print("  rows accepted by the contract : %d" % len(cands))
    print("  rows REJECTED by the contract : %d" % len(bad))
    for t, why in bad[:a.show]:
        print("      %-8s %s" % (t, "; ".join(why)))
    # Grouped, not listed: every row carries the SAME note while the screeners
    # emit no tokens, and 150 identical lines bury the one that differs.
    print("  catalyst-evidence notes       : %d  (REQUIRE_CATALYST_EVIDENCE is "
          "False -- reported, not dropped)" % len(note))
    for fam, k in Counter(_family("; ".join(w)) for _t, w in note).most_common(5):
        print("      %4d x %s" % (k, fam if len(fam) <= 120
                                  else fam[:117] + "..."))

    print()
    print("-" * 78)
    print("  PLANS  (%d)" % len(plans))
    print("-" * 78)
    if plans:
        print("  %-8s %-4s %9s %7s %9s %8s %11s %6s  %s"
              % ("ticker", "exch", "limit", "shares", "stop", "risk/sh",
                 "notional", "xATR", "stop_basis"))
        for p in plans:
            print("  %-8s %-4s %9.2f %7d %9.2f %8.2f %11.0f %6.2f  %s"
                  % (p.ticker, p.exchange, p.limit_price, p.shares,
                     p.stop_price, p.est_risk_per_share, p.est_notional,
                     p.atr_mult, p.stop_basis))
        tot = sum(p.est_notional for p in plans)
        rsk = sum(p.est_risk_dollars() for p in plans)
        print("  total notional %.0f (%.1f%% of equity), total risk %.0f "
              "(%.2f%%)" % (tot, 100.0 * tot / a.equity, rsk,
                            100.0 * rsk / a.equity))
        if any(not p.sector for p in plans):
            print("  NOTE: sector is empty on every plan -- sector_of is "
                  "injected by the pipeline, so the sector cap CANNOT fire "
                  "here. Untested, not passed.")
    else:
        print("  none")

    print()
    print("-" * 78)
    print("  REJECTIONS  (%d)  grouped by cause" % len(rejects))
    print("-" * 78)
    fams = Counter(_family(r.reason) for r in rejects)
    for fam, k in fams.most_common():
        print("  %4d  %s" % (k, fam))
        for r in [x for x in rejects if _family(x.reason) == fam][:3]:
            print("          e.g. %-8s %s" % (r.ticker, r.reason))

    print()
    print("  %d candidate(s) -> %d plan(s), %d rejection(s). Zero plans with "
          "correct reasons is a VALID result." % (len(cands), len(plans),
                                                  len(rejects)))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
