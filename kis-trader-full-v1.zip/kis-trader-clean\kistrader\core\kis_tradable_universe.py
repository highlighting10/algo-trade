#!/usr/bin/env python3
"""
KIS tradable-universe gate (US overseas)
========================================

The screener's universe (yfinance/Finnhub) is far broader than what KIS actually lets
you trade. A small cap the screener loves but KIS doesn't list must be dropped BEFORE
the decision engine arms it — otherwise you either get a place-order rejection (safe)
or, worse, a position whose management calls can't resolve it. This gate is the cheap,
reliable filter: KIS's own downloadable master files are the source of truth for
"can I trade this on KIS?".

Format verified against koreainvestment/open-trading-api (MCP master_file plugin):
  * URLs:   https://new.real.download.dws.co.kr/common/master/{nas,nys,ams}mst.cod.zip
  * layout: TAB-separated, 25 columns; the ticker is column index 4 ('symbol')
  * the three US files map 1:1 to the NAS / NYS / AMS codes Position.exchange uses.

Usage:
  python kis_tradable_universe.py --refresh                 # (re)download the masters
  python kis_tradable_universe.py AAPL MSFT SOME_MICROCAP    # check specific tickers
  # in code:
  uni = TradableUniverse(); uni.ensure()
  kept, rejected = uni.filter(["AAPL", "NVDA", "OBSCURE"])
  ex = uni.resolve("AAPL")     # -> "NAS" or None
"""
from __future__ import annotations
import io
import os
import sys
import json
import time
import zipfile
import urllib.request
from typing import Optional

MASTER_URLS = {
    "NAS": "https://new.real.download.dws.co.kr/common/master/nasmst.cod.zip",
    "NYS": "https://new.real.download.dws.co.kr/common/master/nysmst.cod.zip",
    "AMS": "https://new.real.download.dws.co.kr/common/master/amsmst.cod.zip",
}
SYMBOL_COL = 4                                  # verified column index of 'symbol'
EXCH_PRIORITY = ("NAS", "NYS", "AMS")           # if a symbol appears in >1 file
ENCODINGS = ("cp949", "euc-kr", "utf-8-sig", "utf-8", "latin1")
CACHE_FILE = "kis_tradable_universe.json"
DEFAULT_MAX_AGE_DAYS = 7


def _decode(raw: bytes) -> str:
    for enc in ENCODINGS:
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    return raw.decode("latin1", errors="replace")  # last resort, never raises


def _parse_symbols(raw: bytes) -> set:
    """Pull the uppercase ticker set from one master file's raw (unzipped) bytes."""
    out = set()
    for line in _decode(raw).splitlines():
        if not line.strip():
            continue
        parts = line.split("\t")
        if len(parts) > SYMBOL_COL:
            s = parts[SYMBOL_COL].strip().upper()
            if s:
                out.add(s)
    return out


class TradableUniverse:
    def __init__(self, cache_dir=".", max_age_days=DEFAULT_MAX_AGE_DAYS):
        self.cache_path = os.path.join(cache_dir, CACHE_FILE)
        self.max_age_days = max_age_days
        self.by_exchange: dict = {}             # "NAS" -> set(symbols)
        self._resolved: dict = {}               # symbol -> exchange (priority-picked)

    # ---- network (overridable in tests) ----
    def _fetch(self, url: str) -> bytes:
        with urllib.request.urlopen(url, timeout=60) as r:
            blob = r.read()
        with zipfile.ZipFile(io.BytesIO(blob)) as zf:
            return zf.read(zf.namelist()[0])

    # ---- build / cache ----
    def refresh(self) -> "TradableUniverse":
        """Download every US master, parse, and write the cache."""
        by_ex = {}
        for ex, url in MASTER_URLS.items():
            raw = self._fetch(url)
            syms = _parse_symbols(raw)
            if not syms:
                raise RuntimeError(f"{ex}: master parsed to 0 symbols — format/encoding issue")
            by_ex[ex] = syms
            print(f"  {ex}: {len(syms):>6} tradable symbols")
        self.by_exchange = by_ex
        self._reindex()
        payload = {"_built": time.time(),
                   "exchanges": {ex: sorted(s) for ex, s in by_ex.items()}}
        with open(self.cache_path, "w", encoding="utf-8") as f:
            json.dump(payload, f)
        return self

    def _reindex(self):
        self._resolved = {}
        for ex in EXCH_PRIORITY:
            for s in self.by_exchange.get(ex, ()):        # first exchange in priority wins
                self._resolved.setdefault(s, ex)

    def _cache_fresh(self) -> bool:
        if not os.path.exists(self.cache_path):
            return False
        age_days = (time.time() - os.path.getmtime(self.cache_path)) / 86400.0
        return age_days <= self.max_age_days

    def load_cache(self) -> bool:
        if not os.path.exists(self.cache_path):
            return False
        with open(self.cache_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        self.by_exchange = {ex: set(s) for ex, s in data.get("exchanges", {}).items()}
        self._reindex()
        return bool(self._resolved)

    def ensure(self) -> "TradableUniverse":
        """Load a fresh cache if present, else download. Call before using the gate."""
        if self._cache_fresh() and self.load_cache():
            return self
        return self.refresh()

    # ---- the gate ----
    @staticmethod
    def _variants(ticker: str):
        """Handle symbology drift between data vendors and KIS (BRK-B / BRK.B / BRKB)."""
        t = ticker.strip().upper()
        seen = []
        for v in (t, t.replace("-", "."), t.replace(".", "-"),
                  t.replace("-", ""), t.replace(".", "")):
            if v and v not in seen:
                seen.append(v)
        return seen

    def resolve(self, ticker: str) -> Optional[str]:
        """Return the KIS exchange code (NAS/NYS/AMS) for a tradable ticker, else None."""
        for v in self._variants(ticker):
            if v in self._resolved:
                return self._resolved[v]
        return None

    def is_tradable(self, ticker: str) -> bool:
        return self.resolve(ticker) is not None

    def filter(self, tickers):
        """Split screener output into (kept, rejected).
        kept     = [(ticker, exchange), ...]   ready for the decision engine
        rejected = [(ticker, reason), ...]"""
        if not self._resolved:
            raise RuntimeError("universe not loaded — call ensure() or refresh() first")
        kept, rejected = [], []
        for t in tickers:
            ex = self.resolve(t)
            if ex:
                kept.append((t, ex))
            else:
                rejected.append((t, "not in KIS overseas tradable universe"))
        return kept, rejected


def main(argv):
    uni = TradableUniverse()
    if "--refresh" in argv:
        print("Refreshing KIS US master files...")
        uni.refresh()
        print(f"Cached -> {uni.cache_path}")
        argv = [a for a in argv if a != "--refresh"]
        if not argv:
            return 0
    else:
        uni.ensure()
    if not argv:
        total = sum(len(s) for s in uni.by_exchange.values())
        print(f"Universe loaded: {total} US symbols "
              f"({', '.join(f'{ex}={len(uni.by_exchange.get(ex,[]))}' for ex in EXCH_PRIORITY)})")
        return 0
    kept, rejected = uni.filter([a.upper() for a in argv])
    for t, ex in kept:
        print(f"  TRADABLE   {t:<8} -> {ex}")
    for t, why in rejected:
        print(f"  REJECTED   {t:<8} -> {why}")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
