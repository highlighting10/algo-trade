#!/usr/bin/env python3
"""
apply_watchdog_pins.py -- pin the numbers that decide whether an alert arrives.

THE GAP

Every strategy parameter is guarded: FROZEN, PINNED_DECISION, PINNED_ENGINE,
PINNED_EXPOSURE, IDENTITY_TR. The layer that WATCHES all of it is guarded by
nothing. Until now not one supervisor or dead-man constant was reported or
pinned anywhere, and 2026-09-19 measured why that matters:

  * the supervisor's backoff caps at 300s while the deployed dead-man calls
    the heartbeat stale at 180s, so a NORMAL recovery pages the operator. The
    two numbers live in different files and nothing correlated them.
  * `SuccessExitStatus=2 3` in kistrader.service is the ONLY reason systemd
    does not restart a supervisor that deliberately gave up. Drop the 3, or
    flip Restart=always, and the crash-storm guard is real in code and INERT
    in deployment -- discoverable only by killing the trader seven times.

That second one is the dangerous shape: a proven safety mechanism turned into
a no-op by a one-word edit in a file no test reads.

WHERE THIS GOES, AND WHY NOT param_snapshot

param_snapshot reads the kistrader package. supervisor.py and deadman.py are
standalone by design -- deadman's rule 1 is ZERO coupling to the package, so
that a broken venv or a mid-edit repo cannot take down the watcher with the
thing it watches. Importing them into param_snapshot would work against that.
tests/test_watchdogs.py already imports both and already has _root(); the pins
belong there, next to the behaviour they constrain.

Defaults are read from SOURCE because they live inside main() as argparse
defaults, with nothing importable to read. That is the same tool
param_snapshot.screener_overrides() uses for the same reason, and it FAILS
CLOSED: an option the reader cannot find returns None and fails its check
rather than passing quietly. There is a control for that.

    python apply_watchdog_pins.py --verify
    python apply_watchdog_pins.py
    python apply_watchdog_pins.py --revert

Run from the repo root.
"""
from __future__ import annotations

import argparse
import os
import subprocess
import sys
import tempfile

REPO_BRANCH = "e10-progressive-exposure"
F_TEST = os.path.join("tests", "test_watchdogs.py")
SENTINEL = "def t_watchdog_pins"
N_NEW_CHECKS = 18

BLOCK = '''def _arg_default(path, opt):
    """The argparse default for `opt`, read from SOURCE.

    The defaults live inside main() as add_argument(default=...), so there is
    nothing importable to read -- same situation, and same tool, as
    param_snapshot.screener_overrides(). FAILS CLOSED: an option the reader
    cannot find comes back None, which fails its check instead of passing.
    """
    import re
    with open(path, encoding="utf-8") as fh:
        src = fh.read()
    m = re.search(r\'add_argument\\(\\s*"\' + re.escape(opt) + r\'"[^)]*?default=([^,)\\s]+)\',
                  src)
    return m.group(1) if m else None


def _unit(name):
    with open(os.path.join(_root(), "deploy", name), encoding="utf-8") as fh:
        return fh.read()


def t_watchdog_pins():
    """J -- the constants that decide whether an alert arrives at all.

    Every strategy parameter has a guard. The layer that watches them had
    none. These are not backtest-chosen values; they are what the watchdogs
    were BUILT with, so drift is a stop -- the argument PATCH I made for the
    TR ids, applied to the watchers."""
    print("J  watchdog constants -- and the interaction nobody was watching")
    sup = os.path.join(_root(), "supervisor.py")
    dm = os.path.join(_root(), "deadman.py")

    for opt, want in (("--backoff-base", "65.0"), ("--backoff-cap", "300.0"),
                      ("--healthy-secs", "600.0"), ("--max-restarts", "6"),
                      ("--window", "1800.0")):
        got = _arg_default(sup, opt)
        check("supervisor default %s is %s" % (opt, want), got == want, str(got))
    for opt, want in (("--stale-secs", "300"), ("--interval", "60"),
                      ("--renotify-secs", "1800")):
        got = _arg_default(dm, opt)
        check("deadman default %s is %s" % (opt, want), got == want, str(got))

    check("POSITIVE CONTROL the source reader fails closed on a missing option",
          _arg_default(sup, "--no-such-option") is None,
          str(_arg_default(sup, "--no-such-option")))

    u_trader, u_dead = _unit("kistrader.service"), _unit("kistrader-deadman.service")

    # THE ONE THAT TURNS A PROVEN GUARD INTO A NO-OP.
    # Measured on the box 2026-09-19: the supervisor exits 3 when it gives up
    # after a crash storm, and systemd printed "Deactivated successfully"
    # rather than restarting it. That is SuccessExitStatus=2 3 doing the work.
    # Drop the 3, or flip Restart=always, and the guard still fires in the log
    # and is dead in deployment -- provable only by killing the trader seven
    # times. See RESULT_20260919_crash_storm_proven sec.2.
    check("kistrader.service counts exit 3 as SUCCESS (the guard reaches you)",
          "SuccessExitStatus=2 3" in u_trader,
          [l for l in u_trader.splitlines() if "SuccessExitStatus" in l])
    check("...with Restart=on-failure, so a deliberate give-up is not undone",
          "Restart=on-failure" in u_trader,
          [l for l in u_trader.splitlines() if l.startswith("Restart=")])
    check("the dead-man is Restart=always -- it must OUTLIVE the trader",
          "Restart=always" in u_dead,
          [l for l in u_dead.splitlines() if l.startswith("Restart=")])

    # The deployed arguments, which are where the real values come from. The
    # repo defaults above are NOT what runs for the dead-man.
    check("the deployed dead-man overrides stale to 180 and interval to 60",
          "--stale-secs 180" in u_dead and "--interval 60" in u_dead,
          [l for l in u_dead.splitlines() if "ExecStart=" in l])
    check("the deployed supervisor passes NO policy override, so the "
          "defaults above ARE the live policy",
          not any(f in u_trader for f in ("--backoff", "--healthy-secs",
                                          "--max-restarts", "--window")),
          [l for l in u_trader.splitlines() if "ExecStart=" in l])

    # THE INTERACTION, and the decision that governs it.
    # The backoff caps at 300s; the deployed dead-man calls stale at 180s. So a
    # NORMAL recovery pages the phone -- observed live during the crash-storm
    # run, at a 261s backoff, twelve minutes before anything was wrong.
    #
    # DECIDED 2026-09-19, by the operator, and NOT an oversight: keep 180. The
    # transient pages are WANTED, because a DOWN/RECOVERED pair is a record
    # that a crash happened and the supervisor handled it, which a silent
    # recovery destroys. The rule is:
    #     DOWN then RECOVERED          -> supervisor did its job, no action
    #     DOWN, no RECOVERED in 30 min -> manual check
    # Do NOT "fix" 180 up past the backoff cap. Under a 300s backoff it looks
    # like a misconfiguration and is not one: it is the setting that makes
    # every crash visible. See RESULT_20260919_crash_storm_proven sec.4.
    cap = float(_arg_default(sup, "--backoff-cap"))
    check("DECIDED: the deployed stale threshold sits BELOW the backoff cap",
          180.0 < cap, "180 vs cap %s" % cap)
    # And the collision is in the SHIPPED DEFAULTS too, where the two are
    # exactly equal -- a max backoff would land on the threshold and alert or
    # not on which side of a second the poll falls. The box's 180 makes the
    # overlap wide and consistent instead of marginal.
    check("...and at the shipped defaults the two are EQUAL, which is worse",
          float(_arg_default(dm, "--stale-secs")) == cap,
          "%s vs %s" % (_arg_default(dm, "--stale-secs"), cap))
    # renotify IS the escalation half of the rule above. Verified off
    # `deadman.py --help` on the box; the unit passes no override.
    check("renotify is 1800s, which IS the 30-minute escalation rule",
          _arg_default(dm, "--renotify-secs") == "1800"
          and "--renotify" not in u_dead,
          _arg_default(dm, "--renotify-secs"))
    # Measured on the box: the guard tripped on the SEVENTH exit. --max-restarts
    # is the number of restarts ALLOWED, so the seventh exit is the one nobody
    # answers. The policy line prints it as "6 exits", which is the wrong noun
    # for the number and is what made an earlier estimate of "2 exits in 600s"
    # survive as long as it did.
    check("storm guard allows 6 restarts, so it trips on exit 7 (measured)",
          _arg_default(sup, "--max-restarts") == "6",
          _arg_default(sup, "--max-restarts"))


'''

ANCHOR_FN_OLD = ("\n\n# ---------------------------------------------------"
                 "------------------------\n\ndef main():")
ANCHOR_FN_NEW = ("\n\n# ---------------------------------------------------"
                 "------------------------\n\n" + BLOCK + "def main():")

ANCHOR_CALL_OLD = "        t_supervisor_constants()\n"
ANCHOR_CALL_NEW = "        t_supervisor_constants()\n    t_watchdog_pins()\n"

EDITS = [(F_TEST, ANCHOR_FN_OLD, ANCHOR_FN_NEW),
         (F_TEST, ANCHOR_CALL_OLD, ANCHOR_CALL_NEW)]


def _read(p):
    with open(p, encoding="utf-8") as fh:
        return fh.read()


def _write(p, text):
    compile(text, p, "exec")
    d = os.path.dirname(os.path.abspath(p))
    fd, tmp = tempfile.mkstemp(dir=d, suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as fh:
            fh.write(text)
        os.replace(tmp, p)
    except BaseException:
        if os.path.exists(tmp):
            os.unlink(tmp)
        raise


def _ascii_guard():
    try:
        BLOCK.encode("ascii")
    except UnicodeEncodeError as e:
        raise SystemExit(f"patch text is not pure ASCII: {e}")


def check_branch(force):
    try:
        r = subprocess.run(["git", "rev-parse", "--abbrev-ref", "HEAD"],
                           capture_output=True, text=True, timeout=5)
        b = r.stdout.strip() if r.returncode == 0 else ""
    except Exception:                      # noqa: BLE001
        b = ""
    if force or b == REPO_BRANCH:
        print(f"  branch = {b or '(unknown)'}")
        return
    raise SystemExit(f"REFUSING: on branch {b!r}, expected {REPO_BRANCH!r}. "
                     f"--force-branch to override.")


def apply(revert=False):
    for need in (F_TEST, os.path.join("deploy", "kistrader.service"),
                 os.path.join("deploy", "kistrader-deadman.service"),
                 "supervisor.py", "deadman.py"):
        if not os.path.isfile(need):
            raise SystemExit(f"missing {need} (run from the repo root)")
    src = _read(F_TEST)
    hits = sum(1 for _f, _o, new in EDITS if new in src)
    if not revert and hits == len(EDITS):
        raise SystemExit("already applied -- nothing to do")
    if not revert and hits:
        raise SystemExit(f"PARTIAL state: {hits}/{len(EDITS)}. Refusing.")
    if revert and hits == 0:
        raise SystemExit("not applied -- nothing to revert")
    if revert and hits != len(EDITS):
        raise SystemExit(f"PARTIAL state: {hits}/{len(EDITS)}. Refusing.")
    for _f, old, new in EDITS:
        a, b = (new, old) if revert else (old, new)
        n = src.count(a)
        if n != 1:
            raise SystemExit(f"anchor matched {n} times, expected 1:\n"
                             f"---\n{a[:140]}\n---")
        src = src.replace(a, b, 1)
    _write(F_TEST, src)
    print(f"  {'reverted' if revert else 'patched '} {F_TEST} "
          f"({len(EDITS)} edit(s))")
    print("REVERTED." if revert else "APPLIED.")


class V:
    def __init__(self):
        self.p = self.f = 0

    def check(self, label, cond, detail=""):
        ok = bool(cond)
        self.p += ok
        self.f += (not ok)
        print(f"  {'PASS' if ok else 'FAIL'}  {label}"
              + (f"   {detail}" if detail and not ok else ""))

    def done(self):
        print(f"\n  {self.p}/{self.p + self.f} checks passed")
        return 0 if self.f == 0 else 1


def verify():
    _ascii_guard()
    v = V()
    src = _read(F_TEST)
    for i, (_f, _o, new) in enumerate(EDITS, 1):
        v.check(f"edit {i}/{len(EDITS)} present exactly once",
                src.count(new) == 1, f"count={src.count(new)}")
    v.check("sentinel present", src.count(SENTINEL) == 1)
    v.check("main() runs it", "    t_watchdog_pins()\n" in src)
    try:
        compile(src, F_TEST, "exec")
        v.check("compiles", True)
    except SyntaxError as e:
        v.check("compiles", False, str(e))
        return v.done()

    sys.path.insert(0, os.getcwd())
    sys.path.insert(0, os.path.join(os.getcwd(), "tests"))
    import test_watchdogs as T
    before = list(T.PASS)
    print("\n  --- running the block ---")
    T.t_watchdog_pins()
    print("  --- end ---\n")
    ran = T.PASS[1] - before[1]
    passed = T.PASS[0] - before[0]
    v.check(f"the block contributes {N_NEW_CHECKS} checks",
            ran == N_NEW_CHECKS, str(ran))
    v.check("every one of them passes", passed == ran, f"{passed}/{ran}")

    # ---- POSITIVE CONTROLS ----
    # A pin that cannot fail is decoration. Both of these prove the reader is
    # really reading, not returning something that happens to match.
    sup = os.path.join(os.getcwd(), "supervisor.py")
    dm = os.path.join(os.getcwd(), "deadman.py")
    v.check("POSITIVE CONTROL the reader returns None for a missing option",
            T._arg_default(sup, "--not-a-real-flag") is None)
    v.check("POSITIVE CONTROL it distinguishes two DIFFERENT options",
            T._arg_default(sup, "--backoff-base") == "65.0"
            and T._arg_default(sup, "--backoff-cap") == "300.0",
            f'{T._arg_default(sup, "--backoff-base")} '
            f'{T._arg_default(sup, "--backoff-cap")}')
    # And that the collision the block records is REAL, computed here rather
    # than asserted from the patch text.
    v.check("POSITIVE CONTROL the default collision is real (stale == cap)",
            float(T._arg_default(dm, "--stale-secs"))
            == float(T._arg_default(sup, "--backoff-cap")),
            f'{T._arg_default(dm, "--stale-secs")} '
            f'{T._arg_default(sup, "--backoff-cap")}')
    v.check("POSITIVE CONTROL the DEPLOYED stale really is 180, not the default",
            "--stale-secs 180" in T._unit("kistrader-deadman.service"))
    return v.done()


def main(argv=None):
    ap = argparse.ArgumentParser(description="pin the watchdog constants")
    ap.add_argument("--verify", action="store_true")
    ap.add_argument("--revert", action="store_true")
    ap.add_argument("--force-branch", action="store_true")
    a = ap.parse_args(argv)
    _ascii_guard()
    if a.verify:
        return verify()
    check_branch(a.force_branch)
    apply(revert=a.revert)
    return 0


if __name__ == "__main__":
    sys.exit(main())
