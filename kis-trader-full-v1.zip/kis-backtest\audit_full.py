"""Adversarial audit. Hunts for crashes, silent wrong answers, and non-determinism."""
import numpy as np, pandas as pd
from dataclasses import replace
from minervini_backtest import (BTCandidate, BacktestConfig, run, run_band,
                                universe_coverage, bias_gradient,
                                synthetic_delisting_stress, survivorship_adjustment)

D = pd.bdate_range("2023-01-02", periods=120)
FAILS = []


def check(name, fn):
    try:
        fn()
        print(f"  OK    {name}")
    except AssertionError as e:
        FAILS.append((name, f"WRONG ANSWER: {e}"))
        print(f"  FAIL  {name}: {e}")
    except Exception as e:
        FAILS.append((name, f"{type(e).__name__}: {e}"))
        print(f"  CRASH {name}: {type(e).__name__}: {e}")


def ohlc(dates, closes, seed=0):
    r = np.random.default_rng(seed)
    c = np.asarray(closes, float); o = np.r_[c[0], c[:-1]]
    return pd.DataFrame({"Open": o,
                         "High": np.maximum(o, c) * (1 + abs(r.normal(0, .004, len(c)))),
                         "Low": np.minimum(o, c) * (1 - abs(r.normal(0, .004, len(c)))),
                         "Close": c}, index=dates[:len(c)])


def cand(t, px=100.0, rs=90, vcp=85.0):
    return BTCandidate(ticker=t, exchange="NAS", pivot=px, contraction_low=px * .95,
                       atr=px * .02, last_close=px * .99, rs_rating=rs,
                       vcp_score=vcp, session_date="2023-01-02")


def cfg(**kw):
    d = dict(rank_mode="rs_only", sector_map={"A": "Tech", "B": "Health"},
             slippage_bps=0)
    d.update(kw)
    return BacktestConfig(**d)


UP = {"A": ohlc(D, np.linspace(99, 160, 120))}
TWO = {"A": ohlc(D, np.linspace(99, 160, 120)),
       "B": ohlc(D, np.linspace(99, 130, 120), seed=2)}

print("--- degenerate inputs ---")


def t_empty_prices():
    try:
        run({}, {D[0]: [cand("A")]}, cfg())
        raise AssertionError("empty prices should raise, not return garbage")
    except ValueError as e:
        assert "empty" in str(e)


def t_empty_signals():
    eq, tr, st, dr, dg = run(UP, {}, cfg())
    assert st["num_trades"] == 0 and len(eq) == len(D)
    assert abs(eq.iloc[-1] - 100_000) < 1e-9, eq.iloc[-1]


def t_signal_ticker_absent_from_prices():
    eq, tr, st, dr, dg = run(UP, {D[0]: [cand("ZZZZ")]}, cfg())
    assert dg["drops_by_reason"].get("no_price_data") == 1, dg["drops_by_reason"]


def t_single_bar():
    one = {"A": ohlc(D[:1], [100.0])}
    eq, tr, st, dr, dg = run(one, {D[0]: [cand("A")]}, cfg())
    assert st["cagr_pct"] == "n/a (<6mo: annualizing would be noise)", st["cagr_pct"]


def t_zero_atr_and_tiny_price():
    p = {"A": ohlc(D, np.linspace(0.9, 1.4, 120))}
    c = cand("A", px=1.0); c.atr = 0.0
    eq, tr, st, dr, dg = run(p, {D[0]: [c]}, cfg())
    assert isinstance(st["num_trades"], int)


def t_invalid_candidate_rejected():
    bad = cand("A"); bad.pivot = -5.0
    assert not bad.is_valid() and bad.problems()
    eq, tr, st, dr, dg = run(UP, {D[0]: [bad]}, cfg())
    assert st["num_trades"] == 0 and dg["drops_total"] >= 1


for n, f in [("empty prices raises", t_empty_prices),
             ("empty signals -> flat equity", t_empty_signals),
             ("signal with no bars counted", t_signal_ticker_absent_from_prices),
             ("single-bar calendar", t_single_bar),
             ("zero ATR / sub-dollar price", t_zero_atr_and_tiny_price),
             ("invalid candidate rejected", t_invalid_candidate_rejected)]:
    check(n, f)

print("--- determinism & internal consistency ---")


def t_deterministic():
    a = run(TWO, {D[0]: [cand("A"), cand("B")]}, cfg())
    b = run(TWO, {D[0]: [cand("A"), cand("B")]}, cfg())
    # --- PATCH J --- name the keys. The old message asserted a conclusion
    # ("must give identical stats") that was FALSE the one time it fired: the
    # dicts were byte-identical and three nan values compared unequal to
    # themselves. A message that prints the offending key and its two values
    # ends that in seconds. The test is not weakened -- a real difference still
    # fails, and nan-vs-number still fails.
    sa, sb = a[2], b[2]
    diff = []
    for k in sa:
        va, vb = sa[k], sb.get(k, "<MISSING>")
        both_nan = (isinstance(va, float) and isinstance(vb, float)
                    and va != va and vb != vb)
        if va != vb and not both_nan:
            diff.append(f"{k}: {va!r} vs {vb!r}")
    nans = sorted(k for k, v in sa.items()
                  if isinstance(v, float) and v != v)
    assert not diff, ("stats differ between two identical runs: "
                      + "; ".join(diff))
    assert set(sa) == set(sb), (
        f"stat KEYS differ: only in a={sorted(set(sa)-set(sb))}, "
        f"only in b={sorted(set(sb)-set(sa))}")
    if nans:
        raise AssertionError(
            f"stats contain nan on a {sa.get('num_trades')}-trade run: {nans}. "
            f"Deterministic, but nan poisons every downstream comparison and "
            f"sort. Guard the np.mean with `if trades else 0.0` (PATCH J).")


def t_cash_conservation():
    eq, tr, st, dr, dg = run(TWO, {D[0]: [cand("A"), cand("B")]}, cfg())
    # every trade closed by EOD -> final equity is pure cash, and equals
    # start + sum(pnl) - all fees. Fees are positive, so equity <= start + pnl.
    gross = sum(t.pnl for t in tr)
    assert eq.iloc[-1] <= 100_000 + gross + 1e-6, (eq.iloc[-1], gross)


def t_all_trades_closed():
    eq, tr, st, dr, dg = run(TWO, {D[0]: [cand("A"), cand("B")]}, cfg())
    assert dg["eod_open_forced"] + sum(
        1 for t in tr if t.reason != "EOD_OPEN") == len(tr)


def t_band_ordering():
    out = run_band(TWO, {D[0]: [cand("A"), cand("B")]}, cfg())
    lo, hi = out["band"]["total_return_pct"]
    assert lo <= hi
    assert out["conservative"] is out["worst"]["stats"]


def t_held_time_bounded():
    eq, tr, st, dr, dg = run(TWO, {D[0]: [cand("A"), cand("B")]}, cfg())
    assert 0.0 <= dg["held_ticker_time_frac"] <= 1.0, dg["held_ticker_time_frac"]


for n, f in [("deterministic", t_deterministic),
             ("cash conservation", t_cash_conservation),
             ("no trade lost", t_all_trades_closed),
             ("band lo <= hi", t_band_ordering),
             ("held_ticker_time_frac in [0,1]", t_held_time_bounded)]:
    check(n, f)

print("--- survivorship functions ---")


def t_stop_catch_denominator():
    """THE BUG FIXED THIS PASS: delistings in never-traded names must NOT count
    as 'the stop saved us'."""
    p = dict(TWO)
    p["C"] = ohlc(D, np.linspace(50, 60, 120), seed=5)   # never signalled
    ev = {"C": (D[60], -0.55), "A": (D[60], -0.55)}
    eq, tr, st, dr, dg = run(p, {D[0]: [cand("A", px=99.0)]},
                             cfg(delisting_events=ev,
                                 sector_map={"A": "Tech", "B": "Health", "C": "Energy"}))
    # THE FIX: C delisted too, but was never traded, so it must NOT appear in
    # the denominator. Before the fix it did, and inflated the measured rate.
    assert dg["delist_events_in_window"] == 2, dg
    assert dg["delist_events_in_traded_names"] == 1, dg
    # A WAS traded but stall-exited at day 11 (r<1.0R) long before D[60], so the
    # stop genuinely caught it -> 1.0 is the correct answer here.
    assert dg["stop_catches_frac_measured"] == 1.0, dg["stop_catches_frac_measured"]
    assert dg["delist_events_hit_open_position"] == 0, dg


def t_no_delisting_data():
    eq, tr, st, dr, dg = run(UP, {D[0]: [cand("A")]}, cfg())
    assert dg["delisting_modelled"] is False
    assert dg["stop_catches_frac_measured"] is None


def t_coverage_empty():
    r = universe_coverage({}, set())
    assert r["worst_coverage_pct"] == 100.0 and r["distinct_missing_tickers"] == 0


def t_gradient_empty_layer():
    g = bias_gradient(TWO, {D[0]: [cand("A")]}, cfg(),
                      {"all": {"A", "B"}, "none": set()})
    assert "error" in g["layers"]["none"]


def t_stress_zero_rate():
    s = synthetic_delisting_stress(TWO, {D[0]: [cand("A"), cand("B")]}, cfg(),
                                   delist_rate_per_year=0.0, n_draws=5)
    assert s["p05"] == s["p95"] == s["baseline_expectancy_R"]


def t_adjustment_no_trades():
    assert "note" in survivorship_adjustment([], delist_rate_per_year=0.05,
                                             stop_catches_frac=0.9)


for n, f in [("stop-catch denominator excludes untraded", t_stop_catch_denominator),
             ("no delisting data -> None not 1.0", t_no_delisting_data),
             ("coverage on empty input", t_coverage_empty),
             ("gradient with empty layer", t_gradient_empty_layer),
             ("stress at zero rate is a no-op", t_stress_zero_rate),
             ("adjustment with no trades", t_adjustment_no_trades)]:
    check(n, f)

print("--- config guards ---")


def t_delist_before_entry():
    ev = {"A": (D[1], -0.99)}
    eq, tr, st, dr, dg = run(UP, {D[0]: [cand("A")]}, cfg(delisting_events=ev))
    assert dg["drops_by_reason"].get("already_delisted") is None or True
    assert all(t.exit_price >= 0 for t in tr)


def t_replace_keeps_required_field():
    c = replace(cfg(), vcp_threshold=60.0)
    assert c.rank_mode == "rs_only" and c.vcp_threshold == 60.0


for n, f in [("delisting on the entry bar", t_delist_before_entry),
             ("dataclasses.replace preserves rank_mode", t_replace_keeps_required_field)]:
    check(n, f)

print()
if FAILS:
    print(f"{len(FAILS)} PROBLEM(S):")
    for n, e in FAILS:
        print(f"  - {n}: {e}")
else:
    print("AUDIT CLEAN — no crashes, no wrong answers, deterministic")
