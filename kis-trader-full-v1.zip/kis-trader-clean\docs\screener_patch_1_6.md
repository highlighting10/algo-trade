# Screener §1.6 patch — surface the three fields the entry half needs

**Why:** the entry half's ATR volatility stop and its extension guard need the
absolute latest ATR20, the latest Close, and the base low. `generate_report()`
currently exposes `atr_ratio` (a *ratio*) but none of these absolutes. Without
them the decision engine can't verify extension and can't ATR-floor the stop.

**Where:** `VCPAnalyzerV4.generate_report()`, inside the `Extracted_Pattern`
dict (sp500_v21.py ≈ line 2349; same block in the other three screeners). At
that point `base_df`, `self.df['Close']`, and `self.df['ATR20']` are all already
in scope, so this is a pure, drop-in addition — **no scoring/detection change.**

## The change

Add three keys to the `Extracted_Pattern` dict:

```python
            'Extracted_Pattern': {
                'Base_High':         float(base_high),
                'Base_Start_Bar':    int(base_start_num),
                'Wave_Count':        len(waves),
                'Wave_Depths_Pct':   [round(float(w.depth_pct), 2) for w in waves],
                'Wave_Highs':        [round(float(w.high_price), 2) for w in waves],
                'Wave_Lows':         [round(float(w.low_price), 2)  for w in waves],
                'Pivot':             float(rdm.get('pivot_level', 0)),  # LOCKED
                'Invalid_Waves_Dropped': int(self._invalid_wave_count),
                # --- §1.6: absolutes the entry half needs (no scoring impact) ---
                'Base_Low':          float(base_df['Low'].min()),
                'Latest_Close':      float(self.df['Close'].iloc[-1]),
                'Latest_ATR':        float(self.df['ATR20'].ffill().bfill().iloc[-1]),
            },
```

That's the whole patch. Notes:

- `base_df['Low'].min()` is the **true structural floor** of the base — a better
  stop anchor than `min(Wave_Lows)` (the lowest *swing* low), which the consumer
  falls back to when `Base_Low` is absent. The absolute low is never above the
  lowest wave low, so the stop can only get safer, not tighter.
- `.ffill().bfill()` on ATR20 mirrors what the analyzer already does at input
  validation (line ≈1648) and in the ZigZag (line ≈1861), so the leading 20-bar
  NaN window can't produce a NaN here.
- Apply the identical three lines in `us_small_v21.py`, the MSCI ex-US, and the
  MSCI Korea screeners — the `Extracted_Pattern` block is the same shape in all
  four (the VCP engine was ported verbatim).

## After patching

`candidate_from_report()` picks these up automatically; nothing else to wire.
The consumer has also been hardened (see `screen_contract.py` /
`decision_engine.py`) so that **if this patch is missing or a field is dropped,
the pipeline now fails LOUD and SAFE** instead of silently disabling the guards:
a missing `Latest_Close` rejects the candidate with an explicit reason (unless
you set `allow_missing_close=True` for a dry run), and a missing `Latest_ATR`
falls back to a structural-only stop that is *labelled* (`stop_basis`) in the
plan and the event log rather than applied silently.
