# F8 — differential fixture: harness exit engine vs `engine_v2`

Drop this folder at `kis-backtest/f8/`. It touches nothing else in either repo.

`PARAMETER_FREEZE` Rev 3 §6 F8 calls the harness exit engine *"the largest
single unvalidated assumption in the project."* Half of it was already closed by
`tests/test_exit_state_machine.py`, which pins `engine_v2`. This closes the
other half: it drives the **real `engine_v2`** over synthetic daily bars and
compares its exits, case by case, against the harness's reimplementation.

---

## Before anything

`kis-backtest` still has no git repository (verified 2026-08-16, still true
2026-08-22). Do this first, or there is no rollback point:

```powershell
cd C:\Users\user\PyCharmMiscProject\kis-backtest
git init
git config user.name "JH"; git config user.email "jh@kistrader.local"
# .gitignore FIRST: .venv/ __pycache__/ price_cache/ *.pkl runs/ *.db *.parquet
git add -A
git commit -m "Baseline: kis-backtest as it produced PARAMETER_FREEZE Rev 3"
```

---

## Run it

```powershell
cd C:\Users\user\PyCharmMiscProject\kis-backtest\f8

# production side only — should be 62/62
python run_f8.py --prod-root C:\Users\user\kis-trader-clean

# the actual diff — should be 98/98
python run_f8.py --prod-root C:\Users\user\kis-trader-clean --harness ..\minervini_backtest.py

# both guards must be shown to fail
python sabotage_check.py   --prod-root C:\Users\user\kis-trader-clean
python sabotage_harness.py --prod-root C:\Users\user\kis-trader-clean --harness ..\minervini_backtest.py

# THE ONE THAT EARNS THE CONCLUSION — 12,000 random scenarios.
# Exit code 0 = no unknown divergence. Run this after touching either engine.
python fuzz_f8.py --prod-root C:\Users\user\kis-trader-clean --harness ..\minervini_backtest.py --trials 12000

# EMA definition side-experiment
python ema_compare.py --prod-root C:\Users\user\kis-trader-clean
```

Reproduced independently on the target machine (Windows, Python 3.14,
pandas 3.0.3) 2026-08-22: 62/62, 98/98, both proofs green, and the sweep
**bit-identical** to the development run — same 11,950/50 split, same scenario
ids. The RNG stream is stable across Python 3.11 and 3.14, so the sweep is a
genuine regression baseline, not just a smoke test.

No dependencies beyond the stdlib and `requests` (which `engine_v2` imports).
Nothing here touches the box, the broker, or any live state.

---

## Files

| file | what |
|---|---|
| `engine_side.py` | Loads production `engine_v2` **by absolute path**, and replays daily bars through the real `ExecutionMonitor` with an in-memory broker and a fake clock. This is Rev 3 §10's "drive the real `engine_v2` with a backtest broker". |
| `cases.py` | The eight required cases plus nine extras (17 total). Each states the `stall_day` it exercises. |
| `run_f8.py` | Runner and reporter. Exit 0 = all green. |
| `sabotage_check.py` | Plants defects in throwaway copies of `engine_v2` and asserts the fixture catches them. |
| `ema_compare.py` | Side-experiment: does the harness's EMA21 mean the same number as production's? |
| `harness_side.py` | Drives the real `minervini_backtest.run()` over the same bars and reads the `Trade` back. Monkeypatches exactly one symbol (`_ema`) so both sides see the same indicator. |
| `sabotage_harness.py` | Plants defects in throwaway copies of the HARNESS and asserts the **diff** goes red. This is the direction F8 needs. |
| `fuzz_f8.py` | 12,000 random bar sequences through both engines. Exit 0 only while every disagreement falls in a pinned class. |
| `FINDING_f8_fixture_20260822.md` | The write-up: what was proven, the two harness defects, and what still needs a decision. |

---

## Why modules are loaded by path

`kis-backtest` ships a partial copy of `kistrader/`, and Python puts the cwd at
`sys.path[0]`, so a plain `import kistrader...` run from the harness repo
silently resolves to the vendored copy. A fixture that must hold **both**
engines in one process cannot rely on `sys.path` at all.

Verified precondition: `engine_v2.py` and `providers.py` import only stdlib and
`requests` — no intra-package imports — so they load standalone with no package
context. The harness is loaded the other way round, *with* the `kis-backtest`
root on `sys.path`, so it resolves its own vendored `kistrader` exactly as it
does in a real run. F8 asks whether the harness **as it actually ran** agrees
with production; "fix it first, then compare" would answer a different question.

Every run prints the resolved path of each side. Do not quote a number from
this fixture without that line.

---

## Conventions, and why they are reported rather than assumed

`engine_v2` is tick-driven; daily bars have no intraday sequence. A tick path
must be synthesised, and every choice is a modelling decision, not a fact about
the engine.

**Tick path** (`--tick-path`, default `worst`): `open → stop → +3R →
breakeven-retest → close`. The stop is visited before the +3R trigger, so a bar
touching both stops out — the freeze's stated rule and the harness's own
`ambiguity_mode="worst"`. `olhc` drops the same-bar breakeven retest; `ohlc`
lets the partial precede the stop (present only so the pessimism can be
measured, never as a default).

**Tick prices are decision prices, not bar extremes.** The stop tick is fed at
exactly `stop` — or at `open` when the bar gaps through it, because then the
open tick is already below the stop. The +3R tick is fed at exactly
`entry + 3R`, never at `high`. This reproduces the freeze's documented fill
rules without special-casing them: the engine just sees the price at which its
own condition first becomes true.

**Price is reported, not asserted.** `engine_v2` has no fill model — it decides
"exit now" and places a limit at `_band(bid * (1 - slip), bid, price)`, about 2%
under the bid. The diff asserts `(exit_reason, exit_bar)` and reports
`exit_price` alongside the limit the engine actually sent, so exit slippage the
harness does not model is visible without being mistaken for a strategy
disagreement.

**Session counting.** `run_loop` rolls the day at the first cycle of a new
trading date, before that session's close. A position filled intraday on bar 0
was not in the list when bar 0 rolled, so **bar 0 = entry session, days_held 0**.
If the harness counts the entry session as day 1, every stall comparison is off
by one.

---

## Production-side reference results

`--tick-path worst`, **62/62** green, from the real engine. (An earlier draft
of this file said 50/50 — that was the count before the recheck added cases 2b,
10 and 11. The RECHECK section at the end is the authority for every figure.)

| case | stall | reason | bar | price | R |
|---|---|---|---|---|---|
| 1 clean intraday stop | 252 | STOP_HIT | 1 | 90.00 | −1.000 |
| 2 gap through the stop | 252 | STOP_HIT | 1 | 85.00 | −1.500 |
| 3 stop and +3R on one bar | 252 | STOP_HIT | 1 | 90.00 | −1.000 |
| 4 +3R partial then breakeven | 252 | STOP_HIT | 2 | 100.00 | +1.000 |
| 5 EMA break after promotion | 3 | EMA_BREAK | 5 | 108.00 | +0.800 |
| 6 STALL_EXIT below the R floor | 3 | STALL_EXIT | 4 | 104.00 | +0.400 |
| 7 R floor boundary, r == 1.0 | 3 | *(promotes, still open)* | — | — | +1.100 |
| 8 queued exit fills at the next open | 3 | STALL_EXIT | 4 | 95.00 | −0.500 |
| 2b the ENTRY BAR pierces the stop | 252 | STOP_HIT | 0 | 90.00 | −1.000 |
| 5b promotion bar already under the EMA | 3 | EMA_BREAK | 5 | 108.00 | +0.800 |
| 7b the same bars at 252 | 252 | *(inert, still open)* | — | — | +1.100 |
| 3b case 3's bar under `ohlc` | 252 | STOP_HIT | 1 | 100.00 | +1.000 |
| 4b partial and breakeven on one bar | 252 | STOP_HIT | 1 | 100.00 | +1.000 |
| 8b queued exit + gap through the stop | 3 | STALL_EXIT | 4 | 85.00 | −1.500 |
| 9 partial truncation, 32 shares | 252 | STOP_HIT | 2 | 100.00 | +0.938 |
| 10 bar opens above +3R | 252 | STOP_HIT | 2 | 100.00 | +1.200 |
| 11 opens above +3R, trades under the stop | 252 | STOP_HIT | 1 | 100.00 | +1.000 |

These are the engine's answers, hand-derived from `on_tick` / `on_close` /
`on_session_open` first and then confirmed against it — not read off and
blessed. Cases 10 and 11 are where the harness DISAGREES; the runner pins its
values rather than asserting agreement (see RECHECK).

---

## What the sabotage proof caught, including in this fixture

The proof is run against throwaway copies; the real repo is never touched. Each
patch asserts its anchor matched exactly once before replacing.

| planted defect | caught by |
|---|---|
| `elif` → `if` in `on_close` | case 5b |
| `STALL_R_FLOOR` `<` → `<=` | case 7 |
| queued exit booked at the signal bar's close | cases 6, 8, 8b |
| `int()` truncation removed from the partial | case 9 |
| stop / +3R precedence flipped in `_on_tick` | **nothing — and that is the finding** |

The first version of this fixture missed two of these. Cases 5b and 9 exist
because the sabotage proof found the holes; case 9 uses 32 shares specifically
because `int`, `round` and the exact fraction all disagree there.

The last row is a result in its own right. `prove_precedence_unreachable()`
shows no tick can satisfy both branches: before the partial the stop sits at
`entry − risk`, so `price ≤ stop` implies `r ≤ −1`, never `≥ 3`; after the
partial, `partial_done` closes the branch permanently. **The stop-versus-partial
ordering inside `engine_v2` can never bind.** The same-bar question is therefore
decided entirely by the backtest's ambiguity convention, with nothing on the
production side to diff against — and cases 3 vs 3b price that choice at **2.0R
per ambiguous bar** (−1.0R under `worst`, +1.0R under `ohlc`).

---

## EMA side-experiment

Production's EMA is `providers.ema`: SMA-seeded, `k = 2/(period+1)`, over
`yf.Ticker(t).history(period="120d")` — roughly 82 trading bars, including the
current session's close.

Measured against three plausible harness alternatives: mean absolute difference
**0.0057**, max **0.0157** (0.01% of price), **zero decision flips**, and zero
bars sitting close enough to the EMA to have flipped. The SMA seed washes out
after ~82 bars, so the seeding question is empirically dead.

The one that looked dangerous — a harness lagging its EMA by one bar to avoid
look-ahead — is dead for a better reason. Since `e_t = k·c_t + (1−k)·e_{t−1}`,

```
c_t < e_t  ⟺  (1−k)·c_t < (1−k)·e_{t−1}  ⟺  c_t < e_{t−1}
```

for any `0 < k < 1`. **The `close < EMA21` decision is invariant to whether the
EMA includes the current close.** Confirmed over 572,181 pairs as well as
algebraically. A harness that lags its EMA cannot disagree with production on
the trail for that reason alone.

---

## Definition of done, against Rev 3 §6

- [x] a differential fixture exists and covers all eight required cases
- [x] it has been shown to fail — four planted defects, each caught by a named case
- [x] it drives the real `engine_v2`, not a description of it
- [ ] **both engines agree on every case, or every disagreement is documented**
      — blocked on `minervini_backtest.py`

Until that last box is ticked, F8 is not closed. What is closed is the reference
half: the fixture is built, proven able to fail, and its production-side answers
are the engine's own.

---

## What NOT to do

- Do not "fix" the harness to match `engine_v2` before establishing which is
  correct. `engine_v2` wins ties because it is the code that trades — but a
  disagreement might reveal a bug in `engine_v2`, and that is worth more than a
  matching number.
- Do not run the comparison only at `STALL_DAY = 252`. It cannot reach the trail
  or stall paths. Every case here states its own value.
- Do not edit `PARAMETER_FREEZE`'s numbers. Nothing in this work authorises a
  parameter change.

---

## Four things the diff surfaced that are NOT exit-logic disagreements

**1. The optimistic bound is unattainable, not merely optimistic.** Case 3b is
excluded from the agreement test because the two sides mean different things by
"optimistic". The engine side's `ohlc` is a coherent intraday path: price
reaches +3R, the partial fires, the stop moves to breakeven, and the bar's own
low then takes the runner out at breakeven -> **+1.0R**. The harness's
`ambiguity_mode="best"` takes the partial and then does NOT apply the new
breakeven stop on that bar (line 707-711 closes only `if worst`), so the
position survives a bar whose low was 88 while carrying a stop at 100 ->
**+2.33R**. The harness says so itself at line 46: *"neither run is a coherent
intraday path -- they are BOUNDS."* Since the standing decision rule ranks on
the conservative bound only, parameter selection is unaffected -- but the
reported BAND WIDTH overstates the real uncertainty, because its upper edge is
not reachable by any price path.

**2. The +3R partial never enters a Trade record.** `Trade.r_at_exit` is the
final leg only -- the harness says so at line 699. Case 4 is +1.0R
share-weighted (10sh at +3R, 20sh at breakeven) and **0.0R in the harness's own
trade log**; case 9 is +0.938R vs 0.0R. The partial's profit lands in `cash` and
`partial_pnl` instead. So any expectancy computed by averaging `r_at_exit` over
trades **systematically understates every partialled trade**, and the 57-of-200
trades that reached the trail via the partial (Rev 3 R2) are exactly the
population affected. This is an accounting question about how Rev 3's +0.330R
was computed, not a defect in either engine. The diff reports it on every case
where the two R figures differ.

**3. The fill rule looks ALREADY FIXED in this file.**
`FREEZE_REV3_CORRECTIONS_20260822.md` sec.3 -- *"the fill rule is wrong, and it is
the biggest correction"* -- says the harness fills on `high >= limit`. This file
does not. Line 617-633 reads:

```python
if o > plan.limit_price:
    ambiguous_bars += 1
    if cfg.ambiguity_mode == "best" and lo <= plan.limit_price:
        try_fill(tkr, plan, plan.limit_price, d)
    else:
        drops.add(d, tkr, "gap_above_limit: resting limit unfilled")
elif h >= plan.pivot:
    try_fill(tkr, plan, plan.limit_price, d)
```

That is the corrected rule the corrections document asks for -- gap-above-limit
is refused under `worst`, and the trigger is `high >= pivot` with the fill at
the capped limit, not `high >= limit`. `grep` finds no `high >= limit` path
anywhere in the file. **Re-read sec.3 against this file before spending the
estimated ~3 hours on it.** Either the correction was already applied, or the
document is describing a different version.

**4. There is no vendored `kistrader/` package in the archive.** The harness
imports `kistrader.entry.decision_engine` with a fallback to a bare
`decision_engine`; neither exists in the supplied tree, so the import resolves
to whatever `kistrader` is installed -- which is PRODUCTION's. That matters
beyond F8: `run()` line 460 constructs `DecisionEngine(replace(cfg.decision,
rs_weight=..., stage2_weight=...))` and never sets `vcp_weight`, while
production's `DecisionConfig` defaults it to **1.0**. Combined with
`stage2_score := vcp_score` at line 861:

```
vcp_only   0*RS + 1*vcp + 1.0*vcp = 2*vcp   -> same ordering, harmless
rs_only    2*RS + 0     + 1.0*vcp           -> SILENTLY ranks on RS + VCP
```

**This is Problem 2's trap, and it is live right now** -- not a hazard to avoid
while fixing, but the current state of any run made without the vendored copy
present. F8 is unaffected (it runs `vcp_only`, where the double-count collapses
to `2*vcp` and leaves the ordering unchanged, and every case has one candidate),
but no `rs_only` or `rs_plus_vcp` number produced in this configuration means
what its name says.

---

# RECHECK, 2026-08-22 (second pass)

The first pass reported "13 of 13 cases agree" and called F8 closed. That claim
was too strong: the same person chose the cases AND derived the expected
answers, so it could only find defects on paths someone thought to write down.
`fuzz_f8.py` was written to attack it -- thousands of random bar sequences
through both engines. It found four things.

## Two bugs in this fixture, both of which made the engines look more alike

**A. The entry bar had an open tick it should not have had.** The position does
not exist until the breakout fills it intraday, so the bar's open happened
before we were in and cannot trigger anything. A bar that opened at 85, ran
through the pivot (filling at 100) and printed a high of 105 was being exited at
85 instead of at the stop -- **0.5R of phantom loss on every entry bar that
gapped**. The harness had this right all along, explicitly. Now case **2b**.

**B. A gap-up partial silently skipped its own breakeven stop.** When a bar
OPENS at or above +3R the partial fires on the first tick, and `engine_v2`
confirms a partial on the NEXT call -- so without a confirmation tick the
position stayed `partial_pending` for the rest of the bar, `partial_done` never
became True, and the same-bar breakeven retest never ran. That spared the runner
a stop-out it should have taken. This was the only DECISION-LAYER disagreement
in 3000 trials, and it was mine.

Neither was reachable from any of the fourteen hand-written cases. Both are
fixed; both directions of error flattered the agreement.

## Two real harness defects, one root cause

The harness decides the +3R partial from the bar's HIGH alone and fills it at
exactly the +3R level, ignoring the OPEN -- even though it already honours the
open for the stop (`o if o < pos.stop_loss_price else pos.stop_loss_price`).

**Case 10 -- the bar opens above +3R.** `engine_v2` polls from the open, sees
136.00, and `r_multiple(136) = 3.6 >= 3` fires the partial THERE. The harness's
`fill = slip_sell(partial_level)` is unconditional, so it books 130.00. Reason,
bar and exit price all agree; only the partial leg differs, by the size of the
gap. **48 of 1013 partialled trades (4.7%) in a 12,000-trial sweep.**

**Case 11 -- it opens above +3R and also trades below the original stop.** The
harness sees stop and +3R both inside `[low, high]`, calls it ambiguous, and
applies stop-first. But the bar OPENED at 130: the +3R was reached at the open,
so the stop cannot have preceded it and there is nothing to resolve. Production
books **+1.0R**, the harness **-1.0R** -- a **2.0R divergence**. Rare (2 in
12,000) but not exotic: a gap-up that reverses hard is an earnings day.

Both understate, so Rev 3's numbers remain a lower bound in this respect --
the safe direction. Both are now pinned as cases 10 and 11: the runner asserts
the harness produces exactly those values, so the divergence is
regression-guarded rather than merely known.

## The sweep as it stands

```
12,000 random scenarios, seed 20260822    11,950 agree    50 disagree
   4,000 x 3 independent seeds (1, 7, 99999)              17 / 14 / 16 disagree
paths exercised: STOP_HIT 10,599 | partial taken 1,013 | still open 653
                 STALL_EXIT 413  | EMA_BREAK 335
every disagreement in a characterised class; ZERO unknown divergence
```

`fuzz_f8.py` exits 0 only while every disagreement falls into a class cases 10
and 11 pin. A new class fails the run. Run it after touching either engine:

```powershell
python fuzz_f8.py --prod-root ... --harness ... --trials 12000
```

## What F8's answer actually is, stated precisely

The harness's exit engine reproduces `engine_v2`'s **decision layer** --
which reason, on which bar -- on 11,950 of 11,950 scenarios where the bar does
not open beyond the +3R level, and on every one of the 15 hand-built cases. Two
characterised divergences remain, both in the +3R partial's FILL, both
conservative, both now pinned.

That is a materially stronger claim than the first pass made, and it is the one
the evidence supports.