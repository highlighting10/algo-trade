# kistrader — KIS Minervini/VCP Trading System

Algorithmic swing-trading system for US equities (Minervini SEPA / VCP) executing
through the Korea Investment & Securities (KIS) overseas API. Screeners pick
candidates; the entry half sizes/arms them with confirmation-based fills; the exit
engine manages stops, partials, and trailing — all "confirm, never infer".

Packaged for deployment: `pip install .`, configure via `.env`, run with one command.

## Install

```bash
git clone/unzip → cd kis-trader
python -m venv .venv && . .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -e .                                   # installs `kistrader` + deps
pip install -e ".[trail]"                          # + yfinance/pandas for EMA-trail/stall
```

No install needed to just run: from the repo root, `python -m kistrader.cli …` works too.

## Configure

```bash
cp .env.example .env      # then edit .env with your KIS *mock* credentials
```

`.env` (git-ignored) — mock and live accounts have different app keys:

```
KIS_APP_KEY=...     KIS_APP_SECRET=...   KIS_CANO=12345678   KIS_PRDT=01
KIS_MOCK=1          KIS_EQUITY_USD=100000
```

## Run

```bash
kistrader test                 # all 9 suites, 497 checks — no account/network
kistrader verify               # MONDAY, US hours: prove write paths + dump the 3 field names
kistrader verify --allow-fill  #   ...also test fill reads (spends mock cash)
kistrader run --once --arm     # build pipeline, arm today's candidates, one cycle (smoke)
kistrader run --arm            # forward-test loop (mock unless KIS_MOCK=0)

# 497 = entry_half 135 + pipeline_e2e 100 + screener_harness 85
#     + exit_state_machine 59 + candidate_emit 32 + point_in_time 25
#     + breakout_volume 23 + seed_position 23 + boot_params 15
#                                              (counted, not estimated)
#
# On main: 497/497 green.
# On a TECHNICAL soak branch (VCP_SCORE_THRESHOLD 45) EXACTLY TWO are red BY
# DESIGN -- test_entry_half 'threshold is 75' and test_boot_params 'live: no
# refusal when the set matches'. Those are DRIFT GUARDS. Red there is the
# pass condition; green would mean the guard is broken, not that the tree is
# clean. Do not 'fix' them to make the suite green -- they are what stops a
# 45-threshold soak build from being started against a live account.
# A THIRD red on a soak branch is a real finding.
```

(Equivalently `python -m kistrader.cli <cmd>` without installing.)

## Layout

```
kis-trader/
├─ pyproject.toml          # installable; `kistrader` console entry point
├─ .env.example            # copy to .env (git-ignored)
├─ conftest.py             # pytest/path shim
├─ kistrader/              # the package
│  ├─ config.py            #   env-driven config (+ minimal .env loader)
│  ├─ cli.py               #   `kistrader test | verify | run`
│  ├─ core/                #   ⚠ VERIFIED — byte-identical to prod, treat read-only
│  │  ├─ engine_v2.py      #     exit engine (stops/partials/trail/stall, event store, recovery)
│  │  ├─ run_loop.py       #     US session clock + poll loop
│  │  └─ kis_tradable_universe.py
│  ├─ entry/               #   the entry half (this project)
│  │  ├─ screen_contract.py   #   Candidate schema + CSV/JSON + screener adapter (§1.6)
│  │  ├─ decision_engine.py   #   rank → select → ATR stop → equal-R size (pure)
│  │  ├─ entry_manager.py     #   arm/confirm/adopt; buying-power + open-order gates
│  │  ├─ pipeline.py          #   build_pipeline() — full wiring
│  │  └─ providers.py         #   daily-close + 21-EMA (activates trail/stall exits)
│  └─ tools/
│     └─ contract_verify.py   #   the `verify` command's implementation
├─ screeners/             # YOUR screeners (sp500_v21 & us_small_v21 = §1.6-patched)
├─ tests/                 # 9 suites, 497 checks: entry_half 135, pipeline_e2e 100,
                          #   screener_harness 85, exit_state_machine 59,
                          #   candidate_emit 32, point_in_time 25,
                          #   breakout_volume 23, seed_position 23,
                          #   boot_params 15
└─ docs/                  # DEVELOPMENT_CHECKLIST.md, screener_patch_1_6.md,
                          # KIS_mock_trading_guide_ko.md
```

## Data flow

```
screeners/*.py ─► candidates.csv ─► [gate] ─► [decision_engine] ─► [entry_manager] ─► core exit engine
   Stage1/2/3      screen_contract   tradable   rank/size/stop      arm→confirm fill    stops/partials/trail
```

## Deploy notes

- **Verified core is untouched** (`kistrader/core/` is byte-identical to your uploads);
  the entry half depends only on its already-verified broker reads.
- **Tests need no third-party packages** (stdlib + in-memory fakes). `requests` is the
  only base dependency (for live KIS calls); `[trail]` adds yfinance/pandas.
- A few fields in `entry/` still carry `# VERIFY` — confirm them with `kistrader verify`
  (it dumps the raw KIS responses). Until then, `run` uses safe fallbacks.
- Status & what's left: `docs/DEVELOPMENT_CHECKLIST.md`. KIS mock setup:
  `docs/KIS_mock_trading_guide_ko.md`.
```
