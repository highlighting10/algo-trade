#!/usr/bin/env python3
"""
probe_recent_closed_r.py -- run the SHIPPED read against REAL closed trades.

Every check in apply_e10_layer2.py --verify used a store I built by hand, so
every payload had exactly the keys I chose to write. This runs the same
function against the box's own database.

WHAT IT PROVES        real payloads parse; the R values and their signs are
                      sane; the MEASURED NaN rate, i.e. how much of the
                      partial-fill-price gap (RESULT_20260919_E10 sec.5) is
                      real rather than estimated.
WHAT IT DOES NOT      that arm_today calls it at the right moment, that
                      self.mon.db is the right object at runtime, that the
                      LOSS_STREAK alert renders in a live session, or that the
                      ceiling reaches plan(). Only a session with the gate ON
                      shows those.

Run on the LAPTOP, on branch e10-progressive-exposure, against the COPY:

    python probe_recent_closed_r.py probe.db
"""
from __future__ import annotations

import argparse
import json
import math
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from kistrader.core.engine_v2 import EventStore                    # noqa: E402
from kistrader.entry.exposure_controller import (                  # noqa: E402
    DEFAULT_LOSS_STREAK_CEILINGS, ExposureConfig, ExposureController,
    loss_streak_from, streak_ceiling)

LIVE_NAME = "kis_engine_state.db"


def rows(db_path, limit):
    """The same set recent_closed_r() reads, plus the fields behind each
    verdict. Queried separately so the table and the function can disagree
    visibly if the function is wrong."""
    con = EventStore(db_path).conn
    out = []
    for ts, key, et, price, payload in con.execute(
            "SELECT ts, order_key, event_type, price, payload "
            "FROM position_events WHERE event_type LIKE 'CLOSED:%' "
            "AND payload IS NOT NULL ORDER BY id DESC LIMIT ?", (limit * 4,)):
        try:
            d = json.loads(payload)
        except Exception:                          # noqa: BLE001
            d = {}
        out.append((ts, key, et, price, d))
    con.close()
    return out


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[1].strip())
    ap.add_argument("db", nargs="?", default="probe.db",
                    help="path to the COPY of the event store")
    ap.add_argument("--limit", type=int, default=200,
                    help="how many closes to inspect (default 200)")
    ap.add_argument("--force-live", action="store_true",
                    help="allow running against a file named " + LIVE_NAME)
    a = ap.parse_args(argv)

    if not os.path.isfile(a.db):
        raise SystemExit(f"no such database: {a.db}")
    # EventStore.__init__ runs CREATE TABLE IF NOT EXISTS and PRAGMA
    # journal_mode=WAL -- it WRITES. Never point it at a live trader's file.
    if os.path.basename(a.db) == LIVE_NAME and not a.force_live:
        raise SystemExit(
            f"REFUSING: {a.db} is the live database name. EventStore writes on "
            f"open (CREATE TABLE, PRAGMA journal_mode). Use a copy made by "
            f"box_backup_db.py, or pass --force-live if this really is a copy.")

    print("=" * 78)
    print(f"recent_closed_r() against REAL data -- {a.db}")
    print("=" * 78)

    detail = rows(a.db, a.limit)
    seen, table = set(), []
    for ts, key, et, price, d in detail:
        if key in seen:
            table.append((ts, key, et, price, d, "DUP (skipped)"))
            continue
        seen.add(key)
        risk = d.get("initial_risk_per_share")
        try:
            risk_f = float(risk or 0.0)
        except (TypeError, ValueError):
            risk_f = 0.0
        if d.get("partial_done"):
            why = "NaN partial_done"
        elif risk_f <= 0:
            why = "NaN risk<=0"
        elif price is None:
            why = "NaN no price"
        else:
            try:
                why = "%+.3f R" % ((float(price) - float(d["entry_price"])) / risk_f)
            except (TypeError, ValueError, KeyError):
                why = "NaN unparseable"
        table.append((ts, key, et, price, d, why))

    if not table:
        print("\n  NO CLOSED TRADES IN THIS DATABASE.")
        print("  The read is unexercised on real data. That is a result, not a")
        print("  failure -- it means the box has not closed a trade into this")
        print("  store yet. Re-run after the soak produces closes.")
        return 0

    print(f"\n  {len(table)} CLOSED event(s), newest first\n")
    print(f"  {'ts':<20} {'order_key':<20} {'entry':>9} {'exit':>9} "
          f"{'risk/sh':>9} {'part':>5}  verdict")
    print("  " + "-" * 92)
    for ts, key, et, price, d, why in table:
        print(f"  {str(ts)[:19]:<20} {str(key)[:20]:<20} "
              f"{_n(d.get('entry_price')):>9} {_n(price):>9} "
              f"{_n(d.get('initial_risk_per_share')):>9} "
              f"{str(bool(d.get('partial_done'))):>5}  {why}   {et}")

    # ---- what the function itself returns ----
    st = EventStore(a.db)
    vals = st.recent_closed_r(limit=a.limit)
    default_vals = st.recent_closed_r()          # the production window (20)
    st.conn.close()

    nan = sum(1 for v in vals if math.isnan(v))
    loss = sum(1 for v in vals if not math.isnan(v) and v < 0)
    win = sum(1 for v in vals if not math.isnan(v) and v > 0)
    scratch = sum(1 for v in vals if v == 0)

    print("\n" + "-" * 78)
    print(f"  recent_closed_r(limit={a.limit}) returned {len(vals)} value(s)")
    print(f"    loser  R<0   {loss}")
    print(f"    winner R>0   {win}")
    print(f"    scratch R==0 {scratch}")
    print(f"    NaN          {nan}"
          + (f"   <-- {nan / len(vals):.0%} of real closes are UNSCORABLE"
             if vals else ""))
    print("\n  THE MEASURED GAP. Each NaN ENDS a streak rather than extending")
    print("  it, so a high rate here means the gate bites less often than its")
    print("  rung numbers suggest. Closing it needs the partial fill price")
    print("  recorded at _finalize_partial.")

    streak = loss_streak_from(default_vals)
    cap = streak_ceiling(DEFAULT_LOSS_STREAK_CEILINGS, streak)
    print("\n" + "-" * 78)
    print(f"  production window (limit=20): {[_r(v) for v in default_vals]}")
    print(f"  loss_streak_from(...)       = {streak}")
    print(f"  streak_ceiling(DEFAULT, {streak})  = {cap:.2f}")

    on = ExposureController(ExposureConfig(
        loss_streak_ceilings=DEFAULT_LOSS_STREAK_CEILINGS))
    d_on = on.decide(None, None, True, loss_streak=streak)
    d_off = ExposureController().decide(None, None, True)
    print(f"\n  IF the gate were ON today: {d_on.state.value} "
          f"ceiling {d_on.max_portfolio_exposure_pct:.0%}")
    print(f"     {d_on.reason}")
    print(f"  AS SHIPPED (gate OFF):     {d_off.state.value} "
          f"ceiling {d_off.max_portfolio_exposure_pct:.0%}")
    print("\n  Nothing was traded and nothing was written to the box.")
    print("=" * 78)
    return 0


def _n(v):
    try:
        return "%.4f" % float(v)
    except (TypeError, ValueError):
        return "-"


def _r(v):
    return "NaN" if math.isnan(v) else "%+.2f" % v


if __name__ == "__main__":
    sys.exit(main())
