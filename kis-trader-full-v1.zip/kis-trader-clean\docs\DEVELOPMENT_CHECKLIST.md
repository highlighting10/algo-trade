# Trading System — Full Development-Cycle Checklist

Status legend: `[x]` done & verified · `[~]` partial / in progress · `[!]` built but NOT yet
proven against reality · `[ ]` not started

> Note: screener internals (§1) reflect prior sessions and are from memory — adjust to your
> actual code. Everything in §2–§5 and §7 was built/verified in the current sessions.

**Where you are right now:** exit engine + run loop + tradability gate = built & tested. The
**entry half (§3) is built and passes 85/85 mock invariants + a 17/17 end-to-end integration
test** that drives the assembled pipeline (arm → fill → handoff → stop-exit, recovery routing,
on_close wiring) offline with fakes. Both HIGH/MED entry residuals are closed (§3.9.1
crash-orphan double-BUY, §3.9.2 adopt baseline); the §1.6 coupling fails loud/safe; EMA/close
providers (§5.4) activate the trail/stall exits; cosmetics clean; write-path verifier written.
What remains before live is purely **contact with KIS**: run `kis_contract_verify.py` Monday to
confirm 3 field names, then the live end-to-end + ~3-month forward runs. `engine_v2.py` is
byte-identical to your upload — the verified exit core was never touched. Roughly: US exit half
done & tested; US entry half built, mock-tested (85/85) and integration-tested (17/17) with both
entry residuals retired; live-proving is the gate; non-US markets deferred.

---

## 1. Screener Suite `[~]`
- [x] **1.1 Stage 1 — Minervini Trend Template**
  - [x] 1.1.1 MA structure (50/150/200) + slope
  - [x] 1.1.2 price vs 52-week high/low thresholds
  - [x] 1.1.3 full 8-criteria trend gate
- [x] **1.2 Stage 2 — Ranking & fundamentals**
  - [x] 1.2.1 RS Rating (IBD percentile, two-pass, segmental ratios)
  - [x] 1.2.2 Finnhub math floor (0–45)
  - [x] 1.2.3 Gemini qualitative (0–55), batched (~10/call)
  - [x] 1.2.4 Stage 2c selective grounding (high-RS rejects, web_search verify)
  - [x] 1.2.5 CATALYST_SCORE_THRESHOLD tuned (55→40)
- [x] **1.3 Stage 3 — VCP engine**
  - [x] 1.3.1 ATR-hybrid ZigZag swing detection
  - [x] 1.3.2 depth / volatility / wave-count / down-vol dry-up / time contraction
  - [x] 1.3.3 pivot lock + breakout proximity tiers
  - [x] 1.3.4 per-universe benchmarks (^GSPC / EFA / EWY)
- [x] **1.4 Universe modules**
  - [x] 1.4.1 S&P 500  *(executable)*
  - [x] 1.4.2 US small-cap  *(executable; some names not on KIS — see §2)*
  - [~] 1.4.3 MSCI ex-US  *(screening done; execution unsupported — see §6)*
  - [~] 1.4.4 MSCI Korea  *(screening done; needs domestic-API engine — see §6.3)*
- [x] **1.5 Regression tests** (`test_screeners_v21.py`, AST static-ref guard)
- [~] **1.6 Output contract for the entry half**  *(consumer side built, hardened & tested;
      producer patch documented, pending application — `screen_contract.py`)*
  - [~] 1.6.1 emit per name: ticker, exchange, RS%, Stage2%, VCP depth, ATR, pivot, base-low→stop
    - **Patch APPLIED to `sp500_v21.py` + `us_small_v21.py`** (3 lines in `generate_report()`'s
      `Extracted_Pattern`: `Base_Low` = `base_df['Low'].min()`, `Latest_Close`, `Latest_ATR`).
      Verified: compiles, diff is exactly the 3 lines, keys match the adapter exactly.
      ⬜ Still to patch: MSCI ex-US + MSCI Korea screeners (identical block).
  - [x] 1.6.1a **Coupling hazard SOLVED (consumer-side, fail-loud/fail-safe).** Missing
      `Latest_Close` no longer defaults to pivot: it sets `close_known=False`, and the decision
      engine **fails closed** (rejects with an explicit, actionable reason) unless
      `allow_missing_close=True`. Missing `Latest_ATR` → structural-only stop that is **labelled**
      (`EntryPlan.stop_basis`) and logged at arm, never silent. `require_atr=True` makes even that
      a hard reject. Covered by test **I10** (14 checks). Net: without the producer patch the
      pipeline arms *nothing* (loud) instead of trading with disabled guards (silent).
  - [x] 1.6.2 stable schema (CSV/JSON, versioned→v2, fail-closed reader, provenance preserved)
- [~] **1.7 Known debt**
  - [ ] 1.7.1 Gemini key stored plaintext (`chmod 600` no-op on Windows) — move to env/secret

## 2. Tradability Gate (`kis_tradable_universe.py`) `[x]`
- [x] 2.1 master download (nas/nys/ams `.cod`) — URLs verified vs official repo
- [!] 2.1a first `--refresh` on your machine (download domain unreachable from build env)
- [x] 2.2 parse (25-col tab, symbol @ index 4) + encoding fallback
- [x] 2.3 cache + freshness window
- [x] 2.4 `resolve()` / `filter()` + symbology variants (BRK-B ↔ BRK.B)
- [!] 2.5 wire into pipeline (screener output → gate → decision engine) — built in
      `pipeline.PipelineLoop.arm_today()` (gates candidates, stamps exchange); not yet proven end-to-end

## 3. Decision Engine / Entry Half `[!]`  ← BUILT & MOCK-TESTED (not proven live)
> Files: `decision_engine.py` (pure), `entry_manager.py` (stateful, mirrors ExecutionMonitor;
> now with `list_open_order_tickers`), `screen_contract.py` (contract), `pipeline.py` (wiring),
> `providers.py` (§5.4 EMA/close), `kis_contract_verify.py` (§7.3 write-path prover),
> `test_entry_half.py` (**85/85**), `test_pipeline_e2e.py` (**17/17** integration). Safety rests only on already-verified broker reads; fill
> price + buying power are refinements with safe fallbacks. **engine_v2.py is byte-identical to
> your upload — the verified exit core was never touched.**
- [x] 3.1 Portfolio Rank Score (2×RS% + Stage2%) — deterministic, unit-tested
- [x] 3.2 Top-N selection (N_max = 8) + exposure/sector caps — greedy, deterministic order
- [x] 3.3 Position sizing (equal-R, adaptive ATR mult 1.3–2.5 via VCP depth, single-name cap)
- [x] 3.4 Stop derivation (structural base-low ⊓ ATR-floor; reject if risk > max_stop_pct)
      → `initial_risk_per_share` frozen from the REAL fill, not the plan
- [!] 3.5 `PENDING_ENTRY` arming — tri-state, settle-gated, positive-evidence-only (mock-tested)
  - [!] 3.5.1 place entry limit (BUY) at `pivot·(1+chase)`; reject if too extended
  - [!] 3.5.2 entry fill confirmation (`get_fills` qty authority; None → hold)
  - [x] 3.5.3 construct FILLED `Position` on fill → hand to monitor (I9: real monitor drives it)
  - [!] 3.5.4 entry timeout / partial-entry / rejection handling (partial = real position, tested)
- [x] 3.6 dedup vs existing holdings & open orders
  - [x] 3.6.1 dedup vs broker holdings + in-flight `_pending` (I6)
  - [x] 3.6.2 dedup vs OPEN ORDERS we didn't record — done via §3.9.1 (I11)
- [!] 3.7 buying-power / cash check before arming — cumulative gate + fail-safe refusal on
      UNKNOWN (tested); provider itself unverified (see §3.10)
- [x] 3.8 entry-half tests (mock) — `test_entry_half.py`, I1–I14 + contract round-trip, **85/85**;
      plus `test_pipeline_e2e.py` integration, **17/17**

- [~] **3.9 Entry-half residual risk (from code assessment)** — 3.9.1 & 3.9.2 closed; 3.9.3 open
  - [x] 3.9.1 **HIGH — crash-orphan double-BUY window — CLOSED.** Added
        `KISBrokerWithEntry.list_open_order_tickers()` (paginated `inquire-nccs`; reuses the
        already-verified `odno`, ticker from `pdno`) and folded resting-order tickers into
        `arm_batch` dedup. An UNTRACKED resting order is refused (no double-BUY); a TRACKED one
        (our prior arm) still adopts idempotently — I1 + I11 both pass. UNKNOWN open-order read
        is fail-safe (refuse), mirroring the buying-power gate (`require_open_order_check`,
        default True). ⚠ One field to confirm Monday: `pdno` == ticker on `inquire-nccs`
        (folded into §7.3; verifier dumps it).
  - [x] 3.9.2 **MED — `adopt()` baseline assumption — CLOSED.** Entry now captures the ticker's
        holding at arm and credits only `held − baseline` as this order's fill, so a pre-existing
        same-ticker position can't be mis-read as a phantom fill. After a crash the baseline is
        unknown (adopt doesn't recapture it), so recovery relies on executions + the settle
        timeout and never infers from raw holdings. Tested I14 (adopt case + normal backstop).
  - [ ] 3.9.3 **MED (inherited) — `get_fills` single-page.** No `inquire-ccnl` pagination; a
        fill beyond page 1 reads as 0. Entry path is saved by the paginated holdings backstop —
        but that dependency is now load-bearing on both halves. Consider paging `get_fills`.
- [~] **3.10 Entry-half unverified I/O (safe fallbacks in place; VERIFY before live trust)**
  - [ ] 3.10.1 `KISBrokerWithEntry.get_fills_detail` VWAP — confirm price field `ft_ccld_unpr`
        on overseas `inquire-ccnl` (falls back to BUY limit if absent → conservative)
  - [ ] 3.10.2 buying-power provider — confirm TR (`TTTS3007R`/`VTTS3007R`), `inquire-psamount`
        params, and USD orderable-amount field (returns None → fail-safe refuse if unverified)
- [x] **3.11 Cosmetic cleanup — DONE.** Removed dead imports and the `for p in armed` loop;
      `pipeline._account_state` now reads cash from the buying-power provider (advisory; the
      enforced cash gate stays in `arm_batch`). All four modules scan clean.

## 4. Execution / Exit Engine (`engine.py` / `engine_v2.py`) `[x]`
- [x] **4.1 Broker layer**
  - [x] 4.1.1 auth / token caching
  - [x] 4.1.2 TR_IDs — live `T`-prefix corrected (verified vs repo)
  - [x] 4.1.3 `get_quote` — bid read from `output2`
  - [x] 4.1.4 `get_holding` / `get_all_holdings` — paginated (H1)
  - [x] 4.1.5 `get_fills` — `inquire-ccnl` full params (safety-critical fix)
        *(note: returns None only on API failure — never 0 on parse error; the entry half now
        depends on this. Single-page — see §3.9.3.)*
  - [x] 4.1.6 `get_order_status` — nccs paging fields
  - [x] 4.1.7 `place_limit_order` / `cancel_order` — body parity
  - [x] 4.1.8 rate limiter (token bucket, M3)
  - [!] 4.1.9 mock write-paths proven vs real account  ← Monday (now also covers entry BUY/cancel)
- [x] **4.2 Exit state machine**
  - [x] 4.2.1 synthetic stop (STOP_HIT)
  - [x] 4.2.2 3R partial + breakeven move
  - [!] 4.2.3 EMA trail (logic done; provider built & wired via §5.4 — not yet proven on a live close)
  - [!] 4.2.4 stall exit (day-10) (logic done; provider built & wired via §5.4 — not yet proven live)
  - [x] 4.2.5 reprice loop / order aging
  - [x] 4.2.6 oversell clamp
  - [x] 4.2.7 tri-state UNKNOWN handling
  - [x] 4.2.8 settle window (ambiguous GONE)
- [x] **4.3 Persistence & recovery**
  - [x] 4.3.1 append-only SQLite event store
  - [x] 4.3.2 snapshot recovery + idempotent re-adoption
  - [x] 4.3.3 positive-evidence reconcile (C1)
  - [x] 4.3.4 monotonic-timer rebase on restart (H2)
  - [x] 4.3.5 audit-delta logging
- [~] **4.4 Liveness**
  - [x] 4.4.1 watchdog (heartbeat → reconnect + reconcile)
  - [x] 4.4.2 periodic reconcile (M1 self-heal)
  - [ ] 4.4.3 WebSocket feed (REST-floor for now)
- [ ] **4.5 Residual logic debt**
  - [ ] 4.5.1 M2 — `_take_partial` band price-fallback
  - [ ] 4.5.2 M4 — confirm real KIS `PRICE_BAND`
  - [x] 4.5.3 `get_quote` 0/0-on-error guard — property already held at the only consumer
        (`run_loop._quote`: `last<=0 → None → tick skipped`; engine never calls get_quote
        internally). Verified engine untouched; pinned by regression test **I12**.

## 5. Run Loop / Scheduler (`run_loop.py`) `[x]`
- [x] 5.1 US session clock (manual DST + 2026 holidays)
- [x] 5.2 REST poll → on_tick / on_session_open / on_close / day-roll
- [x] 5.3 recover-on-start + watchdog wiring (positions_provider)
      *(entry-aware routing now lives in `pipeline.PipelineLoop.start()`: holdings → monitor,
      PENDING_ENTRY → `EntryManager.adopt()`; the tested `run_loop.py` itself is untouched)*
- [x] 5.4 EMA + daily-close providers — `providers.py` (`DailyCloseEMAProvider`, pure `ema()`,
      per-day cache, None-on-insufficient-data). Built & tested offline (**I13**) and forwarded
      through `build_pipeline(ema_provider=, close_provider=)`. Wire `build_yf_daily_fetch()` on
      your machine to feed real bars.
- [x] 5.5 bootstrap entrypoint (`run_forward_test.py`)
- [ ] 5.6 WebSocket integration (future accelerant)

## 6. Market-Coverage Extensions `[ ]`  (deferred — US first, per your scope)
- [ ] 6.1 non-US exchange codes in `_excg` (TSE / SEHK / SHAA / …)
- [ ] 6.2 multi-currency balance (`TR_CRCY_CD` per market)
- [ ] 6.3 KIS **domestic** API engine for MSCI Korea (separate engine)

## 7. Testing & Validation `[~]`
- [x] 7.1 Sim harness — 8 invariants (`kis_engine_simharness.py`) 8/8  (exit half)
- [x] 7.2 Contract verifier — read paths (auth/quote/balance/nccs/ccnl)
- [!] 7.3 Contract verifier — write paths — **script authored** (`kis_contract_verify.py`).
      Proves place/status/fills/cancel + `list_open_order_tickers`, and DUMPS raw JSON so you
      confirm the 3 field names (`ft_ccld_unpr`, psamount USD field, nccs `pdno`) in one pass.
      ← just RUN it Monday (US hours): `python kis_contract_verify.py [--allow-fill]`
- [ ] 7.4 Mock forward test — exit half, seeded position  ← Monday
- [x] 7.5 Entry-half tests (mock) — `test_entry_half.py` **85/85** + `test_pipeline_e2e.py` **17/17**
      (I11 orphan-dedup, I12 quote-guard, I13 EMA/close, I14 adopt-baseline; E1–E3 integration)
- [~] 7.6 End-to-end pipeline test (screener → gate → entry → manage → exit) — **offline
      integration test done** (`test_pipeline_e2e.py`, 17/17: full arm→fill→handoff→stop-exit,
      recovery routing both ways, §5.4 on_close wiring). Live end-to-end on the mock account still
      pending (needs §7.3 + candidates.csv).
- [ ] 7.7 ~3-month mock forward run (operational reliability, not alpha)

## 8. Ops / Production Hardening `[ ]`
- [ ] 8.1 Real alert sink (Slack / PagerDuty / SMS) wired to `alert`
- [ ] 8.2 Structured logging + rotation
- [~] 8.3 Secrets: env-var / secret-store (fix plaintext Gemini + KIS keys)
- [ ] 8.4 Process supervision / auto-restart
- [ ] 8.5 Health / metrics dashboard
- [ ] 8.6 Live-account cutover checklist (only after mock validation + §3.9.1 closed)

---

## Current Focus — next actions
**Done this weekend (Tier 1 + Tier 2 authoring + offline integration):** §3.9.1 orphan dedup
(HIGH) + §3.9.2 adopt baseline (MED) — both closed · §3.6.2 · §3.11 cleanup · §4.5.3 quote guard
(pinned) · §5.4 EMA/close providers (built, wired, on_close proven) · §7.3 verifier authored ·
§7.6 offline end-to-end integration test. Tests 44 → **85/85** unit + **17/17** integration.
`engine_v2.py` untouched.

Remaining — all gated on contact with KIS (nothing more to build first):
1. **Apply the screener §1.6 patch (3 lines)** from `screener_patch_1_6.md` to all 4 screeners,
   then generate a real `candidates.csv`. (Independent of KIS — do anytime.)
2. **Monday (US session): run the verifier (§7.3).** `python kis_contract_verify.py` then
   `--allow-fill`. Read the raw dumps and confirm 3 field names (`ft_ccld_unpr`, psamount USD
   field, nccs `pdno`). Fix any mismatch (one line each), flip §3.10/§3.9.1 field notes to `[x]`.
3. **Mock forward test (§7.4, §7.6):** seed → manage exits; then candidates.csv → gate → decision
   → arm → fill → hand to monitor → exit, on the paper account.
4. **Wire `build_yf_daily_fetch()`** into `DailyCloseEMAProvider` on your machine so the trail/
   stall exits get real daily bars, and confirm one live `on_close` fires (§4.2.3/4.2.4).
5. **~3-month operational run (§7.7)**, then the residual mediums (§3.9.2, §3.9.3) and ops (§8)
   before any live-money cutover.

### Policy knobs to confirm (defaults in `DecisionConfig`, not settled)
`risk_per_trade_pct` 0.75% · ATR band 1.3–2.5 over depth 8%→25% · `entry_chase_pct` 0.5% ·
`max_extension_pct` 5% · `max_stop_pct` 10% · `n_max`/`max_open_positions` 8 · `sector_cap` 2 ·
`max_position_pct` 25% · `require_trade_signal` False (arms without a confirmed breakout flag —
consider True for a strict breakout system) · `ENTRY_TIMEOUT_SECS` 120 · `CASH_BUFFER_PCT` 2% ·
`allow_missing_close` False (fail-closed if the §1.6 patch isn't applied) · `require_atr` False
(structural-only stop allowed but labelled) · `require_open_order_check` True (fail-closed if the
resting-order read is unavailable — §3.9.1).
