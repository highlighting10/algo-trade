#!/usr/bin/env python3
"""
F8 side-experiment -- is the harness's EMA21 the same number as production's?

The EMA trail is one of only two exits that can fire at STALL_DAY = 252, and it
accounts for 64 of the 225 trades in Rev 3 sec.2. If the two engines compute a
different EMA, they disagree about the trail on borderline bars EVEN IF the exit
logic is identical -- and that disagreement would be invisible to a diff that
supplies the same EMA to both sides (which the F8 fixture deliberately does, to
isolate one question at a time).

PRODUCTION'S DEFINITION, read off the code, not assumed:

    providers.ema(values, 21):  seed = SMA(values[:21]),
                                then e = v*k + e*(1-k), k = 2/(21+1)
    providers.build_yf_daily_fetch(lookback_days=120):
        yf.Ticker(t).history(period="120d")  ->  ~82 trading bars
    DailyCloseEMAProvider.ema():  ema(closes, 21) over that whole window,
        where closes[-1] is the MOST RECENT COMPLETED SESSION.

So on_close(pos, close, ema) compares a close against an EMA that INCLUDES that
same close, computed off a ~82-bar window with an SMA seed.

Three ways a harness commonly differs, all measured below:
  * pandas .ewm(span=21, adjust=True)   -- no SMA seed, weighted-average form
  * pandas .ewm(span=21, adjust=False)  -- recursive but seeded on the FIRST bar
  * the same SMA-seeded EMA over the FULL history instead of a 120d window

The number that matters is not the average error, it is DECISION FLIPS: bars
where `close < ema` is true under one definition and false under the other.
That is a trail exit gained or lost.

    python ema_compare.py --prod-root /path/to/kis-trader-clean
"""
from __future__ import annotations

import argparse
import math
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from engine_side import load_module   # noqa: E402

SPAN = 21
PROD_WINDOW = 82        # ~ trading bars inside yfinance period="120d"


def ewm_adjust_true(xs, span=SPAN):
    a = 2.0 / (span + 1.0)
    out = []
    num = den = 0.0
    for x in xs:
        num = x + (1 - a) * num
        den = 1.0 + (1 - a) * den
        out.append(num / den)
    return out


def ewm_adjust_false(xs, span=SPAN):
    a = 2.0 / (span + 1.0)
    out, e = [], None
    for x in xs:
        e = x if e is None else x * a + e * (1 - a)
        out.append(e)
    return out


def synthetic_closes(n=400):
    """A deterministic price path with trend, cycle and a shock -- no RNG, so the
    numbers are identical on every machine and quotable without a seed."""
    xs = []
    p = 100.0
    for i in range(n):
        drift = 0.0012
        cycle = 0.010 * math.sin(i / 9.0) + 0.004 * math.sin(i / 2.3)
        shock = -0.055 if i in (150, 151, 300) else 0.0
        p *= (1.0 + drift + cycle + shock)
        xs.append(round(p, 2))
    return xs


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--prod-root", required=True)
    ap.add_argument("--bars", type=int, default=400)
    args = ap.parse_args()

    P = load_module(os.path.join(args.prod_root, "kistrader", "entry", "providers.py"),
                    "f8_prod_providers_ema")
    closes = synthetic_closes(args.bars)

    print("=" * 78)
    print("F8 SIDE-EXPERIMENT -- EMA21 definition")
    print("=" * 78)
    print(f"  providers loaded from : {P.__f8_loaded_from__}")
    print(f"  synthetic closes      : {len(closes)} bars, deterministic (no RNG)")
    print(f"  production window     : last {PROD_WINDOW} bars (yfinance period='120d')")
    print("=" * 78)

    at, af = ewm_adjust_true(closes), ewm_adjust_false(closes)

    rows = []
    for t in range(PROD_WINDOW, len(closes)):
        window = closes[max(0, t - PROD_WINDOW + 1): t + 1]
        prod = P.ema(window, SPAN)                 # what the box actually computes
        full = P.ema(closes[: t + 1], SPAN)        # same formula, full history
        lag = P.ema(closes[: t], SPAN)             # EMA as of YESTERDAY
        rows.append((t, closes[t], prod, full, at[t], af[t], lag))

    def report(label, idx, note=""):
        diffs = [abs(r[2] - r[idx]) for r in rows]
        flips = [r for r in rows if (r[1] < r[2]) != (r[1] < r[idx])]
        mx = max(diffs)
        # a bar sitting closer to the EMA than the max disagreement is a bar that
        # COULD have flipped on a different price path -- the honest exposure
        # measure when the observed flip count is zero
        near = [r for r in rows if abs(r[1] - r[2]) <= mx]
        print(f"\n  production vs {label}")
        print(f"    mean |diff| {sum(diffs) / len(diffs):8.4f}   "
              f"max |diff| {mx:8.4f}   "
              f"as % of price {100 * mx / max(r[1] for r in rows):6.3f}%")
        print(f"    DECISION FLIPS (close<ema disagrees): {len(flips)} of {len(rows)} bars"
              f"  = {100.0 * len(flips) / len(rows):.2f}%")
        print(f"    bars close enough to the EMA that they COULD flip: {len(near)}"
              f"  ({100.0 * len(near) / len(rows):.2f}%)")
        for r in flips[:5]:
            print(f"       bar {r[0]}: close {r[1]:.2f}  prod ema {r[2]:.2f} "
                  f"({'BREAK' if r[1] < r[2] else 'hold'})  "
                  f"{label} {r[idx]:.2f} ({'BREAK' if r[1] < r[idx] else 'hold'})")
        if note:
            for line in note.split("\n"):
                print(f"    {line}")

    report("SMA-seed over FULL history", 3)
    report("pandas ewm(adjust=True)", 4)
    report("pandas ewm(adjust=False)", 5)
    report("EMA AS OF YESTERDAY (current close excluded)", 6,
           "ZERO FLIPS HERE IS A THEOREM, NOT A MEASUREMENT.\n"
           "  e_t = k*c_t + (1-k)*e_{t-1}, so\n"
           "      c_t < e_t  <=>  (1-k)*c_t < (1-k)*e_{t-1}  <=>  c_t < e_{t-1}\n"
           "  for any 0 < k < 1. The `close < EMA21` trail decision is therefore\n"
           "  INVARIANT to whether the EMA includes the current close. A harness\n"
           "  that lags its EMA by one bar cannot disagree with production on the\n"
           "  trail for that reason alone. (Verified over 572,181 pairs as well.)")

    print("\n" + "=" * 78)
    print("  Read this as: even with identical exit LOGIC, this fraction of trail")
    print("  decisions can differ purely from the EMA definition. Check which")
    print("  form minervini_backtest.py uses before attributing any EMA_BREAK")
    print("  disagreement to the exit engine -- but note the invariance result")
    print("  above rules out the most likely candidate before you look.")
    print("=" * 78)
    return 0


if __name__ == "__main__":
    sys.exit(main())
