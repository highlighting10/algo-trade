"""Answers this turn's two questions with runnable evidence."""
import numpy as np, pandas as pd
from minervini_backtest import (BTCandidate, BacktestConfig, DecisionEngine,
                                DecisionConfig, AccountState,
                                synthetic_delisting_stress)

DATES = pd.bdate_range("2022-01-03", periods=300)


def ohlc(dates, closes, seed=0):
    r = np.random.default_rng(seed)
    c = np.asarray(closes, float); o = np.r_[c[0], c[:-1]]
    return pd.DataFrame({"Open": o,
                         "High": np.maximum(o, c) * (1 + abs(r.normal(0, .004, len(c)))),
                         "Low": np.minimum(o, c) * (1 - abs(r.normal(0, .004, len(c)))),
                         "Close": c}, index=dates[:len(c)])


def cand(t, rs, s2, px=100.0, vcp=85.0):
    return BTCandidate(ticker=t, exchange="NAS", pivot=px, contraction_low=px * .95,
                       atr=px * .02, last_close=px * .99, rs_rating=rs,
                       stage2_score=s2, vcp_score=vcp, session_date="2022-01-03")


# =============== Q1: is a 3x multiplier on RS distinguishable from 1x? ==========
def test_multiplier_is_inert():
    cands = [cand("A", 72, 90), cand("B", 85, 45), cand("C", 78, 60)]
    acct = AccountState(equity=1e6, cash=1e6, held_tickers=frozenset(),
                        pending_tickers=frozenset(), open_position_count=0,
                        open_notional=0.0, sector_counts={}, sector_of=None)

    def order(rs_w, s2_w):
        e = DecisionEngine(DecisionConfig(rs_weight=rs_w, stage2_weight=s2_w))
        plans, _ = e.plan(sorted(cands, key=lambda c: c.ticker), acct)
        return [p.ticker for p in plans]

    o1, o2, o3 = order(1.0, 0.0), order(2.0, 0.0), order(3.0, 0.0)
    assert o1 == o2 == o3, (o1, o2, o3)
    prod = order(2.0, 1.0)                       # production: 2*RS + Stage2
    print(f"PASS  RS-only ordering identical at 1x/2x/3x: {o1}")
    print(f"      production (2*RS + Stage2) orders:      {prod}")
    assert prod != o1, "Stage 2 should reorder relative to pure RS"
    print("      -> Stage 2 DOES reorder; the multiplier does NOT.")


# =============== Q1b: what RS range do Stage-1 survivors actually have? ========
def test_survivor_rs_range():
    from signals import RS_RATING_THRESHOLD
    print(f"PASS  Stage-1 condition 8 gate is RS >= {RS_RATING_THRESHOLD}, so every "
          f"survivor sits in {RS_RATING_THRESHOLD}-99, not 50-60")


# =============== Q2: option A as a stress test, no delisted prices needed ======
def test_delisting_stress():
    prices, sigs = {}, []
    for i, t in enumerate("ABCDEFGH"):
        r = np.random.default_rng(20 + i)
        c = 100 * np.cumprod(1 + r.normal(0.0012 - i * 0.0002, 0.016, len(DATES)))
        prices[t] = ohlc(DATES, np.r_[99, c[1:]], seed=i)
        sigs.append(cand(t, rs=95 - i * 2, s2=0.0))
    # monthly rescan -- positions are held for much of the window, so a
    # uniformly-drawn delisting date can actually land during a hold
    signals = {}
    for i in range(0, len(DATES) - 20, 21):
        d = DATES[i]
        row = []
        for j, t in enumerate(prices):
            recent = prices[t]["Close"].iloc[max(0, i - 20):i + 1]
            px = float(recent.max()) if len(recent) else 100.0
            row.append(cand(t, rs=95 - j * 2, s2=0.0, px=px))
        signals[d] = row
    cfg = BacktestConfig(rank_mode="rs_only",
                         sector_map={t: "Tech" for t in prices},
                         vcp_threshold=80.0, slippage_bps=5.0)

    for label, rate in (("sp500  (NYSE/AMEX 1.2%/yr)", 0.012),
                        ("us_small (Nasdaq 5.6%/yr)", 0.056)):
        s = synthetic_delisting_stress(prices, signals, cfg,
                                       delist_rate_per_year=rate,
                                       n_draws=60, seed=1)
        print(f"  {label}: baseline={s['baseline_expectancy_R']}  "
              f"p50={s['p50']}  p05={s['p05']}  worst={s['worst_draw']}  "
              f"mean_shift={s['mean_shift_vs_baseline']}  "
              f"(avg {s['mean_events_per_draw']} events/draw)")
    print("PASS  synthetic delisting stress runs without any delisted-price source")


if __name__ == "__main__":
    test_multiplier_is_inert()
    test_survivor_rs_range()
    test_delisting_stress()
    print("\nOK")
