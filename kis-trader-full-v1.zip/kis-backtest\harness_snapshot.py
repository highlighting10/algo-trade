#!/usr/bin/env python3
"""
HARNESS SNAPSHOT -- the backtest's missing `param_snapshot`.

Production cannot boot with a wrong STALL_DAY because `param_snapshot.py` checks
the live constants against the frozen set on every start. The BACKTEST has no
such guard, and that absence -- not the weights themselves -- is the root cause
of the rank problem: `minervini_backtest.run()` sets two of three ranking
weights and inherits the third from whichever `decision_engine` happened to be
imported, and nothing anywhere reports which one that was.

Measured 2026-08-22: the vendored 2-weight engine is live and all three modes
are correct. That is the GOOD state. This file exists so that if it ever stops
being true -- someone deletes the vendored package, or a sweep runs from a
different directory -- the run says so instead of quietly producing numbers
whose mode labels have changed meaning.

WHAT IT DOES

  1. Resolves `kistrader.entry.decision_engine` and records its path + sha256.
  2. Classifies it into a known PROFILE by its weight signature.
  3. PROVES the mode semantics with a conflicting-order fixture rather than
     inferring them from the weights -- the fixture is built so RS order and
     VCP order are exact reverses, with the RS spread deliberately TIGHT
     because that is what a post-Stage-1 candidate set looks like and it is
     where a stray weight actually bites.
  4. Checks the sizing defaults against the frozen set and, when they differ,
     requires them to have been passed explicitly.

USE

    python harness_snapshot.py                     # report + verdict, exit 0/1
    python harness_snapshot.py --require-explicit-sizing --risk-pct 0.0085 \\
                              --max-position-pct 0.25

  or from inside a sweep, before a single bar is loaded:

    from harness_snapshot import snapshot
    snap = snapshot(risk_pct=args.risk_pct, max_position_pct=args.max_position_pct,
                    require_explicit_sizing=True)
    snap.require_ok()          # raises SystemExit on drift
    print(snap.one_line())     # stamp it on the result

Read-only. Imports modules and hashes files; writes nothing, touches no network.
"""
from __future__ import annotations

import argparse
import hashlib
import os
import sys
from dataclasses import dataclass, field, replace

FROZEN_RISK_PCT = 0.0085
FROZEN_MAX_POSITION_PCT = 0.25

# sha256 of the vendored decision_engine that PARAMETER_FREEZE Rev 3 was
# produced against, measured on the machine 2026-08-22. Pinning it turns a
# silent file swap into a stop.
#
# TO RE-PIN: only after you have verified the new file deliberately. Run
#   python harness_snapshot.py
# read the sha it reports, and paste it here in the same commit as the change
# that caused it. A sha updated on its own is an audit trail with a hole in it.
EXPECTED_ENGINE_SHA = "8656b5dc6d45834ddcf18dea9b30320730dbb8f91a33b735f5420630e6fd95ff"

# A profile is a known-good shape for the imported engine. Anything not matching
# one of these is UNKNOWN, and UNKNOWN is a stop, not a shrug.
PROFILES = {
    # the copy vendored inside kis-backtest, which Rev 3 was produced against
    "vendored-2weight": dict(has_vcp_weight=False, rs=2.0, s2=1.0),
    # production's, post-migration
    "production-3weight": dict(has_vcp_weight=True, rs=0.0, s2=0.0, vcp=1.0),
}

CLAIMS = {"rs_only": "RS only", "vcp_only": "VCP only",
          "rs_plus_vcp": "2*RS + 1*VCP"}


def sha256(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


@dataclass
class Snapshot:
    engine_path: str = ""
    engine_sha: str = ""
    profile: str = "UNKNOWN"
    rs_default: float = 0.0
    s2_default: float = 0.0
    vcp_default = None            # None means the field does not exist
    risk_pct: float = 0.0
    max_position_pct: float = 0.0
    rank_weights_arity: int = 0
    mode_results: dict = field(default_factory=dict)   # mode -> (ok, reduces_to)
    problems: list = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return not self.problems

    def one_line(self) -> str:
        """Stamp this on every result. Rev 3 sec.10: carry the configuration with
        every number."""
        v = "none" if self.vcp_default is None else self.vcp_default
        return (f"[harness] engine={os.path.basename(os.path.dirname(self.engine_path))}"
                f"/{os.path.basename(self.engine_path)} sha={self.engine_sha[:12]} "
                f"profile={self.profile} defaults(rs={self.rs_default},s2={self.s2_default},"
                f"vcp={v}) risk={self.risk_pct} cap={self.max_position_pct} "
                f"modes={'OK' if all(v2[0] for v2 in self.mode_results.values()) else 'BROKEN'}")

    def require_ok(self):
        if not self.ok:
            for p in self.problems:
                print(f"  [FAIL] {p}", file=sys.stderr)
            raise SystemExit(
                "harness_snapshot: refusing to run. The imported decision_engine "
                "is not in a state whose numbers can be labelled.")


def _fixture(SC):
    """RS order and VCP order are exact reverses. The RS spread is TIGHT on
    purpose: Stage 1 has already filtered to high RS, so real survivors cluster,
    and a stray weight that looks harmless on a wide spread dominates here."""
    rows = [("AAA", 92, 60), ("BBB", 91, 65), ("CCC", 90, 70),
            ("DDD", 89, 75), ("EEE", 88, 80), ("FFF", 87, 85)]
    return [SC.Candidate(
        ticker=t, exchange="NAS", rs_rating=rs, stage2_score=0.0,
        vcp_score=float(v), pivot=99.5025, base_high=105.0, base_low=90.452261,
        contraction_low=90.452261, depth_pct=0.09, last_close=99.0, atr=0.5,
        trade_signal=True, session_date="2026-08-22", name=t, close_known=True)
        for t, rs, v in rows]


def snapshot(risk_pct=None, max_position_pct=None,
             require_explicit_sizing=False, harness_path=None,
             expect_sha=EXPECTED_ENGINE_SHA) -> Snapshot:
    from kistrader.entry import decision_engine as DE
    from kistrader.entry import screen_contract as SC

    s = Snapshot()
    s.engine_path = os.path.abspath(DE.__file__)
    s.engine_sha = sha256(s.engine_path)

    cfg0 = DE.DecisionConfig()
    has_vcp = hasattr(cfg0, "vcp_weight")
    s.rs_default = cfg0.rs_weight
    s.s2_default = cfg0.stage2_weight
    s.vcp_default = cfg0.vcp_weight if has_vcp else None
    s.risk_pct = risk_pct if risk_pct is not None else cfg0.risk_per_trade_pct
    s.max_position_pct = (max_position_pct if max_position_pct is not None
                          else cfg0.max_position_pct)

    # -- profile ---------------------------------------------------------
    for name, sig in PROFILES.items():
        if sig["has_vcp_weight"] != has_vcp:
            continue
        if abs(cfg0.rs_weight - sig["rs"]) > 1e-9:
            continue
        if abs(cfg0.stage2_weight - sig["s2"]) > 1e-9:
            continue
        if has_vcp and abs(cfg0.vcp_weight - sig["vcp"]) > 1e-9:
            continue
        s.profile = name
        break
    # -- fingerprint ------------------------------------------------------
    if expect_sha and s.engine_sha != expect_sha:
        s.problems.append(
            f"decision_engine sha256 is {s.engine_sha[:16]}... but the pinned "
            f"value is {expect_sha[:16]}.... The file this harness computes with "
            f"has CHANGED since the freeze. Verify the change is deliberate, "
            f"then re-pin EXPECTED_ENGINE_SHA in the same commit.")

    if s.profile == "UNKNOWN":
        s.problems.append(
            f"decision_engine at {s.engine_path} matches no known profile "
            f"(rs={s.rs_default} s2={s.s2_default} vcp={s.vcp_default}). "
            f"Mode labels cannot be trusted until it is classified.")

    # -- RANK_WEIGHTS arity, read from the harness source, not imported ---
    if harness_path and os.path.isfile(harness_path):
        import re
        with open(harness_path, encoding="utf-8", errors="replace") as fh:
            m = re.search(r"^RANK_WEIGHTS\s*=\s*\{[^}]*?\"rs_only\":\s*\(([^)]*)\)",
                          fh.read(), re.M)
        if m:
            s.rank_weights_arity = len(m.group(1).split(","))
            if s.rank_weights_arity == 2 and has_vcp:
                s.problems.append(
                    "RANK_WEIGHTS is a 2-tuple but the imported engine has a THIRD "
                    "weight (vcp_weight) that run() never sets. Its default leaks "
                    "into every mode.")

    # -- PROVE the modes, do not infer them -------------------------------
    HW = {"rs_only": (2.0, 0.0), "vcp_only": (0.0, 1.0), "rs_plus_vcp": (2.0, 1.0)}
    cands = _fixture(SC)
    acct = DE.AccountState(equity=1_000_000.0, cash=1_000_000.0)
    by_rs = [c.ticker for c in sorted(cands, key=lambda c: (-c.rs_rating, c.ticker))]
    by_vcp = [c.ticker for c in sorted(cands, key=lambda c: (-c.vcp_score, c.ticker))]
    by_mix = [c.ticker for c in sorted(
        cands, key=lambda c: (-(2 * c.rs_rating + c.vcp_score), c.ticker))]
    want_by_mode = {"rs_only": by_rs, "vcp_only": by_vcp, "rs_plus_vcp": by_mix}

    for mode, (rs_w, s2_w) in HW.items():
        cfg = replace(DE.DecisionConfig(), rs_weight=rs_w, stage2_weight=s2_w)
        got = [p.ticker for p in DE.DecisionEngine(cfg).plan(
            [replace(c, stage2_score=float(c.vcp_score)) for c in cands], acct)[0]]
        eff = cfg.vcp_weight if has_vcp else 0.0
        reduces = f"{cfg.rs_weight}*RS + {cfg.stage2_weight + eff}*VCP"
        ok = got[:len(want_by_mode[mode])] == want_by_mode[mode]
        s.mode_results[mode] = (ok, reduces)
        if not ok:
            s.problems.append(
                f"mode {mode!r} claims {CLAIMS[mode]} but scores {reduces} and "
                f"selects {' > '.join(got)} instead of "
                f"{' > '.join(want_by_mode[mode])}")

    # -- sizing defaults ---------------------------------------------------
    drift_risk = abs(cfg0.risk_per_trade_pct - FROZEN_RISK_PCT) > 1e-12
    drift_cap = abs(cfg0.max_position_pct - FROZEN_MAX_POSITION_PCT) > 1e-12
    if (drift_risk or drift_cap) and require_explicit_sizing:
        if risk_pct is None or max_position_pct is None:
            s.problems.append(
                f"engine defaults are risk={cfg0.risk_per_trade_pct} "
                f"cap={cfg0.max_position_pct} but the frozen set is "
                f"{FROZEN_RISK_PCT} / {FROZEN_MAX_POSITION_PCT}. Pass --risk-pct "
                f"and --max-position-pct explicitly, or the run silently uses "
                f"pre-migration values.")
    return s


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--harness", default="minervini_backtest.py")
    ap.add_argument("--risk-pct", type=float, default=None)
    ap.add_argument("--max-position-pct", type=float, default=None)
    ap.add_argument("--require-explicit-sizing", action="store_true")
    ap.add_argument("--expect-sha", default=EXPECTED_ENGINE_SHA,
                    help="pinned decision_engine sha256; pass '' to skip the check")
    args = ap.parse_args()

    try:
        s = snapshot(risk_pct=args.risk_pct,
                     max_position_pct=args.max_position_pct,
                     require_explicit_sizing=args.require_explicit_sizing,
                     harness_path=args.harness,
                     expect_sha=args.expect_sha or None)
    except ImportError as e:
        print(f"FATAL: cannot import kistrader.entry.decision_engine ({e})")
        print("Run from the kis-backtest root, or set PYTHONPATH to it.")
        return 2

    W = 78
    print("=" * W)
    print("  HARNESS SNAPSHOT -- what the backtest is about to compute with")
    print("=" * W)
    print(f"  decision_engine  : {s.engine_path}")
    print(f"  sha256           : {s.engine_sha}"
          + ("" if not EXPECTED_ENGINE_SHA
             else ("   (matches pin)" if s.engine_sha == EXPECTED_ENGINE_SHA
                   else "   ** DOES NOT MATCH THE PIN **")))
    print(f"  profile          : {s.profile}")
    v = "MISSING (2-weight engine)" if s.vcp_default is None else s.vcp_default
    print(f"  weight defaults  : rs={s.rs_default}  stage2={s.s2_default}  vcp={v}")
    print(f"  risk / cap       : {s.risk_pct} / {s.max_position_pct}"
          + ("" if (abs(s.risk_pct - FROZEN_RISK_PCT) < 1e-12
                    and abs(s.max_position_pct - FROZEN_MAX_POSITION_PCT) < 1e-12)
             else f"   ** frozen is {FROZEN_RISK_PCT} / {FROZEN_MAX_POSITION_PCT}"))
    if s.rank_weights_arity:
        print(f"  RANK_WEIGHTS     : {s.rank_weights_arity}-tuple")
    print("=" * W)
    print("  mode semantics, PROVEN against a conflicting-order fixture:")
    for mode, (ok, reduces) in s.mode_results.items():
        print(f"    {'[ OK ]' if ok else '[FAIL]'} {mode:<14}{reduces}")
    print("=" * W)
    if s.ok:
        print("  VERDICT: every mode means what its name says.")
        print(f"  {s.one_line()}")
        print("=" * W)
        return 0
    print("  VERDICT: DO NOT LABEL RESULTS FROM THIS CONFIGURATION.")
    for p in s.problems:
        for i, line in enumerate(_wrap(p, W - 8)):
            print(("    - " if i == 0 else "      ") + line)
    print("=" * W)
    return 1


def _wrap(text, width):
    out, line = [], ""
    for w in str(text).split():
        if len(line) + len(w) + 1 > width:
            out.append(line); line = w
        else:
            line = (line + " " + w).strip()
    if line:
        out.append(line)
    return out


if __name__ == "__main__":
    sys.exit(main())
