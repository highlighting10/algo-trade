"""
13_pyramid.py -- does ADDING TO WINNERS pay on THESE trades?

WHAT THIS IS: an OVERLAY, not a re-simulation. It replays completed trade
records through pyramid rules using only max_r_seen and r_at_exit, which the
harness already records.

WHAT IT CANNOT SEE, and therefore where it is OPTIMISTIC:
  1. The capital the added tranche consumes. Real adds compete for the
     exposure ceiling, cash, and slots -- so a real pyramid buys FEWER new
     names. This overlay charges nothing for that.
  2. A breakeven stop whipsawing a trade that dips below entry and then
     recovers. The overlay assumes breakeven-stopped trades finish at exactly
     0.0 R and that no eventual winner is scratched. That is an upper bound.
  3. The +3R partial (R_PARTIAL_MULTIPLE=3.0, PARTIAL_FRACTION=1/3) interacting
     with the added tranche.
Where it is CONSERVATIVE:
  4. Tranche-2 stop logic uses continuity: if the trade FINISHED below
     (T - s) R it must have passed through (T - s) after the add, so the add
     was stopped at -s. If it finished above, the overlay lets the add ride --
     it cannot see an intra-trade dip that would have stopped it. So the
     add's loss side is right and its win side is optimistic.

USE IT AS A SCREEN. If the overlay says no, do not build the mechanism.
If it says yes, build it in the harness properly and re-measure.

Usage:
    python scripts/13_pyramid.py --threshold 70 --signals data/signals_daily.pkl
    python scripts/13_pyramid.py --threshold 70 --signals data/signals_daily.pkl --start 2018-01-01 --end 2022-06-30
    python scripts/13_pyramid.py --threshold 70 --signals data/signals_daily.pkl --start 2022-07-01
"""
import pathlib as _pl
import sys as _sys
_sys.path.insert(0, str(_pl.Path(__file__).resolve().parent.parent))

import argparse
import pathlib
import pickle
from collections import defaultdict

import numpy as np
import pandas as pd

from minervini_backtest import (BacktestConfig, DecisionConfig, load_sector_map,
                                run)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--threshold", type=float, default=70.0)
    ap.add_argument("--slippage", type=float, default=5.0)
    ap.add_argument("--signals", default="data/signals.pkl")
    ap.add_argument("--start", default=None)
    ap.add_argument("--end", default=None)
    args = ap.parse_args()

    bars = {p.stem: pd.read_parquet(p)
            for p in pathlib.Path("data/bars").glob("*.parquet")}
    prices = {t: d for t, d in bars.items() if t != "^GSPC"}
    with open(args.signals, "rb") as f:
        signals = pickle.load(f)["signals"]
    if args.start or args.end:
        lo = pd.Timestamp(args.start) if args.start else pd.Timestamp.min
        hi = pd.Timestamp(args.end) if args.end else pd.Timestamp.max
        n0 = len(signals)
        signals = {d: v for d, v in signals.items() if lo <= pd.Timestamp(d) <= hi}
        print(f"[pyr] clipped signals: {n0} -> {len(signals)} date(s)")
    if not signals:
        raise SystemExit("[pyr] no signals in the requested window")

    _b = bars.get("^GSPC")
    cfg = BacktestConfig(rank_mode="rs_only", equity_mode="compounding",
                         entry_mode="pivot_limit", ambiguity_mode="worst",
                         vcp_threshold=args.threshold, slippage_bps=args.slippage,
                         sector_map=load_sector_map("data/sectors.csv"),
                         decision=DecisionConfig(),
                         benchmark_close=(_b["Close"] if _b is not None else None))
    eq, trades, st, dr, dg = run(prices, signals, cfg)
    if not trades:
        raise SystemExit("[pyr] no trades")

    m = np.array([float(t.max_r_seen) for t in trades])
    r = np.array([float(t.r_at_exit) for t in trades])
    n = len(trades)

    print("=" * 78)
    print(f"PYRAMID OVERLAY  threshold={args.threshold}  {n} trades  "
          f"window {min(signals).date()}..{max(signals).date()}")
    print("=" * 78)
    print(f"  baseline expectancy      : {r.mean():+.4f} R   "
          f"(harness reports {st['expectancy_R']:+.3f} R)")
    if abs(r.mean() - float(st["expectancy_R"])) > 0.02:
        print("  *** MISMATCH vs harness expectancy_R -- r_at_exit may not be the")
        print("      quantity expectancy_R is computed from. STOP and check before")
        print("      believing anything below.")
    print()

    # ---------------------------------------------------------------- 1
    print("  1. THE DECIDING STATISTIC")
    print("     Adding at +T pays only if trades that REACH +T finish above +T.")
    print(f"     {'T':>6}{'n reach T':>11}{'% of trades':>13}"
          f"{'E[r | MFE>=T]':>16}{'edge = E[r]-T':>16}")
    for T in (0.5, 1.0, 1.5, 2.0, 2.5, 3.0):
        sel = m >= T
        if not sel.any():
            print(f"     {T:>6.1f}{0:>11}{0.0:>12.1f}%{'--':>16}{'--':>16}")
            continue
        e = r[sel].mean()
        flag = "  <== positive" if (e - T) > 0 else ""
        print(f"     {T:>6.1f}{int(sel.sum()):>11}{100*sel.mean():>12.1f}%"
              f"{e:>+16.3f}{e - T:>+16.3f}{flag}")
    print()

    # ---------------------------------------------------------------- 2
    def overlay(T, k, s, breakeven):
        trig = m >= T
        t1 = np.where(trig & breakeven, np.maximum(r, 0.0), r)
        t2 = np.where(trig, k * np.maximum(r - T, -s), 0.0)
        return t1 + t2

    print("  2. VARIANTS   (k = added shares as a fraction of tranche 1;")
    print("                 s = the added tranche's own stop, in R below the add)")
    print(f"     {'variant':<34}{'expectancy':>12}{'vs base':>10}{'max risk':>10}")
    base = r.mean()
    rows = []
    rows.append(("baseline (no add, no BE stop)", base, 1.0))
    for T in (1.0, 1.5, 2.0):
        be = np.where(m >= T, np.maximum(r, 0.0), r).mean()
        rows.append((f"BE stop at +{T}R, NO add", be, 1.0))
    for T in (1.0, 1.5, 2.0):
        for k in (0.5, 1.0):
            for s in (0.5, 1.0):
                rows.append((f"add@{T}R k={k} s={s}, no BE",
                             overlay(T, k, s, False).mean(), 1.0 + k * s))
                rows.append((f"add@{T}R k={k} s={s}, +BE",
                             overlay(T, k, s, True).mean(), 1.0 + k * s))
    for label, val, risk in rows:
        print(f"     {label:<34}{val:>+12.4f}{val - base:>+10.4f}{risk:>9.2f}R")
    print()

    # ---------------------------------------------------------------- 3
    print("  3. IS THE GAIN THE ADD, OR JUST THE STOP?")
    print(f"     {'T':>5}{'k':>6}{'s':>6}{'BE alone':>12}{'BE + add':>12}"
          f"{'add contributes':>18}")
    for T in (1.0, 1.5, 2.0):
        be = np.where(m >= T, np.maximum(r, 0.0), r).mean()
        for k in (0.5, 1.0):
            for s in (0.5, 1.0):
                b = overlay(T, k, s, True).mean()
                print(f"     {T:>5.1f}{k:>6.2f}{s:>6.2f}{be:>+12.4f}{b:>+12.4f}"
                      f"{b - be:>+18.4f}")
    print()

    # ---------------------------------------------------------------- 4
    print("  4. WHERE THE ADD WOULD HAVE FIRED, BY EXIT REASON  (T = 1.0R)")
    by = defaultdict(list)
    for i, t in enumerate(trades):
        by[t.reason].append(i)
    print(f"     {'reason':<14}{'n':>6}{'reach 1R':>10}{'E[r|>=1R]':>12}"
          f"{'add P&L/trade':>15}")
    for reason in sorted(by, key=lambda x: -len(by[x])):
        idx = np.array(by[reason])
        sel = m[idx] >= 1.0
        if sel.any():
            e = r[idx][sel].mean()
            add = 0.5 * np.maximum(r[idx][sel] - 1.0, -0.5).sum() / len(idx)
            print(f"     {reason:<14}{len(idx):>6}{int(sel.sum()):>10}"
                  f"{e:>+12.3f}{add:>+15.4f}")
        else:
            print(f"     {reason:<14}{len(idx):>6}{0:>10}{'--':>12}{0.0:>+15.4f}")
    print()
    print("=" * 78)
    print("  READ IT LIKE THIS")
    print("=" * 78)
    print("  - Section 1 is the whole decision. If edge = E[r|MFE>=T] - T is")
    print("    NEGATIVE at every T, adding to winners loses money on these trades")
    print("    and no choice of k or s rescues it.")
    print("  - Section 3 separates the two mechanisms. If 'add contributes' is")
    print("    <= 0 while 'BE alone' beats baseline, the finding is about STOP")
    print("    MANAGEMENT, not pyramiding -- and stop management is far cheaper")
    print("    to build and does not raise max risk.")
    print("  - Re-run with --start/--end for H1 and H2 before believing any of it.")
    print("    Six parameters already reversed on the split.")


if __name__ == "__main__":
    main()
