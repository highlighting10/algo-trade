#!/usr/bin/env python3
r"""
e10_subperiod.py -- sub-period dominance on WITHIN-SLICE drawdown.

READ-ONLY. Runs no sweep, writes no file, changes nothing.
Run from the kis-backtest root:

    .\.venv\Scripts\python.exe e10_subperiod.py

PRE-REGISTERED 2026-09-19 in PREREG_20260919_E10_subperiod_dominance.
Every decision below was fixed BEFORE this file was written. Read that document
before reading any number this prints.

-----------------------------------------------------------------------------
WHY THIS EXISTS

RESULT_20260919_E10_phase1 measured the two extremes of the exposure ceiling and
found them inseparable on every metric: 0.06 to 0.5 paired SE, block-insensitive,
and needing ~14x to ~1000x more data to read -- 120 to 180 YEARS. That killed the
sweep route.

RESULT_20260919_E10_phase1d then showed the estimand could be fixed (frequency,
not tail magnitude) but that the significance test attached to it could not:
mcSE = sqrt(discord)/N is MONTE CARLO precision, so mc_z rises as sqrt(draws).
Measured: 2000 -> 8000 draws DOUBLED every mc_z while every point estimate held.

So the uncertainty of the difference ON ANOTHER HISTORY remains unmeasured, and
no amount of resampling ONE history will measure it.

This script takes the other route: NEAR-INDEPENDENT DATA. Four calendar slices,
four regimes, one question each. Dominance is floor-independent -- no SE appears
anywhere in this file -- which is exactly why S1's pre-registration chose it.

-----------------------------------------------------------------------------
WHY NO BOOTSTRAP HERE

A moving-block bootstrap SCRAMBLES CALENDAR ORDER. A drawn path's "first quarter"
is not 2018-2020; it is 26 blocks pulled from anywhere in the window. Calendar
identity is the entire point of a sub-period test, so the actual equity curves are
used and nothing is resampled.

Consequence, and it is a feature: this run is DETERMINISTIC. No --seed, no
--draws, nothing that can be turned up until a number looks convincing. That was
the exact failure mode of the mc_z column this script replaces.

-----------------------------------------------------------------------------
WHAT IT CANNOT ESTABLISH -- read this before quoting anything

  * NOT statistical significance. Four cells give 1/16 = 6.25% under a null of
    independent coin flips, and the cells are NOT independent: serial correlation
    runs across slice boundaries and both arms share one market. 6.25% is a FLOOR
    on the chance level, not the actual one.
    The phrase is CONSISTENT DIRECTIONAL EVIDENCE. Never "significant".
  * NOT production's configuration. Every exposure arm is exposure_policy=
    regime_ceiling, and minervini_backtest.py:442 REFUSES that with
    regime_ma=None. Production has run regime_ma=None since PATCH F3, and
    RESULT_20260919_regime_sweep_closed measured regime_20 as LOSING to
    regime_off on expectancy at all four cost levels. sector_cap is 2 here;
    production runs 0 (PATCH F).
  * NOT comparable to any 8-cell or H1/H2 result. This is 4 cells at ONE cost
    level (SLIP=5.0, inherited from paired_bootstrap). The project's convention
    is 8 cells = 4 costs x 2 halves. Cost is HELD, not swept.

-----------------------------------------------------------------------------
DOCTRINE CARVE-OUT -- this script knowingly breaks a standing rule

RESULT_20260828_S4_trail_null: "drawdown is a veto, never a ranker."

Here drawdown is the PRIMARY ADJUDICATOR. The carve-out, and it is narrow:

    Drawdown may RANK when survival is the estimand -- when the question is
    itself about loss avoidance. It remains a VETO, NEVER A RANKER, on return
    questions, which is what the original rule was written for.

Do not cite this file as precedent for ranking a return question on drawdown.
"""
from __future__ import annotations

import sys
from dataclasses import replace

import numpy as np
import pandas as pd

from minervini_backtest import (BacktestConfig, DecisionConfig, load_bars,
                                load_sector_map, run)
# Arms are IMPORTED, never redeclared, so they cannot drift from the ones
# Phase 1 and Phase 1d measured.
from paired_bootstrap import CELLS, SLIP

ARM_A = "exp_100"        # ceiling held open
ARM_B = "exp_ceiling"    # binary, == exp_000
NSLICES = 4
THIN_TRADES = 30
# Fixed BEFORE any within-slice depth was looked at, and deliberately spanning
# past where the data can reach. The deep rungs will be empty; their emptiness
# is informative and is why they stay. DESCRIPTIVE ONLY -- does not adjudicate.
LADDER = (-5.0, -10.0, -15.0, -20.0, -25.0, -30.0, -35.0)


def mdd_pct(vals: np.ndarray) -> float:
    """Max drawdown over exactly these values, peak reset at vals[0]."""
    if len(vals) < 2 or vals[0] <= 0:
        return float("nan")
    peak = np.maximum.accumulate(vals)
    return float((vals / peak - 1.0).min()) * 100.0


def arm(prices, signals, base, name):
    cfg = replace(base, slippage_bps=SLIP, ambiguity_mode="worst", **CELLS[name])
    eq, trades, stats, _drops, diag = run(prices, signals, cfg)
    lo, hi = diag["stats_window"].split("..")
    eq = eq.dropna()
    eq = eq.loc[(eq.index >= pd.Timestamp(lo)) & (eq.index <= pd.Timestamp(hi))]
    print("[sp] %-14s trades=%4d  ret=%s%%  DD=%s%%  window=%s"
          % (name, stats.get("num_trades"), stats.get("total_return_pct"),
             stats.get("max_drawdown_pct"), diag["stats_window"]))
    return {"eq": eq, "trades": trades, "stats": stats}


def main() -> int:
    print("[sp] E10 SUB-PERIOD DOMINANCE -- pre-registered "
          "PREREG_20260919_E10_subperiod_dominance")
    print("[sp] deterministic: no bootstrap, no seed, no draw count")
    print()

    bars = load_bars()                      # patch S: refuses on a wrong cwd
    prices = {t: d for t, d in bars.items() if t != "^GSPC"}
    import pickle
    with open("data/signals_daily.pkl", "rb") as fh:
        signals = pickle.load(fh)["signals"]
    bench = bars.get("^GSPC")
    if bench is None:
        return int(print("[sp] no ^GSPC bars -- the frozen set needs regime_ma=20") or 2)

    base = BacktestConfig(
        rank_mode="vcp_only", equity_mode="compounding",
        entry_mode="pivot_limit", ambiguity_mode="worst",
        vcp_threshold=75.0, regime_ma=20, stall_day=252,
        sector_map=load_sector_map("data/sectors.csv"),
        decision=DecisionConfig(risk_per_trade_pct=0.0085,
                                max_position_pct=0.25, sector_cap=2),
        benchmark_close=bench["Close"])

    A = arm(prices, signals, base, ARM_A)
    B = arm(prices, signals, base, ARM_B)

    if not A["eq"].index.equals(B["eq"].index):
        print("[sp] the two arms have DIFFERENT stats windows -- the slices would "
              "cover different calendars. Refusing.")
        return 1

    idx = A["eq"].index
    n = len(idx)
    # Equal TRADING-DAY counts, positional. Fixed before any result was seen;
    # deliberately NOT regime-defined, because choosing boundaries around known
    # events (COVID, the 2022 bear) is choosing the test by its answer.
    cuts = [round(i * n / NSLICES) for i in range(NSLICES + 1)]
    vA, vB = A["eq"].to_numpy(), B["eq"].to_numpy()

    exA = pd.Series([pd.Timestamp(t.exit_date).normalize() for t in A["trades"]])
    exB = pd.Series([pd.Timestamp(t.exit_date).normalize() for t in B["trades"]])

    print()
    print("[sp] %d slices of ~%d trading days, equal count, positional"
          % (NSLICES, n // NSLICES))
    print("[sp] %-6s %-24s %6s %7s %7s %9s %9s %8s"
          % ("slice", "dates", "days", "trA", "trB", "mddA", "mddB", "delta"))

    rows, wins_B, wins_A, inconclusive = [], 0, 0, 0
    for k in range(NSLICES):
        i, j = cuts[k], cuts[k + 1]
        sl = idx[i:j]
        d0, d1 = sl[0], sl[-1]
        mA, mB = mdd_pct(vA[i:j]), mdd_pct(vB[i:j])
        tA = int(((exA >= d0) & (exA <= d1)).sum()) if len(exA) else 0
        tB = int(((exB >= d0) & (exB <= d1)).sum()) if len(exB) else 0
        thin = (tA < THIN_TRADES) or (tB < THIN_TRADES)
        # B wins when its drawdown is SHALLOWER -- less negative, larger value.
        delta = mB - mA
        if thin:
            verdict = "THIN"
            inconclusive += 1
        elif delta > 0:
            verdict = "B"
            wins_B += 1
        elif delta < 0:
            verdict = "A"
            wins_A += 1
        else:
            verdict = "TIE"
            inconclusive += 1
        rows.append((k + 1, d0, d1, mA, mB, delta, tA, tB, thin, verdict))
        print("[sp] %-6d %s..%s %6d %7d %7d %9.2f %9.2f %+8.2f  %s"
              % (k + 1, d0.date(), d1.date(), j - i, tA, tB, mA, mB, delta,
                 verdict + ("  <-- under %d trades" % THIN_TRADES if thin else "")))

    full_A, full_B = mdd_pct(vA), mdd_pct(vB)
    print("[sp] %-6s %-24s %6d %7d %7d %9.2f %9.2f %+8.2f  (reference)"
          % ("FULL", "%s..%s" % (idx[0].date(), idx[-1].date()), n,
             len(exA), len(exB), full_A, full_B, full_B - full_A))

    print()
    print("[sp] PRIMARY READ -- continuous within-slice max drawdown, peak reset")
    print("[sp]   B (%s) shallower in %d of %d slices" % (ARM_B, wins_B, NSLICES))
    print("[sp]   A (%s) shallower in %d of %d slices" % (ARM_A, wins_A, NSLICES))
    if inconclusive:
        print("[sp]   %d slice(s) inconclusive (thin or tied) -- NOT counted as wins"
              % inconclusive)
    dl = [r[5] for r in rows if not r[8]]
    if dl:
        print("[sp]   deltas on countable slices: %s"
              % ", ".join("%+.2f" % d for d in dl))
        print("[sp]   direction without magnitude is empty: 4/4 at 0.1pp and 4/4")
        print("[sp]   at 5pp are the same verdict and different facts.")

    top = max(wins_B, wins_A)
    who = ARM_B if wins_B >= wins_A else ARM_A
    print()
    if inconclusive:
        print("[sp] VERDICT: INCOMPLETE -- %d of %d cells could not be counted."
              % (inconclusive, NSLICES))
    elif top == NSLICES:
        print("[sp] VERDICT: CONSISTENT DIRECTIONAL EVIDENCE for %s (%d/%d)."
              % (who, top, NSLICES))
        if who == ARM_A:
            print("[sp]   NOTE: this direction is evidence AGAINST progressive")
            print("[sp]   exposure. Registered symmetrically on purpose.")
    elif top == NSLICES - 1:
        print("[sp] VERDICT: SUGGESTIVE for %s (%d/%d) -- not decisive."
              % (who, top, NSLICES))
    else:
        print("[sp] VERDICT: NULL (%d/%d) -- no consistent direction." % (top, NSLICES))
    print("[sp] This is NOT a significance claim. 4/4 is 1/16 = 6.25% ONLY under")
    print("[sp] independent coin flips; these cells share one market and correlate")
    print("[sp] across boundaries, so 6.25% is a FLOOR on the chance level.")

    print()
    print("[sp] SECONDARY -- threshold ladder, DESCRIPTIVE ONLY, does not adjudicate")
    print("[sp] fixed before any within-slice depth was seen; empty deep rungs are")
    print("[sp] informative, which is why they stay.")
    print("[sp] %-10s %s" % ("threshold",
                             " ".join("slice%d" % (k + 1) for k in range(NSLICES))))
    for thr in LADDER:
        cells = []
        for (_k, _d0, _d1, mA, mB, _dl, _tA, _tB, _thin, _v) in rows:
            bA, bB = (mA <= thr), (mB <= thr)
            cells.append("both  " if (bA and bB) else
                         "A only" if bA else
                         "B only" if bB else
                         "none  ")
        print("[sp] %+10.1f %s" % (thr, " ".join(cells)))
    print("[sp]   'both' and 'none' are TIES at that threshold, never wins.")

    print()
    print("[sp] LABEL -- do not cross-quote: 4 cells at ONE cost level (SLIP=%.1f),"
          % SLIP)
    print("[sp] regime_ma=20 sector_cap=2 (Rev 3 reproduction, NOT production),")
    print("[sp] %d slices (NOT H1/H2). Incomparable to any 8-cell result." % NSLICES)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
