"""
exposure_controller.py -- portfolio-level exposure ceiling, Minervini-style.

WHAT THIS REPLACES
The first draft had five states (DEFENSIVE..MAXIMUM), seven boolean inputs and
two position-size constants. That is roughly twelve free parameters. The backtest
that would have to justify them contains 225 trades. Twelve parameters cannot be
fitted on 225 trades, and only ONE of the seven inputs has ever been measured.

So this module implements exactly what the data supports and nothing else.

WHAT THE DATA SAYS (threshold 75, vcp_only, stall_day 252, 0.85%/25%)
  regime_off  worst cell +0.217 R   mean +0.281 R
  regime_20   worst cell +0.243 R   mean +0.320 R   beats regime_off 8/8 cells
  regime_50   worst cell +0.092 R   mean +0.162 R
  regime_100  worst cell +0.179 R   mean +0.273 R   wins H1, LOSES H2
  regime_150  worst cell +0.180 R   mean +0.284 R   wins H1, LOSES H2
  regime_200  worst cell +0.131 R   mean +0.264 R   wins H1, LOSES H2

regime_20 is the only setting that beats the control in BOTH halves. Total R is
unchanged (65.6 vs 64.9) on ~12% fewer trades -- it does not add return, it
removes trades that net to zero. The gap is +0.038 R against a standard error of
+/-0.19 R at ~100 trades per half, so the ONLY evidence is the 8/8 cell sweep,
which is two independent successes. Suggestive, not proven. Treat it as a risk
control, not a return enhancer.

TWO DESIGN RULES, both learned the hard way this session
  1. ONE GATE, ONE SOURCE. DecisionConfig.max_portfolio_exposure_pct already IS
     the exposure ceiling and already binds (4,084 rejections in the full-window
     run). This controller WRITES that value. It never adds a second gate --
     that is the shape of the orphan open_notional bug.
  2. NO UNREACHABLE STATES. The draft's determine_state() could never return
     AGGRESSIVE or MAXIMUM: the deterioration branch returned DEFENSIVE, the
     unhealthy branch CAUTIOUS, the healthy branch NORMAL, and the default
     CAUTIOUS. Two of five states were dead code. Every state below is
     reachable, and there is a test that proves it.

NOT IMPLEMENTED, DELIBERATELY
  - Progressive position building (pilot -> full). That is the pyramid. Its
    overlay estimator flipped sign twice against harness measurement, so it is
    unvalidated. NOTE: the "no free capital" objection raised at threshold 70
    (68.9% deployment) does NOT hold at the frozen threshold 75, where
    deployment is ~37.8% and adds would take it to ~54%. The capital objection
    is WITHDRAWN; the estimator objection stands.
  - Trade-feedback inputs: PARTLY BUILT 2026-09-19, see loss_streak_ceilings.
    The original entry read "No measurement exists. Adding them now would be
    fitting noise." That was correct, and measurement was then attempted and
    FAILED to settle it: the two extremes of the ceiling are inseparable
    (0.06-0.5 paired SE, needing 14x-1000x more data), and sub-period
    dominance came back NULL 2/2. So the loss-streak input is built on
    DOCTRINE -- PATCH F3's own named replacement -- and is DEFAULT OFF.
    It is not fitted to anything, which is why it has three fixed levels
    and no tunable. Recent breakout success and stop-out frequency remain
    excluded for the original reason.
  - Breadth, distribution days, volatility states. Same reason.
  Section 6 records what each would need before it earns a place.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Optional


DEFAULT_LOSS_STREAK_CEILINGS = ((2, 0.50), (3, 0.25))
"""Doctrine, not a fit. (streak_at_or_above, ceiling), most permissive first.
Three levels total counting the implicit 1.00 below the first rung, per
HANDOFF_PHASE_E E10 ("two or three levels, not five"). Enabling the gate is
ExposureConfig(loss_streak_ceilings=DEFAULT_LOSS_STREAK_CEILINGS)."""


def streak_ceiling(rungs, streak: int) -> float:
    """Ceiling for a loss streak. PURE. Deepest matching rung wins.

    No rung matched -> 1.00, i.e. the gate is silent until it bites.
    """
    cap = 1.00
    for at, pct in rungs:
        if streak >= at:
            cap = min(cap, float(pct))
    return cap


def loss_streak_from(r_values) -> int:
    """Consecutive losers at the FRONT of a newest-first R list. PURE.

    loser   R < 0   counts
    winner  R > 0   stops the streak
    scratch R == 0  is neither -- a breakeven stop is not a loss, and it
                    does not reset a run of losses either. It is skipped.
    """
    n = 0
    for r in r_values:
        if r is None:
            break
        r = float(r)
        if r != r:                       # NaN -- unknowable, stop counting
            break
        if r > 0:
            break
        if r < 0:
            n += 1
    return n


class ExposureState(Enum):
    """Reachable states only. RISK_OFF and RISK_ON are the measured pair;
    UNAVAILABLE is the fail-closed state when the benchmark cannot be read;
    LOSS_STREAK is progressive exposure biting on our own closed trades."""
    UNAVAILABLE = "unavailable"
    RISK_OFF = "risk_off"
    RISK_ON = "risk_on"
    LOSS_STREAK = "loss_streak"


@dataclass(frozen=True)
class ExposureConfig:
    # --- PATCH F3 2026-08-25 --- OFF.
    # Minervini's Trend Template is eight PER-STOCK criteria and does not gate
    # entries on an index moving average; exposure is managed by progressive
    # exposure keyed to his own trade results. Those eight gates already live in
    # the screener, so the index MA was a second gate the method does not ask
    # for. The sweep could not adjudicate it -- regime_20 beat regime_off by
    # 0.035-0.049 R against a 0.138 R noise floor -- so this is settled on
    # doctrine, not on data.
    #
    # None turns off the VERDICT only. Since PATCH F2 the screener handshake
    # (schema, session date, --emit-threshold, vcp_threshold match) is enforced
    # either way -- see decide(handshake_ok=...). Do NOT set this to None on a
    # tree without F2.
    #
    # To restore the gate: 20 here AND 20 in param_snapshot.FROZEN, together.
    regime_ma: Optional[int] = None

    # Ceilings written into DecisionConfig.max_portfolio_exposure_pct.
    # risk_on reproduces the current production value, so switching the
    # controller on changes nothing while the benchmark is above its MA.
    risk_on_exposure_pct: float = 1.00
    # The backtested gate is binary: it blocks NEW entries entirely. 0.0 is
    # therefore the faithful value. Anything above 0.0 is an untested softening.
    risk_off_exposure_pct: float = 0.00
    # FAIL CLOSED. A benchmark we cannot read is not a benchmark that is fine.
    unavailable_exposure_pct: float = 0.00

    # --- E10 2026-09-19 --- progressive exposure on OUR OWN trade results.
    # None = OFF, the same convention regime_ma uses, so there is one way to
    # disable a gate in this module and not two. DEFAULT_LOSS_STREAK_CEILINGS
    # turns it on. Built on doctrine (PATCH F3's named replacement) after
    # measurement failed to settle it three ways -- see the module docstring.
    loss_streak_ceilings: Optional[tuple] = None

    def __post_init__(self) -> None:
        if self.regime_ma is not None and self.regime_ma < 2:
            raise ValueError("regime_ma must be >= 2 or None (None = controller off)")
        if self.loss_streak_ceilings is not None:
            rungs = tuple(self.loss_streak_ceilings)
            if not rungs:
                raise ValueError("loss_streak_ceilings must be None (off) or non-empty")
            last_at, last_pct = -1, 1.01
            for rung in rungs:
                if len(rung) != 2:
                    raise ValueError("each rung must be (streak_at_or_above, ceiling)")
                at, pct = int(rung[0]), float(rung[1])
                if at < 1:
                    raise ValueError("a rung at streak < 1 would fire before any loss")
                if at <= last_at:
                    raise ValueError("rungs must be strictly increasing in streak")
                if not (0.0 <= pct <= 1.0):
                    raise ValueError("a rung ceiling must be in [0.0, 1.0]")
                if pct > last_pct:
                    raise ValueError("a deeper streak must not RAISE the ceiling")
                last_at, last_pct = at, pct
        for name in ("risk_on_exposure_pct", "risk_off_exposure_pct",
                     "unavailable_exposure_pct"):
            v = getattr(self, name)
            if not (0.0 <= v <= 1.0):
                raise ValueError(f"{name} must be in [0.0, 1.0], got {v}")
        if self.risk_off_exposure_pct > self.risk_on_exposure_pct:
            raise ValueError("risk_off ceiling must not exceed risk_on ceiling")


@dataclass(frozen=True)
class ExposureDecision:
    state: ExposureState
    max_portfolio_exposure_pct: float
    reason: str          # goes straight into the drop log / CRITICAL alert


class ExposureController:
    """Stateless. Given today's benchmark close and its moving average, return
    the exposure ceiling to write into DecisionConfig.

    Deliberately takes NUMBERS, not a data source. The caller owns the fetch and
    owns the failure path; this class cannot silently succeed on stale data.
    """

    def __init__(self, cfg: Optional[ExposureConfig] = None) -> None:
        self.cfg = cfg or ExposureConfig()

    def decide(self, benchmark_close: Optional[float],
               benchmark_ma: Optional[float],
               handshake_ok: bool = True,
               loss_streak: Optional[int] = None) -> ExposureDecision:
        """Regime gate and progressive-exposure gate, composed.

        MOST CONSERVATIVE WINS -- the min of the two ceilings. In production
        the regime gate is OFF (regime_ma=None since PATCH F3), so in
        practice the streak gate is the only thing writing below 1.00.

        `loss_streak` is a NUMBER, by design: the caller owns reading the
        closed-trade history and owns its failure path. See the class
        docstring -- this object cannot silently succeed on stale data.
        """
        base = self._regime_decide(benchmark_close, benchmark_ma, handshake_ok)
        c = self.cfg
        if c.loss_streak_ceilings is None:
            return base                      # gate off: unchanged behaviour
        if loss_streak is None:
            # A gate that cannot evaluate must not pass. Same doctrine as an
            # unreadable benchmark, and a survival gate is not exempt from it.
            return ExposureDecision(
                ExposureState.UNAVAILABLE, c.unavailable_exposure_pct,
                "loss-streak gate is ON but no streak was supplied -- "
                "no new entries (the caller must read the closed-trade "
                "history and pass it)")
        streak = int(loss_streak)
        if streak < 0:
            raise ValueError("loss_streak must be >= 0")
        cap = streak_ceiling(c.loss_streak_ceilings, streak)
        if cap >= base.max_portfolio_exposure_pct:
            return base                      # the regime gate already binds
        return ExposureDecision(
            ExposureState.LOSS_STREAK, cap,
            f"progressive exposure: {streak} consecutive losing trade(s) "
            f"-> ceiling {cap:.2f} (was {base.max_portfolio_exposure_pct:.2f}; "
            f"{base.reason})")

    def _regime_decide(self, benchmark_close: Optional[float],
               benchmark_ma: Optional[float],
               handshake_ok: bool = True) -> ExposureDecision:
        c = self.cfg

        # PATCH F2 -- checked BEFORE the disabled short-circuit, deliberately.
        # handshake_ok is read_regime's meta["validated"]: the sidecar describes
        # a screener run we can trust. Turning the regime gate off must not also
        # turn off validation of the screener's output -- a stale sidecar, an
        # --emit-threshold plumbing run, or a screener that applied a different
        # vcp_threshold has to stop the trader whether or not a regime is being
        # computed. Defaults True so existing direct callers are unaffected.
        if not handshake_ok:
            return ExposureDecision(
                ExposureState.UNAVAILABLE, c.unavailable_exposure_pct,
                "screener sidecar failed validation -- no new entries "
                "(this is independent of the regime gate)")

        # Controller disabled -> today's behaviour, unchanged, no gate.
        if c.regime_ma is None:
            return ExposureDecision(ExposureState.RISK_ON, c.risk_on_exposure_pct,
                                    "regime controller disabled")

        # FAIL CLOSED. Covers a failed fetch, a missing session, and the NaN
        # warm-up window. A gate that cannot evaluate must not pass.
        if (benchmark_close is None or benchmark_ma is None
                or benchmark_close != benchmark_close      # NaN
                or benchmark_ma != benchmark_ma):
            return ExposureDecision(
                ExposureState.UNAVAILABLE, c.unavailable_exposure_pct,
                f"benchmark unavailable (close={benchmark_close}, "
                f"ma{c.regime_ma}={benchmark_ma}) -- no new entries")

        if float(benchmark_close) < float(benchmark_ma):
            return ExposureDecision(
                ExposureState.RISK_OFF, c.risk_off_exposure_pct,
                f"benchmark {benchmark_close:.2f} < ma{c.regime_ma} "
                f"{benchmark_ma:.2f} -- no new entries")

        return ExposureDecision(
            ExposureState.RISK_ON, c.risk_on_exposure_pct,
            f"benchmark {benchmark_close:.2f} >= ma{c.regime_ma} "
            f"{benchmark_ma:.2f}")


def apply_to_decision_config(decision_cfg, decision: ExposureDecision):
    """Write the ceiling into the EXISTING gate. One gate, one source.

    Returns a NEW DecisionConfig; never mutates the one passed in, so a stale
    ceiling cannot leak across sessions.
    """
    from dataclasses import replace
    return replace(decision_cfg,
                   max_portfolio_exposure_pct=decision.max_portfolio_exposure_pct)
