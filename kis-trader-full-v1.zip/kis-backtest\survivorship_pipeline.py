"""Two-step survivorship pipeline: STEP 1 = C+E (free, now), STEP 2 = A (when data lands)."""
import numpy as np, pandas as pd
from minervini_backtest import (BTCandidate, BacktestConfig, run,
                                universe_coverage, bias_gradient,
                                survivorship_adjustment)

DATES = pd.bdate_range("2024-01-02", periods=60)


def ohlc(dates, closes):
    c = np.asarray(closes, float); o = np.r_[c[0], c[:-1]]
    return pd.DataFrame({"Open": o, "High": np.maximum(o, c) * 1.01,
                         "Low": np.minimum(o, c) * 0.99, "Close": c}, index=dates)


def cand(t, px=100.0, rs=90, score=85.0):
    return BTCandidate(ticker=t, exchange="NAS", pivot=px, contraction_low=px * .95,
                       atr=px * .02, last_close=px * .99, rs_rating=rs,
                       vcp_score=score, session_date="2024-01-02")


SECTORS = {t: s for t, s in zip("ABCDEF", ["Tech", "Health", "Energy",
                                           "Financials", "Utilities", "Materials"])}


def cfg(**kw):
    d = dict(rank_mode="rs_only", sector_map=SECTORS, slippage_bps=0)
    d.update(kw)
    return BacktestConfig(**d)


# ================= STEP 1a — OPTION C: size the blind spot =================
def step1_coverage():
    constituents = {
        pd.Timestamp("2020-01-02"): list("ABCDEFGHIJ"),   # J, I no longer exist
        pd.Timestamp("2022-01-03"): list("ABCDEFGH"),
        pd.Timestamp("2024-01-02"): list("ABCDEF"),
    }
    priceable = set("ABCDEF")
    rep = universe_coverage(constituents, priceable)
    assert rep["worst_coverage_pct"] == 60.0, rep["worst_coverage_pct"]
    assert rep["distinct_missing_tickers"] == 4, rep
    print("STEP 1a (C) coverage:")
    for r in rep["by_date"]:
        print(f"   {r['date'].date()}  {r['priceable']}/{r['constituents']} priceable "
              f"-> {r['coverage_pct']}% coverage, {r['missing']} invisible")
    print(f"   worst {rep['worst_coverage_pct']}%  mean {rep['mean_coverage_pct']}%  "
          f"{rep['distinct_missing_tickers']} tickers never seen\n")
    return rep


# ================= STEP 1b — OPTION E: bias gradient =================
def step1_gradient():
    rng = np.random.default_rng(7)
    prices, sigs = {}, []
    for i, t in enumerate("ABCDEF"):
        drift = 0.9 + 0.35 * (i / 5)                       # A weakest .. F strongest
        c = 100 * np.cumprod(1 + rng.normal(0.0015 * drift, 0.02, 60))
        prices[t] = ohlc(DATES, np.r_[99, c[1:]])
        sigs.append(cand(t, rs=80 + i * 3))
    signals = {DATES[0]: sigs}

    layers = {
        "all_current":            set("ABCDEF"),
        "also_in_index_earlier":  set("BCDEF"),            # drop the weakest
        "also_outperformed":      set("DEF"),              # keep only winners
    }
    g = bias_gradient(prices, signals, cfg(), layers, metric="expectancy_R")
    print("STEP 1b (E) bias gradient:")
    for label, v in g["layers"].items():
        print(f"   {label:24} n={v.get('n_tickers')}  trades={v.get('num_trades')}  "
              f"expectancy_R={v.get('expectancy_R')}")
    for s in g["steps"]:
        print(f"   step {s['from']} -> {s['to']}: {s['delta']:+.4f} R")
    print(f"   implied inflation per survivorship layer: "
          f"{g['implied_bias_per_layer']:+.4f} R\n")
    assert len(g["steps"]) == 2
    return g


# ================= STEP 2 — OPTION A: real delisting events =================
def step2_delisting():
    # C collapses; the stop would normally catch it. D gaps straight to a delist.
    up = np.linspace(99, 140, 60)
    crash = np.r_[99, 101, 102, 96, 88, np.linspace(87, 40, 55)]
    prices = {"C": ohlc(DATES, crash), "D": ohlc(DATES, up)}
    signals = {DATES[0]: [cand("C", rs=95), cand("D", rs=94)]}

    base = cfg()
    eq0, tr0, st0, _, dg0 = run(prices, signals, base)
    assert dg0["delisting_modelled"] is False

    events = {"C": (DATES[40], -0.55),      # long after the stop fired
              "D": (DATES[20], -0.55)}      # while still held
    with_a = cfg(delisting_events=events)
    eq1, tr1, st1, _, dg1 = run(prices, signals, with_a)

    print("STEP 2 (A) delisting substitution:")
    print(f"   without A: end equity ${st0['end_equity']:,.2f}  "
          f"exits={st0['exit_reasons']}")
    print(f"   with    A: end equity ${st1['end_equity']:,.2f}  "
          f"exits={st1['exit_reasons']}")
    print(f"   events reached={dg1['delist_events_in_window']}  "
          f"hit an OPEN position={dg1['delist_events_hit_open_position']}")
    print(f"   -> stop_catches_frac MEASURED = {dg1['stop_catches_frac_measured']} "
          f"(was an assumption in step 1)\n")

    assert dg1["delisting_modelled"] is True
    assert "DELISTED" in st1["exit_reasons"]
    assert st1["end_equity"] < st0["end_equity"]
    assert dg1["stop_catches_frac_measured"] == 0.5     # C caught, D not
    return dg1


# ================= tie it together =================
if __name__ == "__main__":
    step1_coverage()
    step1_gradient()
    dg = step2_delisting()

    # step 1's academic fallback, now cross-checked against step 2's measurement
    prices = {"A": ohlc(DATES, np.linspace(99, 150, 60))}
    _, tr, _, _, _ = run(prices, {DATES[0]: [cand("A")]}, cfg())
    a = survivorship_adjustment(tr, delist_rate_per_year=0.056,
                                stop_catches_frac=dg["stop_catches_frac_measured"])
    print("cross-check: academic estimate fed the MEASURED stop-catch rate")
    print(f"   drag/trade = {a['expected_drag_per_trade_pct_equity']}% of equity")
    print("\nTWO-STEP PIPELINE OK")
