#!/usr/bin/env python3
r"""
verify_QT2_ledger.py -- did T2's arm actually ENGAGE, or is the tie a no-op?

READ-ONLY. Runs no sweep, writes no file, changes nothing.
Run from the kis-backtest root:

    .\.venv\Scripts\python.exe verify_QT2_ledger.py

-----------------------------------------------------------------------------
WHY THIS EXISTS

T2 (`--param expequiv`) returned an exact tie at all four cost levels:

    exp_blank +0.3330 / +0.3300 / +0.3120 / +0.2900   201/200/200/199 trades
    exp_ceiling   ... identical ...                    ... identical ...

That is the pre-registered PASS. It is also, precisely, what a flag that never
took effect looks like. The two hypotheses are observationally identical in the
sweep's own output:

    H_equiv   both mechanisms ran, and they agree.
    H_noop    exp_ceiling silently ran the blank, so "both" cells were one cell.

This harness has been bitten by H_noop before and it is in the code comments:
*"PATCH E -- regime_ma was NEVER passed here. It fell to the dataclass default
... so every non-regime sweep ran without one."* Accepting the tie without
separating these would repeat that exactly.

The sweep prints `drops (sample setting)` for the WINNER only, and dict order
made `exp_blank` the winner, so `exp_ceiling`'s ledger was never displayed.

-----------------------------------------------------------------------------
WHAT SEPARATES THEM

The two mechanisms leave DIFFERENT fingerprints even when the trades match:

                        exp_blank (constant)      exp_ceiling (regime_ceiling)
  drops "regime_off"    > 0  (the blank fired)    ABSENT   (blank never runs)
  drops "exposure
        ceiling"        baseline                  HIGHER   (risk-off days now
                                                   reject through the ceiling)
  exposure_reduced_days 0                         > 0

If `exp_ceiling` shows `regime_off` drops, the blank ran and the arm did not
engage -> H_noop, and T2 proves nothing.
If it shows `exposure_reduced_days == 0`, the ceiling never moved -> H_noop.

Then, and only then, the equivalence claim is checked at full strength: not on
aggregate expectancy but on the COMPLETE trade list, field by field.

Cost level is pinned to 5.0 bps and the intrabar bound to "worst" -- the
harness's own decision rule (`run_band`: *"the WORST bound is the number a
parameter choice is judged on"*), and 5.0 bps is Rev 3's established level.

Docstring is raw: this file names `scripts\06_sweep.py` and `\06` is a valid
octal escape (patch N's bug).
"""
from __future__ import annotations

import pathlib
import pickle
import sys
from dataclasses import asdict, replace

import pandas as pd

from minervini_backtest import (BacktestConfig, DecisionConfig, load_sector_map,
                                run)

SLIP = 5.0
CELLS = {
    "exp_blank":   {"exposure_policy": "constant"},
    "exp_ceiling": {"exposure_policy": "regime_ceiling",
                    "exposure_risk_off_pct": 0.0},
}


def main() -> int:
    bars = {p.stem: pd.read_parquet(p)
            for p in pathlib.Path("data/bars").glob("*.parquet")}
    if not bars:
        raise SystemExit(
            "no bars in data/bars -- glob() on a missing directory returns "
            "EMPTY WITHOUT ERROR. Run this from the kis-backtest root.")
    prices = {t: d for t, d in bars.items() if t != "^GSPC"}
    with open("data/signals_daily.pkl", "rb") as fh:
        blob = pickle.load(fh)
    signals = blob["signals"]
    bench = bars.get("^GSPC")
    if bench is None:
        raise SystemExit("no ^GSPC bars -- regime_ma=20 cannot be evaluated.")
    print(f"[T2] {len(prices)} tickers, {len(signals)} signal date(s), "
          f"slippage {SLIP} bps, worst bound")

    base = BacktestConfig(
        rank_mode="vcp_only", equity_mode="compounding",
        entry_mode="pivot_limit", ambiguity_mode="worst",
        vcp_threshold=75.0, regime_ma=20, stall_day=252,
        sector_map=load_sector_map("data/sectors.csv"),
        decision=DecisionConfig(risk_per_trade_pct=0.0085,
                                max_position_pct=0.25, sector_cap=2),
        benchmark_close=bench["Close"])

    out = {}
    for label, kw in CELLS.items():
        cfg = replace(base, slippage_bps=SLIP, ambiguity_mode="worst", **kw)
        _eq, trades, stats, drops, diag = run(prices, signals, cfg)
        out[label] = {"trades": trades, "stats": stats, "diag": diag}
        print(f"\n[T2] {label}")
        print(f"       policy               {diag['exposure_policy']}")
        print(f"       risk_off ceiling     {diag['exposure_risk_off_pct']}")
        print(f"       exposure_reduced_days {diag['exposure_reduced_days']}")
        print(f"       num_trades           {stats.get('num_trades')}")
        print(f"       expectancy_R         {stats.get('expectancy_R')}")
        print(f"       max_drawdown_pct     {stats.get('max_drawdown_pct')}")
        d = diag["drops_by_reason"]
        print(f"       drops regime_off     {d.get('regime_off', 'ABSENT')}")
        print(f"       drops exposure ceil  "
              f"{d.get('decision_engine/ exposure ceiling', 'ABSENT')}")

    blank, ceil = out["exp_blank"]["diag"], out["exp_ceiling"]["diag"]
    fail = []

    # ---- 1. did each arm actually take its own code path? -------------------
    if blank["exposure_policy"] != "constant":
        fail.append("exp_blank did not run as 'constant'")
    if ceil["exposure_policy"] != "regime_ceiling":
        fail.append("exp_ceiling did not run as 'regime_ceiling' -- H_noop")
    if blank["drops_by_reason"].get("regime_off", 0) <= 0:
        fail.append("exp_blank logged NO regime_off drops: the blank never "
                    "fired, so there was no risk-off day to disagree about and "
                    "the tie is vacuous")
    if ceil["drops_by_reason"].get("regime_off", 0) != 0:
        fail.append(f"exp_ceiling logged "
                    f"{ceil['drops_by_reason'].get('regime_off')} regime_off "
                    f"drops -- the BLANK ran under the ceiling policy. H_noop: "
                    f"the arm did not engage and T2 proves nothing")
    if blank["exposure_reduced_days"] != 0:
        fail.append("exp_blank moved its ceiling; 'constant' must never do that")
    if ceil["exposure_reduced_days"] <= 0:
        fail.append("exp_ceiling never lowered its ceiling on any signal day -- "
                    "H_noop")

    # ---- 2. equivalence, on the trade list, not on an average ---------------
    ta = [asdict(t) for t in out["exp_blank"]["trades"]]
    tb = [asdict(t) for t in out["exp_ceiling"]["trades"]]
    if len(ta) != len(tb):
        fail.append(f"trade COUNT differs: {len(ta)} vs {len(tb)}")
    else:
        diffs = [(i, a, b) for i, (a, b) in enumerate(zip(ta, tb)) if a != b]
        if diffs:
            fail.append(f"{len(diffs)} trade(s) differ field-by-field")
            for i, a, b in diffs[:5]:
                keys = [k for k in a if a[k] != b[k]]
                print(f"\n[T2] trade #{i} {a.get('ticker')} differs on {keys}")
                for k in keys:
                    print(f"        blank={a[k]!r}  ceiling={b[k]!r}")
    for k in ("expectancy_R", "max_drawdown_pct", "total_return_pct",
              "win_rate_pct"):
        va = out["exp_blank"]["stats"].get(k)
        vb = out["exp_ceiling"]["stats"].get(k)
        if va != vb:
            fail.append(f"{k}: {va} vs {vb}")

    print()
    if fail:
        print("[T2] FAILED -- T2's tie is NOT evidence of equivalence:")
        for f in fail:
            print("[T2]   " + f)
        return 1
    print("[T2] PASSED")
    print(f"[T2]   both arms engaged: blank fired "
          f"{blank['drops_by_reason']['regime_off']} regime_off drops; the "
          f"ceiling arm logged NONE and reduced its ceiling on "
          f"{ceil['exposure_reduced_days']} signal day(s)")
    print(f"[T2]   and produced byte-identical trade lists: {len(ta)} trades, "
          f"every field equal")
    print("[T2]   -> the eligibility blank and the ceiling writer are the same")
    print("[T2]      mechanism at a 0.00 risk-off ceiling. regime_20's 8/8")
    print("[T2]      result transfers to production's writer AT THE ENDPOINTS.")
    print("[T2]      It still says nothing about a graded ceiling.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
