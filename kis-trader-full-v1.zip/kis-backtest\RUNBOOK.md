# Step-5 backtest — step-by-step

Final version, 2026-08-06. Execute in order. Do not skip a verification step:
each one exists because something actually failed there during the build.

---

## STATE OF PLAY

**Built and tested — 50 checks green, lint clean:**

| file | what it is |
|---|---|
| `minervini_backtest.py` | portfolio loop, production entry/exit geometry, costs, band, survivorship tools, robustness check |
| `vcp_engine.py` | **verbatim** extraction from `sp500_v21.py` (re-verified byte-identical this pass) |
| `signals.py` | point-in-time Stage 1 + VCP loop |
| `self_test.py` (14) · `audit.py` (7) · `audit_full.py` (19) · `test_signals.py` (7) · `test_rank_and_stress.py` (3) | test suites |
| `cost_check.py` · `survivorship_pipeline.py` · `test_robustness.py` · `test_vcp_shape.py` | demonstrations that print real numbers |

**NOT built — you must do these:**
1. Download bars (§2)
2. Frozen sector CSV (§3)
3. Wikipedia constituent-change scrape (§7) — only needed for the survivorship step
4. Vendor `screen_contract.py` — never uploaded, so never verified

**Decided:** `rank_mode="rs_only"` · worst-bound decision rule · costs 0.25%/side + SEC
+ TAF · entry `pivot_limit` · equity `compounding` · exit rules reimplemented,
replay-validation consciously skipped.

**Still open:** FX (per-order conversion or pre-converted USD?) · which metric adjudicates
when `expectancy_R` and `total_return_pct` disagree — they did, in testing.

---

## 1. Set up — 20 minutes

```powershell
cd C:\Users\user\PyCharmMiscProject
mkdir kis-backtest
cd kis-backtest
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install "numpy==2.4.6" "pandas==3.0.3" pyarrow
pip install "yfinance==1.4.1" "lxml==6.1.1"
```

Copy in the 12 delivered files, plus **vendored unmodified** from `kis-trader`:
`decision_engine.py` and `screen_contract.py` at repo root.

**VERIFY — do not proceed until all four pass:**
```powershell
python self_test.py
python audit.py
python audit_full.py
python test_signals.py
```

I developed against pandas 3.0.2; you are pinning 3.0.3. If a rolling/ewm behaviour
changed, it surfaces here. That is the entire point of running these first.

---

## 2. Download bars — 1–2 hours unattended

```python
import yfinance as yf, pathlib
pathlib.Path("data/bars").mkdir(parents=True, exist_ok=True)
for t in tickers + ["^GSPC"]:
    df = yf.Ticker(t).history(period="max", auto_adjust=True)   # matches production
    if df.empty:
        print("MISS", t); continue
    df.index = df.index.tz_localize(None)
    df[["Open","High","Low","Close","Volume"]].to_parquet(f"data/bars/{t}.parquet")
```

Three traps, all of which bit during the build:
- Use `Ticker().history(auto_adjust=True)` — that is what the production screener uses.
  A different adjustment convention makes the pivot geometry wrong.
- `Ticker().history()` returns a **tz-aware** index; `yf.download()` returns tz-naive.
  Mixing them makes `d in df.index` silently miss. `PITBars` normalises on ingest, but
  normalise on write too so the files are self-consistent.
- **Keep Volume.** Dropping it forecloses the volume-confirmed entry style.

**VERIFY:** count tickers with ≥ 504 rows. Below that a name cannot be VCP-scored;
below 221 it cannot clear Stage 1 at all.

---

## 3. Frozen sector map — 30 minutes

Scrape GICS Sector from the same Wikipedia tables as the constituent lists. Write
`data/sectors.csv` with columns `ticker,sector`. Commit it.

**VERIFY:** `load_sector_map("data/sectors.csv")` must not raise. It fails closed on a
blank sector, because a blank silently disables the per-sector cap for that one name.

---

## 4. Signal generation — the long run

```python
import pathlib, pandas as pd
from signals import generate_signals, constant_universe

bars = {p.stem: pd.read_parquet(p) for p in pathlib.Path("data/bars").glob("*.parquet")}
signals = generate_signals(bars, scan_dates, constant_universe(tickers),
                           emit_threshold=0.0)     # emit everything; filter later
```

`emit_threshold=0.0` is deliberate — one signal pass feeds the whole threshold sweep.
Filtering here would silently fix parked parameter #1.

### 4b. THE GATE — do not skip

Run one signal pass dated **2026-08-05** and compare against the seed doc:

```
NTAP 73.55    UNH 67.58    BRKR 72.0    PTGX 62.54
```

If these do not reproduce, the extraction is measuring a different engine and every
downstream number is void. Debug here, not later.

Also read the `[signals]` drop counts. `incomplete_report` in bulk means the report
schema moved — the geometry lives nested under `rep["Extracted_Pattern"]`, and reading
the top level yields `None` and drops every single name. That exact bug cost a cycle.

---

## 5. First real run

```python
from minervini_backtest import BacktestConfig, DecisionConfig, run, load_sector_map

cfg = BacktestConfig(
    rank_mode="rs_only",                 # 2*RS+Stage2 minus Stage 2; multiplier is inert
    equity_mode="compounding",
    entry_mode="pivot_limit",
    vcp_threshold=80.0,
    sector_map=load_sector_map("data/sectors.csv"),
    decision=DecisionConfig(),           # production defaults, untouched
)
eq, trades, stats, drops, diag = run(prices, signals, cfg)
```

**Read `diag` BEFORE `stats`.** Specifically:
- `drops_by_reason` — if `decision_engine` rejections dominate, you are measuring the
  caps, not the threshold. This happened in testing: `sector_cap=2` pinned the portfolio
  to two names and made three different thresholds score identically.
- `held_ticker_time_frac` — how much of available ticker-time you were actually invested.
- `eod_open_forced` — positions still open at the end, force-closed and counted.

---

## 6. The sweep — this is the actual deliverable

```python
from minervini_backtest import robustness_check

settings = {f"thr_{t}": {"vcp_threshold": float(t)} for t in (55,60,65,70,75,80,85)}
r = robustness_check(prices, signals, cfg, settings=settings, metric="expectancy_R")
print(r["verdict"], r["winner_by_slippage"])
```

Every setting runs at 0/5/15/30 bps, always on the worst intrabar bound. Read the verdict:

- **`SETTINGS DID NOT DIFFERENTIATE`** — a constraint decided everything, not the
  parameter. Check `drops_by_reason_sample` and fix before rerunning. This is a **false
  pass**, not a result.
- **`NOT ROBUST`** — the winner flips across the cost grid. Report the instability. Do
  not pick the slippage level that gives the answer you prefer.
- **`ROBUST`** — you have a defensible recommendation.

In testing, `expectancy_R` said ROBUST while `total_return_pct` said NOT ROBUST on the
same data — the winner flipped at 15 bps, because looser thresholds trade more and pay
more cost. **Decide which metric adjudicates before you look at the numbers**, or you
will end up choosing the metric that gives the answer you wanted.

Then repeat for one parked parameter at a time: ATR band, `n_max`, `max_stop_pct`,
`require_trade_signal`. One at a time — never two.

---

## 7. Survivorship — two steps

**Step 1 (free, now).** Scrape Wikipedia's constituent-change tables. The Reason column
splits removals three ways, and they do not point the same direction:
- *bankruptcy* → the classic −100% tail
- *acquisition* → usually a premium — a **winner** your screen might well have held
- *rebalance / market-cap decline* → **still trading, still in yfinance** — reinstate
  these into the historical universe for free

```python
from minervini_backtest import universe_coverage, bias_gradient
cov  = universe_coverage(constituents_by_date, priceable=set(prices))
grad = bias_gradient(prices, signals, cfg, {...layers...})
```

`cov["worst_coverage_pct"]` goes in **every** reported result.

**Step 2 (only if you buy data).** `delisting_events={ticker: (date, return)}`. This is
what turns `stop_catches_frac` from an assumption into
`diag["stop_catches_frac_measured"]`.

**Until then**, `synthetic_delisting_stress()` injects delistings at the empirical base
rate (1.2%/yr NYSE-AMEX, 5.6%/yr Nasdaq) into names you actually traded. A bound, not a
measurement — report the worst draw.

**Current evidence says buy nothing yet.** Three independent indications that
survivorship exposure is small for this strategy: drag an order of magnitude below
transaction costs, low ticker-time occupancy, and a −1R stop that caps most declines
long before −55%. Buy data only if the free bounds turn out wide enough to flip a
parameter decision.

---

## 8. Every reported result must carry

1. Survivorship caveat + `worst_coverage_pct`
2. Stage 2 cut — the backtest screens a **wider** population than production does
3. The `stop_catches_frac` you assumed, or the measured value
4. `diag["exit_rules"]` — the exit engine is a reimplementation, **unvalidated** against
   `engine_v2`; replay-validation was skipped because the soak has never fired a live exit
5. The robustness verdict, not just the winning number
6. FX excluded — absolute returns are wrong if your account converts per order

---

## 9. Discipline

- One parameter at a time.
- Decide on the worst bound only.
- **Never paste an output number into production code.** The deliverable is a
  recommendation with evidence, applied deliberately in a separate session.
- `diag` before `stats`, every time.

---

## 10. Unrelated, still outstanding

`sp500_v21.py:795` — `return Nones` in `_read_finnhub_key()`. Not firing on the box,
since your `.env` resolves the key at line 784. But it sits on the designed missing-key
fallback path, so that graceful degrade is dead. One token: `return None`.
