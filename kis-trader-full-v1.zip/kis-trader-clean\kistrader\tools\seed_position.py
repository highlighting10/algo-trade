#!/usr/bin/env python3
"""
seed_position.py — hand an EXISTING broker holding to the engine (test / recovery).
==================================================================================

WHY THIS EXISTS
  Positions normally enter the engine ONLY through arm -> watch -> trigger ->
  fill, which writes them to the event store. A share lot you bought by hand in
  the KIS app (or one the DB lost to corruption / manual intervention) exists at
  the broker but NOT in the DB, so start()/recover() cannot see or manage it.
  This writes ONE synthetic ENTRY_ARMED+FILLED snapshot so the next `run` adopts
  it as a normal FILLED position and drives the full exit engine over it.

  Primary use: deterministic EXIT-side testing. Set --stop ABOVE the current
  price and the first OPEN cycle marks it EXITING and fires the SELL — the exit
  half proven in two minutes instead of waiting for a real stop breach. It is
  the exit-side analogue of emit_probe for the entry side.

SAFETY (it bypasses every arm-time gate, so it is deliberately hard to misfire)
  * MOCK ONLY unless --allow-live is given AND KIS_MOCK=0 is truthfully set.
  * requires --confirm — no accidental writes.
  * requires an explicit --stop: a protective stop is never guessed.
  * refuses if a live (non-terminal) snapshot already exists for that order_key
    (never shadow a real managed position).
  * writes to the SAME KIS_DB the loop reads — nothing else changes.

USAGE
  python -m kistrader.cli seed --ticker F --shares 2 --entry 12.30 --stop 13.00 \
      --exchange NAS --confirm
  (stop 13.00 > entry/price 12.30  ->  immediate EXITING on the next OPEN cycle)
"""
from __future__ import annotations

import argparse
import sys


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="kistrader seed", description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--ticker", required=True)
    ap.add_argument("--shares", type=int, required=True)
    ap.add_argument("--entry", type=float, required=True,
                    help="the price you actually paid (becomes entry_price; frozen R = entry-stop)")
    ap.add_argument("--stop", type=float, required=True,
                    help="protective stop. ABOVE entry => sells on the next OPEN cycle (exit test)")
    ap.add_argument("--exchange", default="NAS")
    ap.add_argument("--session-date", default=None,
                    help="order_key date (default: today per the US session clock)")
    ap.add_argument("--confirm", action="store_true",
                    help="required: acknowledges this writes a FILLED position to the DB")
    ap.add_argument("--allow-live", action="store_true",
                    help="permit seeding when KIS_MOCK=0 (otherwise mock-only)")
    args = ap.parse_args(argv)

    from kistrader.config import Config
    from kistrader.core.engine_v2 import EventStore, Position, PositionState
    from kistrader.core.run_loop import USSessionClock
    from kistrader.entry.screen_contract import make_order_key

    cfg = Config.from_env()

    # --- guards (fail closed) ---
    if not args.confirm:
        raise SystemExit("refusing without --confirm (this writes a FILLED "
                         "position straight to the DB, bypassing arm-time gates)")
    if not cfg.is_mock and not args.allow_live:
        raise SystemExit("KIS_MOCK=0 (live) — refusing to seed without --allow-live")
    if args.shares <= 0:
        raise SystemExit("--shares must be positive")
    if args.entry <= 0 or args.stop <= 0:
        raise SystemExit("--entry and --stop must be positive")

    risk = round(args.entry - args.stop, 4)   # may be NEGATIVE by design (stop>entry => exit test)
    session_date = args.session_date or USSessionClock().session_date()
    order_key = make_order_key(args.ticker, session_date)

    db = EventStore(cfg.db_path)
    # never shadow an existing live trade under the same key
    for snap in db.load_open_snapshots():
        if snap.order_key == order_key:
            raise SystemExit(f"a live snapshot already exists for {order_key} "
                             f"(state={snap.state.value}); refusing to seed over it")

    pos = Position(
        ticker=args.ticker, state=PositionState.FILLED, shares=args.shares,
        entry_price=float(args.entry), stop_loss_price=float(args.stop),
        initial_risk_per_share=risk, exchange=args.exchange,
        order_key=order_key, last_roll_date=session_date,
        live_order_qty=args.shares, live_order_filled=args.shares)

    # Two events mirror a real fill's trail: the armed record, then the fill.
    db.log(pos, "SEEDED_ENTRY_ARMED:manual", args.entry)
    db.log(pos, f"SEEDED_FILL:{args.shares}@{args.entry}", args.entry)

    rel = "ABOVE entry -> will EXIT on the next OPEN cycle" if args.stop > args.entry \
          else "below entry -> normal hold; sells only if price reaches the stop"
    print(f"seeded {args.ticker} {args.shares}sh @ {args.entry:.2f} stop {args.stop:.2f} "
          f"({rel})")
    print(f"  order_key={order_key}  db={cfg.db_path}  frozen R/sh={risk:+.4f}")
    print(f"  next `kistrader run` will recover and manage it. "
          f"Buy the {args.shares} share(s) in the broker app so holdings back the SELL.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
