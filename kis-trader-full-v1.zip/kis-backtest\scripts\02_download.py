"""
02_download.py -- download daily bars to data/bars/*.parquet. RESUMABLE.

Re-run it after a failure; it skips tickers already on disk. Expect 1-2 hours for
~1500 names.

Three conventions that MUST match production, each of which broke something during
the build:
  * yf.Ticker().history(auto_adjust=True) -- exactly what sp500_v21._fetch_history
    uses. A different adjustment convention silently moves every pivot.
  * tz-naive index. Ticker().history() returns tz-AWARE, yf.download() returns
    naive; mixing them makes `d in df.index` miss without error.
  * Volume is kept. Dropping it forecloses the volume-confirmed entry style.
"""
import pathlib as _pl
import sys as _sys
_sys.path.insert(0, str(_pl.Path(__file__).resolve().parent.parent))
import pathlib
import sys
import time

import pandas as pd
import yfinance as yf

BARS = pathlib.Path("data/bars")
MIN_ROWS_STAGE1 = 221      # screener rejects below this
MIN_ROWS_VCP = 504         # 2y window


def main():
    BARS.mkdir(parents=True, exist_ok=True)
    uni = pd.read_csv("data/universe.csv")
    tickers = sorted(set(uni["ticker"].astype(str))) + ["^GSPC"]

    done = {p.stem for p in BARS.glob("*.parquet")}
    todo = [t for t in tickers if t not in done]
    print(f"[download] {len(tickers)} total, {len(done)} already on disk, "
          f"{len(todo)} to fetch")

    misses, failures = [], []
    for i, t in enumerate(todo, 1):
        try:
            df = yf.Ticker(t).history(period="max", auto_adjust=True)
        except Exception as e:
            failures.append((t, f"{type(e).__name__}: {e}"))
            print(f"[download] {i}/{len(todo)} {t}: FAIL {type(e).__name__}")
            continue
        if df is None or df.empty:
            misses.append(t)
            print(f"[download] {i}/{len(todo)} {t}: EMPTY")
            continue
        need = ["Open", "High", "Low", "Close", "Volume"]
        if not all(c in df.columns for c in need):
            failures.append((t, f"missing columns, got {list(df.columns)}"))
            continue
        df = df[need].dropna()
        if getattr(df.index, "tz", None) is not None:
            df.index = df.index.tz_localize(None)
        df.to_parquet(BARS / f"{t}.parquet")
        if i % 50 == 0:
            print(f"[download] {i}/{len(todo)} ... {t} ({len(df)} rows)")
        time.sleep(0.15)                     # be polite; avoids throttling

    print(f"\n[download] done. {len(misses)} empty, {len(failures)} failed")
    for t, why in failures[:20]:
        print(f"[download]   FAIL {t}: {why}")
    if misses:
        print(f"[download]   EMPTY: {', '.join(misses[:30])}")

    # ---- coverage report: this decides what the backtest can even see --------
    short_stage1, short_vcp, ok = [], [], 0
    for p in BARS.glob("*.parquet"):
        n = len(pd.read_parquet(p, columns=["Close"]))
        if n < MIN_ROWS_STAGE1:
            short_stage1.append((p.stem, n))
        elif n < MIN_ROWS_VCP:
            short_vcp.append((p.stem, n))
        else:
            ok += 1
    print("\n[download] COVERAGE")
    print(f"[download]   {ok} ticker(s) with >= {MIN_ROWS_VCP} rows (VCP-scorable)")
    print(f"[download]   {len(short_vcp)} with {MIN_ROWS_STAGE1}-{MIN_ROWS_VCP} rows "
          f"(Stage 1 only, will score 0 on the VCP RS leg)")
    print(f"[download]   {len(short_stage1)} below {MIN_ROWS_STAGE1} rows "
          f"(cannot clear Stage 1 at all)")

    if not (BARS / "^GSPC.parquet").exists():
        print("\n[download] FATAL: ^GSPC missing. The VCP RS leg needs it; without "
              "it every name silently forfeits 8 points.")
        sys.exit(1)
    print("[download] ^GSPC present.")


if __name__ == "__main__":
    main()
