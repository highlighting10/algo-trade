#!/usr/bin/env python3
"""
PATCH 2 -- make every sweep stamp its own configuration, and refuse to run
unstamped.

WHY

Production cannot boot with a wrong parameter because `param_snapshot.py`
checks the live constants on every start. The backtest has no equivalent, and
that absence -- not any single wrong value -- is what lets a mislabelled run
look legitimate. Two concrete holes it leaves open today:

  * `minervini_backtest.run()` sets two of three ranking weights and inherits
    the third from whichever `decision_engine` was imported. Measured
    2026-08-22 the vendored 2-weight copy is live and every mode is correct --
    but delete that copy and `rs_only` inverts, with nothing in the output
    saying so. `--rank-mode` DEFAULTS to `rs_only`.

  * The vendored engine's sizing defaults are `risk 0.0075 / cap 0.20` against
    the frozen `0.0085 / 0.25`. A sweep run without `--risk-pct` and
    `--max-position-pct` silently uses pre-migration values.

WHAT THIS CHANGES

Immediately after `args = ap.parse_args()`, before a single bar is loaded:

  * resolve and sha256 the decision_engine that is actually imported;
  * PROVE each rank mode against a conflicting-order fixture rather than
    inferring it from the weights;
  * require the sizing flags whenever the engine defaults differ from frozen;
  * refuse to run on any mismatch, and print a one-line stamp when clean.

It runs in well under a second and changes nothing about the simulation. The
only behavioural difference is that a misconfigured sweep now stops instead of
producing numbers whose labels are wrong.

PRECONDITION

`harness_snapshot.py` must sit at the kis-backtest ROOT, beside
`minervini_backtest.py`. `06_sweep.py` line 3 already does
`sys.path.insert(0, <repo root>)`, so a root-level module imports cleanly from
any working directory; a copy inside `rank/` would not.

    python patch_2_sweep_guard.py --file scripts\\06_sweep.py
    python patch_2_sweep_guard.py --file scripts\\06_sweep.py --revert
"""
from __future__ import annotations

import argparse
import os
import sys

MARK = "# --- PATCH 2: harness snapshot guard ---"

ANCHOR = """    args = ap.parse_args()

    bars = {p.stem: pd.read_parquet(p)"""

REPLACEMENT = '''    args = ap.parse_args()

    # --- PATCH 2: harness snapshot guard ---
    # Before any bar is read: pin WHICH decision_engine is imported, PROVE the
    # rank modes against a conflicting-order fixture, and require the sizing
    # flags when the engine's defaults differ from the frozen set. A sweep whose
    # configuration cannot be stated is a sweep whose numbers cannot be labelled.
    try:
        from harness_snapshot import snapshot
    except ImportError:
        raise SystemExit(
            "[sweep] harness_snapshot.py not found. It must sit at the "
            "kis-backtest root, beside minervini_backtest.py.")
    _snap = snapshot(risk_pct=args.risk_pct,
                     max_position_pct=args.max_position_pct,
                     require_explicit_sizing=True,
                     harness_path="minervini_backtest.py")
    if not _snap.ok:
        for _p in _snap.problems:
            print(f"[sweep] REFUSING TO RUN: {_p}")
        raise SystemExit(2)
    print(f"[sweep] {_snap.one_line()}")
    # --- end PATCH 2 ---

    bars = {p.stem: pd.read_parquet(p)'''


def apply(path, revert=False):
    with open(path, encoding="utf-8") as fh:
        src = fh.read()
    already = MARK in src

    if revert:
        if not already:
            print("PATCH 2 is not applied; nothing to revert.")
            return 1
        if src.count(REPLACEMENT) != 1:
            print("  [FAIL] patched block not found exactly once; refusing to revert.")
            return 1
        src = src.replace(REPLACEMENT, ANCHOR)
        _write(path, src)
        print("PATCH 2 reverted. File is byte-identical to the original.")
        return 0

    if already:
        print("PATCH 2 is ALREADY APPLIED. Refusing to run twice (standing rule 4).")
        return 1
    n = src.count(ANCHOR)
    if n != 1:
        print(f"  [FAIL] anchor matched {n} times, expected 1. Nothing written.")
        return 1
    _write(path, src.replace(ANCHOR, REPLACEMENT))
    print(f"  [ OK ] guard wired into {path}")
    print("\nPATCH 2 applied. Confirm with a deliberately bare invocation:")
    print("  python scripts\\\\06_sweep.py --param threshold        <- must EXIT 2")
    print("  python scripts\\\\06_sweep.py --param threshold --risk-pct 0.0085 "
          "--max-position-pct 0.25   <- must print the stamp")
    return 0


def _write(path, src):
    with open(path, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(src)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--file", default=os.path.join("scripts", "06_sweep.py"))
    ap.add_argument("--revert", action="store_true")
    args = ap.parse_args()
    if not os.path.isfile(args.file):
        print(f"FATAL: no such file {args.file!r}")
        return 2
    return apply(args.file, revert=args.revert)


if __name__ == "__main__":
    sys.exit(main())
