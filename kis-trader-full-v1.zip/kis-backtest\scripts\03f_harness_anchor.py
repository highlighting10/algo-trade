"""
03f_harness_anchor.py -- the reproduction anchor that SURVIVES an engine change.

    python scripts/03f_harness_anchor.py --freeze     # BEFORE touching the engine
    python scripts/03f_harness_anchor.py --verify     # after, and in CI

WHY THIS EXISTS

`03_gate.py` pins ten production VCP SCORES. It is the project's only
reproduction anchor, and it answers one question: "does the extraction reproduce
production?"

But read the failure modes 03_gate's own error path enumerates when it fails:

    - corporate actions rescaling adjusted history
    - window length (tail(N)) and window mode (calendar)
    - as-of date -- the effective data date differs from the labelled run date
    - population split -- RS is a percentile per universe
    - the bars themselves

**Every one of those is a HARNESS failure. Not one is an engine failure.** Yet
the quantity it pins is a final VCP score -- the single number that legitimately
moves the moment `_zigzag_pivots` is touched. So the adaptive-threshold work
(`RESULT_20260829_zigzag_calibration` sec.2: "the threshold SHAPE is wrong, not
its value") destroys the anchor at exactly the moment one is most needed, and it
destroys it for a reason that has nothing to do with what the anchor is for.

This file is the other half. It pins the same reproduction question using only
quantities the VCP engine cannot reach.

WHAT IT PINS, AND WHY EACH IS ENGINE-INDEPENDENT

Measured in `vcp_engine.py`, not assumed -- all three of `set_fetcher`,
`compute_rs_ratings` and `check_minervini_technicals` are defined OUTSIDE the
`def safe_divide(` .. `VCPAnalyzerV3 = VCPAnalyzerV4` block that
`engine_reference.py` extracts, and `check_minervini_technicals` returns from
moving averages, the 52-week range and the 6-month return without ever reaching
the ZigZag:

  * **the bar window** -- row count, first and last session, and a sha of the
    OHLCV values. `PITBars.fetch` is the whole look-ahead guard. Catches a
    corporate action rescaling history, a changed `period_mode`, a changed
    window length, and a re-download that moved a price.
  * **the as-of resolution** -- which session the requested date resolved to.
  * **Stage 1** -- `structural_pass`, `current_price`, `high_20d`,
    `stock_6m_return`, `raw_rs`, `status`. Pure Trend Template.
  * **the RS rating** -- a percentile over the population scanned at T. Catches
    a pooled or mis-split universe, which changes every rating.
  * **population sizes and Stage-1 survivor counts** -- the split itself.

WHAT IT DELIBERATELY DOES NOT PIN

Any VCP score, wave count, pivot, or base geometry. Those are the engine, they
are supposed to move, and `engine_reference.json` already measures them
stage-by-stage across all three engine copies. Pinning pivots here would
reproduce 03_gate's mistake one layer down: the ZigZag change exists to move
pivots, so a pivot anchor breaks by design too.

HOW THE THREE ANCHORS DIVIDE THE WORK, AFTER THIS

    03f_harness_anchor.json   the INPUTS reproduce      must NOT move
    engine_reference.json     WHICH STAGE moved, by how much   re-frozen
    03_gate.py's ten scores   the engine as of a commit  re-pinned, deliberately

Only the first is an invariant across an engine change. That separation is the
point: today a single failing number cannot tell you whether the bars moved or
the engine did, and those need opposite responses.

USE, in order, around the ZigZag change

    python scripts/03f_harness_anchor.py --freeze      # on the CURRENT engine
    python scripts/03_gate.py                          # 8/10, the known state
    ... change _zigzag_pivots ...
    python scripts/03f_harness_anchor.py --verify      # MUST be unchanged
    python engine_reference.py --verify --clean <...>  # WHICH stage moved
    python scripts/03_gate.py                          # will fail: re-pin it

A `--verify` failure here means the harness drifted and **no engine conclusion
from that run is readable**, whatever `engine_reference` says.
"""
import pathlib as _pl
import sys as _sys
_sys.path.insert(0, str(_pl.Path(__file__).resolve().parent.parent))

import argparse
import hashlib
import json
import pathlib
import sys

import pandas as pd

import vcp_engine as ve
from signals import PITBars, VCP_PERIOD, populations_from_universe

# The same ten names 03_gate pins, so the two anchors speak about one population.
GATE_TICKERS = ("NTAP", "UNH", "NUE", "STT", "HPE",
                "BRKR", "PTGX", "IRDM", "OKTA", "LFST")
GATE_DATE = pd.Timestamp("2026-08-03")
BENCHMARK = "^GSPC"
DEFAULT_OUT = "harness_anchor.json"
OHLCV = ("Open", "High", "Low", "Close", "Volume")


def load_bars(tickers):
    bars = {}
    for t in tickers:
        p = pathlib.Path(f"data/bars/{t}.parquet")
        if p.exists():
            bars[t] = pd.read_parquet(p)
    return bars


def bar_sha(df):
    """A text digest, not a memory digest: float bit patterns and column dtypes
    are not stable across pandas/pyarrow versions, and a version bump reading as
    a data change would make this anchor cry wolf."""
    cols = [c for c in OHLCV if c in df.columns]
    lines = []
    for ts, row in df[cols].iterrows():
        vals = "|".join("nan" if pd.isna(v) else f"{float(v):.6f}" for v in row)
        lines.append(f"{pd.Timestamp(ts).strftime('%Y-%m-%d')}|{vals}")
    return hashlib.sha256("\n".join(lines).encode()).hexdigest()[:16], cols


def r6(v):
    return None if v is None else round(float(v), 6)


def measure(asof: str):
    uni = pd.read_csv("data/universe.csv")["ticker"].astype(str).tolist()
    bars = load_bars(sorted(set(uni + list(GATE_TICKERS) + [BENCHMARK])))
    missing = [t for t in GATE_TICKERS if t not in bars]
    if missing:
        print(f"[anchor] FATAL: no bars for {missing}. Run 02_download.py first.")
        sys.exit(1)
    print(f"[anchor] {len(bars)} ticker(s) loaded")

    server = PITBars(bars)
    cal = server.calendar()
    want = pd.Timestamp(asof)
    if want in cal:
        gate_date = want
    else:
        prior = cal[cal <= want]
        if not len(prior):
            print(f"[anchor] FATAL: no sessions on or before {want.date()}")
            sys.exit(1)
        gate_date = prior[-1]
        print(f"[anchor] {want.date()} is not a session; using {gate_date.date()}")

    ve.set_fetcher(server.fetch)
    server.set_date(gate_date)

    pops = populations_from_universe("data/universe.csv")
    have = set(bars)
    pops = {k: [t for t in v if t in have] for k, v in pops.items()}
    print("[anchor] populations: "
          + ", ".join(f"{k}={len(v)}" for k, v in pops.items()))

    # Mirror generate_signals' Stage-1 loop exactly: raw_rs is recorded even when
    # structural_pass is False, because the RS percentile is taken over every
    # successfully scored name and not only the survivors.
    of_pop, ratings, pop_stats = {}, {}, {}
    stage1 = {}
    for pop, tickers in pops.items():
        raw, n_pass = {}, 0
        for t in tickers:
            of_pop[t] = pop
            try:
                res = ve.check_minervini_technicals(t)
            except Exception as e:
                res = (False, None, None, None, None,
                       f"exception:{type(e).__name__}")
            ok, price, hi20, ret6m, raw_rs, status = (
                res[0], res[1], res[2], res[3], res[4], res[5])
            if raw_rs is not None:
                raw[t] = raw_rs
            if ok:
                n_pass += 1
            if t in GATE_TICKERS:
                stage1[t] = {"pass": bool(ok), "price": r6(price),
                             "high_20d": r6(hi20), "ret_6m": r6(ret6m),
                             "raw_rs": r6(raw_rs), "status": status}
        ratings.update(ve.compute_rs_ratings(raw) or {})
        pop_stats[pop] = {"size": len(tickers), "scanned": len(tickers),
                          "rs_scored": len(raw), "stage1_pass": n_pass}
        print(f"[anchor]   {pop}: scanned {len(tickers)}, rs_scored {len(raw)}, "
              f"stage1_pass {n_pass}")

    per = {}
    for t in GATE_TICKERS:
        df = server.fetch(t, VCP_PERIOD)
        if df is None or df.empty:
            per[t] = {"window": None}
            continue
        sha, cols = bar_sha(df)
        rs = ratings.get(t)
        per[t] = {
            "population": of_pop.get(t),
            "window": {"rows": int(len(df)),
                       "first": str(pd.Timestamp(df.index[0]).date()),
                       "last": str(pd.Timestamp(df.index[-1]).date()),
                       "cols": list(cols),
                       "ohlcv_sha": sha},
            "close_last": r6(df["Close"].iloc[-1]) if "Close" in df else None,
            "stage1": stage1.get(t),
            "rs_rating": None if rs is None else int(rs),
        }

    return {"asof_requested": str(pd.Timestamp(asof).date()),
            "gate_date": str(gate_date.date()),
            "period": VCP_PERIOD,
            "period_mode": server.period_mode,
            "universe_rows": len(uni),
            "bars_loaded": len(bars),
            "populations": pop_stats,
            "tickers": per}


def flatten(d, prefix=""):
    out = {}
    for k, v in (d or {}).items():
        key = f"{prefix}{k}"
        if isinstance(v, dict):
            out.update(flatten(v, key + "."))
        else:
            out[key] = v
    return out


def main():
    ap = argparse.ArgumentParser()
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--freeze", action="store_true")
    g.add_argument("--verify", action="store_true")
    ap.add_argument("--asof", default=str(GATE_DATE.date()))
    ap.add_argument("--out", default=DEFAULT_OUT)
    a = ap.parse_args()

    print("=" * 74)
    print(f"  HARNESS ANCHOR -- {'FREEZE' if a.freeze else 'VERIFY'}   "
          f"as-of {a.asof}")
    print("  engine-independent by construction: no VCP score, wave, pivot or")
    print("  base geometry is recorded here.")
    print("=" * 74)

    now = measure(a.asof)

    if a.freeze:
        with open(a.out, "w", encoding="utf-8") as fh:
            json.dump(now, fh, indent=1, sort_keys=True)
        print(f"\n  FROZEN -> {a.out}  ({len(now['tickers'])} tickers)")
        print("  Run --verify after ANY change. This one must NOT move when the")
        print("  engine changes; if it does, the harness drifted and no engine")
        print("  conclusion from that run is readable.")
        return 0

    if not pathlib.Path(a.out).is_file():
        print(f"\n  {a.out} not found. Run --freeze first, on the harness you "
              f"are changing FROM.")
        return 2
    old = json.load(open(a.out, encoding="utf-8"))

    a_old, a_new = flatten(old), flatten(now)
    keys = sorted(set(a_old) | set(a_new))
    diffs = [(k, a_old.get(k, "<absent>"), a_new.get(k, "<absent>"))
             for k in keys if a_old.get(k, "<absent>") != a_new.get(k, "<absent>")]

    print(f"\n  {len(keys) - len(diffs)} field(s) unchanged, {len(diffs)} moved")
    if not diffs:
        print("\n  HARNESS UNCHANGED. The extraction still reproduces production's")
        print("  INPUTS. Any score movement is therefore the engine, which is what")
        print("  engine_reference.py is for.")
        return 0

    print("\n  HARNESS MOVED. Stop -- no engine conclusion from this run is")
    print("  readable until this is explained.")
    for k, o, n in diffs[:40]:
        print(f"    {k:44} {o}  ->  {n}")
    if len(diffs) > 40:
        print(f"    ... and {len(diffs) - 40} more")
    print("\n  Where to look, in the order 03_gate already learned:")
    print("    gate_date / asof_requested   the effective data date moved")
    print("    *.window.*                   bars re-downloaded, corporate action,")
    print("                                 or period/period_mode changed")
    print("    populations.*                the universe split changed; RS is a")
    print("                                 percentile per population")
    print("    *.stage1.*                   Trend Template inputs moved")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
