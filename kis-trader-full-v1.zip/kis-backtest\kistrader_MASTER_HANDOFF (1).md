# kistrader — MASTER HANDOFF & CLOUD SETUP

Written 2026-08-01, revised 2026-08-02. Supersedes the 2026-08-01 master and every prior cloud_provisioning.md. This is the single seed file for the Step 6 setup chat — it merges the project handoff with the full provisioning runbook so no second document is required.

Numbering is ORIGINAL: Step 5 = backtest, Step 6 = unattended cloud mock soak.

**Revision note (2026-08-02, revised 2026-08-03 twice).** A pre-Oracle code session closed the `arm_today` freshness defect, found and closed a crash-storm path that was not previously known, audited the deploy manifest against disk, escalated silent callback-exception alerts to CRITICAL, and **verified the deploy set by full dry-run install on a clean venv**. Suite is now **115 unit / 47 e2e / 23 seed+close**, green both in the repo and from the USB deploy copy. Sections carrying material change are marked ⟳.

**◆ Revision note (2026-08-05) — THE BOX IS BUILT AND THE SOAK IS RUNNING.** Bring-up ran across 2026-08-03 evening → 2026-08-05 12:30 KST. All fifteen bring-up steps are closed. The loop, dead-man and screener timer are enabled, reboot-verified, and the dead-man has been proven end-to-end against a real stopped loop. Day 1 of the soak is the ET session of Wed 2026-08-05.

**The single most important finding of this session: item (a), the §3.9.1 open-order gate PASS case, is NOT CLOSABLE ON MOCK.** Proven empirically — see Part I §9a. It moves to the live-cutover checklist as a blocker. The soak's remaining value is items (b), (c), and multi-day unattended uptime evidence.

Sections carrying change from the 08-04/05 bring-up are marked ◆.

---

# PART I — WHERE THE PROJECT STANDS

## 1. Step status

| step | state |
|---|---|
| Step 3 — entry/exit pipeline | CLOSED (strong sense) |
| Step 4 — supervised forward test | substantially done, accruing |
| Step 5 — backtest | ◆ NOT STARTED. Separate repo. Harness build runs in parallel with the soak (Aug 5–12); parameter decisions wait until the soak closes. |
| Step 6 — Oracle unattended soak | ◆ **RUNNING.** Box built and verified 08-03→08-05; units enabled 2026-08-05 03:11 UTC; reboot-verified 03:20 UTC. Day 1 = ET session Wed 2026-08-05. |

Step 3 was declared closed 2026-08-01. Every segment proven live against real KIS mock responses: screen → emit → gate → plan → WATCH → pivot-cross → capped limit → fill → reconcile → monitor handoff → STOP-HIT → SELL → CLOSED.

ENTRY proven 2026-07-21 — CASY & JBHT armed as watches, crossed pivots, placed capped limits, filled, adopted (incl. Bug-B late fill), managed.
EXIT proven 2026-07-23 — seeded F hit stop → SELL (KIS order 0000041848) → flat-confirmed → CLOSED in 58s, ONE order id, no double-sell through an ambiguous mock settle.

⟳ **Suites: 115 unit / 47 e2e / 23 seed+close** (+15 emit, run separately). Green on Windows/Py3.14 and sandbox/Py3.12 — Ubuntu stock 3.12 is fine. The e2e count rose from 33 to 47 with the E6 freshness-gate block (14 checks) added 2026-08-02.

State DB archived 2026-08-01 to `C:\Users\user\kis_engine_state_step3_archive.db` (49,152 bytes) via `sqlite3.backup` — not a file copy; the DB runs in WAL mode and has live `.db-wal` / `.db-shm` beside it.

## 2. The three items the soak exists to close

All three need (i) a triggering candidate and (ii) days of unattended uptime. None can be forced on a laptop.

**a. §3.9.1 open-order gate, PASS case.** ◆ **NOT CLOSABLE ON MOCK — proven 2026-08-05. Moved to the live-cutover blocker list (Part I §9a).** The gate will execute during the soak and will report PASS, but it will be discriminating nothing: mock `inquire-nccs` returns a valid empty regardless of what is actually resting, so `list_open_order_tickers` always returns `{}`. **Do not read a soak-period PASS as evidence.** The systemd unit still must NOT carry `--no-open-order-check` — the flag's absence is correct — but the item itself now closes at live cutover, not here. See Part III §3.

**b. Exit alerts on a fresh live-triggered fill.** The transition-alert layer is offline-proven (E5) only; never fired on a live-triggered position.

⟳ **These alerts are WARN, not CRITICAL — they will NOT buzz your phone.** `notifier.classify` matches `"closed:"` (with a colon); the loop emits `"MU CLOSED — STOP_HIT…"`, which does not match, so it is logged locally and never pushed. This is consistent with the notifier's stated QUIET PHONE design, but it means **item (b) is confirmed by reading `kistrader_alerts.log`, not by receiving a notification.** Going into the soak expecting a buzz would cause a working layer to be read as broken.

⟳ **This is now a DECISION, not an oversight.** Escalating exits was considered and deliberately parked on 2026-08-03. A stop that fires, sells and closes is the engine *working* — there is nothing to act on, and pushing it would permanently redefine what a buzz means, carrying into live cutover where alert fatigue is dangerous. The stability gap that *did* need closing was silent callback exceptions (§5f), which is a different problem: a position going unmanaged with no signal. Revisit exit pushes after the soak, with real data on how often they would actually fire.

**c. `on_close` / EMA-trail / stall-exit firing live.** Offline-proven (E3: `close_provider` was queried on close, `ema_provider` was queried on close). Never fired live — early nights killed the loop before 05:00 KST, later nights had no held position crossing.

Also deferred by design: buying-power provider never verified as truthful USD (`build_pipeline` still marks it `# VERIFY`); PARTIAL_TAKEN never fired; token refresh across the ~23h expiry in a long-running process; live sell TR TTTT1006U (live-cutover gate).

## 3. What the 2026-07-31 → 08-01 session added

First night ever to run past the close. The loop reached 05:00 KST (16:00 ET) and continued ~3h beyond. Session-close path fired correctly:

```
05:00:02 WARN PANW watch EXPIRED — session close (pivot 340.13 never triggered)
05:00:02 WARN PTGX watch EXPIRED — session close (pivot 141.08 never triggered)
05:00:02 WARN session close: 2 untriggered watch(es) expired
```

The full watch lifecycle — arm → tick → expire-at-close — is now proven live end to end. Note this does not close item (c): no held position crossed, so `on_close`'s exit logic still never fired.

**JBHT did not stop out.** Entry 289.47, stop 270.94 (6.4%). A premarket print showed ~-6.7% from entry (≈270.08, through the stop by <$1), but the position survived the session. Leading read: the engine correctly ignored premarket and regular-hours trading never breached. **Not yet confirmed against the actual intraday low — do that before filing it as proven behaviour.**

**FCUV anomaly test** — deliberate, and it passed. JH manually bought 30 shares of a stock he expected to crash, to see how the reconciler handles an unknown holding. Result: detected it, named it, escalated to CRITICAL (not WARN), refused to adopt it, refused to act on it, and kept managing CASY and JBHT normally alongside it for 3.5 hours. "Confirm, never infer" held under a live anomaly it had never seen.

Why refusing was correct: the broker is authoritative that 30 shares exist, but a stop is not a broker fact — stops live only in `kis_engine_state.db`. Adopting would mean inventing the single most important number in the system. The designed resolution is `seed_position.py`, where the human supplies the stop explicitly — confirm, not infer. **General rule: broker truth is authoritative for refusing to act, not for beginning to act.**

But it surfaced a real gap: **an orphan holding is invisible to the exposure ceiling.** `_account_state()` computes `open_notional` from `self.positions()` (local only), while `held_tickers` comes from broker truth — two gates, two sources. The cash gate is safe (`_buying_power()` reads the broker), but percent-deployed is understated by exactly the orphan's size. Not a soak blocker; IS a live-cutover blocker.

**Alert dedup verified.** 42 identical CRITICAL log lines over 3.5h produced 9 Telegram pushes. Dedup works; only the log is verbose. Not a soak blocker.

**One holdings unreadable at 04:48** with the loop running. `holdings_probe -n 5` with the loop stopped came back 5/5 clean. Probe's own verdict names contention as the suspect. Distinct from the earlier laptop-sleep cases.

**Laptop died with an internal error mid-session.** Post-crash check: zero Python processes survived. Broker state confirmed intact — CASY 21, FCUV 30, JBHT 85.

## 4. Code changes 2026-08-01

**Quote-UNKNOWN observability patch** (`kistrader/entry/entry_manager.py`, `_watch_tick`).

Important correction to an earlier belief: the zero-quote guard already existed on both paths and was correct —

- I12 §4.5.3 — zero/failed quote → no tick (returns None), None fields → no tick
- I15 (b) — zero quote holds the watch, None quote holds the watch

A falsy quote could never trigger an entry nor produce a false price for a held position. **The defect was that the guard was silent, not unsafe.** When F was seeded as NAS, `get_quote` returned 0 and the position was skipped correctly, safely, and invisibly. The patch counts consecutive UNKNOWN reads per watch and alerts once at 20 consecutive (`n == 20`, not `>=`, so no alert storm); the counter resets on any good quote. The safety branch is byte-identical.

This matters most at a lowered threshold: with thin names, a silent quote failure is indistinguishable from "no candidate reached its pivot" — which is the primary signal the soak produces.

## 5. ⟳ Code changes 2026-08-02 (pre-Oracle session)

All in `kistrader/entry/pipeline.py`, `tests/test_pipeline_e2e.py`, `kistrader/notifier.py`, `supervisor.py`, `force_stop.py`. Suite re-run green at **115 / 47 / 23**.

### 5a. Freshness gate in `arm_today` — the stale-CSV defect is CLOSED

The defect as previously stated ("`arm_today` does not check `candidates.csv` freshness") was confirmed, then **narrowed by source reading**. `screeners/candidate_emit.py` purges stale rows when it *writes*: line 192 `if old.session_date != session_date: stale += 1`, and the stale row is counted and dropped, never carried into `kept`. So the merged file can only ever contain today's rows.

**Therefore the only path to a stale `candidates.csv` is the screener not running at all** — timer misfire, box down at 08:00 ET, or a crash before any write. This is exactly the unattended failure the soak must survive.

The gate now sits in `arm_today`, immediately after the read and **before** `universe.ensure()` and `_account_state()`, so a stale day costs no KIS token:

- Rows whose `session_date` != the session date computed by `arm_today` are dropped.
- **Partial mismatch** → keep the fresh rows, WARN with an exact count and the offending dates.
- **Zero fresh rows** → arm nothing, alert `ARM BLOCKED` (CRITICAL).
- **Blank/missing `session_date`** → treated as stale, reported as `<missing>`. (`Candidate.problems()` never validates `session_date`, so a blank date otherwise passes validation clean.)

Format safety confirmed, not assumed: `USSessionClock.session_date()` is `.strftime("%Y-%m-%d")` on ET; `run_screeners.sh` uses `TZ=America/New_York date +%F`. Identical format, identical timezone. A format mismatch here would have rejected 100% of rows every day while reporting "entirely STALE" — i.e. it would have read as *the screener broke*, not *the gate broke*.

**Recovery from a block is fix-the-file THEN RESTART.** `_auto_armed_date` is claimed on *attempt* (before the read), which is the correct fail-closed shape — it prevents a per-cycle retry storm — but it means correcting the CSV alone will not re-arm that session. `_auto_armed_date` is in-memory and clears on restart. Both CRITICAL alert texts say so explicitly.

### 5b. Read guard — a crash-storm path that was NOT previously known

`read_candidates` opens the file with no guard. `arm_today` did not wrap it. `PipelineLoop.cycle()` does not wrap `arm_today`. And **`RunLoop.run_forever` has no per-cycle try/except** — it is `self.start()` then `while not self._stop: phase = self.cycle(); sleep_fn(...)`.

So a missing `candidates.csv` raised `FileNotFoundError` straight out of `run_forever` and killed the process. Because the failure is *deterministic*, every supervisor restart hit it again: restart loop → crash-storm guard → rc 3 → deliberate give-up. **A failed screener would have stopped the loop from MANAGING held positions.** Stops unwatched.

This was live on soak day 1 by construction: `candidates.csv` is correctly excluded from the deploy, so the box starts without one.

`arm_today` now wraps the read; any exception alerts `ARM BLOCKED` and returns `[], []`. Note the deliberate asymmetry: `RunLoop.cycle` already guards every monitor callback, and `entry.poll()` is left unguarded on purpose — a transient network fault clears on restart, which is what the supervisor is for. Only the deterministic failure needed the guard.

`on_bad` now collects into a list and alerts after the try block, so an exception from the alert path can never be misreported as a file problem. Output is byte-identical to the previous inline lambda (`why` is a list in both).

### 5c. `ARM BLOCKED` severity token — `notifier.py`

**`notifier.classify` infers severity from message text.** `CRITICAL_SUBSTRINGS` is checked against the lowercased message. **The literal word "CRITICAL" is not in that tuple and means nothing to the classifier.** A first draft of these alerts used it and would have classified as WARN — a fix for silent failure that was itself silent.

`"arm blocked"` was added to `CRITICAL_SUBSTRINGS`. Verified:

```
classify('ARM BLOCKED: candidates.csv is entirely STALE - …')  -> CRITICAL
classify('freshness gate: dropped 1 STALE row(s) …')           -> WARN
classify('arm_today: 5 candidates -> 2 planned -> 2 armed')    -> WARN
```

The pre-existing equity fail-safe (`"arm_today: no equity reading — skipping arm"`) had the same gap — the engine refusing to arm for a whole session did not reach the phone. Re-worded to `ARM BLOCKED: no equity reading — skipping arm (fail-safe)`. No test asserted on the old string (scan confirmed: the only `fail-safe` hits in `tests/` are `arm_batch`'s open-order case and an EMA comment).

The partial-drop WARN is prefixed `freshness gate:` rather than `arm_today:` — E4 counts `m.startswith("arm_today:")` to prove auto-arm fires once per session, and an `arm_today:`-prefixed WARN would make that idiom double-count on any stale-row day.

`dedup_key` collapses digits, so consecutive days' stale alerts share a key; the cooldown is 3600s and arms are ~24h apart, so no suppression.

### 5d. Test suite writes no heartbeat

`_assemble` in `test_pipeline_e2e.py` constructed `PipelineLoop` without `heartbeat_path`, so it took the default `"heartbeat.txt"` and `_heartbeat` wrote it on every cycle of every e2e test. Harmless on the laptop; **on the box, running `kistrader test` while `kistrader-deadman.service` is active would refresh the heartbeat and mask a genuinely dead loop.** `_assemble` now passes `heartbeat_path=None`. No test asserts on it.

### 5e. Docstring prohibitions

`supervisor.py` line 30's USAGE example still showed `--no-open-order-check`, and `argparse` uses `description=__doc__` — so it printed verbatim on every `--help`. Replaced with an explicit prohibition rather than a deletion, so the absence is stated rather than merely blank.

`force_stop.py` printed `"DONE. Wait ~60s, then: python -m kistrader.cli run --no-open-order-check"`. `force_stop.py` **ships to the box**, and the moment you run it is a mid-soak emergency — the tool was handing you a gate-disabling restart command, pre-typed, at the worst possible moment. It also contradicted the systemd design. Now prints `>=65s` (the token floor, not the boundary) and `sudo systemctl start kistrader`.

The flag definition in `cli.py:171` and its uses in `make_plumbing_csv.py` are correct and stay — the flag is legitimate for supervised plumbing runs, and `make_plumbing_csv.py` does not ship.

### 5f. ⟳ `" error:"` escalation — silent unmanaged positions

Tracing `run_loop.py`'s error paths through `classify` found that **four exception handlers were WARN**:

```python
self.alert(f"on_tick({pos.ticker}) error: {ex}")
self.alert(f"on_close({pos.ticker}) error: {ex}")
self.alert(f"on_session_open({pos.ticker}) error: {ex}")
self.alert(f"advance_trading_day error: {ex}")
```

`"error"` alone is not in `CRITICAL_SUBSTRINGS` — only `"handoff error"` is — and `{ex}` is `str(e)`, which omits the exception type, so `"exception"` does not match either.

**`on_tick` is where the stop is evaluated.** A recurring `on_tick` exception means a held position's stop is not being checked, every cycle, with no signal. That is not a missing notification about success; it is a position going unmanaged silently — the same shape as the exchange-code bug and the pre-08-01 quote guard.

`" error:"` was added to `CRITICAL_SUBSTRINGS`. Every `alert()` call in `entry_manager.py` (25) and `engine_v2.py` (15) was enumerated and classified before and after. **Newly escalated — 7, all correct:** the four `run_loop.py` callbacks, `buying_power_provider error:` (cash gate degraded; the provider is still marked `# VERIFY`), `reconcile error:` (broker state unverifiable), and `partial rejected: network error:` (failure to reduce risk).

**Zero false positives.** WATCHING, TRIGGERED, FILLED, EXITING, CLOSED, holdings-unreadable, watch-EXPIRED, `QUOTE UNKNOWN x20`, watchdog feed-silent, the freshness-gate WARN and the arm summary all stay exactly where they were; `adopted late-fill … now managed` and `started;` stay INFO. **Every `" error:"` string in the codebase sits inside an exception handler — there is no routine one.** That is the fact that makes the broad match safe.

**Why broad rather than an explicit list.** The precise alternative was six tokens (`"on_tick("`, `"on_close("`, …). It was rejected: the defect being fixed *was* that a new alert silently defaulted to WARN, and an explicit list reproduces that failure mode for every error alert added later. `" error:"` fails toward noise rather than silence — fail-closed-never-silent, applied to observability.

**Frequency.** Worst case is a deterministic `on_tick` raise: 7s cadence × 6.5h ≈ 3,400 log lines. `dedup_key` collapses digits, so the key is identical every time → **one push per hour, ~6 per session.** Verbose log, quiet phone — the existing pattern, consistent with the 08-01 evidence (42 lines → 9 pushes).

### 5g. ⟳ Deploy dry run — the deploy set is self-sufficient

The USB deploy set (`back up N.2`) was copied to a scratch directory, given a **fresh venv**, `pip install -e .`, and run. Result: **115 / 47 / 23 green with no laptop state, no inherited `.venv`, no cached universe JSON** — the box's exact situation.

Content-verified in the deploy copy, not just by timestamp: `notifier.py` carries both `arm blocked` and `" error:"`; `pipeline.py` carries the read guard, both `ARM BLOCKED` alerts and the freshness gate; `force_stop.py` carries `systemctl` and **no** `no-open-order-check`; `status.py` carries `wait >=65s`.

The dry run also produced the finding in §6 below, which is exactly what it existed to find.

### 5h. ⟳ Full screener verification under the venv — 2026-08-03

Both screeners were run from the repo venv at real threshold 80, session-date 2026-08-03, market closed. **This is the first time the data stack has ever run under the venv rather than system Python.**

- `sp500_v21.py` — 120s warm-cache, 19 names through the VCP engine, `FINAL MATCHES: none reached VCP >= 80`. Highest was NTAP 73.5, the familiar near-miss. Emit reported `14 stale row(s) dropped` — the emit-side purge (Part I §5a) exercised on real data for the first time.
- `us_small_v21.py` — failed on missing `lxml`, was fixed, then ran the full pipeline: 1003 tickers scanned, 182 passed Stage 1, top 30 to Stage 2, Gemini scored them in 3 batch calls, 15 cleared the catalyst gate, VCP engine ran on all 15. Highest BRKR 71.5 (`Tradable` but below 80). `FINAL MATCHES: none`.

Verified working under the venv: numpy, pandas, yfinance, google-genai (live Gemini calls), lxml, and Finnhub over raw `requests` (all 30 fundamentals resolved `src=finnhub`, no yfinance fallback needed this run).

**Zero candidates at threshold 80 is the expected result** in this correction — consistent with the four prior nights. `candidates.csv` is header-only, 174 bytes. This is a plumbing verification; it is not strategy evidence.

⚠ **One data-quality signal worth carrying to the box.** Even on the warm laptop from a residential IP, the smallcap scan reported `Data fetch failed (network/rate-limit) 1` and `RS population coverage: 997/1003 (99%)`. The box's first run is cold-cache, ~1,000 tickers, from an **Oracle datacenter IP** — which Yahoo rate-limits more aggressively than residential addresses. Expect the cold run to be slower and the failure count higher. Run it supervised (bring-up step 9) and read the coverage line; a large drop there means the screen ran on a partial universe, which is degraded input, not a crash.

## 6. ⟳ Open defects and decisions

⚠ **`pyproject.toml` DECLARES ONLY `requests>=2.31`.** Found by the 2026-08-03 dry run. `pip install -e .` on a clean venv pulled `requests` and its four transitive deps and nothing else. **The suite passes anyway**, because the tests do not import the data stack; the screeners and providers do.

Consequence on the box: `pip install -e .` succeeds, `kistrader.cli test` passes 115/47/23, and then the cold screener run at bring-up step 9 fails on `ModuleNotFoundError`. A green suite is NOT evidence that the data path will run.

⟳ **RESOLVED — the exact list is known.** Determined by scanning every import in the shipping set, then confirmed against the versions the screeners have actually been running under:

```
numpy==2.4.6   pandas==3.0.3   yfinance==1.4.1   google-genai==2.8.0   lxml==6.1.1
```

⟳ **`lxml` is NOT importable from any source file** — `pandas.read_html` loads it as a parser backend at call time. An import scan structurally cannot find it. It was missed by the scan and found only by running `us_small_v21.py`, which fetches the S&P 400/600 constituent lists from Wikipedia via `read_html`. **Do not prune it as unused.**

`google-genai` (the newer SDK, `from google import genai`), **not** `google-generativeai` — installing the wrong one produces an ImportError that reads like a typo. Finnhub needs no SDK; that path is raw `requests`. `pytest` is NOT needed on the box: the dry-run venv had only `requests` + `kistrader` and still ran 115/47/23, so `kistrader.cli test` does not go through pytest.

**Versions are pinned deliberately.** `pandas 3.0.3` is a major release with real behavioural changes from 2.x (copy-on-write default, string dtype). A different resolution on the box could change screener output with no error — silently, in the geometry that feeds every pivot.

Post-soak, the honest fix is to declare these in `pyproject.toml` so `pip install -e .` is self-sufficient.

⟳ **The laptop runs TWO interpreters, and the box will run one.** The repo venv contains only `requests`, `pytest`, and editable `kistrader` — no numpy, pandas, yfinance or google-genai. Those live in system Python 3.14. **The screeners have therefore never run from the repo venv.** Venv-everywhere on the box (Part III §2) is consequently a *change from the proven laptop configuration*, not a replication of it. It is still the right call — Ubuntu 24.04 is PEP 668-managed, and a two-interpreter box is exactly the ambiguity class this project keeps getting bitten by — but bring-up step 9 is therefore a **required verification of a new configuration**, not merely an aarch64 stress test.

Note the one place this could bite: `screeners/candidate_emit.py:48` is a **top-level** `kistrader` import. If the package is not importable, the screener dies at import time with a bare `ModuleNotFoundError: No module named 'kistrader'`, before reaching the friendly diagnostic the screeners carry at `sp500_v21.py:2564` / `us_small_v21.py:2521`.

**`supervisor.py` handles SIGINT but not SIGTERM.** `systemctl stop` sends SIGTERM. Mitigated by systemd's default `KillMode=control-group`, which signals the child too — nothing is orphaned. The loop dies abruptly rather than through supervisor's graceful `terminate()`, which its SQLite-committed recovery design survives by construction. Post-soak tidiness item, not a blocker.

**Orphan-holding exposure gap** (Part I §3). Percent-deployed understated by an orphan's size. Live-cutover blocker.

**`HOLIDAYS_2026` covers 2026 only.** `run_loop.py` hardcodes the NYSE holiday set for one year. An always-on box crossing into 2027 will treat 2027-01-01 as a trading day. Also, **half-days are not modeled** — 2026-11-27 closes at 13:00 ET and the loop will believe OPEN until 16:00. Neither affects a five-day soak in August. Both must be closed before the box runs unattended into the next year.

**`notifier.py` and `status.py` have real character corruption.** In `notifier.py`, six literal `??` sequences where em-dashes belong, on lines 1, 9, 18, 118, 148, 152; line 9 also lost a newline. `status.py` carries the same damage (e.g. `"DB snapshots only ??free"`, `"broker returned UNKNOWN (None) ??holdings unreadable"`). This is genuine on-disk damage, not a console artifact — `notifier.py` contains zero non-ASCII bytes, while `pipeline.py` came through the same path with 25 em-dashes intact. Almost certainly `Set-Content -Encoding UTF8`. **All of it is in docstrings and log strings; none touch `classify`, `CRITICAL_SUBSTRINGS`, or `INFO_SUBSTRINGS`.** Cosmetic, optional to repair — but it is proof the known PowerShell corruption has already landed on two shipping files.

**Zombie `F:2026-07-22`.** Not held at the broker. Whether the local record was ever buried is unconfirmed. Since the box starts with an empty DB, this dissolves — but verify it isn't rehydrated if the DB is ever reused. *(A shadow-state-tree hypothesis was tested 2026-08-02 and rejected: the parent directory `C:\Users\user\PyCharmMiscProject\` contained only a stray `heartbeat.txt` dated 2026-07-22, no state DB, no log, no candidates. Stray deleted. The F record's history remains unexplained.)*

**STATE DB MIGRATION — RESOLVED.** Flatten CASY, JBHT and FCUV at Monday's open and start the box with an empty DB. The soak at threshold 55/45 will produce its own fills, so keeping the positions buys little, while migrating would carry the F zombie, stale watch threads and every historical event. Archive stays on the laptop as Step 3's audit trail.

## 7. Backtest-only questions — NEVER decide these in a code session

1. `VCP_SCORE_THRESHOLD` — 80 stands. `--emit-threshold` is for supervised technical tests only.
2. ATR-floor band recalibration for contraction-scale depths (lerp pins at `atr_mult_min` 1.3; the 0.08–0.25 band was calibrated for whole-base depths).
3. `n_max=8` and the 100% exposure ceiling at ~82% deployment.
4. `max_stop_pct` (10% = Minervini doctrinal ceiling).
5. Entry style: breakout vs volume-confirmed vs pullback. (Trigger mechanism is code; which style is data.)

## 8. ⟳ Hard-won lessons

- **"Confirm, never infer; fail closed, never silent."** The governing principle.
- **TWO CLOCKS.** SQLite `ts` is UTC; `kistrader_alerts.log` is local (KST on the laptop). A 58s exit once looked like a missing exit across the 9h offset. On the box both are UTC and finally agree.
- **KIS TOKEN LIMIT.** One access-token issuance per minute per app key (EGW00133); token lasts ~23h; `_ensure_token()` RAISES on denial. Supervisor backoff ≥65s. Never run two kistrader tools within a minute. Note `universe.ensure()` also makes a KIS call — **so on a fresh box the FIRST token issuance happens at the cold screener run, not at `kistrader verify`.**
- ⟳ **EVERY DEFAULT PATH IS RELATIVE.** `heartbeat.txt`, `candidates.csv`, `kis_engine_state.db`, `kistrader_alerts.log`, `supervisor.stop`, `.deadman_state.json` are all relative to the current working directory. Running a tool from the wrong cwd does not create one stray file — it creates a **complete shadow state tree, including a shadow state DB**, and a shadow DB is a shadow set of stops. Demonstrated on the laptop: a `heartbeat.txt` sat in the repo's parent directory for eleven days because the shell was one level up. `WorkingDirectory=` covers the systemd service and `run_screeners.sh` has an explicit `cd`; **neither covers you over SSH.** Rule for the box: `cd ~/kis-trader` before any manual command, every time.
- ⟳ **SEVERITY IS INFERRED FROM MESSAGE TEXT.** `notifier.classify` matches substrings against the lowercased message. The word "CRITICAL" in a message means nothing. To escalate a new alert, add its token to `CRITICAL_SUBSTRINGS` **and verify with `classify()` directly** — a new alert that should buzz and doesn't is invisible by construction.
- ⟳ **THE LAPTOP RAN TWO INTERPRETERS AND NOBODY KNEW.** The repo venv holds only `requests`, `pytest` and editable `kistrader`; the screeners' data stack lives in system Python 3.14. This was invisible for the whole project because both interpreters were on PATH and each worked for what it was asked to do. Before replicating any environment, list what is actually installed in it — do not reason from what the code imports.
- ⟳ **IMPORT SCANNING FINDS DIRECT DEPENDENCIES, NOT RUNTIME BACKENDS.** `lxml` appears in no `import` statement anywhere in the repo; `pandas.read_html` loads it by name at call time. The scan that produced the dependency list could not have found it, and did not. The general class is any library that resolves a parser, driver or engine dynamically. **Only running the code finds these.**
- ⟳ **A GREEN SUITE IS NOT EVIDENCE THE DATA PATH RUNS.** The tests import no third-party package beyond `requests`; the screeners and providers do. A clean-venv install passed 115/47/23 while pandas, numpy and yfinance were absent from the environment entirely. Suite coverage and runtime dependency coverage are separate questions, and only the dry run distinguishes them.
- ⟳ **VERIFY A BACKUP BY CONTENT, NOT BY TIMESTAMP OR SCREENSHOT.** Copies preserve source mtimes, so a file's date says when it was edited, not whether the edit is the right one. Explorer sorts folders before files, so a missing directory is easy to overlook in a screenshot. `Get-ChildItem -Recurse -File` plus targeted `Select-String` on the copy is the check that actually holds — it caught three missing files and a duplicated `tests\tests\` tree on 2026-08-03.
- ⟳ **`py_compile` CANNOT SEE AN INDENTATION-LEVEL LOGIC ERROR.** A patch pasted one level too deep put the entire freshness gate inside `for why in bad_rows:`. It compiled clean, and on any normal day (`bad_rows` empty) the gate would have been **dead code** — stale rows sailing through to `arm_batch`. Multi-line paste into an editor is where these come from. After any block paste: verify nesting, not just compilation. `ast.parse` and listing a function's top-level statements is the cheap check.
- **EXCHANGE CODES ARE SILENT KILLERS.** F is NYSE; seeded as NAS, `get_quote` returned 0 and the position was skipped with no error. Guard is correct on both paths; it was silent until the 08-01 patch.
- **MOCK FILLS ARE OPTIMISTIC.** Mock filled JBHT's below-market resting limit at the limit price; a live market fills that only on a pullback.
- **KIS mock `inquire-ccnl` permanently returns empty** — the fills-based close path is structurally unreachable on mock; flat confirmation uses the `flat_since` sentinel + `EXIT_FLAT_CONFIRM_SECS`.
- **`ft_ccld_unpr3`** (not `ft_ccld_unpr`) is the correct execution-price field.
- **Laptop unsuitability is structural**, not a fixable bug — sleep/lid/Wi-Fi/shared use, and now a hardware fault. Distinct from the code's own failures.
- **FINNHUB falls back to yfinance for many large-caps.** That is a data-coverage pattern, not a bug; the catalyst math floor is fed either way.
- **`us_small_v21.py` APPENDS to the same `candidates.csv`** — confirmed 2026-07-31 (ENVA appeared and is not in the S&P 500). Both screeners must run, sequentially.
- **PowerShell `Set-Content -Encoding UTF8` corrupts non-ASCII and prepends a BOM.** Safe alternative: `[System.IO.File]::WriteAllText((Resolve-Path $f), $c, (New-Object System.Text.UTF8Encoding($false)))`. ⟳ This has already landed on `notifier.py` (Part I §6).
- **PROCESS DISCIPLINE:** one BARE command per PowerShell box, NO placeholders, absolute paths when cwd is ambiguous. Most snags have been command-format errors, not code.
- ◆ **TWO SHELLS, AND THE PROMPT IS THE ONLY GUARD.** Bring-up runs a PowerShell window (laptop) and an SSH window (box) side by side. Wrong-machine command entry happened **four times** in one session — PowerShell commands into bash and vice versa. Same failure class as EVERY DEFAULT PATH IS RELATIVE: right command, wrong context. Keep the windows side by side, not tabbed, so the prompt is always visible. Every instruction in a session log should be explicitly labelled → BOX or → LAPTOP. Identify an unlabelled window with `hostname` (box) or `$PSVersionTable` (laptop).
- ◆ **PowerShell 5.1 DOES NOT SUPPORT `&&`.** Box command chains pasted into the laptop window fail with a parser error, which reads like a broken command rather than a wrong window.
- ◆ **A QUIET PHONE IS AMBIGUOUS.** During bring-up the dead-man was silently restart-looping and had never run — and the symptom was *no alerts*, which is indistinguishable from everything being fine. Any watchdog must be tested by causing the condition it watches for, not by observing that it is `active`.

## 9. ◆ Bring-up findings, 2026-08-04 → 2026-08-05

### 9a. MOCK `inquire-nccs` IS BLIND — item (a) is not closable on mock

Established empirically, in this order:

1. `kistrader verify` FAILed `get_order_status == RESTING` (got GONE) and `list_open_order_tickers` (got `{}`) seconds after successfully placing order `0000046117`. Raw dump: `rt_cd: 0`, `모의투자 조회할 내역(자료)이 없습니다`, no rows.
2. The KIS mock app was checked by hand and **showed the order resting**. Ground truth and API disagreed.
3. A read-only probe with a hand-placed resting AAPL order confirmed it: `VTTS3018R / NASD / DS` → `rt_cd=0`, **0 rows**, with the order visibly in 미체결.
4. The live TR id was tested against the mock server: `TTTS3018R` → `rt_cd=1`, **`모의투자 TR 이 아닙니다`**. So the gateway *does* discriminate TR ids, and `VTTS3018R` is a genuine, supported mock TR that simply returns nothing.

**Consequence.** `get_order_status` computes `_failed(res)` → false (rt_cd 0), finds no matching row, and returns **GONE for an order that is RESTING**. It cannot fail closed, because the server hands it a clean successful empty. This is the same structural blindness already known for `inquire-ccnl`, and the same *shape* as the exchange-code and falsy-quote bugs: a valid-looking response standing in for missing information.

⚠ **This makes Bug B (orphan adoption) more load-bearing than the runbook credits.** The I2 path — GONE + settle window + no fill evidence → CANCELLED — is correct behaviour on wrong input for the whole soak.

**A note against over-reading the official examples.** KIS's own `open-trading-api` repo (`examples_llm/overseas_stock/`) branches real/demo TR ids for `inquire_balance`, `inquire_ccnl`, `inquire_psamount`, `order_rvsecncl` and `inquire_present_balance` — but `inquire_nccs` accepts an `env_dv` argument and then hardcodes `TTTS3018R` with no demo branch. That was initially read as evidence `VTTS3018R` does not exist. **The empirical test disproved that reading**: the gap is in KIS's sample code, not in the API. Corroborating but not decisive: an R wrapper's README notes its `get_orders` appears unsupported in paper trading.

**RETRACTION.** The hardcoded `"OVRS_EXCG_CD": "NASD"` in `get_order_status` was flagged mid-session as a latent NYSE bug. **It is correct.** The official docstring states NASD queries *all* US exchanges; only the other venue codes are exchange-specific, and a blank code is documented as breaking pagination.

### 9b. Live-cutover blockers — three items, all from step 12

`kistrader verify` scored 6/9 on the box. Two FAILs are mock blindness, one was a rate-limit artifact since disproven. Honest state: **7 of 9 provable on mock, all 7 passing; 3 items deferred to live.**

1. `get_order_status == RESTING` — mock `inquire-nccs` blind (§9a)
2. `list_open_order_tickers` / the §3.9.1 gate PASS — same root cause
3. **`ft_ccld_unpr3` — the execution-price field, still never read from a real response.** Needs `--allow-fill`, and `inquire-ccnl` is blind on mock too. **This is the one to worry about**: it sets the entry price, which freezes risk per share, which determines stop distance, size and every R multiple downstream.

`inquire-psamount` IS now settled from a live response: keys `ord_psbl_frcr_amt` / `ovrs_ord_psbl_amt`, USD, value 97855.17, and `make_kis_buying_power_provider` read it correctly. One of the three `# VERIFY` fields is closed.

### 9c. `verify` fires its own calls too fast for mock

`cancel_order` FAILed inside `verify` with `초당 거래건수를 초과하였습니다` — the **per-second** transaction limit, which is a different limit from the token-per-minute ceiling and which `kisgate.sh` cannot help with. KIS's own repo notes mock accounts have lower REST limits than live.

**The cancel path itself is fine.** Proven twice on 2026-08-05 with 10s spacing: order placed, `cancel ok=True`, and the order **visually confirmed appearing and disappearing in the KIS app**. `verify` needs internal spacing between its calls — a post-soak fix, and one that must land **before** live cutover, since `verify` is the cutover tool.

⚠ Every `verify` run places a resting order and, on mock, fails to cancel it. Three runs during diagnosis left orders in the account; all were cancelled by hand. **Do not re-run `verify` casually.**

### 9d. Dependency pins — the aarch64 verification is now genuinely closed

A first install on the box used wrong versions (pandas 2.2.3, numpy 2.1.3, yfinance 0.2.51, plus an unnecessary `finnhub-python`, and no `google-genai` at all). Corrected to the §6 list and rebuilt in a parallel `.venv2`, then swapped in. Everything below was verified on the box:

- **All five pins install as aarch64 wheels on Python 3.12. No source builds.** The three named compile risks all arrived as wheels: `curl_cffi 0.16.0` (cp310-abi3), `pydantic-core 2.46.4` (cp312), `cryptography 50.0.0` (cp311-abi3). Two drifted from the versions this runbook predicted — they are unpinned transitives and are expected to float.
- **`finnhub-python` is NOT needed** — no `import finnhub` anywhere. Finnhub is raw `requests`, as §6 states. It was installed in error and removed.
- **`python-dotenv` is NOT needed** — `kistrader/config.py` carries its own loader (*"Minimal .env loader (no dependency)"*).
- **`pytest` is NOT needed**, confirmed again: `kistrader.cli test` runs the four suites directly.
- ⚠ **Renaming a venv breaks its console scripts.** `mv .venv2 .venv` left `.venv/bin/kistrader` with a shebang pointing at the old path (`cannot execute: required file not found`). `python` itself is a real binary and survives. Fix: `pip install -e . --force-reinstall --no-deps`. Every load-bearing path uses `.venv/bin/python <script>`, so nothing critical depended on the wrapper.

### 9e. `Notifier` fails silently outside the pipeline — TWO independent defects

Found because `run_screeners.sh`'s failure alert did nothing. Both are fixed in the script and both matter for any future standalone alerting:

1. **`Notifier.from_env()` reads `os.environ` and does not load `.env`.** With no credentials it returns a working object that logs locally and **never pushes**, warning once into the log. A standalone caller must call `kistrader.config.load_dotenv()` first.
2. **`emit()` queues to a daemon thread.** `_drain` runs as `daemon=True`, so a short-lived `python -c` process queues the message and exits before it is sent. `deadman.py --test` works only because `Notifier.test()` calls `self._sender(...)` synchronously.

Current workaround in `run_screeners.sh`: `n = Notifier.from_env(); n.emit(...)` then **`n._q.join()`**. That couples the script to a private attribute — if the queue implementation changes it breaks, and it breaks *silently*, back to logging-without-pushing. **Post-soak: add a public `Notifier.flush(timeout)` and switch the script to it.**

`_telegram_send` is bounded — `timeout=10`, 3 attempts, backoff 2/4/6s, worst case ~42s — so joining the queue cannot hang the caller. `_last_push` is an in-memory dict on `time.monotonic()`, so **dedup does not persist across processes**.

### 9f. Deviations from Part III §3's systemd units — both tested, both required

1. **`ProtectHome=true` is incompatible with a repo under `/home` on Ubuntu 24.04 / systemd 255.** The §3 probe was run and failed with `status=200/CHDIR` — the service could not even change into its working directory. The documented fallback (`ProtectSystem=strict` + `ReadWritePaths` + `NoNewPrivileges` + `PrivateTmp`) was probed and returned `RW-OK` with `probe.tmp` on disk owned by `ubuntu`. **The unit ships without `ProtectHome`.**
2. **The dead-man needs `ExecStartPre=/bin/sleep 120` AND `TimeoutStartSec=180`.** Without the sleep, systemd starts the dead-man alongside the loop on every boot, the dead-man checks immediately, `heartbeat.txt` does not exist yet, and it pushes a **false CRITICAL "DOWN?" on every reboot** — observed live at 03:11:19, five seconds before the loop was started. Alert fatigue on the exact alert that matters most.
   ⚠ **The sleep alone is a trap.** systemd's default `TimeoutStartSec` is **90s**, so a 120s `ExecStartPre` is killed with SIGTERM, `Restart=always` restarts it, and the unit restart-loops forever without ever reaching `ExecStart`. Observed: `Active: activating (auto-restart) (Result: timeout)`. **The dead-man was silently dead, and the symptom was a quiet phone.** `TimeoutStartSec=180` fixes it.

### 9g. `run_screeners.sh` — smallcap log prefix

The smallcap screener writes `runs/smallcap_<timestamp>.log`, **not** `runs/us_small_*`. A `check_log "us_small"` found nothing and fired a false CRITICAL. Corrected to `check_log "smallcap"`. Note the failure was in the safe direction — false alarm, not false all-clear — but `check_log`'s failure branch has still only ever been exercised by this bug, never by a genuinely failed screener.

### 9h. Only ONE screener issues a KIS token on a cold day

Settled at bring-up step 9, which the 2026-08-03 laptop verification could not settle. On the cold run, **sp500 issued the token** (`NAS: 5212 / NYS: 2854 / AMS: 4578` written to `kis_tradable_universe.json`); us_small reused the now-warm cache and issued none. With a warm cache, possibly zero issuances. **The `sleep 70` stays** — it costs nothing and removes the failure class.

### 9i. Slot exhaustion — worse than the estimate

The cold run at threshold 55 emitted **12 candidates** (6 sp500 + 6 us_small), against §8's estimate of ~10. With `n_max=8`, **day one fills every slot from a single session**. Record it as a finding, not as the system working.

### 9j. Memory is a non-issue on A1

Measured after the full cold dual-screener run: **514 MiB resident, swap 0 B used**, on 11 GiB. The 8 GB swap is insurance that was not needed. The aarch64 memory question is now measured rather than inferred.

### 9k. Box is now source of truth for four artifacts

`kisgate.sh`, `run_screeners.sh`, the four systemd unit files, and the two diagnostic probes (`nccs_probe.py`, `cancel_probe.py`) were **authored on the box** and exist nowhere else. The laptop/USB/box model is inverted for these. A reverse sync to the laptop repo (under something like `deploy/box/`) is outstanding. Note they hardcode `/home/ubuntu/...` — they are box-specific artifacts, not portable repo code, and should be labelled as such.

---

# PART II — REPO, ENVIRONMENT, BACKUPS

## 1. Package layout

```
kis-trader/
  kistrader/
    __init__.py  cli.py  config.py  notifier.py
    core/    engine_v2.py  kis_tradable_universe.py  run_loop.py
    entry/   decision_engine.py  entry_manager.py  pipeline.py
             providers.py  screen_contract.py
    tools/   close_position.py  contract_verify.py  seed_position.py
  tests/     test_candidate_emit.py  test_entry_half.py
             test_pipeline_e2e.py  test_seed_position.py
  screeners/ sp500_v21.py  us_small_v21.py  candidate_emit.py  emit_probe.py
  docs/      DEVELOPMENT_CHECKLIST.md  KIS_mock_trading_guide_ko.md
             screener_patch_1_6.md
  supervisor.py  clock_check.py  holdings_probe.py  deadman.py
  force_stop.py  check_size.py  make_csv.py  make_plumbing_csv.py
  status.py  conftest.py  pyproject.toml  .env  .gitignore
```

`seed_position.py` and `close_position.py` live inside the package under `tools/`, so they ship automatically. The root-level scripts do not.

## 2. Environment

- Repo: `C:\Users\user\PyCharmMiscProject\kis-trader`
- Installable package `kistrader` (`pip install -e .`; CLI `python -m kistrader.cli test|verify|run|seed|close`)
- Windows, Python 3.14, PyCharm, PowerShell → Oracle Ubuntu 24.04 / Python 3.12
- Broker: KIS overseas REST API, mock account, `KIS_MOCK=1`
- Notifications: Telegram (CRITICAL push via background daemon thread; WARN/INFO to a local rotating log; 60-min dedup cooldown; 15-min heartbeat)
- Data: Finnhub (primary), yfinance (fallback), Gemini — keys via `.env`
- Key scripts: `supervisor.py`, `clock_check.py`, `holdings_probe.py`, `status.py`, `contract_verify.py`, `force_stop.py`, `deadman.py`

## 3. ⟳ Deploy method — EXPLICIT COPY, not git

**There is no git binary on the laptop.** `Get-Command git` returns nothing; `C:\Program Files\Git\cmd\git.exe` does not exist. The clone path does not exist, so the decision is forced — and it is the better one anyway: the manifest is the artifact that has been reasoned about, and copying what you listed is verifiable at the destination with one `ls -la`.

`.gitignore` was audited and **does not cover** `heartbeat.txt`, `.deadman_state.json`, `kistrader_alerts.log`, `kis_tradable_universe.json`, `price_cache/`, `fundamentals_cache/`, `runs/`, `plumbing_candidates.csv`, or `bugB_closed_2026-07-17.log`. It covers only `.env`, `*.db`, `candidates.csv`, and build/cache dirs. The prior claim that "most exclusions handle themselves" under a clone was **checked and is false**. Extending `.gitignore` is a nice-to-have, not a pre-box item, since it is inert without git.

**Verify at the destination after copying.** These must all be absent on the box: `heartbeat.txt`, `.deadman_state.json`, `kistrader_alerts.log`, `candidates.csv`, `kis_tradable_universe.json`, `kis_engine_state.db*`.

## 4. ⟳ Deploy manifest

**Copy to the box**

```
kistrader/            (whole package, minus __pycache__ — tools/ ships with it)
tests/
conftest.py
pyproject.toml
screeners/sp500_v21.py
screeners/us_small_v21.py
screeners/candidate_emit.py
supervisor.py
clock_check.py
holdings_probe.py
status.py
deadman.py
force_stop.py
README.md
docs/
```

⟳ **`status.py` resolved — SHIP IT.** Source-checked: places no orders, writes no state, never mutates the DB. Plain `python status.py` is DB-only — no token, no network. **`status.py --live` reads broker holdings and costs ONE token issuance**, so on the box it goes through `kisgate.sh` (Part III §2a) like every other KIS-touching command.

`.env` deployed separately — as its own deliberate step, never inside a bulk transfer. `chmod 600`. Verify with `ls -l` → `-rw-------`. Type it into an editor; never `echo >>` — shell history persists.

**Do NOT copy**

```
.venv/  .pytest_cache/  **/__pycache__/  kistrader.egg-info/
price_cache/  fundamentals_cache/  runs/
screeners/price_cache/  screeners/fundamentals_cache/  screeners/runs/
candidates.csv  kis_tradable_universe.json
kistrader_alerts.log  heartbeat.txt  .deadman_state.json
kis_engine_state.db{,-wal,-shm}
kis_engine_state_plumbing_20260717.db
plumbing_candidates.csv  bugB_closed_2026-07-17.log
check_size.py  make_csv.py  make_plumbing_csv.py  screeners/emit_probe.py
```

⟳ **Two names in this list were wrong and were corrected 2026-08-02** by auditing against disk: `heartbeat` → **`heartbeat.txt`**, `.deadman_state` → **`.deadman_state.json`**. A literal-match exclusion missed both. Consequences of shipping them: with mtime preserved, the deadman trips instantly on bring-up night and pushes a false CRITICAL before the loop has ever run; with mtime reset, it sits quiet for 180s on a heartbeat nobody is writing — a false all-clear during the exact minutes you are verifying the loop started. Neither kills a soak; both contaminate bring-up evidence, which is what Part III §7 step 14 exists to produce cleanly.

Everything else on the list matched disk exactly. The drift was confined to the two files the *program* writes rather than ones typed by hand — which is where to look first if this list is ever suspect again.

**Rationale for exclusions.** `__pycache__` is version/arch-tagged (cpython-314, Windows x86-64) and ignored by Python 3.12 on aarch64 — dead weight. A Windows `.venv` on ARM is dangerous if it half-works. Anything the program writes about itself stays behind — caches, state, logs, heartbeats; the box starts with no memory. `emit_probe.py` / `make_plumbing_csv.py` are candidate fabricators: excluding them makes plumbing contamination of strategy evidence impossible rather than merely unlikely.

## 5. Backups

**Backup #1 — everything.** The whole `kis-trader` tree, unfiltered. Use the `sqlite3.backup` copy of the state DB, or copy all three `kis_engine_state.db*` files together — WAL mode makes a lone `.db` copy potentially inconsistent.

**Backup #2 — clean rebuild set.** The deploy manifest above, plus the `keepwarm/` folder.

The gap to remember: backup #2 is code, not state. If the cloud dies mid-soak, restoring #2 gives a working box that knows nothing about positions it was holding. Closing that gap is the daily off-box DB backup (Part III §6). #2 + that daily snapshot = a real rebuild. #2 alone = a fresh start.

## 6. ⟳ The deploy set as built (USB `back up N.2`, 2026-08-03)

Layout on the stick: `keepwarm/` and `kis-trader/` as sibling directories, with `.env` alongside them — deliberately outside `kis-trader/`, preserving the separate-deliberate-step discipline. `keepwarm` is separate because it installs to `/opt/keepwarm/`, never into the repo.

Verified present by `Get-ChildItem -Recurse -File`: the full `kistrader/` package including `__init__.py` in `core/`, `entry/` and `tools/`; `tests/` (4 files); `conftest.py`; `pyproject.toml`; `screeners/` with exactly `sp500_v21.py`, `us_small_v21.py`, `candidate_emit.py`; the six root scripts (`supervisor`, `clock_check`, `holdings_probe`, `status`, `deadman`, `force_stop`); `README.md`; `docs/` (3 files); `.gitignore`.

Verified absent: `.venv`, `__pycache__`, `.pytest_cache`, egg-info, all caches, `kis_engine_state.db*`, `candidates.csv`, `heartbeat.txt`, `.deadman_state.json`, `kis_tradable_universe.json`, `kistrader_alerts.log`, and every fabricator (`emit_probe.py`, `make_plumbing_csv.py`, `make_csv.py`, `check_size.py`).

⟳ **A first pass of this backup was missing `pyproject.toml`, `tests/`, `conftest.py`, `README.md`, `docs/` and `.gitignore`** — the first three are deploy blockers (no `pyproject.toml` means no package, no CLI, nothing runs; no `tests/` means enabling the soak on unverified code). They were absent from a screenshot review because Explorer sorts folders before files and the gap is easy to miss. Always confirm with a recursive file listing.

⟳ **`Copy-Item -Recurse` produced a duplicated `tests\tests\` tree** — four test files copied twice, identical sizes. Cause not determined; the same command shape did *not* duplicate `docs/`. Harmless to `kistrader.cli test` (which invokes modules explicitly, not by pytest discovery) but it is dead weight and a drift hazard: editing `tests/x.py` on the box would leave `tests/tests/x.py` stale, and a bare `pytest` run would collect both. Remove it and re-verify.

**Dry-run verification procedure — run this before every deployment.** Deactivate any active venv first, copy the deploy set to a scratch directory, build a fresh venv, `pip install -e .`, run the suite, then content-check the changed files with `Select-String`. Delete the scratch directory afterwards — **it contains a copy of `.env`** — and `cd` out of it first, or the removal fails with "item is in use."

Read the `pip install` output, not just the suite result: it is the only place the dependency gap in Part I §6 is visible.

---

# PART III — ORACLE PROVISIONING

## 1. Instance

### ◆ AS BUILT (2026-08-03/04)

| item | value |
|---|---|
| Tenancy | `junhyeok0427`, root compartment, **Pay As You Go** |
| Region | US East (Ashburn) / `us-ashburn-1` / IAD |
| Instance | `instance-20260803-2253` *(not renamed to `kistrader-soak`; cosmetic, changeable via More actions → Edit)* |
| Shape | `VM.Standard.A1.Flex`, 2 OCPU / 12 GB, **Always Free-eligible** tag confirmed |
| Image | Canonical Ubuntu 24.04, build `2026.07.17-0`, aarch64 |
| Kernel | `6.17.0-1019-oracle` (after full `apt upgrade` + reboot) |
| Boot volume | 50 GB, VPU:10, Oracle-managed encryption |
| VCN | `kistrader-vcn` — built with **Networking → VCN Wizard → Create VCN with Internet Connectivity** |
| Private IP | `10.0.0.240` (`enp0s6`) |
| **Public IP** | **`132.145.144.7`** — *ephemeral*: survives reboot, **changes if the instance is ever stopped and started** |
| SSH user / key | `ubuntu` / `C:\Users\user\.ssh\oracle_kistrader` (RSA 4096) |

**Login — → LAPTOP**
```
ssh -i C:\Users\user\.ssh\oracle_kistrader ubuntu@132.145.144.7
```

**Serial console break-glass — created and TESTED 2026-08-03. → LAPTOP**
```
ssh -i C:\Users\user\.ssh\oracle_kistrader -o HostKeyAlgorithms=+ssh-rsa -o PubkeyAcceptedAlgorithms=+ssh-rsa -o ProxyCommand="ssh -i C:\Users\user\.ssh\oracle_kistrader -W %h:%p -p 443 ocid1.instanceconsoleconnection.oc1.iad.anuwcljsjtqqtryckdbz2etmr6nzmp6tkr47c6qcnfsdouqvuhuruj4ytnla@instance-console.us-ashburn-1.oci.oraclecloud.com" ocid1.instance.oc1.iad.anuwcljsjtqqtrycvn5btxdd4g2kzjgwqvrq7faqafnh45h5vmiw7yzkmzka
```
Console connection lives on the instance page under the **OS Management** tab (this console build uses top tabs, not a left Resources panel) → *Console connection* → **Create local connection**. The menu item is **"Copy serial console connection for Linux/Mac"** — take the Linux/Mac variant even on Windows; the Windows one is PuTTY-formatted.

Four gotchas, all solved:
1. **`sudo passwd ubuntu` must be set first.** Cloud images disable password login, so the serial console otherwise gives a prompt you cannot pass. SSH stays key-only; this password works only over the serial port. (`passwd` echoes nothing while typing — normal, not a hang.)
2. **Accept the proxy host key in a standalone session first.** `ProxyCommand` has no TTY, so its yes/no prompt can never be answered → `Host key verification failed`. Run the bare proxy command once and answer `yes`; it connects, prints the banner, then closes with `unknown channel type: unsupported channel type: session` — **that is success.**
3. `no matching host key type found. Their offer: ssh-rsa` → add `-o HostKeyAlgorithms=+ssh-rsa -o PubkeyAcceptedAlgorithms=+ssh-rsa`. `+` appends; only the console path is loosened, port 22 stays strict.
4. Connects to a blank screen — **press Enter** for the login prompt. **Disconnect: Enter, then `~.`**

**Console security settings at creation — all defaults, deliberately.** *Shielded instance: OFF* (locks Secure Boot / Measured Boot / TPM permanently after launch; Secure Boot on ARM Ubuntu constrains kernel module loading and no runbook step accounts for it; boot-level malware is not the threat model here). *Confidential computing: unavailable* — AMD SEV hardware, Ampere cannot do it; the "BM Confidential computing" text in the image list is an image property, not a setting. *Security attributes (ZPR): none* — tagging with an attribute that has no matching policy is a way to lock yourself out. *Boot volume encryption: Oracle-managed.*

⚠ **PAYG safety requirement.** Keep a **$1 budget** under Billing & Cost Management → Budgets, scoped to the **root** compartment, with **two** alert rules: actual spend 50% and forecast spend 100%. Actual-only tells you after money moved; forecast warns before. Budgets evaluate every few hours. Only ever provision shapes/sizes carrying the *Always Free-eligible* tag. *(Deferred on 08-03 — Oracle needed time to verify the tenancy after the PAYG upgrade.)*

⚠ Many online sources still state the A1 allowance as 4 OCPU / 24 GB. Those predate the June 2026 change. **2 OCPU / 12 GB is correct**, and the *Always Free-eligible* tag on the shape selector is the only reliable confirmation.

- Oracle Always Free ARM (Ampere A1). Allowance halved 2026-06-15 to 2 OCPU / 12 GB (was 4/24). Ample — the screener is the memory peak, not the loop. 200 GB block storage, 10 TB/mo egress.
- **Home region** is chosen at signup and CANNOT be changed. It must support A1 — a hard gate. Home region is set to **Ashburn (us-east / IAD)**. Note this is a datacenter location only; it has **no effect on the instance clock**, which boots UTC and must stay UTC (Part I §8, TWO CLOCKS).
- Ubuntu 24.04, stock Python 3.12.
- ⚠ **IDLE RECLAMATION.** Oracle reclaims idle Always Free compute. The correct fix is converting the tenancy to Pay As You Go — it exempts the instance entirely and costs nothing inside the free allowance. `keepwarm` (Part IV) is the fallback if that is not done. Losing the box silently mid-soak is the worst environmental failure available. VERIFY current terms in the console — the June allowance change means the policy has been moving.

**Host prep, before anything else** — ◆ **ALL COMPLETE 2026-08-03/04.** As executed:

- Swap: **8 GB `/swapfile`**, prio -2, in `/etc/fstab`, `vm.swappiness=10` via `/etc/sysctl.d/99-swappiness.conf`. Survived reboot.
- Clock: `Etc/UTC`, NTP active, RTC not in local TZ — confirmed by `timedatectl`.
- `python3.12-venv` installed (Python 3.12.3).
- Serial console break-glass created **and logged into**.
- **Auto-reboot explicitly disabled.** Every `Automatic-Reboot` line in `50unattended-upgrades` was commented out, i.e. relying on a distro default. Made explicit in a numbered override that survives package upgrades — `/etc/apt/apt.conf.d/99-kistrader-no-reboot` with `Automatic-Reboot "false"` and `Automatic-Reboot-WithUsers "false"`. Verified with `apt-config dump`. Security patching continues; **you reboot deliberately, between soak days, when a kernel update lands.**
- 62 pending security updates applied plus a kernel upgrade, then rebooted with nothing deployed — cheapest possible time to exercise boot behaviour.
- **IP-binding: NOT bound**, or this box is already permitted. `holdings_probe.py` returned `OK` from a US datacenter IP with no auth error. Host prep item 7 is closed.

⚠ **Sequencing correction.** Item 6 below says to install the data deps "after the editable install", but the numbered bring-up puts host prep at step 2 and the deploy at step 3 — the repo does not exist yet at step 2. **The dependency install belongs inside step 3.**

1. Add 4–8 GB swap. A1 ships without it; the screener is the memory peak and an OOM kill is a silent screener failure.
2. `timedatectl` → confirm UTC, chrony running.
3. `apt install python3.12-venv` — **not in the base image**, and the venv is mandatory (§2 below).
4. Enable the serial console / Cloud Shell break-glass path BEFORE you need it. SSH is IP-restricted; Korean residential IPs rotate, and a rotation mid-soak locks you out.
5. `unattended-upgrades` — keep security patching, disable automatic reboot for the soak window.
6. ⚠ **INSTALL the data dependencies explicitly — `pip install -e .` will NOT pull them.** `pyproject.toml` declares only `requests>=2.31` (Part I §6). Into the venv, after the editable install:
   ```
   pip install numpy==2.4.6 pandas==3.0.3 yfinance==1.4.1 google-genai==2.8.0 lxml==6.1.1
   ```
   Pinned on purpose — a different pandas major would change screener output silently. No `pytest`; it is not needed.
   **Watch the install output for source builds.** Three transitive deps are compiled and are where an aarch64 wheel gap would appear: `curl_cffi 0.15.0` (via yfinance; bundles a patched libcurl — the least certain of the set), `pydantic-core 2.46.4` (via google-genai; Rust), `cryptography 49.0.0` (via google-auth; Rust). If pip starts compiling any of them, stop and reassess rather than waiting it out on 2 OCPU.
7. VERIFY whether the KIS app key is IP-bound. If so, register the box IP or `kistrader verify` fails.
8. Host firewall. Oracle's Ubuntu images ship restrictive local iptables in addition to the cloud security list. Nothing inbound is needed but SSH.

## 2. ⟳ Interpreter — venv everywhere, no exceptions

The proven laptop path is a **venv with the package installed editable** (`pip install -e .`), invoked as `python -m kistrader.cli …`. That is why `.venv/` is on the do-not-copy list and why bring-up says *rebuild* the venv.

Earlier drafts of this runbook used `/usr/bin/python3` in the systemd units and in `run_screeners.sh`. **That is wrong twice**: it is a different interpreter from the one the package is installed into, and Ubuntu 24.04 is PEP 668–managed, so `pip install -e .` against system python refuses outright without `--break-system-packages`.

**Every `ExecStart`, `run_screeners.sh`, and the backup one-liner point at `/home/YOURUSER/kis-trader/.venv/bin/python`.** The backup is stdlib-only and would work under system python; use the venv anyway so there is exactly one interpreter on the box.

⟳ **Be honest about what this is: a CHANGE, not a replication.** The laptop runs two interpreters — venv for the package/CLI/tests, system Python 3.14 for the screeners, which import numpy/pandas/yfinance/google-genai that the venv does not have (Part I §6). Venv-everywhere is the better design and PEP 668 makes the alternative awkward, but it has never been exercised. **Bring-up step 9 is therefore a required verification of a new configuration**, not merely an aarch64 stress test. Run it supervised, with the market closed, and read the output rather than assuming success.

## 2a. ⟳ `kisgate.sh` — structural token spacing

Bring-up runs several separate KIS-touching processes, and each is a separate token issuance under the one-per-minute ceiling. Manual `sleep 70` works but depends on never mis-sequencing at 22:30 KST. Put it in a wrapper instead — outside the package, at the repo root:

```bash
#!/usr/bin/env bash
STAMP="$HOME/.kis_last_token"
MIN=70
if [ -f "$STAMP" ]; then
  last=$(cat "$STAMP"); now=$(date +%s); wait=$(( MIN - (now - last) ))
  if [ "$wait" -gt 0 ]; then echo "kisgate: waiting ${wait}s" >&2; sleep "$wait"; fi
fi
date +%s > "$STAMP"
"$@"
rc=$?
date +%s > "$STAMP"
exit $rc
```

Stamps on both sides, so a long-running probe cannot let the next command fire early. Every KIS-touching command during bring-up goes through it:

```
cd ~/kis-trader && ./kisgate.sh .venv/bin/python holdings_probe.py -n 5 -i 10
```

Two limits: it cannot see the laptop, and it cannot see the loop once systemd owns it (`RestartSec=70` covers that side).

◆ **BUILT AND TESTED 2026-08-05**, verbatim as above, at `~/kis-trader/kisgate.sh`, `chmod +x`. Verified with a harmless command: first run fired immediately (no stamp file), second printed `kisgate: waiting 64s`, slept, then ran. Used for bring-up steps 9 and 11–13.

⚠ **It does not help with the per-second limit.** `초당 거래건수를 초과하였습니다` is a *different* ceiling from the one-token-per-minute rule, it fires *inside* a single process, and `kisgate.sh` spaces invocations only. See Part I §9c.

⚠ **`run_screeners.sh` keeps its internal `sleep 70` rather than wrapping each screener in the gate.** Deliberate, chosen for conservatism: `sleep` has no dependencies and cannot fail open, whereas `kisgate.sh` under systemd depends on `$HOME` resolving — and with `$HOME` empty the stamp write fails silently and the script **carries on ungated** (there is no `set -e`). A silent fail-open is the exact failure class this project exists to eliminate. `kisgate.sh` is for manual commands; `sleep 70` is for the unattended script.

## 3. systemd — the loop

Two layers: systemd for boot persistence, `supervisor.py` for backoff and the crash-storm guard.

`supervisor.py` exit codes (source-verified 2026-08-01):

| rc | cause | meaning |
|---|---|---|
| 0 | Ctrl+C, stop file, `--dry` | operator stop |
| 2 | `supervisor.stop` present at startup | operator intent |
| 3 | crash-storm guard tripped | deliberate give-up |

Supervisor only ever exits on conditions where restarting is wrong — it absorbs transient faults itself. So all three are `SuccessExitStatus`, and systemd restarts only if supervisor itself dies unexpectedly (rc 1).

**`/etc/systemd/system/kistrader.service`** — ◆ AS DEPLOYED (`ProtectHome` removed; see Part I §9f)

```ini
[Unit]
Description=kistrader loop (supervised)
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=ubuntu
WorkingDirectory=/home/ubuntu/kis-trader
ExecStart=/home/ubuntu/kis-trader/.venv/bin/python supervisor.py -- --auto-arm
Restart=on-failure
RestartSec=70
SuccessExitStatus=2 3
TimeoutStopSec=30
NoNewPrivileges=true
ProtectSystem=strict
PrivateTmp=true
ReadWritePaths=/home/ubuntu/kis-trader

[Install]
WantedBy=multi-user.target
```

◆ Verified at enable: supervisor and child both in the cgroup; policy line `backoff 65.0s..300.0s, healthy after 600.0s, storm guard 6 exits/1800.0s, stop file: supervisor.stop`.

⚠ `--no-open-order-check` is deliberately ABSENT. That flag is the reason §3.9.1 has never run in production. Shipping it would run the soak for five days and close only two of the three gated items.

⚠ `Restart=on-failure` / `RestartSec=70`, not `always` / `30`. 30s is below the 65s token floor (guaranteed EGW00133 storm), and `Restart=always` resurrects the supervisor after the crash-storm guard deliberately gave up.

⚠ `WorkingDirectory` is load-bearing — `STOP_FILE` is relative, and so is every other default path (Part I §8).

⚠ ⟳ **`ProtectHome=true` + `ReadWritePaths` under `/home` must be TESTED, not assumed.** `ProtectHome=true` masks `/home` with an empty tmpfs, and `ReadWritePaths` may not un-mask what `ProtectHome` has already hidden. Probe before enabling anything:

```
sudo systemd-run --uid=$USER --property=ProtectHome=true --property=ProtectSystem=strict \
  --property=ReadWritePaths=/home/$USER/kis-trader \
  --working-directory=/home/$USER/kis-trader \
  /bin/bash -c 'touch probe.tmp && echo RW-OK'
```

If it fails: drop `ProtectHome`, keep `ProtectSystem=strict` + `ReadWritePaths` + `NoNewPrivileges` + `PrivateTmp`. Do not relocate the repo mid-bring-up — it invalidates every path in this runbook.

Let Python read `.env`, not systemd's `EnvironmentFile=`. systemd's parser is not a shell; quoting and spaces behave differently, and a silently mis-parsed key is exactly the failure class this project exists to eliminate.

**`/etc/systemd/system/kistrader-deadman.service`** — ◆ AS DEPLOYED (`ExecStartPre` + `TimeoutStartSec` added; see Part I §9f)

```ini
[Unit]
Description=kistrader dead-man switch
After=network-online.target

[Service]
Type=simple
User=ubuntu
WorkingDirectory=/home/ubuntu/kis-trader
ExecStartPre=/bin/sleep 120
TimeoutStartSec=180
ExecStart=/home/ubuntu/kis-trader/.venv/bin/python deadman.py --file heartbeat.txt --stale-secs 180
Restart=always
RestartSec=60

[Install]
WantedBy=multi-user.target
```

⚠ **Both added lines are required and they are required together.** `ExecStartPre` alone exceeds systemd's default 90s `TimeoutStartSec` and produces a permanent restart loop that never reaches `ExecStart` — a dead dead-man whose only symptom is silence.

**`/etc/systemd/system/kistrader-screeners.service`** — ◆ NEW, was not in the runbook

```ini
[Unit]
Description=kistrader screeners (daily candidate emit)

[Service]
Type=oneshot
User=ubuntu
WorkingDirectory=/home/ubuntu/kis-trader
ExecStart=/home/ubuntu/kis-trader/run_screeners.sh
```

**`/etc/systemd/system/kistrader-screeners.timer`** — ◆ NEW

```ini
[Unit]
Description=Run kistrader screeners at 08:00 ET on weekdays

[Timer]
OnCalendar=Mon..Fri *-*-* 08:00:00 America/New_York

[Install]
WantedBy=timers.target
```

◆ **Enable order matters: dead-man and timer first, loop last** — and run `sudo systemd-analyze verify` on all three services before enabling anything. It catches typos the shell will not.

◆ **DEAD-MAN PROVEN END TO END, 2026-08-05.** Not merely `active` — the loop was deliberately stopped with the market closed and the dead-man walked `FRESH 7s → 67s → 127s → STALE (alerted) at 187s`, with `push ok` and a Telegram alert received, then recovered on restart. Threshold behaved exactly as specified (180s, no premature alert at 127s), and `ARMED file=heartbeat.txt` confirms it watches the right file.

⟳ **`--file heartbeat.txt` is load-bearing, not decorative.** `deadman.py`'s own default is the alerts log — its docstring still describes the dedicated heartbeat writer as future work, but that writer has landed (`pipeline.py` writes `heartbeat.txt` every cycle, any phase). Drop the flag and the deadman silently watches the wrong file.

180s, not 120s — heartbeat gaps to ~55s were observed under open-phase load. `Restart=always` is correct here: the dead-man has no storm guard to defeat.

**Test a real reboot** — `systemctl enable` plus an actual reboot — before the soak. Boot persistence that was never exercised is not boot persistence.

◆ **DONE 2026-08-05 03:20 UTC.** After reboot: `kistrader` active with both processes, heartbeat written 03:20:14 (seconds after the check), timer armed for Wed 12:00 UTC, same public IP, **and no false DOWN? push** — confirming the `ExecStartPre` fix. `kistrader-deadman` reads `activating` for its first 120s after any boot; that is correct, not a fault.

## 4. The loop's schedule

The supervisor is always-on, never scheduled. It must be running before 09:30 ET so the first OPEN cycle can auto-arm, and still running through 16:00 ET so `on_close` fires. 16:00 ET is 05:00 KST — killing the loop just before 05:00 is exactly why `on_close` is still unproven.

## 5. ⟳ Screeners

Both, sequentially. Sequential matters twice: the screener is the memory peak, and both append to the same `candidates.csv`.

**`/home/YOURUSER/kis-trader/run_screeners.sh`**

Requirements — do not simplify any of these away:

1. **Venv interpreter**, not `/usr/bin/python3`.
2. **Explicit `cd /home/YOURUSER/kis-trader`** — every default path is relative.3. **ET session date**: `D=$(TZ=America/New_York date +%F)`. This must match `USSessionClock.session_date()` exactly or the freshness gate rejects everything.
4. **`--emit-threshold` read from a single variable at the top**, so the day-3 55→45 change is one edit, not a script rewrite.
5. **Each screener runs and is alerted on INDEPENDENTLY.** Do not let `set -e` abort the script after sp500 fails — us_small must still run. An sp500 failure that suppresses us_small is a total blackout; on its own it is a smaller universe with correct geometry.
6. ⚠ **EXIT CODE IS NOT SUFFICIENT — check the run LOG.** Verified 2026-08-03: with `lxml` missing, `us_small_v21.py` printed `[-] Failed to load corporate datasets (both S&P 400 and S&P 600 fetches failed)` and **exited 0**. A screener that screened an empty universe reports success. Combined with the freshness gate's blind spot below, that failure would have been completely silent: sp500's fresh rows keep `n_stale` at zero, the gate stays quiet, exit codes are clean, and the soak runs on half the universe with no signal.
   The check must therefore be **both**: non-zero exit AND a scan of the run log under `runs/` for `Failed to load` / `[-]` markers, or a comparison of `candidates.csv` before and after. A successful smallcap log ends with `STAGE 1 COMPLETE: N stock(s) passed` and an `[emit]` line; a failed one is ~440 bytes and has neither.
7. **Do NOT delete or move `candidates.csv` before running.** An earlier draft proposed this; it is actively harmful. `candidate_emit` already purges stale rows on write, so a surviving file is self-correcting, while deleting it converts a partial failure into a total one.
8. Emit the ramp label into the log: `TECHNICAL (emit-threshold N) — plumbing evidence only`.

⟳ **No `PYTHONPATH` and no `cd screeners/` are needed** — source-verified 2026-08-03. Both screeners anchor the repo root on `__file__` (`sp500_v21.py:315`, `us_small_v21.py:262`, with the comment *"screeners/ lives one level under the repo root"*), so path resolution does not depend on cwd. Both import `candidate_emit` with a dual-path fallback (sibling first, then package-qualified at `sp500_v21.py:2554/2559` and `us_small_v21.py:2511/2516`), so either invocation location works, and both carry a named diagnostic if that fails. `kistrader` itself resolves because the venv has it installed editable. The `cd` in the script is still required — but for `candidates.csv` and the caches, not for imports.

Invocation shape:

```
cd /home/YOURUSER/kis-trader
.venv/bin/python screeners/sp500_v21.py --emit-candidates --session-date "$D" --emit-threshold "$T"
sleep 70
.venv/bin/python screeners/us_small_v21.py --emit-candidates --session-date "$D" --emit-threshold "$T"
```

⟳ **The `sleep 70` is deliberate and must not be removed.** Each screener is a separate process and therefore a separate KIS token issuance (via `universe.ensure()` inside `candidate_emit`), and the limit is one issuance per minute per app key. sp500 took **120s** with warm caches on the laptop — above the floor measured start-to-start, but that does not prove safety, because what matters is where in each run the token is issued, not the run's total length. The 2026-08-03 verification could not settle it: **both screeners emitted zero candidates, so the universe was never queried and no token was issued at all** (`kis_tradable_universe.json` was not rewritten). The sleep costs nothing — the timer fires 90 minutes before the open — and removes the failure class outright. Without it, a cold first day would likely pass and a warm second day would fail with EGW00133: a nasty intermittent.

⟳ **What the freshness gate does and does not cover.** If sp500 fails and us_small succeeds, us_small's emit purges yesterday's rows on write, so the file ends with fresh us_small rows and **zero stale rows**. `n_stale == 0` and the gate says nothing. **The gate only catches the both-screeners-failed case.** Single-screener failure is covered entirely by requirement 6.

Use a systemd timer with the timezone as a **suffix on the calendar expression** — there is no `Timezone=` directive:

```ini
OnCalendar=Mon..Fri *-*-* 08:00:00 America/New_York
```

Validate before trusting it:

```
systemd-analyze calendar 'Mon..Fri *-*-* 08:00:00 America/New_York' --iterations=5
```

That resolves to 12:00 UTC under EDT and 13:00 UTC under EST — matching the two times Part IV names, and clear of all four keepwarm windows. `Mon..Fri` is pinned so a weekend run cannot leave a file for the gate to reason about. No `Persistent=true` — a stale catch-up run at an odd hour is worse than a missed one.

◆ Validated 2026-08-05: `Wed 2026-08-05 12:00 UTC`, then Thu/Fri/Mon/Tue — weekdays only, EDT resolving to 12:00 UTC as predicted.

Run at 08:00 ET (21:00 KST — you are awake): prior bars settled for hours, 90-minute runway to the open.

**First run on the box is a cold cache** — ~1,000 tickers, no `.pkl` fallback. That is the aarch64 stress test. Do it supervised, watching `free -m`.

### ◆ `run_screeners.sh` as built (2026-08-05, on the box)

Structure actually deployed, meeting all eight requirements:

- `cd /home/ubuntu/kis-trader`, `PY=/home/ubuntu/kis-trader/.venv/bin/python`
- `T=55` at the top — **the one edit for the threshold ramp**
- `D=$(TZ=America/New_York date +%F)`
- No `set -e`; each screener runs and is judged independently
- `alert()` shells to Python with `load_dotenv()` + `n._q.join()` (Part I §9e)
- `check_log()` takes a log prefix and the rc; requires a log to exist, rc 0, **no** `Failed to load`, **and** the presence of `STAGE 1 COMPLETE`
- Prefixes are **`sp500`** and **`smallcap`** (Part I §9g)
- `sleep 70` between the two screeners

⚠ The alert message wording matters: it must contain **`error:`** (one of `CRITICAL_SUBSTRINGS`) or a screener failure will sit in the log and never reach the phone. `classify('screener error: …')` → CRITICAL, verified directly.

**Cold run result, 2026-08-05 03:37–03:43 UTC** (bring-up step 9, through `kisgate.sh`, threshold 55, session 2026-08-03): 5m47s total, both screeners full three-stage pipelines, zero errors. sp500 503 tickers → 91 Stage 1 → 30 Stage 2 → 19 Stage 3, none ≥ 80 (NTAP 73.55 top). us_small 1003 tickers → 180 Stage 1 → 30 → 21 Stage 3, none ≥ 80 (BRKR 72.0 top). 12 rows emitted at the degraded threshold. `Data fetch failed (network/rate-limit) 10` and 99% RS coverage on the smallcap leg — acceptable, worth watching. **This run proved, all at once: pandas 3.0.3 on the screener code, `lxml` (S&P 400/600 loaded), Gemini, Finnhub, yfinance, venv-everywhere, and the KIS token path.**

## 6. Backups on the box

Not `cp` — WAL mode.

```
/home/YOURUSER/kis-trader/.venv/bin/python -c "import sqlite3,datetime,pathlib; \
d=pathlib.Path.home()/'backups'; d.mkdir(exist_ok=True); \
s=sqlite3.connect('/home/YOURUSER/kis-trader/kis_engine_state.db'); \
t=sqlite3.connect(str(d/('state-'+datetime.date.today().isoformat()+'.db'))); \
s.backup(t); t.close(); s.close()"
```

Daily, keep 14 days, `Persistent=true` on this one (a missed backup should catch up). Push a copy off-box — OCI Object Storage has a free allowance. A backup that lives only on the instance does not survive losing the instance, and that DB is the memory of every stop.

## 7. ⟳ Monday bring-up — DO NOT REORDER

### ◆ STATUS: ALL FIFTEEN STEPS CLOSED (2026-08-03 → 2026-08-05)

| # | step | result |
|---|---|---|
| 1 | Laptop stopped & verified | ✅ no Python processes, no scheduled tasks |
| 2 | Provision + host prep | ✅ §1 above |
| 3 | Deploy + venv + `pip install -e .` | ✅ 38/38 files |
| 4 | Absence check | ✅ 6/6 absent — **empty state DB, no orphans, F zombie dissolved** |
| 5 | `kistrader test` | ✅ **115 / 47 / 23** (+15 emit) on aarch64, from the deploy copy, no `.env` present |
| 6 | `clock_check.py` | ✅ UTC→ET conversion correct, holidays loaded, phase matches NYSE |
| 7 | `deadman.py --test` | ✅ phone buzzed |
| 8 | `ProtectHome` probe | ⚠ **FAILED as documented** → fallback set probed and passed (Part I §9f) |
| 9 | Cold screener run | ✅ 5m47s, both screeners, first KIS token issuance (§5 above) |
| 10 | Flatten CASY/JBHT/FCUV | ✅ done early, by hand, 2026-08-03 |
| 11 | `holdings_probe -n 5` | ✅ 0 rows; **also proved the app key is not IP-bound** |
| 12 | `kistrader verify` | ⚠ **7/9 provable on mock, all 7 pass; 3 items → live cutover** (Part I §9b) |
| 13 | `holdings_probe` baseline | ✅ 3/3 zero rows, `ok=3/3`, no rate-limit or transport failures |
| 14 | Supervised night | ✅ folded into 08-04/05 — the box ran supervised through the whole bring-up |
| 15 | Enable units | ✅ enabled 03:11 UTC, reboot-verified 03:20, dead-man proven 03:39 |

⚠ **Step 1's note is WRONG and is corrected here.** It claims step 6 (`clock_check.py`) is the box's first KIS call. Source-checked on the box: `clock_check.py` imports only `datetime` and `USSessionClock`/`HOLIDAYS_2026`, and greps clean for `universe.ensure`, `token` and `requests.`. **Step 9 is the first KIS token issuance**, as originally written.

⚠ **Step 5's invocation matters.** The suite is invoked as `python -m kistrader.cli test` (or the four files directly). Running it under **`pytest` produces a misleading failure** — 36 collected, `fixture 'filled_pos' not found` — because `test_entry_half.py` chains tests by calling them directly (`filled_pos = test_happy_full_fill()` at line 879) and `conftest.py` is a 7-line path shim with **zero** `def`. Not a defect; wrong runner.

⚠ **Steps 11–13 all go through `kisgate.sh`.** Since §2a's wrapper now exists, run the cold screener (step 9) through it too.



**Daytime KST (market closed)**

1. **Laptop fully stopped and verified stopped, FIRST.** Two machines on one app key is the worst available failure, and step 6 below is the box's first KIS call — not step 9 as previously written, because `universe.ensure()` issues a token.
   ```
   Get-CimInstance Win32_Process -Filter "Name LIKE '%python%'" | Select-Object ProcessId,Name,CommandLine
   ```
   Empty output is the pass. Also confirm nothing will resurrect itself:
   ```
   Get-ScheduledTask | Where-Object { $_.Actions.Execute -like "*python*" }
   ```
   *(Both verified clean on 2026-08-02, but this is a per-day check — PyCharm holds interpreters and any activated shell spawns python. Re-run it Monday, and run nothing on the laptop afterward.)*
2. Provision the instance; host prep per §1 (including `python3.12-venv`).
3. Deploy per Part II §4 (explicit copy); rebuild the venv; `pip install -e .`
4. Verify the box has no inherited memory: `ls -la ~/kis-trader` — `heartbeat.txt`, `.deadman_state.json`, `kistrader_alerts.log`, `candidates.csv`, `kis_tradable_universe.json`, `kis_engine_state.db*` must all be ABSENT.
5. `cd ~/kis-trader && .venv/bin/python -m kistrader.cli test` → **115 / 47 / 23**
6. `.venv/bin/python clock_check.py` → ET matches a world clock. Genuinely different on the box: the laptop ran it with a KST-local clock (verified 08-01: UTC 00:09:52 → ET 20:09:52, UTC-4 EDT, phase CLOSED — all consistent). The box is UTC, so the conversion takes a different path.
7. `.venv/bin/python deadman.py --test` → phone buzzes.
8. `ProtectHome` probe (§3) before enabling any unit.
9. Cold screener run, supervised, watching `free -m`. **← first KIS token issuance on the box** (`universe.ensure()`).

**At the US open (22:30 KST)**

10. Flatten CASY, JBHT and FCUV. Simplest is by hand in the KIS mock app — no token contention, no script sequencing. If scripting, `force_stop.py` in ONE invocation for all three: the one-per-minute limit is on token *issuance*, not API calls, so multiple sells inside a single process are fine.
11. `./kisgate.sh .venv/bin/python holdings_probe.py -n 5 -i 10` → zero rows.
12. `./kisgate.sh .venv/bin/python -m kistrader.cli verify` → KIS write path works from this IP.
13. `./kisgate.sh .venv/bin/python holdings_probe.py -n 30 -i 10` → baseline the balance read.
14. One supervised cloud night, watched, before enabling any units.
15. Enable the systemd units → the soak.

Step 14 exists because a first night always finds something environmental.

## 8. Soak threshold ramp

Real 80 yields ~0 candidates in the current correction — four nights produced zero armable names (NTAP the recurring 72–74 near-miss). Degraded thresholds are allowed ON MOCK ONLY.

- Days 1–2: `--emit-threshold 55`
- Days 3–5: `--emit-threshold 45`

◆ **ACTUAL CALENDAR AS RUNNING.** Ramp shifted so the wider-candidate days fall after the weekend, in front of the operator, rather than on a Friday:

| ET session | day | threshold |
|---|---|---|
| Wed 2026-08-05 | 1 | 55 |
| Thu 2026-08-06 | 2 | 55 |
| Fri 2026-08-07 | 3 | 55 |
| Mon 2026-08-10 | 4 | **45** |
| Tue 2026-08-11 | 5 | 45 |
| Wed 2026-08-12 | 6 | 45 |

**The 45 edit happens Sunday KST**, before Monday's ET session. One line:
```
cd ~/kis-trader && sed -i 's/^T=55/T=45/' run_screeners.sh && grep -n "^T=" run_screeners.sh
```
⚠ Set a phone reminder. The timer is `Mon..Fri`, so an unmade edit means Monday silently runs at 55 — a missing ramp reads as a quiet week, not as an error.

**Daily check, ~5 minutes each evening (~22:00 KST):**
```
cd ~/kis-trader && systemctl is-active kistrader kistrader-deadman && tail -20 kistrader_alerts.log && cat heartbeat.txt && ls -t runs/*.log | head -2
```
Both `active`, heartbeat under 60s old, no unexplained CRITICAL, two fresh screener logs.

One trading week. Label each segment explicitly:

```
TECHNICAL (emit-threshold N) — plumbing evidence only
```

Change only the emit threshold. Do not also loosen `n_max`, the ATR band or `max_stop_pct` — multiple parked params moving at once makes the run uninterpretable.

**Reading the results:**

- Lowering helps the exit items (b) and (c) directly — an exit is an exit.
- It helps item (a) less, possibly against it: looser names have wider stops and draw more cap rejections. At threshold 60 the one emitting name, NTAP, was cap-rejected at 11.9% risk against the 10% ceiling. Treat every cap-rejection as a successful test of the cap.
- ⚠ **Slot exhaustion is a MEASURED risk, not a hypothesis.** A full dual-screener run on 2026-08-03 scored 34 names through the VCP engine (19 sp500 + 15 us_small). Counting them against the ramp thresholds:
  - **threshold 55 → ~10 emitting names** (NTAP 73.5, BRKR 71.5, PBF 60.9, PTGX 60.3, ENVA 59.5, NUE 58.8, OKTA 58.4, PANW 58.1, LFST 56.9, DDOG 55.1)
  - **threshold 45 → ~16 emitting names** (adds AMN 54.1, LQDA 52.6, FTNT 53.1, ROST 52.0, INSW 49.6, DELL 48.0)

  With `n_max=8`, **day one at threshold 55 would fill every slot from a single session's emit.** All eight filling early is a signal, not a success — and now we know it is the likely outcome rather than a tail risk. Watch for it explicitly on days 1–2 and record it as a finding rather than reading it as the system working.
- Thinner names → more odd listings and thin quotes → more zero quotes. The `QUOTE UNKNOWN x20` alert is what keeps a starved soak distinguishable from a broken one.
- ⟳ A day with **no arming at all** now has three distinguishable causes, all visible: `ARM BLOCKED … could not read` (no file), `ARM BLOCKED … entirely STALE` (screener didn't run), or a normal `arm_today: N candidates -> 0 planned` (real screen, nothing qualified). Only the third is strategy evidence.
- ⟳ **Exit alerts are WARN and will not buzz.** Confirm item (b) by reading `kistrader_alerts.log`.
- Mock fills are optimistic.

## 9. ⟳ After the soak

### ◆ PHASED ROADMAP (agreed 2026-08-05)

The ordering below resolves a circular dependency: *"solve all technical problems → then forward test → then real money"* cannot run in that order, because the last three technical problems (Part I §9b) **require a live account to close**. The resolution is separating two uses of the same money.

| phase | what | money |
|---|---|---|
| 1 | Soak — Aug 5–12 | mock |
| 1b | Backtest **harness build** in parallel (data, pinning to numpy 2.4.6 / pandas 3.0.3). **Not** the parameter decisions — those need soak evidence and are never made in a code session. | none |
| 2 | Post-soak code fixes — **Thu Aug 13** | none |
| 3 | Backtest parameter decisions (Part I §7), with a week of production evidence in hand | none |
| **4** | **Live cutover verify — 1 share, ~$300, held minutes.** An experiment with a fixed cost, not a trade. Closes the three §9b blockers. | **real, as an instrument** |
| 5 | Live forward test — small size, engine-managed | real, as capital |
| 6 | Scale | real |

Target close ~Aug 19. **There is no slack in that.** A soak finding on day 3, or a first live-cutover attempt that fails, moves it to ~Aug 21 — fine if expected rather than a surprise.

**Phase 2 execution order — stop the loop and snapshot first.** `systemctl stop kistrader`, back up the DB and `.venv`, confirm the account flat. Then cheapest-first, each leaving 200/200 green: (1) declare the deps in `pyproject.toml`, built and verified in a parallel `.venv2` before swapping; (2) public `Notifier.flush(timeout)` and switch `run_screeners.sh` off `_q.join()`; (3) **`verify` internal call spacing — must land before phase 4, since `verify` is the cutover tool**; (4) `??` mojibake repair; (5) SIGTERM handler.

⚠ **Phase 4 needs a checklist written while nothing is at stake.** Live uses **different app keys from mock** (README states this explicitly), so cutover is a full `.env` swap plus `KIS_MOCK=0` plus `--allow-live` — not a one-flag change. `KIS_MOCK` has been the single guard between paper and real for the entire project, which makes that swap the most dangerous config edit in the codebase. Also unexercised on mock: the real per-venue exchange codes on the *order* path, which is exactly where the F-as-NAS class of silent skip lives.

1. Close the three gated items; write them up. ◆ **Item (a) closes at phase 4, not here** (Part I §9a).
2. `supervisor.py` SIGTERM handler.
3. Orphan-holding exposure gap (Part I §3).
4. `HOLIDAYS_2026` → 2027 entries, and half-day modeling (Part I §6). **Hard requirement before the box runs unattended past 2026-11-27.**
5. `notifier.py` `??` repair (cosmetic).
6. JBHT 2026-08-01 survival confirmed against the actual intraday low.
7. Consider consolidating file sprawl with an agentic tool — refactor against BOTH the passing suite and multi-day production evidence, the strongest possible baseline.
8. Backtest-only parameter decisions (Part I §7).
9. Live-cutover work: TTTT1006U 1-share verify; separate key, OCI Vault, IP allowlist.
10. Korean pipeline (parallel work item, early stage): domestic KIS exchange code, KRW sizing, KRX session clock, domestic quote/fill broker path — four unknowns still open. Screener `msci_korea_v21.py` in progress.

---

# PART IV — keepwarm (Oracle idle ballast)

# ◆ NOT NEEDED — DO NOT INSTALL

**The tenancy was converted to Pay As You Go on 2026-08-03.** PAYG exempts the instance from idle reclamation entirely, so this whole part is dead weight. Do not install `keepwarm`, do not copy `keepwarm/` from the USB. This also removes the 22:00 UTC scheduling constraint the section imposes.

Retained below for reference only, in case the tenancy is ever reverted.

---

Only needed if the tenancy is NOT converted to Pay As You Go. PAYG removes the reclamation criterion entirely, for free. `keepwarm` games it instead.

Files: `keepwarm.py`, `keepwarm.service`, `keepwarm.timer`, `install.sh`, `README.md`. Install with `sudo bash install.sh` → `/opt/keepwarm/`.

**Isolation, on four axes:** filesystem (`/opt/keepwarm/`, never in the repo — cannot be swept into a deploy); process (own systemd unit → own cgroup → own row in `systemd-cgtop`); ownership (`keepwarm` system user, no login, no read access to `.env` or the state DB); and time — windows at 01/05/09/22 UTC only.

**Duty cycle.** The criterion is p95 < 20% over 7 days; p95 clears 20% once more than 5% of samples do = 8.4 h/week. 4 × 30 min = 2 h/day = 14 h/week ≈ 8.3%. `CPUQuota=100%` caps it at one core = 50% instance-wide on 2 OCPU. Do not parallelize. **These thresholds are UNVERIFIED — they predate the June allowance change.** Check the OCI console's own CPU/network graphs after a few days. The criteria are an AND across CPU, network and memory; the loop's quote polling plus two daily ~1,000-ticker screener runs may already clear the network leg alone.

**Four bugs found and fixed during review — do not reintroduce:**

1. `TimeoutStartSec=2100` is required. `Type=oneshot` applies it to the whole run; the 90s default would kill a 30-minute burn at 90 seconds.
2. `RestrictAddressFamilies=none`, not `=`. An empty value resets the filter (no restriction); `none` is the form that actually denies. `systemd-analyze verify` accepts both — the linter cannot catch this.
3. `useradd --system --user-group` — the unit names `Group=keepwarm` explicitly; do not rely on the distro `USERGROUPS_ENAB` default.
4. **22:00 UTC, not 21:00.** Under EST the close is at exactly 21:00 UTC — the moment `on_close` / EMA-trail / stall-exit fires, one of the three gated items. Never start ballast on top of it. Tightest margin with 01/05/09/22 is 1 hour across both DST states.
   - EDT (Mar–Nov): session 13:30–20:00 UTC, screener 12:00 UTC
   - EST (Nov–Mar): session 14:30–21:00 UTC, screener 13:00 UTC

**Verified on the laptop 2026-08-01:** 10s run → 15.8M hashes, exit 0; Ctrl+C → clean stop, SIGINT, no traceback; 60s run → 95.2M hashes. Rate held at ~1.58M/s across every run — no thermal throttling. Peak RSS measured at 14.1 MB in the sandbox, which is what `MemoryMax=64M` is sized against (~4.5× headroom).

**Operating it**

```
systemctl list-timers keepwarm.timer
journalctl -u keepwarm.service --since today
systemd-cgtop                          # per-unit CPU attribution
sudo systemctl stop keepwarm.timer     # stop while diagnosing ANYTHING
```

**Smoke test** (60s instead of 1800):

```
sudo systemd-run --unit=keepwarm-smoke --uid=keepwarm \
  --setenv=KEEPWARM_SECONDS=60 /usr/bin/python3 /opt/keepwarm/keepwarm.py
```

**Validate any schedule change** before trusting it:

```
systemd-analyze calendar '*-*-* 01,05,09,22:00:00' --iterations=5
```

Keep every window outside 12:00–21:00 UTC — the union of both DST states, plus margin.

---

# APPENDIX — held positions at time of writing

| ticker | qty | entry | stop | risk | note |
|---|---|---|---|---|---|
| CASY | 21 | 874.34 | 801.60 | $1,527.54 | live-triggered 07-21 |
| JBHT | 85 | 289.47 | 270.94 | $1,575.05 | live-triggered 07-21; survived 08-01 |
| FCUV | 30 | — | — | — | manual anomaly test; no local record |

Near-identical risk per position across very different share counts and prices — the equal-R sizer is doing its job.

◆ **ALL THREE FLATTENED 2026-08-03, by hand in the KIS mock app.** Confirmed by `holdings_probe` on the box: 0 rows across every sample on 08-04 and 08-05. The box therefore started with an empty `kis_engine_state.db` and no orphan positions, and the `F:2026-07-22` zombie dissolved with it. This table is now historical.

---

# APPENDIX B — ⟳ pre-box checklist status (2026-08-03)

**Done and verified**

- `supervisor.py` docstring prohibition + parenthetical reorder (content-verified, `py_compile` clean)
- `force_stop.py` restart guidance — `systemctl`, `>=65s`, no `no-open-order-check` (content-verified)
- `status.py` `wait ~60s` → `wait >=65s` (content-verified at line 21); classified read-only → ships
- `pipeline.py` read guard + freshness gate + docstring + line-121 comment (AST-verified nesting)
- `notifier.py` `"arm blocked"` and `" error:"` in `CRITICAL_SUBSTRINGS` (verified via `classify()` on 8 real strings)
- `test_pipeline_e2e.py` `heartbeat_path=None` + E6 block (14 checks)
- Suite green **115 / 47 / 23** — in the repo AND from the USB deploy copy on a clean venv
- Deploy method decided: explicit copy (no git binary on the laptop)
- Manifest name drift corrected: `heartbeat` → `heartbeat.txt`, `.deadman_state` → `.deadman_state.json`, `status.py` added
- Stray parent-directory `heartbeat.txt` deleted; shadow-tree hypothesis tested and rejected
- Backup #2 built on USB, completed after audit, dry-run installed and content-verified
- Duplicated `tests\tests\` tree removed from the USB; `tests/` re-verified at 4 files
- Dry-run scratch directory deleted (it held a copy of `.env`); no python processes left behind
- Third-party dependency list determined and version-pinned (Part I §6); `google-genai` confirmed as the correct SDK
- `lxml` found by running the screeners — invisible to import scanning (Part I §6)
- Both screeners run end-to-end under the repo venv at threshold 80 (Part I §5h); venv-everywhere verified on the laptop
- Screener silent-failure mode identified: exit 0 on an empty universe — `run_screeners.sh` requirement 6 rewritten (Part III §5)

**Open — resolve before or during box setup**

- Copy this document to the USB alongside the deploy set — it is the seed file for the box-setup chat and has no other home.

**Deliberately deferred (nice-to-have)**

- `.gitignore` extension — inert without a git binary
- `notifier.py` / `status.py` `??` repair — cosmetic, docstrings and log strings only
- Declare data dependencies in `pyproject.toml` so `pip install -e .` is self-sufficient (post-soak)

---

# ◆ APPENDIX C — OPEN ITEMS AS OF 2026-08-05 12:30 KST

**Outstanding right now, before the 22:30 KST open**

1. **§6 daily DB backup — NOT SET UP.** The highest-value open item. The state DB is the only artifact here that cannot be reconstructed, and from tonight it holds the stops for whatever fills. Must be a `sqlite3.backup` (WAL mode), daily, `Persistent=true`, **with a copy pushed off-box** — a backup living only on the instance does not survive losing the instance.
2. **Reverse sync** of the four box-authored artifact groups to the laptop repo (Part I §9k).

**Deferred to post-soak (phase 2)**

- `pyproject.toml` dependency declaration — deliberately parked; touching packaging while the soak runs is the risk that was explicitly declined
- Public `Notifier.flush(timeout)` replacing the `_q.join()` coupling
- `verify` internal call spacing — **must land before phase 4**
- `notifier.py` / `status.py` `??` repair
- `supervisor.py` SIGTERM handler
- Rename the instance to `kistrader-soak` (cosmetic)
- Tighten the security list to a residential IP — safe now that the serial console is proven, but Korean IPs rotate; weigh the lockout risk against the benefit
- OCI orphan boot volume check (Storage → Block Storage → **Boot volumes**, a separate nav entry from Block volumes; the list can be AD-scoped)

**Deferred to live cutover (phase 4) — BLOCKERS**

- `get_order_status == RESTING` (Part I §9a)
- `list_open_order_tickers` / §3.9.1 gate PASS (Part I §9a)
- `ft_ccld_unpr3` execution-price field (Part I §9b)
- Orphan-holding exposure gap (Part I §3)
- A written `.env` / `KIS_MOCK=0` swap checklist (Part III §9)

**Hard deadline, unrelated to the soak**

- `HOLIDAYS_2026` → 2027 entries and half-day modeling, **before 2026-11-27**
