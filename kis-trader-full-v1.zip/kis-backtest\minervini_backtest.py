"""
minervini_backtest.py  (v2) -- production-faithful harness for the kistrader SEPA/VCP system.

WHY v2 EXISTS
=============
v1 was a generic momentum harness: fixed 8%-below-entry stop, ticker-only signals,
SMA-break exit. It could not answer EITHER primary question in the Step-5 seed doc
(§1): `VCP_SCORE_THRESHOLD` needs a VCP score on the signal, and the ATR-floor band
and `max_stop_pct` need the production stop geometry, none of which v1 carried.

CHANGES, AND THE REASON FOR EACH
--------------------------------
1. SIGNAL PAYLOAD IS A CANDIDATE, NOT A TICKER.
   Carries pivot / contraction_low / atr / last_close / rs_rating / vcp_score.
   Reason: without these, `stop = min(structural, atr_floor)` cannot be computed,
   so parked parameters #1, #2, #4 and #5 have no representation. A bare-ticker
   signal is now REFUSED rather than silently downgraded.

2. RANK / SELECT / STOP / SIZE ARE DELEGATED TO THE REAL `decision_engine`.
   Not reimplemented. Reason: the 115 unit invariants are the geometry contract
   (seed doc §10); a reimplementation would measure something the invariants no
   longer guard. `DecisionConfig` is therefore the entire sweep surface.

3. EXITS ARE A PURE REIMPLEMENTATION OF engine_v2's RULES (choice #5-A; C SKIPPED).
   Five constants copied verbatim, no broker, no sqlite, no threads.
   Reason: engine_v2's confirm semantics (tri-state holdings, settle windows,
   flat_since) have no meaning on daily bars; simulating them would dominate the
   work. Replay-validation against engine_v2 (#5-C) was CONSCIOUSLY SKIPPED --
   the soak has never fired an exit alert, on_close, EMA-trail or stall-exit
   live, so there are no production exit events to replay against. The
   reimplementation is therefore PERMANENTLY UNVALIDATED unless that changes;
   `diag["exit_rules"]` says so on every run and it must appear in every result.

4. EQUITY IS MARK-TO-MARKET COMPOUNDING (choice #3-2-B), fixed available as control.
   Reason: risk_per_trade_pct, max_position_pct and max_portfolio_exposure_pct are
   all equity FRACTIONS, so parked parameter #3 is unmeasurable under fixed equity.

5. ENTRY IS THE PRODUCTION PIVOT-LIMIT MODEL (choice #4-B), next-open as control.
   Reason: next-open fill is a different entry style and would confound parked
   parameter #5.

6. INTRABAR AMBIGUITY IS REPORTED AS A BAND, AND DECIDED ON THE WORST BOUND
   (choices #4-B + #4-2-C, decision rule = conservative).
   `run_band()` runs identical inputs twice, resolving every same-bar ambiguity
   against then for the trader, and reports the count of bars that were actually
   ambiguous. NOTE: neither run is a coherent intraday path -- they are BOUNDS.
   Under compounding equity they diverge path-dependently, so the band widens
   with horizon rather than shrinking. Parameter selection therefore uses the
   WORST bound only: `run_band()["conservative"]` and `compare_settings()` rank
   on it, so a wide band can never be argued into a favourable verdict.

8. SECTOR MAP IS A FROZEN FILE (choice #3-C), loaded via `load_sector_map()`.
   Reason: seed doc §4 requires every run to hit local files, never the network.
   Build it once from GICS (choice Q5), commit it, replay from disk. A ticker
   missing from the map is a COUNTED DROP, not a silent sector="" that would
   disable the cap for that name alone.

7. EVERY DROP IS COUNTED (seed doc §10).
   v1 silently discarded: entries on cash exhaustion, signals on non-trading days,
   pending sells that could never fill, and positions still open at the end of the
   run. All four are now explicit, counted, and surfaced in `diag`.

INHERITED, DELIBERATE LIMITS
----------------------------
* Survivorship bias comes from the caller's universe (seed doc §2). Unchanged.
* Stage 2 is cut, so `rank_mode` MUST be chosen explicitly (seed doc §7).
  There is no default; constructing a config without it raises.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field, replace
from enum import Enum
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

# --------------------------------------------------------------------------- #
# The real decision engine -- imported, never reimplemented, so this backtest
# measures the same geometry the 115 unit invariants guard.
# --------------------------------------------------------------------------- #
try:
    from kistrader.entry.decision_engine import (AccountState, DecisionConfig,
                                                 DecisionEngine)
except ImportError:
    try:
        from decision_engine import AccountState, DecisionConfig, DecisionEngine
    except ImportError as _e:
        raise ImportError(
            "minervini_backtest requires the production decision_engine "
            "(kistrader.entry.decision_engine, or a vendored decision_engine.py on "
            "sys.path). Reimplementing it here would decouple the backtest from the "
            "115 unit invariants -- refusing to run."
        ) from _e


# --------------------------------------------------------------------------- #
# Signal payload. Duck-compatible with screen_contract.Candidate for every field
# DecisionEngine reads. Use the REAL Candidate when the screener emits one; this
# exists so synthetic/self-test signals need no screener run.
# --------------------------------------------------------------------------- #
@dataclass
class BTCandidate:
    ticker: str
    exchange: str
    pivot: float
    contraction_low: float
    atr: float
    last_close: float
    rs_rating: int
    vcp_score: float
    session_date: str
    stage2_score: float = 0.0      # Stage 2 is CUT -- see rank_mode, never ranked on
    close_known: bool = True
    trade_signal: bool = False     # screener's volume-confirmed breakout flag
    name: str = ""

    # S8 (2026-09-04) renamed production's Candidate field rs_rating -> rs_proxy
    # (SURVEY_20260904_rs_proxy_rename_surface: 64 sites, 10 files, all in
    # kis-trader-clean). This module keeps rs_rating as the FIELD, because the
    # vendored 2-weight decision_engine every sweep imports reads that name and
    # because harness_anchor.json pins it. The alias below is what lets the same
    # candidate also feed PRODUCTION's 3-weight engine, which F8 forces onto
    # sys.path. Read-only: one field, two names, no second source of truth.
    @property
    def rs_proxy(self) -> int:
        return self.rs_rating

    def problems(self) -> List[str]:
        p = []
        if not self.ticker:
            p.append("no ticker")
        if self.pivot <= 0:
            p.append("pivot <= 0")
        if self.contraction_low <= 0:
            p.append("contraction_low <= 0")
        if self.atr < 0:
            p.append("atr < 0")
        if not (0 <= self.rs_rating <= 99):
            p.append(f"rs_rating {self.rs_rating} out of range")
        return p

    def is_valid(self) -> bool:
        return not self.problems()


# --------------------------------------------------------------------------- #
# Exit rules -- pure reimplementation of engine_v2 (choice #5-A).
# Constants copied verbatim from engine_v2.py lines 48-52.
# --------------------------------------------------------------------------- #
R_PARTIAL_MULTIPLE = 3.0
PARTIAL_FRACTION = 1.0 / 3.0
STALL_DAY = 10
STALL_R_FLOOR = 1.0
# Module-level so a sweep can vary them. run() reads these via cfg overrides
# below rather than the constants directly.
EMA_LEN = 21


class ExitState(Enum):
    FILLED = "FILLED"
    TRAILING = "TRAILING"
    PARTIAL_TAKEN = "PARTIAL_TAKEN"
    CLOSED = "CLOSED"


HOLDING_STATES = (ExitState.FILLED, ExitState.TRAILING, ExitState.PARTIAL_TAKEN)


@dataclass
class BTPosition:
    ticker: str
    state: ExitState
    shares: int
    entry_price: float
    stop_loss_price: float
    initial_risk_per_share: float          # FROZEN at fill (engine_v2 semantics)
    entry_date: pd.Timestamp
    sector: str = ""
    days_held: int = 0
    partial_done: bool = False
    # --- PATCH 1: share-weighted expectancy ---
    # The +3R partial's proceeds go to cash and never reach a Trade, so a
    # share-weighted R cannot be reconstructed afterwards. Record the leg here.
    partial_qty: int = 0
    partial_fill: float = 0.0
    last_roll_date: Optional[pd.Timestamp] = None
    # Maximum Favourable Excursion, in R. How far the trade went in our favour
    # before we exited. If MFE is routinely 2-3R while r_at_exit is 0.1R, the
    # ENTRY is finding real moves and the EXIT is giving them back -- which is a
    # completely different problem from "the setups are bad".
    max_r_seen: float = 0.0
    base_volume: float = 0.0       # mean 50d volume up to entry, for cond 4
    # --- PATCH O (S3) --- the breakout level this trade was taken on. Entry is
    # pivot*(1+entry_chase_pct), so a close back BELOW pivot is a ~-0.5% event
    # while the realised stop is ~-6.4%. Without this field the harness could
    # not tell the two apart and S3 was unrunnable.
    pivot: float = 0.0
    # consecutive closes below the trigger level; reset by any close at or above
    fb_closes_below: int = 0

    def r_multiple(self, price: float) -> float:
        if self.initial_risk_per_share <= 0:
            return 0.0
        return (price - self.entry_price) / self.initial_risk_per_share


@dataclass
class Trade:
    ticker: str
    entry_date: pd.Timestamp
    exit_date: pd.Timestamp
    entry_price: float
    exit_price: float
    shares: int
    reason: str
    r_at_exit: float = 0.0
    max_r_seen: float = 0.0        # MFE in R over the life of the trade
    days_held: int = 0
    # Needed to compute UNCENSORED forward MFE. max_r_seen only covers the actual
    # hold, so a trade cut at day 10 cannot show a move that happened on day 25 --
    # it conflates "the move was not there" with "we left before it happened".
    risk_per_share: float = 0.0
    # --- PATCH 1: share-weighted expectancy ---
    # `shares` above is the RUNNER count. These two make the whole position
    # reconstructible: original size = shares + partial_qty.
    partial_qty: int = 0
    partial_fill: float = 0.0
    # --- PATCH O (S3) --- appended LAST so every existing positional
    # construction of Trade keeps working. Carried for post-hoc analysis: how
    # far below its pivot did a loser close, and how early.
    pivot: float = 0.0

    @property
    def pnl(self) -> float:
        return (self.exit_price - self.entry_price) * self.shares

    @property
    def ret(self) -> float:
        return self.exit_price / self.entry_price - 1.0


# --------------------------------------------------------------------------- #
# Config
# --------------------------------------------------------------------------- #
RANK_MODES = ("rs_only", "vcp_only", "rs_plus_vcp")
EQUITY_MODES = ("compounding", "fixed")
ENTRY_MODES = ("pivot_limit", "next_open")
AMBIGUITY_MODES = ("worst", "best")


# --- PATCH Q --- exposure policies. "constant" is the CONTROL: the ceiling is
# whatever decision.max_portfolio_exposure_pct says and never moves, which is
# every result produced before this patch. "regime_ceiling" expresses the regime
# verdict the way production's ExposureController does -- by WRITING the ceiling
# -- instead of by blanking eligibility.
EXPOSURE_POLICIES = ("constant", "regime_ceiling")


@dataclass
class BacktestConfig:
    # REQUIRED, no default. Seed doc §7: cutting Stage 2 destroyed `2*RS + Stage2`
    # and created a NEW parameter. The harness refuses to guess it.
    rank_mode: str

    equity_mode: str = "compounding"       # choice #3-2: B primary, A control
    starting_equity: float = 100_000.0
    entry_mode: str = "pivot_limit"        # choice #4: B primary, A control
    ambiguity_mode: str = "worst"          # choice #4-2: run both via run_band()

    # Production policy object -- the sweep surface for parked #2 (atr band),
    # #3 (n_max / exposure), #4 (max_stop_pct), #5 (require_trade_signal).
    decision: DecisionConfig = field(default_factory=DecisionConfig)

    vcp_threshold: float = 80.0            # parked parameter #1
    # Exit-engine constants, exposed so they can be swept. Defaults are
    # engine_v2's. Half of all exits at threshold 80 were STALL_EXIT, so these
    # are doing more work than the entry threshold is.
    stall_day: int = STALL_DAY
    stall_r_floor: float = STALL_R_FLOOR
    # Breakeven trigger, DECOUPLED from the +3R partial. Today the stop is raised
    # to entry in exactly ONE place -- when the partial fires (lines 652/659) --
    # and is otherwise frozen from fill (line 525). At stall_day=252 there is no
    # promotion to TRAILING either (line 721), so the EMA trail at line 780 never
    # arms and NOTHING between entry and +3R protects an open gain.
    # None reproduces today's behaviour exactly, so it is the sweep control.
    be_trigger_r: Optional[float] = None
    # MARKET REGIME GATE. Minervini's progressive exposure reduced to its
    # simplest testable form: no NEW entries while the benchmark trades below
    # its own moving average. Open positions are untouched -- exits still run.
    # None reproduces today's behaviour exactly, so it is the sweep control.
    regime_ma: Optional[int] = None

    # ---- PROGRESSIVE EXPOSURE (S1) -----------------------------------------
    # --- PATCH Q --- the ceiling becomes a per-day quantity.
    # "constant" reproduces today's behaviour exactly, so it is the sweep
    # CONTROL -- the same role regime_ma=None and fb_trigger=None play.
    #
    # Before Q the engine was built once (line ~522) and
    # max_portfolio_exposure_pct could not move for the length of a run, so
    # progressive exposure -- a ceiling that MOVES -- was not expressible. This
    # is not "measured and rejected"; it had never been representable.
    #
    # Under "regime_ceiling" the regime verdict is written into the ONE existing
    # gate (decision_engine.plan's exposure ceiling) rather than blanking
    # eligibility. Those agree on trades at 0.00/1.00 and diverge everywhere
    # between, which is the whole region S1 asks about.
    exposure_policy: str = "constant"
    # Mirrors ExposureConfig.risk_off_exposure_pct. 0.0 == the backtested gate:
    # binary, no new entries. Anything above 0.0 is untested softening.
    exposure_risk_off_pct: float = 0.0
    # Mirrors ExposureConfig.unavailable_exposure_pct. SEPARATE from risk_off on
    # purpose: production FAILS CLOSED when the benchmark cannot be read, no
    # matter how permissive the risk-off ceiling is. One shared number would
    # make the harness measure a mechanism production does not run.
    exposure_unavailable_pct: float = 0.0

    # ---- FAILED BREAKOUT (S3) ----------------------------------------------
    # --- PATCH O --- Minervini cuts a breakout that fails to hold its pivot.
    # None reproduces today's behaviour exactly, so it is the sweep CONTROL --
    # same role regime_ma=None and be_trigger_r=None play.
    #   None           off
    #   "same_day"     one close below the level
    #   "two_closes"   two CONSECUTIVE closes below the level
    #   "buffer"       one close below pivot*(1 - fb_buffer_pct)
    # Only evaluated while the position is still FILLED: once it reaches
    # TRAILING or PARTIAL_TAKEN the breakout demonstrably held, and cutting on
    # a pivot it has long since left behind would be a different rule.
    fb_trigger: Optional[str] = None
    fb_buffer_pct: float = 0.0
    # "full" only. PLAN sec.5: the response is a strategy choice, not a sweep
    # output -- sweeping 18 cells on a +/-0.19 R floor chooses noise. See this
    # patch's docstring for why breakeven is near-degenerate here.
    fb_response: str = "full"

    # ---- CONDITIONAL STALL -------------------------------------------------
    # "legacy"      : engine_v2's rule -- at stall_day, exit if r < stall_r_floor.
    # "conditional" : from stall_day onward, evaluate HEALTH conditions each
    #                 close and hold while the stock is acting right. Exit when
    #                 fewer than stall_min_conditions pass. Hard cap at
    #                 stall_max_day regardless (exit reason TIME_CAP).
    #
    # Rationale: no documented source uses a 10-day time stop. Minervini has no
    # time stop at all -- he holds while the Stage 2 trend is intact and cuts on
    # the trailing stop. O'Neil's is 20% in 13 weeks (65 sessions). The legacy
    # rule demands ~0.57%/session; O'Neil's asks ~0.31%/session.
    stall_mode: str = "legacy"
    stall_max_day: int = 126               # ~6 months, hard backstop
    stall_min_conditions: int = 2          # how many health checks must pass
    stall_use_r: bool = True               # cond 1: not underwater (r >= 0)
    stall_use_ema: bool = True             # cond 2: close >= EMA(21)
    stall_use_bench: bool = True           # cond 3: beating the benchmark since entry
    stall_use_volume: bool = True          # cond 4: volume vs its 50d base at entry
    stall_vol_ratio_min: float = 0.7
    # Benchmark closes for cond 3. Without it that condition is skipped and
    # counted as unavailable rather than silently passed.
    benchmark_close: Optional[pd.Series] = None

    # ---- COSTS: researched, not assumed (2026-08 rates) --------------------
    # KIS US-equity commission per side, BOTH sides charged.
    # 0.00014 is JH's actual negotiated/event rate. The published standard online
    # rate is 0.0025 (0.25%) and promotional rates run 0.0007-0.0009; at 0.25%
    # commission consumed 99.9% of gross profit on the threshold-70 run, so this
    # single number decides whether the strategy is viable. Re-verify it before
    # trusting any absolute return figure.
    broker_commission_pct: float = 0.00014         # 0.014% per side
    # SEC Section 31 fee: USD 20.60 per $1,000,000 of SALE proceeds, from 2026-04-04.
    sec_fee_pct: float = 0.0000206                 # sell side only
    # FINRA Trading Activity Fee: per SHARE on sells, from 2026-01-01, capped per trade.
    # Per-share means CHEAP stocks cost proportionally more -- this is why it is
    # modelled per-share rather than folded into a bps figure: us_small pays more.
    taf_per_share: float = 0.000195
    taf_cap_per_trade: float = 9.79
    # Market-impact estimate. NOT engine_v2's BASE_EXIT_SLIP (0.02), which is how
    # far below the bid an exit LIMIT is placed -- order aggressiveness, not cost.
    # Still a heuristic: sweep it and require the parameter RANKING to be stable.
    slippage_bps: float = 5.0
    # FX (KRW<->USD) is deliberately absent: it applies to funding, not per trade,
    # unless the account auto-converts per order (통합증거금). Confirm before relying
    # on any absolute return figure.
    limit_order_ttl_days: int = 1          # entry_manager: watches are DAY ORDERS

    # ---- OPTION A: real delisting events, once a PIT source exists.
    # ticker -> (delist_date, delist_return). delist_return is the terminal return
    # applied to the last observed close, e.g. -0.55 (Shumway & Warther) or the
    # actual DLRET from CRSP dsedelist. A delisting BYPASSES the stop -- that is
    # the whole point: it models the gap-through the stop cannot protect against.
    # Empty dict = no delisting modelling (and the run says so in diag).
    delisting_events: Dict[str, tuple] = field(default_factory=dict)

    # ticker -> sector. An EMPTY map makes decision_engine skip the sector cap
    sector_map: Dict[str, str] = field(default_factory=dict)
    allow_missing_sector_map: bool = False
    strict_sector_map: bool = True

    def __post_init__(self):
        if self.rank_mode not in RANK_MODES:
            raise ValueError(
                f"rank_mode must be one of {RANK_MODES}. Seed doc §7: cutting "
                f"Stage 2 created this parameter; it must be chosen explicitly "
                f"and recorded, never defaulted.")
        if self.be_trigger_r is not None and self.be_trigger_r <= 0:
            raise ValueError("be_trigger_r must be > 0 or None (None = off)")
        # --- PATCH O (S3) ---
        if self.fb_trigger is not None:
            if self.fb_trigger not in ("same_day", "two_closes", "buffer"):
                raise ValueError(
                    "fb_trigger must be None (off), 'same_day', 'two_closes' "
                    f"or 'buffer'. Got {self.fb_trigger!r}.")
            if self.fb_trigger == "buffer" and not (0.0 < self.fb_buffer_pct < 0.5):
                raise ValueError(
                    "fb_trigger='buffer' needs 0 < fb_buffer_pct < 0.5. Got "
                    f"{self.fb_buffer_pct!r}. A zero buffer is 'same_day' -- "
                    "say which you mean.")
        if self.fb_buffer_pct and self.fb_trigger != "buffer":
            raise ValueError(
                f"fb_buffer_pct={self.fb_buffer_pct!r} is set but fb_trigger is "
                f"{self.fb_trigger!r}, which ignores it. Refusing a run whose "
                f"configuration would be mis-labelled.")
        if self.fb_response != "full":
            raise ValueError(
                "fb_response only accepts 'full' in this harness. 'half' and "
                "'breakeven' are separate strategies, not sweep cells "
                "(PLAN sec.5); breakeven is also near-degenerate because entry "
                "is pivot*1.005, so an entry stop sits above market. Got "
                f"{self.fb_response!r}.")
        if self.regime_ma is not None:
            if self.regime_ma < 2:
                raise ValueError("regime_ma must be >= 2 or None (None = off)")
            if self.benchmark_close is None:
                raise ValueError(
                    "regime_ma is set but benchmark_close is None. The gate would "
                    "silently never fire -- exactly the failure this harness exists "
                    "to prevent. Pass ^GSPC or set regime_ma=None.")
        # --- PATCH Q --- every branch here refuses a configuration that would
        # SILENTLY do nothing, which is this harness's whole reason to exist.
        if self.exposure_policy not in EXPOSURE_POLICIES:
            raise ValueError(
                f"exposure_policy must be one of {EXPOSURE_POLICIES}, got "
                f"{self.exposure_policy!r}")
        if self.exposure_policy == "regime_ceiling" and self.regime_ma is None:
            raise ValueError(
                "exposure_policy='regime_ceiling' with regime_ma=None. The "
                "ceiling would never move and the run would be indistinguishable "
                "from 'constant' while being LABELLED as a regime run -- exactly "
                "the ambiguity the regime_ma/benchmark_close guard above exists "
                "to prevent. Set regime_ma, or use 'constant'.")
        _base_ceiling = self.decision.max_portfolio_exposure_pct
        for _n in ("exposure_risk_off_pct", "exposure_unavailable_pct"):
            _v = getattr(self, _n)
            if not (0.0 <= _v <= 1.0):
                raise ValueError(f"{_n} must be in [0.0, 1.0], got {_v}")
            if _v > _base_ceiling:
                raise ValueError(
                    f"{_n}={_v} exceeds the base ceiling "
                    f"decision.max_portfolio_exposure_pct={_base_ceiling}. A "
                    "reduced state that is more permissive than the normal one "
                    "is not a reduced state.")
            if self.exposure_policy == "constant" and _v != 0.0:
                raise ValueError(
                    f"{_n}={_v} is set but exposure_policy='constant', under "
                    "which it is IGNORED. A parameter that silently does nothing "
                    "is how a run gets mislabelled. Set "
                    "exposure_policy='regime_ceiling' or leave it at 0.0.")
        if self.stall_mode not in ("legacy", "conditional"):
            raise ValueError("stall_mode must be 'legacy' or 'conditional'")
        if self.stall_mode == "conditional" and self.stall_max_day < self.stall_day:
            raise ValueError("stall_max_day must be >= stall_day")
        for name, val, allowed in (("equity_mode", self.equity_mode, EQUITY_MODES),
                                   ("entry_mode", self.entry_mode, ENTRY_MODES),
                                   ("ambiguity_mode", self.ambiguity_mode, AMBIGUITY_MODES)):
            if val not in allowed:
                raise ValueError(f"{name} must be one of {allowed}")
        if self.decision.sector_cap and not self.sector_map and not self.allow_missing_sector_map:
            raise ValueError(
                "sector_cap is active but sector_map is empty. decision_engine skips "
                "the cap when sector == '', which would make this run SILENTLY more "
                "permissive than production. Supply sector_map, set "
                "decision.sector_cap=0, or set allow_missing_sector_map=True to "
                "declare the omission explicitly.")


# --------------------------------------------------------------------------- #
# Drop ledger -- seed doc §10: count and report every drop.
# --------------------------------------------------------------------------- #
class DropLog:
    def __init__(self):
        self.counts: Dict[str, int] = {}
        self.detail: List[Tuple[pd.Timestamp, str, str]] = []

    def add(self, date, ticker: str, reason: str):
        self.counts[reason.split(":")[0].strip()] = \
            self.counts.get(reason.split(":")[0].strip(), 0) + 1
        self.detail.append((date, ticker, reason))

    def total(self) -> int:
        return sum(self.counts.values())


def load_bars(bars_dir: str = "data/bars") -> dict:
    """--- PATCH S --- load every *.parquet under `bars_dir`, keyed by ticker.

    RAISES rather than returning empty. `Path(d).glob("*.parquet")` on a
    directory that does not exist returns an EMPTY ITERATOR WITH NO ERROR, so a
    run launched from the wrong working directory silently loads zero bars.

    Every consumer did eventually refuse -- run_backtest on "prices is empty",
    04_signals on a missing ^GSPC, trail_8cell on a missing benchmark -- so this
    was never a route to a wrong NUMBER. But each of those messages names a
    downstream symptom instead of the cause, which cost a debugging cycle on
    2026-08-29. Fail where the mistake is, and say what it was.

    Iteration order is deliberately UNCHANGED (no sorted()): bar ordering has
    not been proven irrelevant to the result, and this helper must be a strict
    no-op on a correct tree.
    """
    import pathlib
    d = pathlib.Path(bars_dir)
    if not d.is_dir():
        raise SystemExit(
            f"[bars] directory not found: {bars_dir}\n"
            f"[bars]   resolved to : {d.resolve()}\n"
            f"[bars]   cwd         : {pathlib.Path.cwd()}\n"
            f"[bars] glob() on a missing directory returns EMPTY WITHOUT ERROR, "
            f"so this run would have proceeded on ZERO bars and failed later "
            f"with a message naming the wrong cause. Run from the kis-backtest "
            f"root.")
    bars = {p.stem: pd.read_parquet(p) for p in d.glob("*.parquet")}
    if not bars:
        raise SystemExit(
            f"[bars] no *.parquet files in {d.resolve()} -- refusing to run on "
            f"zero bars. Run scripts/02_download.py, or check the path.")
    return bars


def load_sector_map(path: str, ticker_col: str = "ticker",
                    sector_col: str = "sector") -> Dict[str, str]:
    """Choice #3-C: load the FROZEN sector file. Build it once (Wikipedia GICS,
    yfinance .info as backfill), commit it, and replay from disk forever after --
    seed doc §4 forbids a run touching the network. Fails closed on a missing
    file or a blank sector rather than yielding a map that silently disables the
    cap for some names."""
    df = pd.read_csv(path)
    cols = {c.lower(): c for c in df.columns}
    if ticker_col not in cols or sector_col not in cols:
        raise ValueError(f"{path} needs '{ticker_col}' and '{sector_col}' columns; "
                         f"found {list(df.columns)}")
    out: Dict[str, str] = {}
    blank = []
    for t, s in zip(df[cols[ticker_col]], df[cols[sector_col]]):
        t = str(t).strip().upper()
        s = str(s).strip()
        if not s or s.lower() in ("nan", "none", "unknown"):
            blank.append(t)
            continue
        out[t] = s
    if blank:
        raise ValueError(
            f"{path}: {len(blank)} ticker(s) have no sector ({blank[:8]}...). A blank "
            f"sector silently disables the per-sector cap for those names. Fill them "
            f"or remove them from the universe deliberately.")
    return out


def _ema(close: pd.Series, span: int = EMA_LEN) -> pd.Series:
    return close.ewm(span=span, adjust=False, min_periods=span).mean()


def _normalize_signals(signals) -> Dict[pd.Timestamp, list]:
    if not isinstance(signals, dict):
        raise TypeError("signals must be {date: [Candidate]}")
    out = {}
    for k, v in signals.items():
        cands = list(v)
        for c in cands:
            if isinstance(c, str):
                raise TypeError(
                    f"signal {c!r} is a bare ticker. v2 requires Candidate objects "
                    f"(pivot, contraction_low, atr, rs_rating, vcp_score); a ticker "
                    f"alone cannot reproduce the production stop geometry.")
        out[pd.Timestamp(k)] = cands
    return out


def _rank_key(cfg: BacktestConfig, c) -> float:
    """Replacement for `2*RS + Stage2`. Explicit, never defaulted (seed doc §7)."""
    if cfg.rank_mode == "rs_only":
        return 2.0 * c.rs_rating
    if cfg.rank_mode == "vcp_only":
        return float(c.vcp_score)
    return 2.0 * c.rs_rating + float(c.vcp_score)

# decision_engine.plan() re-sorts on its OWN rank_score (decision_engine.py:308),
# so any ordering built in this module is discarded. rank_mode must therefore be
# expressed in the ENGINE's weights. This is also the only form that could ever
# be deployed to production, because production ranks with these same fields.
#   rank_score = rs_weight * rs_rating + stage2_weight * stage2_score
# Stage 2 is cut, so stage2_score is a free channel; vcp_score is parked in it
# at line ~794 and the weights below select the mode.
RANK_WEIGHTS = {
    "rs_only":     (2.0, 0.0),   # 2*RS + 0*vcp   == production with catalyst=0
    "vcp_only":    (0.0, 1.0),   # 0*RS + 1*vcp
    "rs_plus_vcp": (2.0, 1.0),   # 2*RS + 1*vcp
}
assert set(RANK_WEIGHTS) == set(RANK_MODES), (
    "RANK_WEIGHTS and RANK_MODES disagree; a mode would silently fall through")

def _sector_counts(positions) -> dict:
    out: Dict[str, int] = {}
    for p in positions.values():
        if p.sector:
            out[p.sector] = out.get(p.sector, 0) + 1
    return out


# --------------------------------------------------------------------------- #
# Engine
# --------------------------------------------------------------------------- #
def run(prices: Dict[str, pd.DataFrame], signals, cfg: BacktestConfig):
    """Returns (equity_curve, trades, stats, drops, diag)."""
    sig = _normalize_signals(signals)
    if not prices:
        raise ValueError("prices is empty -- nothing to simulate")

    calendar = pd.DatetimeIndex(
        sorted(set().union(*[set(df.index) for df in prices.values()])))
    ema = {t: _ema(df["Close"]) for t, df in prices.items()}

    _rs_w, _s2_w = RANK_WEIGHTS[cfg.rank_mode]
    # --- PATCH Q --- hold the base policy so the calendar loop can vary ONE
    # field without re-deriving the rank weights. replace() COPIES, so
    # cfg.decision is never mutated and cannot leak across sweep cells.
    _base_decision = replace(cfg.decision, rs_weight=_rs_w, stage2_weight=_s2_w)
    engine = DecisionEngine(_base_decision)
    _regime_sma = (cfg.benchmark_close.rolling(cfg.regime_ma).mean()
                   if cfg.regime_ma is not None else None)
    sector_of = (lambda t: cfg.sector_map.get(t, "")) if cfg.sector_map else None

    cash = cfg.starting_equity
    positions: Dict[str, BTPosition] = {}
    trades: List[Trade] = []
    equity_curve = pd.Series(index=calendar, dtype=float)
    last_close: Dict[str, float] = {}
    drops = DropLog()
    ambiguous_bars = 0
    partials = 0
    partial_pnl = 0.0
    exposure_reduced_days = 0      # PATCH Q: SIGNAL days spent below the base
                                   # ceiling. Signal days, not calendar days --
                                   # a reduced ceiling on a day with nothing to
                                   # arm has no effect and must not be counted
                                   # as the gate "binding".

    armed: Dict[str, tuple] = {}                       # ticker -> (plan, expiry)
    next_open_buys: Dict[str, tuple] = {}              # ticker -> (plan, expiry)
    pending_sells: Dict[str, Tuple[str, int]] = {}     # ticker -> (reason, waited)

    # option A: index delisting events by session date
    delist_by_date: Dict[pd.Timestamp, list] = {}
    for _t, _ev in cfg.delisting_events.items():
        _d = pd.Timestamp(_ev[0])
        delist_by_date.setdefault(_d, []).append((_t, (_d, float(_ev[1]))))
    position_days = 0
    cond_fail = {"r": 0, "ema": 0, "bench": 0, "volume": 0}
    bench_s = cfg.benchmark_close
    if bench_s is not None and getattr(bench_s.index, "tz", None) is not None:
        bench_s = bench_s.tz_localize(None)
    bench_at_entry: Dict[str, float] = {}
    # Sessions from the FIRST signal onward. The bar calendar can start decades
    # before any signal exists (unfiltered history), and dividing by the whole
    # calendar dilutes deployment by dead years in which nothing could be held.
    active_sessions = 0
    first_signal_pos = None
    delist_events_reached = 0
    delist_events_relevant = 0
    delist_events_hit_open = 0
    ever_traded: set = set()
    delisted_so_far: set = set()

    def slip_sell(p): return p * (1 - cfg.slippage_bps / 1e4)

    def buy_cost(notional: float) -> float:
        """Broker commission only. No SEC fee, no TAF on the buy side."""
        return abs(notional) * cfg.broker_commission_pct

    def sell_cost(notional: float, shares: int) -> float:
        """Broker commission + SEC Section 31 + FINRA TAF (both sell-side only)."""
        taf = min(shares * cfg.taf_per_share, cfg.taf_cap_per_trade)
        return abs(notional) * (cfg.broker_commission_pct + cfg.sec_fee_pct) + taf

    def holdings_value() -> float:
        return sum(p.shares * last_close.get(t, p.entry_price) for t, p in positions.items())

    def close_position(tkr, pos, date, price, reason):
        nonlocal cash
        fill = slip_sell(price)
        cash += pos.shares * fill - sell_cost(pos.shares * fill, pos.shares)
        pos.state = ExitState.CLOSED
        trades.append(Trade(tkr, pos.entry_date, date, pos.entry_price, fill,
                            pos.shares, reason, round(pos.r_multiple(fill), 3),
                            round(pos.max_r_seen, 3), pos.days_held,
                            round(pos.initial_risk_per_share, 6),
                            pos.partial_qty,                    # --- PATCH 1 ---
                            round(pos.partial_fill, 6),         # --- PATCH 1 ---
                            round(pos.pivot, 4)))               # --- PATCH O ---
        positions.pop(tkr, None)

    def try_fill(tkr, plan, price, date):
        """Fill at the CAPPED LIMIT, not at the pivot. In production the trigger
        fires on last >= pivot and the limit (pivot*(1+chase)) sits ABOVE market,
        so it is marketable and fills near the pivot -- using the limit is
        entry_manager's own stated convention: "a conservative overstatement of
        entry -> understates R, never the reverse". A limit fill also cannot be
        worse than the limit, so no adverse slippage applies on entry."""
        nonlocal cash
        if plan.shares <= 0:
            drops.add(date, tkr, "zero_shares"); return
        if price <= plan.stop_price:
            drops.add(date, tkr, "fill_below_stop: gap left no risk distance")
            return
        cost = plan.shares * price + buy_cost(plan.shares * price)
        if cost > cash:
            # v1 dropped this silently; the exposure ceiling should bind first,
            # so reaching here means the caps and the cash model disagree.
            drops.add(date, tkr, "insufficient_cash: exposure ceiling did not bind first")
            return
        cash -= cost
        # --- PATCH O (S3) --- thread the pivot through, and FAIL CLOSED when
        # the trigger is armed but the plan has none. A silent pivot=0 would
        # make every fb_* arm score identically to fb_off, which reads as "the
        # trigger does nothing" rather than "the trigger never fired". That is
        # the same shape as the mock sell-TR id and the unpassed --stall-day.
        _pivot = float(getattr(plan, "pivot", 0.0) or 0.0)
        if cfg.fb_trigger is not None and _pivot <= 0:
            raise ValueError(
                f"fb_trigger={cfg.fb_trigger!r} is armed but the EntryPlan for "
                f"{tkr} carries no pivot (got {_pivot!r}). decision_engine.plan() "
                f"sets pivot=float(c.pivot); a zero here means the vendored "
                f"engine or the candidate contract has changed. Refusing to run "
                f"a failed-breakout sweep that cannot fire.")
        positions[tkr] = BTPosition(
            ticker=tkr, state=ExitState.FILLED, shares=plan.shares, entry_price=price,
            stop_loss_price=plan.stop_price, initial_risk_per_share=price - plan.stop_price,
            entry_date=date, sector=plan.sector, last_roll_date=date,
            pivot=_pivot)
        if bench_s is not None:
            _b = bench_s.loc[bench_s.index <= date]
            if len(_b):
                bench_at_entry[tkr] = float(_b.iloc[-1])
        df_e = prices.get(tkr)
        if df_e is not None and "Volume" in df_e.columns:
            v = df_e.loc[df_e.index <= date, "Volume"].tail(50)
            positions[tkr].base_volume = float(v.mean()) if len(v) else 0.0
        ever_traded.add(tkr)

    for di, d in enumerate(calendar):
        # ---- 0) day roll (engine_v2.advance_trading_day) --------------------
        for pos in positions.values():
            if pos.state in HOLDING_STATES and pos.last_roll_date != d:
                pos.days_held += 1
                pos.last_roll_date = d

        # ---- 1) pending exits fill at THIS open (engine_v2.on_session_open) --
        for tkr in list(pending_sells.keys()):
            reason, waited = pending_sells[tkr]
            if tkr not in positions:
                pending_sells.pop(tkr); continue
            df = prices.get(tkr)
            if df is None or d not in df.index:
                waited += 1
                if waited > cfg.limit_order_ttl_days + 4:
                    pos = positions[tkr]
                    close_position(tkr, pos, d, last_close.get(tkr, pos.entry_price),
                                   f"{reason}_FORCED")
                    drops.add(d, tkr, "pending_sell_forced: no bars left to fill against")
                    pending_sells.pop(tkr)
                else:
                    pending_sells[tkr] = (reason, waited)
                continue
            close_position(tkr, positions[tkr], d, float(df.at[d, "Open"]), reason)
            pending_sells.pop(tkr)

        # ---- 2) entries -----------------------------------------------------
        if cfg.entry_mode == "next_open":
            for tkr in list(next_open_buys.keys()):
                plan, expiry = next_open_buys[tkr]
                df = prices.get(tkr)
                if df is None or d not in df.index:
                    # BOUNDED retry. Without an expiry this loops forever AND
                    # holds a pending_tickers slot, silently blocking the name
                    # from ever being re-signalled -- the v1 pending-sell bug
                    # in a different costume.
                    if d > expiry:
                        next_open_buys.pop(tkr)
                        drops.add(d, tkr, "next_open_expired: no bar before TTL")
                    continue
                next_open_buys.pop(tkr)
                try_fill(tkr, plan, float(df.at[d, "Open"]), d)
        else:
            for tkr in list(armed.keys()):
                plan, expiry = armed[tkr]
                df = prices.get(tkr)
                if df is None or d not in df.index:
                    if d > expiry:
                        armed.pop(tkr)
                        drops.add(d, tkr, "armed_expired: no bar before TTL")
                    continue
                o, h, lo = (float(df.at[d, "Open"]), float(df.at[d, "High"]),
                            float(df.at[d, "Low"]))
                if o > plan.limit_price:
                    # entry_manager: an above-limit gap still PLACES the same
                    # capped limit, which then RESTS BELOW MARKET -- production
                    # never chases past the cap, but it does not abandon the name.
                    # It fills only on a pullback to the limit, and only within
                    # ENTRY_TIMEOUT_SECS (120s) before the order is cancelled.
                    # A daily bar cannot resolve whether the pullback landed
                    # inside that window -> fourth ambiguity class.
                    ambiguous_bars += 1
                    if cfg.ambiguity_mode == "best" and lo <= plan.limit_price:
                        try_fill(tkr, plan, plan.limit_price, d)
                    else:
                        drops.add(d, tkr, "gap_above_limit: resting limit unfilled")
                    armed.pop(tkr)
                elif h >= plan.pivot:
                    try_fill(tkr, plan, plan.limit_price, d)
                    armed.pop(tkr)
                elif d >= expiry:
                    armed.pop(tkr)
                    drops.add(d, tkr, "armed_expired: pivot never touched within TTL")

        # ---- 3) intraday stop / +3R partial (engine_v2._on_tick) ------------
        for tkr in list(positions.keys()):
            df = prices.get(tkr)
            if df is None or d not in df.index:
                continue
            pos = positions[tkr]
            o, h, lo = (float(df.at[d, "Open"]), float(df.at[d, "High"]),
                        float(df.at[d, "Low"]))
            entry_bar = (pos.entry_date == d)
            # ---- breakeven trigger, decoupled from the +3R partial ----------
            # Evaluated BEFORE this bar's high is folded into max_r_seen, so it
            # reads state through the PREVIOUS bar and the amended stop is in
            # the market before this session opens -- which is what amending a
            # stop order actually does. It therefore creates NO new ambiguity
            # class: unlike the partial's stop move, which happens mid-bar and
            # is charged to ambiguous_bars, this one cannot be intrabar.
            # Idempotent -- the stop only ever rises to entry once -- so
            # BTPosition needs no new field.
            if (cfg.be_trigger_r is not None and not entry_bar
                    and pos.stop_loss_price < pos.entry_price
                    and pos.max_r_seen >= cfg.be_trigger_r):
                pos.stop_loss_price = pos.entry_price

            # MFE uses the bar HIGH -- the best the trade ever showed us
            pos.max_r_seen = max(pos.max_r_seen, pos.r_multiple(h))

            stop_touched = lo <= pos.stop_loss_price
            partial_level = pos.entry_price + R_PARTIAL_MULTIPLE * pos.initial_risk_per_share
            partial_touched = (not pos.partial_done) and h >= partial_level

            # Ambiguity classes, both unresolvable from a daily bar:
            #   (a) stop and +3R both inside [low, high]
            #   (b) the entry bar also pierces the stop (did the fill precede the low?)
            ambiguous = (stop_touched and partial_touched) or (entry_bar and stop_touched)
            if ambiguous:
                ambiguous_bars += 1
            worst = (cfg.ambiguity_mode == "worst")

            if entry_bar and stop_touched and not worst:
                stop_touched = False        # optimistic bound: fill came after the low

            if stop_touched and (worst or not partial_touched):
                # On the entry bar the gap already happened before the fill, so the
                # stop fills AT the stop, not at the open.
                fill = pos.stop_loss_price if entry_bar else (
                    o if o < pos.stop_loss_price else pos.stop_loss_price)
                close_position(tkr, pos, d, fill, "STOP_HIT")
                continue

            if partial_touched:
                qty = int(pos.shares * PARTIAL_FRACTION)
                if qty <= 0:
                    pos.partial_done = True
                    pos.stop_loss_price = pos.entry_price
                    pos.state = ExitState.PARTIAL_TAKEN
                else:
                    fill = slip_sell(partial_level)
                    cash += qty * fill - sell_cost(qty * fill, qty)
                    pos.shares -= qty
                    pos.partial_qty = qty       # --- PATCH 1 ---
                    pos.partial_fill = fill     # --- PATCH 1 ---
                    pos.partial_done = True
                    pos.stop_loss_price = pos.entry_price     # breakeven post-confirm
                    pos.state = ExitState.PARTIAL_TAKEN
                    partials += 1
                    # Track separately: the partial's profit lands in cash but
                    # NEVER appears in any Trade record, because Trade.shares is
                    # the reduced runner count. Without this the reconciliation
                    # buries ~25k of real profit in a "residual" bucket.
                    partial_pnl += qty * (fill - pos.entry_price)
                # Ambiguity class (c): the partial moved the stop up to breakeven
                # mid-bar, and this same bar's low is below the NEW stop. Whether
                # the low preceded the +3R touch is unknowable from a daily bar.
                if lo <= pos.stop_loss_price:
                    if not ambiguous:
                        ambiguous_bars += 1
                    if worst:
                        close_position(tkr, pos, d, pos.stop_loss_price, "STOP_HIT")

        # ---- 3b) DELISTING (option A). Bypasses the stop deliberately: this is
        # ---- the gap-through the stop cannot protect against. Positions already
        # ---- closed by then were "caught by the stop" -- counting both gives a
        # ---- MEASURED stop_catches_frac instead of an assumed one.
        for tkr, ev in delist_by_date.get(d, ()):
            _dt, dret = ev
            delist_events_reached += 1
            if tkr in ever_traded:
                # Only names we actually traded can tell us anything about
                # whether the STOP protected us. A delisting in a name we never
                # touched is not "caught by the stop" -- it is irrelevant, and
                # counting it would drive the measured rate toward 1.0 on any
                # realistic universe.
                delist_events_relevant += 1
            if tkr in positions:
                pos = positions[tkr]
                px = last_close.get(tkr, pos.entry_price) * (1.0 + dret)
                close_position(tkr, pos, d, max(px, 0.0), "DELISTED")
                delist_events_hit_open += 1
            armed.pop(tkr, None)
            next_open_buys.pop(tkr, None)
            pending_sells.pop(tkr, None)
            delisted_so_far.add(tkr)

        # ---- 4) mark closes --------------------------------------------------
        # ONLY held names. Every reader of last_close (holdings_value, the forced
        # pending-sell close, the delisting path, the EOD force-close) looks up
        # tickers that are in . Marking the whole universe meant ~1500
        # scalar .at[] lookups per session instead of <=8 -- with ~3600 sessions
        # that is 5.4M pandas accesses per run, and a sweep does 57 runs.
        # This step runs AFTER entries and exits, so  is exactly what
        # is held at the close.
        for tkr in positions:
            df = prices.get(tkr)
            if df is not None and d in df.index:
                last_close[tkr] = float(df.at[d, "Close"])

        # ---- 5) close decisions -> queued for next open (engine_v2.on_close) -
        for tkr in list(positions.keys()):
            df = prices.get(tkr)
            if df is None or d not in df.index or tkr in pending_sells:
                continue
            pos = positions[tkr]
            close = float(df.at[d, "Close"])
            e = ema[tkr].get(d, np.nan)
            # --- PATCH O (S3) --- failed breakout. Evaluated BEFORE the stall
            # block and only while FILLED. Queued for the next open exactly like
            # every other close decision, so the fill model is unchanged.
            if cfg.fb_trigger is not None and pos.state == ExitState.FILLED:
                _lvl = (pos.pivot * (1.0 - cfg.fb_buffer_pct)
                        if cfg.fb_trigger == "buffer" else pos.pivot)
                if close < _lvl:
                    pos.fb_closes_below += 1
                else:
                    pos.fb_closes_below = 0
                _need = 2 if cfg.fb_trigger == "two_closes" else 1
                if pos.fb_closes_below >= _need:
                    pending_sells[tkr] = ("FAILED_BREAKOUT", 0)
                    continue
            if pos.state == ExitState.FILLED and pos.days_held >= cfg.stall_day:
                if cfg.stall_mode == "legacy":
                    if pos.r_multiple(close) < cfg.stall_r_floor:
                        pending_sells[tkr] = ("STALL_EXIT", 0)
                    else:
                        pos.state = ExitState.TRAILING
                elif pos.r_multiple(close) >= cfg.stall_r_floor:
                    # Earned its way onto the trail. From here the EMA trail
                    # governs, exactly as in legacy.
                    pos.state = ExitState.TRAILING
                else:
                    # ---- below the floor: survive on HEALTH, re-checked EVERY
                    # ---- close until it either earns the trail, fails the
                    # ---- health test, or hits the hard cap. The first version
                    # ---- of this checked once at stall_day and then promoted,
                    # ---- which is the legacy rule with extra steps.
                    passed, checked = 0, 0
                    if cfg.stall_use_r:
                        # a softer floor: not losing money, even if not yet 1R
                        checked += 1
                        ok = pos.r_multiple(close) >= 0.0
                        passed += ok
                        cond_fail["r"] += (not ok)
                    if cfg.stall_use_ema:
                        e_ = ema[tkr].get(d, np.nan)
                        if not (isinstance(e_, float) and math.isnan(e_)):
                            checked += 1
                            ok = close >= float(e_)
                            passed += ok
                            cond_fail["ema"] += (not ok)
                    if cfg.stall_use_bench and bench_s is not None:
                        b_now = bench_s.get(d)
                        b_in = bench_at_entry.get(tkr)
                        if b_now is not None and b_in:
                            checked += 1
                            ok = (close / pos.entry_price) >= (b_now / b_in)
                            passed += ok
                            cond_fail["bench"] += (not ok)
                    if cfg.stall_use_volume and pos.base_volume > 0:
                        dfv = prices.get(tkr)
                        if dfv is not None and "Volume" in dfv.columns:
                            vv = dfv.loc[dfv.index <= d, "Volume"].tail(10)
                            if len(vv):
                                checked += 1
                                ok = (float(vv.mean()) / pos.base_volume
                                      >= cfg.stall_vol_ratio_min)
                                passed += ok
                                cond_fail["volume"] += (not ok)
                    need = min(cfg.stall_min_conditions, checked) if checked else 0
                    if checked and passed < need:
                        pending_sells[tkr] = ("STALL_EXIT", 0)
                    elif pos.days_held >= cfg.stall_max_day:
                        pending_sells[tkr] = ("TIME_CAP", 0)
                    # else: stay in FILLED and re-check tomorrow
            elif pos.state in (ExitState.TRAILING, ExitState.PARTIAL_TAKEN):
                if (cfg.stall_mode == "conditional"
                        and pos.days_held >= cfg.stall_max_day):
                    pending_sells[tkr] = ("TIME_CAP", 0)
                elif not (isinstance(e, float) and math.isnan(e)) and close < float(e):
                    pending_sells[tkr] = ("EMA_BREAK", 0)

        # ---- 6) tonight's screen -> decision_engine -> arms -------------------
        todays = sig.get(d)
        if todays:
            equity = (cash + holdings_value()) if cfg.equity_mode == "compounding" \
                     else cfg.starting_equity
            eligible = []
            for c in todays:
                if c.vcp_score < cfg.vcp_threshold:
                    drops.add(d, c.ticker, "below_vcp_threshold")
                elif c.ticker not in prices:
                    drops.add(d, c.ticker, "no_price_data")
                elif c.ticker in delisted_so_far:
                    drops.add(d, c.ticker, "already_delisted")
                elif (cfg.strict_sector_map and cfg.sector_map
                      and c.ticker not in cfg.sector_map):
                    # sector "" would disable the cap for this name alone
                    drops.add(d, c.ticker, "unmapped_sector: not in frozen sector file")
                else:
                    eligible.append(c)

            account = AccountState(
                equity=equity, cash=cash,
                held_tickers=frozenset(positions.keys()),
                pending_tickers=frozenset(list(armed) + list(next_open_buys)),
                open_position_count=len(positions),
                open_notional=holdings_value(),
                sector_counts=_sector_counts(positions),
                sector_of=sector_of)
            # vcp_score parked in stage2_score so the engine's rank_score can see
            # it; replace() COPIES, so the shared signals dict is never mutated
            # across sweep settings or cost levels. Sorting here is now cosmetic --
            # plan() re-sorts on rank_score - but it keeps this line honest.
            # --- PATCH Q --- ONE GATE, ONE SOURCE (exposure_controller.py
            # design rule 1). The regime verdict is computed once here and then
            # spent EITHER as a ceiling write (production's mechanism) OR as the
            # legacy eligibility blank -- never both.
            _regime_state = None
            if _regime_sma is not None:
                _bc, _bm = cfg.benchmark_close.get(d), _regime_sma.get(d)
                if _bc is None or _bm is None or pd.isna(_bm):
                    _regime_state = "unavailable"
                elif float(_bc) < float(_bm):
                    _regime_state = "off"
                else:
                    _regime_state = "on"

            _ceiling = _base_decision.max_portfolio_exposure_pct
            if cfg.exposure_policy == "regime_ceiling":
                if _regime_state == "off":
                    _ceiling = cfg.exposure_risk_off_pct
                elif _regime_state == "unavailable":
                    _ceiling = cfg.exposure_unavailable_pct
            elif _regime_state is not None and eligible:
                # LEGACY blank -- unchanged, and the default. Candidates are
                # dropped BEFORE plan() sees them, which is why the drop ledger
                # differs between the two policies even when the trades do not.
                if _regime_state == "unavailable":
                    for _c in eligible:
                        drops.add(d, _c.ticker, "regime_unavailable")
                    eligible = []
                elif _regime_state == "off":
                    for _c in eligible:
                        drops.add(d, _c.ticker, "regime_off")
                    eligible = []

            if _ceiling < _base_decision.max_portfolio_exposure_pct:
                exposure_reduced_days += 1
            if _ceiling != engine.cfg.max_portfolio_exposure_pct:
                engine = DecisionEngine(
                    replace(_base_decision, max_portfolio_exposure_pct=_ceiling))
            ordered = [replace(c, stage2_score=float(c.vcp_score)) for c in eligible]
            plans, rejections = engine.plan(ordered, account)
            for r in rejections:
                drops.add(d, r.ticker, f"decision_engine/ {r.reason}")
            expiry = calendar[min(di + cfg.limit_order_ttl_days, len(calendar) - 1)]
            for p in plans:
                if cfg.entry_mode == "next_open":
                    next_open_buys[p.ticker] = (p, expiry)
                else:
                    armed[p.ticker] = (p, expiry)

        position_days += len(positions)
        if sig.get(d) or first_signal_pos is not None:
            if first_signal_pos is None:
                first_signal_pos = di
            active_sessions += 1
        equity_curve.at[d] = cash + holdings_value()

    # ---- open positions at the end were invisible to every trade statistic in
    # ---- v1 while still driving the equity curve. Force-close and count them.
    eod_open = 0
    for tkr in list(positions.keys()):
        pos = positions[tkr]
        close_position(tkr, pos, calendar[-1], last_close.get(tkr, pos.entry_price), "EOD_OPEN")
        eod_open += 1
    equity_curve.at[calendar[-1]] = cash

    # Stats must be computed on the ACTIVE window. The bar calendar routinely
    # starts decades before the first signal (05_backtest loads bars untrimmed),
    # and a flat cash prefix does not change total_return or max_drawdown but it
    # wrecks anything time-normalised: CAGR takes the root over the wrong span
    # (0.27% instead of 2.07% on an 8.6y run) and Sharpe is diluted by years of
    # zero-variance returns.
    _eq = equity_curve.dropna()
    if first_signal_pos is not None and first_signal_pos < len(calendar):
        _eq = _eq.loc[_eq.index >= calendar[first_signal_pos]]
    stats = _summarize(_eq, trades)
    diag = {
        "rank_mode": cfg.rank_mode, "equity_mode": cfg.equity_mode,
        "entry_mode": cfg.entry_mode, "ambiguity_mode": cfg.ambiguity_mode,
        "vcp_threshold": cfg.vcp_threshold,
        "ambiguous_bars": ambiguous_bars, "eod_open_forced": eod_open,
        "partials_taken": partials,
        "stall_mode": cfg.stall_mode,
        "stall_condition_failures": dict(cond_fail),
        # PATCH Q -- which exposure mechanism produced this result. A run that
        # cannot say this is not a result.
        "exposure_policy": cfg.exposure_policy,
        "exposure_risk_off_pct": cfg.exposure_risk_off_pct,
        "exposure_unavailable_pct": cfg.exposure_unavailable_pct,
        "exposure_reduced_days": exposure_reduced_days,
        "benchmark_supplied": bench_s is not None,
        "partial_pnl": round(partial_pnl, 2), "drops_total": drops.total(),
        "drops_by_reason": dict(sorted(drops.counts.items())),
        "sector_cap_measured": bool(cfg.sector_map),
        # Fraction of available ticker-time actually spent holding. This is the
        # single cleanest measure of how EXPOSED the strategy is to survivorship
        # bias at all: a delisting can only hurt a name you were holding. Short
        # holds + day-order arms make this small, which is why index-level bias
        # figures overstate the damage to a stopped, low-occupancy strategy.
        "held_ticker_time_frac": round(
            position_days / max(active_sessions * len(prices), 1), 6),
        "active_sessions": active_sessions,
        "calendar_sessions": len(calendar),
        "stats_window": (f"{_eq.index[0].date()}..{_eq.index[-1].date()}"
                         if len(_eq) else "empty"),
        "stats_window_years": (round((_eq.index[-1] - _eq.index[0]).days / 365.25, 2)
                               if len(_eq) > 1 else 0.0),
        "avg_positions_held": round(position_days / max(active_sessions, 1), 3),
        "delisting_modelled": bool(cfg.delisting_events),
        "delist_events_in_window": delist_events_reached,
        "delist_events_in_traded_names": delist_events_relevant,
        "delist_events_hit_open_position": delist_events_hit_open,
        # MEASURED, not assumed. Denominator is delistings in names the strategy
        # ACTUALLY TRADED -- not every delisting in the window. Using the latter
        # would count "we never bought it" as "the stop saved us" and drive the
        # rate toward 1.0 on any realistic universe.
        "stop_catches_frac_measured": (
            round(1.0 - delist_events_hit_open / delist_events_relevant, 3)
            if delist_events_relevant else None),
        "exit_rules": ("PURE REIMPLEMENTATION of engine_v2 -- UNVALIDATED against "
                       "production until soak exit events exist to replay (#5-C)"),
    }
    return _eq, trades, stats, drops, diag


def _weighted_r(t: "Trade") -> float:
    """--- PATCH 1 --- Share-weighted R across BOTH legs.

    t.shares is the runner; t.partial_qty is what the +3R partial sold. Original
    size is their sum. A trade that never partialled returns exactly r_at_exit,
    so this is identical to the old number for every non-partialled trade.
    """
    pq = getattr(t, "partial_qty", 0) or 0
    total = t.shares + pq
    if t.risk_per_share <= 0 or total <= 0:
        return float(t.r_at_exit)
    pnl = (pq * (getattr(t, "partial_fill", 0.0) - t.entry_price)
           + t.shares * (t.exit_price - t.entry_price))
    return pnl / (total * t.risk_per_share)


def _summarize(equity: pd.Series, trades: List[Trade]) -> dict:
    if equity.empty:
        return {}
    rets = equity.pct_change().dropna()
    years = max((equity.index[-1] - equity.index[0]).days, 1) / 365.25
    total_ret = equity.iloc[-1] / equity.iloc[0] - 1
    dd = float((equity / equity.cummax() - 1).min())
    wins = [t for t in trades if t.pnl > 0]
    losses = [t for t in trades if t.pnl < 0]
    flat = [t for t in trades if t.pnl == 0]
    # None, not NaN: NaN != NaN silently breaks equality checks and can sort
    # unpredictably in compare_settings. An undefined Sharpe should be visibly
    # absent, not a value that compares false against itself.
    sharpe = ((rets.mean() / rets.std() * math.sqrt(252))
              if len(rets) and rets.std() > 0 else None)
    return {
        "start_equity": round(float(equity.iloc[0]), 2),
        "end_equity": round(float(equity.iloc[-1]), 2),
        "total_return_pct": round(float(total_ret) * 100, 2),
        # v1 annualized a 2-month run into a 39% CAGR. Refuse below 6 months.
        "cagr_pct": (round(float((equity.iloc[-1] / equity.iloc[0]) ** (1 / years) - 1) * 100, 2)
                     if years >= 0.5 else "n/a (<6mo: annualizing would be noise)"),
        "max_drawdown_pct": round(dd * 100, 2),
        "sharpe_daily_ann": (round(float(sharpe), 2) if sharpe is not None
                             else "n/a (no variance in equity)"),
        "num_trades": len(trades), "num_wins": len(wins),
        "num_losses": len(losses), "num_flat": len(flat),
        "win_rate_pct": round(100 * len(wins) / len(trades), 1) if trades else 0.0,
        "avg_win_pct": round(100 * float(np.mean([t.ret for t in wins])), 2) if wins else 0.0,
        "avg_loss_pct": round(100 * float(np.mean([t.ret for t in losses])), 2) if losses else 0.0,
        "expectancy_pct": round(100 * float(np.mean([t.ret for t in trades])), 2) if trades else 0.0,
        "expectancy_R": round(float(np.mean([t.r_at_exit for t in trades])), 3) if trades else 0.0,
        # --- PATCH 1: share-weighted expectancy ---
        # expectancy_R above is the RUNNER leg's per-share R and is position-size
        # INVARIANT, which scripts/06_sweep.py's FALLACY-4 test depends on. Do not
        # substitute this for it. This one includes the +3R partial leg, so it is
        # what the account earned per unit of risk -- and it is NOT size-invariant,
        # because the partial is int(shares/3).
        "expectancy_R_weighted": (round(float(np.mean(
            [_weighted_r(t) for t in trades])), 3) if trades else 0.0),
        "partialled_trades": sum(1 for t in trades if getattr(t, "partial_qty", 0) > 0),
        "exit_reasons": {r: sum(1 for t in trades if t.reason == r)
                         for r in sorted({t.reason for t in trades})},
        # Reward:risk actually delivered, vs what the setups offered
        # --- PATCH J --- these three were the only stats over `trades` WITHOUT
        # the `if trades else 0.0` guard their neighbours carry. On a zero-trade
        # run np.mean([]) is nan, and nan != nan, so two byte-identical stats
        # dicts compared unequal -- reported by audit_full as non-determinism.
        # Measured 2026-08-28: repr(a) == repr(b) was True while a == b was False.
        "avg_mfe_R": (round(float(np.mean([t.max_r_seen for t in trades])), 3)
                      if trades else 0.0),
        "avg_r_at_exit": (round(float(np.mean([t.r_at_exit for t in trades])), 3)
                          if trades else 0.0),
        "giveback_R": (round(float(np.mean([t.max_r_seen - t.r_at_exit
                                            for t in trades])), 3)
                       if trades else 0.0),
        "pct_reaching_3R": round(100 * sum(1 for t in trades if t.max_r_seen >= 3.0)
                                 / len(trades), 1) if trades else 0.0,
        "pct_reaching_2R": round(100 * sum(1 for t in trades if t.max_r_seen >= 2.0)
                                 / len(trades), 1) if trades else 0.0,
    }


def run_band(prices, signals, cfg: BacktestConfig):
    """Choice #4-2-C. Identical inputs run twice, resolving every same-bar
    ambiguity against then for the trader. Returns both runs plus the band.

    Neither run is a coherent intraday path -- they are BOUNDS. Under compounding
    equity the two diverge path-dependently, so the band widens with horizon
    rather than shrinking; `ambiguous_bars` is how often the question was live."""
    out = {}
    for mode in AMBIGUITY_MODES:
        eq, tr, st, dr, dg = run(prices, signals, replace(cfg, ambiguity_mode=mode))
        out[mode] = {"equity": eq, "trades": tr, "stats": st, "drops": dr, "diag": dg}
    band = {}
    for k in ("total_return_pct", "max_drawdown_pct", "expectancy_R",
              "win_rate_pct", "num_trades"):
        a, b = out["worst"]["stats"].get(k), out["best"]["stats"].get(k)
        if isinstance(a, (int, float)) and isinstance(b, (int, float)):
            band[k] = (min(a, b), max(a, b))
    band["ambiguous_bars"] = out["worst"]["diag"]["ambiguous_bars"]
    out["band"] = band
    # Decision rule: the WORST bound is the number a parameter choice is judged
    # on. A wide band can then never be argued into a favourable verdict.
    out["conservative"] = out["worst"]["stats"]
    out["decision_rule"] = ("worst bound only -- the optimistic run exists to size "
                            "the uncertainty, never to justify a parameter")
    return out


def universe_coverage(constituents_by_date: Dict, priceable: set) -> dict:
    """OPTION C -- size the hole, don't correct it. Free, exact, no new data.

    `constituents_by_date`: {date: [tickers that WERE in the index then]} — from
    Wikipedia change tables replayed backwards from today's list.
    `priceable`: tickers you actually have bars for (i.e. still listed).

    Returns per-date coverage plus the worst case. This number belongs in every
    reported result: "this window is blind to N% of the population that existed."
    """
    rows, missing_ever = [], set()
    for d in sorted(constituents_by_date):
        members = set(constituents_by_date[d])
        have = members & priceable
        gone = members - priceable
        missing_ever |= gone
        rows.append({"date": d, "constituents": len(members),
                     "priceable": len(have), "missing": len(gone),
                     "coverage_pct": round(100 * len(have) / max(len(members), 1), 2)})
    cov = [r["coverage_pct"] for r in rows] or [100.0]
    return {"by_date": rows,
            "worst_coverage_pct": min(cov),
            "mean_coverage_pct": round(sum(cov) / len(cov), 2),
            "distinct_missing_tickers": len(missing_ever),
            "note": ("Blind spot, not a correction. Absolute returns are an "
                     "optimistic ceiling by roughly this fraction of the universe.")}


def bias_gradient(prices, signals, cfg: BacktestConfig,
                  survivor_layers: Dict[str, set], metric: str = "expectancy_R") -> dict:
    """OPTION E (salvaged) -- measure how much each ADDED layer of survivorship
    inflates the result, using only data you already have.

    The original idea (cross-validate against a clean external universe) fails for
    this strategy: the only free clean universe is the Dow 30, whose constituents
    almost never delist for performance, and on which the screening funnel cannot
    run at all (RS is a percentile over the scanned population). So instead of
    finding a less-biased dataset, we add MORE bias and measure the slope.

    `survivor_layers`: {label: set(tickers)}, ordered from least to most filtered,
    e.g. {"all_current": all, "also_in_index_5y_ago": subset, "also_outperformed": subset}.

    ASSUMPTION, stated because it is doing real work: the inflation from removing
    one layer of survivorship is taken as a proxy for the inflation caused by the
    layer you are MISSING (names that vanished entirely). That is a linear
    extrapolation one step beyond the observed range. It bounds the magnitude; it
    does not measure it.
    """
    out, order = {}, list(survivor_layers)
    for label in order:
        keep = survivor_layers[label]
        sub_prices = {t: df for t, df in prices.items() if t in keep}
        sub_signals = {d: [c for c in cs if c.ticker in keep]
                       for d, cs in signals.items()}
        sub_signals = {d: cs for d, cs in sub_signals.items() if cs}
        if not sub_prices or not sub_signals:
            out[label] = {"error": "layer empty after filtering"}
            continue
        r = run_band(sub_prices, sub_signals, cfg)
        out[label] = {"n_tickers": len(sub_prices),
                      metric: r["conservative"].get(metric),
                      "num_trades": r["conservative"].get("num_trades")}
    steps = []
    for a, b in zip(order, order[1:]):
        va, vb = out.get(a, {}).get(metric), out.get(b, {}).get(metric)
        if isinstance(va, (int, float)) and isinstance(vb, (int, float)):
            steps.append({"from": a, "to": b, "delta": round(vb - va, 4)})
    return {"layers": out, "steps": steps,
            "implied_bias_per_layer": (round(sum(s["delta"] for s in steps) / len(steps), 4)
                                       if steps else None),
            "WARNING": ("Extrapolation one step beyond the observed range. Report as "
                        "a magnitude bound, never as a correction to subtract.")}


def synthetic_delisting_stress(prices, signals, cfg: BacktestConfig, *,
                               delist_rate_per_year: float,
                               delist_return: float = -0.55,
                               n_draws: int = 200, seed: int = 0,
                               metric: str = "expectancy_R") -> dict:
    """OPTION A WITHOUT a delisted-price source -- a stress test, not a measurement.

    The real option A needs prices for companies that no longer exist, so that the
    screener could have selected them and the delisting could then fire. Wikipedia
    gives the EVENTS (ticker, date, reason) but not the PRICES, so those names
    never enter the universe and the event never triggers.

    What CAN be done now: take the names the strategy actually traded and ask
    "what if some of them had delisted instead of exiting normally?" Draw delisting
    events at the empirical base rate, re-run, and report the distribution. That
    bounds the damage without inventing prices.

    Base rates (Shumway & Warther 1999): ~1.2%/yr NYSE-AMEX, ~5.6%/yr Nasdaq for
    performance-related delistings. Those are WHOLE-UNIVERSE rates; a Minervini
    trend template rarely selects a company heading into one, so using them here
    is deliberately pessimistic.

    Runs at ambiguity_mode="worst" throughout, per the standing decision rule.
    """
    base_cfg = replace(cfg, ambiguity_mode="worst")
    _, base_trades, base_stats, _, _ = run(prices, signals, base_cfg)
    baseline = base_stats.get(metric)

    calendar = pd.DatetimeIndex(
        sorted(set().union(*[set(df.index) for df in prices.values()])))
    # Span must be the ACTIVE window, not the bar calendar. Bars are commonly
    # loaded untrimmed and reach back decades before the first signal; using the
    # full calendar applied ~64 years of delisting risk to an 11-year backtest
    # and clamped p to 1.0, delisting every ticker in every draw.
    sig_dates = [pd.Timestamp(d) for d in signals] if signals else []
    if sig_dates:
        win_lo, win_hi = min(sig_dates), calendar[-1]
    else:
        win_lo, win_hi = calendar[0], calendar[-1]
    window = calendar[(calendar >= win_lo) & (calendar <= win_hi)]
    span_years = max((win_hi - win_lo).days, 1) / 365.25
    p_ticker = min(delist_rate_per_year * span_years, 1.0)

    rng = np.random.default_rng(seed)
    tickers = sorted(prices)
    draws, n_events = [], []
    for _ in range(n_draws):
        events = {}
        for t in tickers:
            if rng.random() < p_ticker:
                events[t] = (window[rng.integers(0, len(window))], delist_return)
        n_events.append(len(events))
        _, _, st, _, _ = run(prices, signals, replace(base_cfg, delisting_events=events))
        v = st.get(metric)
        if isinstance(v, (int, float)):
            draws.append(float(v))

    if not draws:
        return {"error": "no numeric results -- check metric name"}
    arr = np.array(draws)
    return {
        "baseline_" + metric: baseline,
        "draws": n_draws,
        "p_delist_per_ticker_over_window": round(p_ticker, 4),
        "span_years": round(span_years, 2),
        "window": f"{win_lo.date()}..{win_hi.date()}",
        "mean_events_per_draw": round(float(np.mean(n_events)), 2),
        "p05": round(float(np.percentile(arr, 5)), 4),
        "p50": round(float(np.percentile(arr, 50)), 4),
        "p95": round(float(np.percentile(arr, 95)), 4),
        "worst_draw": round(float(arr.min()), 4),
        "mean_shift_vs_baseline": (round(float(arr.mean()) - baseline, 4)
                                   if isinstance(baseline, (int, float)) else None),
        "WARNING": ("STRESS TEST, not a measurement. It injects delistings into names "
                    "that DID trade; it cannot recover names that never entered the "
                    "universe because their prices are gone. Report the p05 under the "
                    "standing worst-bound rule."),
    }


def robustness_check(prices, signals, cfg: BacktestConfig, *,
                     settings: Dict[str, dict],
                     slippage_grid=(0.0, 5.0, 15.0, 30.0),
                     metric: str = "expectancy_R",
                     higher_is_better: bool = True,
                     min_trades: int = 1,
                     min_confidence_trades: int = 30) -> dict:
    """Does the WINNER survive the cost sweep?

    `settings` maps a label to the kwargs that define it, e.g.
        {"thr_70": {"vcp_threshold": 70.0}, "thr_80": {"vcp_threshold": 80.0}}

    Every setting is run at every slippage level, always on the WORST intrabar
    bound. If the winner changes across the grid, the parameter choice is NOT
    supported by the data and this returns verdict="NOT ROBUST" -- report that
    instead of a number.

    Why this matters more than picking the right slippage: slippage is the one
    heuristic the backtest ITSELF introduces, and it is not neutral across the
    thing being tested. A looser VCP threshold trades more, so it pays more
    cost. Zeroing costs would systematically favour looser thresholds; picking
    a number would bury that choice. Sweeping it removes its power to decide.
    """
    table: Dict[float, List[Tuple[str, float]]] = {}
    # --- PATCH K --- `trade_counts` is assigned inside the slippage loop below,
    # so it holds the LAST grid level only (30.0 bps by default) and is printed
    # with no cost label. On 2026-08-28 that read as a one-trade miss against
    # Rev 3's 200 when expectancy_R and max_drawdown_pct had both reproduced
    # EXACTLY at 5.0 bps. Keep it -- the min_trades exclusion below uses it and
    # the highest-cost level is the conservative basis for that -- but also
    # record every level, which is what the report needs.
    trade_counts: Dict[str, int] = {}
    trade_counts_by_slip: Dict[float, Dict[str, int]] = {}
    for slip in slippage_grid:
        runs = {}
        for label, kw in settings.items():
            c = replace(cfg, slippage_bps=slip, ambiguity_mode="worst", **kw)
            runs[label] = run_band(prices, signals, c)
            trade_counts[label] = runs[label]["conservative"].get("num_trades", 0)
        trade_counts_by_slip[slip] = {
            lbl: runs[lbl]["conservative"].get("num_trades", 0)
            for lbl in settings}
        table[slip] = compare_settings(runs, metric=metric,
                                       higher_is_better=higher_is_better,
                                       min_trades=min_trades)
    excluded = sorted(l for l, n in trade_counts.items() if n < min_trades)

    winners = {slip: ranked[0][0] for slip, ranked in table.items() if ranked}
    stable = len(set(winners.values())) == 1
    orders = {slip: [lbl for lbl, _ in ranked] for slip, ranked in table.items()}
    order_stable = len({tuple(v) for v in orders.values()}) == 1

    # A sweep where every setting scores IDENTICALLY is not evidence of
    # robustness -- it means the parameter never bound, usually because some
    # other constraint (sector cap, n_max, exposure ceiling) decided everything.
    # Reporting that as ROBUST would be a false pass, so it gets its own verdict.
    # A winner separated from second place by 0.000 is SORT ORDER, not a result.
    #  only catches the case where EVERY setting ties; the
    # atrfloor sweep tied its top FOUR and still reported a recommendation.
    margins = {}
    for _slip, _ranked in table.items():
        margins[_slip] = (round(_ranked[0][1] - _ranked[1][1], 6)
                          if len(_ranked) > 1 else None)
    winner_tied = any(m == 0.0 for m in margins.values() if m is not None)
    n_tied_at_top = 0
    if table:
        _first = next(iter(table.values()))
        if _first:
            _top = _first[0][1]
            n_tied_at_top = sum(1 for _l, _v in _first if _v == _top)
    # Trade counts below this get REPORTED rather than silently ranked. 14 trades
    # over 11.6 years produced the highest score in the entrystyle sweep.
    low_trade = sorted((l, n) for l, n in trade_counts.items()
                       if min_trades <= n < min_confidence_trades)

    undifferentiated = all(len(set(round(v, 6) for v in dict(ranked).values())) <= 1
                           for ranked in table.values() if ranked)

    # Probe the WINNER, not whichever setting happens to be first in the dict.
    # Reporting thr_55's drop counts beside a thr_70 recommendation invites
    # reading the diagnostics as if they described the winner.
    _win = None
    for _ranked in table.values():
        if _ranked:
            _win = _ranked[0][0]
            break
    probe_kw = settings.get(_win, next(iter(settings.values())))
    probe_cfg = replace(cfg, ambiguity_mode="worst", **probe_kw)
    _, _, _, _, probe_diag = run(prices, signals, probe_cfg)

    if not any(table.values()):
        verdict = (f"NO SETTING TRADED at least {min_trades} time(s) -- nothing to "
                   f"compare. Lower the threshold or widen the window.")
    elif undifferentiated:
        verdict = ("SETTINGS DID NOT DIFFERENTIATE -- every setting scored the "
                   "same, so this measures a binding constraint, not the "
                   "parameter. Check drops_by_reason before rerunning.")
    elif winner_tied:
        verdict = (f"WINNER IS TIED -- top {n_tied_at_top} setting(s) scored "
                   f"identically; the reported order is dict order, not a result")
    elif stable and order_stable:
        verdict = "ROBUST"
    elif stable:
        verdict = "WINNER STABLE, ORDER NOT"
    else:
        verdict = "NOT ROBUST"

    return {
        "metric": metric,
        "slippage_grid": list(slippage_grid),
        "ranking_by_slippage": {s: orders[s] for s in orders},
        "scores_by_slippage": {s: dict(table[s]) for s in table},
        "winner_by_slippage": winners,
        "winner_stable": stable,
        "full_order_stable": order_stable,
        "settings_differentiated": not undifferentiated,
        "winner_margin_by_slippage": margins,
        "winner_tied": winner_tied,
        "n_tied_at_top": n_tied_at_top,
        "low_trade_settings": low_trade,
        "min_confidence_trades": min_confidence_trades,
        "trade_counts": trade_counts,
        # --- PATCH K --- the same counts, per cost level. The key
        # above is the LAST level only; this one is comparable to
        # scores_by_slippage.
        "trade_counts_by_slippage": trade_counts_by_slip,
        "excluded_insufficient_trades": excluded,
        "probed_setting": _win,
        "drops_by_reason_sample": probe_diag["drops_by_reason"],
        "held_ticker_time_frac_sample": probe_diag["held_ticker_time_frac"],
        "avg_positions_held_sample": probe_diag["avg_positions_held"],
        "verdict": verdict,
        "note": ("If the verdict is not ROBUST, the parameter choice is not "
                 "supported by the data. Report the instability; do not pick "
                 "the slippage level that gives the answer you prefer."),
    }


def survivorship_adjustment(trades: list, *,
                            delist_rate_per_year: float,
                            delist_return: float = -0.55,
                            stop_catches_frac: float,
                            avg_notional_pct_equity: float = 0.125) -> dict:
    """Size the survivorship hole. DOES NOT alter the equity curve -- it returns a
    separate figure you REPORT alongside results, because a silent haircut would
    make the backtest unfalsifiable.

    Anchors (verifiable, not invented):
      * Shumway & Warther (1999, J.Finance): a corrected return of -55% for missing
        performance-related delisting returns corrects the Nasdaq bias.
      * Same paper: ~1.2%/yr of NYSE/AMEX and ~5.6%/yr of Nasdaq stocks delist for
        poor performance.

    `stop_catches_frac` is YOURS to choose and is the dominant assumption: a
    -1R stop caps most bankruptcy declines long before -55%, so only the
    gap-to-zero tail (halt, fraud) escapes. There is no published number for a
    trend-template-filtered population; state whatever you use.

    Also note the base rate is for the WHOLE universe. A Minervini trend template
    (rising 200dma, RS>=70, within 25% of the 52w high) rarely selects a company
    heading into a performance delisting, so the true rate for SELECTED names is
    lower -- this estimate is an upper bound, deliberately.
    """
    n = len(trades)
    if n == 0:
        return {"note": "no trades -- nothing to adjust"}
    days = [(t.exit_date - t.entry_date).days for t in trades]
    avg_hold_years = (sum(days) / n) / 365.25
    p_event = delist_rate_per_year * avg_hold_years          # per position held
    escapes = 1.0 - stop_catches_frac
    # loss when the stop does NOT catch it, as a fraction of equity
    loss_per_escape = abs(delist_return) * avg_notional_pct_equity
    drag_per_trade = p_event * escapes * loss_per_escape
    return {
        "avg_hold_years": round(avg_hold_years, 3),
        "p_delist_per_position": round(p_event, 5),
        "expected_drag_per_trade_pct_equity": round(drag_per_trade * 100, 4),
        "expected_drag_over_run_pct_equity": round(drag_per_trade * n * 100, 2),
        "assumptions": {
            "delist_rate_per_year": delist_rate_per_year,
            "delist_return": delist_return,
            "stop_catches_frac": stop_catches_frac,
            "avg_notional_pct_equity": avg_notional_pct_equity,
        },
        "WARNING": ("ORDER OF MAGNITUDE ONLY. stop_catches_frac is an unmeasured "
                    "assumption and dominates the result. Report this figure "
                    "BESIDE the equity curve, never subtracted from it."),
    }


def compare_settings(runs: Dict[str, dict], metric: str = "expectancy_R",
                     higher_is_better: bool = True,
                     min_trades: int = 1) -> List[Tuple[str, float]]:
    """Rank parameter settings on the WORST bound of each one's band.

    `runs` maps a label ("threshold_70", "threshold_80", ...) to a `run_band()`
    result. Ordering ignores the optimistic bound entirely: two settings whose
    bands overlap are separated by their worst case, so a setting never wins on
    the strength of its best-case path."""
    scored = []
    for label, r in runs.items():
        # A setting that never traded scores expectancy_R = 0.0, which would rank
        # ABOVE a genuinely losing setting and could win the sweep on the strength
        # of having done nothing. Not a result -- excluded and reported instead.
        if r["conservative"].get("num_trades", 0) < min_trades:
            continue
        v = r["conservative"].get(metric)
        if not isinstance(v, (int, float)):
            raise ValueError(f"{label}: metric {metric!r} is {v!r}, not numeric")
        scored.append((label, float(v)))
    return sorted(scored, key=lambda kv: kv[1], reverse=higher_is_better)
