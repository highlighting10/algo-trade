#!/usr/bin/env python3
"""
P3.2 — point-in-time fundamentals: the record, and the capture.
================================================================

Two halves, and the second one is why this suite exists.

The PURE half (`kistrader/entry/point_in_time.py`) is the draft module recovered
from `minervini_fixes_complete_first_draft.zip`, plus UNKNOWN handling and a
series query. It carries its own 20-check self-test; this suite runs it.

The CAPTURE half is `DataProxy`'s fundamentals cache, and it had a live bug:

    def _fund_cache_load(self, ticker):
        if (time.time() - os.path.getmtime(path)) / 86400.0 > FUND_CACHE_MAX_AGE_DAYS:

**The staleness guard read filesystem mtime, and the payload carried no date at
all.** `cp -r`, `scp`, `rsync` without `-p`/`-t`, and an unpacked deploy all reset
mtime FORWARD, so a six-month-old fundamental looked fresh and was served. The
guard failed OPEN on a routine file copy, and `.gitignore` covers
`fundamentals_cache/`, so those are exactly the paths it travels by.

`test_stale_record_survives_an_mtime_reset` FAILS on the pre-AG code. That is the
point of it.

Run:  python tests/test_point_in_time.py
      python -m pytest -q tests/test_point_in_time.py
"""
from __future__ import annotations

import datetime as _dt
import json
import os
import sys
import tempfile
import time

_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.dirname(_HERE)
for _p in (_ROOT, _HERE):
    if _p not in sys.path:
        sys.path.insert(0, _p)

# Reuse the harness's stub machinery rather than duplicating it -- the screeners
# import yfinance and google.genai at module scope, and there is one correct way
# to stub that, already written and already maintained.
from test_screener_harness import _import_screeners            # noqa: E402

FAIL: list = []
_N = [0]


def check(name, cond, detail=""):
    _N[0] += 1
    print(f"  [{'PASS' if cond else 'FAIL'}] {name}   {detail}")
    if not cond:
        FAIL.append(name)


def _fund(eps=(1.2, 1.1, 1.0, 0.9)):
    return {"eps": list(eps), "revenue": [], "eps_surprises": [], "source": "finnhub"}


def _run_for(mod, label, tmp):
    """Every capture check, run against ONE screener. Both must behave the same."""
    cwd = os.getcwd()
    os.chdir(tmp)
    try:
        proxy = mod.DataProxy()
        cache = mod.FUND_CACHE_DIR
        max_age = mod.FUND_CACHE_MAX_AGE_DAYS

        # -- the record carries its own date ------------------------------
        proxy._fund_cache_save("AAA", _fund())
        path = os.path.join(cache, "AAA.json")
        doc = json.load(open(path, encoding="utf-8"))
        check(f"[{label}] the saved record carries as_of", "as_of" in doc,
              str(doc.get("as_of")))
        check(f"[{label}] ...and fetched_at", "fetched_at" in doc)
        check(f"[{label}] ...and a schema version", "schema" in doc)
        today = _dt.datetime.now(_dt.timezone.utc).date().isoformat()
        check(f"[{label}] as_of is today (UTC)", doc.get("as_of") == today,
              f"{doc.get('as_of')} vs {today}")
        check(f"[{label}] a fresh record loads", proxy._fund_cache_load("AAA") is not None)

        # --- PATCH AJ (daily archive) --- the boundary, which is the whole bug.
        # A record dated exactly FUND_CACHE_MAX_AGE_DAYS ago must MISS, or the
        # screener never refetches and never writes an archive row for today.
        edge = _fund()
        proxy._fund_cache_save("EDGE", edge)
        pe = os.path.join(cache, "EDGE.json")
        de = json.load(open(pe, encoding="utf-8"))
        de["as_of"] = (_dt.date.fromisoformat(today)
                       - _dt.timedelta(days=int(max_age))).isoformat()
        with open(pe, "w", encoding="utf-8") as fh:
            json.dump(de, fh)
        check(f"[{label}] a record exactly max_age days old MISSES",
              proxy._fund_cache_load("EDGE") is None,
              f"as_of={de['as_of']}, max_age={max_age}d")
        # --- end PATCH AJ (daily archive) ---

        # -- THE BUG: mtime reset must not resurrect a stale record --------
        stale = _fund()
        proxy._fund_cache_save("BBB", stale)
        p2 = os.path.join(cache, "BBB.json")
        d2 = json.load(open(p2, encoding="utf-8"))
        old = (_dt.date.fromisoformat(today)
               - _dt.timedelta(days=int(max_age) + 30)).isoformat()
        d2["as_of"] = old
        with open(p2, "w", encoding="utf-8") as fh:
            json.dump(d2, fh)
        os.utime(p2, (time.time(), time.time()))          # what cp/scp/rsync do
        check(f"[{label}] a stale record survives an mtime reset",
              proxy._fund_cache_load("BBB") is None,
              f"as_of={old}, mtime=now, max_age={max_age}d")

        # -- legacy records still work, and say so once --------------------
        legacy = os.path.join(cache, "CCC.json")
        with open(legacy, "w", encoding="utf-8") as fh:
            json.dump(_fund(), fh)                        # no as_of at all
        check(f"[{label}] a legacy record without as_of still loads",
              proxy._fund_cache_load("CCC") is not None)

        # -- the archive ---------------------------------------------------
        arch = os.path.join("fundamentals_archive", today[:7])
        want = os.path.join(arch, f"AAA-{today}.json")
        check(f"[{label}] the day's snapshot is archived", os.path.isfile(want), want)
        before = open(want, "rb").read()
        proxy._fund_cache_save("AAA", _fund((9.9, 9.8)))  # same day, new values
        check(f"[{label}] a same-day re-save does NOT rewrite history",
              open(want, "rb").read() == before)
        n_files = len([f for f in os.listdir(arch) if f.startswith("AAA-")])
        check(f"[{label}] ...and creates no second file for the same day",
              n_files == 1, f"{n_files} file(s)")

        # -- the archive is a RECORD, never an INPUT ------------------------
        import shutil
        shutil.rmtree("fundamentals_archive")
        check(f"[{label}] deleting the whole archive does not break the live read",
              proxy._fund_cache_load("AAA") is not None)
    finally:
        os.chdir(cwd)


def main() -> int:
    print("=" * 64)
    print("P3.2 — POINT-IN-TIME: THE RECORD, AND THE CAPTURE")
    print("=" * 64)

    print("A  the pure module (recovered draft + UNKNOWN handling + series)")
    from kistrader.entry import point_in_time as pit
    check("point_in_time self-test passes", pit._self_test() == 0)
    check("UNKNOWN availability is invisible",
          not pit.available_as_of(
              pit.FundamentalObservation(_dt.date(2026, 1, 1), None, 1.0),
              _dt.date(2099, 1, 1)))

    print("B  the capture — run identically against BOTH screeners")
    sp, us, err = _import_screeners()
    if err is not None:
        check("both screeners import", False, str(err)[:70])
    else:
        check("both screeners import", True)
        for mod, label in ((sp, "sp500"), (us, "us_small")):
            _run_for(mod, label, tempfile.mkdtemp())

    print("=" * 64)
    print(f"PASSED {_N[0] - len(FAIL)} / {_N[0]}")
    print("=" * 64)
    return 1 if FAIL else 0


def test_zz_all_checks_passed():
    """Terminal guard. check() never raises, so without this pytest would report
    this file as passed no matter how many checks failed."""
    main()
    assert not FAIL, f"{len(FAIL)} failed check(s): " + "; ".join(FAIL)


if __name__ == "__main__":
    raise SystemExit(main())
