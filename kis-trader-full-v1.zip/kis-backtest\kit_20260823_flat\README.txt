KIT 2026-08-23  --  sector_cap finding + production suggestions
==============================================================

Four files. Two are documents, two are runnable.


WHAT IS IN HERE
---------------

FREEZE_REV3_CORRECTIONS_v2_20260823.md
    Supersedes FREEZE_REV3_CORRECTIONS_20260822.md (does not edit it).
    F8 closed; the two pinned divergences; the fill-rule contradiction;
    the expectancy_R labelling finding; sec.6 the boot guard's real
    coverage; sec.6.1 the sector_cap divergence.

PRODUCTION_SUGGESTIONS_20260823.md
    Answers "does any of F8 / the rank work apply to production?"
    Headline: engine_v2 came out of F8 with ZERO defects, so nothing
    here is a bug fix -- except item 1.

sector_cap_probe.py
    Reproduces the sector_cap measurement on your own tree.
    Touches nothing; imports the production package read-only.

patch_3_harness_side_note.py
    OPTIONAL. Corrects a stale claim in f8/harness_side.py's docstring.
    Docstring only -- no executable line, so F8 must stay 98/98.


HOW TO RUN THEM
---------------

1) the probe  (put it anywhere; the repo root is an argument)

    cd C:\Users\user\PyCharmMiscProject\kis-backtest
    python sector_cap_probe.py --prod-root C:\Users\user\kis-trader-clean
    "exit = $LASTEXITCODE"

   EXPECT exit 0:
     [A] sector_of=None      -> plans AAA BBB CCC DDD, all sectors ''
     [B] sector_of supplied  -> plans AAA BBB + 2 sector-cap rejections
     [C] 'sector' occurs anywhere in cli.py: False

   Exit 1 means the probe stopped discriminating -- either the wiring
   changed or the fixture is being rejected upstream. It says which.
   Both failure modes were tested before shipping.

2) the docstring patch  (from the f8 directory, optional)

    cd C:\Users\user\PyCharmMiscProject\kis-backtest\f8
    python patch_3_harness_side_note.py --file harness_side.py
    python run_f8.py --prod-root C:\Users\user\kis-trader-clean --harness ..\minervini_backtest.py

   EXPECT still 98/98. Then:  git add f8\harness_side.py  and commit.
   Revert:  python patch_3_harness_side_note.py --file harness_side.py --revert
   (reverts byte-identically; tested)


THE ONE FINDING, IN THREE LINES
-------------------------------

sector_cap = 2 is a dataclass default that no data session ever set, and
it is not one of the frozen 15.

The BACKTEST enforces it -- 06_sweep.py hard-loads data/sectors.csv and
BacktestConfig refuses to construct without a map.

PRODUCTION does not -- cli.py never passes sector_of, so plan.sector is ''
for every candidate and the cap's own guard is False. The live trader can
put all eight slots in one sector; Rev 3's run stopped at two.

The harness's own guard text and BE_CAREFUL sec.1.5 both state this
backwards ("more permissive than production"). Production is the
permissive side.

CHEAPEST NEXT MOVE, and it touches no code: count "sector cap 2 reached"
in a Rev 3 sweep's drop ledger. Footnote, or a real divergence. ~20 min.
That is a data decision, not a code one.


ALL FILES ARE ASCII-ONLY
------------------------
No BOM, LF endings, safe on a cp949 console. The probe additionally
ASCII-folds production's rejection strings before printing them, because
those contain an em-dash that a cp949 console cannot encode -- an
encoding traceback must never stand in for a diagnosis.
