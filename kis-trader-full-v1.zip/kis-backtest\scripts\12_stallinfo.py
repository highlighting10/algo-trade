"""
12_stallinfo.py -- CAN an adaptive stall work? Test before building.

The fixed stall (exit at day N if R < floor) reversed across the split sample:
cutting fast won the choppy half, letting run won the trending half. That is
regime dependence, so a rule keyed to the STOCK'S OWN BEHAVIOUR rather than the
calendar could in principle capture both.

But an adaptive rule can only work if, AT THE DECISION POINT, something
observable separates trades that go on to make 3R from trades that die. This
measures exactly that -- it does not build the rule, it tests whether the
information the rule would need actually exists.

Method, uncensored:
  * take every entry the strategy made
  * exclude entries whose stop would have fired before the decision day (those
    never reach the stall decision, so including them would be a counterfactual)
  * record candidate observables at the decision day
  * record the forward outcome: max R over the NEXT `horizon` sessions
  * report the forward outcome split by each observable

If forward outcome is flat across every observable, the day-10 decision is
uninformative and an adaptive stall cannot beat a coin toss. If one observable
separates them, that is what to key the rule on.

Usage:
    python scripts/12_stallinfo.py --threshold 70 --signals data/signals_daily.pkl
    python scripts/12_stallinfo.py --decision-day 10 --horizon 40
"""
import pathlib as _pl
import sys as _sys
_sys.path.insert(0, str(_pl.Path(__file__).resolve().parent.parent))

import argparse
import pathlib
import pickle

import numpy as np
import pandas as pd

from minervini_backtest import (BacktestConfig, DecisionConfig, load_sector_map,
                                run)


def split_report(name, values, outcome, cuts):
    """Report forward outcome bucketed by an observable."""
    v = np.asarray(values, float)
    o = np.asarray(outcome, float)
    ok = ~(np.isnan(v) | np.isnan(o))
    v, o = v[ok], o[ok]
    if len(v) < 20:
        print(f"  {name:<26} (only {len(v)} usable trades -- skipped)")
        return None
    print(f"  {name}")
    edges = [-np.inf] + list(cuts) + [np.inf]
    spread = []
    for lo, hi in zip(edges, edges[1:]):
        m = (v > lo) & (v <= hi)
        if m.sum() < 10:
            continue
        lab = (f"<= {hi:g}" if lo == -np.inf else
               f"> {lo:g}" if hi == np.inf else f"{lo:g}..{hi:g}")
        mean_fwd = o[m].mean()
        pct3 = 100 * np.mean(o[m] >= 3.0)
        spread.append(mean_fwd)
        print(f"    {lab:>12}  n={m.sum():>4}  mean fwd MFE {mean_fwd:>6.2f} R"
              f"   reach 3R {pct3:>5.1f}%")
    if len(spread) > 1:
        rng = max(spread) - min(spread)
        print(f"    -> spread across buckets: {rng:.2f} R"
              + ("   <-- INFORMATIVE" if rng >= 0.5 else "   (flat: no signal)"))
        return rng
    return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--threshold", type=float, default=70.0)
    ap.add_argument("--slippage", type=float, default=5.0)
    ap.add_argument("--signals", default="data/signals.pkl")
    ap.add_argument("--decision-day", type=int, default=10)
    ap.add_argument("--horizon", type=int, default=40)
    ap.add_argument("--start", default=None)
    ap.add_argument("--end", default=None)
    args = ap.parse_args()

    bars = {}
    for p in pathlib.Path("data/bars").glob("*.parquet"):
        df = pd.read_parquet(p)
        if getattr(df.index, "tz", None) is not None:
            df.index = df.index.tz_localize(None)
        bars[p.stem] = df.sort_index()
    prices = {t: d for t, d in bars.items() if t != "^GSPC"}
    bench = bars.get("^GSPC")

    with open(args.signals, "rb") as f:
        signals = pickle.load(f)["signals"]
    if args.start or args.end:
        lo = pd.Timestamp(args.start) if args.start else pd.Timestamp.min
        hi = pd.Timestamp(args.end) if args.end else pd.Timestamp.max
        signals = {d: v for d, v in signals.items() if lo <= pd.Timestamp(d) <= hi}

    cfg = BacktestConfig(rank_mode="rs_only", equity_mode="compounding",
                         entry_mode="pivot_limit", ambiguity_mode="worst",
                         vcp_threshold=args.threshold, slippage_bps=args.slippage,
                         sector_map=load_sector_map("data/sectors.csv"),
                         decision=DecisionConfig())
    eq, trades, st, dr, dg = run(prices, signals, cfg)
    if not trades:
        raise SystemExit("[stallinfo] no trades")

    D = args.decision_day
    feat = {k: [] for k in ("r_at_D", "mfe_to_D", "mae_to_D", "vs_ema21",
                            "vs_bench", "vol_ratio")}
    fwd = []
    stopped_early = reached = 0

    for t in trades:
        df = prices.get(t.ticker)
        rps = t.risk_per_share
        if df is None or rps <= 0:
            continue
        after = df.loc[df.index > t.entry_date]
        if len(after) < D + 5:
            continue
        head = after.iloc[:D]
        stop_px = t.entry_price - rps
        if float(head["Low"].min()) <= stop_px:
            stopped_early += 1          # never reaches the stall decision
            continue
        reached += 1

        close_D = float(head["Close"].iloc[-1])
        feat["r_at_D"].append((close_D - t.entry_price) / rps)
        feat["mfe_to_D"].append((float(head["High"].max()) - t.entry_price) / rps)
        feat["mae_to_D"].append((float(head["Low"].min()) - t.entry_price) / rps)

        hist = df.loc[df.index <= after.index[D - 1], "Close"]
        ema = hist.ewm(span=21, adjust=False, min_periods=21).mean()
        feat["vs_ema21"].append((close_D / float(ema.iloc[-1]) - 1) * 100
                                if len(ema.dropna()) else np.nan)

        if bench is not None:
            b = bench["Close"]
            b0 = b.loc[b.index <= t.entry_date]
            b1 = b.loc[b.index <= after.index[D - 1]]
            if len(b0) and len(b1):
                br = float(b1.iloc[-1] / b0.iloc[-1] - 1) * 100
                sr = (close_D / t.entry_price - 1) * 100
                feat["vs_bench"].append(sr - br)
            else:
                feat["vs_bench"].append(np.nan)
        else:
            feat["vs_bench"].append(np.nan)

        if "Volume" in df.columns:
            v_recent = float(head["Volume"].mean())
            v_base = float(df.loc[df.index <= t.entry_date, "Volume"].tail(50).mean())
            feat["vol_ratio"].append(v_recent / v_base if v_base > 0 else np.nan)
        else:
            feat["vol_ratio"].append(np.nan)

        tail = after.iloc[D:D + args.horizon]
        fwd.append((float(tail["High"].max()) - t.entry_price) / rps
                   if len(tail) else np.nan)

    print("=" * 74)
    print(f"STALL DECISION INFORMATION  day {D}, forward horizon {args.horizon}")
    print("=" * 74)
    print(f"  entries taken            : {len(trades)}")
    print(f"  stopped before day {D:<5} : {stopped_early}  (never face the decision)")
    print(f"  reach the decision point : {reached}")
    f = np.asarray(fwd, float)
    f = f[~np.isnan(f)]
    if len(f):
        print(f"  forward MFE from day {D}   : mean {f.mean():.2f} R, "
              f"median {np.median(f):.2f} R, reach 3R {100*np.mean(f>=3):.1f}%")
    print()
    print("  DOES ANYTHING AT THE DECISION POINT PREDICT THE FUTURE?")
    print()
    spreads = {}
    spreads["r_at_D"] = split_report(
        f"R at day {D}  (this is what the CURRENT rule uses)",
        feat["r_at_D"], fwd, (0.0, 0.5, 1.0, 2.0))
    spreads["mfe_to_D"] = split_report(
        f"best R seen by day {D}", feat["mfe_to_D"], fwd, (0.5, 1.0, 2.0))
    spreads["mae_to_D"] = split_report(
        f"worst R seen by day {D}", feat["mae_to_D"], fwd, (-0.75, -0.5, -0.25))
    spreads["vs_ema21"] = split_report(
        "close vs 21-EMA (%)", feat["vs_ema21"], fwd, (-2, 0, 5))
    spreads["vs_bench"] = split_report(
        "excess return vs ^GSPC (%)", feat["vs_bench"], fwd, (-2, 0, 3))
    spreads["vol_ratio"] = split_report(
        "volume vs 50d base", feat["vol_ratio"], fwd, (0.7, 1.0, 1.5))

    print()
    print("=" * 74)
    print("  VERDICT")
    print("=" * 74)
    live = {k: v for k, v in spreads.items() if v is not None}
    if not live:
        print("  Not enough data to judge.")
    else:
        best = max(live, key=live.get)
        if live[best] < 0.5:
            print("  NOTHING observable at the decision point separates future")
            print("  winners from losers -- every bucket has the same forward MFE.")
            print("  An adaptive stall cannot beat a fixed one, because the")
            print("  information it would key on does not exist. Do not build it.")
        else:
            print(f"  '{best}' separates outcomes by {live[best]:.2f} R across buckets.")
            print("  An adaptive stall keyed on this has something real to work with.")
            print("  Next: encode it as the stall condition and split-sample it --")
            print("  the same test that killed every fixed parameter.")
        print()
        print("  Ranked by informativeness:")
        for k in sorted(live, key=live.get, reverse=True):
            print(f"    {k:<12} {live[k]:.2f} R")


if __name__ == "__main__":
    main()
