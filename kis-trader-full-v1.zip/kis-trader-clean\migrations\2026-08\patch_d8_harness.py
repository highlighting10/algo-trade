#!/usr/bin/env python3
"""
patch_d8_harness.py -- D8: make `python -m pytest -q` capable of FAILING.

THE PROBLEM (measured 2026-08-12): check() appends to a FAIL list and prints; it
never raises. pytest marks a test function passed if it returns without an
exception, so a function in which every check failed still reports PASSED.
Proven by inverting the sort in DecisionEngine.plan() -- pytest's output was
byte-identical on the correct and the inverted tree (36 passed both times),
while the direct run correctly reported 113/115 and exited 1.

THE FIX (test harness only -- zero production files touched):
  B. one terminal guard per check()-based suite:  assert not FAIL
     Defined LAST so pytest runs it after every other test in the file. This
     preserves the "run every check, report all failures" property that makes
     these suites useful -- unlike making check() raise, which would abort the
     rest of the function at the first failure.
  D. test_handoff_to_monitor(filled_pos) took a positional arg, which pytest
     read as a fixture request -> permanent collection ERROR -> pytest exited 1
     on a CLEAN tree too. Now defaults to the Position captured by
     test_happy_full_fill, which also stops returning non-None (pytest warns
     about that today and future versions make it an error).
  test_seed_position.py has NO module-level test_ functions at all, so pytest
     collected nothing from it -- 23 checks that never ran. One wrapper fixes it.

Anchors are asserted; edits are applied bottom-up within each file.

Usage:  python patch_d8_harness.py <repo-root>
"""
from __future__ import annotations

import os
import sys

GUARD_ENTRY = '''def test_zz_all_checks_passed():
    """D8 terminal guard. check() never raises, so without this pytest reports
    every function in this file as passed no matter how many checks failed.
    Defined last on purpose: pytest runs file order, so this sees the whole run.
    Harmless under the direct `python tests/...` run, which main() drives."""
    assert not FAIL, f"{len(FAIL)} failed check(s): " + "; ".join(FAIL)


'''

SEED_ENTRY = '''def test_seed_and_close_suite():
    """D8: this file defines no module-level test_ functions, so pytest used to
    collect NOTHING from it and all 23 checks silently never ran. main() drives
    the whole suite and returns 1 on any failure."""
    assert main() == 0, f"{len(FAIL)} failed check(s): " + "; ".join(FAIL)


'''


def edit(text, old, new, label):
    n = text.count(old)
    if n != 1:
        raise SystemExit(f"REFUSING: anchor for {label} matched {n} times, expected 1")
    print(f"  ok  {label}")
    return text.replace(old, new)


def read(p):
    with open(p, encoding="utf-8") as f:
        return f.read()


def write(p, s):
    with open(p, "w", encoding="utf-8", newline="") as f:
        f.write(s)


def main(root):
    th = os.path.join(root, "tests", "test_entry_half.py")
    e2e = os.path.join(root, "tests", "test_pipeline_e2e.py")
    sp = os.path.join(root, "tests", "test_seed_position.py")
    for p in (th, e2e, sp):
        if not os.path.isfile(p):
            raise SystemExit(f"REFUSING: not found: {p}")

    s_th, s_e2e, s_sp = read(th), read(e2e), read(sp)
    if any("test_zz_all_checks_passed" in s for s in (s_th, s_e2e)) \
            or "test_seed_and_close_suite" in s_sp:
        raise SystemExit("REFUSING: D8 appears to be applied already.")

    # ---------------- test_entry_half.py (bottom-up) ----------------
    print(f"test_entry_half.py  ({th})")
    s_th = edit(s_th,
                "    test_handoff_to_monitor(filled_pos)\n",
                "    test_handoff_to_monitor()\n",
                "main(): call handoff with no arg")
    s_th = edit(s_th,
                "    filled_pos = test_happy_full_fill()\n",
                "    test_happy_full_fill()\n",
                "main(): stop capturing the return value")
    s_th = edit(s_th,
                "def main():\n",
                GUARD_ENTRY + "def main():\n",
                "insert test_zz_all_checks_passed()")
    s_th = edit(s_th,
                "    p = filled_pos\n",
                "    p = _LAST_FILLED if filled_pos is None else filled_pos\n"
                "    assert p is not None, (\"no FILLED position captured -- \"\n"
                "                           \"test_happy_full_fill must run first\")\n",
                "handoff: fall back to the captured position")
    s_th = edit(s_th,
                "def test_handoff_to_monitor(filled_pos):\n",
                "def test_handoff_to_monitor(filled_pos=None):\n",
                "handoff: make the argument optional (pytest read it as a fixture)")
    s_th = edit(s_th,
                "    return p  # for handoff test\n",
                "    global _LAST_FILLED\n"
                "    _LAST_FILLED = p          # handed to test_handoff_to_monitor;\n"
                "                              # NOT returned -- pytest warns on non-None\n"
                "                              # returns and will make that an error.\n",
                "happy path: publish via module global instead of returning")
    s_th = edit(s_th,
                "PASS, FAIL = [], []\n",
                "PASS, FAIL = [], []\n"
                "_LAST_FILLED = None      # D8: set by test_happy_full_fill, read by\n"
                "                         # test_handoff_to_monitor under pytest.\n",
                "declare _LAST_FILLED")

    # ---------------- test_pipeline_e2e.py ----------------
    print(f"test_pipeline_e2e.py  ({e2e})")
    s_e2e = edit(s_e2e,
                 "def main():\n",
                 GUARD_ENTRY + "def main():\n",
                 "insert test_zz_all_checks_passed()")

    # ---------------- test_seed_position.py ----------------
    print(f"test_seed_position.py  ({sp})")
    s_sp = edit(s_sp,
                'if __name__ == "__main__":\n',
                SEED_ENTRY + 'if __name__ == "__main__":\n',
                "insert test_seed_and_close_suite()")

    write(th, s_th)
    write(e2e, s_e2e)
    write(sp, s_sp)
    print("\nD8 APPLIED. `pytest -q` should now be 0 on a clean tree and non-zero on a broken one.")
    return 0


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("usage: python patch_d8_harness.py <repo-root>")
    sys.exit(main(sys.argv[1]))
