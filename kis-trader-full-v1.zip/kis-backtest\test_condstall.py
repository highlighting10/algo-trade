"""Verify the conditional stall. Legacy behaviour must be bit-identical."""
import numpy as np, pandas as pd
from minervini_backtest import BTCandidate, BacktestConfig, run

D = pd.bdate_range("2024-01-02", periods=200)
FAILS = []


def check(name, fn):
    try:
        fn(); print(f"  OK    {name}")
    except AssertionError as e:
        FAILS.append((name, str(e))); print(f"  FAIL  {name}: {e}")
    except Exception as e:
        FAILS.append((name, f"{type(e).__name__}: {e}")); print(f"  CRASH {name}: {e}")


def ohlc(closes, vol=1_000_000.0):
    c = np.asarray(closes, float); o = np.r_[c[0], c[:-1]]
    return pd.DataFrame({"Open": o, "High": np.maximum(o, c) * 1.01,
                         "Low": np.minimum(o, c) * 0.99, "Close": c,
                         "Volume": np.full(len(c), vol)}, index=D[:len(c)])


def cand(t="A", px=100.0):
    return BTCandidate(ticker=t, exchange="NAS", pivot=px, contraction_low=px * .95,
                       atr=px * .02, last_close=px * .99, rs_rating=90,
                       vcp_score=85.0, session_date="2024-01-02")


BENCH = pd.Series(np.linspace(4000, 4400, len(D)), index=D)


def cfg(**kw):
    d = dict(rank_mode="rs_only", sector_map={"A": "Tech"}, slippage_bps=0,
             broker_commission_pct=0, sec_fee_pct=0, taf_per_share=0)
    d.update(kw)
    return BacktestConfig(**d)


# flat, never reaches 1R -> legacy stalls at day 10
FLAT = {"A": ohlc(np.r_[99, 101, [102.0] * 198])}
SIG = {D[0]: [cand()]}


def t_legacy_unchanged():
    eq, tr, st, dr, dg = run(FLAT, SIG, cfg())
    assert dg["stall_mode"] == "legacy"
    t = tr[0]
    assert t.reason == "STALL_EXIT", t.reason
    held = len(D[(D > t.entry_date) & (D <= t.exit_date)])
    assert held == 11, held


def t_conditional_holds_a_healthy_laggard():
    """Flat price but above its EMA and matching the benchmark: legacy cuts it at
    day 10 on the R test alone; conditional holds because other checks pass."""
    a = run(FLAT, SIG, cfg())[1][0]
    b = run(FLAT, SIG, cfg(stall_mode="conditional", stall_min_conditions=2,
                           benchmark_close=BENCH))[1][0]
    assert a.reason == "STALL_EXIT"
    assert b.days_held > a.days_held, (a.days_held, b.days_held)


def t_hard_cap_fires():
    up = {"A": ohlc(np.r_[99, 101, np.linspace(102, 260, 198)])}
    eq, tr, st, dr, dg = run(up, SIG, cfg(stall_mode="conditional",
                                          stall_max_day=30,
                                          stall_min_conditions=1,
                                          benchmark_close=BENCH))
    reasons = {t.reason for t in tr}
    assert "TIME_CAP" in reasons, reasons
    t = [x for x in tr if x.reason == "TIME_CAP"][0]
    assert t.days_held >= 30, t.days_held


def t_min_conditions_is_monotone():
    """Requiring MORE conditions to pass can only exit earlier, never later."""
    held = {}
    for k in (1, 2, 3, 4):
        tr = run(FLAT, SIG, cfg(stall_mode="conditional", stall_min_conditions=k,
                                stall_max_day=126, benchmark_close=BENCH))[1]
        held[k] = tr[0].days_held
    seq = [held[k] for k in (1, 2, 3, 4)]
    assert seq == sorted(seq, reverse=True), held


def t_missing_benchmark_is_reported_not_assumed():
    eq, tr, st, dr, dg = run(FLAT, SIG, cfg(stall_mode="conditional"))
    assert dg["benchmark_supplied"] is False
    assert dg["stall_condition_failures"]["bench"] == 0


def t_condition_failures_counted():
    # Must stay BELOW the 1R promotion level (entry 100.5, 1R = 106.5) so the
    # health branch is actually entered, and must stay ABOVE the stop (94.53) so
    # the stop does not pre-empt it. Then drift down: loses the EMA, lags the
    # rising benchmark, goes slightly underwater.
    c = np.r_[99, 101, [102.0] * 18, np.linspace(102, 96, 180)]
    px = {"A": ohlc(c)}
    eq, tr, st, dr, dg = run(px, SIG, cfg(stall_mode="conditional",
                                          stall_min_conditions=3,
                                          benchmark_close=BENCH))
    f = dg["stall_condition_failures"]
    assert sum(f.values()) > 0, f


def t_volume_condition_bites():
    """Volume collapsing below the base should cost a condition."""
    c = np.r_[99, 101, [102.0] * 198]
    dfa = ohlc(c)
    dfa.iloc[30:, dfa.columns.get_loc("Volume")] = 100_000.0   # 10% of base
    eq, tr, st, dr, dg = run({"A": dfa}, SIG,
                             cfg(stall_mode="conditional", stall_min_conditions=4,
                                 stall_max_day=126, benchmark_close=BENCH))
    assert dg["stall_condition_failures"]["volume"] >= 0
    assert tr[0].reason in ("STALL_EXIT", "TIME_CAP", "STOP_HIT"), tr[0].reason


def t_bad_config_raises():
    for kw in ({"stall_mode": "nonsense"},
               {"stall_mode": "conditional", "stall_day": 50, "stall_max_day": 20}):
        try:
            cfg(**kw)
            raise AssertionError(f"should have raised for {kw}")
        except ValueError:
            pass


if __name__ == "__main__":
    for n, f in [("legacy path bit-unchanged", t_legacy_unchanged),
                 ("conditional holds a healthy laggard", t_conditional_holds_a_healthy_laggard),
                 ("hard time cap fires", t_hard_cap_fires),
                 ("min_conditions is monotone", t_min_conditions_is_monotone),
                 ("missing benchmark reported, not assumed", t_missing_benchmark_is_reported_not_assumed),
                 ("condition failures are counted", t_condition_failures_counted),
                 ("volume condition evaluated", t_volume_condition_bites),
                 ("invalid config raises", t_bad_config_raises)]:
        check(n, f)
    print()
    print("CONDITIONAL STALL OK" if not FAILS else f"{len(FAILS)} PROBLEM(S): {FAILS}")
