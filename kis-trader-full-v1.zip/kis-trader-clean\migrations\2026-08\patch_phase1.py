#!/usr/bin/env python3
"""
patch_phase1.py -- PHASE 1 only: the vcp_weight ranking term + its test.

Refuses to touch anything unless EVERY anchor matches EXACTLY ONCE, and refuses
to run twice (it checks for its own output first). Edits are applied bottom-up
within each file, so no edit shifts a later one.

  kistrader/entry/decision_engine.py   +1 config field, +1 term in rank_score
  tests/test_entry_half.py             +test_rank_score(), registered in main()

Phase 1 is a NO-OP at runtime: vcp_weight defaults to 0.0, so rank_score returns
exactly what it returned before. Nothing about today's behaviour changes until
Phase 2 sets the weights.

Usage:  python patch_phase1.py <repo-root>
"""
from __future__ import annotations

import os
import sys

TEST_BLOCK = '''def test_rank_score():
    """3.1 ranking. This function had ZERO direct coverage in any suite, and it
    is where the bug that invalidated every backtest sweep lived: plan() re-sorts
    on rank_score, so a rank_mode the score cannot express has no effect at all.

    Every case sets the weights EXPLICITLY, so this test does not need editing
    when the production defaults change in Phase 2."""
    print("I8b rank_score: no-op default, both weightings, and they must DIFFER")

    acct = AccountState(equity=100_000, cash=100_000)
    UNCAPPED = dict(risk_per_trade_pct=0.01, sector_cap=0, max_position_pct=1.0,
                    max_portfolio_exposure_pct=10.0)

    # Three names whose RS, Stage-2 and VCP orderings all DISAGREE, so no two
    # weightings can coincide by accident and no ordering can fall through to
    # the ticker tiebreak unnoticed.
    #                  rs        s2         vcp      -> 2*RS+S2
    a = _cand("AAA", rs=80, s2=90.0, score=72.0)   # 250
    b = _cand("BBB", rs=95, s2=70.0, score=91.0)   # 260
    c = _cand("CCC", rs=88, s2=55.0, score=84.0)   # 231

    # (1) the new third term is a true no-op until someone sets it
    check("vcp_weight defaults to 0.0", DecisionConfig().vcp_weight == 0.0,
          f"{DecisionConfig().vcp_weight}")
    eng_default = DecisionEngine(DecisionConfig())
    old = lambda x: 2.0 * x.rs_rating + 1.0 * x.stage2_score
    check("default weights reproduce 2*RS + Stage2 exactly",
          all(abs(eng_default.rank_score(x) - old(x)) < 1e-12 for x in (a, b, c)))

    # (2) today's production weighting
    eng_rs = DecisionEngine(DecisionConfig(rs_weight=2.0, stage2_weight=1.0,
                                           vcp_weight=0.0, **UNCAPPED))
    order_rs = [p.ticker for p in eng_rs.plan([a, b, c], acct)[0]]
    check("(2,1,0) selects BBB > AAA > CCC", order_rs == ["BBB", "AAA", "CCC"],
          f"{order_rs}")

    # (3) the frozen target weighting (vcp_only)
    eng_vcp = DecisionEngine(DecisionConfig(rs_weight=0.0, stage2_weight=0.0,
                                            vcp_weight=1.0, **UNCAPPED))
    order_vcp = [p.ticker for p in eng_vcp.plan([a, b, c], acct)[0]]
    check("(0,0,1) selects BBB > CCC > AAA", order_vcp == ["BBB", "CCC", "AAA"],
          f"{order_vcp}")

    # (4) THE invariant that was silently false for the project's whole history:
    #     changing the ranking must actually change the selected order.
    check("the two weightings produce DIFFERENT orders", order_rs != order_vcp,
          f"{order_rs} vs {order_vcp}")

    # (5) each weighting ignores the other's inputs completely
    hi_rs = _cand("XRS", rs=99, s2=99.0, score=10.0)
    hi_vcp = _cand("XVC", rs=1, s2=1.0, score=99.0)
    o_v = [p.ticker for p in eng_vcp.plan([hi_rs, hi_vcp], acct)[0]]
    check("vcp_only ignores RS and Stage2 entirely", o_v == ["XVC", "XRS"], f"{o_v}")
    o_r = [p.ticker for p in eng_rs.plan([hi_rs, hi_vcp], acct)[0]]
    check("rs+stage2 ignores VCP entirely", o_r == ["XRS", "XVC"], f"{o_r}")

    # (6) an exact tie must still resolve deterministically, ticker ascending
    z = _cand("ZZZ", rs=50, s2=50.0, score=88.0)
    aa = _cand("AAA", rs=50, s2=50.0, score=88.0)
    o_t = [p.ticker for p in eng_vcp.plan([z, aa], acct)[0]]
    check("exact rank tie falls to ticker ascending", o_t == ["AAA", "ZZZ"], f"{o_t}")

    # (7) the plan carries the score the engine actually ranked on, so the event
    #     log cannot disagree with the selection
    plans, _ = eng_vcp.plan([a], acct)
    check("EntryPlan.rank_score reflects the configured weights",
          bool(plans) and abs(plans[0].rank_score - 72.0) < 1e-12,
          f"{plans[0].rank_score if plans else 'no plan produced'}")


'''


def edit(text, old, new, label):
    n = text.count(old)
    if n != 1:
        raise SystemExit(f"REFUSING: anchor for {label} matched {n} times, expected 1")
    print(f"  ok  {label}")
    return text.replace(old, new)


def read(p):
    with open(p, encoding="utf-8") as f:
        return f.read()


def write(p, s):
    with open(p, "w", encoding="utf-8", newline="") as f:
        f.write(s)


def main(root):
    de = os.path.join(root, "kistrader", "entry", "decision_engine.py")
    th = os.path.join(root, "tests", "test_entry_half.py")
    for p in (de, th):
        if not os.path.isfile(p):
            raise SystemExit(f"REFUSING: not found: {p}")

    src_de, src_th = read(de), read(th)
    if "vcp_weight" in src_de or "test_rank_score" in src_th:
        raise SystemExit("REFUSING: Phase 1 appears to be applied already.")

    print(f"decision_engine.py  ({de})")
    # --- bottom-up: the later edit first ---
    src_de = edit(
        src_de,
        "        return self.cfg.rs_weight * c.rs_rating + self.cfg.stage2_weight * c.stage2_score",
        "        return (self.cfg.rs_weight * c.rs_rating\n"
        "                + self.cfg.stage2_weight * c.stage2_score\n"
        "                + self.cfg.vcp_weight * c.vcp_score)",
        "rank_score third term")
    src_de = edit(
        src_de,
        "    stage2_weight: float = 1.0\n",
        "    stage2_weight: float = 1.0\n"
        "    vcp_weight: float = 0.0           # 0.0 preserves today's behaviour exactly.\n"
        "                                      # Set with rs_weight=stage2_weight=0.0 for\n"
        "                                      # the frozen vcp_only ranking (Phase 2).\n",
        "DecisionConfig.vcp_weight field")

    print(f"test_entry_half.py  ({th})")
    src_th = edit(
        src_th,
        "    test_decision()\n    test_contract_roundtrip()",
        "    test_decision()\n    test_rank_score()\n    test_contract_roundtrip()",
        "register test_rank_score in main()")
    src_th = edit(
        src_th,
        "def main():\n",
        TEST_BLOCK + "def main():\n",
        "insert test_rank_score()")

    write(de, src_de)
    write(th, src_th)
    print("\nPHASE 1 APPLIED. Now run:  python -m pytest -q   (and the two suites)")
    return 0


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("usage: python patch_phase1.py <repo-root>")
    sys.exit(main(sys.argv[1]))
