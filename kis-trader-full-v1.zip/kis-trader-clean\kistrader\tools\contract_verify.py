#!/usr/bin/env python3
"""
kis_contract_verify.py — WRITE-PATH + unverified-field verifier  (§7.3, §3.10)
==============================================================================

Run this against a KIS **mock** account, during US market hours, to prove the
entry half's write paths on a real server and to CONFIRM the two field names the
code still carries as `# VERIFY`:

  1. get_fills_detail's execution-price field  (assumed `ft_ccld_unpr`)
  2. inquire-psamount's USD orderable-amount field (buying power)
  3. list_open_order_tickers's ticker field       (assumed `pdno`)

It is deliberately conservative:
  * The resting-order test places a 1-share BUY at HALF the last price, so it
    rests and does not fill; then it cancels.
  * It only places a *marketable* (fill-able) order if you pass --allow-fill,
    and even then it's 1 share. That leaves 1 share in the mock account, which
    you can flatten in the app.

For every unverified field it DUMPS the raw response keys, so if an assumed name
is wrong you can read the correct one straight off the output.

Setup (PowerShell):
    $env:KIS_APP_KEY=...; $env:KIS_APP_SECRET=...; $env:KIS_CANO=...; $env:KIS_PRDT="01"
Run:
    python kis_contract_verify.py                 # read + resting write paths, no fill
    python kis_contract_verify.py --allow-fill    # also test fill reads (spends mock cash)
"""
from __future__ import annotations


import os
import sys
import time
import json
import argparse

from kistrader.entry.entry_manager import KISBrokerWithEntry, make_kis_buying_power_provider


def _dump(b, label, url_path, tr, params):
    """Raw GET + print the field keys of the first output row, so you can confirm
    (or correct) an assumed field name against what KIS actually returns."""
    res = b._request("GET", f"{b.base_url}{url_path}", headers=b._headers(tr),
                     params=params)
    print(f"\n--- RAW {label} ---")
    if res.get("_transport_error"):
        print("  transport error:", res.get("msg1")); return
    print("  rt_cd:", res.get("rt_cd"), " msg:", res.get("msg1"))
    rows = res.get("output")
    if isinstance(rows, dict):                       # some endpoints: single dict
        print("  output keys:", sorted(rows.keys()))
        print("  output:", json.dumps(rows, ensure_ascii=False)[:800])
        return
    rows = rows or res.get("output1") or []
    if rows:
        print(f"  {len(rows)} row(s). row0 keys:", sorted(rows[0].keys()))
        print("  row0:", json.dumps(rows[0], ensure_ascii=False)[:800])
    else:
        print("  (no rows)")


# --- PATCH Y (I3) ---
# Substrings that would appear in a KIS volume-ish field name. Deliberately
# loose: a false positive costs one printed line, a false negative costs a
# session, and sessions are the scarce resource here.
_VOL_TOKENS = ("vol", "amt", "trqu", "qty", "cntg", "shrs", "shnu")


def _dump_i3(b, label, url_path, tr, params):
    """Full-payload dump plus a volume-field scan.

    `_dump` above prints row0's keys truncated at 800 chars, which is right for
    CONFIRMING a field name you already suspect. I3 is the opposite problem:
    nobody knows what comes back, so print every container, every key, and then
    name the fields that could be a volume. Read-only: one GET, no state."""
    print("")
    print("--- I3 RAW %s ---" % label)
    print("    path=%s  tr=%s" % (url_path, tr))
    try:
        res = b._request("GET", "%s%s" % (b.base_url, url_path),
                         headers=b._headers(tr), params=params)
    except Exception as ex:
        print("  request raised: %r" % (ex,))
        print("  A raised request is NOT the same as an empty payload. Record it.")
        return
    if not isinstance(res, dict):
        print(("  unexpected response type %s: %r"
               % (type(res).__name__, res))[:400])
        return
    if res.get("_transport_error"):
        print("  transport error:", res.get("msg1"))
        print("  If this 404s, the PATH is wrong, not the TR id. Re-run with")
        print("  --price-path <correct path>. The other endpoint still answers")
        print("  the S2 question on its own.")
        return
    print("  rt_cd:", res.get("rt_cd"), " msg:", res.get("msg1"))
    print("  top-level keys:", sorted(res.keys()))
    found = []
    for key in sorted(res.keys()):
        val = res.get(key)
        if isinstance(val, dict):
            rows = [val]
        elif isinstance(val, list) and val and isinstance(val[0], dict):
            rows = val
        else:
            continue
        print("  [%s] %d row(s), keys: %s" % (key, len(rows), sorted(rows[0].keys())))
        print("  [%s] row0: %s"
              % (key, json.dumps(rows[0], ensure_ascii=False)[:2000]))
        for fk, fv in rows[0].items():
            if any(tok in str(fk).lower() for tok in _VOL_TOKENS):
                found.append((key, fk, fv))
    if found:
        print("  VOLUME CANDIDATES:")
        for c, fk, fv in found:
            print("    %s.%s = %r" % (c, fk, fv))
        print("  A candidate is a NAME, not a confirmed meaning. Check the value")
        print("  against the day's real volume before wiring anything to it.")
    else:
        print("  VOLUME CANDIDATES: none. No key on this endpoint looks like a")
        print("  volume. If both endpoints read 'none', PLAN sec.4 S2's second")
        print("  branch is earned: record live volume confirmation as a PERMANENT")
        print("  divergence, not an open TODO.")
# --- end PATCH Y (I3) ---


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--ticker", default="AAPL")
    ap.add_argument("--exchange", default="NAS")
    ap.add_argument("--allow-fill", action="store_true",
                    help="also place a marketable 1-share BUY to test fill reads "
                         "(spends mock cash; leaves 1 share)")
    # --- PATCH Y (I3) ---
    ap.add_argument("--i3-only", action="store_true",
                    help="I3: token + one quote + the two payload dumps, then "
                         "stop. Places NO order and touches no state.")
    ap.add_argument("--price-path",
                    default="/uapi/overseas-price/v1/quotations/price",
                    help="path for TR_PRICE (HHDFS00000300). UNVERIFIED - it has "
                         "zero call sites in this codebase, which is why I3 "
                         "exists. If it 404s, pass the correct path here.")
    # --- end PATCH Y (I3) ---
    args = ap.parse_args()

    try:
        key = os.environ["KIS_APP_KEY"]; sec = os.environ["KIS_APP_SECRET"]
        cano = os.environ["KIS_CANO"]
    except KeyError as e:
        print(f"missing env var {e}. Set KIS_APP_KEY/KIS_APP_SECRET/KIS_CANO (mock).")
        return 2
    prdt = os.environ.get("KIS_PRDT", "01")
    tkr, exch = args.ticker.upper(), args.exchange

    b = KISBrokerWithEntry(key, sec, cano, acnt_prdt_cd=prdt, is_mock=True)
    from kistrader.core.engine_v2 import TR_FILLS_MOCK, TR_UNFILLED_MOCK
    # --- PATCH Y (I3) --- TR_PRICE has zero call sites; TR_QUOTE is what
    # get_quote already uses and whose payload has never been printed whole.
    from kistrader.core.engine_v2 import TR_PRICE, TR_QUOTE
    # --- end PATCH Y (I3) ---

    results = []
    def rec(name, ok, detail=""):
        results.append(ok); print(f"[{'PASS' if ok else 'FAIL'}] {name}   {detail}")

    print("=" * 66)
    print(f"KIS MOCK write-path verify — {tkr}/{exch}  (mock={b.is_mock})")
    print("=" * 66)

    # 0 — token
    try:
        rec("token issuance", bool(b._ensure_token()))
    except Exception as e:
        rec("token issuance", False, str(e)); return _summary(results)

    # 1 — quote (need a live price to size the safe limits)
    q = b.get_quote(tkr, exch)
    last = float(q.get("last") or 0)
    rec("get_quote", last > 0, f"last={last} bid={q.get('bid')}")
    if last <= 0:
        print("no price (market closed?) — run during US regular hours."); 
        return _summary(results)

    # --- PATCH Y (I3) --- payload discovery. Two GETs, no order, no state.
    # (a) is the endpoint TR_PRICE names and nothing in this codebase calls.
    # (b) is the one get_quote calls on every tick, out of which it keeps only
    #     `last` and `pbid1`. Volume may already be arriving there unread, in
    #     which case I3 closes without a new endpoint at all.
    _dump_i3(b, "inquire-price (TR_PRICE, zero call sites in this codebase)",
             args.price_path, TR_PRICE, {"AUTH": "", "EXCD": exch, "SYMB": tkr})
    _dump_i3(b, "inquire-asking-price (what get_quote already reads)",
             "/uapi/overseas-price/v1/quotations/inquire-asking-price",
             TR_QUOTE, {"AUTH": "", "EXCD": exch, "SYMB": tkr})
    if args.i3_only:
        print("")
        print("--i3-only: NO order was placed and no state was touched.")
        print("Read the two VOLUME CANDIDATES lines above; that is the I3 answer.")
        return _summary(results)
    # --- end PATCH Y (I3) ---

    # 2 — place a FAR-below-market limit BUY (rests, will not fill)
    px = round(last * 0.5, 2)
    res = b.place_limit_order(tkr, 1, px, "BUY", exch)
    oid = res.get("order_id")
    rec("place_limit_order (resting)", bool(res.get("ok") and oid),
        f"oid={oid} msg={res.get('msg')}")
    if not oid:
        return _summary(results)
    time.sleep(2)

    # 3 — status should be RESTING
    st = b.get_order_status(oid)
    rec("get_order_status == RESTING", st == "RESTING", f"got {st}")

    # 4 — fills should be 0 (concrete zero, not None)
    fl = b.get_fills(oid)
    rec("get_fills == 0 (concrete)", fl == 0, f"got {fl}")

    # 5 — list_open_order_tickers should include our ticker  (VERIFY pdno)
    oo = b.list_open_order_tickers()
    ok_oo = isinstance(oo, dict) and tkr in oo
    rec("list_open_order_tickers shows ticker (pdno)", ok_oo, f"got {oo}")
    if not ok_oo:
        print("  ⚠ ticker not found — the ticker field may not be 'pdno'. Raw row below:")
        _dump(b, "inquire-nccs (find the ticker field)",
              "/uapi/overseas-stock/v1/trading/inquire-nccs", TR_UNFILLED_MOCK,
              {"CANO": b.cano, "ACNT_PRDT_CD": b.acnt_prdt_cd, "OVRS_EXCG_CD": "NASD",
               "SORT_SQN": "DS", "CTX_AREA_FK200": "", "CTX_AREA_NK200": ""})

    # 6 — cancel, then status should be GONE
    cx = b.cancel_order(tkr, oid, 1, exch)
    rec("cancel_order", bool(cx.get("ok")), cx.get("msg"))
    time.sleep(2)
    rec("get_order_status == GONE after cancel", b.get_order_status(oid) == "GONE")

    # 7 — buying power: dump raw psamount, then try the provider  (VERIFY field/TR)
    _dump(b, "inquire-psamount (confirm USD orderable-amount field)",
          "/uapi/overseas-stock/v1/trading/inquire-psamount",
          "VTTS3007R",                       # # VERIFY mock psamount TR id
          {"CANO": b.cano, "ACNT_PRDT_CD": b.acnt_prdt_cd,
           "OVRS_EXCG_CD": b._excg(exch), "OVRS_ORD_UNPR": "0", "ITEM_CD": tkr})
    bp = make_kis_buying_power_provider(b, excg=b._excg(exch), fallback_item=tkr)()
    rec("buying_power_provider returns a number", bp is not None, f"got {bp}")

    # 8 — OPTIONAL: marketable order to exercise fill reads  (VERIFY ft_ccld_unpr)
    if args.allow_fill:
        pxf = round(last * 1.003, 2)          # slightly through the offer -> should fill
        print(f"\n--- placing marketable 1-share BUY @ {pxf} (spends mock cash) ---")
        rf = b.place_limit_order(tkr, 1, pxf, "BUY", exch); oidf = rf.get("order_id")
        rec("place_limit_order (marketable)", bool(oidf), f"oid={oidf}")
        if oidf:
            time.sleep(3)
            _dump(b, "inquire-ccnl (confirm exec-price field ft_ccld_unpr)",
                  "/uapi/overseas-stock/v1/trading/inquire-ccnl", TR_FILLS_MOCK,
                  {"CANO": b.cano, "ACNT_PRDT_CD": b.acnt_prdt_cd, "PDNO": "",
                   "ORD_STRT_DT": time.strftime("%Y%m%d"),
                   "ORD_END_DT": time.strftime("%Y%m%d"),
                   "SLL_BUY_DVSN": "00", "CCLD_NCCS_DVSN": "00", "OVRS_EXCG_CD": "",
                   "SORT_SQN": "DS", "ORD_DT": "", "ORD_GNO_BRNO": "", "ODNO": "",
                   "CTX_AREA_FK200": "", "CTX_AREA_NK200": ""})
            qty = b.get_fills(oidf)
            rec("get_fills sees the marketable fill", bool(qty and qty > 0), f"qty={qty}")
            d = b.get_fills_detail(oidf)
            ok_d = d is not None and d[0] > 0 and d[1] > 0
            rec("get_fills_detail returns (qty, price>0)", ok_d, f"got {d}")
            print("  NOTE: 1 share now held in the mock account — flatten it in the app.")

    return _summary(results)


def _summary(results) -> int:
    ok = sum(1 for r in results if r); n = len(results)
    print("=" * 66)
    print(f"{ok}/{n} checks passed")
    print("Confirm from the RAW dumps above: (1) exec-price field == ft_ccld_unpr, "
          "(2) psamount USD field name, (3) nccs ticker field == pdno.")
    print("=" * 66)
    return 0 if ok == n else 1


if __name__ == "__main__":
    sys.exit(main())
