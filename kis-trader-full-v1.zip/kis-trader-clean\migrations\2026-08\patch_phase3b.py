#!/usr/bin/env python3
"""
patch_phase3b.py -- PHASE 3b: the regime gate, in the screeners.

This is where the gate starts having an effect. 3a landed the artifact; 3c makes
the trader read it.

WHAT CHANGES, in BOTH screeners
  * _load_regime_params()  -- regime_ma from ExposureConfig, bar-age ceiling from
    screen_contract. Same fail-closed contract as _load_vcp_threshold(): no local
    fallback value, ever.
  * _regime_probe()        -- one ^GSPC fetch, close vs its regime_ma-day MA, plus
    a check on the BAR'S OWN DATE.
  * main()                 -- the gate runs BEFORE Stage 1. RISK_OFF or
    UNAVAILABLE emits zero rows (plus the sidecar) and returns.
  * run_stage3_vcp()       -- accepts index_df, so the frame the gate fetched is
    reused and nothing is fetched twice.
  * both emit_fn calls     -- carry the regime values into the sidecar.

WHY BEFORE STAGE 1, NOT INSIDE run_stage3_vcp
run_stage3_vcp already fetches ^GSPC, so reusing that looks like the cheap
option. It is not: that call happens at main() line ~2817, AFTER the ~500-900
ticker Stage-1 parallel scan and after every Gemini call. Gating there would
compute the correct answer having already spent the entire run. One extra
single-ticker fetch at the top costs nothing and skips all of it -- which matters
on a 2 vCPU / 4 GB box where the Stage-1 scan is the peak-memory event.

WHY THE BAR DATE IS CHECKED
_fetch_history() silently falls back to a pickled cache when the provider returns
empty ("using cached prices from a recent run"). Harmless for the RS leg. For a
regime gate it means a failed fetch can produce a confident RISK_ON off a bar
from days ago. The probe therefore verifies the bar's own date against the
session and fails closed beyond REGIME_MAX_BAR_AGE_DAYS.

WHY ZERO ROWS RATHER THAN A SEPARATE FLAG
The backtest's gate empties `eligible` on a RISK_OFF day and leaves open
positions untouched. Emitting zero rows is the faithful port. The sidecar carries
the reason, which zero rows alone cannot -- that is the whole argument for
Option C over Option B.

UNAVAILABLE IS TREATED AS RISK_OFF. A gate that cannot evaluate must not pass.

Anchors are asserted; edits are applied bottom-up within each file.

Usage:  python patch_phase3b.py <repo-root>
"""
from __future__ import annotations

import os
import sys

HELPERS = '''def _load_regime_params():
    """Resolve the regime gate's two constants from their single sources.

    regime_ma lives in ExposureConfig -- the same field param_snapshot checks
    against the frozen set, so the screener and the trader cannot drift. The
    bar-age ceiling lives in screen_contract, beside the sidecar it guards.

    Same contract as _load_vcp_threshold(): NO local fallback. A screener that
    guessed its own regime_ma would gate on a different market than the one that
    was backtested, and nothing would report it."""
    try:
        from kistrader.entry.exposure_controller import ExposureConfig
        from kistrader.entry.screen_contract import REGIME_MAX_BAR_AGE_DAYS
        return ExposureConfig().regime_ma, REGIME_MAX_BAR_AGE_DAYS
    except ImportError as e:
        raise SystemExit(
            f"[regime] FATAL: cannot read the regime parameters ({e}).\\n"
            f"  regime_ma comes from kistrader.entry.exposure_controller and the\\n"
            f"  bar-age ceiling from kistrader.entry.screen_contract. Refusing to\\n"
            f"  guess either. From the repo root:\\n"
            f"      pip install -e .                        (then re-run as-is)\\n"
            f"      python -m screeners.{_SCREENER}         (no install needed)")


def _regime_probe(regime_ma, session_date, max_bar_age_days):
    """Evaluate the market regime ONCE, before any expensive work.

    Returns (state, close, ma, bar_date, index_df, reason) where state is one of
    'risk_on' / 'risk_off' / 'unavailable'. close and ma are None unless the
    state is decided, so an unusable probe can never be written to the sidecar as
    a usable one.

    The returned frame is handed to run_stage3_vcp so the benchmark is fetched
    once per run, not twice."""
    import datetime as _d
    try:
        df = _flatten_columns(_fetch_history(VCP_BENCHMARK, VCP_LOOKBACK_PERIOD))
    except Exception as e:                                    # noqa: BLE001
        return ("unavailable", None, None, None, None,
                f"{VCP_BENCHMARK} fetch raised {type(e).__name__}: {e}")
    if df is None or getattr(df, "empty", True) or "Close" not in df:
        return ("unavailable", None, None, None, None,
                f"{VCP_BENCHMARK} fetch returned no usable frame")

    closes = df["Close"].dropna()
    if len(closes) < regime_ma:
        return ("unavailable", None, None, None, df,
                f"only {len(closes)} usable {VCP_BENCHMARK} bars, need {regime_ma}")

    close = float(closes.iloc[-1])
    ma = float(closes.tail(regime_ma).mean())
    try:
        bar_date = closes.index[-1].date().isoformat()
    except AttributeError:
        return ("unavailable", None, None, None, df,
                f"{VCP_BENCHMARK} frame carries no dated index")

    # The bar's OWN date, not the fetch's success. _fetch_history falls back to a
    # pickled cache on an empty provider response, so a "successful" fetch can
    # carry a bar from days ago -- which would otherwise become a confident
    # RISK_ON off stale data.
    try:
        age = (_d.date.fromisoformat(str(session_date))
               - _d.date.fromisoformat(bar_date)).days
    except ValueError:
        return ("unavailable", None, None, bar_date, df,
                f"unparseable dates (bar={bar_date!r}, session={session_date!r})")
    if age < 0:
        return ("unavailable", None, None, bar_date, df,
                f"benchmark bar {bar_date} is AFTER session {session_date}")
    if age > max_bar_age_days:
        return ("unavailable", None, None, bar_date, df,
                f"benchmark bar {bar_date} is {age} days before {session_date} "
                f"(max {max_bar_age_days}) -- probably a cached frame, not today's")

    state = "risk_on" if close >= ma else "risk_off"
    return (state, close, ma, bar_date, df,
            f"{VCP_BENCHMARK} close {close:.2f} vs ma{regime_ma} {ma:.2f} "
            f"(bar {bar_date})")


'''

GATE = '''    # ---- REGIME GATE (Phase 3b) -------------------------------------------------
    # Runs BEFORE Stage 1 on purpose: a RISK_OFF day then costs one benchmark
    # fetch instead of the full ticker scan plus every Gemini call. The backtest
    # gate empties `eligible` on those days and leaves open positions alone, so
    # emitting zero rows is the faithful port -- and the sidecar carries the
    # reason, which zero rows alone cannot.
    _sess = session_date or _regime_today()
    _rma, _max_age = _load_regime_params()
    _state, _bclose, _bma, _bar, _index_df, _why = _regime_probe(
        _rma, _sess, _max_age)
    _regime_kw = dict(benchmark=VCP_BENCHMARK, regime_ma=_rma,
                      benchmark_close=_bclose, benchmark_ma=_bma,
                      benchmark_bar_date=_bar)
    print("=" * 70)
    print(f"REGIME GATE: {_state.upper()} -- {_why}")
    print("=" * 70)
    if _state != "risk_on":
        # UNAVAILABLE is treated exactly like RISK_OFF: a gate that cannot
        # evaluate must not pass.
        print(f"[regime] {_state} -- no new entries today. Skipping the scan "
              f"entirely (no Stage-1 fetches, no Gemini spend).")
        if emit_path and not dry_run:
            emit_fn(stage3_results=[], passed_stocks=[], stage2_passed=[],
                    out_path=emit_path, vcp_threshold=emit_thr,
                    session_date=_sess,
                    source=f"{_SCREENER}" + (f" DEGRADED@{emit_thr}" if _degraded else ""),
                    **_regime_kw)
        else:
            print("[regime] no --emit-candidates (or --dry-run): nothing written. "
                  "The trader will fail closed on the missing/stale sidecar.")
        print("=" * 70)
        return

'''

TODAY_FN = '''def _regime_today():
    """Today's date as an ISO string. Local helper so the gate does not depend on
    a module-level datetime import that this file does not currently have."""
    import datetime as _d
    return _d.date.today().isoformat()


'''


def edit(text, old, new, label):
    n = text.count(old)
    if n != 1:
        raise SystemExit(f"REFUSING: anchor for {label} matched {n} times, expected 1")
    print(f"  ok  {label}")
    return text.replace(old, new)


def read(p):
    with open(p, encoding="utf-8") as f:
        return f.read()


def write(p, s):
    with open(p, "w", encoding="utf-8", newline="") as f:
        f.write(s)


def patch_screener(path, mod, main_anchor):
    print(f"{os.path.basename(path)}  ({path})")
    s = read(path)
    if "_regime_probe" in s:
        raise SystemExit(f"REFUSING: {path} already patched.")
    if "_load_vcp_threshold" not in s:
        raise SystemExit(f"REFUSING: D3a has not been applied to {path}.")

    # ---- bottom-up: the two emit calls are the lowest edits -------------------
    s = edit(s,
             '            emit_fn(stage3_results=[], passed_stocks=[], stage2_passed=[],\n'
             '                    out_path=emit_path, vcp_threshold=emit_thr,\n'
             f'                    session_date=session_date, source=f"{mod}" + (f" DEGRADED@{{emit_thr}}" if _degraded else ""))\n',
             '            emit_fn(stage3_results=[], passed_stocks=[], stage2_passed=[],\n'
             '                    out_path=emit_path, vcp_threshold=emit_thr,\n'
             f'                    session_date=_sess, source=f"{mod}" + (f" DEGRADED@{{emit_thr}}" if _degraded else ""),\n'
             '                    **_regime_kw)\n',
             "zero-Stage-1 emit: carry the regime values")
    s = edit(s,
             '                emit_fn(stage3_results=results,\n'
             '                        passed_stocks=passed_stocks,\n'
             '                        stage2_passed=stage2_passed,\n'
             '                        out_path=emit_path,\n'
             '                        vcp_threshold=emit_thr,\n'
             '                        session_date=session_date,\n'
             f'                        source=f"{mod}" + (f" DEGRADED@{{emit_thr}}" if _degraded else ""))\n',
             '                emit_fn(stage3_results=results,\n'
             '                        passed_stocks=passed_stocks,\n'
             '                        stage2_passed=stage2_passed,\n'
             '                        out_path=emit_path,\n'
             '                        vcp_threshold=emit_thr,\n'
             '                        session_date=_sess,\n'
             f'                        source=f"{mod}" + (f" DEGRADED@{{emit_thr}}" if _degraded else ""),\n'
             '                        **_regime_kw)\n',
             "normal emit: carry the regime values")

    # ---- reuse the frame the gate already fetched ----------------------------
    s = edit(s,
             "        results = run_stage3_vcp(stage2_passed, dry_run=dry_run)\n",
             "        results = run_stage3_vcp(stage2_passed, dry_run=dry_run,\n"
             "                                 index_df=_index_df)\n",
             "hand the benchmark frame down to Stage 3")

    # ---- the gate itself, before Stage 1 -------------------------------------
    s = edit(s, main_anchor, GATE.replace("{_SCREENER}", mod) + main_anchor,
             "insert the regime gate ahead of Stage 1")

    # ---- run_stage3_vcp: accept a pre-fetched frame ---------------------------
    s = edit(s,
             '    print(f"[*] Fetching benchmark {VCP_BENCHMARK} ({VCP_LOOKBACK_PERIOD}) for the VCP RS leg...")\n'
             '    index_df = _flatten_columns(_fetch_history(VCP_BENCHMARK, VCP_LOOKBACK_PERIOD))\n',
             '    if index_df is None:\n'
             '        print(f"[*] Fetching benchmark {VCP_BENCHMARK} ({VCP_LOOKBACK_PERIOD}) for the VCP RS leg...")\n'
             '        index_df = _flatten_columns(_fetch_history(VCP_BENCHMARK, VCP_LOOKBACK_PERIOD))\n'
             '    else:\n'
             '        print(f"[*] Reusing the {VCP_BENCHMARK} frame the regime gate already fetched.")\n',
             "run_stage3_vcp: fetch only if no frame was handed in")
    s = edit(s,
             "def run_stage3_vcp(stage2_passed, dry_run=False):\n",
             TODAY_FN + HELPERS.replace("{_SCREENER}", mod)
             + "def run_stage3_vcp(stage2_passed, dry_run=False, index_df=None):\n",
             "insert the regime helpers + index_df parameter")
    write(path, s)


def main(root):
    sp = os.path.join(root, "screeners", "sp500_v21.py")
    us = os.path.join(root, "screeners", "us_small_v21.py")
    ce = os.path.join(root, "screeners", "candidate_emit.py")
    for p in (sp, us, ce):
        if not os.path.isfile(p):
            raise SystemExit(f"REFUSING: not found: {p}")
    if "regime_path_for" not in read(ce):
        raise SystemExit("REFUSING: Phase 3a has not been applied (candidate_emit "
                         "does not know about the sidecar).")

    patch_screener(sp, "sp500_v21", '    print("Fetching S&P 500 constituents database...")\n')
    patch_screener(us, "us_small_v21", "    universe = load_universe()\n")
    print("\nPHASE 3b APPLIED. The gate is LIVE in both screeners.")
    print("Verify with:  python tests/test_screener_harness.py")
    print("Then a real run:  python -m screeners.sp500_v21 --limit 3 --dry-run")
    return 0


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("usage: python patch_phase3b.py <repo-root>")
    sys.exit(main(sys.argv[1]))
