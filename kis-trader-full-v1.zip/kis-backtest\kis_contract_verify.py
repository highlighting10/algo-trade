#!/usr/bin/env python3
"""
KIS broker-contract verifier
=============================

Purpose: before the entry half and run loop are built on top of engine.py, confirm
that the engine's `# VERIFY` assumptions — endpoint paths, TR_IDs, and the exact
field names the safety logic parses — actually match what YOUR KIS account returns.
Every safety guarantee in the engine rests on get_holding / get_fills parsing the
right field; a wrong name fails silently (returns 0/empty), so this proves it first.

What it checks, mapped to the engine code that depends on it:
  quote        -> get_quote().bid          (field: pbid1)        used by the exit re-pricing loop
  balance      -> get_holding()            (fields: ovrs_pdno, ovrs_cblc_qty)  the holdings backstop
  unfilled     -> get_order_status()       (field: odno)         RESTING/GONE detection
  executions   -> get_fills()              (fields: odno, ft_ccld_qty)  POSITIVE fill confirmation
  order        -> place_limit_order()      (field: ODNO)         order id we track
  cancel       -> cancel_order()           (rt_cd success)       stale re-pricing

IMPORTANT, READ THIS:
  The TR_IDs, paths and field names below are MIRRORED FROM engine.py and are my
  best reconstruction — several may be wrong. That is exactly what this tool finds.
  The authoritative source is the official examples:
      https://github.com/koreainvestment/open-trading-api  (examples_user/overseas_stock)
  On any failure, KIS's own `msg_cd` / `msg1` in the raw response is GROUND TRUTH —
  read it; it usually says precisely which TR_ID or field is wrong.

SAFETY:
  * Read-only checks (quote/balance/unfilled/executions) run anywhere.
  * The order/cancel and fill tests PLACE REAL ORDERS and so run on the MOCK
    (모의투자) domain ONLY, 1 share, and clean up after themselves. They refuse to
    run against the live domain.

Usage (PowerShell / cmd on Windows):
  set KIS_APP_KEY=...
  set KIS_APP_SECRET=...
  set KIS_CANO=12345678            # 8-digit account
  set KIS_ACNT_PRDT_CD=01
  python kis_contract_verify.py --symbol AAPL
  python kis_contract_verify.py --symbol AAPL --with-order-test     # mock only: rest+cancel
  python kis_contract_verify.py --symbol AAPL --with-fill-test      # mock only: fill+sell (verifies balance+executions fields)
  python kis_contract_verify.py --selftest                         # no creds; proves the checker logic
"""

from __future__ import annotations
import os
import sys
import json
import time
import argparse

try:
    import requests
except ImportError:
    print("pip install requests"); sys.exit(1)

# ---- mirrored from engine.py (the # VERIFY constants) ----
MOCK_URL = "https://openapivts.koreainvestment.com:29443"
LIVE_URL = "https://openapi.koreainvestment.com:9443"
TR_QUOTE = "HHDFS76200100"
TR_PRICE = "HHDFS00000300"
TR_BAL_MOCK, TR_BAL_LIVE = "VTTS3012R", "JTTS3012R"
TR_FILLS_MOCK, TR_FILLS_LIVE = "VTTS3035R", "JTTS3035R"
TR_NCCS_MOCK, TR_NCCS_LIVE = "VTTS3018R", "JTTS3018R"
TR_BUY_MOCK, TR_SELL_MOCK = "VTTT1002U", "VTTT1006U"
TR_CANCEL_MOCK = "VTTT1004U"

HTTP_TIMEOUT = 7


class Report:
    """Tallies each engine assumption as CONFIRMED / MISMATCH / UNVERIFIED."""
    def __init__(self):
        self.rows = []  # (label, status, detail, fix)

    def add(self, label, status, detail, fix=None):
        self.rows.append((label, status, detail, fix))
        mark = {True: "PASS", False: "FAIL", None: "????"}[status]
        print(f"   [{mark}] {label}: {detail}")
        if status is False and fix:
            print(f"          -> fix: {fix}")

    def summary(self):
        print("\n" + "=" * 68)
        print("CONTRACT SUMMARY (each row is an engine.py assumption)")
        print("=" * 68)
        order = {True: 0, None: 1, False: 2}
        for label, status, detail, fix in sorted(self.rows, key=lambda r: order[r[1]]):
            mark = {True: "CONFIRMED ", False: "MISMATCH  ", None: "UNVERIFIED"}[status]
            print(f"  {mark}  {label}")
            if status is False and fix:
                print(f"              fix engine.py: {fix}")
        n_ok = sum(1 for r in self.rows if r[1] is True)
        n_bad = sum(1 for r in self.rows if r[1] is False)
        n_unk = sum(1 for r in self.rows if r[1] is None)
        print("-" * 68)
        print(f"  {n_ok} confirmed | {n_bad} MISMATCH | {n_unk} unverified")
        if n_bad:
            print("  ACTION: correct the listed field/TR constants in engine.py, then re-run.")
        if n_unk:
            print("  NOTE: 'unverified' rows need a real holding/fill — run --with-fill-test on mock.")
        print("=" * 68)
        return n_bad == 0


# ---------- pure field-checkers (also exercised by --selftest) ----------

def _rows(resp, containers=("output", "output1", "output2")):
    for c in containers:
        v = resp.get(c)
        if isinstance(v, list):
            return v
    return []


def check_balance_fields(resp, report):
    rows = _rows(resp, ("output1", "output"))
    if not rows:
        report.add("balance.row", None,
                   "endpoint replied but no holdings present (can't confirm row fields)",
                   )
        return
    row = rows[0]
    for f, fix in (("ovrs_pdno", "get_holding(): change the ticker field"),
                   ("ovrs_cblc_qty", "get_holding(): change the qty field")):
        present = f in row
        report.add(f"balance.{f}", present,
                   f"{'found' if present else 'MISSING'} (sample keys: {list(row)[:6]})", None if present else fix)


def check_executions_fields(resp, report):
    rows = _rows(resp, ("output", "output1"))
    if not rows:
        report.add("executions.row", None,
                   "endpoint replied but no executions today (can't confirm fill fields)")
        return
    row = rows[0]
    present_odno = "odno" in row
    report.add("executions.odno", present_odno,
               f"{'found' if present_odno else 'MISSING'} (sample keys: {list(row)[:8]})",
               None if present_odno else "get_fills(): change the order-id match field")
    qty_field = next((f for f in ("ft_ccld_qty", "ccld_qty") if f in row), None)
    report.add("executions.filled_qty", qty_field is not None,
               f"found '{qty_field}'" if qty_field else "MISSING ft_ccld_qty / ccld_qty",
               None if qty_field else "get_fills(): change the filled-qty field")


def check_unfilled_fields(resp, report):
    rows = _rows(resp, ("output", "output1"))
    if not rows:
        report.add("unfilled.row", None,
                   "no resting orders (run --with-order-test to place one)")
        return
    row = rows[0]
    present = "odno" in row
    report.add("unfilled.odno", present,
               f"{'found' if present else 'MISSING'} (sample keys: {list(row)[:8]})",
               None if present else "get_order_status(): change the order-id match field")


def check_quote_fields(resp, report):
    out = resp.get("output1") or resp.get("output") or {}
    for f, fix in (("last", "get_quote(): change last-price field"),
                   ("pbid1", "get_quote(): change the bid field")):
        present = f in out
        report.add(f"quote.{f}", present,
                   f"{'found' if present else 'MISSING'} (sample keys: {list(out)[:8]})",
                   None if present else fix)


def check_order_resp(resp, report):
    out = resp.get("output", {}) or {}
    oid = out.get("ODNO") or out.get("odno")
    report.add("order.ODNO", oid is not None,
               f"order id = {oid}" if oid else f"MISSING (sample keys: {list(out)[:8]})",
               None if oid else "place_limit_order(): change the order-id field")
    return oid


# ---------------------- live verifier ----------------------

class KISVerifier:
    def __init__(self, key, secret, cano, prdt, is_mock=True):
        self.key, self.secret, self.cano, self.prdt = key, secret, cano, prdt
        self.is_mock = is_mock
        self.base = MOCK_URL if is_mock else LIVE_URL
        self.token = None

    def _req(self, method, path, tr, params=None, body=None):
        url = self.base + path
        headers = {"authorization": f"Bearer {self.token}", "appkey": self.key,
                   "appsecret": self.secret, "tr_id": tr, "custtype": "P",
                   "content-type": "application/json"}
        try:
            r = requests.request(method, url, headers=headers, params=params,
                                 json=body, timeout=HTTP_TIMEOUT)
            return r.json()
        except Exception as e:
            return {"rt_cd": "-1", "msg1": f"transport: {e}", "_transport": True}

    def auth(self, report):
        try:
            r = requests.post(self.base + "/oauth2/tokenP",
                              json={"grant_type": "client_credentials",
                                    "appkey": self.key, "appsecret": self.secret},
                              timeout=HTTP_TIMEOUT).json()
        except Exception as e:
            report.add("auth.token", False, f"transport error: {e}",
                       "check network / domain allowlist"); return False
        self.token = r.get("access_token")
        report.add("auth.token", self.token is not None,
                   "token acquired" if self.token else f"FAILED: {r}",
                   None if self.token else "check appkey/secret and domain")
        return self.token is not None

    @staticmethod
    def _show(name, resp):
        s = json.dumps(resp, ensure_ascii=False)
        print(f"   raw[{name}]: {s[:280]}{'...' if len(s) > 280 else ''}")
        if resp.get("rt_cd") not in ("0", None):
            print(f"   KIS says -> msg_cd={resp.get('msg_cd')} msg1={resp.get('msg1')}")

    def verify_quote(self, symbol, report):
        print("\n[quote] /overseas-price/.../inquire-asking-price")
        r = self._req("GET", "/uapi/overseas-price/v1/quotations/inquire-asking-price",
                      TR_QUOTE, params={"AUTH": "", "EXCD": "NAS", "SYMB": symbol})
        self._show("quote", r); check_quote_fields(r, report)

    def verify_balance(self, report):
        print("\n[balance] /overseas-stock/.../inquire-balance")
        tr = TR_BAL_MOCK if self.is_mock else TR_BAL_LIVE
        r = self._req("GET", "/uapi/overseas-stock/v1/trading/inquire-balance", tr,
                      params={"CANO": self.cano, "ACNT_PRDT_CD": self.prdt,
                              "OVRS_EXCG_CD": "NASD", "TR_CRCY_CD": "USD",
                              "CTX_AREA_FK200": "", "CTX_AREA_NK200": ""})
        self._show("balance", r); check_balance_fields(r, report)

    def verify_unfilled(self, report):
        print("\n[unfilled] /overseas-stock/.../inquire-nccs")
        tr = TR_NCCS_MOCK if self.is_mock else TR_NCCS_LIVE
        r = self._req("GET", "/uapi/overseas-stock/v1/trading/inquire-nccs", tr,
                      params={"CANO": self.cano, "ACNT_PRDT_CD": self.prdt,
                              "OVRS_EXCG_CD": "NASD", "SORT_SQN": "DS",
                              "CTX_AREA_FK200": "", "CTX_AREA_NK200": ""})
        self._show("unfilled", r); check_unfilled_fields(r, report)

    def verify_executions(self, report):
        print("\n[executions] /overseas-stock/.../inquire-ccnl")
        tr = TR_FILLS_MOCK if self.is_mock else TR_FILLS_LIVE
        today = time.strftime("%Y%m%d")
        r = self._req("GET", "/uapi/overseas-stock/v1/trading/inquire-ccnl", tr,
                      params={"CANO": self.cano, "ACNT_PRDT_CD": self.prdt,
                              "ORD_STRT_DT": today, "ORD_END_DT": today,
                              "OVRS_EXCG_CD": "NASD", "SORT_SQN": "DS",
                              "CTX_AREA_FK200": "", "CTX_AREA_NK200": ""})
        self._show("executions", r); check_executions_fields(r, report)

    # ---- order tests: MOCK ONLY, 1 share, self-cleaning ----
    def _place(self, symbol, qty, price, side):
        tr = TR_BUY_MOCK if side == "BUY" else TR_SELL_MOCK
        return self._req("POST", "/uapi/overseas-stock/v1/trading/order", tr,
                         body={"CANO": self.cano, "ACNT_PRDT_CD": self.prdt,
                               "OVRS_EXCG_CD": "NASD", "PDNO": symbol,
                               "ORD_QTY": str(qty), "OVRS_ORD_UNPR": f"{price:.2f}",
                               "ORD_SVR_DVSN_CD": "0", "ORD_DVSN": "00"})

    def verify_order_cycle(self, symbol, report):
        if not self.is_mock:
            report.add("order.cycle", None, "skipped: order test runs on MOCK only"); return
        print("\n[order] place a far-below-market $1 BUY (rests, won't fill) -> read unfilled -> cancel")
        r = self._place(symbol, 1, 1.00, "BUY")
        self._show("order", r)
        oid = check_order_resp(r, report)
        if not oid:
            return
        time.sleep(1)
        self.verify_unfilled(report)  # now there IS a resting order -> confirms unfilled fields
        print("\n[cancel] /overseas-stock/.../order-rvsecncl")
        c = self._req("POST", "/uapi/overseas-stock/v1/trading/order-rvsecncl", TR_CANCEL_MOCK,
                      body={"CANO": self.cano, "ACNT_PRDT_CD": self.prdt,
                            "OVRS_EXCG_CD": "NASD", "PDNO": symbol,
                            "ORGN_ODNO": str(oid), "RVSE_CNCL_DVSN_CD": "02",
                            "ORD_QTY": "1", "OVRS_ORD_UNPR": "0", "ORD_SVR_DVSN_CD": "0"})
        self._show("cancel", c)
        report.add("cancel.rt_cd", c.get("rt_cd") == "0",
                   "cancel accepted" if c.get("rt_cd") == "0" else f"FAILED: {c.get('msg1')}",
                   None if c.get("rt_cd") == "0" else "cancel_order(): check TR_CANCEL / RVSE_CNCL_DVSN_CD")

    def verify_fill_cycle(self, symbol, report):
        """MOCK ONLY: marketable 1-share buy -> confirms balance + executions row
        fields (the SAFETY-CRITICAL ones) -> sells the share back to flatten."""
        if not self.is_mock:
            report.add("fill.cycle", None, "skipped: fill test runs on MOCK only"); return
        pr = self._req("GET", "/uapi/overseas-price/v1/quotations/price", TR_PRICE,
                       params={"AUTH": "", "EXCD": "NAS", "SYMB": symbol})
        last = float((pr.get("output") or {}).get("last", 0) or 0)
        if last <= 0:
            report.add("fill.cycle", None, "could not read current price; skipping fill test"); return
        print(f"\n[fill] marketable 1-share BUY of {symbol} on MOCK at ~{last*1.05:.2f} to force a fill")
        r = self._place(symbol, 1, round(last * 1.05, 2), "BUY")
        self._show("fill-buy", r)
        if r.get("rt_cd") != "0":
            report.add("fill.cycle", False, f"buy rejected: {r.get('msg1')}"); return
        time.sleep(2)
        self.verify_balance(report)      # now a holding exists -> confirms ovrs_cblc_qty
        self.verify_executions(report)   # now a fill exists -> confirms ft_ccld_qty
        print("\n[fill] selling the share back to flatten")
        self._show("fill-sell", self._place(symbol, 1, round(last * 0.95, 2), "SELL"))


def selftest():
    """No credentials needed. Feeds canned good/bad responses through the field
    checkers to PROVE that a PASS means PASS and a renamed field is caught."""
    print("SELFTEST: proving the contract checkers themselves are correct\n")
    print("-- good responses (engine assumptions hold) --")
    g = Report()
    check_balance_fields({"rt_cd": "0", "output1": [{"ovrs_pdno": "AAPL", "ovrs_cblc_qty": "10"}]}, g)
    check_executions_fields({"rt_cd": "0", "output": [{"odno": "0001", "ft_ccld_qty": "5"}]}, g)
    check_unfilled_fields({"rt_cd": "0", "output": [{"odno": "0001"}]}, g)
    check_quote_fields({"rt_cd": "0", "output1": {"last": "190.1", "pbid1": "190.0"}}, g)
    check_order_resp({"rt_cd": "0", "output": {"ODNO": "0007"}}, g)
    assert all(r[1] is True for r in g.rows), "good responses should all CONFIRM"
    print("\n-- bad responses (fields renamed -> must be caught) --")
    b = Report()
    check_balance_fields({"rt_cd": "0", "output1": [{"symbol": "AAPL", "qty": "10"}]}, b)
    check_executions_fields({"rt_cd": "0", "output": [{"order_no": "1", "exec_qty": "5"}]}, b)
    check_order_resp({"rt_cd": "0", "output": {"order_id": "7"}}, b)
    assert all(r[1] is False for r in b.rows), "renamed fields must all MISMATCH"
    print("\n-- empty responses (no data -> UNVERIFIED, not a false pass) --")
    u = Report()
    check_balance_fields({"rt_cd": "0", "output1": []}, u)
    check_executions_fields({"rt_cd": "0", "output": []}, u)
    assert all(r[1] is None for r in u.rows), "empty data must be UNVERIFIED"
    print("\nSELFTEST PASSED: checkers correctly report CONFIRMED / MISMATCH / UNVERIFIED")


def main():
    ap = argparse.ArgumentParser(description="KIS broker-contract verifier")
    ap.add_argument("--symbol", default="AAPL")
    ap.add_argument("--live", action="store_true", help="use LIVE domain (default: mock/모의투자)")
    ap.add_argument("--with-order-test", action="store_true", help="mock only: rest + cancel a $1 order")
    ap.add_argument("--with-fill-test", action="store_true", help="mock only: fill 1 share + sell back")
    ap.add_argument("--selftest", action="store_true")
    args = ap.parse_args()

    if args.selftest:
        selftest(); return

    creds = (os.getenv("KIS_APP_KEY"), os.getenv("KIS_APP_SECRET"),
             os.getenv("KIS_CANO"), os.getenv("KIS_ACNT_PRDT_CD", "01"))
    if not all(creds[:3]):
        print("Set KIS_APP_KEY, KIS_APP_SECRET, KIS_CANO (and optionally KIS_ACNT_PRDT_CD).")
        print("Or run:  python kis_contract_verify.py --selftest"); sys.exit(1)

    print(f"Domain: {'LIVE' if args.live else 'MOCK (모의투자)'}   Symbol: {args.symbol}")
    v = KISVerifier(*creds, is_mock=not args.live)
    report = Report()
    if not v.auth(report):
        report.summary(); sys.exit(1)
    v.verify_quote(args.symbol, report)
    v.verify_balance(report)
    v.verify_unfilled(report)
    v.verify_executions(report)
    if args.with_order_test:
        v.verify_order_cycle(args.symbol, report)
    if args.with_fill_test:
        v.verify_fill_cycle(args.symbol, report)
    ok = report.summary()
    sys.exit(0 if ok else 2)


if __name__ == "__main__":
    main()
