# 1. download pip files first
#    pip install requests pandas yfinance google-genai lxml
# 2. from aistudio.google.com get api key of gemini flash 2.5
# 3. when google updates manual update of model is needed.
#
# v3 CHANGES vs v2 (see markdown writeup for full rationale):
#   - The 8 Minervini conditions and their thresholds: STILL UNCHANGED
#   - Retry now also fires on yfinance's "silent failure" (empty DataFrame,
#     no exception) -- this is yfinance's default behavior on rate-limit/
#     errors (raise_errors=False), so the old exception-only retry rarely
#     actually triggered. Retry no longer wastes time on tickers that are
#     just genuinely too new (<200 real rows) -- only empty/None results retry.
#   - auto_adjust=True and timeout=10 set EXPLICITLY (previously relied on
#     yfinance's library default, which has silently changed before)
#   - check_minervini_technicals now also returns a `status` string
#     ("matched" / "rejected" / "insufficient_history" / "fetch_failed" /
#     "calc_error") purely for terminal transparency -- it does not change
#     which stocks pass or fail
#   - Stage 1 summary now reports a breakdown of those statuses, so you can
#     tell genuine rejections apart from data-fetch problems
#   - Ctrl+C now cancels pending scans quickly instead of waiting for the
#     whole thread pool to drain
#   - A single bad ticker can no longer crash the whole scan after several
#     minutes of work (future.result() is now guarded)
#   - yfinance's internal warning/error logging is quieted so the progress
#     output stays readable across a 500+ ticker scan
#
# v4 CHANGES vs v3 (fixes from the v3 self-critique):
#   - Fixed: a failed future.result() call used to leave stale ticker
#     identity from a PREVIOUS iteration (harmless today, but fragile and
#     erased which ticker actually failed) -- now recovered reliably from
#     the futures map regardless of success/failure
#   - Fixed: Top-3 tie-break could vary run-to-run because thread completion
#     order is non-deterministic -- added a secondary sort key (ticker
#     symbol) so exact ties resolve the same way every time
#   - Fixed: the Wikipedia universe fetch had a timeout but no retry --
#     now retries transient failures before giving up on that source
#   - Fixed: thread-pool shutdown was only guaranteed on the success path
#     and on KeyboardInterrupt -- any other exception type would skip
#     cleanup; now wrapped in `finally` so it always runs
#
# v5 CHANGES vs v4 (cross-script consistency fixes -- these had already
# been applied to the MSCI Korea / MSCI ex-US screeners but never made it
# back into this one):
#   - Fixed: the history-length guard was `< 200`, but
#     sma_200_20d_ago = rolling(200).mean().iloc[-21] only stops being NaN
#     once there are >= 220 rows (rolling(200) itself first produces a
#     value at row index 199, and iloc[-21] on a 200-row series points at
#     index 179). At exactly 200-220 rows this meant cond_3 silently
#     evaluated `sma_200 > NaN` -> always False, quietly rejecting every
#     recent IPO/spinoff with no error trail. Raised to `< 221`.
#   - Added: gemini_key.txt is now chmod'd to 0600 after creation, matching
#     the MSCI screeners (the key was previously left at default/world-
#     readable permissions)
#
# v6 CHANGES vs v5 (by request -- condition 8 upgraded to a real RS Rating):
#   - Condition 8 was `stock_6m_return > spy_return`, a binary "did it beat
#     the index" check. That's a much weaker bar than Minervini/IBD's actual
#     RS Rating, which is a 1-99 PERCENTILE of a recency-weighted return
#     score against the rest of the universe. Replaced it with that: each
#     ticker now gets a raw weighted score (most recent quarter 40%, each
#     prior quarter 20%), and once every ticker in the scan has been
#     scored, those raw scores are ranked into a 1-99 percentile via
#     compute_rs_proxy(). Condition 8 is now RS Rating >= 70.
#   - This requires a genuine two-pass design: a single ticker's percentile
#     can't be known until every other ticker has been scored too, so the
#     final match decision (and the [MATCH] print) now happens in a second,
#     single-threaded pass after run_parallel_scan's parallel loop
#     completes, not live as each thread finishes.
#   - The RS-score lookback windows (3/6/9/12 months back) use an adaptive
#     clamp (_lookback_price) instead of a fixed iloc index, so a ticker
#     right at the 221-row structural minimum doesn't crash or get wrongly
#     bounced as insufficient_history just because it's a bit short of a
#     full 252-trading-day year.
#   - Conditions 1-7 and their thresholds: still byte-for-byte unchanged.
#
# v7 CHANGES vs v6 (cross-suite review fixes):
#   - Fixed: RS raw-score formula changed from cumulative ratios (p_now/p_Xm,
#     all anchored to current price) to segmental ratios: p_now/p_3m (Q4),
#     p_3m/p_6m (Q3), p_6m/p_9m (Q2), p_9m/p_12m (Q1). Each term now
#     measures only its own 3-month window. Previously a strong last quarter
#     inflated the 6m, 9m, and 12m weighted terms as well.
#   - Fixed: spy_return parameter removed from check_minervini_technicals()
#     and _scan_one(). Both accepted it but the function body never used it
#     (cond_8 was moved to the second pass in v6). spy_return is unchanged;
#     still fetched in main() and used for alpha display in the second pass.
#   - Fixed: double executor.shutdown() on KeyboardInterrupt path replaced
#     with a single _cancelled-flag pattern in the finally block.
#   - Fixed: fetch_wikipedia_table() used hard-coded column names
#     ('Ticker symbol'/'Symbol', 'Company'/'Security') that would silently
#     KeyError if Wikipedia restructures the table. Replaced with flexible
#     contains-based detection; raises a clear ValueError with the actual
#     column names if no match is found.
#
# v8 CHANGES vs v7 (Stage 2 redesign — mirrors mark_6_sp500_screener_v8;
# the AI is now a scored catalyst FILTER, not a free-form analyst/trade
# planner):
#   - The Gemini stage no longer decides entries or discusses technical
#     setups. Its sole job is to decide whether a company's FUNDAMENTAL
#     catalysts are strong enough to deserve technical (VCP) evaluation.
#     Pipeline is now a strict AND chain of three independent filters:
#         Stage 1  Trend Template (objective)        -> structural pass
#         Stage 2  AI Catalyst Evaluation (this file) -> CATALYST_SCORE >= 55
#         Stage 3  VCP Recognition Engine (separate   -> valid VCP setup
#                  VCPAnalyzer module, run downstream)
#   - Replaced the analyze_catalysts_with_gemini() prompt with the same
#     structured 100-point CATALYST SCORECARD used by the S&P 500 screener
#     (8 weighted categories, machine-readable `CATALYST_SCORE: NN` line).
#   - Model UNCHANGED: still gemini-2.5-flash, same retry/backoff logic.
#   - Added extract_catalyst_score() + CATALYST_SCORE_THRESHOLD = 60. A
#     missing/garbled score or an API-error string parses to 0 (< threshold),
#     so a failed evaluation REJECTS the ticker instead of slipping through.
#   - analyze_catalysts_with_gemini() no longer takes current_price /
#     high_20d (the fundamental-only prompt must not see price). The Stage 2
#     loop still prints those prices in its own header for the reader.
#   - Conditions 1-8, RS Rating, and the parallel scan: UNCHANGED.
#
# v8 tuning pass:
#   - TOP_N_CANDIDATES raised 3 -> 25 (wider funnel into Stages 2-3).
#   - CATALYST_SCORE_THRESHOLD lowered 60 -> 55.
#   - Gemini Stage-2 call now sends a deterministic config (temperature 0,
#     fixed seed, low thinking budget) so an identical company scores the
#     same across runs -- reproducible testing, fewer borderline gate flips.
#   - extract_catalyst_score() now takes the LAST CATALYST_SCORE match
#     (the authoritative final line) instead of the first.
#
# Robustness pass (running-right):
#   - GEMINI_MAX_OUTPUT_TOKENS = 2048 added to the Stage-2 config. On 2.5 the
#     thinking budget shares this allowance, so the cap sits well above
#     THINKING_BUDGET + the scorecard to avoid empty reply -> score 0 -> reject.
#   - check_minervini_technicals now splits its catch: expected data errors
#     (KeyError/IndexError/ValueError/TypeError) stay quiet, but any other
#     (unexpected) exception is printed loudly instead of being swallowed as a
#     silent non-match.
#   - RS_COVERAGE_MIN = 0.90 fetch-coverage guard: each run reports the scored
#     fraction of the universe and warns loudly if it drops below 90%, since RS
#     Rating is a percentile that distorts when many fetches fail silently.
#
# v9 (tooling + reliability pass):
#   - Lazy Gemini client: client/key load happen on first use, so --dry-run and
#     test_screeners.py import and run with no key present and no prompt.
#   - CLI: --limit N (scan first N tickers; fast plumbing test) and --dry-run
#     (skip all Gemini calls -- no quota, no wait) for cheap end-to-end checks.
#   - Run logging: every run tees stdout to runs/<screener>_<timestamp>.log.
#   - Stage-2 API-failure warning: counts calls that errored at the API and
#     warns that those score-0 rejections may be false (quota/rate-limit/SDK).
#   - GEMINI_MODEL constant centralizes the model string (value unchanged).
#   - PRICE CACHE: every good fetch is pickled to price_cache/; if Yahoo later
#     returns empty for a ticker, the last good copy (<= PRICE_CACHE_MAX_AGE_DAYS
#     old) is reused so a transient gap does not silently shrink the RS pool.
#   - test_screeners.py: regression harness asserting extract_catalyst_score()
#     and compute_rs_proxy() behave identically across all four screeners.
#
# v10 (batched free-tier AI filter + quota-aware retry):
#   - Stage 2 now scores candidates in BATCHES (STAGE2_BATCH_SIZE=10), one Gemini
#     call per batch: 30 candidates -> 3 calls/run, ~12/day across the four
#     screeners -- under the free-tier 20/day cap. Replaces per-stock calls.
#   - Compact output: one line per stock, TICKER | CATALYST_SCORE: NN | reason;
#     the CODE stamps [match]/[fail] at CATALYST_SCORE_THRESHOLD (55), so the
#     verdict always agrees with the gate. Only [match] advances to Stage 3.
#   - Truncation-safe: a stock missing from a batch reply is UNEVALUATED (never a
#     false 0/reject); extract_batch_scores() maps each score back by ticker.
#   - Quota-aware retry: a daily-quota 429 STOPS Stage 2 cleanly (rest left
#     unevaluated) instead of burning the cap on doomed retries; transient
#     429/503 retries honor the server's own suggested retry delay.
#   - Removed the now-unused single-stock analyze_catalysts_with_gemini().
#
# v10.1 (selective grounded re-score -- Stage 2c):
#   - After the ungrounded batch pass, high-RS rejects (RS >= GROUNDING_RS_FLOOR)
#     whose reason smells like stale knowledge ("not traded/acquired/defunct", or
#     a literal 0) are re-scored ONE per call with Google Search grounding
#     (tools=[{"google_search": {}}]) under a forced-search prompt.
#   - Verification gate: a grounded score is trusted ONLY if grounding_metadata
#     shows a search actually ran; otherwise the batch verdict stands. A grounded
#     score >= the gate prints RESCUED and advances to Stage 3.
#   - Token-light (one stock, 2048 cap, no extra thinking) and budget-capped
#     (MAX_GROUNDED_RESCORES, GROUNDING_ENABLED flag). Typically 0-2 calls/run.
#   - NOTE: API grounding may require billing; if the free tier rejects it, the
#     grounded call fails gracefully and the batch score is kept.

# =====================================================================
# v20 (HYBRID Stage 2: Python math floor + Gemini qualitative)
#   Python computes a 45-pt math floor (Earnings Accel /25 + Revenue Accel /20)
#   from real Finnhub -> yfinance fundamentals; Gemini scores ONLY the 55
#   qualitative points (cats 3-8) and may emit [KNOWLEDGE_GAP] -> grounded
#   lookup. CATALYST_SCORE = math(0-45) + qual(0-55); gate lowered 55 -> 40 so
#   elite EPS/revenue acceleration can pass on the numbers alone. The v10 Gemini
#   transport (batching, quota-aware retry, grounding) is UNCHANGED. Adds a
#   DataProxy + flat-OHLCV schema guardrail. Needs finnhub_key.txt (optional;
#   yfinance fallback). Stage 3 (the VCP recognition engine) is now WIRED IN --
#   it mirrors the sp500 screener: the catalyst-cleared names (stage2_passed) are
#   handed to run_stage3_vcp() / the inlined VCP engine, completing the Stage
#   1 -> 2 -> 3 AND chain. VCP makes no Gemini calls, so it runs even under
#   --dry-run. Final pick = Stage 1 AND Stage 2(>=40) AND VCP(>=VCP_SCORE_THRESHOLD,
#   80). Finnhub's free tier is US-centric, so for non-US
#   / Korean tickers the math floor often reads 'unavailable' and the screen
#   leans on the qualitative score (graceful degradation, never fabricated).
# =====================================================================
# =====================================================================
# v21 (suite version bump -- NO functional change in this file)
#   The four screeners are kept in lockstep. v21 exists only to restore a
#   missing 'def _looks_like_knowledge_gap(...)' header in the SP500 screener,
#   whose absence raised NameError mid-run at the Stage 2c call site. THIS
#   file already had the header, so it is identical to v20 apart from this note.
# =====================================================================
import os
import sys
import re
import time
import argparse
import logging
import threading
import concurrent.futures
import requests
import pandas as pd
import numpy as np
import yfinance as yf
from google import genai
from google.genai import types
from io import StringIO
from dataclasses import dataclass, field, replace

logging.getLogger('yfinance').setLevel(logging.CRITICAL)


# =====================================================================
# API KEY & CLIENT INITIALIZATION
# =====================================================================
# =====================================================================
# RUN LOGGING (tee stdout -> dated file so every run leaves a record)
# =====================================================================
class _Tee:
    """Duplicate writes to several streams (console + a run-log file).

    A stream that fails is DROPPED, never allowed to raise. Logging is a
    convenience; it must not be able to kill a screener run. The failure modes
    this actually protects against are real: a broken stdout pipe (the parent
    process dies, or the run is piped into something that exits early), a
    console-less process, and a file descriptor that has been redirected out
    from under the original stream -- which is how this was found, as
    `OSError: [WinError 6] The handle is invalid` from a bare `st.flush()`.
    """
    def __init__(self, *streams):
        self._streams = [s for s in streams if s is not None]

    def _each(self, op):
        dead = []
        for st in self._streams:
            try:
                op(st)
            except Exception:                 # noqa: BLE001 — see the docstring
                dead.append(st)
        if dead:
            self._streams = [s for s in self._streams if s not in dead]

    def write(self, data):
        self._each(lambda st: (st.write(data), st.flush()))
        return len(data)                      # file-like consumers expect a count

    def flush(self):
        self._each(lambda st: st.flush())

    def isatty(self):
        return any(getattr(s, "isatty", lambda: False)() for s in self._streams)


def _setup_run_log(prefix):
    """Tee stdout for this run into runs/<prefix>_<timestamp>.log.

    Best-effort in BOTH directions: an unopenable log leaves the run
    console-only, and a console stream that cannot be written is dropped by
    _Tee rather than crashing the screener.

    Tees onto the CURRENT sys.stdout, not sys.__stdout__: the original handle
    may have been redirected out from under the process, and a caller that has
    deliberately wrapped stdout should be respected, not bypassed.

    The file is opened BEFORE stdout is swapped, so if the open fails the error
    is reported on a stream that still works -- previously the handler's own
    print went through the half-installed tee and raised again.
    """
    original = sys.stdout
    try:
        os.makedirs("runs", exist_ok=True)
        path = os.path.join("runs", f"{prefix}_{time.strftime('%Y-%m-%d_%H%M%S')}.log")
        logf = open(path, "a", encoding="utf-8")
    except Exception as e:
        print(f"[log] could not open run log ({e}); continuing console-only.")
        return
    sys.stdout = _Tee(original, logf)
    print(f"[log] recording this run to {path}")


def _repo_root():
    # screeners/ lives one level under the repo root; anchoring on __file__
    # makes key lookup independent of the process's working directory
    # (PowerShell, PyCharm Run, Task Scheduler, cron all behave the same).
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def get_or_ask_api_key():
    # env (incl. .env at the REPO ROOT and cwd) > gemini_key.txt (repo root or
    # cwd) > prompt. Env keys never touch disk; a non-interactive console
    # (PyCharm Run / headless box) with no key fails CLOSED, never hangs.
    try:
        from kistrader.config import load_dotenv
        load_dotenv(os.path.join(_repo_root(), ".env"))
        load_dotenv()  # a cwd .env still works too
    except Exception:
        pass
    api_key = os.environ.get("GEMINI_API_KEY", "").strip()
    if api_key:
        return api_key
    for key_path in (os.path.join(_repo_root(), "gemini_key.txt"),
                     "gemini_key.txt"):
        if os.path.exists(key_path):
            with open(key_path, "r") as file:
                api_key = file.read().strip()
            if api_key:
                return api_key
    if not os.isatty(0):
        raise SystemExit("GEMINI_API_KEY not set (checked .env at repo root & "
                         "cwd) and no gemini_key.txt — refusing to prompt on a "
                         "non-interactive console (fail closed)")
    api_key = input("Paste your Gemini API Key: ").strip()
    with open(os.path.join(_repo_root(), "gemini_key.txt"), "w") as file:
        file.write(api_key)
    return api_key


# Lazy Gemini client: created (and the API key loaded) only on first use (the
# first Stage-2 batch call). Lets --dry-run and the test harness import and
# run this module with no key present and no interactive prompt.
_gemini_client = None


def _get_client():
    global _gemini_client
    if _gemini_client is None:
        _gemini_client = genai.Client(api_key=get_or_ask_api_key())
        try:
            os.chmod("gemini_key.txt", 0o600)  # restrict plaintext key to current user
        except Exception:
            pass
    return _gemini_client

# Tune this if you hit rate-limit errors from Yahoo Finance.
# 8 is a conservative default; set to 1 to fall back to fully sequential scanning.
MAX_WORKERS = 8
print_lock = threading.Lock()

# Classic Minervini/IBD cutoff for condition 8 (matches Group A's UI default).
# This is a PERCENTILE against the rest of THIS scan's universe (S&P 400/600),
# not against the full market the way IBD's real RS Rating is -- see the
# comment on compute_rs_proxy() below for what that does and doesn't mean.
RS_PROXY_THRESHOLD = 70

# Minimum fraction of the universe that must fetch + score for the RS Rating
# percentile to be trustworthy. Below this a run prints a loud WARNING that RS
# (the cond-8 gate AND the top-N selector) was computed over a shrunken,
# possibly biased population. Detection only -- it does not fix the fetch.
RS_COVERAGE_MIN = 0.90

# Stage 2 gate: minimum Gemini CATALYST_SCORE (out of 100) a company must earn
# to be passed downstream to the VCP engine (Stage 3). Below this, the AI
# catalyst filter rejects the ticker. Named here next to RS_PROXY_THRESHOLD
# so both gates stay easy to tune in one place.
# v20 hybrid: CATALYST_SCORE = Python math floor (0-45, cats 1-2 from real
# fundamentals) + Gemini qualitative (0-55, cats 3-8). Gate 40 sits BELOW the
# 45 math ceiling, so elite EPS/revenue acceleration can pass on numbers alone.
CATALYST_SCORE_THRESHOLD = 40

# How many Stage-1 passers (ranked by RS Rating) advance to the AI catalyst
# stage and then the VCP engine. This caps the number of Gemini calls per run
# -- the funnel's cost/throttle knob -- so it's the single value to raise for a
# wider candidate set (at the cost of more API calls + rate-limit wait). RS
# Rating intentionally does double duty here: it's cond_8 AND the selector that
# picks which passers reach Stages 2-3. 30 here, scored 10 per Gemini call
# (see STAGE2_BATCH_SIZE) = 3 calls/run -- a free-tier-friendly request count.
TOP_N_CANDIDATES = 30

# Stage 2 scores candidates in batches of this size in ONE Gemini call each, to
# stay under the free-tier daily request cap. 30 candidates / 10 = 3 calls.
# Smaller batches = less truncation risk and less "lost in the middle" drift.
STAGE2_BATCH_SIZE = 10

# --- Gemini Stage-2 determinism config -------------------------------------
# Stage 2 scores otherwise vary run-to-run because the model samples at a
# default temperature. These knobs make an identical company score identically
# across runs (reproducible testing; a borderline name won't randomly flip the
# gate). NOTE: even at temperature 0 + fixed seed, hosted Gemini is "mostly",
# not perfectly, deterministic, and "gemini-2.5-flash" is a moving alias Google
# can update. Requires a reasonably current google-genai SDK.
GEMINI_TEMPERATURE = 0        # 0 = greedy decoding (most reproducible)
GEMINI_SEED = 1234            # fixed seed -> repeatable sampling
GEMINI_THINKING_BUDGET = 512  # low = steadier + faster + cheaper; 0 disables
                              # thinking entirely; raise for deeper reasoning
GEMINI_MAX_OUTPUT_TOKENS = 2048  # response ceiling. MUST exceed THINKING_BUDGET
                                 # + the ~800-token scorecard: on 2.5 the thinking
                                 # tokens share this budget, so too low -> empty
                                 # reply -> score 0 -> ticker wrongly rejected.
GEMINI_MODEL = "gemini-2.5-flash"  # centralized; kept as the floating alias per
                                   # the project constraint. A dated string would
                                   # pin reproducibility but is intentionally not used.
GEMINI_CALL_SPACING = 12  # seconds between Stage-2 calls to respect PER-MINUTE
                          # limits. Lower it on a paid tier. NOTE: this does NOT
                          # help the PER-DAY request cap -- only billing does.
# Batched Stage-2 calls score ~10 stocks at once, so they need more room than a
# single-stock call. Thinking shares the output budget on 2.5, so the ceiling is
# set well above (thinking + ~10 compact lines). Both far under the 65k cap.
GEMINI_BATCH_THINKING_BUDGET = 2048
GEMINI_BATCH_MAX_OUTPUT_TOKENS = 8192

# ---- Stage 2c: selective grounded re-score of knowledge-gap anomalies ----
# After the ungrounded batch pass, a few high-RS candidates may be REJECTED on a
# stale-knowledge error (the model thinks a recent spin-off/IPO is defunct, like
# SNDK). Only those few get a per-stock Google-Search-grounded re-score, and only
# if the response metadata confirms a search actually ran. Token-light by design.
GROUNDING_ENABLED = True        # False = skip the grounded pass entirely
GROUNDING_RS_FLOOR = 80         # only re-ground strong technical candidates (RS >= this)
MAX_GROUNDED_RESCORES = 5       # hard cap per run; keeps the free-tier 20/day cap safe
GROUNDED_MAX_OUTPUT_TOKENS = 2048   # one stock, compact output -> far fewer tokens
# Reason phrases that smell like "the model thinks the company is gone" (a stale-
# knowledge false-reject) rather than a substantive weak-fundamentals rejection.
KNOWLEDGE_GAP_PHRASES = (
    "not a currently traded", "not currently traded", "no longer", "acquired",
    "defunct", "delisted", "merged", "ceased", "bankrupt", "no recent data",
    "unable to find", "not recognize", "unknown company", "no data", "private company",
    "does not exist", "no public", "not found",
)


# =====================================================================
# TECHNICAL SCANNER FUNCTIONS  (conditions 1-7: UNCHANGED LOGIC.
# Condition 8 upgraded from a binary "beat the benchmark" check to a real
# percentile RS Rating -- see check_minervini_technicals() and
# compute_rs_proxy() below.)
# =====================================================================
# =====================================================================
# PRICE CACHE  (last-good fallback so a transient Yahoo gap does not
# silently shrink the RS population -- pairs with RS_COVERAGE_MIN)
# =====================================================================
PRICE_CACHE_ENABLED = True
PRICE_CACHE_DIR = "price_cache"
PRICE_CACHE_MAX_AGE_DAYS = 5   # never fall back to prices older than this


def _cache_key(ticker):
    return "".join(c if (c.isalnum() or c in ".-") else "_" for c in str(ticker))


def _cache_save(ticker, data):
    """Best-effort: persist a good fetch so a later empty fetch can reuse it."""
    if not PRICE_CACHE_ENABLED:
        return
    try:
        os.makedirs(PRICE_CACHE_DIR, exist_ok=True)
        data.to_pickle(os.path.join(PRICE_CACHE_DIR, f"{_cache_key(ticker)}.pkl"))
    except Exception:
        pass  # caching must never break a scan


def _cache_load(ticker):
    """Return the last good cached history for `ticker`, or None if absent/too old."""
    if not PRICE_CACHE_ENABLED:
        return None
    try:
        path = os.path.join(PRICE_CACHE_DIR, f"{_cache_key(ticker)}.pkl")
        if not os.path.exists(path):
            return None
        age_days = (time.time() - os.path.getmtime(path)) / 86400.0
        if age_days > PRICE_CACHE_MAX_AGE_DAYS:
            return None  # too stale to trust
        df = pd.read_pickle(path)
        if df is not None and not df.empty:
            return df
    except Exception:
        return None
    return None


def _fetch_history(ticker, period, max_retries=3, retry_wait=2.0):
    """
    Shared fetch helper with real retry-on-failure.
    yfinance defaults to raise_errors=False, so most rate-limit / transient
    errors come back as an EMPTY DataFrame, not a raised exception. We retry
    on "None or empty", but NOT on "valid response that's just short" (e.g.
    a recent IPO with <200 days of history) -- that's a real answer, not a
    transient failure, so retrying it would only waste time.
    """
    data = None
    for attempt in range(max_retries):
        try:
            data = yf.Ticker(ticker).history(period=period, auto_adjust=True, timeout=10)
        except Exception:
            data = None
        if data is not None and not data.empty:
            flat = _enforce_flat_schema(data)        # guardrail: flat OHLCV or None
            if flat is not None:
                _cache_save(ticker, flat)            # cache the clean, enforced frame
                return flat
        if attempt < max_retries - 1:
            time.sleep(retry_wait)
    # Retries exhausted -> empty/None. Fall back to the last good cached copy so a
    # transient Yahoo gap does not silently drop this ticker from the RS pool.
    cached = _enforce_flat_schema(_cache_load(ticker))
    if cached is not None:
        print(f"    [cache] {ticker}: Yahoo returned empty; using cached prices from a recent run.", flush=True)
        return cached
    return None  # None/empty/unusable after retries, and no usable cache


def calculate_spy_6m_return():
    print("Calculating S&P 500 (SPY) 6-month baseline return...", flush=True)
    spy = _fetch_history('SPY', '6mo')
    # PATCH G -- which bar did this run actually receive? Before F3 turned the
    # regime gate off, "REGIME GATE: ... (bar YYYY-MM-DD)" carried this, and it
    # is how the yfinance publication-lag rate gets counted. That lag measured
    # 0.103 R of expectancy on 2026-08-25 (+0.3300 at lag 0 vs +0.2270 at
    # lag 1), so the measurement is worth keeping. This frame is already in
    # hand: no extra fetch.
    try:
        print("[data] newest SPY bar %s -- compare with the session date: one "
              "session back is the design, two is a publication delay"
              % spy.index[-1].date())
    except Exception:
        print("[data] newest SPY bar: UNREADABLE")
    try:
        close_vals = spy['Close'].dropna()
        return float((close_vals.iloc[-1] - close_vals.iloc[0]) / close_vals.iloc[0])
    except Exception:
        return 0.096  # Fallback


def _lookback_price(close, trading_days_back):
    """
    Defensive lookback for the RS-score windows below: clamps to the
    earliest available row instead of raising an IndexError. A ticker can
    reach this function with as few as 221 rows (the existing structural
    minimum for cond_3) -- well short of the 252 rows a full 12-month
    lookback wants -- so the 12-month leg gracefully falls back to "the
    oldest price we have" rather than crashing or forcing an artificially
    high length requirement that would reject perfectly normal stocks
    whose '1y' fetch came back at, say, 250-252 rows instead of 253+.
    """
    idx = max(0, len(close) - 1 - trading_days_back)
    return close.iloc[idx]


def compute_rs_proxy(raw_score_by_ticker):
    """
    Converts each ticker's raw weighted-return score into an IBD-style 1-99
    percentile RS Rating, ranked against every OTHER ticker that was
    successfully scored in this same scan -- not just the ones that already
    passed conditions 1-7. RS Rating is meant to describe a stock's price
    strength relative to its peer universe independent of the other
    Minervini conditions, so the percentile has to be computed across the
    full scored population first; only then does "RS Rating >= 70" become
    condition 8. This can only run once every ticker has a score, which is
    why it happens after run_parallel_scan's main loop, not inside it.

    Caveat worth knowing: this ranks against the S&P 400/600 names that
    were actually scanned, not IBD's full multi-thousand-stock database, so
    the percentile is "strongest within the mid/small-cap universe" rather
    than "strongest in the entire market." For an index-membership scanner
    like this one, that's arguably the more useful comparison anyway.
    """
    if not raw_score_by_ticker:
        return {}
    tickers = list(raw_score_by_ticker.keys())
    scores = pd.Series([raw_score_by_ticker[t] for t in tickers], index=tickers)
    pct = scores.rank(pct=True, method='average') * 100
    return pct.round().clip(lower=1, upper=99).astype(int).to_dict()


def check_minervini_technicals(ticker):
    """
    Conditions 1-7 (price/SMA/52-week structure): same formulas and
    thresholds as the original script, untouched. Returns `structural_pass`
    (conditions 1-7 only) and `raw_rs_score` (this ticker's own weighted-
    return score, not yet a percentile). The RS Rating >= 70 gate (condition
    8) is applied afterward in run_parallel_scan(), once compute_rs_proxy()
    has seen every score.
    """
    data = _fetch_history(ticker, '1y')

    if data is None or data.empty:
        return False, None, None, None, None, "fetch_failed"

    # 221, not 200: sma_200_20d_ago = rolling(200).mean().iloc[-21] only
    # becomes a real (non-NaN) value once there are >= 220 rows, since
    # rolling(200) itself only starts producing values at row index 199.
    # At exactly 200 rows, iloc[-21] points at index 179 -- still NaN --
    # so cond_3 (sma_200 > sma_200_20d_ago) silently evaluates to False
    # for every stock with 200-220 days of history (e.g. recent IPOs/
    # spinoffs), with no error or warning. 221 leaves a 1-day margin.
    if len(data) < 221:
        return False, None, None, None, None, "insufficient_history"

    try:
        close = data['Close'].dropna().squeeze()
        high = data['High'].dropna().squeeze()
        low = data['Low'].dropna().squeeze()

        sma_50 = close.rolling(window=50).mean().iloc[-1]
        sma_150 = close.rolling(window=150).mean().iloc[-1]
        sma_200 = close.rolling(window=200).mean().iloc[-1]
        sma_200_20d_ago = close.rolling(window=200).mean().iloc[-21]

        current_price = close.iloc[-1]
        low_52wk = low.min()
        high_52wk = high.max()
        stock_6m_return = (close.iloc[-1] - close.iloc[-126]) / close.iloc[-126]

        cond_1 = current_price > sma_150 and current_price > sma_200
        cond_2 = sma_150 > sma_200
        cond_3 = sma_200 > sma_200_20d_ago
        cond_4 = sma_50 > sma_150 and sma_50 > sma_200
        cond_5 = current_price > sma_50
        cond_6 = current_price >= (low_52wk * 1.30)
        cond_7 = current_price >= (high_52wk * 0.75)

        structural_pass = all([cond_1, cond_2, cond_3, cond_4, cond_5, cond_6, cond_7])
        high_20d = high.tail(20).max()

        # IBD-style segmental RS raw score: each term covers exactly one
        # 3-month window so no quarter bleeds into another. Q4 (most recent)
        # gets 40%; Q3/Q2/Q1 (older quarters) 20% each. The previous version
        # used cumulative ratios (all anchored to p_now), which caused a
        # strong last quarter to inflate the 6m, 9m, and 12m terms as well.
        p_now = close.iloc[-1]
        p_3m = _lookback_price(close, 63)
        p_6m = _lookback_price(close, 126)
        p_9m = _lookback_price(close, 189)
        p_12m = _lookback_price(close, 252)
        raw_rs_score = (0.4 * (p_now / p_3m) +    # Q4: last 3 months
                        0.2 * (p_3m  / p_6m) +    # Q3: 3–6 months ago
                        0.2 * (p_6m  / p_9m) +    # Q2: 6–9 months ago
                        0.2 * (p_9m  / p_12m))    # Q1: 9–12 months ago

        return structural_pass, current_price, high_20d, stock_6m_return, raw_rs_score, "ok"
    except (KeyError, IndexError, ValueError, TypeError):
        # expected when price data is short/malformed -> just not a match
        return False, None, None, None, None, "calc_error"
    except Exception as e:
        # anything else is probably a real bug -- surface it, do not hide it
        print(f"    [UNEXPECTED] {ticker}: {type(e).__name__}: {e}", flush=True)
        return False, None, None, None, None, "unexpected_error"


def extract_catalyst_score(text):
    """
    Pulls the integer catalyst score out of Gemini's response. The prompt
    instructs the model to finish with:

        CATALYST_SCORE: 82

    Returns 0 when the line is missing or unparseable -- which includes the
    "API Error: ..." strings the Stage-2 scorers return on failure. Since 0 is below CATALYST_SCORE_THRESHOLD, a failed or malformed
    evaluation safely REJECTS the ticker rather than letting it slip through.
    """
    matches = re.findall(r"CATALYST_SCORE:\s*(\d+)", text)
    if matches:
        return int(matches[-1])
    return 0


def _parse_retry_delay(error_msg, default):
    """Best-effort: read the server's suggested wait (seconds) out of a 429 body,
    e.g. "Please retry in 39.8s" or "retryDelay': '39s'". Falls back to `default`."""
    m = re.search(r"retry in ([\d.]+)s", error_msg) or re.search(r"retryDelay['\"]?\s*:?\s*['\"]?(\d+)\s*s", error_msg)
    if m:
        try:
            return min(120, int(float(m.group(1))) + 2)  # small cushion, hard-capped
        except Exception:
            pass
    return default


# =====================================================================
# DATA-SCHEMA GUARDRAIL + FUNDAMENTALS + MATH FLOOR  (Stage 2 cats 1-2)
# =====================================================================
_OHLCV = ["Open", "High", "Low", "Close", "Volume"]


def _enforce_flat_schema(df):
    """Flatten a MultiIndex, repair column case, return exactly
    [Open,High,Low,Close,Volume] -- or None if unusable. Lets downstream code
    assume a clean OHLCV frame."""
    if df is None or len(df) == 0:
        return None
    try:
        if isinstance(df.columns, pd.MultiIndex):
            df = df.copy()
            df.columns = df.columns.get_level_values(0)
        lower = {str(c).lower(): c for c in df.columns}
        cols = []
        for want in _OHLCV:
            src = lower.get(want.lower())
            if src is None:
                return None
            cols.append(src)
        out = df[cols].copy()
        out.columns = _OHLCV
        return out
    except Exception:
        return None


# Hybrid Stage 2: Python computes the 45-pt math floor (Earnings Acceleration /25
# + Revenue Acceleration /20) from REAL fundamentals; Gemini scores only the 55
# qualitative points. Finnhub primary (clean quarterly EPS actuals + surprises on
# the free tier), yfinance fallback per field. Fail-safe: any error returns None
# for that field, the floor degrades to what's computable, and a fully-missing
# stock gets math=0 (still passable on qual >= 40/55; never fabricated).
# Finnhub's free tier is US-centric -- non-US/Korean tickers will often miss.
FINNHUB_KEY_FILE = "finnhub_key.txt"
FINNHUB_BASE = "https://finnhub.io/api/v1"
FINNHUB_MIN_SPACING = 1.1
FUND_CACHE_DIR = "fundamentals_cache"
# --- PATCH AG (P3.2) --- the append-only twin of the cache above. The cache is
# overwritten every run and is the LIVE read path; the archive is written once
# per ticker per session and is never read by anything here. It exists so that
# `available_date` can be derived later from first appearance, which is the only
# honest source for it that does not cost an extra API call.
FUND_ARCHIVE_DIR = "fundamentals_archive"
FUND_SCHEMA_VERSION = 1
_FUND_LEGACY_WARNED = [False]


def _warn_legacy_fund_cache():
    """Say it once. A legacy record is not an error -- it is a record written
    before the stamp existed -- but the operator must know the weaker rule is
    in force for it."""
    if not _FUND_LEGACY_WARNED[0]:
        _FUND_LEGACY_WARNED[0] = True
        print("[fundamentals] legacy cache record has no as_of -- falling back "
              "to file mtime, which RESETS on any copy (cp/scp/rsync/deploy) "
              "and makes a stale record look FRESH. Re-fetch to stamp them.")
# --- end PATCH AG (P3.2) ---
FUND_CACHE_MAX_AGE_DAYS = 1

EPS_GROWTH_PTS   = 12.0
EPS_ACCEL_PTS    = 8.0
EPS_SURPRISE_PTS = 5.0      # Earnings Acceleration /25
REV_GROWTH_PTS   = 12.0
REV_ACCEL_PTS    = 8.0      # Revenue Acceleration /20
EPS_FULL_GROWTH_PCT = 0.25  # full EPS-growth pts at +25% YoY (Minervini bar)
REV_FULL_GROWTH_PCT = 0.20  # lower: sustained 25% revenue growth is rarer
SURPRISE_FULL_PCT   = 0.05  # full surprise pts at +5% average beat


def _read_finnhub_key():
    # env (incl. .env at repo root & cwd) > finnhub_key.txt (repo root or cwd).
    # Missing key keeps the graceful fallback (math floor uses yfinance).
    try:
        from kistrader.config import load_dotenv
        load_dotenv(os.path.join(_repo_root(), ".env"))
        load_dotenv()
    except Exception:
        pass
    k = os.environ.get("FINNHUB_API_KEY", "").strip()
    if k:
        return k
    for key_path in (os.path.join(_repo_root(), FINNHUB_KEY_FILE),
                     FINNHUB_KEY_FILE):
        try:
            with open(key_path) as f:
                v = f.read().strip()
                if v:
                    return v
        except Exception:
            pass
    return None


def _yoy_growth(series, i):
    """YoY growth of quarter i vs i+4 (most-recent-first). None if not computable
    or if the year-ago base <= 0 (gives EPS its profitability guard for free)."""
    if series is None or len(series) <= i + 4:
        return None
    cur, prior = series[i], series[i + 4]
    if cur is None or prior is None or prior <= 0:
        return None
    return (cur - prior) / abs(prior)


def _growth_and_accel_points(series, full_pct, growth_pts, accel_pts):
    """Growth (linear 0->full_pct) + acceleration (full if the YoY growth rate
    rose 2 consecutive quarters, half for 1). Returns (growth, accel, latest_g)."""
    g0, g1, g2 = _yoy_growth(series, 0), _yoy_growth(series, 1), _yoy_growth(series, 2)
    gp = 0.0 if g0 is None else max(0.0, min(1.0, g0 / full_pct)) * growth_pts
    ap = 0.0
    if g0 is not None and g1 is not None and g0 > g1:
        ap = accel_pts if (g2 is not None and g1 > g2) else accel_pts * 0.5
    return gp, ap, g0


def _surprise_points(surprises, full_pct, pts):
    """Average of up to 4 recent EPS surprises (fractions); positive beats earn
    points scaled to full at SURPRISE_FULL_PCT."""
    if not surprises:
        return 0.0
    recent = surprises[:4]
    avg = sum(recent) / len(recent)
    if avg <= 0:
        return 0.0
    return max(0.0, min(1.0, avg / full_pct)) * pts


def compute_math_floor(fund):
    """Map normalized fundamentals to the 0-45 math floor (cats 1-2). Pure
    function; missing metrics contribute 0; empty fund -> 0 + math_available=False."""
    if not fund:
        return 0.0, {'math_available': False, 'math_score': 0.0, 'source': None}
    eps = fund.get('eps') or []
    rev = fund.get('revenue') or []
    sur = fund.get('eps_surprises') or []
    eps_gp, eps_ap, eps_g0 = _growth_and_accel_points(eps, EPS_FULL_GROWTH_PCT, EPS_GROWTH_PTS, EPS_ACCEL_PTS)
    eps_sp = _surprise_points(sur, SURPRISE_FULL_PCT, EPS_SURPRISE_PTS)
    rev_gp, rev_ap, rev_g0 = _growth_and_accel_points(rev, REV_FULL_GROWTH_PCT, REV_GROWTH_PTS, REV_ACCEL_PTS)
    cat1 = eps_gp + eps_ap + eps_sp
    cat2 = rev_gp + rev_ap
    total = round(min(cat1, 25.0) + min(cat2, 20.0), 2)
    return total, {
        'math_available': bool(eps or rev),
        'math_score':     total,
        'cat1_earnings':  round(min(cat1, 25.0), 2),
        'cat2_revenue':   round(min(cat2, 20.0), 2),
        'eps_growth':     None if eps_g0 is None else round(eps_g0, 4),
        'rev_growth':     None if rev_g0 is None else round(rev_g0, 4),
        'source':         fund.get('source'),
    }


def _fund_cache_key(ticker):
    return "".join(c if (c.isalnum() or c in ".-") else "_" for c in str(ticker))


class DataProxy:
    """Fundamentals front door: Finnhub primary -> yfinance fallback per field,
    light rate guard, 1-day disk cache, total fail-safety. history() is a
    schema-enforced convenience fetch (Stage 2 only calls fundamentals())."""
    def __init__(self):
        self._finnhub_key = _read_finnhub_key()
        self._last_finnhub = 0.0

    def history(self, ticker, period):
        try:
            return _enforce_flat_schema(yf.Ticker(ticker).history(period=period, auto_adjust=True))
        except Exception:
            return None

    def fundamentals(self, ticker):
        cached = self._fund_cache_load(ticker)
        if cached is not None:
            return cached
        fund = {'eps': [], 'revenue': [], 'eps_surprises': [], 'source': None}
        self._finnhub_eps(ticker, fund)
        self._yf_revenue(ticker, fund)
        if not fund['eps']:
            self._yf_eps(ticker, fund)
        if not fund['revenue']:
            self._finnhub_revenue(ticker, fund)
        if fund['eps'] or fund['revenue']:
            self._fund_cache_save(ticker, fund)
            return fund
        return None

    def _finnhub_throttle(self):
        dt = time.time() - self._last_finnhub
        if dt < FINNHUB_MIN_SPACING:
            time.sleep(FINNHUB_MIN_SPACING - dt)
        self._last_finnhub = time.time()

    def _finnhub_eps(self, ticker, fund):
        if not self._finnhub_key:
            return
        try:
            self._finnhub_throttle()
            r = requests.get(FINNHUB_BASE + "/stock/earnings",
                             params={"symbol": ticker, "token": self._finnhub_key}, timeout=10)
            if r.status_code != 200:
                return
            rows = r.json()
            if not isinstance(rows, list) or not rows:
                return
            rows = sorted(rows, key=lambda d: (d.get('year', 0), d.get('quarter', 0)), reverse=True)
            eps = [float(d['actual']) for d in rows if d.get('actual') is not None]
            sur = [float(d['surprisePercent']) / 100.0 for d in rows if d.get('surprisePercent') is not None]
            # --- PATCH AG (P3.2) --- `period` was always in this response and
            # always discarded. Kept as a PARALLEL list so fund['eps'] stays a
            # plain [float] and compute_math_floor / _yoy_growth / harness S7
            # see no change whatsoever. This is period END, not availability --
            # availability is not in this endpoint and is never invented.
            fund['eps_periods'] = [str(d.get('period') or '') for d in rows
                                   if d.get('actual') is not None]
            # --- end PATCH AG (P3.2) ---
            if eps:
                fund['eps'] = eps
                fund['source'] = 'finnhub'
            if sur:
                fund['eps_surprises'] = sur
        except Exception:
            return

    def _finnhub_revenue(self, ticker, fund):
        if not self._finnhub_key:
            return
        try:
            self._finnhub_throttle()
            r = requests.get(FINNHUB_BASE + "/stock/metric",
                             params={"symbol": ticker, "metric": "all", "token": self._finnhub_key}, timeout=10)
            if r.status_code != 200:
                return
            series = (r.json().get("series") or {}).get("quarterly") or {}
            for k in ("revenuePerShare", "salesPerShare"):   # per-share proxy: growth is a ratio
                arr = series.get(k)
                if isinstance(arr, list) and arr:
                    arr = sorted(arr, key=lambda d: d.get("period", ""), reverse=True)
                    vals = [float(d["v"]) for d in arr if d.get("v") is not None]
                    # --- PATCH AG (P3.2) --- this list was ALREADY sorted on
                    # d["period"] one line above; the key was used and thrown
                    # away. Parallel list, same order, same reason as eps.
                    fund['revenue_periods'] = [str(d.get("period") or "")
                                               for d in arr
                                               if d.get("v") is not None]
                    # --- end PATCH AG (P3.2) ---
                    if vals:
                        fund['revenue'] = vals
                        fund['source'] = fund['source'] or 'finnhub'
                        return
        except Exception:
            return

    def _yf_revenue(self, ticker, fund):
        try:
            df = yf.Ticker(ticker).quarterly_income_stmt
            if df is None or df.empty:
                return
            for label in ("Total Revenue", "TotalRevenue", "Revenue", "OperatingRevenue"):
                if label in df.index:
                    row = df.loc[label].sort_index(ascending=False)
                    vals = [float(v) for v in row.values if pd.notna(v)]
                    if vals:
                        fund['revenue'] = vals
                        fund['source'] = fund['source'] or 'yfinance'
                    return
        except Exception:
            return

    def _yf_eps(self, ticker, fund):
        try:
            df = yf.Ticker(ticker).quarterly_income_stmt
            if df is None or df.empty:
                return
            for label in ("Diluted EPS", "Basic EPS", "DilutedEPS", "BasicEPS"):
                if label in df.index:
                    row = df.loc[label].sort_index(ascending=False)
                    vals = [float(v) for v in row.values if pd.notna(v)]
                    if vals:
                        fund['eps'] = vals
                        fund['source'] = fund['source'] or 'yfinance'
                    return
        except Exception:
            return

    def _fund_cache_save(self, ticker, fund):
        try:
            os.makedirs(FUND_CACHE_DIR, exist_ok=True)
            import json
            # --- PATCH AG (P3.2) --- stamp the record with its own date. The
            # previous version relied on file mtime, which resets on any copy
            # and therefore failed OPEN: a stale record looked fresh.
            import datetime as _dtm
            _now = _dtm.datetime.now(_dtm.timezone.utc)
            doc = dict(fund)
            doc["schema"] = FUND_SCHEMA_VERSION
            doc["as_of"] = _now.date().isoformat()
            doc["fetched_at"] = _now.replace(microsecond=0).isoformat()
            _key = _cache_key(ticker)
            # --- end PATCH AG (P3.2) ---
            with open(os.path.join(FUND_CACHE_DIR, _fund_cache_key(ticker) + ".json"), "w") as f:
                json.dump(doc, f)
            # --- PATCH AG (P3.2) --- append-only archive. WRITE ONCE: a re-run
            # on the same day must never mutate history, so an existing file is
            # left exactly as it is. Monthly subdirectories because a full
            # universe over a year is ~378,000 files.
            _adir = os.path.join(FUND_ARCHIVE_DIR, doc["as_of"][:7])
            os.makedirs(_adir, exist_ok=True)
            _apath = os.path.join(_adir, f"{_key}-{doc['as_of']}.json")
            if not os.path.exists(_apath):
                with open(_apath, "w") as f:
                    json.dump(doc, f)
            # --- end PATCH AG (P3.2) ---
        except Exception:
            pass

    def _fund_cache_load(self, ticker):
        try:
            path = os.path.join(FUND_CACHE_DIR, _fund_cache_key(ticker) + ".json")
            if not os.path.exists(path):
                return None
            import json
            with open(path) as f:
                doc = json.load(f)
            # --- PATCH AG (P3.2) --- as_of is AUTHORITATIVE; mtime is the
            # fallback for records written before the stamp existed, and it is
            # announced because it fails OPEN (any copy resets it forward, and a
            # stale record then reads as fresh).
            _as_of = doc.get("as_of") if isinstance(doc, dict) else None
            if _as_of:
                import datetime as _dtm
                _age = (_dtm.datetime.now(_dtm.timezone.utc).date()
                        - _dtm.date.fromisoformat(str(_as_of))).days
            else:
                _age = (time.time() - os.path.getmtime(path)) / 86400.0
                _warn_legacy_fund_cache()
            # --- PATCH AJ (daily archive) --- >= not >. AG turned a float
            # age into an integer day count and kept `>`, so a record written
            # yesterday is exactly 1 day old, 1 > 1 is False, and the cache HITS.
            # Measured 2026-09-08: screener ran, fetched nothing, wrote no
            # archive row. The archive is the whole point of AG and it was
            # capturing every other session. The legacy float branch is
            # unaffected: 0.5 >= 1 is still False.
            if _age >= FUND_CACHE_MAX_AGE_DAYS:
                return None
            return doc
            # --- end PATCH AG (P3.2) ---
        except Exception:
            return None


DATA = DataProxy()


# =====================================================================
# BATCHED AI CATALYST EVALUATOR  (free-tier friendly: scores ~10 stocks per
# Gemini call instead of one, cutting requests ~10x. Each company is one line --
# TICKER | CATALYST_SCORE: NN | reason -- so scores map back to tickers, and a
# stock missing from a (possibly truncated) reply is UNEVALUATED, never a 0.)
# =====================================================================
def analyze_catalysts_batch(stocks):
    """
    Score a batch of companies in ONE call. `stocks` is a list of
    (ticker, company_name). Returns the raw response text, or "QUOTA_EXHAUSTED"
    / "API Error: ..." on failure. Same determinism config + quota/retry handling
    as the single-stock path, just a bigger output budget.
    """
    roster = "\n".join(f"- {t}: {n}" for t, n in stocks)
    tickers = ", ".join(t for t, _ in stocks)
    prompt = f"""You are an expert growth-stock analyst specializing in Mark Minervini's SEPA methodology.

Categories 1-2 (Earnings Acceleration /25 and Revenue Acceleration /20) are
PRE-COMPUTED by our system from hard financial data. Do NOT score, estimate, or
mention them. You score ONLY the 55 QUALITATIVE points below.

Score EACH company INDEPENDENTLY against this fixed 55-point qualitative rubric
-- do NOT grade them relative to one another; a strong company must not inflate a
weak one, or vice versa. The per-company QUAL_SCORE is the sum of these:
3. Positive Forward Guidance ... /15  (guidance, outlook, analyst revisions)
4. New Product / Innovation .... /10  (launches, tech leadership, competitive edge)
5. Industry Tailwinds .......... /10  (sector strength, macro trends, demand)
6. Institutional Interest ...... /10  (ownership, accumulation, sponsorship)
7. Management / Capital Alloc .. /5   (capital allocation, execution, discipline)
8. Other Significant Catalysts . /5

Rules:
- Be objective and conservative. Never invent information. Unknown info scores low.
- If you genuinely LACK current data on a company (possible recent IPO, spin-off,
  merger, or rename your training may not cover), output [KNOWLEDGE_GAP] in place
  of the number rather than guessing or scoring 0 -- we will look it up live.

Companies ({len(stocks)}):
{roster}

For EACH company output EXACTLY ONE line and nothing else -- no headers, no blank
lines, no extra prose before or after:

<TICKER> | QUAL_SCORE: <integer 0-55 OR [KNOWLEDGE_GAP]> | <reason, 10 words max>

Required format, one line per company (example):
AMD | QUAL_SCORE: 41 | strong AI-GPU demand, raised guidance
NEWCO | QUAL_SCORE: [KNOWLEDGE_GAP] | unfamiliar -- needs live lookup

Output exactly one such line for each of the {len(stocks)} companies, in order: {tickers}
"""
    max_retries = 3
    for attempt in range(max_retries):
        try:
            response = _get_client().models.generate_content(
                model=GEMINI_MODEL,
                contents=prompt,
                config=types.GenerateContentConfig(
                    temperature=GEMINI_TEMPERATURE,
                    seed=GEMINI_SEED,
                    max_output_tokens=GEMINI_BATCH_MAX_OUTPUT_TOKENS,
                    thinking_config=types.ThinkingConfig(thinking_budget=GEMINI_BATCH_THINKING_BUDGET),
                ),
            )
            time.sleep(GEMINI_CALL_SPACING)
            return response.text
        except Exception as e:
            error_msg = str(e)
            low = error_msg.lower()
            if "resource_exhausted" in low and "perday" in low:
                return "QUOTA_EXHAUSTED"
            if "503" in error_msg or "429" in error_msg or "unavailable" in low:
                if attempt < max_retries - 1:
                    wait = _parse_retry_delay(error_msg, 30)
                    print(f"    [!] Transient API throttle (attempt {attempt + 1}/{max_retries}); "
                          f"waiting {wait}s before retry...")
                    time.sleep(wait)
                    continue
                return "API Error: Server persistently unavailable after retries."
            return f"API Error: {error_msg[:300]}"
    return "API Error: exhausted retries."


def extract_batch_scores(text):
    """
    Parse a batched reply into {TICKER_UPPER: (score, reason)}. Each company is
    one line:  TICKER | CATALYST_SCORE: NN | reason. Tickers absent from the reply
    (e.g. a truncated batch) simply won't appear -- the caller treats those as
    UNEVALUATED, never a 0/reject. Robust to stray prose/thinking: it scans for
    the pipe-delimited pattern anywhere, not only at line starts.
    """
    out = {}
    pat = re.compile(
        r"([A-Za-z0-9.\-]{1,12})\s*\|\s*CATALYST_SCORE:\s*(\d+)\s*\|\s*([^\n|]*)"
    )
    for tk, sc, reason in pat.findall(text):
        out[tk.upper()] = (int(sc), reason.strip())
    return out


def extract_batch_qual(text):
    """Parse a hybrid batch reply into {TICKER_UPPER: (qual, reason)} where qual is
    an int 0-55 OR the sentinel 'GAP' for [KNOWLEDGE_GAP]. Tickers absent from the
    reply won't appear (caller treats as UNEVALUATED). Scans anywhere in the text."""
    out = {}
    pat = re.compile(
        r"([A-Za-z0-9.\-]{1,12})\s*\|\s*QUAL_SCORE:\s*"
        r"(\[KNOWLEDGE_GAP\]|\d+)\s*\|\s*([^\n|]*)"
    )
    for tk, val, reason in pat.findall(text):
        qual = 'GAP' if val.strip().upper().startswith('[KNOW') else int(val)
        out[tk.upper()] = (qual, reason.strip())
    return out


def _looks_like_knowledge_gap(score, reason, rs):
    """True for a REJECTED, high-RS candidate whose reason smells like the model
    thinks the company is gone (stale training) rather than a substantive weak-
    fundamentals call -- i.e. worth a grounded second look. SNDK ('not a currently
    traded company', score 0, RS 99) -> True; DD ('modest earnings...', 42) -> False."""
    if score >= CATALYST_SCORE_THRESHOLD:
        return False                      # it passed; not an anomaly
    if rs < GROUNDING_RS_FLOOR:
        return False                      # weak technical name; not worth a grounded call
    r = (reason or "").lower()
    if any(p in r for p in KNOWLEDGE_GAP_PHRASES):
        return True
    if score == 0:                        # a literal 0 on a high-RS name usually = "don't know it"
        return True
    return False


def reground_one(ticker, name):
    """Re-score ONE flagged stock WITH Google Search grounding, forcing a live
    lookup. Returns (text, searched): `searched` is True only when the response
    metadata shows a real search ran -- so we never trust a 'grounded' answer the
    model actually pulled from stale memory (the exact trap that batched grounding
    falls into). Token-light: one stock, compact output, no extra thinking budget.
    Returns ('QUOTA_EXHAUSTED', False) / ('API Error: ...', False) on failure."""
    prompt = f"""You are scoring ONE company on the QUALITATIVE half of Mark Minervini SEPA catalysts.

Company: {ticker} -- {name}

You MUST use Google Search to look up this company's CURRENT trading status and its
MOST RECENT quarterly results before scoring. Do NOT rely on prior knowledge -- your
training may be out of date (recent spin-offs, IPOs, mergers, or renames). If the
company is currently and actively traded, score it on its real fundamentals even if
it is new to you; do not score it low merely because you do not recognize it.

Categories 1-2 (earnings & revenue acceleration) are pre-computed by our system --
do NOT score them. Score ONLY the 55 QUALITATIVE points:
guidance (15) + product/innovation (10) + industry tailwinds (10) +
institutional interest (10) + management (5) + other (5).

Output EXACTLY one line, nothing else:
{ticker} | QUAL_SCORE: <0-55> | <reason, 12 words max>
"""
    max_retries = 3
    for attempt in range(max_retries):
        try:
            response = _get_client().models.generate_content(
                model=GEMINI_MODEL,
                contents=prompt,
                config=types.GenerateContentConfig(
                    temperature=GEMINI_TEMPERATURE,
                    seed=GEMINI_SEED,
                    max_output_tokens=GROUNDED_MAX_OUTPUT_TOKENS,
                    tools=[{"google_search": {}}],   # google-genai dict form; new SDK
                ),
            )
            time.sleep(GEMINI_CALL_SPACING)
            # Verify a search actually ran. For a single-stock call, any query is
            # for this stock, so non-empty web_search_queries == genuinely grounded.
            searched = False
            try:
                gm = response.candidates[0].grounding_metadata
                searched = bool(gm and getattr(gm, "web_search_queries", None))
            except Exception:
                searched = False
            return response.text, searched
        except Exception as e:
            error_msg = str(e)
            low = error_msg.lower()
            if "resource_exhausted" in low and "perday" in low:
                return "QUOTA_EXHAUSTED", False
            if "503" in error_msg or "429" in error_msg or "unavailable" in low:
                if attempt < max_retries - 1:
                    wait = _parse_retry_delay(error_msg, 30)
                    print(f"    [!] Transient throttle on grounded call (attempt {attempt + 1}/"
                          f"{max_retries}); waiting {wait}s...")
                    time.sleep(wait)
                    continue
                return "API Error: grounded call unavailable after retries.", False
            # A common first-run case: grounding may be rejected on the free API tier.
            return f"API Error: {error_msg[:300]}", False
    return "API Error: grounded call exhausted retries.", False


# =====================================================================
# UNIVERSE LOADER  (sources unchanged: S&P 400 + S&P 600 from Wikipedia)
# =====================================================================
def _fetch_url_with_retry(url, headers=None, timeout=20, max_retries=3, retry_wait=2.0):
    """
    Retry wrapper for plain HTTP fetches (universe data). Unlike yfinance,
    requests.get() raises a real exception on failure/timeout rather than
    silently returning empty data, so straightforward exception-based retry
    is sufficient here.
    """
    last_err = None
    for attempt in range(max_retries):
        try:
            response = requests.get(url, headers=headers, timeout=timeout)
            response.raise_for_status()
            return response
        except Exception as e:
            last_err = e
            if attempt < max_retries - 1:
                time.sleep(retry_wait)
    raise last_err


def fetch_wikipedia_table(url, headers):
    response = _fetch_url_with_retry(url, headers=headers, timeout=20)
    df = pd.read_html(StringIO(response.text))[0]
    # Flexible column detection: Wikipedia table headers change without
    # notice. Previously hard-coded 'Ticker symbol'/'Symbol' and
    # 'Company'/'Security', which would KeyError silently on restructure.
    sym_col = next((c for c in df.columns
                    if any(k in str(c).lower() for k in ('ticker', 'symbol'))), None)
    sec_col = next((c for c in df.columns
                    if any(k in str(c).lower() for k in ('company', 'security', 'name'))), None)
    if not sym_col or not sec_col:
        raise ValueError(
            f"Could not identify ticker/company columns in Wikipedia table. "
            f"Found: {list(df.columns)}"
        )
    return dict(zip(df[sym_col], df[sec_col]))


def load_universe():
    print("Fetching S&P 400 and S&P 600 constituents databases from Wikipedia...", flush=True)
    universe = {}
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
    }

    sources = [
        ('S&P 400 (Mid-Cap)', 'https://en.wikipedia.org/wiki/List_of_S%26P_400_companies'),
        ('S&P 600 (Small-Cap)', 'https://en.wikipedia.org/wiki/List_of_S%26P_600_companies'),
    ]

    for label, url in sources:
        try:
            part = fetch_wikipedia_table(url, headers)
            universe.update(part)
            print(f"  [+] Loaded {label}: {len(part)} tickers", flush=True)
        except Exception as e:
            print(f"  [-] Failed to load {label}: {e}", flush=True)

    return universe


# =====================================================================
# PARALLEL SCAN WORKER
# =====================================================================
def _scan_one(ticker_raw):
    ticker_clean = str(ticker_raw).replace('.', '-')
    try:
        structural_pass, current_price, high_20d, ret, raw_rs_score, status = check_minervini_technicals(ticker_clean)
    except Exception:
        return ticker_raw, ticker_clean, False, None, None, None, None, "scan_error"
    return ticker_raw, ticker_clean, structural_pass, current_price, high_20d, ret, raw_rs_score, status


STATUS_LABELS = {
    "matched": "Matched conditions 1-7 AND RS Rating >= threshold",
    "structural_fail": "Failed one or more of conditions 1-7",
    "rs_proxy_below_threshold": f"Passed 1-7 but RS Rating < {RS_PROXY_THRESHOLD}",
    "insufficient_history": "Insufficient price history (<221 days)",
    "fetch_failed": "Data fetch failed (network/rate-limit)",
    "calc_error": "Calculation error",
    "scan_error": "Unexpected scan error",
}


def run_parallel_scan(tickers_list, universe, spy_return):
    total = len(tickers_list)
    print(f"[*] Scanning {total} stocks in parallel (workers={MAX_WORKERS})...\n", flush=True)

    scored = {}  # ticker_clean -> result dict, for tickers with usable data
    status_counts = {}
    scanned = 0

    executor = concurrent.futures.ThreadPoolExecutor(max_workers=MAX_WORKERS)
    futures = {executor.submit(_scan_one, t): t for t in tickers_list}
    _cancelled = False
    try:
        for future in concurrent.futures.as_completed(futures):
            # Recover the ticker from the futures map (always available, even
            # if .result() raises) rather than trusting the unpacked tuple --
            # loop variables persist across iterations in Python, so on
            # failure the old values from a *previous* ticker would otherwise
            # leak through silently.
            ticker_raw = futures[future]
            try:
                _, ticker_clean, structural_pass, current_price, high_20d, ret, raw_rs_score, status = future.result()
            except Exception:
                ticker_clean = str(ticker_raw).replace('.', '-')
                structural_pass = False
                current_price = high_20d = ret = raw_rs_score = None
                status = "scan_error"

            with print_lock:
                scanned += 1
                if status == "ok":
                    # Final pass/fail (and the [MATCH] print) can't happen
                    # yet -- RS Rating is a percentile, so it isn't known
                    # until every ticker has been scored. See the
                    # second-pass loop below, after the executor shuts down.
                    scored[ticker_clean] = {
                        "ticker_raw": ticker_raw,
                        "structural_pass": structural_pass,
                        "current_price": current_price,
                        "high_20d": high_20d,
                        "ret": ret,
                        "raw_rs_score": raw_rs_score,
                    }
                else:
                    status_counts[status] = status_counts.get(status, 0) + 1
                if scanned % 50 == 0 or scanned == total:
                    print(f"    ... scanned {scanned}/{total}", flush=True)
    except KeyboardInterrupt:
        _cancelled = True
        print("\n[!] Interrupted by user — cancelling remaining scans (already-found matches are kept)...", flush=True)
        raise
    finally:
        # Single shutdown on every exit path. _cancelled=True → cancel_futures
        # drops queued work immediately (fast Ctrl+C). Normal completion or any
        # other exception → wait=True ensures threads are done before the second
        # pass begins. Previously called shutdown() twice on the Ctrl+C path.
        executor.shutdown(wait=not _cancelled, cancel_futures=_cancelled)

    # --- Second pass (single-threaded, executor already shut down): rank
    # every successfully-scored ticker's raw RS score into a 1-99 percentile
    # RS Rating, THEN apply conditions 1-7 + RS Rating >= threshold together
    # to decide the final matches. This is the step that genuinely can't
    # happen per-ticker, in parallel, during the scan above. ---
    # --- Fetch-coverage guard: RS Rating is a percentile over the tickers that
    # actually fetched + scored. If many failed (silent empty yfinance results)
    # the population shrinks and every RS Rating -- the cond-8 gate AND the
    # top-N selector -- is computed over a smaller, possibly biased set. Make a
    # degraded run loud instead of silent. ---
    coverage = len(scored) / total if total else 0.0
    print(f"\n[i] RS population coverage: {len(scored)}/{total} ({coverage:.0%}) tickers scored.")
    if coverage < RS_COVERAGE_MIN:
        print(f"[!] WARNING: only {coverage:.0%} of the universe scored (< {RS_COVERAGE_MIN:.0%}). "
              f"RS Ratings are a percentile over this reduced set and may be distorted -- "
              f"treat today's matches with caution and consider re-running.")

    rs_proxies = compute_rs_proxy({t: r["raw_rs_score"] for t, r in scored.items()})

    passed_stocks = []
    for ticker_clean, r in scored.items():
        rs_proxy = rs_proxies.get(ticker_clean)
        if r["structural_pass"] and rs_proxy is not None and rs_proxy >= RS_PROXY_THRESHOLD:
            status_counts["matched"] = status_counts.get("matched", 0) + 1
            alpha = r["ret"] - spy_return
            print(f"  [MATCH] {ticker_clean:<6} RS Rating: {rs_proxy:3d}   6mo Return: {r['ret'] * 100:6.1f}%   Alpha vs SPY: {alpha * 100:+5.1f}%", flush=True)
            passed_stocks.append((ticker_clean, universe[r["ticker_raw"]], r["ret"],
                                   r["current_price"], r["high_20d"], rs_proxy, r["raw_rs_score"]))
        elif r["structural_pass"]:
            status_counts["rs_proxy_below_threshold"] = status_counts.get("rs_proxy_below_threshold", 0) + 1
        else:
            status_counts["structural_fail"] = status_counts.get("structural_fail", 0) + 1

    return passed_stocks, status_counts


# Stage 3 gate: minimum VCP score for a candidate to become a FINAL match.
# Final pick = Stage 1 AND Stage 2 AND VCP >= VCP_SCORE_THRESHOLD.
#
# DECLARED ONCE, in kistrader/entry/screen_contract.py, and read by BOTH
# screeners and the trader. Do not re-introduce a literal here: both screeners
# write the same candidates.csv, so a local value would screen half the universe
# at a bar nobody chose, with nothing reporting it.
def _load_vcp_threshold():
    """Resolve the ONE declaration of the Stage-3 VCP bar (screen_contract).

    Same two-invocation contract as _load_emitter():
      * `python -m screeners.<name>`  -> works from the repo root, no install
      * `python screeners\\<name>.py`  -> needs `pip install -e .`

    There is deliberately NO local fallback value. A fallback would let this
    screener run at a different bar from its sibling and from the trader, which
    is exactly the drift that moving the constant here removes. Fail closed and
    say how to fix it."""
    try:
        from kistrader.entry.screen_contract import VCP_SCORE_THRESHOLD as _thr
        return _thr
    except ImportError as e:
        raise SystemExit(
            f"[config] FATAL: cannot read VCP_SCORE_THRESHOLD from "
            f"kistrader.entry.screen_contract ({e}).\n"
            f"  The Stage-3 VCP bar is declared there ONCE and shared by both\n"
            f"  screeners and the trader. Refusing to guess a value.\n"
            f"  Fix either way, from the repo root:\n"
            f"      pip install -e .                        (then re-run as-is)\n"
            f"      python -m screeners.us_small_v21         (no install needed)")


VCP_SCORE_THRESHOLD = _load_vcp_threshold()



# =====================================================================
# VCP RECOGNITION ENGINE  (inlined verbatim from vcp_pattern_v4_1.py --
# detection + scoring logic UNCHANGED; only its standalone __main__ demo was
# dropped, since this screener's __main__ is now the single entry point.)
# =====================================================================
# ──────────────────────────────────────────────────────────────────────────
# NUMERICAL SAFETY (Risk 5) — one guarded division used engine-wide
# ──────────────────────────────────────────────────────────────────────────
def safe_divide(a, b, default=0.0):
    """
    a / b with denominator (and numerator) safety. Returns `default` when the
    denominator is None / NaN / effectively zero (|b| < 1e-9), or when the
    numerator is None / NaN. Centralises the defensive division that was
    previously duplicated across stages.
    """
    if b is None or pd.isna(b) or abs(b) < 1e-9:
        return default
    if a is None or pd.isna(a):
        return default
    return a / b


# --- PATCH AE (v4 avg_vol_50) --- non-finite -> 0.0 (== UNKNOWN in the v4
# schema). NaN is not JSON-representable and must never reach the contract; 0.0
# fails closed at the consumer, which is the safe direction for a denominator.
def _finite_vol(x) -> float:
    try:
        v = float(x)
    except (TypeError, ValueError):
        return 0.0
    return v if (v == v and v not in (float("inf"), float("-inf")) and v > 0) else 0.0
# --- end PATCH AE (v4 avg_vol_50) ---


# ──────────────────────────────────────────────────────────────────────────
# CONFIGURATION (Improvement B) — every tunable threshold in one place
# ──────────────────────────────────────────────────────────────────────────
@dataclass
class VCPConfig:
    """
    Central configuration for the engine. Defaults reproduce V4 behaviour
    EXACTLY, so later optimisation only varies fields here — no code edits.
    Grouped by stage. Rolling-window periods for the moving averages / ATR in
    calculate_base_metrics are deliberately left as canonical Minervini
    constants (50/150/200/20) and are not exposed here.
    """
    # ── ZigZag / base detection ──────────────────────────────────────────
    atr_multiplier:        float = 1.5
    # --- E11 --- adaptive ZigZag threshold. None reproduces the shipped
    # fixed-ATR behaviour EXACTLY (same branch, same arithmetic). A float in
    # (0, 1) makes each confirmation threshold a fraction of the PREVIOUS
    # confirmed wave's depth, so the detector contracts with the pattern.
    # RESULT_20260829_zigzag_calibration sec.2: "The threshold SHAPE is wrong,
    # not its value." Annotated float rather than Optional[float] because the
    # engine block is exec'd standalone and does not import typing itself.
    contraction_ratio:     float = None
    min_pct:               float = 0.015
    max_base_lookback:     int   = 252
    advance_min_pct:       float = 0.15
    default_lookback_days: int   = 130
    min_base_bars:         int   = 10
    max_score:             float = 104.0   # = sum of all stage point budgets, so the
                                            # normalized score spans a true 0-100 (100 is
                                            # now achievable; was 110 -> capped at ~94.5)
    # --- TOL --- 'general' (1.10) counted a wave 10% LARGER than its
    # predecessor as a contraction: 20 -> 22 -> 24 scored quality 1.000, the
    # same as a real 20 -> 12 -> 7. A VCP detector cannot award full marks to
    # volatility EXPANSION. 'strict' requires depths[i] <= depths[i-1].
    # The other modes are kept so existing references still resolve.
    contraction_mode:      str   = 'strict'
    contraction_modes:     dict  = field(
        default_factory=lambda: {'strict': 1, 'elite': 1.05,
                                 'general': 1.10, 'loose': 1.20})
    # --- end TOL ---

    # ── Input validation ─────────────────────────────────────────────────
    min_rows:              int   = 30

    # ── Stage 1: trend + RS ──────────────────────────────────────────────
    prior_uptrend_full:    float = 0.30
    prior_uptrend_points:  float = 8.0
    prior_lookback:        int   = 130
    trend_template_points: float = 8.0
    rs_full:               float = 0.15
    rs_points:             float = 8.0
    rs_min_common:         int   = 252
    rs_segments:           tuple = field(default_factory=lambda: (
        ((-1, -64), 0.40), ((-64, -127), 0.20),
        ((-127, -190), 0.20), ((-190, -253), 0.20)))

    # ── Stage 2: base quality ────────────────────────────────────────────
    base_depth_zero:       float = 0.35   # depth giving 0 credit
    base_depth_full:       float = 0.25   # depth giving full credit
    base_depth_points:     float = 6.0
    base_dur_min_weeks:    float = 6.0
    base_dur_max_weeks:    float = 20.0
    base_dur_points:       float = 4.0
    base_dur_center:       float = 13.0
    base_dur_falloff:      float = 0.2

    # ── Stage 3 & 4: contraction counts ──────────────────────────────────
    # --- PATCH AH (wave count: scoring vs rejection) --- 6 is now PRESENT and
    # scored zero, rather than ABSENT and defaulted to zero. Same number, and
    # the difference is the whole patch: a sweep can move this value without
    # also moving the rejection ceiling, which is impossible while one .get()
    # does both jobs. Ordered by wave count so the curve is readable.
    # Minervini's VCP is 2-6 contractions; 7+ is noise, and that is now said
    # by wave_count_max rather than implied by a missing dict key.
    wave_count_points:     dict  = field(
        default_factory=lambda: {2: 8, 3: 13, 4: 15, 5: 10, 6: 0})
    wave_count_max:        int   = 6
    # --- end PATCH AH (wave count: scoring vs rejection) ---

    # --- 3b (final-contraction tightness) --- the stop is set from the FINAL
    # contraction (decision_engine.derive_stop anchors on contraction_low =
    # Wave_Lows[-1]), and 45% of scored names fail max_stop_pct because nothing
    # here measured its ABSOLUTE size. quality_ratio is relative only, so
    # 40 -> 30 -> 22 scores a perfect 1.000 with a 22% final contraction.
    # UNITS: PERCENT, because Wave.depth_pct multiplies by 100. decision_engine
    # uses a FRACTION for the same quantity -- do not copy a value across.
    # final_tight_zero is DERIVED, not chosen: it is the depth at which the
    # structural stop lands exactly on max_stop_pct, given
    #   risk = ((1+chase) - (1-d)(1-buffer)) / (1+chase)
    # with chase 0.005, buffer 0.005, max_stop_pct 0.10  ->  d = 9.10%.
    # Re-solve it if any of those three move.
    final_tight_full:      float = 5.00
    final_tight_zero:      float = 9.10
    # --- end 3b ---

    # ── Stage 5: higher lows ─────────────────────────────────────────────
    higher_low_full:       float = 0.75
    higher_low_points:     float = 5.0

    # ── Stage 6: volume dry-up ───────────────────────────────────────────
    vol_overall_zero:      float = 1.0    # vol_ratio giving 0 credit
    vol_overall_full:      float = 0.70   # vol_ratio giving full credit
    vol_elite:             float = 0.50
    vol_strong:            float = 0.70
    vol_w_overall:         float = 0.60
    vol_w_sequence:        float = 0.40
    vol_points:            float = 10.0
    seq_good:              float = 2.0 / 3.0
    seq_weak:              float = 1.0 / 3.0

    # ── Stage 7: ATR compression ─────────────────────────────────────────
    atr_comp_zero:         float = 1.0
    atr_comp_full:         float = 0.75
    atr_comp_points:       float = 10.0
    atr_comp_window:       int   = 10

    # ── Stage 8: tight area ──────────────────────────────────────────────
    tight_zero:            float = 0.08
    tight_full:            float = 0.04
    tight_points:          float = 10.0
    tight_window:          int   = 10

    # ── Stage 9: resistance ──────────────────────────────────────────────
    resistance_points:     float = 5.0

    # ── Stage 10: accumulation ───────────────────────────────────────────
    accum_zero:            float = 1.0    # ratio giving 0 credit
    accum_full:            float = 1.2    # ratio giving full credit
    accum_points:          float = 10.0

    # ── Stage 11 & 12: readiness + breakout ──────────────────────────────
    ready_excellent:       float = 0.01
    ready_good:            float = 0.03
    ready_acceptable:      float = 0.05
    ready_poor_span:       float = 0.05
    ready_pts_excellent:   float = 5.0
    ready_pts_good:        float = 4.0
    ready_pts_acceptable:  float = 2.5
    breakout_vol_mult:     float = 1.5

    # ── Base-confidence diagnostic ───────────────────────────────────────
    conf_lookback_days:    int   = 130
    conf_min_drop_pct:     float = 0.10
    conf_compare_floor:    float = 0.90
    conf_competing_ratio:  float = 0.95
    conf_nearby_ratio:     float = 0.90
    conf_late_reach:       float = 0.98
    conf_late_frac:        float = 0.25

    # ── Grade cutoffs ────────────────────────────────────────────────────
    grade_elite:           float = 90.0
    grade_strong:          float = 80.0
    grade_tradable:        float = 70.0
    grade_watchlist:       float = 60.0


# ──────────────────────────────────────────────────────────────────────────
# SCORING (Improvement C) — one ramp replaces the repeated clamp pattern
# ──────────────────────────────────────────────────────────────────────────
class ScoreCalculator:
    """
    Removes the duplicated `max(0, min(cap, (target - x)/span * cap))` scoring
    pattern. `linear` interpolates a value to [0, points], saturating outside
    the [zero_at, full_at] band and working in either direction (full_at may be
    above or below zero_at).
    """
    @staticmethod
    def clamp(x, lo, hi):
        return max(lo, min(hi, x))

    @staticmethod
    def linear(value, zero_at, full_at, points):
        span = full_at - zero_at
        if abs(span) < 1e-12:                       # degenerate band
            return points if value == full_at else 0.0
        frac = (value - zero_at) / span
        return ScoreCalculator.clamp(frac, 0.0, 1.0) * points


# ==========================================
# VCP FRAMEWORK V4.1  (config-driven refactor)
# ==========================================
# Architecture:  Candles → Swings → WAVES → VCP Analysis
#
# The WAVE is the fundamental object. Every metric (base, pivot, contractions,
# higher-lows, resistance, volume) operates on waves — never on raw candles
# or raw swings.
#
# Locked definitions (per V3.1/V3.2 spec):
#   • Wave        = Swing High → Swing Low (Wave dataclass)
#   • ZigZag      = ATR-hybrid, threshold = max(ATR20×mult, Close×min_pct)
#   • Pivot       = waves[-1].high_price (most recent COMPLETED contraction)
#   • Breakout    = close > pivot AND volume confirms
#   • Contraction = configurable tolerance (elite 1.05 / general 1.10 / loose 1.20)
#
# Changes V3.1 → V3.2:
#   A  BASE DETECTION rewritten (was FROZEN). Now ZigZag-structural:
#        base start = most recent significant swing high that initiates the
#        current contraction sequence (a decisive advance establishes it),
#        replacing arbitrary highest-high-in-lookback anchoring.
#   B  READINESS redefined to actual breakout proximity:
#        distance_to_pivot = max(0, (pivot - current_close) / pivot)
#        scale  ≤1% Excellent · ≤3% Good · ≤5% Acceptable · >5% Poor
#   C  ACCUMULATION metric now AVG up-vol / AVG down-vol (was sum/sum), so it
#        measures participation intensity, not advancing-day count.
#   D  VOLUME DRY-UP now dual-axis: overall endpoint reduction (kept) PLUS a
#        progressive sequence-consistency score; both feed the stage score
#        (overall 60% / sequence 40%).
#
# Changes V3.2 → V4 (production hardening — no algorithm changes):
#   1  Accumulation: explicit neutral (1.0) when an up/down group is empty or
#      its mean is NaN/≤0, so an all-up-days base can never inject NaN.
#   2  Volume sequence: requires ≥2 wave volumes before the (len-1) division
#      (already guarded; made explicit and centralised).
#   3  ATR: ffill→bfill, then a Close×0.02 fallback on ANY residual NaN, then a
#      final fillna(0); datasets with unrecoverable price data are REJECTED.
#   4  Tight-area: guards mean(Close) ≤ 0 / NaN before dividing.
#   5  safe_divide() helper centralises every guarded division.
#   6  Score aggregation sanitises each stage score (NaN/±Inf → 0) and clamps
#      the final score to a finite [0,100].
#   7  Wave validation: malformed waves (high ≤ low, non-positive/NaN prices,
#      bad bar order) are dropped in _build_waves before they reach scoring.
#   8  Early-exit: _validate_input_data() rejects malformed frames up front;
#      stages continue to fail closed on thin/empty input.
#   Class renamed VCPAnalyzerV3 → VCPAnalyzerV4 (V3 name kept as an alias).
#
# Changes V4 → V4.1 (refactor only — behaviour is bit-identical to V4):
#   A  safe_divide() (added in V4) now covers the last inline guards.
#   B  VCPConfig dataclass centralises EVERY scoring threshold, lookback,
#      weight and grade cutoff. Stages read self.cfg.* instead of literals, so
#      later optimisation only varies config fields. The V4 constructor kwargs
#      (atr_multiplier, min_pct, contraction_mode, …) still work and override
#      the config; an optional `config=VCPConfig(...)` can be passed instead.
#   C  ScoreCalculator.linear() replaces the repeated
#      max(0, min(cap, (target - x)/span * cap)) pattern across the stages.
#
# Carried unchanged from V3.1: Wave object, ZigZag engine, pivot lock,
# wave-count scoring (4=15,3=13,5=10,2=8,else=0), wave-based volume, real RS.
# ==========================================


# ──────────────────────────────────────────────────────────────────────────
# THE FUNDAMENTAL OBJECT: a contraction wave  (Swing High → Swing Low)
# ──────────────────────────────────────────────────────────────────────────
@dataclass
class Wave:
    """
    A completed contraction wave: a confirmed swing high followed by a
    confirmed swing low.

      high_price / high_bar : the swing high that begins the contraction
      low_price  / low_bar  : the swing low  that ends   the contraction

    Bar indices are 0-based iloc positions WITHIN base_df.

    A Wave object is only ever created once its LOW is ZigZag-confirmed, so
    every Wave is a completed contraction by construction — there is no
    'currently forming' wave in the list, which prevents pivot repainting.
    """
    high_price: float
    high_bar:   int
    low_price:  float
    low_bar:    int

    @property
    def depth_pct(self) -> float:
        """Contraction depth as a positive percentage of the wave high."""
        if self.high_price <= 0:
            return 0.0
        return safe_divide(self.high_price - self.low_price,
                           self.high_price, default=0.0) * 100.0

    def is_valid(self) -> bool:
        """
        Reject malformed waves before they reach scoring (Risk 7).

        A wave is valid iff:
          • high_price and low_price are finite and strictly positive,
          • the contraction is positive (high_price > low_price), and
          • bar indices are finite, non-negative, and ordered (low at/after high).
        """
        for v in (self.high_price, self.low_price):
            if v is None or not np.isfinite(v) or v <= 0:
                return False
        if self.high_price <= self.low_price:        # contraction must be > 0
            return False
        for b in (self.high_bar, self.low_bar):
            if b is None or not np.isfinite(b) or b < 0:
                return False
        if self.low_bar < self.high_bar:             # low cannot precede the high
            return False
        return True


class VCPAnalyzerV4:
    # Contraction tolerance modes (Fix 5)
    CONTRACTION_MODES = {'elite': 1.05, 'general': 1.10, 'loose': 1.20}

    def __init__(self, df, index_df=None,
                 atr_multiplier=None, min_pct=None,
                 contraction_mode=None,
                 max_base_lookback=None, advance_min_pct=None,
                 contraction_ratio=None,
                 config=None):
        self.df = df.copy()
        self.index_df = index_df

        # ── Configuration (Improvement B) ────────────────────────────────────
        # All tunables live on VCPConfig. The V4 scalar kwargs still work and,
        # when supplied, override the config — preserving the old call sites.
        cfg = config if config is not None else VCPConfig()
        overrides = {}
        if atr_multiplier   is not None: overrides['atr_multiplier']    = atr_multiplier
        if contraction_ratio is not None: overrides['contraction_ratio'] = contraction_ratio
        if min_pct          is not None: overrides['min_pct']           = min_pct
        if max_base_lookback is not None: overrides['max_base_lookback'] = max_base_lookback
        if advance_min_pct  is not None: overrides['advance_min_pct']   = advance_min_pct
        if contraction_mode is not None: overrides['contraction_mode']  = contraction_mode
        if overrides:
            cfg = replace(cfg, **overrides)
        if cfg.contraction_mode not in cfg.contraction_modes:
            cfg = replace(cfg, contraction_mode='general')
        self.cfg = cfg

        # Instance mirrors kept so the ZigZag / base-detection code is untouched.
        self.atr_multiplier    = cfg.atr_multiplier
        self.contraction_ratio = cfg.contraction_ratio
        self.min_pct           = cfg.min_pct
        self.contraction_mode  = cfg.contraction_mode
        self.contraction_tol   = cfg.contraction_modes[cfg.contraction_mode]
        self.max_base_lookback = cfg.max_base_lookback
        self.advance_min_pct   = cfg.advance_min_pct
        self.max_score         = cfg.max_score

        self._data_ok, self._data_reasons = self._precheck_columns()
        if self._data_ok:
            self.calculate_base_metrics()
        self._invalid_wave_count = 0  # set by _build_waves (Risk 7 diagnostic)

    # ─────────────────────────────────────────────────────────────────────
    # INPUT VALIDATION (Risk 3 + Risk 8) — fail closed before any scoring
    # ─────────────────────────────────────────────────────────────────────
    def _precheck_columns(self):
        """Cheap structural check run in __init__ before metric computation."""
        required = ['Open', 'High', 'Low', 'Close', 'Volume']
        if self.df is None or len(self.df) == 0:
            return False, ['empty_dataframe']
        missing = [f'missing_column:{c}' for c in required
                   if c not in self.df.columns]
        return (len(missing) == 0), missing

    def _validate_input_data(self, min_rows=None):
        """
        Deep data-quality gate, run at the top of generate_report.

        Rejects a symbol when:
          • required columns were missing (carried from the precheck),
          • there is too little usable history, or
          • ATR is unrecoverable even after ffill/bfill and the Close-based
            fallback (Risk 3) — i.e. price data is too broken for ZigZag.
        """
        if min_rows is None:
            min_rows = self.cfg.min_rows
        if not self._data_ok:
            return False, self._data_reasons
        reasons = []
        if len(self.df) < min_rows:
            reasons.append('insufficient_rows')
        if self.df['Close'].notna().sum() < min_rows:
            reasons.append('close_mostly_nan')
        atr = self.df['ATR20'].ffill().bfill()
        if atr.isna().all() and (self.df['Close'].ffill().bfill() * 0.02).isna().all():
            reasons.append('atr_unrecoverable')
        return (len(reasons) == 0), reasons

    def calculate_base_metrics(self):
        """Moving averages, ATR, and volume metrics."""
        self.df['MA50']  = self.df['Close'].rolling(window=50).mean()
        self.df['MA150'] = self.df['Close'].rolling(window=150).mean()
        self.df['MA200'] = self.df['Close'].rolling(window=200).mean()

        self.df['Previous_Close'] = self.df['Close'].shift(1)
        self.df['TR'] = (self.df[['High', 'Previous_Close']].max(axis=1) -
                         self.df[['Low',  'Previous_Close']].min(axis=1))
        self.df['ATR20'] = self.df['TR'].rolling(window=20).mean()

        self.df['Avg_Vol_10'] = self.df['Volume'].rolling(window=10).mean()
        self.df['Avg_Vol_50'] = self.df['Volume'].rolling(window=50).mean()

    # ─────────────────────────────────────────────────────────────────────
    # CHANGE A — BASE DETECTION (V3.2, ZigZag-structural; was FROZEN)
    # ─────────────────────────────────────────────────────────────────────
    def _find_base_start(self, lookback_days=130):
        """
        Locked V3.2 definition:

            Base Start = the most recent SIGNIFICANT ZigZag swing high that
                         initiates the current contraction sequence.

        This replaces highest-high-in-lookback anchoring, which mis-fired in
        Run→BaseA→Run→BaseB structures. The new method is wave-native: it
        reads the same ATR-hybrid ZigZag used everywhere else, so the base is
        chosen from real swing structure rather than an arbitrary window max.

        Method
        ──────
        1. Run the ZigZag over a wide structural window (max_base_lookback).
        2. Collect swing highs (confirmed H pivots + the leading peak before
           the first confirmed low, so a base topped at the window edge is
           still seen).
        3. Walk the highs forward tracking the running peak. A *decisive
           advance* — an up-move that lifts to a new high at least
           advance_min_pct above the prior running peak — RESETS the base to
           that new high. The last such reset is the start of the current
           contraction sequence.
        4. If no decisive advance is found, the structure is a single base:
           anchor on the dominant (max) swing high.
        5. base_high is then the highest high from base_start to the current
           bar — the ceiling the contraction sits beneath.

        Assumption (documented; validation deferred to chart testing per spec)
        ──────────────────────────────────────────────────────────────────
        A later base that forms ENTIRELY below a prior high without a decisive
        new-high advance is treated as still sitting under that prior high
        (the prior high remains the controlling ceiling). Tune advance_min_pct
        to make base re-anchoring more or less eager.

        Returns (base_start_num, base_high) as (int iloc, float).
        """
        n = len(self.df)
        if n < 20:
            return n - 1, float(self.df['High'].iloc[-1])

        lb = min(self.max_base_lookback, n)
        start_pos = n - lb
        window = self.df.iloc[start_pos:]

        rel_piv = self._zigzag_pivots(window)
        piv = [(start_pos + b, float(p), t) for (b, p, t) in rel_piv]

        # Fallback: absolute high within the requested (narrower) lookback
        fb_lb    = min(lookback_days if lookback_days else lb, n)
        fb_start = n - fb_lb
        fb_win   = self.df.iloc[fb_start:]
        fb_bar   = fb_start + int(fb_win['High'].values.argmax())
        fb_price = float(self.df['High'].iloc[fb_bar])

        if not piv:
            return fb_bar, fb_price

        # ── Collect swing highs (leading peak + confirmed H pivots) ──────────
        highs = []
        first_low_bar = next((b for (b, p, t) in piv if t == 'L'), None)
        if first_low_bar is not None and first_low_bar > start_pos:
            lead_slice = self.df.iloc[start_pos:first_low_bar + 1]
            lead_bar   = start_pos + int(lead_slice['High'].values.argmax())
            highs.append((lead_bar, float(self.df['High'].iloc[lead_bar])))
        highs += [(b, p) for (b, p, t) in piv if t == 'H']
        highs.sort(key=lambda x: x[0])

        if not highs:
            return fb_bar, fb_price

        # ── Most recent decisive advance resets the base ─────────────────────
        base_bar, base_price = None, None
        running_peak = highs[0][1]
        for (b, p) in highs:
            if p > running_peak * (1.0 + self.advance_min_pct):
                base_bar, base_price = b, p
            running_peak = max(running_peak, p)

        if base_bar is None:
            # Single base: dominant swing high
            base_bar, base_price = max(highs, key=lambda x: x[1])

        # ── Base ceiling = highest high since the base started ───────────────
        ceiling   = float(self.df['High'].iloc[base_bar:].max())
        base_price = max(base_price, ceiling)

        return base_bar, base_price

    # ─────────────────────────────────────────────────────────────────────
    # BASE-CONFIDENCE DIAGNOSTIC (validation aid, non-invasive)
    # ─────────────────────────────────────────────────────────────────────
    def _assess_base_confidence(self, base_start_num, base_high,
                                lookback_days=None, min_drop_pct=None):
        """
        Cross-checks the chosen anchor and surfaces a confidence label so the
        screener can gate on it. Retained from V3.1 as a validation surface
        for the new ZigZag-structural base detection (spec lists base
        detection validation as a pending chart-testing item).

        Two independent risk signals:

          A) COMPETING EARLIER BASE
             A comparable prior peak (≥ conf_competing_ratio of base_high)
             exists BEFORE the chosen anchor, separated by a real drawdown. →
             the anchor may be BaseA when BaseB was intended.

          B) LATE INTERNAL HIGH
             Inside the chosen base, price later revisited/exceeded base_high
             well past the start (> conf_late_frac into the base). → the true
             base may begin at that later high, not the chosen anchor.

        Returns (confidence_label, reasons_list)
            confidence_label ∈ {'high', 'medium', 'low'}
        """
        cfg = self.cfg
        if lookback_days is None:
            lookback_days = cfg.conf_lookback_days
        if min_drop_pct is None:
            min_drop_pct = cfg.conf_min_drop_pct

        reasons = []
        if len(self.df) < 20:
            return 'low', ['insufficient_history']
        if base_high is None or not np.isfinite(base_high) or base_high <= 0:
            return 'low', ['invalid_base_high']   # Risk 5/8 — avoid /base_high blowups

        if len(self.df) < lookback_days:
            lookback_days = len(self.df)
        start_pos = len(self.df) - lookback_days

        # ── Signal A: competing earlier base before the anchor ───────────────
        # A genuine prior base = a peak comparable to base_high that was THEN
        # followed by a real drawdown inside the pre-anchor region. A plain
        # monotonic run-up (highs approaching base_high while rising) must NOT
        # trigger this — only a peak-then-decline does.
        pre = self.df.iloc[start_pos:base_start_num]
        if len(pre) >= 15:
            ph = pre['High'].values
            pc = pre['Close'].values
            best_ratio = 0.0
            for i in range(len(pre) - 5):
                if ph[i] >= base_high * cfg.conf_compare_floor:
                    future_min = pc[i + 1:].min()
                    draw = safe_divide(ph[i] - future_min, ph[i], default=0.0)
                    if draw >= min_drop_pct:
                        best_ratio = max(best_ratio,
                                         safe_divide(ph[i], base_high, default=0.0))
            if best_ratio >= cfg.conf_competing_ratio:
                reasons.append('competing_earlier_base')
            elif best_ratio >= cfg.conf_nearby_ratio:
                reasons.append('nearby_earlier_peak')

        # ── Signal B: late internal high inside the chosen base ──────────────
        base = self.df.iloc[base_start_num:]
        if len(base) >= 10:
            # bars (relative to base start) where price reached the anchor band
            reach = np.where(base['High'].values >= base_high * cfg.conf_late_reach)[0]
            if len(reach) > 0:
                last_reach_frac = reach[-1] / max(1, len(base) - 1)
                if last_reach_frac > cfg.conf_late_frac:
                    reasons.append('late_internal_high')

        # ── Combine ──────────────────────────────────────────────────────────
        if 'competing_earlier_base' in reasons or 'late_internal_high' in reasons:
            confidence = 'low'
        elif 'nearby_earlier_peak' in reasons:
            confidence = 'medium'
        else:
            confidence = 'high'

        return confidence, reasons

    # ─────────────────────────────────────────────────────────────────────
    # FIX 3 — ATR-HYBRID ZIGZAG (official swing engine)
    # ─────────────────────────────────────────────────────────────────────
    def _zigzag_pivots(self, base_df):
        """
        Detection layer. Confirms a pivot only when price reverses by

            threshold = max(ATR20 × atr_multiplier, Close × min_pct)

        from the running extreme. A pivot is therefore only ever emitted
        AFTER it is confirmed by a reversal (Fix 4 — no unconfirmed pivots).

        Returns list of (bar_idx, price, 'H'|'L'), bar_idx 0-based in base_df.
        The base high at bar 0 is implied (not emitted).
        """
        if len(base_df) < 5:
            return []

        atr_s = base_df['ATR20'].ffill().bfill()
        if atr_s.isna().any():                       # any residual NaN → Close-based fallback
            atr_s = (base_df['Close'] * 0.02).ffill().bfill()
        atr_s = atr_s.fillna(0.0)                     # last-resort: 0 (min_pct floor still applies)

        pivots       = []
        prev_depth   = 0.0        # --- E11 --- depth of the last CONFIRMED wave
        direction    = 'down'
        run_high     = base_df['High'].iloc[0]
        run_high_bar = 0
        run_low      = base_df['Low'].iloc[0]
        run_low_bar  = 0

        for i in range(1, len(base_df)):
            h = base_df['High'].iloc[i]
            l = base_df['Low'].iloc[i]
            # --- E11 --- adaptive threshold. With contraction_ratio set, the
            # bar for confirming the NEXT reversal is a fraction of the PREVIOUS
            # wave's depth, so resolution contracts as the pattern does. The
            # min_pct floor still applies and stops it collapsing onto noise.
            # The first wave has no predecessor (prev_depth == 0) and always
            # takes the shipped ATR branch, so contraction_ratio=None is
            # behaviourally identical to the engine as shipped.
            if self.contraction_ratio and prev_depth > 0:
                thresh = max(prev_depth * self.contraction_ratio,
                             base_df['Close'].iloc[i] * self.min_pct)
            else:
                thresh = max(atr_s.iloc[i] * self.atr_multiplier,
                             base_df['Close'].iloc[i] * self.min_pct)

            if direction == 'down':
                if l < run_low:
                    run_low, run_low_bar = l, i
                if (h - run_low) >= thresh:                # reversal up → low confirmed
                    pivots.append((run_low_bar, run_low, 'L'))
                    # --- E11 --- a Wave is high -> low, so its depth is known
                    # exactly here, at the moment the low is confirmed. run_high
                    # still holds the high that opened this wave; it is reset on
                    # the next line.
                    prev_depth = run_high - run_low
                    direction = 'up'
                    run_high, run_high_bar = h, i
            else:  # up
                if h > run_high:
                    run_high, run_high_bar = h, i
                if (run_high - l) >= thresh:               # reversal down → high confirmed
                    pivots.append((run_high_bar, run_high, 'H'))
                    direction = 'down'
                    run_low, run_low_bar = l, i

        return pivots

    # ─────────────────────────────────────────────────────────────────────
    # FIX 2 — WAVE CONSTRUCTION (analysis layer)
    # ─────────────────────────────────────────────────────────────────────
    def _build_waves(self, base_df, base_high):
        """
        Converts confirmed ZigZag pivots into a list of Wave objects.

        A Wave = swing high → swing low. We walk the pivot sequence holding
        the 'current high' (starting at base_high@bar0). Each time a LOW is
        confirmed we close a Wave(current_high → that low). Each confirmed
        HIGH updates current_high for the next wave.

        Because a Wave is only created on a confirmed LOW, every Wave in the
        returned list is a COMPLETED contraction (Fix 1 / Fix 4).
        """
        pivots = self._zigzag_pivots(base_df)

        waves = []
        current_high     = base_high
        current_high_bar = 0

        for bar_idx, price, p_type in pivots:
            if p_type == 'L':
                waves.append(Wave(high_price=current_high,
                                  high_bar=current_high_bar,
                                  low_price=price,
                                  low_bar=bar_idx))
            else:  # 'H'
                current_high     = price
                current_high_bar = bar_idx

        # Risk 7 — reject malformed waves before they can contaminate scoring.
        valid = [w for w in waves if w.is_valid()]
        self._invalid_wave_count = len(waves) - len(valid)
        return valid

    # ─────────────────────────────────────────────────────────────────────
    # FIX 5 (RS) — real relative strength vs index (carried from mark4)
    # ─────────────────────────────────────────────────────────────────────
    def _compute_rs_raw(self):
        """Minervini quarterly-weighted excess return vs index. 0 if no index."""
        if self.index_df is None:
            return 0.0

        common = self.df['Close'].index.intersection(self.index_df['Close'].index)
        if len(common) < self.cfg.rs_min_common:
            return 0.0

        s = self.df['Close'][common]
        b = self.index_df['Close'][common]

        def qret(series, end, start):
            sv = series.iloc[start]
            return safe_divide(series.iloc[end], sv, default=1.0) - 1.0

        rs = 0.0
        for (end, start), w in self.cfg.rs_segments:
            try:
                rs += w * (qret(s, end, start) - qret(b, end, start))
            except (IndexError, ZeroDivisionError):
                pass
        return rs

    # ─────────────────────────────────────────────────────────────────────
    # MASTER EXTRACTION — returns the wave list + base context
    # ─────────────────────────────────────────────────────────────────────
    def extract(self, lookback_days=None):
        """
        Full extraction pipeline: base detection → ZigZag → wave construction.

        Returns
        ───────
        base_start_num : int
        base_high      : float
        base_df        : DataFrame (empty if base too fresh)
        waves          : list[Wave]   (completed contractions only)
        base_conf      : str   'high' | 'medium' | 'low'  (Bug 3 diagnostic)
        base_reasons   : list[str]  risk signals behind the confidence label
        """
        if lookback_days is None:
            lookback_days = self.cfg.default_lookback_days
        base_start_num, base_high = self._find_base_start(lookback_days=lookback_days)
        base_df = self.df.iloc[base_start_num:].copy()

        base_conf, base_reasons = self._assess_base_confidence(
            base_start_num, base_high, lookback_days=lookback_days)

        if len(base_df) < self.cfg.min_base_bars:
            return base_start_num, base_high, pd.DataFrame(), [], base_conf, base_reasons

        waves = self._build_waves(base_df, base_high)
        return base_start_num, base_high, base_df, waves, base_conf, base_reasons

    # ─────────────────────────────────────────────────────────────────────
    # STAGE 1: Trend Qualification (+ real RS)
    # ─────────────────────────────────────────────────────────────────────
    def stage_1_trend(self, base_start_num):
        cfg = self.cfg
        current    = self.df.iloc[-1]
        past_price = self.df['Close'].iloc[max(0, base_start_num - cfg.prior_lookback)]
        prior_uptrend = safe_divide(
            self.df['High'].iloc[base_start_num] - past_price, past_price, default=0.0)

        trend_template = bool(
            current['Close'] > current['MA50']  and
            current['MA50']  > current['MA150'] and
            current['MA150'] > current['MA200'])

        score = ScoreCalculator.linear(prior_uptrend, 0.0,
                                        cfg.prior_uptrend_full, cfg.prior_uptrend_points)
        if trend_template:
            score += cfg.trend_template_points

        rs_raw   = self._compute_rs_raw()
        rs_score = ScoreCalculator.linear(rs_raw, 0.0, cfg.rs_full, cfg.rs_points)
        score   += rs_score

        return score, {'prior_uptrend': prior_uptrend,
                       'trend_template': trend_template,
                       'rs_excess': round(rs_raw, 4),
                       'rs_score': round(rs_score, 2)}

    # ─────────────────────────────────────────────────────────────────────
    # STAGE 2: Base Quality
    # ─────────────────────────────────────────────────────────────────────
    def stage_2_base(self, base_df, base_high):
        if base_df.empty:
            return 0, {}
        cfg = self.cfg
        base_weeks = len(base_df) / 5
        base_low   = base_df['Low'].min()
        base_depth = safe_divide(base_high - base_low, base_high, default=1.0)

        depth_score    = ScoreCalculator.linear(base_depth, cfg.base_depth_zero,
                                                 cfg.base_depth_full, cfg.base_depth_points)
        duration_score = (cfg.base_dur_points
                          if cfg.base_dur_min_weeks <= base_weeks <= cfg.base_dur_max_weeks
                          else max(0, cfg.base_dur_points
                                   - abs(base_weeks - cfg.base_dur_center) * cfg.base_dur_falloff))
        return depth_score + duration_score, {'base_depth': base_depth,
                                              'base_weeks': base_weeks}

    # ─────────────────────────────────────────────────────────────────────
    # STAGE 3 & 4: Contraction Analysis  (operates on Wave depths)
    # ─────────────────────────────────────────────────────────────────────
    def stage_3_and_4_contractions(self, waves):
        """
        Fix 7 — discrete wave-count budget, scaled by contraction quality.

            wave-count base points:  4→15  3→13  5→10  2→8  else→0
            contraction quality:     fraction of waves where
                                       depth[i] <= depth[i-1] × tol   (Fix 5)

            score = base_points × quality_ratio
        """
        n = len(waves)
        depths = [w.depth_pct for w in waves]

        if n < 2:
            return 0, {'wave_count': n, 'waves': depths, 'wave_count_points': 0}

        # --- PATCH AH (wave count: scoring vs rejection) --- REJECTION first,
        # then SCORING. Identical output for every n: above the ceiling the
        # dict had no key and defaulted to 0; now it is said outright.
        if n > self.cfg.wave_count_max:
            base_points = 0
        else:
            base_points = self.cfg.wave_count_points.get(n, 0)
        # --- end PATCH AH (wave count: scoring vs rejection) ---

        met = sum(1 for i in range(1, n)
                  if depths[i] <= depths[i - 1] * self.contraction_tol)
        quality_ratio = met / (n - 1)

        # --- 3b --- the FINAL contraction is what the stop is set from, so its
        # absolute size gates the same points its relative shape does. In [0, 1]
        # and multiplicative, so this can only REDUCE a score: no name can be
        # lifted over the threshold by this term. depths[] is in PERCENT.
        final_depth = float(depths[-1])
        tightness = ScoreCalculator.linear(
            final_depth, self.cfg.final_tight_zero, self.cfg.final_tight_full,
            1.0)
        score = base_points * quality_ratio * tightness
        return score, {'wave_count': n,
                       'waves': depths,
                       'wave_count_points': base_points,
                       'contraction_quality': round(quality_ratio, 3),
                       'final_contraction_pct': round(final_depth, 2),
                       'final_tightness': round(tightness, 3),
                       'contraction_mode': self.contraction_mode}
        # --- end 3b ---

    # ─────────────────────────────────────────────────────────────────────
    # STAGE 5: Higher-Low Structure  (operates on Wave lows)
    # ─────────────────────────────────────────────────────────────────────
    def stage_5_higher_lows(self, waves):
        lows = [w.low_price for w in waves]
        if len(lows) < 2:
            return 0, {'higher_low_ratio': 0}
        higher = sum(1 for i in range(1, len(lows)) if lows[i] > lows[i - 1])
        ratio  = higher / max(1, len(lows) - 1)
        score  = ScoreCalculator.linear(ratio, 0.0,
                                        self.cfg.higher_low_full, self.cfg.higher_low_points)
        return score, {'higher_low_ratio': round(ratio, 3)}

    # ─────────────────────────────────────────────────────────────────────
    # STAGE 6: Wave-Based Volume Dry-Up  (Fix 8)
    # ─────────────────────────────────────────────────────────────────────
    def stage_6_volume_dry_up(self, base_df, waves):
        """
        Wave-based volume dry-up, evaluated on TWO complementary axes (V3.2):

          1. OVERALL REDUCTION  — last_wave_avg_vol / first_wave_avg_vol
             "Has supply dried up from the START of the base to the END?"
             Strong < 0.70   Elite < 0.50

          2. SEQUENCE CONSISTENCY — fraction of consecutive wave pairs whose
             average volume decreases (progressive contraction).
             "Did supply disappear PROGRESSIVELY, wave by wave?"
             100% Excellent · ≥67% Good · ≥33% Weak · 0% Fail

        These measure different things. A base can pass (1) on its endpoints
        while supply briefly RETURNS mid-sequence — e.g. wave volumes
        100→80→90→45 pass overall (45/100) yet wave 3 shows supply coming back,
        which only (2) penalises. Both feed the 10-point stage budget
        (overall 60% / sequence 40%).

        Wave volume is each wave's mean over its actual bar span (high_bar →
        low_bar), consistent with the rest of the engine.
        """
        if base_df.empty or len(waves) < 2:
            return 0, {'vol_ratio': 1.0, 'vol_sequence_score': 0.0,
                       'vol_sequence_tier': 'Fail', 'volume_tier': 'Weak'}

        def wave_vol(w):
            s, e = w.high_bar, w.low_bar
            if e < s:
                s, e = e, s
            seg = base_df['Volume'].iloc[s:e + 1]
            return seg.mean() if len(seg) else None

        wave_volumes = [wave_vol(w) for w in waves]
        wave_volumes = [v for v in wave_volumes if v is not None and v > 0]
        if len(wave_volumes) < 2:
            return 0, {'vol_ratio': 1.0, 'vol_sequence_score': 0.0,
                       'vol_sequence_tier': 'Fail', 'volume_tier': 'Weak'}

        # ── 1. Overall reduction (endpoint dry-up) ───────────────────────────
        cfg = self.cfg
        # ── 1. Overall reduction (endpoint dry-up) ───────────────────────────
        v1, vN    = wave_volumes[0], wave_volumes[-1]
        vol_ratio = safe_divide(vN, v1, default=1.0)
        overall_component = ScoreCalculator.linear(
            vol_ratio, cfg.vol_overall_zero, cfg.vol_overall_full, 1.0)

        # ── 2. Sequence consistency (progressive dry-up) ─────────────────────
        decreasing_pairs = sum(wave_volumes[i] < wave_volumes[i - 1]
                               for i in range(1, len(wave_volumes)))
        sequence_score = decreasing_pairs / (len(wave_volumes) - 1)

        # ── Combine: both metrics contribute to the stage score ──────────────
        score = cfg.vol_points * (cfg.vol_w_overall * overall_component +
                                  cfg.vol_w_sequence * sequence_score)

        # Tiers use the exact fractions 2/3 and 1/3 (the spec table's 67% / 33%
        # are roundings of these). A literal 0.67 cutoff would misclassify the
        # canonical 2-of-3 case (66.67%) as Weak rather than Good.
        if   sequence_score >= 1.0 - 1e-9:        seq_tier = 'Excellent'
        elif sequence_score >= cfg.seq_good - 1e-9: seq_tier = 'Good'
        elif sequence_score >= cfg.seq_weak - 1e-9: seq_tier = 'Weak'
        else:                                     seq_tier = 'Fail'

        return score, {'vol_ratio': round(vol_ratio, 3),
                       'vol_sequence_score': round(sequence_score, 3),
                       'vol_sequence_tier': seq_tier,
                       'volume_tier': ('Elite' if vol_ratio < cfg.vol_elite
                                       else 'Strong' if vol_ratio < cfg.vol_strong
                                       else 'Weak')}

    # ─────────────────────────────────────────────────────────────────────
    # STAGE 7: ATR Compression
    # ─────────────────────────────────────────────────────────────────────
    def stage_7_volatility(self, base_df):
        cfg = self.cfg
        if len(base_df) < 2 * cfg.atr_comp_window:
            return 0, {}
        first = base_df['ATR20'].iloc[:cfg.atr_comp_window].mean()
        last  = base_df['ATR20'].iloc[-cfg.atr_comp_window:].mean()
        ratio = safe_divide(last, first, default=1.0)
        score = ScoreCalculator.linear(ratio, cfg.atr_comp_zero,
                                       cfg.atr_comp_full, cfg.atr_comp_points)
        return score, {'atr_ratio': round(ratio, 3)}

    # ─────────────────────────────────────────────────────────────────────
    # STAGE 8: Tight Area
    # ─────────────────────────────────────────────────────────────────────
    def stage_8_tight_area(self, base_df):
        cfg = self.cfg
        if len(base_df) < cfg.tight_window:
            return 0, {}
        last_n = base_df.iloc[-cfg.tight_window:]
        rng        = last_n['High'].max() - last_n['Low'].min()
        mean_close = last_n['Close'].mean()
        if pd.isna(mean_close) or mean_close <= 0 or pd.isna(rng):
            return 0, {'tight_range': None}          # Risk 4 — malformed data
        tight = rng / mean_close
        score = ScoreCalculator.linear(tight, cfg.tight_zero,
                                       cfg.tight_full, cfg.tight_points)
        return score, {'tight_range': round(tight, 4)}

    # ─────────────────────────────────────────────────────────────────────
    # STAGE 9: Resistance / Declining-Lid  (operates on Wave highs)
    # ─────────────────────────────────────────────────────────────────────
    def stage_9_resistance(self, waves):
        highs = [w.high_price for w in waves]
        if len(highs) < 2:
            return 0, {}
        declining = sum(1 for i in range(1, len(highs)) if highs[i] < highs[i - 1])
        ratio = declining / max(1, len(highs) - 1)
        score = ScoreCalculator.linear(ratio, 0.0, 1.0, self.cfg.resistance_points)
        return score, {'declining_highs_ratio': round(ratio, 3)}

    # ─────────────────────────────────────────────────────────────────────
    # STAGE 10: Accumulation
    # ─────────────────────────────────────────────────────────────────────
    def stage_10_accumulation(self, base_df):
        """
        Accumulation = AVERAGE up-day volume / AVERAGE down-day volume (V3.2).

        Averages (not sums) are used deliberately. A sum-based ratio is inflated
        merely by having more up days than down days, so it measures the COUNT
        of advancing days rather than the INTENSITY of institutional
        participation (e.g. 18 up / 2 down days at identical daily volume yields
        a misleadingly high sum-ratio). Per-day averages isolate participation
        regardless of the up/down day mix. Flat days (Close == Previous_Close)
        are excluded from both legs.
        """
        if base_df.empty:
            return 0, {}
        is_up   = base_df['Close'] > base_df['Previous_Close']
        is_down = base_df['Close'] < base_df['Previous_Close']
        up_vol   = base_df[is_up]['Volume']
        down_vol = base_df[is_down]['Volume']

        # mean() of an empty Series is NaN — fall back to a NEUTRAL ratio (1.0)
        # whenever either group is missing or its mean is NaN/≤0 (Risk 1), so an
        # all-up-days base can never inject NaN into the accumulation score.
        avg_up   = up_vol.mean()   if len(up_vol)   else np.nan
        avg_down = down_vol.mean() if len(down_vol) else np.nan
        if pd.isna(avg_up) or pd.isna(avg_down) or avg_down <= 0:
            ratio = 1.0
        else:
            ratio = safe_divide(avg_up, avg_down, default=1.0)

        score = ScoreCalculator.linear(ratio, self.cfg.accum_zero,
                                       self.cfg.accum_full, self.cfg.accum_points)
        return score, {'accumulation_ratio': round(ratio, 3)}

    # ─────────────────────────────────────────────────────────────────────
    # STAGE 11 & 12: Pivot (LOCKED), Readiness & Breakout Trigger
    # ─────────────────────────────────────────────────────────────────────
    def stage_11_12_trigger(self, base_high, waves):
        """
        Pivot (LOCKED): pivot = waves[-1].high_price — high of the most recent
        COMPLETED contraction. Deterministic; never the forming leg.

        Readiness (V3.2 redefined): actual breakout proximity, measured from
        the live close toward the pivot.

            distance_to_pivot = max(0, (pivot - current_close) / pivot)

            ≤ 1 %  Excellent   ≤ 3 %  Good   ≤ 5 %  Acceptable   > 5 %  Poor

        A close at or above the pivot scores full readiness (it is at/through
        the trigger). Negative distance (already above pivot) → Excellent.

        Breakout (LOCKED): close > pivot AND volume ≥ 1.5 × Avg_Vol_50.
        Close-based by design — an intraday high probing above resistance that
        fails by the close is NOT a breakout.
        """
        if not waves:
            return 0, {'trade_signal': False, 'pivot_level': 0,
                       'distance_to_pivot': None, 'readiness_tier': 'None'}

        cfg = self.cfg
        current = self.df.iloc[-1]
        close   = current['Close']
        pivot   = waves[-1].high_price            # ← LOCKED pivot definition

        distance = max(0.0, safe_divide(pivot - close, pivot, default=1.0))

        if   distance <= cfg.ready_excellent:
            readiness_score, tier = cfg.ready_pts_excellent, 'Excellent'
        elif distance <= cfg.ready_good:
            readiness_score, tier = cfg.ready_pts_good, 'Good'
        elif distance <= cfg.ready_acceptable:
            readiness_score, tier = cfg.ready_pts_acceptable, 'Acceptable'
        else:
            poor_zero = cfg.ready_acceptable + cfg.ready_poor_span
            readiness_score = ScoreCalculator.linear(
                distance, poor_zero, cfg.ready_acceptable, cfg.ready_pts_acceptable)
            tier = 'Poor'

        avg_vol_50 = current['Avg_Vol_50']
        trade_signal = bool(close > pivot and
                            not pd.isna(avg_vol_50) and
                            current['Volume'] >= cfg.breakout_vol_mult * avg_vol_50)

        return readiness_score, {'distance_to_pivot': round(distance, 4),
                                 'readiness_tier': tier,
                                 'trade_signal': trade_signal,
                                 'pivot_level': pivot}

    # ─────────────────────────────────────────────────────────────────────
    # MASTER SCORING ENGINE
    # ─────────────────────────────────────────────────────────────────────
    def generate_report(self):
        # Risk 8 / Risk 3 — fail closed on malformed input before any scoring.
        data_ok, data_reasons = self._validate_input_data()
        if not data_ok:
            return {'Score': 0, 'Grade': 'Reject (Invalid Data)',
                    'Trade_Signal_Active': False,
                    'Base_Confidence': 'low', 'Base_Warnings': data_reasons}

        (base_start_num, base_high, base_df, waves,
         base_conf, base_reasons) = self.extract()

        if base_df.empty:
            return {'Score': 0, 'Grade': 'Reject (No Base)', 'Trade_Signal_Active': False,
                    'Base_Confidence': base_conf, 'Base_Warnings': base_reasons}

        t,  tm  = self.stage_1_trend(base_start_num)
        b,  bm  = self.stage_2_base(base_df, base_high)
        c,  cm  = self.stage_3_and_4_contractions(waves)
        h,  hm  = self.stage_5_higher_lows(waves)
        v,  vm  = self.stage_6_volume_dry_up(base_df, waves)
        vo, vom = self.stage_7_volatility(base_df)
        ti, tim = self.stage_8_tight_area(base_df)
        re, rem = self.stage_9_resistance(waves)
        ac, acm = self.stage_10_accumulation(base_df)
        rd, rdm = self.stage_11_12_trigger(base_high, waves)

        # Risk 6 — sanitise each stage score (NaN/±Inf → 0) before aggregation,
        # so a single bad metric can never silently contaminate the total.
        def _finite(x):
            try:
                xv = float(x)
            except (TypeError, ValueError):
                return 0.0
            return xv if np.isfinite(xv) else 0.0

        components = [_finite(x) for x in (t, b, c, h, v, vo, ti, re, ac, rd)]
        raw   = sum(components)
        final = min((raw / self.max_score) * 100, 100)
        if not np.isfinite(final):                    # final guard against NaN/Inf
            final = 0.0
        final = max(0.0, final)

        cfg = self.cfg
        if   final >= cfg.grade_elite:     grade = "Elite"
        elif final >= cfg.grade_strong:    grade = "Strong"
        elif final >= cfg.grade_tradable:  grade = "Tradable"
        elif final >= cfg.grade_watchlist: grade = "Watchlist"
        else:                              grade = "Reject"

        return {
            'Score': round(final, 2),
            'Grade': grade,
            'Trade_Signal_Active': rdm.get('trade_signal', False),
            'Base_Confidence': base_conf,        # Bug 3 diagnostic: high/medium/low
            'Base_Warnings':   base_reasons,     # risk signals (may be empty)
            'Extracted_Pattern': {
                'Base_High':         float(base_high),
                'Base_Start_Bar':    int(base_start_num),
                'Wave_Count':        len(waves),
                'Wave_Depths_Pct':   [round(float(w.depth_pct), 2) for w in waves],
                'Wave_Highs':        [round(float(w.high_price), 2) for w in waves],
                'Wave_Lows':         [round(float(w.low_price), 2)  for w in waves],
                'Pivot':             float(rdm.get('pivot_level', 0)),  # LOCKED
                'Invalid_Waves_Dropped': int(self._invalid_wave_count),  # Risk 7
                # --- §1.6: absolutes the entry half needs (no scoring impact) ---
                'Base_Low':          float(base_df['Low'].min()),
                'Latest_Close':      float(self.df['Close'].iloc[-1]),
                'Latest_ATR':        float(self.df['ATR20'].ffill().bfill().iloc[-1]),
                # --- PATCH AE (v4 avg_vol_50) --- the DENOMINATOR for breakout
                # volume confirmation. Already computed above (rolling(50) on
                # Volume) and already used by the engine's own daily-bar
                # Trade_Signal_Active; it was simply never exported.
                # NaN (fewer than 50 bars) -> 0.0, which the v4 schema defines
                # as UNKNOWN. An unknown denominator can only make a volume gate
                # REFUSE; a fabricated one could make it PASS.
                'Avg_Vol_50':        _finite_vol(self.df['Avg_Vol_50'].iloc[-1]),
                # --- end PATCH AE (v4 avg_vol_50) ---
            },
            'Metrics': {**tm, **bm, **cm, **hm, **vm, **vom,
                        **tim, **rem, **acm, **rdm},
        }
# Backward-compatibility: existing screeners that import VCPAnalyzerV3 keep working.
VCPAnalyzerV3 = VCPAnalyzerV4


# ==========================================
# RESULTS FORMATTING (integration-ready output)
# ==========================================
# Pure presentation layer — touches NO scoring/detection logic. Renders the
# report dict from generate_report() as one standardised, pipe-delimited row per
# ticker so the engine plugs straight into the screener suite.
#
#   Columns:  Ticker|vcp score|outcome|pivot
#   Example:  $NVDA|90.0|success|180.45
RESULTS_HEADER = "Ticker|vcp score|outcome|pivot"


def result_outcome(report):
    """
    Map a report to the Stage-3 screen outcome. 'success' when the VCP score
    clears VCP_SCORE_THRESHOLD (the final-match gate), else 'fail'. Tied to
    that single threshold so the results table and the final picks always agree.
    """
    return 'success' if report.get('Score', 0) >= VCP_SCORE_THRESHOLD else 'fail'


def format_result_row(ticker, report):
    """Render one '$TICKER|score|outcome|pivot' line for the results table."""
    score = report.get('Score', 0)
    # Reject-before-scoring paths omit Extracted_Pattern, so default pivot to 0.0.
    pivot = report.get('Extracted_Pattern', {}).get('Pivot', 0.0)
    return f"${ticker.upper()}|{score}|{result_outcome(report)}|{pivot:.2f}"


# =====================================================================
# STAGE 3: VCP RECOGNITION ENGINE  (inlined above -- single-file build)
# =====================================================================
# Hands the catalyst-cleared names from Stage 2 to the VCP engine, completing
# the strict AND chain the pipeline was always built around:
#     Stage 1  Trend Template      -> structural pass
#     Stage 2  AI Catalyst filter  -> CATALYST_SCORE >= threshold
#     Stage 3  VCP Recognition     -> valid VCP setup   (this stage)
# The engine and its results formatter are defined just above in the "VCP
# RECOGNITION ENGINE" section of this same file. Stage 3 uses price data only
# and makes NO Gemini calls, so it runs even under --dry-run.
VCP_LOOKBACK_PERIOD  = "2y"        # history window handed to the VCP engine
VCP_BENCHMARK        = "^GSPC"     # S&P 500 index; RS leg benchmark (matches the file's SPY baseline)
VCP_CONTRACTION_MODE = "strict"    # strict / elite / general / loose
# strict (1.00) requires depths[i] <= depths[i-1]. "general" (1.10) let a
# wave 10% LARGER than the last count as a contraction: 20 -> 22 -> 24
# scored contraction_quality 1.000, the same as a real 20 -> 12 -> 7.
# This constant lives OUTSIDE the extracted engine block, so changing
# VCPConfig's default alone does NOT reach production -- the call at
# `VCPAnalyzerV4(..., contraction_mode=VCP_CONTRACTION_MODE)` overrides it.


def _flatten_columns(df):
    """Single-ticker yf.Ticker().history() already returns flat columns, but guard
    against a MultiIndex (e.g. if the fetch is ever swapped for yf.download)."""
    if df is not None and isinstance(df.columns, pd.MultiIndex):
        df = df.copy()
        df.columns = df.columns.droplevel(1)
    return df


def _regime_today():
    """Today's date as an ISO string. Local helper so the gate does not depend on
    a module-level datetime import that this file does not currently have."""
    import datetime as _d
    return _d.date.today().isoformat()


def _load_regime_params():
    """Resolve the regime gate's two constants from their single sources.

    regime_ma lives in ExposureConfig -- the same field param_snapshot checks
    against the frozen set, so the screener and the trader cannot drift. The
    bar-age ceiling lives in screen_contract, beside the sidecar it guards.

    Same contract as _load_vcp_threshold(): NO local fallback. A screener that
    guessed its own regime_ma would gate on a different market than the one that
    was backtested, and nothing would report it."""
    try:
        from kistrader.entry.exposure_controller import ExposureConfig
        from kistrader.entry.screen_contract import REGIME_MAX_BAR_AGE_DAYS
        return ExposureConfig().regime_ma, REGIME_MAX_BAR_AGE_DAYS
    except ImportError as e:
        raise SystemExit(
            f"[regime] FATAL: cannot read the regime parameters ({e}).\n"
            f"  regime_ma comes from kistrader.entry.exposure_controller and the\n"
            f"  bar-age ceiling from kistrader.entry.screen_contract. Refusing to\n"
            f"  guess either. From the repo root:\n"
            f"      pip install -e .                        (then re-run as-is)\n"
            f"      python -m screeners.us_small_v21         (no install needed)")


def _regime_probe(regime_ma, session_date, max_bar_age_days):
    """Evaluate the market regime ONCE, before any expensive work.

    Returns (state, close, ma, bar_date, index_df, reason) where state is one of
    'risk_on' / 'risk_off' / 'unavailable'. close and ma are None unless the
    state is decided, so an unusable probe can never be written to the sidecar as
    a usable one.

    The returned frame is handed to run_stage3_vcp so the benchmark is fetched
    once per run, not twice.

    regime_ma=None DISABLES the gate. That is the documented one-value rollback
    for the whole regime phase, so it has to be handled here rather than reaching
    the arithmetic below -- `len(closes) < None` is a TypeError, raised inside
    main(), which stops the screener from running at all. Returning index_df=None
    also hands the benchmark fetch back to run_stage3_vcp, exactly as before
    Phase 3b."""
    import datetime as _d
    if regime_ma is None:
        return ("disabled", None, None, None, None,
                "regime gate DISABLED (regime_ma=None) — scanning without it")
    try:
        df = _flatten_columns(_fetch_history(VCP_BENCHMARK, VCP_LOOKBACK_PERIOD))
    except Exception as e:                                    # noqa: BLE001
        return ("unavailable", None, None, None, None,
                f"{VCP_BENCHMARK} fetch raised {type(e).__name__}: {e}")
    if df is None or getattr(df, "empty", True) or "Close" not in df:
        return ("unavailable", None, None, None, None,
                f"{VCP_BENCHMARK} fetch returned no usable frame")

    closes = df["Close"].dropna()
    # A bar dated ON (or after) the session date is a LIVE, unsettled row: the
    # provider publishes a provisional row for the current session and it MOVES
    # between fetches, so two screeners minutes apart disagree and the regime
    # would rest on an unfinished close. Keep COMPLETED sessions only; the age
    # checks below still catch a frame that is merely stale. Found 2026-08-19.
    try:
        _sd_cut = _d.date.fromisoformat(str(session_date))
        # ONLY the session's own row is dropped. A frame whose newest bar is
        # AFTER the session date is not a live row -- it is bad data or a skewed
        # clock -- and must still be refused outright by the age check below.
        if len(closes) and closes.index[-1].date() == _sd_cut:
            closes = closes[[ts.date() < _sd_cut for ts in closes.index]]
    except Exception:                                          # noqa: BLE001
        pass
    if len(closes) < regime_ma:
        return ("unavailable", None, None, None, df,
                f"only {len(closes)} usable {VCP_BENCHMARK} bars, need {regime_ma}")

    close = float(closes.iloc[-1])
    ma = float(closes.tail(regime_ma).mean())
    try:
        bar_date = closes.index[-1].date().isoformat()
    except AttributeError:
        return ("unavailable", None, None, None, df,
                f"{VCP_BENCHMARK} frame carries no dated index")

    # The bar's OWN date, not the fetch's success. _fetch_history falls back to a
    # pickled cache on an empty provider response, so a "successful" fetch can
    # carry a bar from days ago -- which would otherwise become a confident
    # RISK_ON off stale data.
    try:
        age = (_d.date.fromisoformat(str(session_date))
               - _d.date.fromisoformat(bar_date)).days
    except ValueError:
        return ("unavailable", None, None, bar_date, df,
                f"unparseable dates (bar={bar_date!r}, session={session_date!r})")
    if age < 0:
        return ("unavailable", None, None, bar_date, df,
                f"benchmark bar {bar_date} is AFTER session {session_date}")
    if age > max_bar_age_days:
        return ("unavailable", None, None, bar_date, df,
                f"benchmark bar {bar_date} is {age} days before {session_date} "
                f"(max {max_bar_age_days}) -- probably a cached frame, not today's")

    state = "risk_on" if close >= ma else "risk_off"
    return (state, close, ma, bar_date, df,
            f"{VCP_BENCHMARK} close {close:.2f} vs ma{regime_ma} {ma:.2f} "
            f"(bar {bar_date})")


def run_stage3_vcp(stage2_passed, dry_run=False, index_df=None):
    """
    Run the VCP recognition engine on every Stage-2 passer and print the compact
    results table (Ticker|vcp score|outcome|pivot) from the engine's own
    formatter. Returns a list of (ticker, name, report) for any downstream use;
    `report` is None for a ticker whose price fetch or engine run failed.
    """
    print("\n" + "=" * 70)
    print("STAGE 3 of 3: VCP RECOGNITION ENGINE (vcp_pattern_v4_1)")
    print("=" * 70)

    if not stage2_passed:
        print("[-] No catalyst-cleared candidates to evaluate -- Stage 3 skipped.")
        print("=" * 70)
        return []

    # VCPAnalyzerV4 and its results formatter live in the "VCP RECOGNITION ENGINE"
    # section above -- this is a single self-contained file, nothing to import.

    # Benchmark fetched ONCE and reused for every candidate's RS leg. The engine
    # accepts index_df=None (degraded RS), so a failed fetch warns, not aborts.
    if index_df is None:
        print(f"[*] Fetching benchmark {VCP_BENCHMARK} ({VCP_LOOKBACK_PERIOD}) for the VCP RS leg...")
        index_df = _flatten_columns(_fetch_history(VCP_BENCHMARK, VCP_LOOKBACK_PERIOD))
    else:
        print(f"[*] Reusing the {VCP_BENCHMARK} frame the regime gate already fetched.")
    if index_df is None or index_df.empty:
        print(f"[!] Benchmark fetch failed -- the VCP RS leg runs in degraded mode (index_df=None).")
        index_df = None

    print(f"[*] Running the VCP engine on {len(stage2_passed)} catalyst-cleared "
          f"candidate(s) (mode='{VCP_CONTRACTION_MODE}', history='{VCP_LOOKBACK_PERIOD}')...\n")

    rows, results = [], []
    n = len(stage2_passed)
    for i, (ticker, name, catalyst_score) in enumerate(stage2_passed, 1):
        cat = "dry-run" if catalyst_score is None else f"catalyst={catalyst_score}"
        print(f"    [{i}/{n}] {ticker:<6} fetching {VCP_LOOKBACK_PERIOD} history... ({cat})", flush=True)

        stock_df = _flatten_columns(_fetch_history(ticker, VCP_LOOKBACK_PERIOD))
        if stock_df is None or stock_df.empty:
            print(f"           price fetch failed -- cannot run VCP. [skip]")
            rows.append(f"${ticker.upper()}|0|fail|0.00")
            results.append((ticker, name, None))
            continue

        try:
            engine = VCPAnalyzerV4(df=stock_df, index_df=index_df,
                                   contraction_mode=VCP_CONTRACTION_MODE)
            report = engine.generate_report()
        except Exception as e:
            print(f"           VCP engine error ({type(e).__name__}: {e}). [skip]")
            rows.append(f"${ticker.upper()}|0|fail|0.00")
            results.append((ticker, name, None))
            continue

        rows.append(format_result_row(ticker, report))
        results.append((ticker, name, report))
        print(f"           VCP {report.get('Score', 0)} ({report.get('Grade', '?')})")

    # The deliverable: the engine's own pipe-delimited results table.
    print("\n--- RESULTS ---")
    print(RESULTS_HEADER)
    for row in rows:
        print(row)

    # ---- FINAL PICKS: Stage 1 AND Stage 2 AND VCP >= VCP_SCORE_THRESHOLD ----
    finals = [(t, n, r) for (t, n, r) in results
              if r is not None and r.get('Score', 0) >= VCP_SCORE_THRESHOLD]
    print("\n" + "=" * 70)
    if finals:
        print(f"FINAL MATCHES: {len(finals)} name(s) cleared all three stages "
              f"(VCP >= {VCP_SCORE_THRESHOLD}):")
        for t, n, r in sorted(finals, key=lambda x: x[2].get('Score', 0), reverse=True):
            pivot = r.get('Extracted_Pattern', {}).get('Pivot', 0.0)
            print(f"    ${t.upper():<6} {n:<30} VCP {r.get('Score', 0)} "
                  f"({r.get('Grade', '?')})  pivot {pivot:.2f}")
    else:
        print(f"FINAL MATCHES: none reached VCP >= {VCP_SCORE_THRESHOLD}.")
    print("=" * 70)
    return results


# =====================================================================
# MAIN EXECUTION ENGINE
# =====================================================================
def _load_emitter():
    """Resolve the §1.6 candidate emitter, supporting BOTH invocations:
      * `python screeners\\us_small_v21.py`  -> needs `pip install -e .`
      * `python -m screeners.us_small_v21`   -> works from the repo root, no install
    Called as a PREFLIGHT at the top of main(): an emit run that cannot write its
    CSV must fail in the first second, not after a full scan + Gemini spend."""
    try:
        from candidate_emit import emit_candidates
        return emit_candidates
    except ImportError:
        pass
    try:
        from screeners.candidate_emit import emit_candidates
        return emit_candidates
    except ImportError as e:
        raise SystemExit(
            f"[emit] FATAL: cannot import the candidate emitter ({e}).\n"
            f"  This usually means the kistrader package is not importable from here.\n"
            f"  Fix either way, from the repo root:\n"
            f"      pip install -e .                              (then re-run this command as-is)\n"
            f"      python -m screeners.us_small_v21 --emit-candidates   (no install needed)\n"
            f"  Refusing to start: a run that cannot write its CSV would spend Gemini\n"
            f"  quota for nothing."
        )


def _assert_kistrader_local():
    """PATCH G -- refuse to run against a kistrader from another checkout.

    This file lives at <root>/screeners/, so the only correct kistrader is
    <root>/kistrader/. A script run puts the SCRIPT's directory on sys.path and
    NOT the cwd, so `import kistrader` resolves through site-packages -- and on
    2026-08-25 that editable install pointed at a different repository. The
    screener was running clean-tree source over an old-repo package, and
    param_snapshot's tree sha could not see it because it only ever describes
    the repo that param_snapshot.py itself lives in.
    """
    import kistrader
    here = os.path.dirname(os.path.realpath(__file__))          # <root>/screeners
    want = os.path.normcase(os.path.join(os.path.dirname(here), "kistrader"))
    got = os.path.normcase(os.path.dirname(os.path.realpath(kistrader.__file__)))
    if got != want:
        raise SystemExit(
            "FATAL: this screener is running someone else's kistrader.\n"
            "  this file  : %s\n"
            "  expected   : %s\n"
            "  actually   : %s\n"
            "Two checkouts in one process: the screener would read parameters "
            "from a tree nobody is editing, and param_snapshot cannot detect "
            "it. Fix with:\n"
            "    pip install -e %s"
            % (os.path.realpath(__file__), want, got, os.path.dirname(here)))


def main(limit=None, dry_run=False, emit_path=None, session_date=None,
         emit_threshold=None):
    _assert_kistrader_local()                                    # PATCH G
    _setup_run_log("smallcap")
    # ---- emit preflight (§1.6): resolve the writer BEFORE any expensive work ----
    emit_fn = _load_emitter() if (emit_path and not dry_run) else None
    # §9 supervised-test override: lowers ONLY the emit filter. VCP_SCORE_THRESHOLD
    # (the strategy bar) is never touched, so it cannot survive as a silent file edit.
    emit_thr = VCP_SCORE_THRESHOLD if emit_threshold is None else float(emit_threshold)
    _degraded = emit_thr < VCP_SCORE_THRESHOLD
    if _degraded and emit_path and not dry_run:
        print('=' * 70)
        print(f'*** DEGRADED EMIT THRESHOLD: {emit_thr} (strategy bar is '
              f'{VCP_SCORE_THRESHOLD}, unchanged)')
        print('*** SUPERVISED PLUMBING TEST ONLY — rows emitted below the real bar')
        print('*** are NOT strategy-grade candidates. Do not run unattended.')
        print('=' * 70)
    # ---- REGIME GATE (Phase 3b) -------------------------------------------------
    # Runs BEFORE Stage 1 on purpose: a RISK_OFF day then costs one benchmark
    # fetch instead of the full ticker scan plus every Gemini call. The backtest
    # gate empties `eligible` on those days and leaves open positions alone, so
    # emitting zero rows is the faithful port -- and the sidecar carries the
    # reason, which zero rows alone cannot.
    _sess = session_date or _regime_today()
    _rma, _max_age = _load_regime_params()
    _state, _bclose, _bma, _bar, _index_df, _why = _regime_probe(
        _rma, _sess, _max_age)
    # PATCH F4: regime_declared says this screener KNOWS about the gate, so the
    # sidecar receipt is written even when the gate is off and there is no
    # regime to record. One key here covers all three emit call sites below.
    _regime_kw = dict(benchmark=VCP_BENCHMARK, regime_ma=_rma,
                      regime_declared=True,
                      benchmark_close=_bclose, benchmark_ma=_bma,
                      benchmark_bar_date=_bar)
    print("=" * 70)
    print(f"REGIME GATE: {_state.upper()} -- {_why}")
    if _state == "disabled":
        print("  NOTE: the sidecar IS written, with regime_ma=null and no "
              "benchmark -- it still carries the session date, this screener's "
              "vcp_threshold and any --emit-threshold flag, which the trader "
              "checks either way. The trader must ALSO be running "
              "ExposureConfig(regime_ma=None), or it will refuse the mismatch.")
    print("=" * 70)
    if _state not in ("risk_on", "disabled"):
        # UNAVAILABLE is treated exactly like RISK_OFF: a gate that cannot
        # evaluate must not pass.
        print(f"[regime] {_state} -- no new entries today. Skipping the scan "
              f"entirely (no Stage-1 fetches, no Gemini spend).")
        if emit_path and not dry_run:
            emit_fn(stage3_results=[], passed_stocks=[], stage2_passed=[],
                    out_path=emit_path, vcp_threshold=emit_thr,
                    session_date=_sess,
                    source=f"us_small_v21" + (f" DEGRADED@{emit_thr}" if _degraded else ""),
                    **_regime_kw)
        else:
            print("[regime] no --emit-candidates (or --dry-run): nothing written. "
                  "The trader will fail closed on the missing/stale sidecar.")
        print("=" * 70)
        return

    universe = load_universe()
    if not universe:
        print("[-] Failed to load corporate datasets (both S&P 400 and S&P 600 fetches failed).", flush=True)
        return

    spy_return = calculate_spy_6m_return()
    print(f"[+] Baseline SPY Return: {spy_return * 100:.2f}%\n", flush=True)

    print("=" * 70)
    print("STAGE 1 of 3: TECHNICAL SCREENING (Minervini Trend Template / SEPA)")
    print("=" * 70)

    tickers_list = list(universe.keys())
    if limit is not None:
        tickers_list = tickers_list[:limit]
        print(f"[LIMIT] Scanning only the first {len(tickers_list)} tickers. "
              f"NOTE: RS Rating is a percentile, so over a tiny set it is not meaningful "
              f"-- this mode is for testing plumbing, not for real signals.\n", flush=True)
    try:
        passed_stocks, status_counts = run_parallel_scan(tickers_list, universe, spy_return)
    except KeyboardInterrupt:
        print("[-] Scan cancelled by user.", flush=True)
        return

    print("\n" + "=" * 70)
    print(f"STAGE 1 COMPLETE: {len(passed_stocks)} stock(s) passed all 8 Minervini criteria")
    print("-" * 70)
    for status, count in sorted(status_counts.items(), key=lambda kv: -kv[1]):
        print(f"    {STATUS_LABELS.get(status, status):<42} {count}")
    print("=" * 70)

    if passed_stocks:
        # Ranked by RS Rating (the real percentile measure), then by the
        # underlying raw score for deterministic ordering among same-integer
        # ratings (ties are common on a 1-99 scale), then by ticker symbol
        # as a final tiebreaker so ordering never depends on thread timing.
        passed_stocks.sort(key=lambda x: (x[5], x[6], x[0]), reverse=True)
        top_candidates = passed_stocks[:TOP_N_CANDIDATES]

        print(f"\n[*] Top {len(top_candidates)} candidates selected for Stage 2 (ranked by RS Rating):")
        for t, n, r, cp, h20, rs, raw in top_candidates:
            alpha = r - spy_return
            print(f"    - {t:<6} {n:<30} RS Rating: {rs:3d}   6mo Return: {r * 100:6.1f}%   Alpha: {alpha * 100:+5.1f}%   Price: ${cp:.2f}")

        print("\n" + "=" * 70)
        print("STAGE 2 of 3: AI CATALYST EVALUATION (Structured Fundamental Filter — Gemini 2.5 Flash)")
        print(f"          (gate: CATALYST_SCORE >= {CATALYST_SCORE_THRESHOLD}/100 to advance to Stage 3)")
        print("=" * 70)

        # ---- Math floor: Python scores categories 1-2 from real fundamentals ----
        # Computed up front for every candidate so a strong-enough math score can
        # carry a stock even when Gemini lacks qualitative data ([KNOWLEDGE_GAP]).
        math_by_ticker = {}        # TICKER_UPPER -> (math_score 0-45, breakdown)
        if not dry_run:
            print(f"[*] Computing the 45-pt math floor for {len(top_candidates)} candidate(s) "
                  f"(Finnhub -> yfinance fundamentals)...")
            for t, n, *_ in top_candidates:
                m_score, mbd = compute_math_floor(DATA.fundamentals(t))
                math_by_ticker[t.upper()] = (m_score, mbd)
                note = "" if mbd.get('math_available') else "  [fundamentals unavailable -> 0]"
                print(f"    {t:<6} math {m_score:>5}/45  (EPS {mbd.get('cat1_earnings')}, "
                      f"REV {mbd.get('cat2_revenue')}; src={mbd.get('source') or 'none'}){note}")

        stage2_passed = []         # tickers cleared (catalyst filter)
        stage2_api_failures = 0     # batch calls that errored at the API
        stage2_quota_hit = False    # set if the daily Gemini quota ran out mid-stage
        stage2_unevaluated = []     # tickers a batch reply did not return a score for
        stage2_fails = []           # (ticker, name, rs, score, reason) for rejected names
        ground_queue = []           # (ticker, name, rs, mfloor) for GAP names math couldn't carry

        batches = [top_candidates[i:i + STAGE2_BATCH_SIZE]
                   for i in range(0, len(top_candidates), STAGE2_BATCH_SIZE)]
        print(f"[*] Scoring {len(top_candidates)} candidate(s) in {len(batches)} batch call(s) "
              f"of up to {STAGE2_BATCH_SIZE} (free-tier friendly).")

        for bi, batch in enumerate(batches, 1):
            batch_tickers = [row[0] for row in batch]
            print(f"\n{'-' * 70}")
            print(f"  BATCH {bi}/{len(batches)} ({len(batch)} stocks): {', '.join(batch_tickers)}")
            print(f"{'-' * 70}")

            if dry_run:
                print(f"  [DRY RUN] would score these {len(batch)} stocks in ONE Gemini call -- skipped.")
                for ticker, name, *_ in batch:
                    stage2_passed.append((ticker, name, None))
                continue

            analysis = analyze_catalysts_batch([(row[0], row[1]) for row in batch])

            if analysis == "QUOTA_EXHAUSTED":
                print(f"\n[!] STOPPING Stage 2: the Gemini daily request quota is exhausted -- no "
                      f"further calls can succeed today. Remaining batches are left UNEVALUATED "
                      f"(NOT rejected). Enable billing for a higher quota, or re-run tomorrow.")
                stage2_quota_hit = True
                stage2_unevaluated.extend(batch_tickers)
                break

            if isinstance(analysis, str) and analysis.startswith("API Error"):
                stage2_api_failures += 1
                print(f"  [!] Batch {bi} failed at the API ({analysis}); its {len(batch)} stock(s) "
                      f"are left UNEVALUATED (not rejected).")
                stage2_unevaluated.extend(batch_tickers)
                continue

            quals = extract_batch_qual(analysis)
            if not quals:
                # Model ignored the format entirely -- show raw so it's debuggable
                # instead of silently leaving the whole batch unevaluated.
                print(f"  [!] Could not parse any QUAL_SCORE from batch {bi}. Raw reply:")
                print(analysis)

            for ticker, name, ret, cp, h20, rs, raw in batch:
                mfloor, _mbd = math_by_ticker.get(ticker.upper(), (0.0, {}))
                qentry = quals.get(ticker.upper())
                if qentry is None:
                    print(f"  {ticker:<6} UNEVALUATED  | no qual returned (omission/truncation) | [skip]")
                    stage2_unevaluated.append(ticker)
                    continue
                qual, reason = qentry

                if qual == 'GAP':
                    # Gemini lacks data. If the math floor alone already clears the
                    # gate, the numbers carry it -- no live lookup needed. Else queue.
                    final = round(mfloor, 1)
                    if final >= CATALYST_SCORE_THRESHOLD:
                        print(f"  {ticker:<6} math {mfloor:>5} + qual GAP   = {final:>5}  | "
                              f"{reason} | [match: carried by math]")
                        stage2_passed.append((ticker, name, final))
                    else:
                        print(f"  {ticker:<6} math {mfloor:>5} + qual [KNOWLEDGE_GAP] | {reason} | "
                              f"[queued for grounded lookup]")
                        ground_queue.append((ticker, name, rs, mfloor))
                    continue

                final = round(mfloor + qual, 1)
                verdict = "match" if final >= CATALYST_SCORE_THRESHOLD else "fail"
                print(f"  {ticker:<6} math {mfloor:>5} + qual {qual:>3}   = {final:>5}  | {reason} | [{verdict}]")
                if verdict == "match":
                    stage2_passed.append((ticker, name, final))
                else:
                    stage2_fails.append((ticker, name, rs, final, reason))
            # ---- Catalyst-cleared names in stage2_passed advance to Stage 3 ----
            # Stage 3 (the standalone VCP engine module) is handed only these,
            # preserving the strict AND logic of the pipeline.

        # ---- Stage 2c: selective grounded re-score of knowledge-gap anomalies ----
        # Spend a grounded Google-Search call ONLY on the few high-RS rejects whose
        # reason smells like stale knowledge (e.g. SNDK "not a currently traded
        # company"). One stock per call so the search-verification is trustworthy.
        if GROUNDING_ENABLED and not dry_run and not stage2_quota_hit:
            seen, targets = set(), []
            for ticker, name, rs, mfloor in ground_queue:                # explicit gaps first
                if ticker.upper() not in seen:
                    seen.add(ticker.upper())
                    targets.append((ticker, name, rs, mfloor))
            for ticker, name, rs, score, reason in sorted(stage2_fails, key=lambda f: f[2], reverse=True):
                if ticker.upper() in seen:
                    continue
                if _looks_like_knowledge_gap(score, reason, rs):         # secondary heuristic
                    seen.add(ticker.upper())
                    m = math_by_ticker.get(ticker.upper(), (0.0, {}))[0]
                    targets.append((ticker, name, rs, m))
            targets.sort(key=lambda q: q[2], reverse=True)               # highest RS first
            targets = targets[:MAX_GROUNDED_RESCORES]
            if targets:
                print(f"\n{'-' * 70}")
                print(f"  STAGE 2c: grounded qualitative re-score of {len(targets)} name(s) "
                      f"([KNOWLEDGE_GAP] / stale-knowledge) -- one Google-Search call each.")
                print(f"{'-' * 70}")
                for ticker, name, rs, mfloor in targets:
                    text, searched = reground_one(ticker, name)
                    if text == "QUOTA_EXHAUSTED":
                        print(f"  [!] Daily quota hit during grounding -- stopping. {ticker} and any "
                              f"remaining names keep their pre-grounding verdict.")
                        stage2_quota_hit = True
                        break
                    if isinstance(text, str) and text.startswith("API Error"):
                        print(f"  {ticker:<6} grounded call failed ({text}); not rescued. "
                              f"(Grounding may need billing enabled on the API tier.)")
                        continue
                    if not searched:
                        print(f"  {ticker:<6} grounding did NOT actually search (verification failed) "
                              f"-- NOT trusted; not rescued.")
                        continue
                    entry = extract_batch_qual(text).get(ticker.upper())
                    if entry is None or entry[0] == 'GAP':
                        print(f"  {ticker:<6} grounded reply unparseable / still a gap; not rescued.")
                        continue
                    gqual, greason = entry
                    final = round(mfloor + gqual, 1)
                    verdict = "match" if final >= CATALYST_SCORE_THRESHOLD else "fail"
                    print(f"  {ticker:<6} math {mfloor:>5} + grounded qual {gqual:>3} = {final:>5}  | "
                          f"{greason} | [{verdict}]   (searched OK)")
                    if verdict == "match":
                        stage2_passed.append((ticker, name, final))
                        print(f"           -> RESCUED: now advances to Stage 3.")

        print("=" * 70)
        if stage2_passed:
            print(f"STAGE 2 COMPLETE: {len(stage2_passed)} of {len(top_candidates)} "
                  f"candidate(s) cleared the catalyst filter; queued for Stage 3 (VCP engine):")
            for t, n, s in stage2_passed:
                score_str = "(dry run -- not scored)" if s is None else f"Catalyst Score: {s}/100"
                print(f"    - {t:<6} {n:<30} {score_str}")
        else:
            print(f"STAGE 2 COMPLETE: 0 of {len(top_candidates)} candidate(s) cleared the "
                  f"catalyst filter (threshold {CATALYST_SCORE_THRESHOLD}). Nothing advances to Stage 3.")
        if stage2_api_failures:
            print(f"[!] WARNING: {stage2_api_failures} batch call(s) failed at the API "
                  f"(rate-limit/quota or a bad SDK/key). Their stocks were left UNEVALUATED, "
                  f"not rejected -- re-run or check quota.")
        if stage2_unevaluated:
            print(f"[!] UNEVALUATED ({len(stage2_unevaluated)}): {', '.join(stage2_unevaluated)} "
                  f"-- left unscored (batch failure, truncation, or model omission), NOT rejected.")
        if stage2_quota_hit:
            print(f"[!] NOTE: Stage 2 stopped early on the daily quota. Remaining batches were "
                  f"NOT scored and are NOT rejected -- finish with billing enabled (Tier 1) or tomorrow.")

        # ---- Stage 3: VCP recognition engine on the catalyst-cleared names ----
        # Completes the strict AND chain. Free (no Gemini), so it runs even under
        # --dry-run -- exactly the Stage 1 -> 2 -> 3 hand-off dry-run mode validates.
        results = run_stage3_vcp(stage2_passed, dry_run=dry_run,
                                 index_df=_index_df)

        # ---- Step 3 (§1.6 wiring): machine-readable candidates.csv ------------
        if emit_path:
            if dry_run:
                print(f"[emit] --dry-run: NOT writing {emit_path} -- dry-run has no real "
                      f"Stage-2 scores. Plumbing CSVs are written by hand (docs §9).", flush=True)
            else:
                emit_fn(stage3_results=results,
                        passed_stocks=passed_stocks,
                        stage2_passed=stage2_passed,
                        out_path=emit_path,
                        vcp_threshold=emit_thr,
                        session_date=_sess,
                        source=f"us_small_v21" + (f" DEGRADED@{emit_thr}" if _degraded else ""),
                        **_regime_kw)
    else:
        print("[-] No stocks met the Minervini Trend Template today.", flush=True)
        if emit_path and not dry_run:
            # Still rewrite the CSV (empty result is a VALID result): a stale
            # candidates file must never survive a real zero-candidate day.
            emit_fn(stage3_results=[], passed_stocks=[], stage2_passed=[],
                    out_path=emit_path, vcp_threshold=emit_thr,
                    session_date=_sess, source=f"us_small_v21" + (f" DEGRADED@{emit_thr}" if _degraded else ""),
                    **_regime_kw)
    print("=" * 70, flush=True)


# CRITICAL EXECUTION BLOCK: This triggers the script to run!
if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Minervini US small/mid-cap screener (Stage 1 technicals + Stage 2 AI catalyst filter)."
    )
    parser.add_argument(
        "--limit", type=int, default=None, metavar="N",
        help="Scan only the first N tickers. Fast plumbing test. RS Rating is a "
             "percentile, so a small N makes RS meaningless -- use only for testing flow.",
    )
    parser.add_argument(
        "--dry-run", action="store_true",
        help="Skip every Gemini call in Stage 2 (no API quota or wait). Shows which "
             "candidates would be evaluated and passes them straight through.",
    )
    parser.add_argument(
        "--emit-candidates", nargs="?", const="candidates.csv", default=None,
        metavar="PATH",
        help="After Stage 3, write the machine-readable candidates CSV for the "
             "kistrader pipeline (schema: kistrader.entry.screen_contract). Bare "
             "flag defaults to candidates.csv. Same-date rows from the other "
             "screener are preserved (merged); rows from other dates are dropped "
             "as stale. No-op under --dry-run.",
    )
    parser.add_argument(
        "--emit-threshold", type=float, default=None, metavar="SCORE",
        help="SUPERVISED TEST ONLY. Emit candidates at this VCP score instead of "
             "VCP_SCORE_THRESHOLD. Lowers ONLY the emit filter -- the strategy bar in "
             "the file is never modified, so a degraded run cannot persist. The run "
             "banners and the CSV's source field both record the degrade.",
    )
    parser.add_argument(
        "--session-date", default=None, metavar="YYYY-MM-DD",
        help="Session date stamped on emitted candidates (default: today, local "
             "time). Informational -- the pipeline stamps its own date at arm time.",
    )
    args = parser.parse_args()
    main(limit=args.limit, dry_run=args.dry_run,
         emit_path=args.emit_candidates, session_date=args.session_date,
         emit_threshold=args.emit_threshold)
