#!/usr/bin/env python3
"""
Screener -> decision-engine output contract  (checklist §1.6)
=============================================================

The screener suite currently emits only `Ticker|vcp score|outcome|pivot`
(RESULTS_HEADER). That is enough for a human-readable table but NOT enough to
arm a trade: the decision engine needs RS%, the catalyst (Stage-2) score, the
base geometry (pivot / contraction low), and an ATR to size the position and
derive a stop. This module is the *formal, stable* schema that closes that gap —
one `Candidate` per name, plus a CSV/JSON round-trip the decision engine consumes.

Field provenance (all already computed inside the screener today):
  ticker, name       -- Stage 1 universe row
  exchange           -- kis_tradable_universe.resolve(ticker)  (NAS/NYS/AMS)
  rs_rating          -- compute_rs_ratings()  (IBD percentile, 1..99)
  stage2_score       -- catalyst score  (math floor 0-45 + Gemini 0-55 -> 0..100)
  vcp_score          -- VCPAnalyzerV4.generate_report()['Score']  (0..100)
  pivot              -- report['Extracted_Pattern']['Pivot']      (LOCKED;
                        == Wave_Highs[-1], the final contraction's high —
                        verified 21/21 on live reports 2026-07-18)
  base_high          -- report['Extracted_Pattern']['Base_High']
  base_low           -- report['Extracted_Pattern']['Base_Low']  (whole base's
                        absolute floor; falls back to min(Wave_Lows))
  contraction_low    -- report['Extracted_Pattern']['Wave_Lows'][-1]  (the FINAL
                        contraction's low — the Minervini stop anchor, v3)
  depth_pct          -- (base_high - base_low) / base_high         (0..1, WHOLE base)
  last_close         -- latest bar Close
  atr                -- latest ATR20 (absolute $)
  trade_signal       -- report['Trade_Signal_Active']  (close > pivot on
                        breakout-multiple volume — a volume-confirmed breakout)

v3 (2026-07-18): added `contraction_low`. The stop moved from the whole base's
floor to the FINAL CONTRACTION's low (Minervini doctrine): `pivot` was already
the final contraction's high, so entering off the final contraction while
stopping off the whole base mixed two structures in one trade — and rejected
real VCPs as "too wide" (probe 2026-07-18: 3/21 -> 10/21 armable). base_high /
base_low / depth_pct KEEP their whole-base meanings (validation + audit trail);
only the stop anchor moved. On Base_Low vs min(Wave_Lows): Base_Low can be
genuinely lower (observed 2/21 — AMAT, URI), but since v3 neither drives the
stop; the fallback remains for base-geometry purposes only.

On MISSING inputs the contract does NOT paper over gaps silently — that was the
coupling hazard (defaulting last_close to the pivot made the extension guard
pass by construction; atr==0 quietly dropped the ATR stop-floor). Instead:

  * a missing Latest_Close leaves last_close unset and marks close_known=False.
    The decision engine FAILS CLOSED unless allow_missing_close=True.
  * a missing Latest_ATR sets atr=0.0 -> a contraction-only stop, LABELLED via
    stop_basis. Set require_atr=True to reject instead.
  * a missing Wave_Lows leaves contraction_low=0.0 (UNKNOWN). It is NEVER
    copied from base_low — that would silently reproduce the deleted base-anchor
    behavior. The decision engine FAILS CLOSED (cannot place the strategy's stop).

The schema is intentionally flat and versioned (SCHEMA_VERSION) so a change is
detectable by the consumer instead of silently mis-parsed. FIELDS is append-only.
"""
from __future__ import annotations

import csv
import json
import math
from dataclasses import dataclass, asdict
from typing import Optional


SCHEMA_VERSION = 3   # v3: contraction_low (Minervini stop anchor)
                     # v2: close_known provenance flag (§1.6 coupling fix)

# Column order for CSV. Stable: append-only if you ever extend it, and bump
# SCHEMA_VERSION so read_candidates can reject an unknown layout loudly.
FIELDS = [
    "schema_version", "session_date", "ticker", "name", "exchange",
    "rs_rating", "stage2_score", "vcp_score",
    "pivot", "base_high", "base_low", "depth_pct",
    "last_close", "atr", "trade_signal", "close_known",
    "contraction_low",
]


def make_order_key(ticker: str, session_date: str) -> str:
    """Deterministic trade id carried from entry through exit. Matches the exit
    engine's convention ('MU:2026-06-29') so one position keeps ONE order_key
    across its whole lifecycle and the event store groups it under that key."""
    return f"{ticker.strip().upper()}:{session_date}"


def _finite(x, default=0.0) -> float:
    try:
        v = float(x)
    except (TypeError, ValueError):
        return default
    return v if math.isfinite(v) else default


@dataclass
class Candidate:
    """One screener-cleared name, fully specified for the decision engine.

    A Candidate is a *fact sheet*, not a decision: it says nothing about size,
    stop, or whether we will actually trade it. The decision engine turns a
    ranked, capped subset of Candidates into EntryPlans.
    """
    ticker: str
    exchange: str                 # NAS / NYS / AMS  (from the tradability gate)
    rs_rating: int                # 1..99
    stage2_score: float           # 0..100  (catalyst)
    vcp_score: float              # 0..100
    pivot: float                  # LOCKED breakout trigger (final contraction's high)
    base_high: float              # whole base's high        (geometry/audit)
    base_low: float               # whole base's floor       (geometry/audit; NOT the stop)
    depth_pct: float              # 0..1  WHOLE-base depth   (geometry/audit)
    last_close: float
    atr: float = 0.0              # absolute ATR20 ($); 0.0 => contraction-only stop
    trade_signal: bool = False    # volume-confirmed breakout on the last bar
    session_date: str = ""        # YYYY-MM-DD
    name: str = ""
    close_known: bool = True      # False => last_close absent (extension guard can't run)
    contraction_low: float = 0.0  # FINAL contraction's low = Wave_Lows[-1];
                                  # 0.0 => UNKNOWN (engine fails closed: no stop anchor)
    schema_version: int = SCHEMA_VERSION

    def order_key(self) -> str:
        return make_order_key(self.ticker, self.session_date)

    # ---- validation: a Candidate that can't be safely sized is rejected here,
    #      not deep inside the sizer where the failure mode is a bad share count.
    def problems(self) -> list:
        p = []
        if not self.ticker:
            p.append("empty ticker")
        if self.exchange not in ("NAS", "NYS", "AMS"):
            p.append(f"bad exchange {self.exchange!r}")
        if not (1 <= self.rs_rating <= 99):
            p.append(f"rs_rating out of range: {self.rs_rating}")
        if not (0 <= self.stage2_score <= 100):
            p.append(f"stage2_score out of range: {self.stage2_score}")
        if not (0 <= self.vcp_score <= 100):
            p.append(f"vcp_score out of range: {self.vcp_score}")
        if self.pivot <= 0:
            p.append("pivot <= 0")
        if self.base_low <= 0 or self.base_high <= 0:
            p.append("base_low/base_high <= 0")
        if self.base_low >= self.base_high:
            p.append("base_low >= base_high")
        if not (0.0 <= self.depth_pct < 1.0):
            p.append(f"depth_pct out of range: {self.depth_pct}")
        # last_close is only required to be positive when it is actually KNOWN.
        # An unknown close is not "invalid data" — it's a missing input the
        # decision engine handles explicitly (fail-closed on the extension guard),
        # so we don't want it to look like a corrupt row here.
        if self.close_known and self.last_close <= 0:
            p.append("last_close <= 0")
        if self.atr < 0:
            p.append("atr < 0")
        # contraction_low: 0.0 is a legal UNKNOWN (engine fails closed). A
        # PRESENT value must sit below the pivot — a wave low at/above its own
        # wave's high (pivot == Wave_Highs[-1], verified 21/21) is corrupt.
        # NOTE deliberately NOT checked: contraction_low vs base_low. The two
        # are measured over slightly different windows in the screener, so the
        # final wave's low can legitimately undercut the whole base's floor by
        # cents (observed 3/21 on 2026-07-20: VLO, SWK, ADM) — and a final
        # contraction undercutting prior lows is the classic SHAKEOUT, a
        # feature of strong bases, not corruption. An earlier version of this
        # check dropped exactly those setups.
        if self.contraction_low < 0:
            p.append("contraction_low < 0")
        elif self.contraction_low > 0:
            if self.pivot > 0 and self.contraction_low >= self.pivot:
                p.append("contraction_low >= pivot (corrupt wave geometry)")
        return p

    def is_valid(self) -> bool:
        return not self.problems()

    def to_row(self) -> dict:
        d = asdict(self)
        d["trade_signal"] = int(bool(self.trade_signal))
        d["close_known"] = int(bool(self.close_known))
        return d


def candidate_from_report(ticker: str, exchange: str, rs_rating: int,
                          stage2_score: float, report: dict, session_date: str,
                          name: str = "", last_close: Optional[float] = None,
                          atr: Optional[float] = None) -> Candidate:
    """Build a Candidate from a VCP generate_report() dict + the Stage-1/2 scores.

    `report` is exactly what VCPAnalyzerV4.generate_report() returns. The §1.6
    keys (Latest_Close / Latest_ATR / Base_Low) are used when present; the v3
    stop anchor comes from Wave_Lows[-1] (the final contraction's low). Absent
    inputs propagate as UNKNOWN (close_known=False / atr=0.0 /
    contraction_low=0.0) and the decision engine handles each explicitly —
    fail-closed for close and contraction_low, labelled degrade for atr.
    """
    ep = report.get("Extracted_Pattern", {}) or {}
    pivot = _finite(ep.get("Pivot", 0.0))
    base_high = _finite(ep.get("Base_High", 0.0))

    base_low = _finite(ep.get("Base_Low", 0.0))
    lows_raw = ep.get("Wave_Lows") or []
    if base_low <= 0:
        lows = [_finite(x) for x in lows_raw if _finite(x) > 0]
        base_low = min(lows) if lows else 0.0

    # v3 stop anchor: the FINAL contraction's low. Waves are chronological
    # (Pivot == Wave_Highs[-1], verified 21/21), so [-1] is the final one.
    # Absent/garbage -> 0.0 (UNKNOWN); never fabricated from base_low.
    contraction_low = _finite(lows_raw[-1]) if lows_raw else 0.0
    if contraction_low < 0:
        contraction_low = 0.0

    # last_close: prefer the caller's value, then the screener field. We do NOT
    # fall back to the pivot — a fabricated close would silently satisfy the
    # extension guard. If we have no real close, we say so (close_known=False)
    # and let the decision engine decide (fail-closed by default).
    if last_close is None:
        close_val = _finite(ep.get("Latest_Close", 0.0))
        close_known = close_val > 0
        last_close = close_val
    else:
        last_close = _finite(last_close)
        close_known = last_close > 0

    if atr is None:
        atr = _finite(ep.get("Latest_ATR", 0.0))   # absent -> 0.0 -> contraction-only

    depth = 0.0
    if base_high > 0 and 0 < base_low < base_high:
        depth = (base_high - base_low) / base_high

    return Candidate(
        ticker=ticker.strip().upper(),
        exchange=exchange,
        rs_rating=int(rs_rating),
        stage2_score=_finite(stage2_score),
        vcp_score=_finite(report.get("Score", 0.0)),
        pivot=pivot,
        base_high=base_high,
        base_low=base_low,
        depth_pct=depth,
        last_close=_finite(last_close),
        atr=_finite(atr),
        trade_signal=bool(report.get("Trade_Signal_Active", False)),
        session_date=session_date,
        name=name,
        close_known=close_known,
        contraction_low=contraction_low,
    )


# ---------------------------------------------------------------------------
# Serialization — a stable CSV/JSON the decision engine reads. Fail-CLOSED on a
# malformed row (skip + collect), so one bad line never poisons the batch.
# ---------------------------------------------------------------------------

def write_candidates(path: str, candidates) -> int:
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=FIELDS)
        w.writeheader()
        n = 0
        for c in candidates:
            w.writerow(c.to_row())
            n += 1
    return n


def read_candidates(path: str, on_bad=None) -> list:
    """Read candidates.csv -> [Candidate]. Malformed/out-of-range rows are
    skipped (reported via on_bad(row, reasons)) rather than raising, so a single
    corrupt line can't abort the whole arming run. schema_version is checked
    STRICTLY per row: a v2 file fails loudly with the true reason (stale layout),
    never limps in with contraction_low silently unknown."""
    out = []
    with open(path, newline="", encoding="utf-8") as f:
        r = csv.DictReader(f)
        if r.fieldnames and "schema_version" in r.fieldnames:
            pass  # layout looks current; per-row version is checked below too
        for row in r:
            try:
                ver = int(row.get("schema_version", SCHEMA_VERSION))
                if ver != SCHEMA_VERSION:
                    raise ValueError(f"schema_version {ver} != {SCHEMA_VERSION}")
                c = Candidate(
                    ticker=str(row["ticker"]).strip().upper(),
                    exchange=str(row["exchange"]).strip().upper(),
                    rs_rating=int(float(row["rs_rating"])),
                    stage2_score=float(row["stage2_score"]),
                    vcp_score=float(row["vcp_score"]),
                    pivot=float(row["pivot"]),
                    base_high=float(row["base_high"]),
                    base_low=float(row["base_low"]),
                    depth_pct=float(row["depth_pct"]),
                    last_close=float(row["last_close"]),
                    atr=float(row.get("atr", 0.0) or 0.0),
                    trade_signal=bool(int(float(row.get("trade_signal", 0) or 0))),
                    session_date=str(row.get("session_date", "")).strip(),
                    name=str(row.get("name", "")).strip(),
                    # absent provenance column -> assume UNKNOWN (safe: engine fails closed)
                    close_known=bool(int(float(row.get("close_known", 0) or 0))),
                    # v3 column is REQUIRED at v3 (KeyError -> on_bad); 0.0 = UNKNOWN
                    contraction_low=float(row["contraction_low"]),
                )
            except (KeyError, ValueError, TypeError) as e:
                if on_bad:
                    on_bad(row, [str(e)])
                continue
            probs = c.problems()
            if probs:
                if on_bad:
                    on_bad(row, probs)
                continue
            out.append(c)
    return out


def write_candidates_json(path: str, candidates) -> int:
    payload = {"schema_version": SCHEMA_VERSION,
               "candidates": [asdict(c) for c in candidates]}
    with open(path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2)
    return len(candidates)


def read_candidates_json(path: str, on_bad=None) -> list:
    with open(path, encoding="utf-8") as f:
        payload = json.load(f)
    if payload.get("schema_version") != SCHEMA_VERSION:
        raise ValueError(f"schema_version {payload.get('schema_version')} "
                         f"!= {SCHEMA_VERSION}")
    out = []
    for d in payload.get("candidates", []):
        d = dict(d)
        d.setdefault("close_known", False)       # absent -> UNKNOWN (engine fails closed)
        d.setdefault("contraction_low", 0.0)     # absent -> UNKNOWN (engine fails closed)
        try:
            c = Candidate(**d)
        except TypeError as e:
            if on_bad:
                on_bad(d, [str(e)])
            continue
        probs = c.problems()
        if probs:
            if on_bad:
                on_bad(d, probs)
            continue
        out.append(c)
    return out
