#!/usr/bin/env python3
"""
patch_phase4c.py -- make the alerts that BLOCK TRADING reach the phone.

MEASURED against the real notifier.classify(), not assumed:

    condition            severity  reaches phone?
    risk_off day         WARN      log only        <- correct, normal operation
    sidecar MISSING      WARN      log only        <- WRONG
    sidecar STALE        WARN      log only        <- WRONG
    degraded run         WARN      log only        <- WRONG

The last three are misconfigurations that stop ALL new entries: the screener
produced a CSV but no sidecar, the sidecar is from another session, or someone
left --emit-threshold on. The system correctly refuses to trade and correctly
writes it to the rotating log -- where nobody looks until they wonder why nothing
has traded for a week.

THE FIX, without touching the notifier's policy
The notifier defines CRITICAL as "the engine hit something it cannot resolve".
An UNAVAILABLE regime is exactly that; a RISK_OFF regime is not -- it is the
market answering the question. So the two are split:

  RISK_OFF      -> unchanged wording, stays WARN. A quiet phone on a normal
                   no-trade day is the design goal, not an oversight.
  UNAVAILABLE   -> "ARM BLOCKED: regime UNAVAILABLE ..." -- the vocabulary
                   arm_today already uses for a stale or missing CSV, and
                   already in the notifier's CRITICAL list.

AND ONE PIECE OF MY OWN MISDIRECTION, REMOVED
ORPHAN_ALERT_LEVEL = "CRITICAL" claimed to be "the token the notifier routes on".
It is not: classify("CRITICAL something bland") returns WARN. The orphan alert
pages because it contains the phrase "no local record", which is in the
notifier's CRITICAL list and was put there for precisely this case. The constant
was decoration that read like a mechanism -- worse than nothing, because the next
reader would trust it. It is deleted, the phrase is documented as load-bearing,
and a test now asserts the routing directly instead of a prefix that does not
control it.

THE NEW TEST is a cross-module contract: pipeline emits -> notifier.classify ->
expected severity. Nothing tested that boundary before, which is why a phrase
carried the routing for two phases without anyone noticing.

Anchors are asserted; edits are applied bottom-up.

Usage:  python patch_phase4c.py <repo-root>
"""
from __future__ import annotations

import os
import sys

OLD_BRANCH = '''        else:
            # The operator must be able to tell this apart from "nothing
            # qualified", which is the whole reason the sidecar exists.
            self.alert(f"regime {regime.state.value.upper()}: {regime.reason} "
                       f"[sidecar: {rmeta['reason']}] — exposure ceiling "
                       f"{regime.max_portfolio_exposure_pct:.0%}, NO new entries. "
                       f"Exits and existing positions are unaffected.")
'''

NEW_BRANCH = '''        elif regime.state is ExposureState.RISK_OFF:
            # The market answered the question. Normal operation on a no-trade
            # day: logged, NOT pushed. The operator must still be able to tell
            # this apart from "nothing qualified", which is why the sidecar
            # reason is carried.
            self.alert(f"regime RISK_OFF: {regime.reason} "
                       f"[sidecar: {rmeta['reason']}] — exposure ceiling "
                       f"{regime.max_portfolio_exposure_pct:.0%}, NO new entries. "
                       f"Exits and existing positions are unaffected.")
        else:
            # UNAVAILABLE is not a market verdict, it is a fault: a missing or
            # stale sidecar, screeners disagreeing, a threshold or regime_ma
            # mismatch, or an --emit-threshold run. All of them stop trading
            # entirely, and none of them fixes itself.
            #
            # "ARM BLOCKED" is load-bearing: notifier.classify() routes on
            # message text, and that phrase is what makes this a phone push
            # instead of a line in a log nobody reads. Do not reword it without
            # checking CRITICAL_SUBSTRINGS.
            self.alert(f"ARM BLOCKED: regime UNAVAILABLE — {regime.reason} "
                       f"[sidecar: {rmeta['reason']}] — exposure ceiling "
                       f"{regime.max_portfolio_exposure_pct:.0%}, NO new entries "
                       f"until this is fixed. Exits and existing positions are "
                       f"unaffected.")
'''

E10 = '''def test_e10_alert_severity_contract():
    """§the alerts that BLOCK TRADING must reach the phone.

    notifier.classify() decides severity from MESSAGE TEXT, and only CRITICAL
    pushes. Nothing tested that boundary before, so a phrase carried the routing
    for two phases without anyone noticing. This pins pipeline's wording to the
    notifier's rule; reword either side and it fails here rather than in
    production, silently, on the day it matters."""
    print("E10 alert severity: what actually reaches the phone")
    try:
        from kistrader.notifier import classify
    except ImportError as e:
        check("kistrader.notifier importable", False, str(e)); return

    now = {"t": OPEN_UTC}
    CAND = dict(pivot=100.0, base_low=92.0, last_close=100.0)

    def worst(seen):
        return "CRITICAL" if any(classify(m) == "CRITICAL" for m in seen) else "quiet"

    def arm(regime, extra=None):
        b, db, path, mon, entry, dec, loop, fclk = _assemble(now)
        csv = _write_csv([_cand("MU", **CAND)], path="e2e_sev.csv", regime=regime)
        if extra:
            extra(csv, loop, b)
        seen = _capture(loop)
        loop.arm_today(csv)
        return seen

    # a normal no-trade day must NOT buzz -- a quiet phone is the design goal
    check("risk_off day stays quiet (log only)", worst(arm("risk_off")) == "quiet")

    # every fault that stops trading MUST buzz
    check("missing sidecar pushes", worst(arm(None)) == "CRITICAL")

    def _stale(csv, _loop, _b):
        write_regime(regime_path_for(csv), session_date="2000-01-03",
                     screener="sp500_v21", vcp_threshold=75.0, benchmark="^GSPC",
                     regime_ma=20, benchmark_close=110.0, benchmark_ma=100.0,
                     bar_date="2000-01-02", log=lambda m: None)
    check("stale sidecar pushes", worst(arm(None, _stale)) == "CRITICAL")

    def _degraded(csv, _loop, _b):
        write_regime(regime_path_for(csv), session_date=SESSION, screener="sp500_v21",
                     vcp_threshold=70.0, degraded_threshold=70.0, benchmark="^GSPC",
                     regime_ma=20, benchmark_close=110.0, benchmark_ma=100.0,
                     bar_date=SESSION, log=lambda m: None)
    check("--emit-threshold degraded run pushes", worst(arm(None, _degraded)) == "CRITICAL")

    def _unreadable(_csv, _loop, b):
        b._holdings_readable = False
    check("unreadable holdings pushes", worst(arm("risk_on", _unreadable)) == "CRITICAL")

    # the orphan alert routes on the phrase "no local record", NOT on any level
    # prefix -- classify() ignores the word CRITICAL entirely.
    b, db, path, mon, entry, dec, loop, fclk = _assemble(now)
    b._holdings = {"ZZZ": 500}
    b._price["ZZZ"] = 198.40
    seen = _capture(loop)
    loop._account_state()
    orphan = [m for m in seen if "ORPHAN ZZZ" in m]
    check("orphan alert is classified CRITICAL",
          bool(orphan) and classify(orphan[0]) == "CRITICAL",
          f"{[classify(m) for m in orphan]}")
    check("...because of the phrase 'no local record', which is load-bearing",
          bool(orphan) and "no local record" in orphan[0].lower(), f"{orphan}")
    check("a bare 'CRITICAL' prefix would NOT route (it is not a token)",
          classify("CRITICAL something bland") == "WARN",
          classify("CRITICAL something bland"))


'''


def edit(text, old, new, label):
    n = text.count(old)
    if n != 1:
        raise SystemExit(f"REFUSING: anchor for {label} matched {n} times, expected 1")
    print(f"  ok  {label}")
    return text.replace(old, new)


def read(p):
    with open(p, encoding="utf-8") as f:
        return f.read()


def write(p, s):
    with open(p, "w", encoding="utf-8", newline="") as f:
        f.write(s)


def main(root):
    pl = os.path.join(root, "kistrader", "entry", "pipeline.py")
    te = os.path.join(root, "tests", "test_pipeline_e2e.py")
    nf = os.path.join(root, "kistrader", "notifier.py")
    for p in (pl, te, nf):
        if not os.path.isfile(p):
            raise SystemExit(f"REFUSING: not found: {p}")
    s, t = read(pl), read(te)
    if "_report_orphans" not in s:
        raise SystemExit("REFUSING: Phase 4b has not been applied.")
    if "regime UNAVAILABLE" in s:
        raise SystemExit("REFUSING: Phase 4c appears to be applied already.")
    if "no local record" not in read(nf):
        raise SystemExit("REFUSING: notifier.CRITICAL_SUBSTRINGS no longer contains "
                         "'no local record' — the orphan alert would not push. "
                         "Fix the notifier or the message before applying this.")

    print(f"pipeline.py  ({pl})")
    s = edit(s,
             '                f"{ORPHAN_ALERT_LEVEL} ORPHAN {t} — {qty} sh held at the broker "\n'
             '                f"with NO local record (last ${last:,.2f}, ~${notional:,.0f}). "\n',
             '                # "no local record" is LOAD-BEARING: notifier.classify()\n'
             '                # routes on message text and that phrase is in its\n'
             '                # CRITICAL list. Reword it and this stops being a phone\n'
             '                # push and becomes a line in a log nobody reads.\n'
             '                f"ORPHAN {t} — {qty} sh held at the broker "\n'
             '                f"with NO local record (last ${last:,.2f}, ~${notional:,.0f}). "\n',
             "orphan alert: drop the decorative prefix, document the real token")
    s = edit(s, OLD_BRANCH, NEW_BRANCH, "split RISK_OFF (quiet) from UNAVAILABLE (push)")
    s = edit(s,
             "# The token the notifier routes on. CRITICAL -> phone push; WARN/INFO ->\n"
             "# rotating log only. If this does not match notifier.py's rule the alert\n"
             "# reaches the log and nothing else.\n"
             'ORPHAN_ALERT_LEVEL = "CRITICAL"\n',
             "# NOTE: severity is NOT set by a prefix. notifier.classify() infers it from\n"
             "# message text -- classify(\"CRITICAL ...\") returns WARN. The orphan alert\n"
             "# pushes because it contains \"no local record\", which is in the notifier's\n"
             "# CRITICAL list. test_e10_alert_severity_contract pins that.\n",
             "remove ORPHAN_ALERT_LEVEL (it never controlled routing)")
    write(pl, s)

    print(f"test_pipeline_e2e.py  ({te})")
    t = edit(t, "    test_e9_orphan_alert_is_rate_limited()\n",
             "    test_e9_orphan_alert_is_rate_limited()\n"
             "    test_e10_alert_severity_contract()\n",
             "register test_e10 in main()")
    t = edit(t, "def test_zz_all_checks_passed():", E10 + "def test_zz_all_checks_passed():",
             "insert test_e10_alert_severity_contract")
    t = edit(t,
             "from kistrader.entry.pipeline import (ORPHAN_ALERT_COOLDOWN_SECS,\n"
             "                                      ORPHAN_ALERT_LEVEL)\n",
             "from kistrader.entry.pipeline import ORPHAN_ALERT_COOLDOWN_SECS\n",
             "e2e: drop the removed constant")
    t = edit(t,
             '        check("routes as a phone push, not a log line", m.startswith(ORPHAN_ALERT_LEVEL), m)\n',
             '        # severity is asserted properly in test_e10 against notifier.classify()\n',
             "E9: stop asserting the prefix that never controlled routing")
    write(te, t)
    print("\nPHASE 4c APPLIED. Faults that stop trading now reach the phone.")
    return 0


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("usage: python patch_phase4c.py <repo-root>")
    sys.exit(main(sys.argv[1]))
