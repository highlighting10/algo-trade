# BE CAREFUL HERE

Companion to `scripts/RUN_ORDER.md`. Ordered by how badly it hurts, not by when
you hit it.

---

## TIER 1 — silently produces a WRONG NUMBER

These do not crash. They give you a plausible answer that is wrong.

### 1.1 The gate is not optional

`scripts/03_gate.py` must reproduce NTAP 73.55 / UNH 67.58 / BRKR 72.0 / PTGX 62.54.
If it does not, you are measuring a different engine and every downstream number is
void. **Do not "just check it later".** Four causes, in order of likelihood:

1. Bars use a different adjustment convention than `yf.Ticker().history(auto_adjust=True)`
2. The scanned universe differs from production → RS percentiles differ → RS is 8
   points of the VCP score
3. Report schema moved (geometry is nested under `rep["Extracted_Pattern"]`)
4. yfinance restated history since the box ran

### 1.2 RS is a population statistic, not a ticker attribute

`compute_rs_ratings` converts raw scores to a **percentile across everything scanned
at that date.** Scan a different universe and every RS rating changes, which changes
which names clear the RS ≥ 70 gate, which changes the VCP scores. This is why
`03_gate.py` scans the *full* universe rather than just the ten gate tickers.

Never cache RS per ticker. Never scan a subset for speed.

### 1.3 Read `diag` before `stats` — every single time

If `decision_engine` dominates `drops_by_reason`, **the caps decided your result, not
the parameter you were sweeping.** This happened during the build: `sector_cap=2` with
every name in one sector pinned the portfolio to two tickers and made three different
thresholds score identically. The sweep would have reported `ROBUST`.

`06_sweep.py` now catches this as `SETTINGS DID NOT DIFFERENTIATE`. That is a **false
pass, not a result.**

### 1.4 A setting that never trades scores 0.0 and can win

Zero trades → `expectancy_R = 0.0` → ranks above anything losing. `compare_settings`
now excludes settings below `min_trades` and lists them under
`excluded_insufficient_trades`. **Read that list.** If your winner is surrounded by
excluded settings, the sweep had almost nothing to compare.

### 1.5 Empty sector map disables the sector cap silently

`decision_engine` skips the cap when `sector == ""`. An empty or partial map makes the
backtest more permissive than production with no error. `BacktestConfig` refuses an
empty map; a ticker *missing* from a non-empty map is dropped and counted as
`unmapped_sector`. Do not set `allow_missing_sector_map=True` to make an error go away.

### 1.6 tz-aware vs tz-naive bars

`Ticker().history()` returns tz-**aware**; `yf.download()` returns naive. Mixing them
makes `d in df.index` miss with no error — every bar silently invisible. `02_download.py`
normalises on write and `PITBars` normalises on ingest. If you hand-build any bar file,
normalise it.

### 1.7 Survivorship makes every absolute number a ceiling

Today's constituents only. Report `worst_coverage_pct` beside every result. The
`bias_gradient` output is an extrapolation one step beyond the observed range — a
magnitude bound, never a correction to subtract.

---

## TIER 2 — will block you, loudly

- **`rank_mode` has no default.** `BacktestConfig()` raises. Deliberate — cutting
  Stage 2 destroyed `2×RS + Stage2` and created a new parameter. Set `"rs_only"`.
- **`^GSPC` missing is fatal.** The VCP RS leg needs it; without it every name
  silently forfeits 8 points, so `02_download.py` exits non-zero instead.
- **`screen_contract.py` was never uploaded to me, so it was never verified.** Vendor
  the real one. If `04_signals.py` fails at import, that is why.
- **Zero candidates from `04_signals.py` exits non-zero.** Zero *above threshold 80* is
  fine and expected — that is the observation that motivated this project. Zero
  overall is a bug.
- **pandas 3.0.3.** I built against 3.0.2. Run the four suites in RUN_ORDER §2 before
  touching data; a rolling/ewm change surfaces there rather than in your pivots.

---

## TIER 3 — decisions to make BEFORE you look at output

### 3.1 Which metric adjudicates

In testing, `expectancy_R` said ROBUST and `total_return_pct` said NOT ROBUST on
identical data — the winner flipped at 15 bps, because looser thresholds trade more
and pay more cost. **Pick the metric first.** Choosing after you see both is choosing
the answer.

### 3.2 One parameter at a time

Never two. A run with two parked parameters moving is uninterpretable.

### 3.3 `stop_catches_frac` is yours to declare

It dominates the survivorship figure and there is no published value for a
trend-template-filtered population. State whichever you use, in every report. It stops
being an assumption only when real `delisting_events` arrive.

### 3.4 Never paste an output value into production

The deliverable is a recommendation with evidence, applied deliberately in a separate
session.

---

## STILL OPEN — you owe answers to these

| # | Question | Blocks |
|---|---|---|
| 1 | **FX**: does the account convert KRW→USD per order (통합증거금), or is the balance pre-converted? | every absolute return figure |
| 2 | Which metric adjudicates (§3.1) | every sweep verdict |
| 3 | `atr_mult_min` — confirm that field name exists in your vendored `decision_engine.py`, else edit `SWEEPS` in `06_sweep.py` | the `atrfloor` sweep |
| 4 | Survivorship data source, now WRDS is out | closing rather than bounding the bias |

---

## CAVEATS THAT MUST APPEAR IN EVERY REPORTED RESULT

`05_backtest.py` prints these for you. Do not drop them when you write up.

1. Survivorship: today's constituents → optimistic ceiling, plus `worst_coverage_pct`
2. Stage 2 CUT → screens a **wider** population than production; hit rates will not match
3. The `stop_catches_frac` you assumed
4. Exit engine is a reimplementation, **unvalidated** against `engine_v2` — replay
   validation was consciously skipped because the soak has never fired a live exit
5. The robustness verdict, not just the winning number
6. FX excluded

---

## UNRELATED, STILL OUTSTANDING

`sp500_v21.py:795` — `return Nones` in `_read_finnhub_key()`. Not firing on the box,
since your `.env` resolves the key at line 784. But it sits on the designed
missing-key fallback path, so that graceful degrade is dead. One token: `return None`.
