"""
vcp_engine.py -- MECHANICAL EXTRACTION from screeners/sp500_v21.py.

DO NOT HAND-EDIT. Regenerate with extract_engine.py if the screener changes.

Contains, verbatim:
  * the VCP recognition engine (sp500_v21.py lines 1345-2407, 49,920 chars):
    safe_divide, VCPConfig, ScoreCalculator, Wave, VCPAnalyzerV4
  * Stage-1 scoring: _lookback_price, compute_rs_ratings, check_minervini_technicals

Verified 2026-08-05: the engine block is BYTE-IDENTICAL in sp500_v21.py and
us_small_v21.py, and the Stage-1 functions are AST-IDENTICAL (only docstrings and
line wrapping differ). One extraction therefore serves both universes.

The ONLY change from the originals: check_minervini_technicals took a module-level
_fetch_history (yfinance + cache). Here it takes a  callable so the backtest
can inject a point-in-time slice of stored bars. Nothing else is touched -- the
scoring arithmetic must stay bit-identical or the backtest measures a different
system (see RUNBOOK 3d).
"""
from __future__ import annotations

from dataclasses import dataclass, field, replace

import numpy as np
import pandas as pd

# --------------------------------------------------------------------------- #
# Injected data access. The screener read yfinance through a cached
# _fetch_history(ticker, period); the backtest injects a point-in-time slice
# instead. Fails CLOSED -- an unset fetcher raises rather than silently
# returning None, which check_minervini_technicals would report as
# "fetch_failed" and quietly drop the name.
# --------------------------------------------------------------------------- #
_FETCH = None


def set_fetcher(fn):
    """fn(ticker: str, period: str) -> DataFrame|None with OHLCV columns."""
    global _FETCH
    _FETCH = fn


def _fetch_history(ticker, period):
    if _FETCH is None:
        raise RuntimeError(
            "vcp_engine: no fetcher installed. Call set_fetcher(fn) first. "
            "Refusing to return None, which would be indistinguishable from a "
            "genuine data gap and would silently drop the ticker.")
    return _FETCH(ticker, period)

# NUMERICAL SAFETY (Risk 5) — one guarded division used engine-wide
# ──────────────────────────────────────────────────────────────────────────
def safe_divide(a, b, default=0.0):
    """
    a / b with denominator (and numerator) safety. Returns `default` when the
    denominator is None / NaN / effectively zero (|b| < 1e-9), or when the
    numerator is None / NaN. Centralises the defensive division that was
    previously duplicated across stages.
    """
    if b is None or pd.isna(b) or abs(b) < 1e-9:
        return default
    if a is None or pd.isna(a):
        return default
    return a / b


# --- PATCH AE (v4 avg_vol_50) --- non-finite -> 0.0 (== UNKNOWN in the v4
# schema). NaN is not JSON-representable and must never reach the contract; 0.0
# fails closed at the consumer, which is the safe direction for a denominator.
def _finite_vol(x) -> float:
    try:
        v = float(x)
    except (TypeError, ValueError):
        return 0.0
    return v if (v == v and v not in (float("inf"), float("-inf")) and v > 0) else 0.0
# --- end PATCH AE (v4 avg_vol_50) ---


# ──────────────────────────────────────────────────────────────────────────
# CONFIGURATION (Improvement B) — every tunable threshold in one place
# ──────────────────────────────────────────────────────────────────────────
@dataclass
class VCPConfig:
    """
    Central configuration for the engine. Defaults reproduce V4 behaviour
    EXACTLY, so later optimisation only varies fields here — no code edits.
    Grouped by stage. Rolling-window periods for the moving averages / ATR in
    calculate_base_metrics are deliberately left as canonical Minervini
    constants (50/150/200/20) and are not exposed here.
    """
    # ── ZigZag / base detection ──────────────────────────────────────────
    atr_multiplier:        float = 1.5
    # --- E11 --- adaptive ZigZag threshold. None reproduces the shipped
    # fixed-ATR behaviour EXACTLY (same branch, same arithmetic). A float in
    # (0, 1) makes each confirmation threshold a fraction of the PREVIOUS
    # confirmed wave's depth, so the detector contracts with the pattern.
    # RESULT_20260829_zigzag_calibration sec.2: "The threshold SHAPE is wrong,
    # not its value." Annotated float rather than Optional[float] because the
    # engine block is exec'd standalone and does not import typing itself.
    contraction_ratio:     float = None
    min_pct:               float = 0.015
    max_base_lookback:     int   = 252
    advance_min_pct:       float = 0.15
    default_lookback_days: int   = 130
    min_base_bars:         int   = 10
    max_score:             float = 104.0   # = sum of all stage point budgets, so the
                                            # normalized score spans a true 0-100 (100 is
                                            # now achievable; was 110 -> capped at ~94.5)
    # --- TOL --- 'general' (1.10) counted a wave 10% LARGER than its
    # predecessor as a contraction: 20 -> 22 -> 24 scored quality 1.000, the
    # same as a real 20 -> 12 -> 7. A VCP detector cannot award full marks to
    # volatility EXPANSION. 'strict' requires depths[i] <= depths[i-1].
    # The other modes are kept so existing references still resolve.
    contraction_mode:      str   = 'strict'
    contraction_modes:     dict  = field(
        default_factory=lambda: {'strict': 1, 'elite': 1.05,
                                 'general': 1.10, 'loose': 1.20})
    # --- end TOL ---

    # ── Input validation ─────────────────────────────────────────────────
    min_rows:              int   = 30

    # ── Stage 1: trend + RS ──────────────────────────────────────────────
    prior_uptrend_full:    float = 0.30
    prior_uptrend_points:  float = 8.0
    prior_lookback:        int   = 130
    trend_template_points: float = 8.0
    rs_full:               float = 0.15
    rs_points:             float = 8.0
    rs_min_common:         int   = 252
    rs_segments:           tuple = field(default_factory=lambda: (
        ((-1, -64), 0.40), ((-64, -127), 0.20),
        ((-127, -190), 0.20), ((-190, -253), 0.20)))

    # ── Stage 2: base quality ────────────────────────────────────────────
    base_depth_zero:       float = 0.35   # depth giving 0 credit
    base_depth_full:       float = 0.25   # depth giving full credit
    base_depth_points:     float = 6.0
    base_dur_min_weeks:    float = 6.0
    base_dur_max_weeks:    float = 20.0
    base_dur_points:       float = 4.0
    base_dur_center:       float = 13.0
    base_dur_falloff:      float = 0.2

    # ── Stage 3 & 4: contraction counts ──────────────────────────────────
    # --- PATCH AH (wave count: scoring vs rejection) --- 6 is now PRESENT and
    # scored zero, rather than ABSENT and defaulted to zero. Same number, and
    # the difference is the whole patch: a sweep can move this value without
    # also moving the rejection ceiling, which is impossible while one .get()
    # does both jobs. Ordered by wave count so the curve is readable.
    # Minervini's VCP is 2-6 contractions; 7+ is noise, and that is now said
    # by wave_count_max rather than implied by a missing dict key.
    wave_count_points:     dict  = field(
        default_factory=lambda: {2: 8, 3: 13, 4: 15, 5: 10, 6: 0})
    wave_count_max:        int   = 6
    # --- end PATCH AH (wave count: scoring vs rejection) ---

    # --- 3b (final-contraction tightness) --- the stop is set from the FINAL
    # contraction (decision_engine.derive_stop anchors on contraction_low =
    # Wave_Lows[-1]), and 45% of scored names fail max_stop_pct because nothing
    # here measured its ABSOLUTE size. quality_ratio is relative only, so
    # 40 -> 30 -> 22 scores a perfect 1.000 with a 22% final contraction.
    # UNITS: PERCENT, because Wave.depth_pct multiplies by 100. decision_engine
    # uses a FRACTION for the same quantity -- do not copy a value across.
    # final_tight_zero is DERIVED, not chosen: it is the depth at which the
    # structural stop lands exactly on max_stop_pct, given
    #   risk = ((1+chase) - (1-d)(1-buffer)) / (1+chase)
    # with chase 0.005, buffer 0.005, max_stop_pct 0.10  ->  d = 9.10%.
    # Re-solve it if any of those three move.
    final_tight_full:      float = 5.00
    final_tight_zero:      float = 9.10
    # --- end 3b ---

    # ── Stage 5: higher lows ─────────────────────────────────────────────
    higher_low_full:       float = 0.75
    higher_low_points:     float = 5.0

    # ── Stage 6: volume dry-up ───────────────────────────────────────────
    vol_overall_zero:      float = 1.0    # vol_ratio giving 0 credit
    vol_overall_full:      float = 0.70   # vol_ratio giving full credit
    vol_elite:             float = 0.50
    vol_strong:            float = 0.70
    vol_w_overall:         float = 0.60
    vol_w_sequence:        float = 0.40
    vol_points:            float = 10.0
    seq_good:              float = 2.0 / 3.0
    seq_weak:              float = 1.0 / 3.0

    # ── Stage 7: ATR compression ─────────────────────────────────────────
    atr_comp_zero:         float = 1.0
    atr_comp_full:         float = 0.75
    atr_comp_points:       float = 10.0
    atr_comp_window:       int   = 10

    # ── Stage 8: tight area ──────────────────────────────────────────────
    tight_zero:            float = 0.08
    tight_full:            float = 0.04
    tight_points:          float = 10.0
    tight_window:          int   = 10

    # ── Stage 9: resistance ──────────────────────────────────────────────
    resistance_points:     float = 5.0

    # ── Stage 10: accumulation ───────────────────────────────────────────
    accum_zero:            float = 1.0    # ratio giving 0 credit
    accum_full:            float = 1.2    # ratio giving full credit
    accum_points:          float = 10.0

    # ── Stage 11 & 12: readiness + breakout ──────────────────────────────
    ready_excellent:       float = 0.01
    ready_good:            float = 0.03
    ready_acceptable:      float = 0.05
    ready_poor_span:       float = 0.05
    ready_pts_excellent:   float = 5.0
    ready_pts_good:        float = 4.0
    ready_pts_acceptable:  float = 2.5
    breakout_vol_mult:     float = 1.5

    # ── Base-confidence diagnostic ───────────────────────────────────────
    conf_lookback_days:    int   = 130
    conf_min_drop_pct:     float = 0.10
    conf_compare_floor:    float = 0.90
    conf_competing_ratio:  float = 0.95
    conf_nearby_ratio:     float = 0.90
    conf_late_reach:       float = 0.98
    conf_late_frac:        float = 0.25

    # ── Grade cutoffs ────────────────────────────────────────────────────
    grade_elite:           float = 90.0
    grade_strong:          float = 80.0
    grade_tradable:        float = 70.0
    grade_watchlist:       float = 60.0


# ──────────────────────────────────────────────────────────────────────────
# SCORING (Improvement C) — one ramp replaces the repeated clamp pattern
# ──────────────────────────────────────────────────────────────────────────
class ScoreCalculator:
    """
    Removes the duplicated `max(0, min(cap, (target - x)/span * cap))` scoring
    pattern. `linear` interpolates a value to [0, points], saturating outside
    the [zero_at, full_at] band and working in either direction (full_at may be
    above or below zero_at).
    """
    @staticmethod
    def clamp(x, lo, hi):
        return max(lo, min(hi, x))

    @staticmethod
    def linear(value, zero_at, full_at, points):
        span = full_at - zero_at
        if abs(span) < 1e-12:                       # degenerate band
            return points if value == full_at else 0.0
        frac = (value - zero_at) / span
        return ScoreCalculator.clamp(frac, 0.0, 1.0) * points


# ==========================================
# VCP FRAMEWORK V4.1  (config-driven refactor)
# ==========================================
# Architecture:  Candles → Swings → WAVES → VCP Analysis
#
# The WAVE is the fundamental object. Every metric (base, pivot, contractions,
# higher-lows, resistance, volume) operates on waves — never on raw candles
# or raw swings.
#
# Locked definitions (per V3.1/V3.2 spec):
#   • Wave        = Swing High → Swing Low (Wave dataclass)
#   • ZigZag      = ATR-hybrid, threshold = max(ATR20×mult, Close×min_pct)
#   • Pivot       = waves[-1].high_price (most recent COMPLETED contraction)
#   • Breakout    = close > pivot AND volume confirms
#   • Contraction = configurable tolerance (elite 1.05 / general 1.10 / loose 1.20)
#
# Changes V3.1 → V3.2:
#   A  BASE DETECTION rewritten (was FROZEN). Now ZigZag-structural:
#        base start = most recent significant swing high that initiates the
#        current contraction sequence (a decisive advance establishes it),
#        replacing arbitrary highest-high-in-lookback anchoring.
#   B  READINESS redefined to actual breakout proximity:
#        distance_to_pivot = max(0, (pivot - current_close) / pivot)
#        scale  ≤1% Excellent · ≤3% Good · ≤5% Acceptable · >5% Poor
#   C  ACCUMULATION metric now AVG up-vol / AVG down-vol (was sum/sum), so it
#        measures participation intensity, not advancing-day count.
#   D  VOLUME DRY-UP now dual-axis: overall endpoint reduction (kept) PLUS a
#        progressive sequence-consistency score; both feed the stage score
#        (overall 60% / sequence 40%).
#
# Changes V3.2 → V4 (production hardening — no algorithm changes):
#   1  Accumulation: explicit neutral (1.0) when an up/down group is empty or
#      its mean is NaN/≤0, so an all-up-days base can never inject NaN.
#   2  Volume sequence: requires ≥2 wave volumes before the (len-1) division
#      (already guarded; made explicit and centralised).
#   3  ATR: ffill→bfill, then a Close×0.02 fallback on ANY residual NaN, then a
#      final fillna(0); datasets with unrecoverable price data are REJECTED.
#   4  Tight-area: guards mean(Close) ≤ 0 / NaN before dividing.
#   5  safe_divide() helper centralises every guarded division.
#   6  Score aggregation sanitises each stage score (NaN/±Inf → 0) and clamps
#      the final score to a finite [0,100].
#   7  Wave validation: malformed waves (high ≤ low, non-positive/NaN prices,
#      bad bar order) are dropped in _build_waves before they reach scoring.
#   8  Early-exit: _validate_input_data() rejects malformed frames up front;
#      stages continue to fail closed on thin/empty input.
#   Class renamed VCPAnalyzerV3 → VCPAnalyzerV4 (V3 name kept as an alias).
#
# Changes V4 → V4.1 (refactor only — behaviour is bit-identical to V4):
#   A  safe_divide() (added in V4) now covers the last inline guards.
#   B  VCPConfig dataclass centralises EVERY scoring threshold, lookback,
#      weight and grade cutoff. Stages read self.cfg.* instead of literals, so
#      later optimisation only varies config fields. The V4 constructor kwargs
#      (atr_multiplier, min_pct, contraction_mode, …) still work and override
#      the config; an optional `config=VCPConfig(...)` can be passed instead.
#   C  ScoreCalculator.linear() replaces the repeated
#      max(0, min(cap, (target - x)/span * cap)) pattern across the stages.
#
# Carried unchanged from V3.1: Wave object, ZigZag engine, pivot lock,
# wave-count scoring (4=15,3=13,5=10,2=8,else=0), wave-based volume, real RS.
# ==========================================


# ──────────────────────────────────────────────────────────────────────────
# THE FUNDAMENTAL OBJECT: a contraction wave  (Swing High → Swing Low)
# ──────────────────────────────────────────────────────────────────────────
@dataclass
class Wave:
    """
    A completed contraction wave: a confirmed swing high followed by a
    confirmed swing low.

      high_price / high_bar : the swing high that begins the contraction
      low_price  / low_bar  : the swing low  that ends   the contraction

    Bar indices are 0-based iloc positions WITHIN base_df.

    A Wave object is only ever created once its LOW is ZigZag-confirmed, so
    every Wave is a completed contraction by construction — there is no
    'currently forming' wave in the list, which prevents pivot repainting.
    """
    high_price: float
    high_bar:   int
    low_price:  float
    low_bar:    int

    @property
    def depth_pct(self) -> float:
        """Contraction depth as a positive percentage of the wave high."""
        if self.high_price <= 0:
            return 0.0
        return safe_divide(self.high_price - self.low_price,
                           self.high_price, default=0.0) * 100.0

    def is_valid(self) -> bool:
        """
        Reject malformed waves before they reach scoring (Risk 7).

        A wave is valid iff:
          • high_price and low_price are finite and strictly positive,
          • the contraction is positive (high_price > low_price), and
          • bar indices are finite, non-negative, and ordered (low at/after high).
        """
        for v in (self.high_price, self.low_price):
            if v is None or not np.isfinite(v) or v <= 0:
                return False
        if self.high_price <= self.low_price:        # contraction must be > 0
            return False
        for b in (self.high_bar, self.low_bar):
            if b is None or not np.isfinite(b) or b < 0:
                return False
        if self.low_bar < self.high_bar:             # low cannot precede the high
            return False
        return True


class VCPAnalyzerV4:
    # Contraction tolerance modes (Fix 5)
    CONTRACTION_MODES = {'elite': 1.05, 'general': 1.10, 'loose': 1.20}

    def __init__(self, df, index_df=None,
                 atr_multiplier=None, min_pct=None,
                 contraction_mode=None,
                 max_base_lookback=None, advance_min_pct=None,
                 contraction_ratio=None,
                 config=None):
        self.df = df.copy()
        self.index_df = index_df

        # ── Configuration (Improvement B) ────────────────────────────────────
        # All tunables live on VCPConfig. The V4 scalar kwargs still work and,
        # when supplied, override the config — preserving the old call sites.
        cfg = config if config is not None else VCPConfig()
        overrides = {}
        if atr_multiplier   is not None: overrides['atr_multiplier']    = atr_multiplier
        if contraction_ratio is not None: overrides['contraction_ratio'] = contraction_ratio
        if min_pct          is not None: overrides['min_pct']           = min_pct
        if max_base_lookback is not None: overrides['max_base_lookback'] = max_base_lookback
        if advance_min_pct  is not None: overrides['advance_min_pct']   = advance_min_pct
        if contraction_mode is not None: overrides['contraction_mode']  = contraction_mode
        if overrides:
            cfg = replace(cfg, **overrides)
        if cfg.contraction_mode not in cfg.contraction_modes:
            cfg = replace(cfg, contraction_mode='general')
        self.cfg = cfg

        # Instance mirrors kept so the ZigZag / base-detection code is untouched.
        self.atr_multiplier    = cfg.atr_multiplier
        self.contraction_ratio = cfg.contraction_ratio
        self.min_pct           = cfg.min_pct
        self.contraction_mode  = cfg.contraction_mode
        self.contraction_tol   = cfg.contraction_modes[cfg.contraction_mode]
        self.max_base_lookback = cfg.max_base_lookback
        self.advance_min_pct   = cfg.advance_min_pct
        self.max_score         = cfg.max_score

        self._data_ok, self._data_reasons = self._precheck_columns()
        if self._data_ok:
            self.calculate_base_metrics()
        self._invalid_wave_count = 0  # set by _build_waves (Risk 7 diagnostic)

    # ─────────────────────────────────────────────────────────────────────
    # INPUT VALIDATION (Risk 3 + Risk 8) — fail closed before any scoring
    # ─────────────────────────────────────────────────────────────────────
    def _precheck_columns(self):
        """Cheap structural check run in __init__ before metric computation."""
        required = ['Open', 'High', 'Low', 'Close', 'Volume']
        if self.df is None or len(self.df) == 0:
            return False, ['empty_dataframe']
        missing = [f'missing_column:{c}' for c in required
                   if c not in self.df.columns]
        return (len(missing) == 0), missing

    def _validate_input_data(self, min_rows=None):
        """
        Deep data-quality gate, run at the top of generate_report.

        Rejects a symbol when:
          • required columns were missing (carried from the precheck),
          • there is too little usable history, or
          • ATR is unrecoverable even after ffill/bfill and the Close-based
            fallback (Risk 3) — i.e. price data is too broken for ZigZag.
        """
        if min_rows is None:
            min_rows = self.cfg.min_rows
        if not self._data_ok:
            return False, self._data_reasons
        reasons = []
        if len(self.df) < min_rows:
            reasons.append('insufficient_rows')
        if self.df['Close'].notna().sum() < min_rows:
            reasons.append('close_mostly_nan')
        atr = self.df['ATR20'].ffill().bfill()
        if atr.isna().all() and (self.df['Close'].ffill().bfill() * 0.02).isna().all():
            reasons.append('atr_unrecoverable')
        return (len(reasons) == 0), reasons

    def calculate_base_metrics(self):
        """Moving averages, ATR, and volume metrics."""
        self.df['MA50']  = self.df['Close'].rolling(window=50).mean()
        self.df['MA150'] = self.df['Close'].rolling(window=150).mean()
        self.df['MA200'] = self.df['Close'].rolling(window=200).mean()

        self.df['Previous_Close'] = self.df['Close'].shift(1)
        self.df['TR'] = (self.df[['High', 'Previous_Close']].max(axis=1) -
                         self.df[['Low',  'Previous_Close']].min(axis=1))
        self.df['ATR20'] = self.df['TR'].rolling(window=20).mean()

        self.df['Avg_Vol_10'] = self.df['Volume'].rolling(window=10).mean()
        self.df['Avg_Vol_50'] = self.df['Volume'].rolling(window=50).mean()

    # ─────────────────────────────────────────────────────────────────────
    # CHANGE A — BASE DETECTION (V3.2, ZigZag-structural; was FROZEN)
    # ─────────────────────────────────────────────────────────────────────
    def _find_base_start(self, lookback_days=130):
        """
        Locked V3.2 definition:

            Base Start = the most recent SIGNIFICANT ZigZag swing high that
                         initiates the current contraction sequence.

        This replaces highest-high-in-lookback anchoring, which mis-fired in
        Run→BaseA→Run→BaseB structures. The new method is wave-native: it
        reads the same ATR-hybrid ZigZag used everywhere else, so the base is
        chosen from real swing structure rather than an arbitrary window max.

        Method
        ──────
        1. Run the ZigZag over a wide structural window (max_base_lookback).
        2. Collect swing highs (confirmed H pivots + the leading peak before
           the first confirmed low, so a base topped at the window edge is
           still seen).
        3. Walk the highs forward tracking the running peak. A *decisive
           advance* — an up-move that lifts to a new high at least
           advance_min_pct above the prior running peak — RESETS the base to
           that new high. The last such reset is the start of the current
           contraction sequence.
        4. If no decisive advance is found, the structure is a single base:
           anchor on the dominant (max) swing high.
        5. base_high is then the highest high from base_start to the current
           bar — the ceiling the contraction sits beneath.

        Assumption (documented; validation deferred to chart testing per spec)
        ──────────────────────────────────────────────────────────────────
        A later base that forms ENTIRELY below a prior high without a decisive
        new-high advance is treated as still sitting under that prior high
        (the prior high remains the controlling ceiling). Tune advance_min_pct
        to make base re-anchoring more or less eager.

        Returns (base_start_num, base_high) as (int iloc, float).
        """
        n = len(self.df)
        if n < 20:
            return n - 1, float(self.df['High'].iloc[-1])

        lb = min(self.max_base_lookback, n)
        start_pos = n - lb
        window = self.df.iloc[start_pos:]

        rel_piv = self._zigzag_pivots(window)
        piv = [(start_pos + b, float(p), t) for (b, p, t) in rel_piv]

        # Fallback: absolute high within the requested (narrower) lookback
        fb_lb    = min(lookback_days if lookback_days else lb, n)
        fb_start = n - fb_lb
        fb_win   = self.df.iloc[fb_start:]
        fb_bar   = fb_start + int(fb_win['High'].values.argmax())
        fb_price = float(self.df['High'].iloc[fb_bar])

        if not piv:
            return fb_bar, fb_price

        # ── Collect swing highs (leading peak + confirmed H pivots) ──────────
        highs = []
        first_low_bar = next((b for (b, p, t) in piv if t == 'L'), None)
        if first_low_bar is not None and first_low_bar > start_pos:
            lead_slice = self.df.iloc[start_pos:first_low_bar + 1]
            lead_bar   = start_pos + int(lead_slice['High'].values.argmax())
            highs.append((lead_bar, float(self.df['High'].iloc[lead_bar])))
        highs += [(b, p) for (b, p, t) in piv if t == 'H']
        highs.sort(key=lambda x: x[0])

        if not highs:
            return fb_bar, fb_price

        # ── Most recent decisive advance resets the base ─────────────────────
        base_bar, base_price = None, None
        running_peak = highs[0][1]
        for (b, p) in highs:
            if p > running_peak * (1.0 + self.advance_min_pct):
                base_bar, base_price = b, p
            running_peak = max(running_peak, p)

        if base_bar is None:
            # Single base: dominant swing high
            base_bar, base_price = max(highs, key=lambda x: x[1])

        # ── Base ceiling = highest high since the base started ───────────────
        ceiling   = float(self.df['High'].iloc[base_bar:].max())
        base_price = max(base_price, ceiling)

        return base_bar, base_price

    # ─────────────────────────────────────────────────────────────────────
    # BASE-CONFIDENCE DIAGNOSTIC (validation aid, non-invasive)
    # ─────────────────────────────────────────────────────────────────────
    def _assess_base_confidence(self, base_start_num, base_high,
                                lookback_days=None, min_drop_pct=None):
        """
        Cross-checks the chosen anchor and surfaces a confidence label so the
        screener can gate on it. Retained from V3.1 as a validation surface
        for the new ZigZag-structural base detection (spec lists base
        detection validation as a pending chart-testing item).

        Two independent risk signals:

          A) COMPETING EARLIER BASE
             A comparable prior peak (≥ conf_competing_ratio of base_high)
             exists BEFORE the chosen anchor, separated by a real drawdown. →
             the anchor may be BaseA when BaseB was intended.

          B) LATE INTERNAL HIGH
             Inside the chosen base, price later revisited/exceeded base_high
             well past the start (> conf_late_frac into the base). → the true
             base may begin at that later high, not the chosen anchor.

        Returns (confidence_label, reasons_list)
            confidence_label ∈ {'high', 'medium', 'low'}
        """
        cfg = self.cfg
        if lookback_days is None:
            lookback_days = cfg.conf_lookback_days
        if min_drop_pct is None:
            min_drop_pct = cfg.conf_min_drop_pct

        reasons = []
        if len(self.df) < 20:
            return 'low', ['insufficient_history']
        if base_high is None or not np.isfinite(base_high) or base_high <= 0:
            return 'low', ['invalid_base_high']   # Risk 5/8 — avoid /base_high blowups

        if len(self.df) < lookback_days:
            lookback_days = len(self.df)
        start_pos = len(self.df) - lookback_days

        # ── Signal A: competing earlier base before the anchor ───────────────
        # A genuine prior base = a peak comparable to base_high that was THEN
        # followed by a real drawdown inside the pre-anchor region. A plain
        # monotonic run-up (highs approaching base_high while rising) must NOT
        # trigger this — only a peak-then-decline does.
        pre = self.df.iloc[start_pos:base_start_num]
        if len(pre) >= 15:
            ph = pre['High'].values
            pc = pre['Close'].values
            best_ratio = 0.0
            for i in range(len(pre) - 5):
                if ph[i] >= base_high * cfg.conf_compare_floor:
                    future_min = pc[i + 1:].min()
                    draw = safe_divide(ph[i] - future_min, ph[i], default=0.0)
                    if draw >= min_drop_pct:
                        best_ratio = max(best_ratio,
                                         safe_divide(ph[i], base_high, default=0.0))
            if best_ratio >= cfg.conf_competing_ratio:
                reasons.append('competing_earlier_base')
            elif best_ratio >= cfg.conf_nearby_ratio:
                reasons.append('nearby_earlier_peak')

        # ── Signal B: late internal high inside the chosen base ──────────────
        base = self.df.iloc[base_start_num:]
        if len(base) >= 10:
            # bars (relative to base start) where price reached the anchor band
            reach = np.where(base['High'].values >= base_high * cfg.conf_late_reach)[0]
            if len(reach) > 0:
                last_reach_frac = reach[-1] / max(1, len(base) - 1)
                if last_reach_frac > cfg.conf_late_frac:
                    reasons.append('late_internal_high')

        # ── Combine ──────────────────────────────────────────────────────────
        if 'competing_earlier_base' in reasons or 'late_internal_high' in reasons:
            confidence = 'low'
        elif 'nearby_earlier_peak' in reasons:
            confidence = 'medium'
        else:
            confidence = 'high'

        return confidence, reasons

    # ─────────────────────────────────────────────────────────────────────
    # FIX 3 — ATR-HYBRID ZIGZAG (official swing engine)
    # ─────────────────────────────────────────────────────────────────────
    def _zigzag_pivots(self, base_df):
        """
        Detection layer. Confirms a pivot only when price reverses by

            threshold = max(ATR20 × atr_multiplier, Close × min_pct)

        from the running extreme. A pivot is therefore only ever emitted
        AFTER it is confirmed by a reversal (Fix 4 — no unconfirmed pivots).

        Returns list of (bar_idx, price, 'H'|'L'), bar_idx 0-based in base_df.
        The base high at bar 0 is implied (not emitted).
        """
        if len(base_df) < 5:
            return []

        atr_s = base_df['ATR20'].ffill().bfill()
        if atr_s.isna().any():                       # any residual NaN → Close-based fallback
            atr_s = (base_df['Close'] * 0.02).ffill().bfill()
        atr_s = atr_s.fillna(0.0)                     # last-resort: 0 (min_pct floor still applies)

        pivots       = []
        prev_depth   = 0.0        # --- E11 --- depth of the last CONFIRMED wave
        direction    = 'down'
        run_high     = base_df['High'].iloc[0]
        run_high_bar = 0
        run_low      = base_df['Low'].iloc[0]
        run_low_bar  = 0

        for i in range(1, len(base_df)):
            h = base_df['High'].iloc[i]
            l = base_df['Low'].iloc[i]
            # --- E11 --- adaptive threshold. With contraction_ratio set, the
            # bar for confirming the NEXT reversal is a fraction of the PREVIOUS
            # wave's depth, so resolution contracts as the pattern does. The
            # min_pct floor still applies and stops it collapsing onto noise.
            # The first wave has no predecessor (prev_depth == 0) and always
            # takes the shipped ATR branch, so contraction_ratio=None is
            # behaviourally identical to the engine as shipped.
            if self.contraction_ratio and prev_depth > 0:
                thresh = max(prev_depth * self.contraction_ratio,
                             base_df['Close'].iloc[i] * self.min_pct)
            else:
                thresh = max(atr_s.iloc[i] * self.atr_multiplier,
                             base_df['Close'].iloc[i] * self.min_pct)

            if direction == 'down':
                if l < run_low:
                    run_low, run_low_bar = l, i
                if (h - run_low) >= thresh:                # reversal up → low confirmed
                    pivots.append((run_low_bar, run_low, 'L'))
                    # --- E11 --- a Wave is high -> low, so its depth is known
                    # exactly here, at the moment the low is confirmed. run_high
                    # still holds the high that opened this wave; it is reset on
                    # the next line.
                    prev_depth = run_high - run_low
                    direction = 'up'
                    run_high, run_high_bar = h, i
            else:  # up
                if h > run_high:
                    run_high, run_high_bar = h, i
                if (run_high - l) >= thresh:               # reversal down → high confirmed
                    pivots.append((run_high_bar, run_high, 'H'))
                    direction = 'down'
                    run_low, run_low_bar = l, i

        return pivots

    # ─────────────────────────────────────────────────────────────────────
    # FIX 2 — WAVE CONSTRUCTION (analysis layer)
    # ─────────────────────────────────────────────────────────────────────
    def _build_waves(self, base_df, base_high):
        """
        Converts confirmed ZigZag pivots into a list of Wave objects.

        A Wave = swing high → swing low. We walk the pivot sequence holding
        the 'current high' (starting at base_high@bar0). Each time a LOW is
        confirmed we close a Wave(current_high → that low). Each confirmed
        HIGH updates current_high for the next wave.

        Because a Wave is only created on a confirmed LOW, every Wave in the
        returned list is a COMPLETED contraction (Fix 1 / Fix 4).
        """
        pivots = self._zigzag_pivots(base_df)

        waves = []
        current_high     = base_high
        current_high_bar = 0

        for bar_idx, price, p_type in pivots:
            if p_type == 'L':
                waves.append(Wave(high_price=current_high,
                                  high_bar=current_high_bar,
                                  low_price=price,
                                  low_bar=bar_idx))
            else:  # 'H'
                current_high     = price
                current_high_bar = bar_idx

        # Risk 7 — reject malformed waves before they can contaminate scoring.
        valid = [w for w in waves if w.is_valid()]
        self._invalid_wave_count = len(waves) - len(valid)
        return valid

    # ─────────────────────────────────────────────────────────────────────
    # FIX 5 (RS) — real relative strength vs index (carried from mark4)
    # ─────────────────────────────────────────────────────────────────────
    def _compute_rs_raw(self):
        """Minervini quarterly-weighted excess return vs index. 0 if no index."""
        if self.index_df is None:
            return 0.0

        common = self.df['Close'].index.intersection(self.index_df['Close'].index)
        if len(common) < self.cfg.rs_min_common:
            return 0.0

        s = self.df['Close'][common]
        b = self.index_df['Close'][common]

        def qret(series, end, start):
            sv = series.iloc[start]
            return safe_divide(series.iloc[end], sv, default=1.0) - 1.0

        rs = 0.0
        for (end, start), w in self.cfg.rs_segments:
            try:
                rs += w * (qret(s, end, start) - qret(b, end, start))
            except (IndexError, ZeroDivisionError):
                pass
        return rs

    # ─────────────────────────────────────────────────────────────────────
    # MASTER EXTRACTION — returns the wave list + base context
    # ─────────────────────────────────────────────────────────────────────
    def extract(self, lookback_days=None):
        """
        Full extraction pipeline: base detection → ZigZag → wave construction.

        Returns
        ───────
        base_start_num : int
        base_high      : float
        base_df        : DataFrame (empty if base too fresh)
        waves          : list[Wave]   (completed contractions only)
        base_conf      : str   'high' | 'medium' | 'low'  (Bug 3 diagnostic)
        base_reasons   : list[str]  risk signals behind the confidence label
        """
        if lookback_days is None:
            lookback_days = self.cfg.default_lookback_days
        base_start_num, base_high = self._find_base_start(lookback_days=lookback_days)
        base_df = self.df.iloc[base_start_num:].copy()

        base_conf, base_reasons = self._assess_base_confidence(
            base_start_num, base_high, lookback_days=lookback_days)

        if len(base_df) < self.cfg.min_base_bars:
            return base_start_num, base_high, pd.DataFrame(), [], base_conf, base_reasons

        waves = self._build_waves(base_df, base_high)
        return base_start_num, base_high, base_df, waves, base_conf, base_reasons

    # ─────────────────────────────────────────────────────────────────────
    # STAGE 1: Trend Qualification (+ real RS)
    # ─────────────────────────────────────────────────────────────────────
    def stage_1_trend(self, base_start_num):
        cfg = self.cfg
        current    = self.df.iloc[-1]
        past_price = self.df['Close'].iloc[max(0, base_start_num - cfg.prior_lookback)]
        prior_uptrend = safe_divide(
            self.df['High'].iloc[base_start_num] - past_price, past_price, default=0.0)

        trend_template = bool(
            current['Close'] > current['MA50']  and
            current['MA50']  > current['MA150'] and
            current['MA150'] > current['MA200'])

        score = ScoreCalculator.linear(prior_uptrend, 0.0,
                                        cfg.prior_uptrend_full, cfg.prior_uptrend_points)
        if trend_template:
            score += cfg.trend_template_points

        rs_raw   = self._compute_rs_raw()
        rs_score = ScoreCalculator.linear(rs_raw, 0.0, cfg.rs_full, cfg.rs_points)
        score   += rs_score

        return score, {'prior_uptrend': prior_uptrend,
                       'trend_template': trend_template,
                       'rs_excess': round(rs_raw, 4),
                       'rs_score': round(rs_score, 2)}

    # ─────────────────────────────────────────────────────────────────────
    # STAGE 2: Base Quality
    # ─────────────────────────────────────────────────────────────────────
    def stage_2_base(self, base_df, base_high):
        if base_df.empty:
            return 0, {}
        cfg = self.cfg
        base_weeks = len(base_df) / 5
        base_low   = base_df['Low'].min()
        base_depth = safe_divide(base_high - base_low, base_high, default=1.0)

        depth_score    = ScoreCalculator.linear(base_depth, cfg.base_depth_zero,
                                                 cfg.base_depth_full, cfg.base_depth_points)
        duration_score = (cfg.base_dur_points
                          if cfg.base_dur_min_weeks <= base_weeks <= cfg.base_dur_max_weeks
                          else max(0, cfg.base_dur_points
                                   - abs(base_weeks - cfg.base_dur_center) * cfg.base_dur_falloff))
        return depth_score + duration_score, {'base_depth': base_depth,
                                              'base_weeks': base_weeks}

    # ─────────────────────────────────────────────────────────────────────
    # STAGE 3 & 4: Contraction Analysis  (operates on Wave depths)
    # ─────────────────────────────────────────────────────────────────────
    def stage_3_and_4_contractions(self, waves):
        """
        Fix 7 — discrete wave-count budget, scaled by contraction quality.

            wave-count base points:  4→15  3→13  5→10  2→8  else→0
            contraction quality:     fraction of waves where
                                       depth[i] <= depth[i-1] × tol   (Fix 5)

            score = base_points × quality_ratio
        """
        n = len(waves)
        depths = [w.depth_pct for w in waves]

        if n < 2:
            return 0, {'wave_count': n, 'waves': depths, 'wave_count_points': 0}

        # --- PATCH AH (wave count: scoring vs rejection) --- REJECTION first,
        # then SCORING. Identical output for every n: above the ceiling the
        # dict had no key and defaulted to 0; now it is said outright.
        if n > self.cfg.wave_count_max:
            base_points = 0
        else:
            base_points = self.cfg.wave_count_points.get(n, 0)
        # --- end PATCH AH (wave count: scoring vs rejection) ---

        met = sum(1 for i in range(1, n)
                  if depths[i] <= depths[i - 1] * self.contraction_tol)
        quality_ratio = met / (n - 1)

        # --- 3b --- the FINAL contraction is what the stop is set from, so its
        # absolute size gates the same points its relative shape does. In [0, 1]
        # and multiplicative, so this can only REDUCE a score: no name can be
        # lifted over the threshold by this term. depths[] is in PERCENT.
        final_depth = float(depths[-1])
        tightness = ScoreCalculator.linear(
            final_depth, self.cfg.final_tight_zero, self.cfg.final_tight_full,
            1.0)
        score = base_points * quality_ratio * tightness
        return score, {'wave_count': n,
                       'waves': depths,
                       'wave_count_points': base_points,
                       'contraction_quality': round(quality_ratio, 3),
                       'final_contraction_pct': round(final_depth, 2),
                       'final_tightness': round(tightness, 3),
                       'contraction_mode': self.contraction_mode}
        # --- end 3b ---

    # ─────────────────────────────────────────────────────────────────────
    # STAGE 5: Higher-Low Structure  (operates on Wave lows)
    # ─────────────────────────────────────────────────────────────────────
    def stage_5_higher_lows(self, waves):
        lows = [w.low_price for w in waves]
        if len(lows) < 2:
            return 0, {'higher_low_ratio': 0}
        higher = sum(1 for i in range(1, len(lows)) if lows[i] > lows[i - 1])
        ratio  = higher / max(1, len(lows) - 1)
        score  = ScoreCalculator.linear(ratio, 0.0,
                                        self.cfg.higher_low_full, self.cfg.higher_low_points)
        return score, {'higher_low_ratio': round(ratio, 3)}

    # ─────────────────────────────────────────────────────────────────────
    # STAGE 6: Wave-Based Volume Dry-Up  (Fix 8)
    # ─────────────────────────────────────────────────────────────────────
    def stage_6_volume_dry_up(self, base_df, waves):
        """
        Wave-based volume dry-up, evaluated on TWO complementary axes (V3.2):

          1. OVERALL REDUCTION  — last_wave_avg_vol / first_wave_avg_vol
             "Has supply dried up from the START of the base to the END?"
             Strong < 0.70   Elite < 0.50

          2. SEQUENCE CONSISTENCY — fraction of consecutive wave pairs whose
             average volume decreases (progressive contraction).
             "Did supply disappear PROGRESSIVELY, wave by wave?"
             100% Excellent · ≥67% Good · ≥33% Weak · 0% Fail

        These measure different things. A base can pass (1) on its endpoints
        while supply briefly RETURNS mid-sequence — e.g. wave volumes
        100→80→90→45 pass overall (45/100) yet wave 3 shows supply coming back,
        which only (2) penalises. Both feed the 10-point stage budget
        (overall 60% / sequence 40%).

        Wave volume is each wave's mean over its actual bar span (high_bar →
        low_bar), consistent with the rest of the engine.
        """
        if base_df.empty or len(waves) < 2:
            return 0, {'vol_ratio': 1.0, 'vol_sequence_score': 0.0,
                       'vol_sequence_tier': 'Fail', 'volume_tier': 'Weak'}

        def wave_vol(w):
            s, e = w.high_bar, w.low_bar
            if e < s:
                s, e = e, s
            seg = base_df['Volume'].iloc[s:e + 1]
            return seg.mean() if len(seg) else None

        wave_volumes = [wave_vol(w) for w in waves]
        wave_volumes = [v for v in wave_volumes if v is not None and v > 0]
        if len(wave_volumes) < 2:
            return 0, {'vol_ratio': 1.0, 'vol_sequence_score': 0.0,
                       'vol_sequence_tier': 'Fail', 'volume_tier': 'Weak'}

        # ── 1. Overall reduction (endpoint dry-up) ───────────────────────────
        cfg = self.cfg
        # ── 1. Overall reduction (endpoint dry-up) ───────────────────────────
        v1, vN    = wave_volumes[0], wave_volumes[-1]
        vol_ratio = safe_divide(vN, v1, default=1.0)
        overall_component = ScoreCalculator.linear(
            vol_ratio, cfg.vol_overall_zero, cfg.vol_overall_full, 1.0)

        # ── 2. Sequence consistency (progressive dry-up) ─────────────────────
        decreasing_pairs = sum(wave_volumes[i] < wave_volumes[i - 1]
                               for i in range(1, len(wave_volumes)))
        sequence_score = decreasing_pairs / (len(wave_volumes) - 1)

        # ── Combine: both metrics contribute to the stage score ──────────────
        score = cfg.vol_points * (cfg.vol_w_overall * overall_component +
                                  cfg.vol_w_sequence * sequence_score)

        # Tiers use the exact fractions 2/3 and 1/3 (the spec table's 67% / 33%
        # are roundings of these). A literal 0.67 cutoff would misclassify the
        # canonical 2-of-3 case (66.67%) as Weak rather than Good.
        if   sequence_score >= 1.0 - 1e-9:        seq_tier = 'Excellent'
        elif sequence_score >= cfg.seq_good - 1e-9: seq_tier = 'Good'
        elif sequence_score >= cfg.seq_weak - 1e-9: seq_tier = 'Weak'
        else:                                     seq_tier = 'Fail'

        return score, {'vol_ratio': round(vol_ratio, 3),
                       'vol_sequence_score': round(sequence_score, 3),
                       'vol_sequence_tier': seq_tier,
                       'volume_tier': ('Elite' if vol_ratio < cfg.vol_elite
                                       else 'Strong' if vol_ratio < cfg.vol_strong
                                       else 'Weak')}

    # ─────────────────────────────────────────────────────────────────────
    # STAGE 7: ATR Compression
    # ─────────────────────────────────────────────────────────────────────
    def stage_7_volatility(self, base_df):
        cfg = self.cfg
        if len(base_df) < 2 * cfg.atr_comp_window:
            return 0, {}
        first = base_df['ATR20'].iloc[:cfg.atr_comp_window].mean()
        last  = base_df['ATR20'].iloc[-cfg.atr_comp_window:].mean()
        ratio = safe_divide(last, first, default=1.0)
        score = ScoreCalculator.linear(ratio, cfg.atr_comp_zero,
                                       cfg.atr_comp_full, cfg.atr_comp_points)
        return score, {'atr_ratio': round(ratio, 3)}

    # ─────────────────────────────────────────────────────────────────────
    # STAGE 8: Tight Area
    # ─────────────────────────────────────────────────────────────────────
    def stage_8_tight_area(self, base_df):
        cfg = self.cfg
        if len(base_df) < cfg.tight_window:
            return 0, {}
        last_n = base_df.iloc[-cfg.tight_window:]
        rng        = last_n['High'].max() - last_n['Low'].min()
        mean_close = last_n['Close'].mean()
        if pd.isna(mean_close) or mean_close <= 0 or pd.isna(rng):
            return 0, {'tight_range': None}          # Risk 4 — malformed data
        tight = rng / mean_close
        score = ScoreCalculator.linear(tight, cfg.tight_zero,
                                       cfg.tight_full, cfg.tight_points)
        return score, {'tight_range': round(tight, 4)}

    # ─────────────────────────────────────────────────────────────────────
    # STAGE 9: Resistance / Declining-Lid  (operates on Wave highs)
    # ─────────────────────────────────────────────────────────────────────
    def stage_9_resistance(self, waves):
        highs = [w.high_price for w in waves]
        if len(highs) < 2:
            return 0, {}
        declining = sum(1 for i in range(1, len(highs)) if highs[i] < highs[i - 1])
        ratio = declining / max(1, len(highs) - 1)
        score = ScoreCalculator.linear(ratio, 0.0, 1.0, self.cfg.resistance_points)
        return score, {'declining_highs_ratio': round(ratio, 3)}

    # ─────────────────────────────────────────────────────────────────────
    # STAGE 10: Accumulation
    # ─────────────────────────────────────────────────────────────────────
    def stage_10_accumulation(self, base_df):
        """
        Accumulation = AVERAGE up-day volume / AVERAGE down-day volume (V3.2).

        Averages (not sums) are used deliberately. A sum-based ratio is inflated
        merely by having more up days than down days, so it measures the COUNT
        of advancing days rather than the INTENSITY of institutional
        participation (e.g. 18 up / 2 down days at identical daily volume yields
        a misleadingly high sum-ratio). Per-day averages isolate participation
        regardless of the up/down day mix. Flat days (Close == Previous_Close)
        are excluded from both legs.
        """
        if base_df.empty:
            return 0, {}
        is_up   = base_df['Close'] > base_df['Previous_Close']
        is_down = base_df['Close'] < base_df['Previous_Close']
        up_vol   = base_df[is_up]['Volume']
        down_vol = base_df[is_down]['Volume']

        # mean() of an empty Series is NaN — fall back to a NEUTRAL ratio (1.0)
        # whenever either group is missing or its mean is NaN/≤0 (Risk 1), so an
        # all-up-days base can never inject NaN into the accumulation score.
        avg_up   = up_vol.mean()   if len(up_vol)   else np.nan
        avg_down = down_vol.mean() if len(down_vol) else np.nan
        if pd.isna(avg_up) or pd.isna(avg_down) or avg_down <= 0:
            ratio = 1.0
        else:
            ratio = safe_divide(avg_up, avg_down, default=1.0)

        score = ScoreCalculator.linear(ratio, self.cfg.accum_zero,
                                       self.cfg.accum_full, self.cfg.accum_points)
        return score, {'accumulation_ratio': round(ratio, 3)}

    # ─────────────────────────────────────────────────────────────────────
    # STAGE 11 & 12: Pivot (LOCKED), Readiness & Breakout Trigger
    # ─────────────────────────────────────────────────────────────────────
    def stage_11_12_trigger(self, base_high, waves):
        """
        Pivot (LOCKED): pivot = waves[-1].high_price — high of the most recent
        COMPLETED contraction. Deterministic; never the forming leg.

        Readiness (V3.2 redefined): actual breakout proximity, measured from
        the live close toward the pivot.

            distance_to_pivot = max(0, (pivot - current_close) / pivot)

            ≤ 1 %  Excellent   ≤ 3 %  Good   ≤ 5 %  Acceptable   > 5 %  Poor

        A close at or above the pivot scores full readiness (it is at/through
        the trigger). Negative distance (already above pivot) → Excellent.

        Breakout (LOCKED): close > pivot AND volume ≥ 1.5 × Avg_Vol_50.
        Close-based by design — an intraday high probing above resistance that
        fails by the close is NOT a breakout.
        """
        if not waves:
            return 0, {'trade_signal': False, 'pivot_level': 0,
                       'distance_to_pivot': None, 'readiness_tier': 'None'}

        cfg = self.cfg
        current = self.df.iloc[-1]
        close   = current['Close']
        pivot   = waves[-1].high_price            # ← LOCKED pivot definition

        distance = max(0.0, safe_divide(pivot - close, pivot, default=1.0))

        if   distance <= cfg.ready_excellent:
            readiness_score, tier = cfg.ready_pts_excellent, 'Excellent'
        elif distance <= cfg.ready_good:
            readiness_score, tier = cfg.ready_pts_good, 'Good'
        elif distance <= cfg.ready_acceptable:
            readiness_score, tier = cfg.ready_pts_acceptable, 'Acceptable'
        else:
            poor_zero = cfg.ready_acceptable + cfg.ready_poor_span
            readiness_score = ScoreCalculator.linear(
                distance, poor_zero, cfg.ready_acceptable, cfg.ready_pts_acceptable)
            tier = 'Poor'

        avg_vol_50 = current['Avg_Vol_50']
        trade_signal = bool(close > pivot and
                            not pd.isna(avg_vol_50) and
                            current['Volume'] >= cfg.breakout_vol_mult * avg_vol_50)

        return readiness_score, {'distance_to_pivot': round(distance, 4),
                                 'readiness_tier': tier,
                                 'trade_signal': trade_signal,
                                 'pivot_level': pivot}

    # ─────────────────────────────────────────────────────────────────────
    # MASTER SCORING ENGINE
    # ─────────────────────────────────────────────────────────────────────
    def generate_report(self):
        # Risk 8 / Risk 3 — fail closed on malformed input before any scoring.
        data_ok, data_reasons = self._validate_input_data()
        if not data_ok:
            return {'Score': 0, 'Grade': 'Reject (Invalid Data)',
                    'Trade_Signal_Active': False,
                    'Base_Confidence': 'low', 'Base_Warnings': data_reasons}

        (base_start_num, base_high, base_df, waves,
         base_conf, base_reasons) = self.extract()

        if base_df.empty:
            return {'Score': 0, 'Grade': 'Reject (No Base)', 'Trade_Signal_Active': False,
                    'Base_Confidence': base_conf, 'Base_Warnings': base_reasons}

        t,  tm  = self.stage_1_trend(base_start_num)
        b,  bm  = self.stage_2_base(base_df, base_high)
        c,  cm  = self.stage_3_and_4_contractions(waves)
        h,  hm  = self.stage_5_higher_lows(waves)
        v,  vm  = self.stage_6_volume_dry_up(base_df, waves)
        vo, vom = self.stage_7_volatility(base_df)
        ti, tim = self.stage_8_tight_area(base_df)
        re, rem = self.stage_9_resistance(waves)
        ac, acm = self.stage_10_accumulation(base_df)
        rd, rdm = self.stage_11_12_trigger(base_high, waves)

        # Risk 6 — sanitise each stage score (NaN/±Inf → 0) before aggregation,
        # so a single bad metric can never silently contaminate the total.
        def _finite(x):
            try:
                xv = float(x)
            except (TypeError, ValueError):
                return 0.0
            return xv if np.isfinite(xv) else 0.0

        components = [_finite(x) for x in (t, b, c, h, v, vo, ti, re, ac, rd)]
        raw   = sum(components)
        final = min((raw / self.max_score) * 100, 100)
        if not np.isfinite(final):                    # final guard against NaN/Inf
            final = 0.0
        final = max(0.0, final)

        cfg = self.cfg
        if   final >= cfg.grade_elite:     grade = "Elite"
        elif final >= cfg.grade_strong:    grade = "Strong"
        elif final >= cfg.grade_tradable:  grade = "Tradable"
        elif final >= cfg.grade_watchlist: grade = "Watchlist"
        else:                              grade = "Reject"

        return {
            'Score': round(final, 2),
            'Grade': grade,
            'Trade_Signal_Active': rdm.get('trade_signal', False),
            'Base_Confidence': base_conf,        # Bug 3 diagnostic: high/medium/low
            'Base_Warnings':   base_reasons,     # risk signals (may be empty)
            'Extracted_Pattern': {
                'Base_High':         float(base_high),
                'Base_Start_Bar':    int(base_start_num),
                'Wave_Count':        len(waves),
                'Wave_Depths_Pct':   [round(float(w.depth_pct), 2) for w in waves],
                'Wave_Highs':        [round(float(w.high_price), 2) for w in waves],
                'Wave_Lows':         [round(float(w.low_price), 2)  for w in waves],
                'Pivot':             float(rdm.get('pivot_level', 0)),  # LOCKED
                'Invalid_Waves_Dropped': int(self._invalid_wave_count),  # Risk 7
                # --- §1.6: absolutes the entry half needs (no scoring impact) ---
                'Base_Low':          float(base_df['Low'].min()),
                'Latest_Close':      float(self.df['Close'].iloc[-1]),
                'Latest_ATR':        float(self.df['ATR20'].ffill().bfill().iloc[-1]),
                # --- PATCH AE (v4 avg_vol_50) --- the DENOMINATOR for breakout
                # volume confirmation. Already computed above (rolling(50) on
                # Volume) and already used by the engine's own daily-bar
                # Trade_Signal_Active; it was simply never exported.
                # NaN (fewer than 50 bars) -> 0.0, which the v4 schema defines
                # as UNKNOWN. An unknown denominator can only make a volume gate
                # REFUSE; a fabricated one could make it PASS.
                'Avg_Vol_50':        _finite_vol(self.df['Avg_Vol_50'].iloc[-1]),
                # --- end PATCH AE (v4 avg_vol_50) ---
            },
            'Metrics': {**tm, **bm, **cm, **hm, **vm, **vom,
                        **tim, **rem, **acm, **rdm},
        }
# Backward-compatibility: existing screeners that import VCPAnalyzerV3 keep working.

VCPAnalyzerV3 = VCPAnalyzerV4

# ------------------------------------------------------------------------
# Stage 1 -- extracted verbatim except for the injected fetcher
# ------------------------------------------------------------------------

def _lookback_price(close, trading_days_back):
    """
    Defensive lookback for the RS-score windows below: clamps to the
    earliest available row instead of raising an IndexError. A ticker can
    reach this function with as few as 221 rows (the existing structural
    minimum for cond_3) -- well short of the 252 rows a full 12-month
    lookback wants -- so the 12-month leg gracefully falls back to "the
    oldest price we have" rather than crashing or forcing an artificially
    high length requirement that would reject perfectly normal stocks
    whose '1y' fetch came back at, say, 250-252 rows instead of 253+.
    """
    idx = max(0, len(close) - 1 - trading_days_back)
    return close.iloc[idx]

def compute_rs_ratings(raw_score_by_ticker):
    """
    Converts each ticker's raw weighted-return score into an IBD-style 1-99
    percentile RS Rating, ranked against every OTHER ticker that was
    successfully scored in this same scan -- not just the ones that already
    passed conditions 1-7. RS Rating is meant to describe a stock's price
    strength relative to its peer universe independent of the other
    Minervini conditions, so the percentile has to be computed across the
    full scored population first; only then does "RS Rating >= 70" become
    condition 8. This can only run once every ticker has a score, which is
    why it happens after run_parallel_scan's main loop, not inside it.

    Caveat worth knowing: this ranks against the ~500 S&P 500 names that
    were actually scanned, not IBD's full multi-thousand-stock database, so
    the percentile is "strongest within the S&P 500" rather than "strongest
    in the entire market." For an index-membership scanner like this one,
    that's arguably the more useful comparison anyway.
    """
    if not raw_score_by_ticker:
        return {}
    tickers = list(raw_score_by_ticker.keys())
    scores = pd.Series([raw_score_by_ticker[t] for t in tickers], index=tickers)
    pct = scores.rank(pct=True, method='average') * 100
    return pct.round().clip(lower=1, upper=99).astype(int).to_dict()

def check_minervini_technicals(ticker):
    """
    Conditions 1-7 (price/SMA/52-week structure): same formulas and
    thresholds as the original script, untouched. Returns `structural_pass`
    (conditions 1-7 only) and `raw_rs_score` (this ticker's own weighted-
    return score, not yet a percentile). The RS Rating >= 70 gate (condition
    8) is applied afterward in run_parallel_scan(), once compute_rs_ratings()
    has seen every score.
    """
    data = _fetch_history(ticker, '1y')

    if data is None or data.empty:
        return False, None, None, None, None, "fetch_failed"

    # 221, not 200: sma_200_20d_ago = rolling(200).mean().iloc[-21] only
    # becomes a real (non-NaN) value once there are >= 220 rows, since
    # rolling(200) itself only starts producing values at row index 199.
    # At exactly 200 rows, iloc[-21] points at index 179 -- still NaN --
    # so cond_3 (sma_200 > sma_200_20d_ago) silently evaluates to False
    # for every stock with 200-220 days of history (e.g. recent IPOs/
    # spinoffs), with no error or warning. 221 leaves a 1-day margin.
    if len(data) < 221:
        return False, None, None, None, None, "insufficient_history"

    try:
        close = data['Close'].dropna().squeeze()
        high = data['High'].dropna().squeeze()
        low = data['Low'].dropna().squeeze()

        sma_50 = close.rolling(window=50).mean().iloc[-1]
        sma_150 = close.rolling(window=150).mean().iloc[-1]
        sma_200 = close.rolling(window=200).mean().iloc[-1]
        sma_200_20d_ago = close.rolling(window=200).mean().iloc[-21]

        current_price = close.iloc[-1]
        low_52wk = low.min()
        high_52wk = high.max()
        stock_6m_return = (close.iloc[-1] - close.iloc[-126]) / close.iloc[-126]

        cond_1 = current_price > sma_150 and current_price > sma_200
        cond_2 = sma_150 > sma_200
        cond_3 = sma_200 > sma_200_20d_ago
        cond_4 = sma_50 > sma_150 and sma_50 > sma_200
        cond_5 = current_price > sma_50
        cond_6 = current_price >= (low_52wk * 1.30)
        cond_7 = current_price >= (high_52wk * 0.75)

        structural_pass = all([cond_1, cond_2, cond_3, cond_4, cond_5, cond_6, cond_7])
        high_20d = high.tail(20).max()

        # IBD-style segmental RS raw score: each term covers exactly one
        # 3-month window so no quarter bleeds into another. Q4 (most recent)
        # gets 40%; Q3/Q2/Q1 (older quarters) 20% each. The previous version
        # used cumulative ratios (all anchored to p_now), which caused a
        # strong last quarter to inflate the 6m, 9m, and 12m terms as well.
        p_now = close.iloc[-1]
        p_3m = _lookback_price(close, 63)
        p_6m = _lookback_price(close, 126)
        p_9m = _lookback_price(close, 189)
        p_12m = _lookback_price(close, 252)
        raw_rs_score = (0.4 * (p_now / p_3m) +    # Q4: last 3 months
                        0.2 * (p_3m  / p_6m) +    # Q3: 3–6 months ago
                        0.2 * (p_6m  / p_9m) +    # Q2: 6–9 months ago
                        0.2 * (p_9m  / p_12m))    # Q1: 9–12 months ago

        return structural_pass, current_price, high_20d, stock_6m_return, raw_rs_score, "ok"
    except (KeyError, IndexError, ValueError, TypeError):
        # expected when price data is short/malformed -> just not a match
        return False, None, None, None, None, "calc_error"
    except Exception as e:
        # anything else is probably a real bug -- surface it, do not hide it
        print(f"    [UNEXPECTED] {ticker}: {type(e).__name__}: {e}", flush=True)
        return False, None, None, None, None, "unexpected_error"
