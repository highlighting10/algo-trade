#!/usr/bin/env python3
"""
patch_shadow_proof.py -- stop kis-backtest's kistrader copy shadowing this repo.

WHAT HAPPENED
    python -m pytest -q      (run from PyCharmMiscProject, the PARENT)
    -> ImportError: cannot import name 'regime_path_for' from
       'kistrader.entry.screen_contract'
       (...\\kis-backtest\\kistrader\\entry\\screen_contract.py)
    -> ModuleNotFoundError: No module named 'kistrader.entry.entry_manager'
    ... 5 collection errors, every one naming the WRONG REPO.

kis-backtest ships its own partial COPY of kistrader/. From the parent directory
pytest makes the parent its rootdir and collects both projects; kis-backtest
sorts first, its files import `kistrader`, and that copy lands in sys.modules.
Every kis-trader suite imported afterwards gets it -- the copy has no
entry_manager, no decision_engine, no tools, and a screen_contract predating
Phase 3a.

WHY THE EXISTING BOOTSTRAP DID NOT HELP
It inserts this repo on sys.path, which is necessary but not sufficient: Python
NEVER re-resolves an already-imported package. Once `kistrader` is in
sys.modules, sys.path is irrelevant. Measured both ways -- with sys.modules
clean the bootstrap wins and all 86 pass; with it poisoned first, the bootstrap
changes nothing.

THE FIX
Two changes to the bootstrap in every suite:
  1. Move this repo to the FRONT of sys.path even if it is already present
     further down, so a foreign entry cannot win a fresh import.
  2. If `kistrader` is ALREADY loaded from outside this repo, evict it and its
     submodules from sys.modules so the next import resolves here. Print a line
     when that happens -- a silent fix would hide a genuinely confusing setup.

The eviction is surgical: it fires only when the loaded package is outside
_ROOT, and objects already held by the other project keep working (they hold
references; only the cache entry goes).

Running pytest from kis-trader remains the right habit -- from the parent you
also collect the backtest suite. This just stops the wrong directory producing
eight errors that point at the wrong file.

Usage:  python patch_shadow_proof.py <repo-root>
"""
from __future__ import annotations

import os
import re
import sys

NEW = '''# Self-locating AND shadow-proof. Two separate problems, both measured:
#  1. `kistrader` and `screeners` are not installed packages (pyproject
#     packages.find includes only kistrader*), so a DIRECT run -- sys.path[0] is
#     tests/ -- cannot import either. pytest happens to work because pyproject
#     sets pythonpath = [".", "tests"].
#  2. kis-backtest ships a partial COPY of kistrader/. Run pytest from the parent
#     directory and it collects both projects; whichever imports first wins
#     sys.modules, and after that sys.path is irrelevant -- Python never
#     re-resolves an imported package. That produced five collection errors
#     naming the wrong repo.
import os as _os, sys as _sys
_ROOT = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))
for _p in (_os.path.join(_ROOT, "screeners"), _ROOT):
    while _p in _sys.path:
        _sys.path.remove(_p)                 # move to the FRONT, not merely present
    _sys.path.insert(0, _p)
_k = _sys.modules.get("kistrader")
_kf = _os.path.abspath(getattr(_k, "__file__", "") or "") if _k is not None else ""
if _k is not None and not _kf.startswith(_ROOT + _os.sep):
    print(f"[path] evicting a foreign kistrader loaded from {_kf!r}; "
          f"this suite tests {_ROOT!r}")
    for _m in [_m for _m in list(_sys.modules)
               if _m == "kistrader" or _m.startswith("kistrader.")]:
        del _sys.modules[_m]
'''

# matches the two bootstrap shapes already in the tree, with or without a comment
OLD_RE = re.compile(
    r"(?:#[^\n]*\n)*"
    r"(?:import os as _os, sys as _sys\n)?"
    r"_(?:HERE|ROOT) = _?os\.path\.dirname\([^\n]*\n"
    r"(?:_ROOT = _?os\.path\.dirname\(_HERE\)\n)?"
    r"for _p in \([^\n]*\n"
    r"    if _p not in _?sys\.path:\n"
    r"        _?sys\.path\.insert\(0, _p\)\n")


def main(root):
    tests = os.path.join(root, "tests")
    if not os.path.isdir(tests):
        raise SystemExit(f"REFUSING: not found: {tests}")
    done = 0
    for name in sorted(os.listdir(tests)):
        if not (name.startswith("test_") and name.endswith(".py")):
            continue
        p = os.path.join(tests, name)
        with open(p, encoding="utf-8") as f:
            s = f.read()
        if "evicting a foreign kistrader" in s:
            print(f"  -- {name}: already shadow-proof")
            continue
        m = OLD_RE.search(s)
        if not m:
            print(f"  -- {name}: no bootstrap found, skipped")
            continue
        s = s[:m.start()] + NEW + s[m.end():]
        with open(p, "w", encoding="utf-8", newline="") as f:
            f.write(s)
        print(f"  ok  {name}: bootstrap replaced (front-of-path + eviction)")
        done += 1
    if not done:
        raise SystemExit("REFUSING: nothing changed.")
    print("\nAPPLIED. A foreign kistrader can no longer shadow this repo's suites.")
    return 0


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("usage: python patch_shadow_proof.py <repo-root>")
    sys.exit(main(sys.argv[1]))
