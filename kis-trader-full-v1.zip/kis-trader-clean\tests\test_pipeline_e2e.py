#!/usr/bin/env python3
"""
End-to-end pipeline integration test (§7.6, offline)
====================================================

The unit suite (test_entry_half.py) proves each piece. This proves the ASSEMBLED
PipelineLoop drives a full lifecycle with the real ExecutionMonitor + RunLoop
wiring — the surface that only exists once everything is bolted together:

  E1  arm_today -> fill -> on_fill handoff -> monitor ticks it -> stop exit
  E2  recovery routing on start(): FILLED snapshot -> monitor list,
      PENDING_ENTRY snapshot -> EntryManager.adopt (not driven as a holding)
  E3  §5.4 wiring: on the OPEN->CLOSED transition the loop calls on_close with
      the ema/close providers (activates stall-exit / EMA-trail)

All with FakeBroker + a controllable session clock. No KIS, no network.
"""
from __future__ import annotations


import os
import sys
from datetime import datetime, timezone

# Self-locating AND shadow-proof. Two separate problems, both measured:
#  1. `kistrader` and `screeners` are not installed packages (pyproject
#     packages.find includes only kistrader*), so a DIRECT run -- sys.path[0] is
#     tests/ -- cannot import either. pytest happens to work because pyproject
#     sets pythonpath = [".", "tests"].
#  2. kis-backtest ships a partial COPY of kistrader/. Run pytest from the parent
#     directory and it collects both projects; whichever imports first wins
#     sys.modules, and after that sys.path is irrelevant -- Python never
#     re-resolves an imported package. That produced five collection errors
#     naming the wrong repo.
import os as _os, sys as _sys
_ROOT = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))
for _p in (_os.path.join(_ROOT, "screeners"), _ROOT):
    while _p in _sys.path:
        _sys.path.remove(_p)                 # move to the FRONT, not merely present
    _sys.path.insert(0, _p)
_k = _sys.modules.get("kistrader")
_kf = _os.path.abspath(getattr(_k, "__file__", "") or "") if _k is not None else ""
if _k is not None and not _kf.startswith(_ROOT + _os.sep):
    print(f"[path] evicting a foreign kistrader loaded from {_kf!r}; "
          f"this suite tests {_ROOT!r}")
    for _m in [_m for _m in list(_sys.modules)
               if _m == "kistrader" or _m.startswith("kistrader.")]:
        del _sys.modules[_m]

from kistrader.core.engine_v2 import ExecutionMonitor, PositionState, HOLDING_STATES
from kistrader.core.run_loop import USSessionClock
from kistrader.entry.entry_manager import EntryManager
from kistrader.entry.decision_engine import DecisionEngine, DecisionConfig
from kistrader.entry.pipeline import PipelineLoop
from kistrader.entry.screen_contract import (Candidate, write_candidates,
                                             write_regime, regime_path_for)
from kistrader.entry.exposure_controller import (ExposureController,
                                                 ExposureConfig)
from kistrader.core.engine_v2 import Position
from dataclasses import replace
from kistrader.entry.pipeline import ORPHAN_ALERT_COOLDOWN_SECS
from test_entry_half import FakeBroker, FakeClock, _db

PASS, FAIL = [], []
def check(name, cond, detail=""):
    (PASS if cond else FAIL).append(name)
    print(f"  [{'PASS' if cond else 'FAIL'}] {name}" + (f"  ({detail})" if detail and not cond else ""))

# a weekday inside US regular hours: 2026-07-06 (Mon) 15:00 UTC == 11:00 EDT
OPEN_UTC = datetime(2026, 7, 6, 15, 0, tzinfo=timezone.utc)
CLOSED_UTC = datetime(2026, 7, 6, 21, 0, tzinfo=timezone.utc)   # 17:00 EDT


SESSION = "2026-07-06"          # the one date every e2e fixture is dated for
# The sidecar cross-check compares the file's vcp_threshold against the LIVE
# constant, so a fixture that hardcodes it fails the moment the threshold moves
# (found 2026-08-19 at the TECHNICAL soak value 45). Single-source it, the same
# discipline patch_d3a_threshold applied to the screeners. The 70.0 sites are
# DELIBERATE mismatches and stay literal.
from kistrader.entry.screen_contract import VCP_SCORE_THRESHOLD as _LIVE_VCP


def _cand(ticker="MU", pivot=100.0, base_low=92.0, base_high=105.0, atr=2.0,
          last_close=100.0, rs=90, s2=70, date=SESSION,
          contraction_low=None):
    # v3: contraction_low is the stop anchor (fail-closed if absent). Default it
    # DISTINCT from base_low so an anchor regression breaks these tests too.
    cl = (base_low + (pivot - base_low) * 0.5) if contraction_low is None else contraction_low
    return Candidate(ticker=ticker, exchange="NAS", rs_proxy=rs, stage2_score=s2,
                     vcp_score=88.0, pivot=pivot, base_high=base_high, base_low=base_low,
                     depth_pct=round((base_high-base_low)/base_high, 4),
                     contraction_low=round(cl, 2),
                     last_close=last_close, atr=atr, trade_signal=True,
                     session_date=date, name=ticker, close_known=True)


def _assemble(now_holder, ema_provider=None, close_provider=None):
    b = FakeBroker()
    fclk = FakeClock()                                  # monotonic timers
    clk = USSessionClock(now_fn=lambda: now_holder["t"])
    db, path = _db()
    monitor = ExecutionMonitor(b, db, alert=lambda m: None, clock=fclk)
    loop_ref = {}
    def on_fill(pos):
        lp = loop_ref.get("loop")
        if lp is not None:
            lp._positions.append(pos)
    entry = EntryManager(b, db, on_fill=on_fill, alert=lambda m: None, clock=fclk,
                         require_buying_power=False, require_open_order_check=True,
                         entry_timeout_secs=30)
    decision = DecisionEngine(DecisionConfig(risk_per_trade_pct=0.01, sector_cap=0,
                                             max_position_pct=1.0))
    loop = PipelineLoop(monitor, b, entry, decision, universe=None,
                        heartbeat_path=None,
                        equity_provider=lambda: 100_000.0, clock=clk,
                        ema_provider=ema_provider, close_provider=close_provider,
                        alert=lambda m: None)
    loop_ref["loop"] = loop
    return b, db, path, monitor, entry, decision, loop, fclk


def _capture(loop):
    """Start the loop and collect its alerts. `seen` is per-test in this file."""
    out = []
    loop.alert = out.append
    loop.start()
    return out


def _write_csv(cands, path="e2e_candidates.csv", regime="risk_on", session=None):
    """Write the CSV and, unless regime=None, the sidecar the screener writes
    beside it. Production always produces both, so a fixture with only the CSV
    would be testing a shape that cannot occur -- and would fail closed at the
    regime gate, correctly but uselessly."""
    write_candidates(path, cands)
    rp = regime_path_for(path)
    if regime is None:
        os.path.exists(rp) and os.unlink(rp)
        return path
    sess = session or SESSION
    close, ma = (110.0, 100.0) if regime == "risk_on" else (90.0, 100.0)
    write_regime(rp, session_date=sess, screener="sp500_v21", vcp_threshold=_LIVE_VCP,
                 benchmark="^GSPC", regime_ma=20, benchmark_close=close,
                 benchmark_ma=ma, bar_date=sess, emitted=len(cands),
                 log=lambda m: None)
    return path


def test_e1_full_lifecycle():
    print("E1 arm -> fill -> handoff -> monitor tick -> stop exit")
    now = {"t": OPEN_UTC}
    b, db, path, mon, entry, dec, loop, fclk = _assemble(now)
    check("clock is OPEN for the test window", loop.clock.phase() == "OPEN")
    csv = _write_csv([_cand("MU", pivot=100.0, base_low=92.0, last_close=100.0)])

    loop.start()
    check("clean start (no positions/pending)",
          loop.positions() == [] and entry.pending() == [])

    armed, rej = loop.arm_today(csv)
    check("arm_today armed one", len(armed) == 1, f"rej={[(r.ticker,r.reason) for r in rej]}")
    check("armed as a WATCH: no order yet, none pending",
          b.place_calls == 0 and entry.pending() == [] and len(entry.watching()) == 1)

    # below the pivot: a full cycle must NOT place anything
    b._price["MU"] = 99.0
    loop.cycle()
    check("below pivot: cycle places nothing", b.place_calls == 0)

    # quote crosses the pivot -> the next cycle triggers the watch and places
    b._price["MU"] = 100.6
    loop.cycle()
    check("pivot cross -> BUY limit placed, watch -> pending",
          b.place_calls == 1 and len(entry.pending()) == 1
          and entry.watching() == [])
    pend = entry.pending()[0]
    oid = pend.live_order_id
    stop = pend.stop_loss_price

    # broker now reports a full fill just inside the limit; price benign (above stop).
    # A filled BUY also increases holdings — the exit engine confirms exposure via
    # get_holding before it will place a SELL, so the fake must model that.
    b._fills[oid] = pend.live_order_qty
    b._vwap[oid] = pend.entry_price
    b._holdings["MU"] = pend.live_order_qty
    b._price["MU"] = round(stop + 5.0, 2)

    loop.cycle()                                        # OPEN: super().cycle() then entry.poll()
    live = loop.positions()
    check("fill confirmed -> FILLED in the loop's managed list",
          len(live) == 1 and live[0].state == PositionState.FILLED)
    check("entry pending drained after handoff", entry.pending() == [])
    pos = live[0]
    check("monitor sees it as a HOLDING state", pos.state in HOLDING_STATES)
    check("risk frozen from real fill (>0)", pos.initial_risk_per_share > 0)

    # drop price to/below the stop -> next cycle begins the exit (marks EXITING),
    # the cycle after that places the actual SELL via _advance_exit
    b._price["MU"] = round(stop - 1.0, 2)
    sell_before = b.place_calls
    loop.cycle()
    check("stop breach -> position EXITING", pos.state == PositionState.EXITING,
          f"state={pos.state.value}")
    loop.cycle()                                        # _advance_exit places the SELL
    check("an exit (SELL) order was placed", b.place_calls > sell_before,
          f"place_calls={b.place_calls}")
    db.conn.close(); os.unlink(path); os.path.exists(csv) and os.unlink(csv)


def test_e2_recovery_routing():
    print("E2 recovery: FILLED -> monitor, PENDING_ENTRY -> adopt")
    now = {"t": OPEN_UTC}
    b, db, path, mon, entry, dec, loop, fclk = _assemble(now)

    # arm MU and fill it (creates a FILLED snapshot), arm NVDA and leave resting
    csv = _write_csv([_cand("MU", pivot=100, base_low=92, last_close=100),
                      _cand("NVDA", pivot=180, base_low=165, base_high=190,
                            atr=4, last_close=180)])
    loop.start()
    armed, _ = loop.arm_today(csv)
    check("armed two (as watches)", len(armed) == 2 and b.place_calls == 0)
    mu = next(p for p in armed if p.ticker == "MU")
    b._price["MU"] = 100.6                              # cross MU's pivot
    b._price["NVDA"] = 180.4                            # cross NVDA's pivot
    loop.cycle()                                        # both watches trigger -> orders
    check("both triggered -> two orders", b.place_calls == 2
          and len(entry.pending()) == 2)
    b._fills[mu.live_order_id] = mu.live_order_qty
    b._vwap[mu.live_order_id] = mu.entry_price
    b._price["MU"] = mu.stop_loss_price + 5
    loop.cycle()                                        # MU fills -> FILLED snapshot in db
    check("MU is FILLED, NVDA still pending",
          any(p.ticker == "MU" and p.state == PositionState.FILLED for p in loop.positions())
          and any(p.ticker == "NVDA" for p in entry.pending()))

    # simulate a restart: brand-new loop/monitor/entry over the SAME db
    b2, db2, path2, mon2, entry2, dec2, loop2, fclk2 = _assemble(now)
    db2.conn.close(); os.unlink(path2)                  # discard fresh db; reuse the first
    mon2.db = db2 = db
    entry2.db = db
    # NVDA order still rests at the (shared) broker so adopt can re-find it
    b2.orders = b.orders; b2._status = b._status; b2._fills = b._fills; b2._vwap = b._vwap
    b2._holdings = {"MU": mu.live_order_qty}            # holdings truth shows MU held

    loop2.start()
    holds = {p.ticker for p in loop2.positions()}
    pends = {p.ticker for p in entry2.pending()}
    check("FILLED MU routed to the monitor list", "MU" in holds)
    check("PENDING NVDA routed to EntryManager.adopt (not a holding)",
          "NVDA" in pends and "NVDA" not in holds)
    db.conn.close(); os.unlink(path); os.path.exists(csv) and os.unlink(csv)


def test_e3_on_close_wiring():
    print("E3 §5.4 on_close fires with ema/close providers on OPEN->CLOSED")
    now = {"t": OPEN_UTC}
    seen = {"close": [], "ema": []}
    ema_p = lambda t: (seen["ema"].append(t) or 21.0)
    close_p = lambda t: (seen["close"].append(t) or 55.0)
    b, db, path, mon, entry, dec, loop, fclk = _assemble(now, ema_provider=ema_p,
                                                          close_provider=close_p)
    csv = _write_csv([_cand("MU", pivot=100, base_low=92, last_close=100)])
    loop.start(); armed, _ = loop.arm_today(csv)
    p = armed[0]
    b._price["MU"] = 100.6                              # cross the pivot
    loop.cycle()                                        # trigger -> place
    b._fills[p.live_order_id] = p.live_order_qty
    b._vwap[p.live_order_id] = p.entry_price
    b._price["MU"] = p.stop_loss_price + 5
    loop.cycle()                                        # fill -> FILLED (held)
    check("position held before close", any(x.state in HOLDING_STATES
          for x in loop.positions()))

    now["t"] = CLOSED_UTC                                # flip to CLOSED -> on_close transition
    loop.cycle()
    check("close_provider was queried on close", "MU" in seen["close"])
    check("ema_provider was queried on close", "MU" in seen["ema"])
    db.conn.close(); os.unlink(path); os.path.exists(csv) and os.unlink(csv)


def test_e4_auto_arm():
    print("E4 unattended auto-arm: opt-in, once per session, first OPEN cycle")
    # (a) opt-in ON: the first OPEN cycle arms (watch, no order); later cycles
    #     never re-arm the same session.
    now = {"t": OPEN_UTC}
    b, db, path, mon, entry, dec, loop, fclk = _assemble(now)
    csv = _write_csv([_cand("MU", pivot=100.0, last_close=99.0)])
    loop.auto_arm = True
    loop.candidates_path = csv
    seen = []
    loop.alert = lambda m: seen.append(m)
    loop.start()
    check("start alone does not arm", entry.watching() == [] and b.place_calls == 0)
    b._price["MU"] = 99.0                                # below pivot: watch only
    loop.cycle()
    check("first OPEN cycle auto-armed -> 1 watching, 0 orders",
          len(entry.watching()) == 1 and b.place_calls == 0)
    loop.cycle(); loop.cycle()
    arms = [m for m in seen if m.startswith("arm_today:")]
    check("auto-arm fired exactly once this session", len(arms) == 1, f"n={len(arms)}")
    db.conn.close(); os.unlink(path); os.path.exists(csv) and os.unlink(csv)

    # (b) default OFF: cycles never arm on their own.
    now2 = {"t": OPEN_UTC}
    b2, db2, path2, mon2, entry2, dec2, loop2, fclk2 = _assemble(now2)
    csv2 = _write_csv([_cand("MU", pivot=100.0, last_close=99.0)], "e2e_c2.csv")
    loop2.candidates_path = csv2
    loop2.start(); loop2.cycle(); loop2.cycle()
    check("auto_arm default OFF: no arm without the flag",
          entry2.watching() == [] and b2.place_calls == 0)
    db2.conn.close(); os.unlink(path2); os.path.exists(csv2) and os.unlink(csv2)


def test_e5_exit_alerts():
    print("E5 exit visibility: stop-hit and close are ANNOUNCED, not silent")
    # Regression guard for the 2026-07-23 finding: engine_v2 persists the whole
    # exit lifecycle to the event store but never calls alert(), so a live stop
    # fired, a real SELL executed and the position closed in 58s with ZERO alert
    # lines. Unattended that is a stop with no notification. PipelineLoop now
    # watches state TRANSITIONS; these checks fail if that layer regresses.
    now = {"t": OPEN_UTC}
    seen = []
    b, db, path, mon, entry, dec, loop, fclk = _assemble(now)
    loop.alert = lambda m: seen.append(m)
    csv = _write_csv([_cand("MU", pivot=100.0, base_low=92.0, last_close=100.0)],
                     "e2e_exit.csv")
    loop.start()
    loop.arm_today(csv)
    b._price["MU"] = 100.6
    loop.cycle()                                        # trigger -> BUY placed
    pend = entry.pending()[0]
    oid, stop = pend.live_order_id, pend.stop_loss_price
    b._fills[oid] = pend.live_order_qty
    b._vwap[oid] = pend.entry_price
    b._holdings["MU"] = pend.live_order_qty
    b._price["MU"] = round(stop + 5.0, 2)
    seen.clear()
    loop.cycle()                                        # entry fill -> FILLED
    check("entry fill is NOT double-announced by the transition layer",
          not any("-> FILLED" in m for m in seen), f"seen={seen}")

    # breach the stop
    b._price["MU"] = round(stop - 1.0, 2)
    seen.clear()
    loop.cycle()
    pos = loop.positions()[0]
    check("stop breach -> position EXITING", pos.state == PositionState.EXITING,
          f"state={pos.state.value}")
    check("EXITING is ALERTED (was silent before this layer)",
          any("EXITING" in m and "MU" in m for m in seen), f"seen={seen}")
    check("the alert names the reason", any("STOP_HIT" in m for m in seen), f"seen={seen}")

    loop.cycle()                                        # SELL placed
    sell_oid = pos.live_order_id
    check("a SELL is working", sell_oid is not None and sell_oid != oid)

    # the SELL fills -> position closes
    b._fills[sell_oid] = pos.shares
    b._holdings["MU"] = 0
    seen.clear()
    loop.cycle()
    check("position reaches CLOSED", pos.state == PositionState.CLOSED,
          f"state={pos.state.value}")
    check("CLOSED is ALERTED", any("CLOSED" in m and "MU" in m for m in seen),
          f"seen={seen}")
    check("close alert carries the entry price for P/L context",
          any("entry" in m for m in seen), f"seen={seen}")

    # a terminal position must not re-alert forever
    seen.clear()
    loop.cycle(); loop.cycle()
    check("terminal position does not re-alert", seen == [], f"seen={seen}")
    db.conn.close(); os.unlink(path); os.path.exists(csv) and os.unlink(csv)


def test_e6_freshness_gate():
    print("E6 freshness gate: stale/missing candidates.csv arms NOTHING, loudly")
    # Regression guard for the 2026-08-01 finding: arm_today read candidates.csv
    # with no session-date filter and no read guard. candidate_emit purges stale
    # rows when it WRITES, so a stale file means the screener never ran — and a
    # MISSING file raised FileNotFoundError straight out of cycle() (run_forever
    # has no per-cycle guard -> deterministic restart loop -> crash-storm give-up).

    # (a) every row stale -> arm nothing, escalated, no order
    now = {"t": OPEN_UTC}
    b, db, path, mon, entry, dec, loop, fclk = _assemble(now)
    seen = []
    loop.alert = lambda m: seen.append(m)
    csv = _write_csv([_cand("MU", pivot=100.0, date="2026-07-02"),
                      _cand("NVDA", pivot=180, base_low=165, base_high=190,
                            atr=4, last_close=180, date="2026-07-02")],
                     "e2e_stale.csv")
    loop.start(); seen.clear()
    armed, _ = loop.arm_today(csv)
    check("all-stale: armed nothing", armed == [] and entry.watching() == [])
    check("all-stale: placed no order", b.place_calls == 0)
    check("all-stale: escalated (ARM BLOCKED)",
          any("ARM BLOCKED" in m for m in seen), f"seen={seen}")
    check("all-stale: alert carries both dates",
          any("2026-07-02" in m and "2026-07-06" in m for m in seen), f"seen={seen}")
    db.conn.close(); os.unlink(path); os.path.exists(csv) and os.unlink(csv)

    # (b) mixed -> only the fresh row arms; degraded, not blocked
    now = {"t": OPEN_UTC}
    b, db, path, mon, entry, dec, loop, fclk = _assemble(now)
    seen = []
    loop.alert = lambda m: seen.append(m)
    csv = _write_csv([_cand("MU", pivot=100.0, date="2026-07-02"),
                      _cand("NVDA", pivot=180, base_low=165, base_high=190,
                            atr=4, last_close=180, date="2026-07-06")],
                     "e2e_mixed.csv")
    loop.start(); seen.clear()
    armed, _ = loop.arm_today(csv)
    check("mixed: only the fresh name armed",
          [p.ticker for p in armed] == ["NVDA"], f"armed={[p.ticker for p in armed]}")
    check("mixed: the drop is announced with an exact count",
          any("dropped 1 STALE" in m for m in seen), f"seen={seen}")
    check("mixed: a partial drop does NOT escalate",
          not any("ARM BLOCKED" in m for m in seen), f"seen={seen}")
    db.conn.close(); os.unlink(path); os.path.exists(csv) and os.unlink(csv)

    # (c) all fresh -> normal arm, NO stale warning (guards a false-positive gate)
    now = {"t": OPEN_UTC}
    b, db, path, mon, entry, dec, loop, fclk = _assemble(now)
    seen = []
    loop.alert = lambda m: seen.append(m)
    csv = _write_csv([_cand("MU", pivot=100.0, date="2026-07-06")], "e2e_fresh.csv")
    loop.start(); seen.clear()
    armed, _ = loop.arm_today(csv)
    check("fresh-only: arms normally", len(armed) == 1)
    check("fresh-only: no stale warning", not any("STALE" in m for m in seen), f"seen={seen}")
    db.conn.close(); os.unlink(path); os.path.exists(csv) and os.unlink(csv)

    # (d) blank session_date is STALE, not "close enough" (problems() never checks it)
    now = {"t": OPEN_UTC}
    b, db, path, mon, entry, dec, loop, fclk = _assemble(now)
    seen = []
    loop.alert = lambda m: seen.append(m)
    csv = _write_csv([_cand("MU", pivot=100.0, date="")], "e2e_nodate.csv")
    loop.start(); seen.clear()
    armed, _ = loop.arm_today(csv)
    check("blank session_date: armed nothing", armed == [] and b.place_calls == 0)
    check("blank session_date: reported as missing",
          any("<missing>" in m for m in seen), f"seen={seen}")
    db.conn.close(); os.unlink(path); os.path.exists(csv) and os.unlink(csv)

    # (e) missing file: no raise out of arm_today OR cycle() -> no crash storm
    now = {"t": OPEN_UTC}
    b, db, path, mon, entry, dec, loop, fclk = _assemble(now)
    seen = []
    loop.alert = lambda m: seen.append(m)
    gone = "e2e_no_such_file.csv"
    os.path.exists(gone) and os.unlink(gone)
    loop.start(); seen.clear()
    armed, _ = loop.arm_today(gone)
    check("missing file: arms nothing without raising", armed == [])
    check("missing file: escalated (ARM BLOCKED)",
          any("ARM BLOCKED" in m for m in seen), f"seen={seen}")
    loop.auto_arm = True
    loop.candidates_path = gone
    loop._auto_armed_date = None
    crashed = None
    try:
        loop.cycle()
    except Exception as e:
        crashed = f"{type(e).__name__}: {e}"
    check("missing file: OPEN cycle survives auto-arm (no crash storm)",
          crashed is None, f"raised {crashed}")
    db.conn.close(); os.unlink(path)


def test_e7_regime_gate():
    """§Phase 3c. The screener's sidecar decides whether NEW entries are allowed.

    Everything here runs through the ONE existing ceiling
    (DecisionConfig.max_portfolio_exposure_pct), so every block arrives as a
    normal, named decision-engine rejection rather than a separate gate."""
    print("E7 regime gate: the sidecar decides whether new entries are allowed")
    now = {"t": OPEN_UTC}
    CAND = dict(pivot=100.0, base_low=92.0, last_close=100.0)

    # (a) risk_on -> normal arming
    b, db, path, mon, entry, dec, loop, fclk = _assemble(now)
    csv = _write_csv([_cand("MU", **CAND)], path="e2e_regime.csv", regime="risk_on")
    seen = _capture(loop)
    armed, rej = loop.arm_today(csv)
    check("risk_on: arms normally", len(armed) == 1, f"{[r.reason for r in rej]}")
    check("risk_on: announced with the benchmark numbers",
          any("RISK_ON" in m and "^GSPC" in m for m in seen), f"{seen}")

    # (b) risk_off -> nothing arms, and the reason is a named ceiling, not silence
    # PATCH F3: the gate is OFF by default now, so this case sets it explicitly.
    # It tests the gate MECHANISM, not the deployment DEFAULT -- which is what
    # it always meant. Reading the default made it silently untestable the
    # moment the default moved.
    b, db, path, mon, entry, dec, loop, fclk = _assemble(now)
    loop.exposure = ExposureController(ExposureConfig(regime_ma=20))
    csv = _write_csv([_cand("MU", **CAND)], path="e2e_regime.csv", regime="risk_off")
    seen = _capture(loop)
    armed, rej = loop.arm_today(csv)
    check("risk_off: arms nothing", armed == [], f"{armed}")
    check("risk_off: no broker order was placed", b.place_calls == 0, f"{b.place_calls}")
    check("risk_off: the rejection names the exposure ceiling",
          bool(rej) and all("exposure ceiling" in r.reason for r in rej),
          f"{[r.reason for r in rej]}")
    # Brief sec.9 asks for the SCORES on every rejection line, not just the
    # reason: "after a few weeks yields a distribution of how much each bar
    # filters and how close the near-misses came". That matters more since
    # RESULT_20260911_emit_bar_yield_measured sec.8 measured max 1 armable name
    # per session -- a soak's information is almost entirely near-misses.
    #
    # The suffix shipped in f80eb79 and IS exercised by the check above (a
    # rejected ticker is in `cands`, so the score branch formats the alert), but
    # nothing ASSERTED it, so it could be deleted with all 583 still green.
    # Exact string, not a "rs=" sniff: this also catches a dropped field, a lost
    # :.1f, and rs_rating creeping back in place of rs_proxy. _cand defaults are
    # rs=90, s2=70, vcp_score=88.0 and CAND overrides none of them.
    check("risk_off: the arm-reject line carries RS / stage2 / VCP",
          any("arm reject: MU" in m and "[rs=90 s2=70.0 vcp=88.0]" in m
              for m in seen),
          f"{[m for m in seen if 'arm reject' in m]}")
    check("risk_off: distinguishable from 'nothing qualified'",
          any("RISK_OFF" in m and "NO new entries" in m for m in seen), f"{seen}")
    # The 0.0 ceiling must be built PER CALL. If it were written back onto the
    # shared config, tomorrow's session would inherit it and trading would stop
    # for good, silently. This is the loop where a leak would be visible.
    check("risk_off: the shared DecisionConfig was NOT mutated",
          loop.decision.cfg.max_portfolio_exposure_pct != 0.0,
          f"{loop.decision.cfg.max_portfolio_exposure_pct}")
    check("risk_off: a second arm in the same session still sees the real ceiling",
          DecisionEngine(loop.decision.cfg).cfg.max_portfolio_exposure_pct > 0.0)

    # (c) no sidecar at all -> fail closed
    b, db, path, mon, entry, dec, loop, fclk = _assemble(now)
    csv = _write_csv([_cand("MU", **CAND)], path="e2e_regime.csv", regime=None)
    seen = _capture(loop)
    armed, rej = loop.arm_today(csv)
    check("missing sidecar: arms nothing (a gate that cannot evaluate must not pass)",
          armed == [], f"{armed}")
    check("missing sidecar: reported as UNAVAILABLE",
          any("UNAVAILABLE" in m for m in seen), f"{seen}")

    # (d) a sidecar from another session -> fail closed
    b, db, path, mon, entry, dec, loop, fclk = _assemble(now)
    csv = _write_csv([_cand("MU", **CAND)], path="e2e_regime.csv", regime=None)
    write_regime(regime_path_for(csv), session_date="2000-01-03",
                 screener="sp500_v21", vcp_threshold=_LIVE_VCP, benchmark="^GSPC",
                 regime_ma=20, benchmark_close=110.0, benchmark_ma=100.0,
                 bar_date="2000-01-02", log=lambda m: None)
    seen = _capture(loop)
    armed, _rej = loop.arm_today(csv)
    check("stale sidecar: arms nothing", armed == [], f"{armed}")
    check("stale sidecar: the reason says STALE", any("STALE" in m for m in seen), f"{seen}")

    # (e) an --emit-threshold degraded run must never arm
    b, db, path, mon, entry, dec, loop, fclk = _assemble(now)
    csv = _write_csv([_cand("MU", **CAND)], path="e2e_regime.csv", regime=None)
    write_regime(regime_path_for(csv), session_date=SESSION, screener="sp500_v21",
                 # PATCH T -- DERIVED. == 70.0 while live is 75, so this
                 # is a no-op here; it stops being a mismatch the day the
                 # live value reaches 70, which is P's bug exactly.
                 vcp_threshold=_LIVE_VCP - 5.0,
                 degraded_threshold=_LIVE_VCP - 5.0, benchmark="^GSPC",
                 regime_ma=20, benchmark_close=110.0, benchmark_ma=100.0,
                 bar_date=SESSION, log=lambda m: None)
    seen = _capture(loop)
    armed, _rej = loop.arm_today(csv)
    check("degraded run: arms nothing (supervised plumbing must never trade)",
          armed == [], f"{armed}")
    check("degraded run: the reason names emit-threshold",
          any("emit-threshold" in m for m in seen), f"{seen}")

    # (h) the screener emitted at a different bar than the trader expects
    b, db, path, mon, entry, dec, loop, fclk = _assemble(now)
    csv = _write_csv([_cand("MU", **CAND)], path="e2e_regime.csv", regime=None)
    write_regime(regime_path_for(csv), session_date=SESSION, screener="sp500_v21",
                 # PATCH T -- DERIVED, and BELOW live on purpose: a
                 # screener applying a LOWER bar than the trader is the
                 # dangerous direction, so the offset keeps its sign.
                 vcp_threshold=_LIVE_VCP - 5.0, benchmark="^GSPC",
                 regime_ma=20,
                 benchmark_close=110.0, benchmark_ma=100.0, bar_date=SESSION,
                 log=lambda m: None)
    seen = _capture(loop)
    armed, _rej = loop.arm_today(csv)
    check("threshold mismatch: arms nothing", armed == [], f"{armed}")
    check("threshold mismatch: the reason names the applied threshold",
          any("applied vcp_threshold" in m for m in seen), f"{seen}")

    # (i) the screener used a different regime window than this trader
    # PATCH F3: explicit, as in case (b) -- a mismatch check needs a gate to
    # mismatch against.
    b, db, path, mon, entry, dec, loop, fclk = _assemble(now)
    loop.exposure = ExposureController(ExposureConfig(regime_ma=20))
    csv = _write_csv([_cand("MU", **CAND)], path="e2e_regime.csv", regime=None)
    write_regime(regime_path_for(csv), session_date=SESSION, screener="sp500_v21",
                 vcp_threshold=_LIVE_VCP, benchmark="^GSPC", regime_ma=150,
                 benchmark_close=110.0, benchmark_ma=100.0, bar_date=SESSION,
                 log=lambda m: None)
    seen = _capture(loop)
    armed, _rej = loop.arm_today(csv)
    check("regime_ma mismatch: arms nothing (the file's MA is not this window)",
          armed == [], f"{armed}")
    check("regime_ma mismatch: the reason names both windows",
          any("regime_ma" in m and "150" in m for m in seen), f"{seen}")

    # (f) PATCH F2. regime_ma=None turns off the VERDICT, not the HANDSHAKE.
    # Before F2 this case asserted "arms even with NO sidecar", which also meant
    # arming on a stale sidecar, a --emit-threshold plumbing run, or a screener
    # that applied a different vcp_threshold. Those are screener-output faults,
    # not market verdicts, and they must stop the trader either way.
    b, db, path, mon, entry, dec, loop, fclk = _assemble(now)
    loop.exposure = ExposureController(ExposureConfig(regime_ma=None))
    csv = _write_csv([_cand("MU", **CAND)], path="e2e_regime.csv")
    seen = _capture(loop)
    armed, rej = loop.arm_today(csv)
    check("regime_ma=None + valid sidecar: arms (the verdict is off)",
          len(armed) == 1, f"{[r.reason for r in rej]}")

    # gate off, but NO sidecar at all -- the screener cannot be vouched for
    b, db, path, mon, entry, dec, loop, fclk = _assemble(now)
    loop.exposure = ExposureController(ExposureConfig(regime_ma=None))
    csv = _write_csv([_cand("MU", **CAND)], path="e2e_regime.csv", regime=None)
    seen = _capture(loop)
    armed, rej = loop.arm_today(csv)
    check("regime_ma=None + NO sidecar: still arms NOTHING", armed == [],
          f"{armed}")

    # gate off, sidecar present but the screener ran at a different threshold
    b, db, path, mon, entry, dec, loop, fclk = _assemble(now)
    loop.exposure = ExposureController(ExposureConfig(regime_ma=None))
    csv = _write_csv([_cand("MU", **CAND)], path="e2e_regime.csv", regime=None)
    write_regime(regime_path_for(csv), session_date=SESSION,
                 # PATCH P -- DERIVED, not a literal. 45.0 was chosen
                 # as "not 75" and stopped being a mismatch the moment
                 # the soak moved the live value to 45, so this check
                 # armed and failed. An offset can never collide.
                 screener="sp500_v21",
                 vcp_threshold=_LIVE_VCP + 10.0, benchmark="^GSPC",
                 regime_ma=20, benchmark_close=110.0, benchmark_ma=100.0,
                 bar_date=SESSION, log=lambda m: None)
    seen = _capture(loop)
    armed, rej = loop.arm_today(csv)
    check("regime_ma=None + threshold mismatch: still arms NOTHING",
          armed == [], f"{armed}")

    # PATCH F4. The case F2 and F3 broke between them: the gate is off AND the
    # sidecar is the one the SCREENER ACTUALLY WRITES in that mode -- regime_ma
    # null, no benchmark, handshake intact. This must ARM. Before F4 the
    # screener wrote no sidecar at all in this mode, so the trader blocked every
    # day and no unit test noticed, because every test built its own sidecar.
    b, db, path, mon, entry, dec, loop, fclk = _assemble(now)
    loop.exposure = ExposureController(ExposureConfig(regime_ma=None))
    csv = _write_csv([_cand("MU", **CAND)], path="e2e_regime.csv", regime=None)
    write_regime(regime_path_for(csv), session_date=SESSION,
                 # PATCH P -- single-sourced, same form as line 532.
                 # A literal 75.0 here becomes a MISMATCH at any other
                 # live value, which turns this ARM check into a
                 # handshake refusal for the wrong reason.
                 screener="sp500_v21", vcp_threshold=_LIVE_VCP,
                 benchmark="^GSPC",
                 regime_ma=None, benchmark_close=None, benchmark_ma=None,
                 bar_date=None, log=lambda m: None)
    seen = _capture(loop)
    armed, rej = loop.arm_today(csv)
    check("gate off + the screener's OWN null-regime sidecar: ARMS",
          len(armed) == 1, f"{[r.reason for r in rej]}")
    check("...and the reason does not claim the benchmark is unavailable",
          not any("benchmark unavailable" in m for m in seen), f"{seen}")


def test_e8_exposure_from_broker_truth():
    """§R3/D5. held_tickers came from broker truth while open_notional came from
    the LOCAL position list -- two gates, two sources -- so a holding the broker
    reports and we have no record of was invisible to the exposure ceiling. And
    an unreadable holdings read degraded to an EMPTY set, which fails open."""
    print("E8 exposure is measured from broker truth, and UNKNOWN is not flat")
    now = {"t": OPEN_UTC}
    CAND = dict(pivot=100.0, base_low=92.0, last_close=100.0)

    # (a) UNKNOWN holdings -> arm nothing, loudly
    b, db, path, mon, entry, dec, loop, fclk = _assemble(now)
    csv = _write_csv([_cand("MU", **CAND)], path="e2e_expo.csv")
    b._holdings_readable = False
    seen = _capture(loop)
    armed, _rej = loop.arm_today(csv)
    check("holdings UNREADABLE: arms nothing", armed == [], f"{armed}")
    check("holdings UNREADABLE: no order placed", b.place_calls == 0, f"{b.place_calls}")
    check("holdings UNREADABLE: escalated, and says why",
          any("UNREADABLE" in m and "ARM BLOCKED" in m for m in seen), f"{seen}")

    # (b) an orphan the broker reports counts against the ceiling
    b, db, path, mon, entry, dec, loop, fclk = _assemble(now)
    csv = _write_csv([_cand("MU", **CAND)], path="e2e_expo.csv")
    b._holdings = {"ZZZ": 500}          # no local record for ZZZ
    b._price["ZZZ"] = 200.0             # 500 x 200 = 100,000 of exposure
    seen = _capture(loop)
    acct = loop._account_state()
    check("orphan is priced into open_notional",
          acct is not None and abs(acct.open_notional - 100_000.0) < 1e-6,
          f"{acct.open_notional if acct else None}")
    check("orphan is NOT adopted as a managed position",
          all(p.ticker != "ZZZ" for p in loop.positions()),
          f"{[p.ticker for p in loop.positions()]}")
    check("orphan still appears in held_tickers (dedup unchanged)",
          "ZZZ" in acct.held_tickers, f"{acct.held_tickers}")

    # ... and that exposure actually binds the ceiling
    loop.decision = DecisionEngine(replace(loop.decision.cfg,
                                           max_portfolio_exposure_pct=0.5))
    seen = _capture(loop)
    armed, rej = loop.arm_today(csv)
    check("orphan exposure blocks a new entry that would breach the ceiling",
          armed == [] and any("exposure ceiling" in r.reason for r in rej),
          f"armed={armed} rej={[r.reason for r in rej]}")

    # (c) an orphan that cannot be priced -> refuse, naming it
    b, db, path, mon, entry, dec, loop, fclk = _assemble(now)
    csv = _write_csv([_cand("MU", **CAND)], path="e2e_expo.csv")
    b._holdings = {"NOPRICE": 10}
    b.get_quote = lambda t, ex="NAS": {"last": 0}      # zero == unusable
    seen = _capture(loop)
    armed, _rej = loop.arm_today(csv)
    check("unpriceable orphan: arms nothing", armed == [], f"{armed}")
    check("unpriceable orphan: the alert names the ticker",
          any("NOPRICE" in m for m in seen), f"{seen}")

    # (d) for a KNOWN ticker the broker's larger quantity wins
    b, db, path, mon, entry, dec, loop, fclk = _assemble(now)
    _write_csv([_cand("MU", **CAND)], path="e2e_expo.csv")
    pos = Position(ticker="MU", state=PositionState.FILLED, shares=10,
                   entry_price=50.0, stop_loss_price=45.0,
                   initial_risk_per_share=5.0, exchange="NAS",
                   order_key="MU:e8")
    loop._positions.append(pos)
    b._holdings = {"MU": 25}            # broker says 25, we recorded 10
    acct = loop._account_state()
    check("known ticker: the larger (broker) quantity is used",
          abs(acct.open_notional - 25 * 50.0) < 1e-6, f"{acct.open_notional}")

    # (e) a position the broker does not report yet is still counted
    b, db, path, mon, entry, dec, loop, fclk = _assemble(now)
    pos = Position(ticker="MU", state=PositionState.FILLED, shares=10,
                   entry_price=50.0, stop_loss_price=45.0,
                   initial_risk_per_share=5.0, exchange="NAS",
                   order_key="MU:e8b")
    loop._positions.append(pos)
    b._holdings = {}                    # pre-reconcile window
    acct = loop._account_state()
    check("pre-reconcile position still counts against exposure",
          abs(acct.open_notional - 500.0) < 1e-6, f"{acct.open_notional}")


def test_e9_orphan_alert_is_rate_limited():
    """§orphans are handled MANUALLY. The system counts them and tells the
    operator; it never invents a stop. One page per orphan per 6h."""
    print("E9 orphan alert: once per orphan per cooldown, with the right exchange")
    now = {"t": OPEN_UTC}

    b, db, path, mon, entry, dec, loop, fclk = _assemble(now)
    b._holdings = {"ZZZ": 500}
    b._price["ZZZ"] = 198.40
    seen = _capture(loop)

    loop._account_state()
    hits = [m for m in seen if "ORPHAN ZZZ" in m]
    check("first sighting alerts exactly once", len(hits) == 1, f"{len(hits)}")
    if hits:
        m = hits[0]
        check("names the quantity and the last price", "500 sh" in m and "198.40" in m, m)
        check("states plainly that it is NOT managed",
              "NOT managed" in m and "no stop" in m, m)
        check("carries the seed command with an explicit --exchange",
              "kistrader seed --ticker ZZZ" in m and "--exchange" in m, m)
        check("leaves the two unknowable fields blank",
              "<FILL>" in m and "<FROM CHART>" in m, m)
        # severity is asserted properly in test_e10 against notifier.classify()

    # a second look in the same session must NOT re-page
    seen.clear()
    loop._account_state()
    check("second look inside the cooldown does not re-alert",
          not [m for m in seen if "ORPHAN ZZZ" in m], f"{seen}")

    # ... but it does once the cooldown has elapsed
    loop._orphan_alerted["ZZZ"] -= (ORPHAN_ALERT_COOLDOWN_SECS + 1)
    seen.clear()
    loop._account_state()
    check("alerts again after the cooldown elapses",
          len([m for m in seen if "ORPHAN ZZZ" in m]) == 1, f"{seen}")

    # two orphans are tracked independently
    b._holdings = {"ZZZ": 500, "QQQ": 10}
    b._price["QQQ"] = 50.0
    seen.clear()
    loop._account_state()
    check("a second orphan alerts on its own schedule",
          [m for m in seen if "ORPHAN QQQ" in m] and
          not [m for m in seen if "ORPHAN ZZZ" in m], f"{seen}")

    # once it is gone the timer is dropped, so a REAPPEARING orphan pages at once
    b._holdings = {}
    loop._account_state()
    check("cooldown entries are pruned when the holding disappears",
          loop._orphan_alerted == {}, f"{loop._orphan_alerted}")
    b._holdings = {"ZZZ": 500}
    seen.clear()
    loop._account_state()
    check("a reappearing orphan alerts immediately, not after the old timer",
          len([m for m in seen if "ORPHAN ZZZ" in m]) == 1, f"{seen}")

    # a SEEDED position is not an orphan and must never page
    b, db, path, mon, entry, dec, loop, fclk = _assemble(now)
    b._holdings = {"MU": 10}
    loop._positions.append(Position(
        ticker="MU", state=PositionState.FILLED, shares=10, entry_price=50.0,
        stop_loss_price=45.0, initial_risk_per_share=5.0, exchange="NAS",
        order_key="MU:e9"))
    seen = _capture(loop)
    loop._account_state()
    check("a position with a local record is not an orphan",
          not [m for m in seen if "ORPHAN" in m], f"{seen}")


def test_e10_alert_severity_contract():
    """§the alerts that BLOCK TRADING must reach the phone.

    notifier.classify() decides severity from MESSAGE TEXT, and only CRITICAL
    pushes. Nothing tested that boundary before, so a phrase carried the routing
    for two phases without anyone noticing. This pins pipeline's wording to the
    notifier's rule; reword either side and it fails here rather than in
    production, silently, on the day it matters."""
    print("E10 alert severity: what actually reaches the phone")
    try:
        from kistrader.notifier import classify
    except ImportError as e:
        check("kistrader.notifier importable", False, str(e)); return

    now = {"t": OPEN_UTC}
    CAND = dict(pivot=100.0, base_low=92.0, last_close=100.0)

    def worst(seen):
        return "CRITICAL" if any(classify(m) == "CRITICAL" for m in seen) else "quiet"

    def arm(regime, extra=None):
        b, db, path, mon, entry, dec, loop, fclk = _assemble(now)
        csv = _write_csv([_cand("MU", **CAND)], path="e2e_sev.csv", regime=regime)
        if extra:
            extra(csv, loop, b)
        seen = _capture(loop)
        loop.arm_today(csv)
        return seen

    # a normal no-trade day must NOT buzz -- a quiet phone is the design goal
    check("risk_off day stays quiet (log only)", worst(arm("risk_off")) == "quiet")

    # every fault that stops trading MUST buzz
    check("missing sidecar pushes", worst(arm(None)) == "CRITICAL")

    def _stale(csv, _loop, _b):
        write_regime(regime_path_for(csv), session_date="2000-01-03",
                     screener="sp500_v21", vcp_threshold=_LIVE_VCP, benchmark="^GSPC",
                     regime_ma=20, benchmark_close=110.0, benchmark_ma=100.0,
                     bar_date="2000-01-02", log=lambda m: None)
    check("stale sidecar pushes", worst(arm(None, _stale)) == "CRITICAL")

    def _degraded(csv, _loop, _b):
        write_regime(regime_path_for(csv), session_date=SESSION, screener="sp500_v21",
                     # PATCH T -- see the note at case (e).
                     vcp_threshold=_LIVE_VCP - 5.0,
                     degraded_threshold=_LIVE_VCP - 5.0,
                     benchmark="^GSPC",
                     regime_ma=20, benchmark_close=110.0, benchmark_ma=100.0,
                     bar_date=SESSION, log=lambda m: None)
    check("--emit-threshold degraded run pushes", worst(arm(None, _degraded)) == "CRITICAL")

    def _unreadable(_csv, _loop, b):
        b._holdings_readable = False
    check("unreadable holdings pushes", worst(arm("risk_on", _unreadable)) == "CRITICAL")

    # the orphan alert routes on the phrase "no local record", NOT on any level
    # prefix -- classify() ignores the word CRITICAL entirely.
    b, db, path, mon, entry, dec, loop, fclk = _assemble(now)
    b._holdings = {"ZZZ": 500}
    b._price["ZZZ"] = 198.40
    seen = _capture(loop)
    loop._account_state()
    orphan = [m for m in seen if "ORPHAN ZZZ" in m]
    check("orphan alert is classified CRITICAL",
          bool(orphan) and classify(orphan[0]) == "CRITICAL",
          f"{[classify(m) for m in orphan]}")
    check("...because of the phrase 'no local record', which is load-bearing",
          bool(orphan) and "no local record" in orphan[0].lower(), f"{orphan}")
    check("a bare 'CRITICAL' prefix would NOT route (it is not a token)",
          classify("CRITICAL something bland") == "WARN",
          classify("CRITICAL something bland"))


def _streak_close(db, key, r=-1.0, provenance="ENTRY_ARMED", partial=False):
    """Write ONE closed trade into the event store the loop actually reads.

    `provenance` is the layer-2b allowlist marker: an ENTRY_ event means the
    strategy made this trade. None writes no marker at all (unknown
    provenance); "SEEDED_ENTRY_ARMED:manual" is what seed_position writes.
    """
    import json
    entry, risk, tkr = 100.0, 10.0, key.split(":")[0]
    ins = ("INSERT INTO position_events (ticker, order_key, event_type, "
           "state_to, shares, price, broker_order_id, payload) "
           "VALUES (?,?,?,?,?,?,?,?)")
    if provenance:
        db.conn.execute(ins, (tkr, key, provenance, "FILLED", 0, entry, None, None))
    # Serialised through the REAL Position, not a hand-built dict: recovery
    # deserialises every payload on start(), so a hand-built one both crashes
    # load_open_snapshots and lets the Position schema drift away from what
    # this fixture claims a close looks like.
    pos = Position(ticker=tkr, state=PositionState.CLOSED, shares=0,
                   entry_price=entry, stop_loss_price=entry - risk,
                   initial_risk_per_share=risk, order_key=key,
                   partial_done=partial)
    db.conn.execute(ins, (tkr, key, "CLOSED:STOP_HIT", "CLOSED", 0,
                          entry + r * risk, None, json.dumps(pos.to_dict())))
    db.conn.commit()


def _streak_setup(now, ceilings, losses=0, seeded=None, unknown=0):
    """A loop with the progressive-exposure gate configured, a seeded history,
    and FOUR candidates. Four is deliberate: each is 20,100 of notional against
    100,000 of equity, so the ceiling lands on a DIFFERENT arm count at every
    rung -- 1.00 -> 4 armed, 0.50 -> 2, 0.25 -> 1. A ladder that is monotone
    and distinct is what proves the number reached plan() rather than merely
    being computed and dropped."""
    b, db, path, mon, entry, dec, loop, fclk = _assemble(now)
    loop.exposure = ExposureController(ExposureConfig(loss_streak_ceilings=ceilings))
    for i in range(losses):
        _streak_close(db, f"L{i}:2026-07-0{i + 1}", r=-1.0)
    if seeded is not None:                      # newest: a seeded WINNER
        _streak_close(db, "SEED:2026-07-06", r=seeded,
                      provenance="SEEDED_ENTRY_ARMED:manual")
    for i in range(unknown):
        _streak_close(db, f"U{i}:2026-07-06", r=-1.0, provenance=None)
    cands = [_cand(t, pivot=100.0, base_low=92.0, last_close=100.0)
             for t in ("AAA", "BBB", "CCC", "DDD")]
    csv = _write_csv(cands, path="e2e_streak.csv", regime="risk_on")
    return b, db, loop, csv


def test_e11_progressive_exposure():
    """E10 layers 1/2/2b -- the TIMING half.

    Layer 1 proved the arithmetic and layer 2's verify proved the read against
    the box's real store. Neither could show that `arm_today` calls the read at
    the right moment, that `self.mon.db` is the right object at runtime, that
    the LOSS_STREAK alert renders in a session, or that the ceiling reaches
    plan(). Those are what this block is for, and only a driven loop shows them.

    THE LADDER IS THE PROOF. Four candidates at 20,100 each against 100,000 of
    equity: ceiling 1.00 -> 4 armed, 0.50 -> 2, 0.25 -> 1. Each rung produces a
    different, observable arm count, so a ceiling that was computed but never
    written would fail here even though every unit check still passed.

    Sabotage-measured 2026-09-20: dropping `loss_streak=` from the decide()
    call turns 7 of these red; disabling the 2b provenance filter turns 4 red,
    reproducing the box's seeded-position defect exactly."""
    from kistrader.notifier import classify
    from kistrader.entry.exposure_controller import DEFAULT_LOSS_STREAK_CEILINGS
    print("E11 progressive exposure: our own closed trades write the ceiling")
    now = {"t": OPEN_UTC}
    RUNGS = DEFAULT_LOSS_STREAK_CEILINGS

    # (a) THE SHIPPED DEFAULT. Gate off -> unchanged, and the store is never
    # read. A counter, not an assertion about intent: with the gate off the
    # tree must make no extra database call at all.
    b, db, loop, csv = _streak_setup(now, ceilings=None, losses=3)
    calls = []
    _real = db.recent_closed_r
    db.recent_closed_r = lambda *a, **k: (calls.append(1), _real(*a, **k))[1]
    seen = _capture(loop)
    armed, rej = loop.arm_today(csv)
    check("gate OFF (shipped default): all four arm despite 3 real losses",
          len(armed) == 4, f"{len(armed)} {[r.reason for r in rej]}")
    check("gate OFF: the event store is never read", calls == [], f"{calls}")
    check("gate OFF: no progressive-exposure alert",
          not any("progressive exposure" in m for m in seen), f"{seen}")

    # (b) 1 loss -> the gate is SILENT. It must not bite before its first rung.
    b, db, loop, csv = _streak_setup(now, ceilings=RUNGS, losses=1)
    seen = _capture(loop)
    armed, rej = loop.arm_today(csv)
    check("streak 1: gate silent, all four arm", len(armed) == 4,
          f"{len(armed)} {[r.reason for r in rej]}")
    check("streak 1: nothing announced",
          not any("progressive exposure" in m for m in seen), f"{seen}")

    # (c) 2 losses -> ceiling 0.50. The ladder's first rung, and the arm count
    # is what shows the number arrived at plan().
    b, db, loop, csv = _streak_setup(now, ceilings=RUNGS, losses=2)
    seen = _capture(loop)
    armed, rej = loop.arm_today(csv)
    check("streak 2 -> ceiling 50%: exactly two arm", len(armed) == 2,
          f"{len(armed)} {[r.reason for r in rej]}")
    check("streak 2: the rejection names the exposure ceiling",
          bool(rej) and all("exposure ceiling" in r.reason for r in rej),
          f"{[r.reason for r in rej]}")
    check("streak 2: announced, with the count and the ceiling",
          any("progressive exposure" in m and "2 consecutive losing" in m
              and "50%" in m for m in seen),
          f"{[m for m in seen if 'progressive' in m]}")

    # (d) 3 losses -> ceiling 0.25. The deeper rung must bind HARDER, not the
    # same: identical arm counts here would pass a gate that ignored the rung.
    b, db, loop, csv = _streak_setup(now, ceilings=RUNGS, losses=3)
    seen = _capture(loop)
    armed, rej = loop.arm_today(csv)
    check("streak 3 -> ceiling 25%: exactly one arms", len(armed) == 1,
          f"{len(armed)} {[r.reason for r in rej]}")
    check("streak 3: announced at 25%",
          any("progressive exposure" in m and "25%" in m for m in seen),
          f"{[m for m in seen if 'progressive' in m]}")
    # Normal operation on a bad run, not a fault: it must NOT reach the phone,
    # and it must NOT carry the ARM BLOCKED phrase that routes a CRITICAL.
    check("streak 3: the alert is WARN, not a phone push",
          all(classify(m) == "WARN"
              for m in seen if "progressive exposure" in m),
          f"{[(classify(m), m) for m in seen if 'progressive exposure' in m]}")
    check("streak 3: arming is LIMITED, never BLOCKED",
          not any("ARM BLOCKED" in m for m in seen), f"{seen}")
    # The ceiling is built per call. Written back onto the shared config, a bad
    # run would clamp every future session, silently and for good.
    check("streak 3: the shared DecisionConfig was NOT mutated",
          loop.decision.cfg.max_portfolio_exposure_pct == 1.0,
          f"{loop.decision.cfg.max_portfolio_exposure_pct}")

    # (e) 2b, end to end: a SEEDED WINNER sits newest in the store. Unfiltered
    # it would end the streak and restore the full ceiling. This is the defect
    # found on the box (HPE:2026-08-20), driven through a real arm.
    b, db, loop, csv = _streak_setup(now, ceilings=RUNGS, losses=3, seeded=+2.0)
    seen = _capture(loop)
    armed, rej = loop.arm_today(csv)
    check("2b: a seeded WINNER does not restore the ceiling", len(armed) == 1,
          f"{len(armed)} {[r.reason for r in rej]}")
    check("2b: the skip is reported, never silent",
          any("manually seeded" in m for m in seen),
          f"{[m for m in seen if 'loss-streak' in m]}")
    check("2b: a seed skip is WARN (routine), not a push",
          all(classify(m) == "WARN" for m in seen if "manually seeded" in m),
          f"{[(classify(m), m) for m in seen if 'manually seeded' in m]}")

    # (f) 2b: a close with NEITHER marker. A code path nobody registered, or a
    # pruned log. Both change what the gate is doing, so this one pushes.
    b, db, loop, csv = _streak_setup(now, ceilings=RUNGS, losses=3, unknown=1)
    seen = _capture(loop)
    armed, rej = loop.arm_today(csv)
    check("2b: unknown provenance is reported",
          any("UNKNOWN provenance" in m for m in seen),
          f"{[m for m in seen if 'loss-streak' in m]}")
    check("2b: unknown provenance PUSHES (manual check)",
          any(classify(m) == "CRITICAL" for m in seen if "UNKNOWN provenance" in m),
          f"{[(classify(m), m) for m in seen if 'UNKNOWN' in m]}")

    # (g) FAIL CLOSED. The gate is on and the read throws: no streak, so the
    # gate cannot evaluate, so nothing arms. A survival gate is not exempt.
    b, db, loop, csv = _streak_setup(now, ceilings=RUNGS, losses=3)
    def _boom(*a, **k):
        raise RuntimeError("event store unreadable")
    db.recent_closed_r = _boom
    seen = _capture(loop)
    armed, rej = loop.arm_today(csv)
    check("read throws -> arms NOTHING (fail closed)", armed == [], f"{armed}")
    check("read throws -> no broker order", b.place_calls == 0, f"{b.place_calls}")
    check("read throws -> the cause is named",
          any("loss-streak read error" in m for m in seen), f"{seen}")
    check("read throws -> it PUSHES (a silent halt is worth a phone call)",
          any(classify(m) == "CRITICAL" for m in seen
              if "loss-streak read error" in m),
          f"{[(classify(m), m) for m in seen if 'read error' in m]}")
    check("read throws -> ARM BLOCKED, so it cannot be missed in the log",
          any("ARM BLOCKED" in m for m in seen), f"{seen}")


def test_zz_all_checks_passed():
    """D8 terminal guard. check() never raises, so without this pytest reports
    every function in this file as passed no matter how many checks failed.
    Defined last on purpose: pytest runs file order, so this sees the whole run.
    Harmless under the direct `python tests/...` run, which main() drives."""
    assert not FAIL, f"{len(FAIL)} failed check(s): " + "; ".join(FAIL)


def main():
    print("=" * 62); print("PIPELINE END-TO-END INTEGRATION TESTS"); print("=" * 62)
    test_e1_full_lifecycle()
    test_e2_recovery_routing()
    test_e3_on_close_wiring()
    test_e4_auto_arm()
    test_e5_exit_alerts()
    test_e6_freshness_gate()
    test_e7_regime_gate()
    test_e8_exposure_from_broker_truth()
    test_e9_orphan_alert_is_rate_limited()
    test_e10_alert_severity_contract()
    test_e11_progressive_exposure()
    print("=" * 62)
    print(f"PASSED {len(PASS)} / {len(PASS) + len(FAIL)}")
    if FAIL:
        print("FAILED:", ", ".join(FAIL))
    print("=" * 62)
    return 1 if FAIL else 0


if __name__ == "__main__":
    sys.exit(main())
