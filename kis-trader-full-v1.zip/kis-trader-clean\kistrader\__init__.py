"""KIS Minervini/VCP trading system."""
__version__ = "0.1.0"
