"""Build a deliberate VCP base and prove the whole chain emits a real candidate."""
import numpy as np, pandas as pd
import vcp_engine as ve
from signals import PITBars, generate_signals, constant_universe
from minervini_backtest import BacktestConfig, run

DATES = pd.bdate_range("2021-01-04", periods=760)


def bars_from_close(c, seed=0, vols=None):
    r = np.random.default_rng(seed)
    c = np.asarray(c, float)
    o = np.r_[c[0], c[:-1]]
    h = np.maximum(o, c) * (1 + abs(r.normal(0, .003, len(c))))
    l = np.minimum(o, c) * (1 - abs(r.normal(0, .003, len(c))))
    v = vols if vols is not None else r.integers(8e5, 2e6, len(c)).astype(float)
    return pd.DataFrame({"Open": o, "High": h, "Low": l, "Close": c,
                         "Volume": np.asarray(v, float)}, index=DATES[:len(c)])


def vcp_close_series(n=760):
    """Long advance, then a base of CONTRACTING pullbacks into a pivot."""
    r = np.random.default_rng(3)
    n_base = 70
    n_up = n - n_base
    # steady primary uptrend with noise -> satisfies the trend template
    up = 20 * np.cumprod(1 + r.normal(0.0026, 0.009, n_up))
    peak = up[-1]
    # three contractions: -18%, -9%, -4%, each recovering toward the pivot
    base = []
    for depth, half in ((0.18, 14), (0.09, 12), (0.04, 9)):
        down = np.linspace(peak, peak * (1 - depth), half)
        upleg = np.linspace(peak * (1 - depth), peak * 0.995, half)
        base.extend(down.tolist() + upleg.tolist())
    base = base[:n_base]
    while len(base) < n_base:
        base.append(peak * 0.995)
    return np.r_[up, np.asarray(base)]


def vcp_volumes(n=760):
    """Volume dries up through the base -- stage 6 of the engine looks for this."""
    r = np.random.default_rng(4)
    n_base = 70
    up = r.integers(15e5, 25e5, n - n_base).astype(float)
    dry = np.linspace(1.0, 0.35, n_base) * 18e5 * (1 + r.normal(0, .08, n_base))
    return np.r_[up, dry]


def main():
    close = vcp_close_series()
    bars = {"VCPX": bars_from_close(close, seed=1, vols=vcp_volumes())}
    # laggard peers so the RS percentile has something to rank against
    for i in range(8):
        r = np.random.default_rng(50 + i)
        c = 30 * np.cumprod(1 + r.normal(0.0002 + i * 3e-5, 0.014, len(DATES)))
        bars[f"LAG{i}"] = bars_from_close(c, seed=60 + i)
    r = np.random.default_rng(9)
    bars["^GSPC"] = bars_from_close(
        3800 * np.cumprod(1 + r.normal(0.0004, 0.008, len(DATES))), seed=9)

    T = DATES[len(close) - 1]
    server = PITBars(bars); server.set_date(T); ve.set_fetcher(server.fetch)

    # --- Stage 1 ---
    res = ve.check_minervini_technicals("VCPX")
    print(f"Stage 1 VCPX: structural_pass={res[0]}  status={res[5]!r}  "
          f"price={res[1]}  raw_rs={res[4]}")

    raw = {}
    for t in bars:
        if t == "^GSPC":
            continue
        rr = ve.check_minervini_technicals(t)
        if rr[4] is not None:
            raw[t] = rr[4]
    ratings = ve.compute_rs_ratings(raw)
    print(f"RS ratings: {dict(sorted(ratings.items(), key=lambda kv: -kv[1]))}")

    # --- Stage 3 ---
    df = server.fetch("VCPX", "2y")
    rep = ve.VCPAnalyzerV4(df, index_df=server.fetch("^GSPC", "2y"),
                           config=ve.VCPConfig()).generate_report()
    if rep:
        pat = rep["Extracted_Pattern"]
        print("VCP report:", {k: rep.get(k) for k in ("Score", "Grade", "Trade_Signal_Active")})
        print("  pattern:", {k: pat.get(k) for k in ("Pivot", "Latest_Close", "Latest_ATR", "Base_Low")})
        print("  Wave_Highs:", pat.get("Wave_Highs"), "Wave_Lows:", pat.get("Wave_Lows"))
    else:
        print("VCP report: None")

    # --- full signal pass + backtest ---
    scan = DATES[700:len(close):5]
    sigs = generate_signals(bars, scan, constant_universe([t for t in bars if t != "^GSPC"]),
                            emit_threshold=0.0)
    total = sum(len(v) for v in sigs.values())
    print(f"\nsignals emitted: {total} across {len(sigs)} date(s)")
    if total:
        d0 = sorted(sigs)[0]; c0 = sigs[d0][0]
        print(f"  sample: {c0.ticker} score={c0.vcp_score} rs={c0.rs_rating} "
              f"pivot={c0.pivot} contraction_low={c0.contraction_low} atr={c0.atr}")
        px = {t: d for t, d in bars.items() if t != "^GSPC"}
        cfg = BacktestConfig(rank_mode="rs_only",
                             sector_map={t: "Tech" for t in px},
                             vcp_threshold=0.0, slippage_bps=5.0)
        eq, tr, st, dr, dg = run(px, sigs, cfg)
        print(f"  BACKTEST: {st['num_trades']} trade(s), end ${st['end_equity']:,.2f}, "
              f"expectancy_R={st['expectancy_R']}, exits={st['exit_reasons']}")
        print(f"  drops: {dg['drops_by_reason']}")
    return total


if __name__ == "__main__":
    n = main()
    print("\nEMITTED A REAL CANDIDATE" if n else "\nNO CANDIDATE -- see diagnostics above")
