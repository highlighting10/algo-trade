"""
03d_asof.py -- WHICH AS-OF DATE produced the seed-doc scores?

Two hypotheses have already been falsified:
  * corporate actions rescaling adjusted history  -> zero actions on all ten
  * window length (tail(N) vs calendar 2y)        -> IRDM matches at EVERY length,
                                                     nine match at none

So stop testing one idea at a time and scan the space. The untested axis is the
as-of date itself. A nightly screener run labelled "2026-08-05" may have used data
through 2026-08-04's close, or through an intraday quote on the 5th, depending on
when the box actually ran it.

This sweeps as-of date x window mode and reports which combination reproduces the
known scores. IRDM is expected to match everywhere -- it is window-invariant, so
it cannot discriminate. The other nine are the informative ones.

Usage:
    python scripts/03d_asof.py
    python scripts/03d_asof.py --back 20
"""
import pathlib as _pl
import sys as _sys
_sys.path.insert(0, str(_pl.Path(__file__).resolve().parent.parent))

import argparse
import pathlib
from collections import Counter

import pandas as pd

import vcp_engine as ve
from signals import VCP_BENCHMARK

EXPECTED = {
    "NTAP": 73.55, "UNH": 67.58, "NUE": 59.83, "STT": 58.64, "HPE": 58.25,
    "BRKR": 72.00, "PTGX": 62.54, "IRDM": 58.66, "OKTA": 58.29, "LFST": 57.07,
}
TOL = 0.01
ANCHOR = pd.Timestamp("2026-08-05")


def load(t):
    p = pathlib.Path(f"data/bars/{t}.parquet")
    if not p.exists():
        return None
    df = pd.read_parquet(p).sort_index()
    if getattr(df.index, "tz", None) is not None:
        df.index = df.index.tz_localize(None)
    return df


def score(df, idx_df, T, mode, n=504):
    w = df.loc[:T]
    i = idx_df.loc[:T]
    if mode == "calendar":
        w = w.loc[w.index >= T - pd.DateOffset(years=2)]
        i = i.loc[i.index >= T - pd.DateOffset(years=2)]
    else:
        w, i = w.tail(n), i.tail(n)
    if len(w) < 60:
        return None, None, None
    try:
        rep = ve.VCPAnalyzerV4(w, index_df=i, config=ve.VCPConfig()).generate_report()
    except Exception:
        return None, None, None
    if not rep:
        return None, None, None
    pat = rep.get("Extracted_Pattern") or {}
    return rep.get("Score"), pat.get("Base_Start_Bar"), pat.get("Wave_Count")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--back", type=int, default=15, help="sessions before the anchor")
    ap.add_argument("--fwd", type=int, default=3, help="sessions after the anchor")
    args = ap.parse_args()

    idx_df = load(VCP_BENCHMARK)
    if idx_df is None:
        raise SystemExit("[asof] no ^GSPC bars")
    bars = {t: load(t) for t in EXPECTED}
    bars = {t: d for t, d in bars.items() if d is not None}
    if not bars:
        raise SystemExit("[asof] no gate-ticker bars")

    cal = idx_df.index
    if ANCHOR in cal:
        pos = cal.get_loc(ANCHOR)
    else:
        pos = cal.searchsorted(ANCHOR) - 1
    lo = max(0, pos - args.back)
    hi = min(len(cal) - 1, pos + args.fwd)
    dates = list(cal[lo:hi + 1])
    print(f"[asof] anchor {ANCHOR.date()}, sweeping {dates[0].date()} .. "
          f"{dates[-1].date()} ({len(dates)} session(s)) x 2 window mode(s)\n")

    grid = {}
    for mode in ("calendar", "sessions"):
        for T in dates:
            n_ok, who = 0, []
            for t, df in bars.items():
                sc, _, _ = score(df, idx_df, T, mode)
                if sc is not None and abs(sc - EXPECTED[t]) <= TOL:
                    n_ok += 1
                    who.append(t)
            grid[(mode, T)] = (n_ok, who)

    print("=" * 76)
    print(f"{'as-of':<12} {'calendar':>10} {'sessions':>10}   matched tickers (calendar)")
    print("=" * 76)
    for T in dates:
        c, cw = grid[("calendar", T)]
        s, _ = grid[("sessions", T)]
        star = "  <<<" if max(c, s) >= 5 else ""
        print(f"{str(T.date()):<12} {c:>10} {s:>10}   {','.join(cw) if cw else '-'}{star}")

    best_key = max(grid, key=lambda k: grid[k][0])
    best_n, best_who = grid[best_key]
    print("\n" + "=" * 76)
    print(f"BEST: {best_key[0]} window, as-of {best_key[1].date()} "
          f"-> {best_n}/{len(bars)} reproduced")
    print("=" * 76)

    # Threshold reasoning: N simultaneous matches to 0.01 across independent
    # price series is not something that happens by chance. Requiring near-perfect
    # agreement mislabels a strong result as ambiguous -- 8/10 at ONE date with
    # 0/10 at thirteen others is a conclusive localisation.
    if best_n >= max(3, int(0.7 * len(bars))):
        print(f"  CONCLUSIVE. {best_n}/{len(bars)} exact matches at a single date,")
        print(f"  against 0 at most others. Set the gate as-of to "
              f"{best_key[1].date()}, period_mode='{best_key[0]}'.")
        missed = [t for t in bars if t not in best_who]
        if missed:
            print(f"  Still unexplained: {missed} -- diagnose separately with 03e,")
            print("  do NOT widen the tolerance to absorb them.")
        print()
        print("  READ THIS: the labelled run date and the effective DATA date differ.")
        print("  If the box systematically screens on stale bars, the backtest is")
        print("  currently giving the strategy FRESHER data than production has --")
        print("  a look-ahead advantage. See the note in RUN_ORDER.")
    elif best_n <= 2:
        never = Counter()
        for (m, T), (n, who) in grid.items():
            for t in who:
                never[t] += 1
        dead = [t for t in bars if never[t] == 0]
        print("  INCONCLUSIVE -- no as-of date reproduces the set.")
        print(f"  Reproduced at SOME point: {sorted(never)}")
        print(f"  Reproduced NOWHERE:       {dead}")
        print()
        print("  That points away from timing and toward the DATA ITSELF. The next")
        print("  discriminator is a direct price comparison: pick one failing ticker,")
        print("  read its Latest_Close from the box's own logs/candidates.csv for")
        print("  2026-08-05, and compare against your stored bar for that date.")
        print("  If the closes differ, the bars differ and no amount of window or")
        print("  date tuning will fix it -- the box's yfinance returned different")
        print("  numbers than yours does now.")
    else:
        print("  PARTIAL. Some names reproduce, others do not -- so timing explains")
        print("  part of it but not all. Do NOT adopt this date as 'the' answer.")


if __name__ == "__main__":
    main()
