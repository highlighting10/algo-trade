#!/usr/bin/env python3
"""
test_candidate_emit.py — offline contract test for the Step-3 emitter.
=====================================================================

No network, no pandas, no broker: synthetic Stage-1/2/3 outputs + a fake
tradable universe drive candidate_emit.emit_candidates() end-to-end into a real
CSV, which is then read back through screen_contract.read_candidates() — the
exact code path pipeline.arm_today() uses. Covers:

  * field round-trip fidelity (schema v3, close_known/trade_signal/contraction_low)
  * KIS slash-symbology fallback (BRK-B -> BRK/B)
  * every fail-closed drop: not-tradable, no RS, no Stage-2 score, bad geometry
  * §1.6-absence behavior: missing Latest_Close -> close_known=0 (emitted, engine
    fails closed downstream); missing Latest_ATR -> atr=0.0 (structural-only stop)
  * VCP threshold + failed-report exclusion
  * cross-screener same-date merge, ticker replacement, stale-date purge
  * zero-final runs still rewrite the file (freshness guarantee) without
    touching the real TradableUniverse import

Run:  python tests/test_candidate_emit.py        (or via pytest)
"""
from __future__ import annotations

import os
import sys
import tempfile

# Self-locating AND shadow-proof. Two separate problems, both measured:
#  1. `kistrader` and `screeners` are not installed packages (pyproject
#     packages.find includes only kistrader*), so a DIRECT run -- sys.path[0] is
#     tests/ -- cannot import either. pytest happens to work because pyproject
#     sets pythonpath = [".", "tests"].
#  2. kis-backtest ships a partial COPY of kistrader/. Run pytest from the parent
#     directory and it collects both projects; whichever imports first wins
#     sys.modules, and after that sys.path is irrelevant -- Python never
#     re-resolves an imported package. That produced five collection errors
#     naming the wrong repo.
import os as _os, sys as _sys
_ROOT = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))
for _p in (_os.path.join(_ROOT, "screeners"), _ROOT):
    while _p in _sys.path:
        _sys.path.remove(_p)                 # move to the FRONT, not merely present
    _sys.path.insert(0, _p)
_k = _sys.modules.get("kistrader")
_kf = _os.path.abspath(getattr(_k, "__file__", "") or "") if _k is not None else ""
if _k is not None and not _kf.startswith(_ROOT + _os.sep):
    print(f"[path] evicting a foreign kistrader loaded from {_kf!r}; "
          f"this suite tests {_ROOT!r}")
    for _m in [_m for _m in list(_sys.modules)
               if _m == "kistrader" or _m.startswith("kistrader.")]:
        del _sys.modules[_m]

from kistrader.entry.screen_contract import read_candidates          # noqa: E402
from candidate_emit import emit_candidates                           # noqa: E402


# ---------------------------------------------------------------- helpers ----

class FakeUniverse:
    """Duck-typed stand-in for kistrader.core.kis_tradable_universe."""
    def __init__(self, mapping):
        self.mapping = {k.upper(): v for k, v in mapping.items()}
        self.ensured = False

    def ensure(self):
        self.ensured = True

    def resolve(self, ticker):
        return self.mapping.get(str(ticker).upper())


UNIVERSE = FakeUniverse({"AAPL": "NAS", "XOM": "NYS", "BRK/B": "NYS", "SNDK": "NAS"})


def rep(score=88, pivot=100.0, base_high=100.0, base_low=90.0,
        wave_lows=(92.0, 94.0), close=99.0, atr=2.0, signal=True, omit=()):
    """Fabricate a VCPAnalyzerV4.generate_report()-shaped dict (§1.6-patched
    unless keys are listed in `omit`)."""
    ep = {"Pivot": pivot, "Base_High": base_high,
          "Wave_Lows": list(wave_lows), "Wave_Highs": [base_high]}
    if "Base_Low" not in omit:
        ep["Base_Low"] = base_low
    if "Latest_Close" not in omit:
        ep["Latest_Close"] = close
    if "Latest_ATR" not in omit:
        ep["Latest_ATR"] = atr
    return {"Score": score, "Grade": "test", "Trade_Signal_Active": signal,
            "Extracted_Pattern": ep}


def s1(ticker, rs, name=None):
    """A passed_stocks row: (t, n, ret, cp, h20, rs, raw)."""
    return (ticker, name or ticker + " Inc", 0.25, 100.0, 99.0, rs, 1.23)


def emit(path, stage3, s1_rows, s2_rows, date="2026-07-16", source="test",
         universe=UNIVERSE, quiet=True):
    logs = []
    n = emit_candidates(stage3_results=stage3, passed_stocks=s1_rows,
                        stage2_passed=s2_rows, out_path=path,
                        vcp_threshold=80, session_date=date, universe=universe,
                        source=source, log=logs.append)
    if not quiet:
        print("\n".join(logs))
    return n, logs


def tmpcsv():
    fd, path = tempfile.mkstemp(suffix=".csv")
    os.close(fd)
    os.remove(path)            # emitter must handle a not-yet-existing path
    return path


# ------------------------------------------------------------------ tests ----

def test_happy_roundtrip():
    path = tmpcsv()
    n, logs = emit(path,
                   stage3=[("AAPL", "Apple", rep(score=91, signal=True))],
                   s1_rows=[s1("AAPL", 95)],
                   s2_rows=[("AAPL", "Apple", 72.5)])
    assert n == 1, logs
    cands = read_candidates(path, on_bad=lambda r, w: (_ for _ in ()).throw(AssertionError(w)))
    assert len(cands) == 1
    c = cands[0]
    assert (c.ticker, c.exchange, c.rs_proxy) == ("AAPL", "NAS", 95)
    assert c.stage2_score == 72.5 and c.vcp_score == 91
    assert c.pivot == 100.0 and c.base_high == 100.0 and c.base_low == 90.0
    assert abs(c.depth_pct - 0.10) < 1e-9
    assert c.last_close == 99.0 and c.close_known is True
    assert c.atr == 2.0 and c.trade_signal is True
    assert c.session_date == "2026-07-16" and c.schema_version == 4
    assert c.contraction_low == 94.0        # Wave_Lows[-1] -- the v3 stop anchor
    os.remove(path)


def test_slash_normalization():
    path = tmpcsv()
    n, logs = emit(path, stage3=[("BRK-B", "Berkshire B", rep())],
                   s1_rows=[s1("BRK-B", 88)], s2_rows=[("BRK-B", "Berkshire B", 55)])
    assert n == 1, logs
    c = read_candidates(path)[0]
    assert c.ticker == "BRK/B" and c.exchange == "NYS"
    assert any("slash" in l for l in logs), logs
    os.remove(path)


def test_fail_closed_drops():
    path = tmpcsv()
    stage3 = [
        ("ZZZZ", "NotTradable", rep()),                       # not in universe
        ("XOM",  "Exxon",       rep(score=79)),               # below VCP 80
        ("SNDK", "Sandisk",     None),                        # engine/fetch failed
        ("AAPL", "Apple",       rep()),                       # no stage-2 score
        ("NORS", "NoRS",        rep()),                       # not in stage-1 rows
    ]
    s1_rows = [s1("ZZZZ", 90), s1("XOM", 91), s1("SNDK", 92), s1("AAPL", 93)]
    s2_rows = [("ZZZZ", "NotTradable", 60), ("XOM", "Exxon", 60),
               ("SNDK", "Sandisk", 60), ("NORS", "NoRS", 60),
               ("AAPL", "Apple", None)]                       # dry-run leak shape
    n, logs = emit(path, stage3, s1_rows, s2_rows)
    assert n == 0, logs
    joined = "\n".join(logs)
    assert "dropped ZZZZ" in joined and "not KIS-tradable" in joined
    assert "dropped AAPL" in joined and "Stage-2" in joined
    assert "dropped NORS" in joined and "RS Rating" in joined
    # below-threshold and failed-report names are excluded silently (not finals)
    assert "XOM" not in joined.replace("0 final", "") or "dropped XOM" not in joined
    cands = read_candidates(path)
    assert cands == []                                        # header-only file
    os.remove(path)


def test_missing_close_fails_closed_downstream():
    path = tmpcsv()
    n, logs = emit(path, stage3=[("XOM", "Exxon", rep(omit=("Latest_Close",)))],
                   s1_rows=[s1("XOM", 85)], s2_rows=[("XOM", "Exxon", 50)])
    assert n == 1, logs
    c = read_candidates(path)[0]
    assert c.close_known is False and c.last_close == 0.0
    assert any("close_known=0" in l or "NO Latest_Close" in l for l in logs), logs
    os.remove(path)


def test_missing_atr_structural_only():
    path = tmpcsv()
    n, _ = emit(path, stage3=[("XOM", "Exxon", rep(omit=("Latest_ATR",)))],
                s1_rows=[s1("XOM", 85)], s2_rows=[("XOM", "Exxon", 50)])
    assert n == 1
    c = read_candidates(path)[0]
    assert c.atr == 0.0 and c.close_known is True
    os.remove(path)


def test_base_low_wave_fallback():
    path = tmpcsv()
    n, _ = emit(path, stage3=[("XOM", "Exxon", rep(omit=("Base_Low",), wave_lows=(93.0, 91.5)))],
                s1_rows=[s1("XOM", 85)], s2_rows=[("XOM", "Exxon", 50)])
    assert n == 1
    c = read_candidates(path)[0]
    assert c.base_low == 91.5               # min(Wave_Lows) fallback (whole-base geometry)
    assert c.contraction_low == 91.5        # Wave_Lows[-1] (the stop anchor)
    os.remove(path)


def test_cross_screener_merge_and_replacement():
    path = tmpcsv()
    # run 1: sp500 emits AAPL
    emit(path, [("AAPL", "Apple", rep(score=90))], [s1("AAPL", 95)],
         [("AAPL", "Apple", 70)], source="sp500")
    # run 2 (same date): us_small emits XOM -> union of both
    n, logs = emit(path, [("XOM", "Exxon", rep(score=85))], [s1("XOM", 88)],
                   [("XOM", "Exxon", 60)], source="us_small")
    assert n == 2, logs
    assert {c.ticker for c in read_candidates(path)} == {"AAPL", "XOM"}
    assert any("1 same-date row(s) preserved" in l for l in logs), logs
    # run 3 (same date): sp500 re-emits AAPL with a new VCP -> replaced, no dup
    n, _ = emit(path, [("AAPL", "Apple", rep(score=97))], [s1("AAPL", 95)],
                [("AAPL", "Apple", 70)], source="sp500")
    cands = read_candidates(path)
    assert n == 2 and len(cands) == 2
    assert next(c for c in cands if c.ticker == "AAPL").vcp_score == 97
    os.remove(path)


def test_stale_date_purged():
    path = tmpcsv()
    emit(path, [("AAPL", "Apple", rep())], [s1("AAPL", 95)],
         [("AAPL", "Apple", 70)], date="2026-07-15")
    n, logs = emit(path, [("XOM", "Exxon", rep())], [s1("XOM", 88)],
                   [("XOM", "Exxon", 60)], date="2026-07-16")
    assert n == 1, logs
    cands = read_candidates(path)
    assert [c.ticker for c in cands] == ["XOM"]
    assert any("1 stale row(s) dropped" in l for l in logs), logs
    os.remove(path)


def test_zero_final_run_refreshes_file_without_universe():
    path = tmpcsv()
    # yesterday's candidates on disk
    emit(path, [("AAPL", "Apple", rep())], [s1("AAPL", 95)],
         [("AAPL", "Apple", 70)], date="2026-07-15")
    # today: Stage 1 produced nothing; universe=None must NOT be touched/imported
    n, logs = emit(path, [], [], [], date="2026-07-16", universe=None)
    assert n == 0, logs
    assert read_candidates(path) == []                        # fresh header-only file
    # and same-date zero-final run preserves the sibling screener's rows
    emit(path, [("XOM", "Exxon", rep())], [s1("XOM", 88)],
         [("XOM", "Exxon", 60)], date="2026-07-16")
    n, _ = emit(path, [], [], [], date="2026-07-16", universe=None)
    assert n == 1 and [c.ticker for c in read_candidates(path)] == ["XOM"]
    os.remove(path)


def test_batch_dedupe_keeps_higher_vcp():
    path = tmpcsv()
    n, _ = emit(path,
                [("AAPL", "Apple", rep(score=85)), ("AAPL", "Apple", rep(score=93))],
                [s1("AAPL", 95)], [("AAPL", "Apple", 70)])
    assert n == 1
    assert read_candidates(path)[0].vcp_score == 93
    os.remove(path)


def test_bad_geometry_dropped_with_reason():
    path = tmpcsv()
    n, logs = emit(path, stage3=[("XOM", "Exxon", rep(pivot=0.0))],
                   s1_rows=[s1("XOM", 85)], s2_rows=[("XOM", "Exxon", 50)])
    assert n == 0
    assert any("dropped XOM" in l and "pivot" in l for l in logs), logs
    os.remove(path)



def test_v3_contraction_low_unknown_fails_closed():
    """Absent Wave_Lows -> contraction_low 0.0 (UNKNOWN, never fabricated from
    base_low), the row still round-trips (unknown != corrupt), and the decision
    engine REJECTS it with a reason naming the fix — the §1.6 fail-closed
    pattern applied to the v3 stop anchor."""
    from kistrader.entry.decision_engine import DecisionEngine, AccountState
    path = tmpcsv()
    n, _ = emit(path, stage3=[("XOM", "Exxon", rep(wave_lows=()))],
                s1_rows=[s1("XOM", 85)], s2_rows=[("XOM", "Exxon", 50)])
    assert n == 1
    c = read_candidates(path)[0]
    assert c.contraction_low == 0.0
    eng = DecisionEngine()
    plans, rej = eng.plan([c], AccountState(equity=200_000.0, cash=200_000.0))
    assert plans == [] and len(rej) == 1
    assert "contraction_low" in rej[0].reason and "Wave_Lows" in rej[0].reason
    os.remove(path)


def test_v3_contraction_regime_replay():
    """Acceptance test for the v3 stop regime, replayed over the 21 real-market
    reports captured by emit_probe on 2026-07-18 (five names with exact
    Wave_Lows[-1]; the rest reconstructed from the printed final-contraction
    depths — verdict margins are >=0.2pp so 1dp reconstruction cannot flip any).
    Expected, from the REAL engine (extension guard included, which the probe's
    own diagnostic omitted): 10 arm, 4 reject too-extended, 7 reject
    final-contraction-too-wide. Uncapped test config so selection caps don't
    mask _plan_one behavior; caps have their own tests in the main suite."""
    from kistrader.entry.decision_engine import (DecisionEngine, DecisionConfig,
                                                 AccountState)
    from kistrader.entry.screen_contract import Candidate

    #        ticker   pivot    close    atr    base_lo  base_hi  c_low   d_final
    data = [
        ("DELL", 438.52, 397.66, 33.12, 357.07, 469.47, 386.01, None),
        ("FTNT", 164.01, 161.46,  6.70, 126.61, 170.35, 152.25, None),
        ("NTAP", 176.97, 162.41,  7.60, 148.82, 192.25, 160.50, None),
        ("DVA",  239.44, 236.25,  6.47, 186.61, 239.64, 225.17, None),
        ("JBHT", 288.03, 289.79,  9.35, 269.39, 299.76, 272.30, None),
        ("PANW", 340.13, 355.82, 16.96, 251.15, 368.80, None, 0.070),
        ("CNC",   69.36,  65.88,  2.40,  31.63,  69.36, None, 0.089),
        ("AMAT", 739.67, 527.86, 50.65, 513.22, 739.67, None, 0.287),
        ("VLO",  264.16, 306.94, 10.26, 232.72, 307.55, None, 0.119),
        ("CHRW", 190.00, 207.26,  5.62, 145.38, 208.70, None, 0.075),
        ("MPC",  312.60, 310.92,  8.44, 238.28, 312.60, "base", None),
        ("VTRS",  17.17,  17.31,  0.50,  14.94,  17.67, None, 0.071),
        ("WST",  367.66, 359.94,  7.95, 223.66, 367.66, None, 0.050),
        ("PSX",  177.99, 206.35,  5.63, 152.47, 206.88, None, 0.051),
        ("TRGP", 275.58, 282.61,  7.19, 252.97, 285.56, None, 0.071),
        ("URI", 1095.00, 1043.60, 32.53, 1035.00, 1143.69, None, 0.049),
        ("LLY", 1238.00, 1176.28, 39.58, 849.05, 1249.45, None, 0.052),
        ("SWK",   95.16,  89.45,  3.26,  84.86,  95.16, "base", None),
        ("AAPL", 309.42, 332.81,  8.57, 273.75, 334.98, None, 0.076),
        ("FFIV", 435.00, 410.17, 14.32, 372.62, 435.00, None, 0.099),
        ("ADM",   82.55,  84.97,  1.94,  71.62,  86.00, None, 0.132),
    ]
    cands = []
    for t, piv, close, atr, bl, bh, cl, d in data:
        if cl == "base":      # printed base depth == final depth -> anchor IS the base floor
            c_low = bl
        elif cl is None:
            c_low = max(round(piv * (1 - d), 2), bl)   # reconstruction, floored at base_low
        else:
            c_low = cl
        cands.append(Candidate(
            ticker=t, exchange="NAS", rs_proxy=90, stage2_score=60.0,
            vcp_score=60.0, pivot=piv, base_high=bh, base_low=bl,
            depth_pct=(bh - bl) / bh, last_close=close, atr=atr,
            trade_signal=False, session_date="2026-07-17", name=t,
            close_known=True, contraction_low=c_low))

    eng = DecisionEngine(DecisionConfig(n_max=100, max_open_positions=100,
                                        max_portfolio_exposure_pct=100.0))
    plans, rej = eng.plan(cands, AccountState(equity=211_710.0, cash=211_710.0))

    armed = {p.ticker for p in plans}
    assert armed == {"PANW", "FTNT", "CNC", "DVA", "VTRS", "WST", "LLY",
                     "JBHT", "TRGP", "URI"}, armed
    reasons = {r.ticker: r.reason for r in rej}
    for t in ("VLO", "CHRW", "PSX", "AAPL"):
        assert "too extended" in reasons[t], (t, reasons[t])
    for t in ("DELL", "AMAT", "NTAP", "MPC", "SWK", "FFIV", "ADM"):
        assert "final contraction too wide" in reasons[t], (t, reasons[t])
    # exact stop values for two exact-anchor names: contraction_low * 0.995
    stops = {p.ticker: p.stop_price for p in plans}
    assert stops["DVA"] == 224.04 and stops["JBHT"] == 270.94, stops
    assert all(p.stop_basis == "contraction+atr" for p in plans)


def test_v3_shakeout_undercut_is_valid_not_corrupt():
    """The final wave's low may undercut the whole base's floor (screener
    measures Base_Low and the ZigZag waves over slightly different windows;
    observed live 3/21 on 2026-07-20: VLO, SWK, ADM). That is a SHAKEOUT — a
    feature of strong bases — so it must round-trip and arm, not be dropped as
    corrupt. (An earlier problems() check rejected exactly this; regression
    guard.) A low at/above the pivot stays corrupt."""
    from kistrader.entry.decision_engine import DecisionEngine, AccountState
    from kistrader.entry.screen_contract import Candidate

    path = tmpcsv()
    # Wave_Lows[-1]=89.5 undercuts Base_Low=90.0 by 0.5 — shakeout geometry
    n, logs = emit(path, stage3=[("XOM", "Exxon",
                                  rep(base_low=90.0, wave_lows=(92.0, 89.5),
                                      close=99.0, atr=2.0))],
                   s1_rows=[s1("XOM", 85)], s2_rows=[("XOM", "Exxon", 50)])
    assert n == 1, logs                      # NOT dropped at the emitter
    c = read_candidates(path)[0]
    assert c.contraction_low == 89.5 and c.base_low == 90.0   # undercut preserved
    # downstream the ENGINE decides on risk (this one is ~11.4% -> cap-rejected,
    # with the honest risk reason — not a bogus "corrupt geometry" drop):
    plans, rej = DecisionEngine().plan(
        [c], AccountState(equity=200_000.0, cash=200_000.0))
    assert plans == [] and "final contraction too wide" in rej[0].reason
    os.remove(path)


def test_v3_shakeout_undercut_arms():
    """Same as above with cap-compatible numbers: proves the undercut row not
    only survives validation but produces a plan anchored on the undercut low."""
    from kistrader.entry.decision_engine import DecisionEngine, AccountState
    path = tmpcsv()
    n, _ = emit(path, stage3=[("XOM", "Exxon",
                               rep(base_low=95.0, wave_lows=(96.0, 94.6),
                                   close=99.0, atr=1.0))],
                s1_rows=[s1("XOM", 85)], s2_rows=[("XOM", "Exxon", 50)])
    assert n == 1
    c = read_candidates(path)[0]
    assert c.contraction_low == 94.6 < c.base_low == 95.0
    plans, rej = DecisionEngine().plan(
        [c], AccountState(equity=200_000.0, cash=200_000.0))
    assert len(plans) == 1 and rej == [], rej
    # stop anchored on the UNDERCUT low: min(94.6*0.995=94.13, 100.5-1.3=99.2)
    assert plans[0].stop_price == 94.13, plans[0].stop_price
    # corrupt case still rejected at the schema: low at/above pivot
    from kistrader.entry.screen_contract import Candidate
    bad = Candidate(ticker="BAD", exchange="NAS", rs_proxy=50, stage2_score=50,
                    vcp_score=50, pivot=100.0, base_high=100.0, base_low=90.0,
                    depth_pct=0.10, last_close=99.0, atr=1.0,
                    session_date="2026-07-17", contraction_low=100.0)
    assert any("contraction_low >= pivot" in pr for pr in bad.problems())
    os.remove(path)


# --------------------------------------------------------- regime sidecar ----
# Phase 3a. The artifact exists; 3b makes the screeners fill it and 3c makes the
# trader read it. These tests are the contract both halves are written against.

def _regime_env():
    from kistrader.entry.screen_contract import regime_path_for
    d = tempfile.mkdtemp()
    csv_path = os.path.join(d, "candidates.csv")
    return d, csv_path, regime_path_for(csv_path)


def test_regime_sidecar_sits_beside_candidates():
    _d, csv_path, rp = _regime_env()
    assert os.path.dirname(rp) == os.path.dirname(os.path.abspath(csv_path)), rp
    assert os.path.basename(rp) == "regime.json", rp


def test_regime_write_read_roundtrip():
    from kistrader.entry.screen_contract import write_regime, read_regime
    _d, _csv, rp = _regime_env()
    write_regime(rp, session_date="2026-08-14", screener="sp500_v21",
                 vcp_threshold=75.0, benchmark="^GSPC", regime_ma=20,
                 benchmark_close=5432.10, benchmark_ma=5400.00,
                 bar_date="2026-08-13", emitted=3, log=lambda m: None)
    close, ma, meta = read_regime(rp, "2026-08-14")
    assert meta["usable"], meta["reason"]
    assert close == 5432.10 and ma == 5400.00, (close, ma)
    assert meta["doc"]["state"] == "risk_on", meta["doc"]["state"]
    assert meta["doc"]["screeners"]["sp500_v21"]["vcp_threshold"] == 75.0


def test_regime_state_is_computed_not_asserted():
    from kistrader.entry.screen_contract import write_regime
    _d, _csv, rp = _regime_env()
    doc = write_regime(rp, session_date="2026-08-14", screener="sp500_v21",
                       vcp_threshold=75.0, benchmark="^GSPC", regime_ma=20,
                       benchmark_close=5300.0, benchmark_ma=5400.0,
                       bar_date="2026-08-13", log=lambda m: None)
    assert doc["state"] == "risk_off", doc["state"]
    doc = write_regime(rp, session_date="2026-08-14", screener="sp500_v21",
                       vcp_threshold=75.0, benchmark="^GSPC", regime_ma=20,
                       benchmark_close=5400.0, benchmark_ma=5400.0,
                       bar_date="2026-08-13", log=lambda m: None)
    assert doc["state"] == "risk_on", "close == ma is RISK_ON (>=), not off"


def test_regime_cross_screener_merge():
    from kistrader.entry.screen_contract import write_regime, read_regime
    _d, _csv, rp = _regime_env()
    common = dict(session_date="2026-08-14", benchmark="^GSPC", regime_ma=20,
                  benchmark_close=5432.10, benchmark_ma=5400.00,
                  bar_date="2026-08-13", log=lambda m: None)
    write_regime(rp, screener="sp500_v21", vcp_threshold=75.0, emitted=3, **common)
    write_regime(rp, screener="us_small_v21", vcp_threshold=75.0, emitted=5, **common)
    close, ma, meta = read_regime(rp, "2026-08-14")
    assert meta["usable"], meta["reason"]
    assert set(meta["doc"]["screeners"]) == {"sp500_v21", "us_small_v21"}
    assert meta["doc"]["screeners"]["us_small_v21"]["emitted"] == 5
    assert meta["doc"]["disagreements"] == []


def test_regime_disagreement_fails_closed():
    """Both screeners see the same completed daily bar pre-open. If they do not,
    one was served a cached frame by _fetch_history -- refuse, do not average."""
    from kistrader.entry.screen_contract import write_regime, read_regime
    _d, _csv, rp = _regime_env()
    base = dict(session_date="2026-08-14", benchmark="^GSPC", regime_ma=20,
                benchmark_ma=5400.00, bar_date="2026-08-13", log=lambda m: None)
    write_regime(rp, screener="sp500_v21", vcp_threshold=75.0,
                 benchmark_close=5432.10, **base)
    write_regime(rp, screener="us_small_v21", vcp_threshold=75.0,
                 benchmark_close=5399.00, **base)
    close, ma, meta = read_regime(rp, "2026-08-14")
    assert (close, ma) == (None, None), (close, ma)
    assert "disagree" in meta["reason"], meta["reason"]


def test_regime_same_screener_rerun_replaces():
    """A screener re-running after a failed first attempt must REPLACE its own
    contribution, not be flagged as disagreeing with itself. Cross-screener
    disagreement (test_regime_disagreement_fails_closed) is unaffected."""
    from kistrader.entry.screen_contract import write_regime, read_regime
    _d, _csv, rp = _regime_env()
    common = dict(session_date="2026-08-14", screener="sp500_v21",
                  vcp_threshold=75.0, benchmark="^GSPC", regime_ma=20,
                  log=lambda m: None)
    write_regime(rp, benchmark_close=None, benchmark_ma=None, bar_date=None,
                 emitted=0, **common)                       # failed fetch
    close, ma, meta = read_regime(rp, "2026-08-14")
    assert (close, ma) == (None, None), "first attempt is unusable"
    write_regime(rp, benchmark_close=5432.10, benchmark_ma=5400.00,
                 bar_date="2026-08-13", emitted=3, **common)   # successful re-run
    close, ma, meta = read_regime(rp, "2026-08-14")
    assert meta["usable"], meta["reason"]
    assert (close, ma) == (5432.10, 5400.00), (close, ma)
    assert meta["doc"]["disagreements"] == [], meta["doc"]["disagreements"]
    assert meta["doc"]["screeners"]["sp500_v21"]["emitted"] == 3


def test_regime_stale_session_fails_closed():
    from kistrader.entry.screen_contract import write_regime, read_regime
    _d, _csv, rp = _regime_env()
    write_regime(rp, session_date="2026-08-13", screener="sp500_v21",
                 vcp_threshold=75.0, benchmark="^GSPC", regime_ma=20,
                 benchmark_close=5432.10, benchmark_ma=5400.00,
                 bar_date="2026-08-12", log=lambda m: None)
    close, ma, meta = read_regime(rp, "2026-08-14")
    assert (close, ma) == (None, None)
    assert "STALE" in meta["reason"], meta["reason"]


def test_regime_missing_and_malformed_fail_closed():
    from kistrader.entry.screen_contract import read_regime
    d, _csv, rp = _regime_env()
    close, ma, meta = read_regime(rp, "2026-08-14")
    assert (close, ma) == (None, None) and "no regime sidecar" in meta["reason"]
    with open(rp, "w", encoding="utf-8") as fh:
        fh.write("{not json")
    close, ma, meta = read_regime(rp, "2026-08-14")
    assert (close, ma) == (None, None) and "unreadable" in meta["reason"]
    with open(rp, "w", encoding="utf-8") as fh:
        fh.write('{"schema_version": 99, "session_date": "2026-08-14"}')
    close, ma, meta = read_regime(rp, "2026-08-14")
    assert (close, ma) == (None, None) and "schema" in meta["reason"]


def test_regime_bar_age_guard():
    """_fetch_history silently substitutes a pickled cache when the provider
    returns empty, so a 'successful' fetch can carry a bar from days ago."""
    from kistrader.entry.screen_contract import write_regime, read_regime
    _d, _csv, rp = _regime_env()
    common = dict(session_date="2026-08-14", screener="sp500_v21",
                  vcp_threshold=75.0, benchmark="^GSPC", regime_ma=20,
                  benchmark_close=5432.10, benchmark_ma=5400.00,
                  log=lambda m: None)
    write_regime(rp, bar_date="2026-08-11", **common)          # 3 days: long weekend
    assert read_regime(rp, "2026-08-14")[2]["usable"]
    write_regime(rp, bar_date="2026-08-01", **common)          # 13 days: cached
    close, ma, meta = read_regime(rp, "2026-08-14")
    assert (close, ma) == (None, None) and "cached frame" in meta["reason"], meta["reason"]
    write_regime(rp, bar_date="2026-08-20", **common)          # future
    assert "AFTER the session" in read_regime(rp, "2026-08-14")[2]["reason"]
    write_regime(rp, bar_date=None, **common)
    assert "bar_date" in read_regime(rp, "2026-08-14")[2]["reason"]


def test_regime_degraded_run_never_arms():
    """--emit-threshold is documented as supervised plumbing only, and today its
    CSV is byte-indistinguishable from a real run. The sidecar makes it visible
    and refuses it."""
    from kistrader.entry.screen_contract import write_regime, read_regime
    _d, _csv, rp = _regime_env()
    write_regime(rp, session_date="2026-08-14", screener="sp500_v21",
                 vcp_threshold=75.0, degraded_threshold=70.0, benchmark="^GSPC",
                 regime_ma=20, benchmark_close=5432.10, benchmark_ma=5400.00,
                 bar_date="2026-08-13", log=lambda m: None)
    close, ma, meta = read_regime(rp, "2026-08-14")
    assert (close, ma) == (None, None)
    assert "emit-threshold" in meta["reason"], meta["reason"]


def test_regime_threshold_mismatch_detected():
    from kistrader.entry.screen_contract import write_regime, read_regime
    _d, _csv, rp = _regime_env()
    write_regime(rp, session_date="2026-08-14", screener="us_small_v21",
                 vcp_threshold=70.0, benchmark="^GSPC", regime_ma=20,
                 benchmark_close=5432.10, benchmark_ma=5400.00,
                 bar_date="2026-08-13", log=lambda m: None)
    _c, _m, meta = read_regime(rp, "2026-08-14", expected_threshold=75.0)
    assert not meta["usable"] and "applied vcp_threshold" in meta["reason"], meta["reason"]


def test_regime_unavailable_benchmark_fails_closed():
    from kistrader.entry.screen_contract import write_regime, read_regime
    _d, _csv, rp = _regime_env()
    doc = write_regime(rp, session_date="2026-08-14", screener="sp500_v21",
                       vcp_threshold=75.0, benchmark="^GSPC", regime_ma=20,
                       benchmark_close=None, benchmark_ma=None,
                       bar_date=None, log=lambda m: None)
    assert doc["state"] == "unavailable", doc["state"]
    close, ma, meta = read_regime(rp, "2026-08-14")
    assert (close, ma) == (None, None) and "benchmark unavailable" in meta["reason"]


def test_emit_writes_the_sidecar():
    """End to end through emit_candidates, the way 3b will call it."""
    from kistrader.entry.screen_contract import read_regime
    d, csv_path, rp = _regime_env()
    n = emit_candidates(stage3_results=[("AAPL", "Apple", rep(score=91))],
                        passed_stocks=[s1("AAPL", 95)],
                        stage2_passed=[("AAPL", "Apple", 72.5)],
                        out_path=csv_path, vcp_threshold=75.0,
                        session_date="2026-08-14", universe=UNIVERSE,
                        source="sp500_v21", benchmark="^GSPC", regime_ma=20,
                        benchmark_close=5432.10, benchmark_ma=5400.00,
                        benchmark_bar_date="2026-08-13", log=lambda m: None)
    assert n == 1, n
    close, ma, meta = read_regime(rp, "2026-08-14")
    assert meta["usable"], meta["reason"]
    assert meta["doc"]["screeners"]["sp500_v21"]["emitted"] == 1
    assert meta["doc"]["screeners"]["sp500_v21"]["vcp_threshold"] == 75.0


def test_emit_records_a_degraded_run():
    from kistrader.entry.screen_contract import read_regime
    d, csv_path, rp = _regime_env()
    emit_candidates(stage3_results=[("AAPL", "Apple", rep(score=91))],
                    passed_stocks=[s1("AAPL", 95)],
                    stage2_passed=[("AAPL", "Apple", 72.5)],
                    out_path=csv_path, vcp_threshold=70.0,
                    session_date="2026-08-14", universe=UNIVERSE,
                    source="sp500_v21 DEGRADED@70", benchmark="^GSPC", regime_ma=20,
                    benchmark_close=5432.10, benchmark_ma=5400.00,
                    benchmark_bar_date="2026-08-13", log=lambda m: None)
    _c, _m, meta = read_regime(rp, "2026-08-14")
    assert not meta["usable"] and "emit-threshold" in meta["reason"], meta["reason"]


def test_emit_without_regime_values_writes_nothing():
    """Phase 3a is inert: a screener that has not been taught the gate yet must
    not produce a sidecar. Its absence is what makes the trader fail closed."""
    d, csv_path, rp = _regime_env()
    emit_candidates(stage3_results=[("AAPL", "Apple", rep(score=91))],
                    passed_stocks=[s1("AAPL", 95)],
                    stage2_passed=[("AAPL", "Apple", 72.5)],
                    out_path=csv_path, vcp_threshold=75.0,
                    session_date="2026-08-14", universe=UNIVERSE,
                    log=lambda m: None)
    assert os.path.exists(csv_path), "the CSV must still be written"
    assert not os.path.exists(rp), "no regime values passed -> no sidecar"


def test_regime_ma_mismatch_detected():
    """The reader consumes a PRECOMPUTED MA. If the writer used a different
    window than the consumer expects, the number is not the one the consumer
    thinks it is -- refuse rather than gate on the wrong average."""
    from kistrader.entry.screen_contract import write_regime, read_regime
    _d, _csv, rp = _regime_env()
    write_regime(rp, session_date="2026-08-14", screener="sp500_v21",
                 vcp_threshold=75.0, benchmark="^GSPC", regime_ma=150,
                 benchmark_close=5432.10, benchmark_ma=5400.00,
                 bar_date="2026-08-13", log=lambda m: None)
    c, m, meta = read_regime(rp, "2026-08-14", expected_regime_ma=20)
    assert (c, m) == (None, None), (c, m)
    assert "regime_ma" in meta["reason"] and "150" in meta["reason"], meta["reason"]
    # the matching window is accepted, and None means "do not check"
    assert read_regime(rp, "2026-08-14", expected_regime_ma=150)[2]["usable"]
    assert read_regime(rp, "2026-08-14")[2]["usable"]


def test_regime_tmp_file_is_process_scoped():
    """Two screeners running concurrently must not race on one temp file."""
    import re
    from kistrader.entry import screen_contract as SC
    src = open(SC.__file__, encoding="utf-8").read()
    m = re.search(r"^\s*tmp = (.+)$", src, re.M)
    assert m, "write_regime no longer has a tmp path"
    assert "getpid" in m.group(1), f"temp path is not process-scoped: {m.group(1)}"


ALL = [v for k, v in sorted(globals().items()) if k.startswith("test_")]

if __name__ == "__main__":
    failed = 0
    for fn in ALL:
        try:
            fn()
            print(f"  PASS  {fn.__name__}")
        except AssertionError as e:
            failed += 1
            print(f"  FAIL  {fn.__name__}: {e}")
    print(f"\n{len(ALL) - failed}/{len(ALL)} emitter contract tests passed")
    sys.exit(1 if failed else 0)
