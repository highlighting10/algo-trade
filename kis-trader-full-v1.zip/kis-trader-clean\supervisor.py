#!/usr/bin/env python3
"""
supervisor.py — auto-restart wrapper for the kistrader loop (Step 6 item #1).
=============================================================================

WHY A SEPARATE PROCESS: the loop cannot restart itself after it has died; only
something OUTSIDE its failure domain can. Same isolation rule as deadman.py:
stdlib only, imports nothing from kistrader, keeps working when the package is
mid-edit or the venv is wounded.

WHAT IT DOES
  * spawns:  <this python> -m kistrader.cli run <your args>
  * child output passes straight through to the console (and thus to any log
    redirect you use); the child's own alerts still go to kistrader_alerts.log.
  * child exits (crash OR clean) -> restart after an exponential backoff
    (base 5s, doubling, capped 300s). The loop is meant to be eternal, so ANY
    exit is abnormal; a clean-exit special case would just hide bugs.
  * backoff RESETS after the child stays up "healthy-secs" (default 600s) —
    one bad start doesn't tax the next week.
  * CRASH-STORM GUARD: more than --max-restarts exits inside --window seconds
    -> supervisor STOPS restarting and exits loudly. Rationale: a loop dying
    every minute has a systemic cause; hammering KIS with fresh sessions makes
    it worse. The DEADMAN then fires on the stale heartbeat — layered defense:
    supervisor absorbs transient faults, deadman reports systemic ones.
  * CLEAN SHUTDOWN: create a file named `supervisor.stop` (any content) in the
    working directory, or Ctrl+C. Either terminates the child gracefully and
    exits 0. The stop file is consumed (deleted) on shutdown.

USAGE
  python supervisor.py -- --auto-arm
      (everything after `--` is passed to `kistrader.cli run`)

  DO NOT pass --no-open-order-check. It disables the 3.9.1 resting-order dedup
  backstop, which is one of the three items the Step 6 soak exists to prove.
  A run carrying that flag produces no error and no log line -- it simply never
  exercises the gate. That flag is for supervised plumbing runs only.

  python supervisor.py --dry              # print the command, don't run
  python supervisor.py --cmd "python x.py"   # supervise an arbitrary command
                                             # (testing / other daemons)
"""
from __future__ import annotations

import argparse
import os
import shlex
import subprocess
import sys
import time
from collections import deque
from datetime import datetime

# A scheduler redirects stdout to a FILE or a PIPE, and that stream takes
# its encoding from the locale -- cp949 on this box, which cannot encode
# U+2014. Printing a single em dash then raises UnicodeEncodeError and this
# process DIES (exit 1). Measured 2026-09-14: every redirected run crashed
# on its own first log line, while the interactive run was fine because
# Python writes to a Windows console through the UTF-16 API instead.
#
# Pin the encoding so no character in any message can kill the watcher.
# Guarded: sys.stdout is None under pythonw and may already be detached.
for _s in (sys.stdout, sys.stderr):
    try:
        _s.reconfigure(encoding="utf-8", errors="backslashreplace")
    except Exception:                                     # noqa: BLE001
        pass

STOP_FILE = "supervisor.stop"

# A child killed by Ctrl+C is an OPERATOR STOP, not a crash to restart. On
# Windows the console sends CTRL_C_EVENT to the whole process group, so the
# child can die from the interrupt WITHOUT the supervisor's own wait() raising
# KeyboardInterrupt — without this check the supervisor would cheerfully
# restart the loop you just tried to stop.
INTERRUPT_EXITS = {-2,            # POSIX: killed by SIGINT
                   -1073741510,   # Windows STATUS_CONTROL_C_EXIT (signed)
                   3221225786}    # ... and unsigned


def log(msg: str) -> None:
    print(f"[supervisor] {datetime.now().strftime('%H:%M:%S')}  {msg}", flush=True)


def stop_requested() -> bool:
    return os.path.exists(STOP_FILE)


def consume_stop() -> None:
    try:
        os.remove(STOP_FILE)
    except OSError:
        pass


def terminate(child: subprocess.Popen, grace: float = 10.0) -> None:
    if child.poll() is not None:
        return
    child.terminate()
    try:
        child.wait(timeout=grace)
    except subprocess.TimeoutExpired:
        log("child ignored terminate -- killing")
        child.kill()
        child.wait()


def main() -> int:
    ap = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("child_args", nargs="*",
                    help="args after `--` are passed to `kistrader.cli run`")
    ap.add_argument("--cmd", default=None,
                    help="supervise this full command instead of kistrader run")
    # 65s, NOT 5s. KIS issues at most ONE access token per minute per app key
    # (EGW00133) and every restarted process must issue its own. A 5s backoff
    # therefore GUARANTEES the restart fails on token issuance, which crashes
    # again, which restarts again -- and those wasted exits count toward the
    # crash-storm guard, so ONE transient fault could trip a full shutdown.
    # 65s puts the first retry safely outside the token window.
    ap.add_argument("--backoff-base", type=float, default=65.0)
    ap.add_argument("--backoff-cap", type=float, default=300.0)
    ap.add_argument("--healthy-secs", type=float, default=600.0,
                    help="uptime after which the backoff resets")
    ap.add_argument("--max-restarts", type=int, default=6,
                    help="storm guard: exits allowed inside --window")
    ap.add_argument("--window", type=float, default=1800.0,
                    help="storm-guard window in seconds")
    ap.add_argument("--dry", action="store_true", help="print the command and exit")
    args = ap.parse_args()

    if args.cmd:
        # shlex.split defaults to POSIX mode, where backslash is an ESCAPE:
        # r"C:\Users\user\.venv\Scripts\python.exe" parses to
        # "C:Usersuser.venvScriptspython.exe" and the spawn fails. On Windows
        # Popen accepts the command line as a STRING and passes it to
        # CreateProcess unmangled, which is the documented form there.
        cmd = args.cmd if os.name == "nt" else shlex.split(args.cmd)
    else:
        cmd = [sys.executable, "-m", "kistrader.cli", "run"] + args.child_args

    log(f"command: {cmd if isinstance(cmd, str) else ' '.join(cmd)}")
    if args.backoff_base < 65 and not args.cmd:
        log(f"WARNING: --backoff-base {args.backoff_base}s is under the KIS "
            f"token-issuance window (1/min). A fast restart will fail with "
            f"EGW00133 and burn a storm-guard slot.")
    log(f"policy: backoff {args.backoff_base}s..{args.backoff_cap}s, healthy after "
        f"{args.healthy_secs}s, storm guard {args.max_restarts} exits/{args.window}s, "
        f"stop file: {STOP_FILE}")
    if args.dry:
        return 0
    if stop_requested():
        log(f"{STOP_FILE} already present -- remove it to start. Exiting.")
        return 2

    backoff = args.backoff_base
    exits = deque()                       # wall-clock timestamps of child exits

    while True:
        started = time.time()
        log("starting child...")
        try:
            child = subprocess.Popen(cmd)
        except Exception as ex:           # noqa: BLE001  (spawn itself failed)
            log(f"SPAWN FAILED: {ex}")
            child = None

        rc = None
        if child is not None:
            while True:
                try:
                    rc = child.wait(timeout=2.0)
                    break                                    # child exited
                except subprocess.TimeoutExpired:
                    if stop_requested():
                        log("stop file seen -- shutting child down cleanly")
                        terminate(child)
                        consume_stop()
                        log("stopped by operator. bye.")
                        return 0
                except KeyboardInterrupt:
                    log("Ctrl+C -- shutting child down cleanly")
                    terminate(child)
                    log("stopped by operator. bye.")
                    return 0

        uptime = time.time() - started
        log(f"child exited rc={rc} after {uptime:.0f}s")

        if rc in INTERRUPT_EXITS:
            log("child exited on an interrupt (Ctrl+C) -- operator stop, not "
                "restarting. bye.")
            return 0

        now = time.time()
        exits.append(now)
        while exits and now - exits[0] > args.window:
            exits.popleft()
        if len(exits) > args.max_restarts:
            log(f"CRASH STORM: {len(exits)} exits within {args.window:.0f}s -- "
                f"NOT restarting. Fix the cause; the dead-man will alert on the "
                f"stale heartbeat. Exiting 3.")
            return 3

        if uptime >= args.healthy_secs:
            backoff = args.backoff_base                      # healthy run: forgive
        if stop_requested():
            consume_stop()
            log("stop file seen -- not restarting. bye.")
            return 0
        log(f"restarting in {backoff:.0f}s")
        slept = 0.0
        while slept < backoff:                               # stop-aware sleep
            try:
                time.sleep(min(1.0, backoff - slept))
            except KeyboardInterrupt:                        # was UNPROTECTED
                log("Ctrl+C during backoff -- not restarting. bye.")
                return 0
            slept += 1.0
            if stop_requested():
                consume_stop()
                log("stop file seen during backoff -- not restarting. bye.")
                return 0
        backoff = min(backoff * 2, args.backoff_cap)


if __name__ == "__main__":
    sys.exit(main())
