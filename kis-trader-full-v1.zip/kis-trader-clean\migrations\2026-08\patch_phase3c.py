#!/usr/bin/env python3
"""
patch_phase3c.py -- PHASE 3c: the trader reads the regime sidecar.

The last piece of Phase 3. 3a built the artifact, 3b made the screeners write it,
this makes it bind.

ONE GATE, ONE SOURCE
exposure_controller.py ships UNMODIFIED. It takes two numbers and owns no fetch,
which is exactly what lets it drop in: arm_today reads the sidecar, converts
anything unusable into (None, None), hands that to ExposureController.decide(),
and writes the resulting ceiling into the EXISTING
DecisionConfig.max_portfolio_exposure_pct. No second gate is added -- a second
gate is the shape of the orphan open_notional bug.

The gated config is built PER CALL via dataclasses.replace, never by mutating
self.decision.cfg, so yesterday's ceiling cannot leak into today's session.
E7(g) asserts that.

WHERE IT SITS
Immediately after the freshness gate and BEFORE universe.ensure() and
_account_state(). That is the placement the freshness gate already documents for
itself: "so a stale day costs no KIS call." A regime-off day should cost none
either.

WHAT IT BLOCKS, AND WHAT IT DOES NOT
It writes the ceiling for NEW entries only. Exits, already-armed watches and
position management are untouched -- matching the backtest, where the gate
empties `eligible` and leaves open positions alone.

FAIL CLOSED
Missing, stale, malformed, disagreeing or degraded sidecar -> (None, None) ->
UNAVAILABLE -> ceiling 0.0 -> every candidate rejected with a named reason. On a
normal risk-off day the CSV is empty anyway; the ceiling matters precisely when
the CSV has fresh rows but the sidecar cannot be trusted.

DISABLING
ExposureConfig(regime_ma=None) makes decide() return RISK_ON with the normal
ceiling, so the whole phase reverts to today's behaviour through one value.

TEST FIXTURES CHANGE TOO
_write_csv now writes the sidecar as well, because production always produces
both. A fixture with only the CSV would be testing a shape that cannot occur --
and would fail closed at the new gate, correctly but uselessly.

Anchors are asserted; edits are applied bottom-up.

Usage:  python patch_phase3c.py <repo-root>
"""
from __future__ import annotations

import os
import sys

# --------------------------------------------------------------- pipeline ----

GATE = '''
        # §regime gate (Phase 3c). Sits here, after freshness and BEFORE
        # universe.ensure()/_account_state(), for the reason the freshness gate
        # gives for itself: a no-trade day must cost no KIS call.
        #
        # The sidecar is written by the screener beside candidates.csv. Anything
        # unusable -- missing, stale, malformed, screeners disagreeing about the
        # benchmark, or an --emit-threshold degraded run -- becomes (None, None),
        # which ExposureController turns into UNAVAILABLE and a 0.0 ceiling.
        # A gate that cannot evaluate must not pass.
        bclose, bma, rmeta = read_regime(regime_path_for(candidates_path),
                                         session_date)
        regime = self.exposure.decide(bclose, bma)
        if regime.state is ExposureState.RISK_ON:
            self.alert(f"regime: RISK_ON — {rmeta['reason'] or regime.reason}")
        else:
            # The operator must be able to tell this apart from "nothing
            # qualified", which is the whole reason the sidecar exists.
            self.alert(f"regime {regime.state.value.upper()}: {regime.reason} "
                       f"[sidecar: {rmeta['reason']}] — exposure ceiling "
                       f"{regime.max_portfolio_exposure_pct:.0%}, NO new entries. "
                       f"Exits and existing positions are unaffected.")
        # ONE GATE, ONE SOURCE: write the existing ceiling rather than adding a
        # second check. Built per call, so a ceiling never leaks across sessions.
        gated = DecisionEngine(apply_to_decision_config(self.decision.cfg, regime))
'''

# ------------------------------------------------------------------ tests ----

OLD_HELPER = '''def _write_csv(cands, path="e2e_candidates.csv"):
    write_candidates(path, cands)
    return path
'''

NEW_HELPER = '''def _capture(loop):
    """Start the loop and collect its alerts. `seen` is per-test in this file."""
    out = []
    loop.alert = out.append
    loop.start()
    return out


def _write_csv(cands, path="e2e_candidates.csv", regime="risk_on", session=None):
    """Write the CSV and, unless regime=None, the sidecar the screener writes
    beside it. Production always produces both, so a fixture with only the CSV
    would be testing a shape that cannot occur -- and would fail closed at the
    regime gate, correctly but uselessly."""
    write_candidates(path, cands)
    rp = regime_path_for(path)
    if regime is None:
        os.path.exists(rp) and os.unlink(rp)
        return path
    sess = session or SESSION
    close, ma = (110.0, 100.0) if regime == "risk_on" else (90.0, 100.0)
    write_regime(rp, session_date=sess, screener="sp500_v21", vcp_threshold=75.0,
                 benchmark="^GSPC", regime_ma=20, benchmark_close=close,
                 benchmark_ma=ma, bar_date=sess, emitted=len(cands),
                 log=lambda m: None)
    return path
'''

E7 = '''def test_e7_regime_gate():
    """§Phase 3c. The screener's sidecar decides whether NEW entries are allowed.

    Everything here runs through the ONE existing ceiling
    (DecisionConfig.max_portfolio_exposure_pct), so every block arrives as a
    normal, named decision-engine rejection rather than a separate gate."""
    print("E7 regime gate: the sidecar decides whether new entries are allowed")
    now = {"t": OPEN_UTC}
    CAND = dict(pivot=100.0, base_low=92.0, last_close=100.0)

    # (a) risk_on -> normal arming
    b, db, path, mon, entry, dec, loop, fclk = _assemble(now)
    csv = _write_csv([_cand("MU", **CAND)], path="e2e_regime.csv", regime="risk_on")
    seen = _capture(loop)
    armed, rej = loop.arm_today(csv)
    check("risk_on: arms normally", len(armed) == 1, f"{[r.reason for r in rej]}")
    check("risk_on: announced with the benchmark numbers",
          any("RISK_ON" in m and "^GSPC" in m for m in seen), f"{seen}")

    # (b) risk_off -> nothing arms, and the reason is a named ceiling, not silence
    b, db, path, mon, entry, dec, loop, fclk = _assemble(now)
    csv = _write_csv([_cand("MU", **CAND)], path="e2e_regime.csv", regime="risk_off")
    seen = _capture(loop)
    armed, rej = loop.arm_today(csv)
    check("risk_off: arms nothing", armed == [], f"{armed}")
    check("risk_off: no broker order was placed", b.place_calls == 0, f"{b.place_calls}")
    check("risk_off: the rejection names the exposure ceiling",
          bool(rej) and all("exposure ceiling" in r.reason for r in rej),
          f"{[r.reason for r in rej]}")
    check("risk_off: distinguishable from 'nothing qualified'",
          any("RISK_OFF" in m and "NO new entries" in m for m in seen), f"{seen}")
    # The 0.0 ceiling must be built PER CALL. If it were written back onto the
    # shared config, tomorrow's session would inherit it and trading would stop
    # for good, silently. This is the loop where a leak would be visible.
    check("risk_off: the shared DecisionConfig was NOT mutated",
          loop.decision.cfg.max_portfolio_exposure_pct != 0.0,
          f"{loop.decision.cfg.max_portfolio_exposure_pct}")
    check("risk_off: a second arm in the same session still sees the real ceiling",
          DecisionEngine(loop.decision.cfg).cfg.max_portfolio_exposure_pct > 0.0)

    # (c) no sidecar at all -> fail closed
    b, db, path, mon, entry, dec, loop, fclk = _assemble(now)
    csv = _write_csv([_cand("MU", **CAND)], path="e2e_regime.csv", regime=None)
    seen = _capture(loop)
    armed, rej = loop.arm_today(csv)
    check("missing sidecar: arms nothing (a gate that cannot evaluate must not pass)",
          armed == [], f"{armed}")
    check("missing sidecar: reported as UNAVAILABLE",
          any("UNAVAILABLE" in m for m in seen), f"{seen}")

    # (d) a sidecar from another session -> fail closed
    b, db, path, mon, entry, dec, loop, fclk = _assemble(now)
    csv = _write_csv([_cand("MU", **CAND)], path="e2e_regime.csv", regime=None)
    write_regime(regime_path_for(csv), session_date="2000-01-03",
                 screener="sp500_v21", vcp_threshold=75.0, benchmark="^GSPC",
                 regime_ma=20, benchmark_close=110.0, benchmark_ma=100.0,
                 bar_date="2000-01-02", log=lambda m: None)
    seen = _capture(loop)
    armed, _rej = loop.arm_today(csv)
    check("stale sidecar: arms nothing", armed == [], f"{armed}")
    check("stale sidecar: the reason says STALE", any("STALE" in m for m in seen), f"{seen}")

    # (e) an --emit-threshold degraded run must never arm
    b, db, path, mon, entry, dec, loop, fclk = _assemble(now)
    csv = _write_csv([_cand("MU", **CAND)], path="e2e_regime.csv", regime=None)
    write_regime(regime_path_for(csv), session_date=SESSION, screener="sp500_v21",
                 vcp_threshold=70.0, degraded_threshold=70.0, benchmark="^GSPC",
                 regime_ma=20, benchmark_close=110.0, benchmark_ma=100.0,
                 bar_date=SESSION, log=lambda m: None)
    seen = _capture(loop)
    armed, _rej = loop.arm_today(csv)
    check("degraded run: arms nothing (supervised plumbing must never trade)",
          armed == [], f"{armed}")
    check("degraded run: the reason names emit-threshold",
          any("emit-threshold" in m for m in seen), f"{seen}")

    # (f) regime_ma=None disables the phase -> pre-Phase-3 behaviour exactly
    b, db, path, mon, entry, dec, loop, fclk = _assemble(now)
    loop.exposure = ExposureController(ExposureConfig(regime_ma=None))
    csv = _write_csv([_cand("MU", **CAND)], path="e2e_regime.csv", regime=None)
    seen = _capture(loop)
    armed, rej = loop.arm_today(csv)
    check("regime_ma=None: arms even with NO sidecar (the deployment control)",
          len(armed) == 1, f"{[r.reason for r in rej]}")


'''


def edit(text, old, new, label):
    n = text.count(old)
    if n != 1:
        raise SystemExit(f"REFUSING: anchor for {label} matched {n} times, expected 1")
    print(f"  ok  {label}")
    return text.replace(old, new)


def read(p):
    with open(p, encoding="utf-8") as f:
        return f.read()


def write(p, s):
    with open(p, "w", encoding="utf-8", newline="") as f:
        f.write(s)


def main(root):
    pl = os.path.join(root, "kistrader", "entry", "pipeline.py")
    sc = os.path.join(root, "kistrader", "entry", "screen_contract.py")
    ec = os.path.join(root, "kistrader", "entry", "exposure_controller.py")
    te = os.path.join(root, "tests", "test_pipeline_e2e.py")
    for p in (pl, sc, ec, te):
        if not os.path.isfile(p):
            raise SystemExit(f"REFUSING: not found: {p}")
    if "read_regime" not in read(sc):
        raise SystemExit("REFUSING: Phase 3a has not been applied.")
    s, t = read(pl), read(te)
    if "ExposureController" in s or "test_e7_regime_gate" in t:
        raise SystemExit("REFUSING: Phase 3c appears to be applied already.")

    # ---------------- pipeline.py (bottom-up) --------------------------------
    print(f"pipeline.py  ({pl})")
    s = edit(s, "        plans, drej = self.decision.plan(cands, account)\n",
             "        plans, drej = gated.plan(cands, account)\n",
             "arm_today: plan with the regime-gated config")
    s = edit(s, "        cands = fresh\n", "        cands = fresh\n" + GATE,
             "arm_today: read the sidecar and derive the ceiling")
    s = edit(s,
             "        self.auto_arm = auto_arm            # Step 6: unattended daily arm (opt-in)\n",
             "        self.auto_arm = auto_arm            # Step 6: unattended daily arm (opt-in)\n"
             "        # Regime gate (Phase 3c). Stateless and injectable; it takes NUMBERS,\n"
             "        # not a data source, so the caller owns the read and its failure path.\n"
             "        # ExposureConfig(regime_ma=None) disables it and reproduces the\n"
             "        # pre-Phase-3 behaviour exactly, which makes it the deployment control.\n"
             "        self.exposure = exposure or ExposureController()\n",
             "PipelineLoop: hold an ExposureController")
    s = edit(s, "                 auto_arm: bool = False, **kw):\n",
             "                 auto_arm: bool = False, exposure=None, **kw):\n",
             "PipelineLoop: accept an injected controller (tests)")
    s = edit(s, "from kistrader.entry.screen_contract import read_candidates\n",
             "from kistrader.entry.screen_contract import (read_candidates, read_regime,\n"
             "                                             regime_path_for)\n"
             "from kistrader.entry.exposure_controller import (ExposureController,\n"
             "                                                 ExposureState,\n"
             "                                                 apply_to_decision_config)\n",
             "import the sidecar reader and the controller")
    write(pl, s)

    # ---------------- tests (bottom-up) --------------------------------------
    print(f"test_pipeline_e2e.py  ({te})")
    t = edit(t, "    test_e6_freshness_gate()\n",
             "    test_e6_freshness_gate()\n    test_e7_regime_gate()\n",
             "register test_e7_regime_gate in main()")
    t = edit(t, "def test_zz_all_checks_passed():", E7 + "def test_zz_all_checks_passed():",
             "insert test_e7_regime_gate")
    t = edit(t, OLD_HELPER, NEW_HELPER,
             "_write_csv writes the sidecar too; add SESSION and _capture")
    t = edit(t, '          last_close=100.0, rs=90, s2=70, date="2026-07-06",\n',
             "          last_close=100.0, rs=90, s2=70, date=SESSION,\n",
             "_cand: take its session date from the single SESSION constant")
    # SESSION must exist BEFORE _cand: default arguments are evaluated at def time.
    t = edit(t, "def _cand(ticker=\"MU\"",
             'SESSION = "2026-07-06"          # the one date every e2e fixture is dated for\n'
             "\n\n"
             'def _cand(ticker="MU"',
             "declare SESSION above _cand (defaults evaluate at def time)")
    t = edit(t, "from kistrader.entry.screen_contract import Candidate, write_candidates\n",
             "from kistrader.entry.screen_contract import (Candidate, write_candidates,\n"
             "                                             write_regime, regime_path_for)\n"
             "from kistrader.entry.exposure_controller import (ExposureController,\n"
             "                                                 ExposureConfig)\n"
             "from kistrader.entry.decision_engine import DecisionEngine\n",
             "e2e imports")
    write(te, t)

    print("\nPHASE 3c APPLIED. The regime gate now binds in the trader.")
    print("Verify with:  python tests/test_pipeline_e2e.py")
    return 0


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("usage: python patch_phase3c.py <repo-root>")
    sys.exit(main(sys.argv[1]))
