#!/usr/bin/env python3
"""
trail_8cell -- is the SMA50 trail real, and is it the LENGTH or the TYPE?

WHY THIS EXISTS

partial_trail_ab showed the trail change worth +8 points of return and +48% on
weighted expectancy over one window at one cost level. That is one observation.
Rev 3's standard for every frozen parameter is harder: beat the control in BOTH
halves at ALL FOUR cost levels -- 8 cells -- because winning both halves is two
independent successes and cost monotonicity catches trade-set churn (Rev 3 sec.4).

It also decomposes a change that was bundled. "EMA21 -> SMA50" is TWO changes at
once: the type and the length. A 2x2 separates them:

    EMA21   the frozen control
    SMA21   type only
    EMA50   length only
    SMA50   both

The partial is held at the FROZEN 3R / one third in every arm. partial_trail_ab
measured the 2R / one half variant as harmful (return 16.58% -> 2.14%, weighted
expectancy -77%, winners truncated at breakeven), which matches Rev 3's own
be_trigger_r sweep. It is not re-tested here.

WINDOW

Clipped to Rev 3's window, 2018-01-01 onward, and split at 2022-06-30 -- the same
H1/H2 boundary Rev 3 uses. That also removes the reproduction gap: the earlier
run spanned 2015-2026 and could not be compared to Rev 3's numbers at all.

NO HARNESS EDIT. R_PARTIAL_MULTIPLE, PARTIAL_FRACTION and _ema are swapped at
runtime and restored in a finally. The harness sha256 is printed before and
after; if it moved, the run refuses its own output.

COST

4 arms x (2 halves x 4 cost levels + 1 full window) = 36 runs. Budget ~10 min
after the bar load. Progress prints per run.

LIMIT

Measures the HARNESS. F8 validated engine_v2 against it at the FROZEN constants
only -- and the EMA-lag invariance proof does NOT extend to a different
indicator at a different length. A win here is a reason to re-run F8 at the new
constants, never a production decision on its own.

USAGE (from the kis-backtest root)

    python trail_8cell.py
"""
from __future__ import annotations

import argparse
import hashlib
import math
import os
import pathlib
import pickle
import sys
import time
from dataclasses import replace

FROZEN = dict(rank_mode="vcp_only", vcp_threshold=75.0, stall_day=252,
              regime_ma=20, risk_per_trade_pct=0.0085, max_position_pct=0.25,
              partial_multiple=3.0, partial_fraction=1.0 / 3.0)

ARMS = [("EMA21", "ema", 21), ("SMA21", "sma", 21),
        ("EMA50", "ema", 50), ("SMA50", "sma", 50)]
CONTROL = "EMA21"
COSTS = (0.0, 5.0, 15.0, 30.0)          # bps, Rev 3 sec.4's four levels
SPLIT = "2022-06-30"                     # Rev 3's H1/H2 boundary
START = "2018-01-01"                     # Rev 3's window start


def sha(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest()[:16]


def trail(kind, span):
    if kind == "sma":
        # rolling() leaves NaN over the warm-up. NaN comparisons are False, so
        # the trail does not fire there -- it never invents an exit off three
        # bars. That is why min_periods is left at the default.
        return lambda close, span=span: close.rolling(span).mean()
    return lambda close, span=span: close.ewm(span=span, adjust=False).mean()


def _run_paired_se(m, fulleq, fulltr, K, a):
    """Print the measured paired floor beside the assumed one."""
    import numpy as np
    import pandas as pd
    print("\n" + "=" * 78)
    print("  PAIRED SE vs %s   (metric: %s)" % (CONTROL, K))
    print("  block=%d draws=%d seed=%d   PRE-REG: "
          "PREREG_20260920_S4_readjudication" % (a.block, a.draws, a.bs_seed))
    print("=" * 78)
    print("  %-10s %10s %10s %10s %8s %s"
          % ("arm", "point", "pairedSE", "unpairSE", "ratio", "|point|/pairedSE"))
    # POSITIVE CONTROL first: the control against ITSELF. Identical trade lists
    # must give a paired difference of exactly 0.0 in every draw. A non-zero
    # here means the pairing is wired wrong and every row below is void.
    ctl = _paired_se_block(m, np, pd, fulleq[CONTROL], fulltr[CONTROL],
                           fulleq[CONTROL], fulltr[CONTROL], K,
                           a.block, a.draws, a.bs_seed)
    if ctl is None or ctl[1] != 0.0 or ctl[0] != 0.0:
        print("  ** POSITIVE CONTROL FAILED: %s vs itself gave point=%s "
              "pairedSE=%s, expected 0.0 / 0.0. The pairing is wrong; "
              "everything below is VOID." % (CONTROL, ctl and ctl[0], ctl and ctl[1]))
        return
    print("  %-10s %10.4f %10.4f %10s %8s  POSITIVE CONTROL ok (exactly 0)"
          % (CONTROL + " vs self", ctl[0], ctl[1], "-", "-"))
    for arm, _k, _s in ARMS:
        if arm == CONTROL:
            continue
        r = _paired_se_block(m, np, pd, fulleq[CONTROL], fulltr[CONTROL],
                             fulleq[arm], fulltr[arm], K,
                             a.block, a.draws, a.bs_seed)
        if r is None:
            print("  %-10s  UNPAIRABLE (different calendars or block too long)"
                  % arm)
            continue
        point, se_p, se_u, ndays = r
        ratio = (se_u / se_p) if se_p > 0 else float("inf")
        z = abs(point) / se_p if se_p > 0 else float("inf")
        print("  %-10s %10.4f %10.4f %10.4f %8.2f %17.2f"
              % (arm, point, se_p, se_u, ratio, z))
    n_ctl = fullrun_trades_hint(fulltr)
    print("  ---")
    print("  the floor this REPLACES: 1.95/sqrt(%d) = %.4f -- single-arm, on an"
          % (n_ctl, 1.95 / max(n_ctl, 1) ** 0.5))
    print("  ASSUMED per-trade sd of 1.95, and n is the FULL window while the")
    print("  8-cell deltas it was compared against are per-half (~n/2).")
    print("  NOTE: point/pairedSE here is a FULL-WINDOW comparison. The 8-cell")
    print("  deltas are half-window; their floor is ~pairedSE * sqrt(2).")


def fullrun_trades_hint(fulltr):
    return len(fulltr.get(CONTROL, []))


def _metric_of(trades, K, m, np):
    """One metric from a trade list. Only the two trade-based metrics are
    needed: the block draw supplies the calendar, not an equity curve."""
    if not trades:
        return float("nan")
    if K == "expectancy_R_weighted":
        return float(np.mean([m._weighted_r(t) for t in trades]))
    return float(np.mean([t.r_at_exit for t in trades]))


def _paired_se_block(m, np, pd, eqA, trA, eqB, trB, K, block, draws, seed):
    """Moving-block paired bootstrap of (B - A) on metric K.

    Mirrors paired_bootstrap.py's draw loop. Blocks are drawn over the SHARED
    calendar; a trade enters a draw when its exit date is in the drawn days, so
    both arms are scored on exactly the same resampled window. That shared
    window is the whole point -- an unpaired SE of the same two arms is larger
    by the arms' correlation, which for two trails on nearly the same book is
    not small.

    Returns (point, paired_se, unpaired_se, n_days) or None if unpairable.
    """
    a_idx = eqA.dropna().index
    b_idx = eqB.dropna().index
    if not a_idx.equals(b_idx):
        # FAIL CLOSED, as paired_bootstrap does: pairing across different
        # calendars would silently compare different windows.
        return None
    idx = a_idx
    n = len(idx)
    L = max(1, int(block))
    if n <= L:
        return None
    dates = idx.normalize().to_numpy()
    byA, byB = {}, {}
    for t in trA:
        byA.setdefault(pd.Timestamp(t.exit_date).normalize(), []).append(t)
    for t in trB:
        byB.setdefault(pd.Timestamp(t.exit_date).normalize(), []).append(t)

    rng = np.random.default_rng(seed)
    nblocks = int(np.ceil(n / L))
    dif, sa, sb = [], [], []
    for _ in range(int(draws)):
        starts = rng.integers(0, n - L + 1, size=nblocks)
        pos = np.concatenate([np.arange(s, s + L) for s in starts])[:n]
        tA, tB = [], []
        for d in dates[pos]:
            key = pd.Timestamp(d)
            if key in byA:
                tA.extend(byA[key])
            if key in byB:
                tB.extend(byB[key])
        mA = _metric_of(tA, K, m, np)
        mB = _metric_of(tB, K, m, np)
        if mA == mA and mB == mB:               # both defined
            dif.append(mB - mA)
            sa.append(mA)
            sb.append(mB)
    if len(dif) < 2:
        return None
    d = np.asarray(dif, dtype=float)
    se_p = float(d.std(ddof=1))
    se_u = float(np.sqrt(np.asarray(sa).std(ddof=1) ** 2
                         + np.asarray(sb).std(ddof=1) ** 2))
    point = (_metric_of(trB, K, m, np) - _metric_of(trA, K, m, np))
    return point, se_p, se_u, n


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", default=".")
    ap.add_argument("--bars", default="data/bars")
    # --- PATCH L (L3) --- the default was data/signals.pkl, the WEEKLY file
    # (every=5). Rev 3's window is data/signals_daily.pkl natively. This was the
    # one unstated input in an otherwise correctly pinned script.
    ap.add_argument("--signals", required=True,
                    help="REQUIRED. data/signals_daily.pkl is every=1 and is "
                         "Rev 3's window; data/signals.pkl is every=5.")
    ap.add_argument("--sectors", default="data/sectors.csv")
    ap.add_argument("--metric", default="expectancy_R_weighted")
    # --- S4 re-adjudication 2026-09-20 --- OFF by default, so a plain run is
    # byte-identical to the one that produced RESULT_20260828_S4_trail_null.
    ap.add_argument("--paired-se", action="store_true",
                    help="measure the PAIRED SE of the difference vs the "
                         "control, by moving-block bootstrap. The printed "
                         "1.95/sqrt(n) floor is single-arm and assumed; this "
                         "one is paired and measured.")
    ap.add_argument("--block", type=int, default=21,
                    help="--paired-se: block length in trading days")
    ap.add_argument("--draws", type=int, default=2000,
                    help="--paired-se: bootstrap draws")
    ap.add_argument("--bs-seed", type=int, default=12345,
                    help="--paired-se: CHANGES THE NUMBERS. Printed with it.")
    # --- PATCH L (L3) --- exposed so the PRODUCTION configuration can be run
    # against the Rev 3 one. rank_mode / threshold / stall_day stay pinned in
    # code: this script's identity is a frozen-set A/B.
    ap.add_argument("--sector-cap", type=int, default=2,
                    help="2 is Rev 3 (the vendored default); production runs 0 "
                         "since PATCH F. expectancy_R_weighted is size-SENSITIVE, "
                         "so the cap is not guaranteed neutral on it the way "
                         "corrections v2 sec.6.1 measured it to be on expectancy_R.")
    ap.add_argument("--regime-ma", default="20",
                    help="20 is Rev 3; 'off' is what production has run since "
                         "PATCH F3 (2026-08-25).")
    a = ap.parse_args()
    _rma = (None if str(a.regime_ma).strip().lower() in ("off", "none", "0")
            else int(a.regime_ma))
    RUN = dict(FROZEN, regime_ma=_rma, sector_cap=a.sector_cap,
               signals=a.signals)

    root = os.path.abspath(a.repo)
    sys.path.insert(0, root)
    hpath = os.path.join(root, "minervini_backtest.py")
    if not os.path.isfile(hpath):
        print("FATAL: no minervini_backtest.py under %r" % root)
        return 2
    before = sha(hpath)

    import pandas as pd
    import minervini_backtest as m

    print("=" * 78)
    print("  TRAIL 8-CELL -- length vs type, both halves, four cost levels")
    print("=" * 78)
    print("  harness : %s  sha %s" % (hpath, before))
    print("  config  : %s" % RUN)                       # PATCH L (L3)
    if _rma is None or a.sector_cap != 2:
        print("  NOTE    : this is NOT the Rev 3 configuration "
              "(regime_ma=20, sector_cap=2). Comparable within this run, "
              "not to Rev 3's published numbers.")
    print("  window  : %s onward, split at %s" % (START, SPLIT))

    bars_dir = pathlib.Path(a.bars)
    if not bars_dir.is_dir():
        print("FATAL: no bar directory at %r" % str(bars_dir))
        return 2
    t0 = time.time()
    bars = {p.stem: pd.read_parquet(p) for p in bars_dir.glob("*.parquet")}
    prices = {t: d for t, d in bars.items() if t != "^GSPC"}
    bench = bars.get("^GSPC")
    if bench is None:
        print("FATAL: no ^GSPC bars; regime_ma=20 fails closed without it.")
        return 2
    with open(a.signals, "rb") as f:
        allsig = pickle.load(f)["signals"]
    smap = m.load_sector_map(a.sectors)

    lo, hi = pd.Timestamp(START), pd.Timestamp(SPLIT)
    full = {d: v for d, v in allsig.items() if pd.Timestamp(d) >= lo}
    H1 = {d: v for d, v in full.items() if pd.Timestamp(d) <= hi}
    H2 = {d: v for d, v in full.items() if pd.Timestamp(d) > hi}
    for name, s in (("full", full), ("H1", H1), ("H2", H2)):
        if not s:
            print("FATAL: %s window has no signals. Check --signals and the "
                  "window constants." % name)
            return 2
    print("  signals : full %d dates   H1 %d   H2 %d   (of %d before clipping)"
          % (len(full), len(H1), len(H2), len(allsig)))

    base = m.BacktestConfig(
        rank_mode=FROZEN["rank_mode"], equity_mode="compounding",
        entry_mode="pivot_limit", ambiguity_mode="worst",
        vcp_threshold=FROZEN["vcp_threshold"], stall_day=FROZEN["stall_day"],
        regime_ma=RUN["regime_ma"], sector_map=smap,            # PATCH L (L3)
        decision=m.DecisionConfig(
            risk_per_trade_pct=FROZEN["risk_per_trade_pct"],
            max_position_pct=FROZEN["max_position_pct"],
            sector_cap=RUN["sector_cap"]),                      # PATCH L (L3)
        benchmark_close=bench["Close"])

    keep = (m.R_PARTIAL_MULTIPLE, m.PARTIAL_FRACTION, m._ema)
    cells, fullrun = {}, {}
    fulleq, fulltr = {}, {}                  # --- S4 re-adjudication ---
    t_start = time.time()
    try:
        # partial pinned to frozen in EVERY arm -- the 2R/half variant is out
        m.R_PARTIAL_MULTIPLE = FROZEN["partial_multiple"]
        m.PARTIAL_FRACTION = FROZEN["partial_fraction"]
        for arm, kind, span in ARMS:
            m._ema = trail(kind, span)
            _e, _t, st, _d, _g = m.run(prices, full, replace(base, slippage_bps=5.0))
            fullrun[arm] = st
            # --- S4 re-adjudication --- the curve and the trades were thrown
            # away here. The paired bootstrap needs both; nothing else reads
            # them, so this is inert unless --paired-se is passed.
            fulleq[arm], fulltr[arm] = _e, _t
            print("  %-6s full-window 5bps  %4d trades  ret %+7.2f%%  dd %7.2f%%"
                  % (arm, st["num_trades"], st["total_return_pct"],
                     st["max_drawdown_pct"]))
            for half, sig in (("H1", H1), ("H2", H2)):
                for bps in COSTS:
                    _e, _t, st, _d, _g = m.run(prices, sig,
                                               replace(base, slippage_bps=bps))
                    cells[(arm, half, bps)] = st
            print("     %s 8 cells done   elapsed %.0fs" % (arm, time.time() - t_start))
    finally:
        m.R_PARTIAL_MULTIPLE, m.PARTIAL_FRACTION, m._ema = keep

    after = sha(hpath)
    if after != before:
        print("  ** HARNESS MODIFIED during the run (%s -> %s). Output void."
              % (before, after))
        return 1
    print("  harness sha after: %s  UNCHANGED" % after)

    K = a.metric
    if K not in fullrun[CONTROL]:
        print("\n  *** %s missing -- this harness predates commit e607db9 "
              "(patch 1)." % K)
        print("  *** Falling back to expectancy_R. Comparable here because the")
        print("  *** partial rule is IDENTICAL in every arm, so the runner-only")
        print("  *** bias is the same on both sides of each comparison.")
        K = "expectancy_R"

    print("\n" + "=" * 78)
    print("  FULL WINDOW, 5 bps")
    print("=" * 78)
    print("  %-8s %8s %9s %9s %10s %10s" %
          ("arm", "trades", "ret%", "dd%", K.split("_")[-1], "ret/|dd|"))
    for arm, _k, _s in ARMS:
        s = fullrun[arm]
        rr = s["total_return_pct"] / abs(s["max_drawdown_pct"]) if s["max_drawdown_pct"] else 0.0
        print("  %-8s %8d %9.2f %9.2f %10.3f %10.3f"
              % (arm, s["num_trades"], s["total_return_pct"],
                 s["max_drawdown_pct"], s[K], rr))

    print("\n" + "=" * 78)
    print("  8-CELL DOMINANCE vs %s   (metric: %s)" % (CONTROL, K))
    print("=" * 78)
    print("  %-8s %-4s %s" % ("arm", "half", "".join("%12s" % ("%gbps" % c) for c in COSTS)))
    for arm, _k, _s in ARMS:
        if arm == CONTROL:
            continue
        won = dd_won = 0
        for half in ("H1", "H2"):
            row = ""
            for bps in COSTS:
                d = cells[(arm, half, bps)][K] - cells[(CONTROL, half, bps)][K]
                dd = (abs(cells[(arm, half, bps)]["max_drawdown_pct"])
                      - abs(cells[(CONTROL, half, bps)]["max_drawdown_pct"]))
                won += d > 0
                dd_won += dd < 0                     # smaller drawdown is better
                row += "%12s" % ("%+.3f" % d)
            print("  %-8s %-4s %s" % (arm if half == "H1" else "", half, row))
        n = cells[(CONTROL, "H1", 5.0)]["num_trades"] + cells[(CONTROL, "H2", 5.0)]["num_trades"]
        se = 1.95 / math.sqrt(max(n, 1))
        print("  %-8s ---> %d / 8 cells on %s,  %d / 8 on drawdown   "
              "(SE ~%.3f R at n=%d)" % ("", won, K.split("_")[-1], dd_won, se, n))
        print()

    if a.paired_se:
        _run_paired_se(m, fulleq, fulltr, K, a)

    print("=" * 78)
    print("  HOW TO READ IT (Rev 3 sec.4)")
    print("   8/8  beats the control in both halves at every cost level. That is")
    print("        the bar every frozen parameter had to clear.")
    print("   4/8  wins one half, loses the other -- regime_150's exact failure.")
    print("        A parameter must hold in BOTH. Not a choice; a rule.")
    print("   Non-monotone across a cost row = the trade set moved, so that rank")
    print("        is churn, not signal (F1).")
    print()
    print("  SMA21 isolates TYPE. EMA50 isolates LENGTH. If EMA50 carries most of")
    print("  SMA50's gain, the win is the slower trail and the SMA is incidental.")
    print()
    print("  HARNESS ONLY. Re-run F8 at any winning constants before believing")
    print("  production would do the same. The EMA-lag invariance proof does not")
    print("  cover a different indicator at a different length.")
    print("=" * 78)
    return 0


if __name__ == "__main__":
    sys.exit(main())
