# FINDING — 2026-09-17: `tvol` has no lag. S2's gate is unreachable by arithmetic.

E9 has been blocked since 2026-09-04 on one unmeasured prerequisite: *"the mock's
`tvol` appears ~15 minutes delayed; measure it before believing a THIN verdict."*

Measured today. **There is no delay.** And the measurement surfaced a different
defect that makes the gate it guards unpassable at any threshold.

---

## 1. The instrument

`~/tvol_probe.py` on the box, 10:23 → 20:05 UTC, one call per minute to
`inquire-price` (TR `HHDFS00000300`) for AAPL, recording `utc, tvol, last, rt_cd`.
Token issued once at startup so the session made no `/oauth2/tokenP` call.

Deliberately started **three hours before the open** — the pre-open rows are what
made both findings visible, and neither would have appeared in a probe that began
at 13:30.

## 2. No lag. The step lands AT the open.

```
minute   tvol          delta       per-min
13:25      188,328
13:26      193,170       4,842       4,842
13:27      194,835       1,665       1,665
13:28      205,398      10,563      10,563
13:29      212,856       7,458       7,458
13:30      782,458     569,602     569,602   <- 43 seconds after the open
13:33    1,097,856     315,398     105,132
13:37    1,571,600     108,706     108,706
13:40    1,856,999     285,399      95,133
```

Pre-open rate 13:25–13:29: **6,132/min**. Open minute: **569,602** — a **93×** step,
at 13:30:43. A 15-minute lag would have put that step at 13:45. It is not there.

**The premise was false.** Every `THIN` verdict was read under a suspicion that the
data does not support.

## 3. And `tvol` never resets — pre-market is included

`212,856 → 782,458` carries straight through the session boundary. There is no
reset. Confirmed further by the pre-open series: 42,679 at 10:23 growing steadily
to 212,856 by 13:29, accelerating into the open (705/min early, 6,132/min by
13:25) — the signature of live pre-market accumulation, not a stale field.

Both statements in `get_session_volume`'s own docstring are wrong:

> *"None on every failure path, INCLUDING a literal 0: before the open a zero is
> not the fact 'nothing traded', it is 'no session yet'."*

There is no zero before the open. `tvol` is counting pre-market the whole time.

## 4. The real defect: a daily-bar criterion evaluated at an intraday instant

S2 asks:

```
cum_session_volume_so_far   >=   1.5 x avg_vol_50
```

The left side is however many minutes have elapsed. The right side is **one and a
half full trading days**. At a trigger two minutes after the open, passing requires
150% of a day's volume in two minutes.

It cannot pass. Not for CORT, not for any ticker, not on any day, at any threshold.
The session is 390 minutes; the gate is unreachable until cumulative volume exceeds
1.5 days, which by construction cannot happen before the close of a day that itself
trades 150% of average — and entries are decided in the first minutes.

The recorded verdict makes sense only in this light:

```
2026-09-09 13:32:33 CORT TRIGGERED last=116.00 >= pivot=115.78
  [volume THIN: volume 6676 < 1.5x avg_vol_50 1077698 (need 1616547)]
```

`6,676` was never a statement about CORT. It is two minutes of a normal session
measured against a day and a half.

Minervini's criterion is a **daily-bar** rule: the breakout *day* closes on elevated
volume. The implementation applies it to an intraday instant. That is the bug, and
no value of `breakout_volume_multiple` repairs it.

## 5. Consequences

**`--require-breakout-volume` must not be turned on as built.** It would hold
**100%** of breakouts, permanently, and the logs would read as a quiet market rather
than a dead gate. It shipped OFF and diagnostic-first (`DEPLOY_CLOSE_20260905` §5),
which is the only reason this is a finding and not an outage. That decision was
right for a reason nobody knew at the time.

**Every `THIN` verdict to date is a structural artifact.** None of them carry
information about a stock.

## 6. E9 can close, on the divergence branch

`HANDOFF_PHASE_E_20260908` §2 states the closing condition:

> enough real verdicts to justify passing `--require-breakout-volume`, or to record
> live volume confirmation as a **permanent divergence**.

This is the divergence branch, and now with a measured reason rather than a hunch:
**a daily-bar volume criterion is not implementable as a live intraday gate.** The
entry decision happens minutes into the session; the criterion is about the whole
day. Those cannot be reconciled by tuning.

The alternative, if it is ever wanted, is a **time-of-day-adjusted denominator** —
`avg_vol_50 x elapsed_session_fraction`, or same-time-of-day historical volume.
Both need an intraday volume curve this project does not have, and both *change* the
criterion rather than implementing it. That is a scoping decision, not a fix.

Recommended: record the divergence, keep the provider ON as a diagnostic (it costs
nothing and the numbers are now interpretable), and leave the enforcement flag
permanently unpassed with a comment naming this document.

## 7. Side confirmation, third instrument

4 of the 16 samples in the 13:25–13:45 window returned `rt_cd=1` — **25%**, matching
the open-hours rejection rate measured yesterday on completely different endpoints
(`FINDING_20260916` §8.3: psamount 34.7%, balance 28.0%, quote 10.2%). A third
instrument, same window, same answer.

## 8. What this cost, and the method note

The lag was assumed on 09-04, carried on the ledger for 13 days as E9's blocker, and
was never true. One probe, started three hours early, answered it in a single
session — and the three hours of pre-open rows, which existed only because the probe
was started before the market rather than at it, are what produced §3 as well.
