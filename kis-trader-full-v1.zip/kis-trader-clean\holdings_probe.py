#!/usr/bin/env python3
"""
holdings_probe.py — diagnose "periodic: holdings unreadable".
=============================================================

THE PROBLEM IT SOLVES
  ExecutionMonitor.reconcile() alerts "holdings unreadable — reconcile skipped"
  whenever get_all_holdings() returns None, but the REASON never reaches the log.
  Tracing the source: get_all_holdings -> _balance_rows -> _request_paged, and
  _balance_rows returns None the moment _failed(res) is true, where

      _failed(res) = res["_transport_error"] or res["rt_cd"] not in ("0", None)

  so exactly two failure families are possible, and they need opposite fixes:

    TRANSPORT  network/DNS/timeout/bad-JSON after HTTP_RETRIES. Environmental —
               flaky link, VPN, DNS. Fix the box or accept it and let the
               supervisor+deadman cover it.
    API        KIS answered but refused: rt_cd != "0". Read msg_cd/msg1 — rate
               limiting (초당 거래건수 초과), an expired/rotated token, a bad
               TR id, or an account/permission issue. Each has a different fix.

  Observed 2026-07-23 at 03:16, 03:36, 04:34, 04:50 — but at 04:55 the same call
  SUCCEEDED (it reported broker=0 for F). So it is INTERMITTENT, which already
  rules out a permanently wrong TR id or a dead credential. This probe runs the
  identical request on a timer and prints what comes back, so the family (and,
  if API, the exact msg) is confirmed rather than inferred.

  Why it matters: the exit engine clamps every SELL to confirmed holdings
  (_advance_exit section 2: `held is None -> return`). A read failure at the
  wrong moment does not just skip a reconcile — it can DELAY A STOP EXIT.

USAGE
  python holdings_probe.py                  # 20 calls, 5s apart (~100s)
  python holdings_probe.py -n 60 -i 10      # 10 minutes of coverage
  python holdings_probe.py --verbose        # dump the full JSON of failures
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from datetime import datetime


def main() -> int:
    ap = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("-n", "--count", type=int, default=20, help="number of calls")
    ap.add_argument("-i", "--interval", type=float, default=5.0, help="seconds between calls")
    ap.add_argument("--verbose", action="store_true", help="dump full JSON on failure")
    args = ap.parse_args()

    from kistrader.config import Config
    from kistrader.core import engine_v2 as E
    from kistrader.entry.entry_manager import KISBrokerWithEntry

    cfg = Config.from_env()
    b = KISBrokerWithEntry(cfg.app_key, cfg.app_secret, cfg.cano, is_mock=cfg.is_mock)
    tr = E.TR_BALANCE_MOCK if cfg.is_mock else E.TR_BALANCE_LIVE

    print(f"probing inquire-balance  mock={cfg.is_mock}  tr_id={tr}  "
          f"n={args.count} every {args.interval}s")
    print("-" * 78)

    ok = 0
    transport = 0
    token_limited = 0
    api: dict = {}

    for i in range(1, args.count + 1):
        t = datetime.now().strftime("%H:%M:%S")
        try:
            # the EXACT request get_all_holdings() makes (first page)
            res, cont = b._request_paged(
                "GET", f"{b.base_url}/uapi/overseas-stock/v1/trading/inquire-balance",
                headers=b._headers(tr, ""),
                params={"CANO": b.cano, "ACNT_PRDT_CD": b.acnt_prdt_cd,
                        "OVRS_EXCG_CD": "NASD", "TR_CRCY_CD": "USD",
                        "CTX_AREA_FK200": "", "CTX_AREA_NK200": ""})
        except Exception as ex:                                    # noqa: BLE001
            msg = str(ex)
            # _ensure_token() RAISES (engine_v2:208) rather than returning a
            # tagged dict, so a token failure never looks like a transport dict.
            # EGW00133 = KIS refuses more than ONE token issuance per minute.
            if "EGW00133" in msg or "token issuance failed" in msg:
                token_limited += 1
                print(f"[{i:>3}] {t}  TOKEN-RATE-LIMIT  (1 issuance/min) {msg[:110]}")
            else:
                transport += 1
                print(f"[{i:>3}] {t}  RAISED  {type(ex).__name__}: {msg[:110]}")
            time.sleep(args.interval)
            continue

        rt = res.get("rt_cd")
        if res.get("_transport_error"):
            transport += 1
            print(f"[{i:>3}] {t}  TRANSPORT  {res.get('msg1')}")
        elif rt not in ("0", None):
            key = f"rt_cd={rt} msg_cd={res.get('msg_cd')} msg1={(res.get('msg1') or '').strip()}"
            api[key] = api.get(key, 0) + 1
            print(f"[{i:>3}] {t}  API-REJECT  {key}")
            if args.verbose:
                print(json.dumps(res, ensure_ascii=False, indent=2)[:1500])
        else:
            ok += 1
            rows = res.get("output1") or []
            tickers = {r.get("ovrs_pdno"): r.get("ovrs_cblc_qty") for r in rows
                       if r.get("ovrs_pdno")}
            print(f"[{i:>3}] {t}  OK  {len(rows)} row(s)  tr_cont={cont!r}  {tickers}")
        time.sleep(args.interval)

    print("-" * 78)
    total = args.count
    print(f"SUMMARY  ok={ok}/{total}  transport-fail={transport}  "
          f"token-rate-limit={token_limited}  api-reject={sum(api.values())}")
    for k, v in api.items():
        print(f"  x{v}  {k}")
    if token_limited:
        print("VERDICT: TOKEN RATE LIMIT (EGW00133) — KIS allows ONE access-token "
              "issuance per minute per app key. Every NEW process issues its own "
              "token, so this fires when two tools start within a minute of each "
              "other, or when a crashed loop is restarted too fast. See the "
              "supervisor backoff note in cloud_provisioning.md. NOT a network "
              "fault and NOT the account being unhealthy.")
    if transport and not api:
        print("VERDICT: transport/environmental — network, DNS or timeouts. The "
              "supervisor+deadman cover this; consider a wired link for the soak.")
    elif api and not transport:
        print("VERDICT: KIS is REFUSING the call. Read msg1 above — rate limiting, "
              "token rotation and permissions each need a different fix.")
    elif api and transport:
        print("VERDICT: BOTH families present — treat them separately.")
    elif ok == total:
        print("VERDICT: no failure reproduced in this window. Re-run during a live "
              "session with the loop also running (contention is a suspect).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
