# PARAMETER_FREEZE Rev 3 — corrections, v2 (2026-08-23)

**Supersedes `FREEZE_REV3_CORRECTIONS_20260822.md`.** That document is not
edited; this one says which of its entries are now closed, which are corrected,
and what is new. Rev 3's own numbers remain untouched — `param_snapshot`
validates the live set against them on every boot, so editing a number in that
document *is* changing the frozen set. Nothing here does that.

> **Provenance.** Sections 1–9 were written before `PARAMETER_FREEZE_2026-08-11.md`
> was available, and are measured against the CODE and against the v1 corrections
> appendix. **Rev 3 was located and read on 2026-08-23** — see sec.10, which
> settles the arithmetic items sec.7 had to leave open. **The whole document,
> sec.0 through the sec.12 appendix, has now been read.**

---

## 1. The frozen values — still unchanged, still enforced

No change from v1 sec.1. Fifteen parameters; re-measured 2026-08-23 on the
laptop tree, `param_snapshot` **exit 0**, all fifteen matching.

**Do not read that as "the box also matches."** v1 sec.1 records the box running
`VCP_SCORE_THRESHOLD = 45` as a deliberate TECHNICAL soak value, where
`param_snapshot` prints `**` and **exits 1**, `boot_log` refuses any live boot,
and `pytest` reads 84/2 with two drift guards red. All four are the guard
working as designed. Revert to 75 when the TECHNICAL phase ends. The exit-0
above is the laptop reference tree, not the deployed set.

See sec.6 below for what that guard does **not** cover, which is more than
anyone had counted.

---

## 2. F8 — CLOSED

v1 sec.4 listed F8 first among the still-open items, quoting Rev 3 sec.6: *"the
largest single unvalidated assumption in the project."*

**It is now closed.** A differential fixture drives the real `engine_v2` over
daily bars with an in-memory broker and a fake clock, and compares its exits
against `minervini_backtest`'s.

That is Rev 3's own recommendation, followed to the letter — **sec.12 Option A**:
*"Feed `engine_v2` a synthetic bar sequence … doubles as the fix for F8 … the
same fixture can assert both engines produce identical exits. Highest value per
hour on the list."* (v1 cited this as "sec.10", and sec.10 is
*Discipline added this session*. The citation was wrong; the recommendation was
right. Corrected here.)

```
17 hand-built cases          98/98 checks green
12,000 random scenarios      11,950 agree / 50 disagree, all in 2 pinned classes
                             exit 0, no unknown divergence
sabotage: 5 defects planted in the HARNESS, each surfaced in the diff
sabotage: 4 defects planted in engine_v2, each caught; 1 proven unreachable
```

Reproduced independently on the target machine, bit-identical to the development
run — same 11,950/50 split, same class counts, same scenario ids — across a
different OS and Python.

**Rev 3's exit statistics can now be quoted** — payoff 3.20:1, avg win +20.15% /
avg loss −6.41%, the exit-reason breakdown — subject to sec.4 below, which is an
accounting question rather than a logic one.

### 2.1 Two characterised divergences remain, both conservative

The harness decides the +3R partial from the bar's HIGH alone and fills it at
exactly the +3R level, **ignoring the OPEN** — even though it already honours
the open for the stop (`o if o < pos.stop_loss_price else pos.stop_loss_price`).

- **Bar opens above +3R.** Production polls from the open, sees 136, and fires
  the partial there; the harness books 130. **48 of 1,013 partialled trades
  (4.7%)** in a 12,000-trial sweep.
- **Opens above +3R and also trades below the original stop.** The harness calls
  it ambiguous and applies stop-first, but the open pins the ordering — the +3R
  was reached before any decline was possible. Production books **+1.0R**, the
  harness **−1.0R**. A **2.0R divergence**, 2 in 12,000.

Both understate, so Rev 3 remains a lower bound in this respect. Both are pinned
as regression cases 10 and 11: the fixture asserts the harness produces exactly
those wrong values, so the divergence cannot drift unnoticed in either direction.

### 2.2 Two results that stand on their own

- **The stop-vs-partial precedence in `_on_tick` can never bind.** Before the
  partial, `price <= stop` implies `r <= −1`, never `>= 3`; after it,
  `partial_done` closes the branch permanently. A sabotage that flipped the two
  branches changed nothing in any of 14 cases. **The same-bar question is decided
  entirely by the backtest's ambiguity convention** — there is nothing on the
  production side to diff against.
- **The EMA trail decision is invariant to EMA lag.** Since
  `e_t = k·c_t + (1−k)·e_{t−1}`, `c_t < e_t ⟺ c_t < e_{t−1}` for any
  `0 < k < 1`. Proven algebraically and over 572,181 pairs. The harness's
  `ewm(adjust=False)` versus production's SMA-seeded EMA differ by at most 0.01%
  of price with **zero decision flips**. The indicator is ruled out as a source
  of `EMA_BREAK` divergence.

---

## 3. v1 sec.3 — "the fill rule is wrong" — FALSIFIED, CLOSED 2026-08-23

v1 called this *"the biggest correction"* and budgeted roughly three hours,
stating the harness fills on `high >= limit`.

**`minervini_backtest.py` does not contain that rule.** Lines 615–631, comments
and `armed.pop(tkr)` bookkeeping elided:

```python
if o > plan.limit_price:                                    # 615
    ...
    ambiguous_bars += 1                                     # 623
    if cfg.ambiguity_mode == "best" and lo <= plan.limit_price:
        try_fill(tkr, plan, plan.limit_price, d)
    else:
        drops.add(d, tkr, "gap_above_limit: resting limit unfilled")   # 627
    armed.pop(tkr)
elif h >= plan.pivot:                                       # 629
    try_fill(tkr, plan, plan.limit_price, d)
    armed.pop(tkr)
```

That is the corrected rule v1 asks for: a gap above the limit is **refused**
under `worst`, and the trigger is `high >= pivot` with the fill at the capped
limit. `grep` finds no `high >= limit` path anywhere in the file's 1363 lines,
and the file is dated 2026-08-11 — the freeze-era file.

### 3.1 The dated evidence — v1 was wrong when it was written

An independent backup taken **2026-08-16 00:46** was measured on 2026-08-23:

```
kis_backup_2026-08-16_0046\...\minervini_backtest.py
  newline-normalised sha256  76ad11f4185db927379d90fe144e732c689c4a1d46b40d67de37146a43ee821e
  == the pre-patch harness, byte for byte

  line 620   # ENTRY_TIMEOUT_SECS (120s) before the order is cancelled.
  line 627   drops.add(d, tkr, "gap_above_limit: resting limit unfilled")
  line 629   elif h >= plan.pivot:
```

**The same three markers, at the same three line numbers, six days before v1 was
written.** The gap-above-limit refusal and the 120-second-timeout reasoning were
already in the file; the file did not change between then and now. Only two
copies of the harness exist on the machine — this backup and the live one — so
there is no third version for v1 to have been describing.

**v1 sec.3 was incorrect at the time of writing, not superseded. The ~3 hours it
budgets are cancelled.**

What survives is the modelling question, not a code fix. The harness fills every
non-gap trigger at the capped limit; production arms at the pivot break and
places the same capped limit, which is *above* market and therefore marketable —
so the non-gap case is modelled correctly, and pessimistically (it pays the cap
rather than the pivot). The gap case, where production's order rests below market
and usually dies inside `ENTRY_TIMEOUT_SECS`, is the one v1's "roughly 1 trigger
in 7" describes, and the harness already refuses it under `worst` and counts it
as the fourth ambiguity class.

The open question is empirical: **is fill rate correlated with VCP score?** That
is a sweep to run, not an hour of editing.

---

## 4. NEW — `expectancy_R` is not expectancy per trade

`_summarize` line 972: `expectancy_R = mean(t.r_at_exit)`, and `r_at_exit` is
the **runner leg's per-share R**, computed after `pos.shares` was reduced by the
+3R partial. The partial's proceeds go to `cash` and, by the harness's own
comment at line 700, *"NEVER appears in any Trade record, because Trade.shares
is the reduced runner count."*

```
runner r_at_exit   booked   share-weighted   error
         -1.000    -1.000           0.333    -1.333
          0.000     0.000           1.000    -1.000
          3.000     3.000           3.000     0.000
          3.398     3.398           3.265    +0.133
```

The crossover is at runner-R 3.0: below it the label understates, above it it
**overstates**. Rev 3's `EMA_BREAK` mean exit is +3.398R and `STOP_HIT` is
−1.071R, so **the two populations are biased in opposite directions** and the net
effect on +0.330R is not signable without measuring it.

Rev 3 R2 records 57 of 200 trades reaching the trail via the partial — that is
the affected population, and partial frequency varies by threshold band, so the
bias is **not constant across the comparison the sweep exists to make.**

**Money numbers were never affected.** `total_return_pct`, `cagr_pct` and
`max_drawdown_pct` come off the equity curve, which does include the partial.

**Now measurable.** `expectancy_R_weighted` and `partialled_trades` are added
alongside — never replacing `expectancy_R`, because `06_sweep.py` line 31's
FALLACY-4 test depends on it being position-size invariant and the weighted
figure is not. Whether Rev 3's headline should be restated is a **data decision**:
run a sweep and compare the two columns.

---

## 5. v1 sec.5's footgun — measured, and its prescribed fix was BACKWARDS

v1 sec.5 warned that the vendored `decision_engine.py` defaults to
`risk 0.0075 / cap 0.20`. **Confirmed live**, and now guarded — `06_sweep.py`
refuses to run without explicit `--risk-pct` and `--max-position-pct`.

But v1 sec.5 then prescribed: *"A correct fix extends `RANK_WEIGHTS` to three
weights."* Measured, the framing is inverted:

| engine the harness imports | `rs_only` | `vcp_only` | `rs_plus_vcp` |
|---|---|---|---|
| **vendored 2-weight** — what is live, what Rev 3 ran | correct | correct | correct |
| production 3-weight | **REVERSED** | correct | wrong ratio |

`06_sweep.py` line 3 inserts the repo root at `sys.path[0]`, so a real sweep gets
the vendored copy, and a conflicting-order fixture confirms all three modes rank
on what their names claim. **The trap is LATENT. Deleting the vendored copy — the
"fix" every prior document proposes — is precisely what springs it.**

`rs_only` is the mode at risk, it is `06_sweep.py`'s **default**, and the damage
is worst exactly where real data lives: Stage 1 has already filtered to high RS,
so survivors cluster and the stray `vcp_weight` term dominates. On a realistic
tight-RS fixture `rs_only` ranks in **perfect reverse-RS order**.

**Consequence: Rev 3 sec.11's mode comparison is VALID.**

Guarded rather than fixed: `harness_snapshot.py` resolves and sha256-pins the
imported engine, classifies it, **proves** each mode against the conflicting-order
fixture instead of reading the weights, and stops the run on any mismatch.

---

## 6. NEW — production's own guard covers less than anyone counted

`param_snapshot.py` validates **15** parameters. Measured against the live code,
these strategy parameters are **not** guarded — change any and a live boot still
reports *"All parameters match"*:

```
DecisionConfig   -- all 12 unguarded fields
                 sector_cap 2 · require_trade_signal False · min_shares 1
                 stop_buffer_pct 0.005 · atr_mult_min 1.3 · atr_mult_max 2.5
                 depth_shallow 0.08 · depth_deep 0.25 · entry_chase_pct 0.005
                 max_extension_pct 0.05
                 allow_missing_close False · require_atr False   <- FAIL-CLOSED SWITCHES
engine_v2        -- 38 unguarded module constants; the ones that decide behaviour
                 PARTIAL_FRACTION 0.3333 · BASE_EXIT_SLIP 0.02 · MAX_SLIP 0.09
                 SETTLE_SECS 8 · EXIT_FLAT_CONFIRM_SECS 15.0 · PRICE_BAND 0.10
                 TR_SELL_LIVE TTTT1006U · TR_SELL_MOCK VTTT1001U
                 TR_BUY_LIVE TTTT1002U · TR_BUY_MOCK VTTT1002U
```

This is the 08-17 handoff's sec.8.4 (*"six strategy parameters outside the boot
guard"*), and the real count is larger — **12** `DecisionConfig` fields and
**38** `engine_v2` module constants, counted programmatically, not estimated.
Three items deserve naming:

- **`sector_cap` is not a guard-coverage item at all.** It was never frozen and
  never chosen, production is right to ignore it, and the harness is the side
  that is wrong. See sec.6.1.
- **`allow_missing_close` and `require_atr` are safety switches, not tuning
  knobs.** Flipping `allow_missing_close` to True lets the system arm without a
  verifiable close. Unguarded.
- **`TR_SELL_LIVE = TTTT1006U` has never been exercised**, and its mock twin was
  wrong for weeks while every unit test passed — the tests use `FakeBroker`, so a
  wrong TR id is invisible to all of them. It is invisible to `param_snapshot`
  too.

See `PRODUCTION_SUGGESTIONS_20260823.md` for what to do about it.

### 6.1 `sector_cap` — the HARNESS is wrong, production is correct. CLOSED 2026-08-23

**This section previously said the opposite.** It framed production as missing a
constraint the backtest enforces. That was wrong, and it was wrong three times in
a row on the same parameter — first "`sector_cap` binds in practice", then
"production has a gap", then "the cap is tail insurance the backtest cannot
price." Every one of those treated a dataclass default as though somebody had
chosen it. Nobody did.

**Rev 3 does not contain a sector cap, and neither does the method.**

- sec.1's frozen table has **ten entries and `sector_cap` is not one of them.**
- sec.7's SEPA coverage table lists Trend, Fundamentals, Catalyst, Entry, Exit,
  Exposure management. **There is no diversification element.**
- sec.5, verbatim: *"The one real difference from Minervini is that he varies
  exposure with market conditions and this system does not."* **One** difference,
  and it is exposure timing — which the regime gate addresses. Not sector limits.

SEPA selects leading stocks in leading groups. A cap that refuses the third name
in the strongest sector fights the selection method rather than protecting it.

#### What is actually true, measured

`cli.py` never passes `sector_of`, so every plan carries `sector=""` and the
cap's guard `if cfg.sector_cap and plan.sector` is False. **Production has no
cap** (`sector_cap_probe.py`, exit 0 on the machine 2026-08-23). The harness
loads `data/sectors.csv` unconditionally and enforces `sector_cap = 2`.

Three runs of the same frozen set, identical data, differing only in the cap:

```
                 cap ON      cap OFF
  trades           160         161        144 rejections -> ONE net trade
  expectancy    +0.168 R    +0.168 R      identical to 3 dp
  return        +16.58%     +18.89%       the cap COSTS 2.31 pts
  drawdown      -15.07%     -17.04%       the cap BUYS  1.97 pts
  return/|dd|      1.100       1.109      a wash
```

`unmapped_sector` drops: **0**. The sector file covers the whole universe, so
`strict_sector_map` costs nothing and the cap is the *only* divergence — the
narrowest possible form of this problem.

**The cap changes no trade quality whatsoever.** It scales return and drawdown
down together and leaves expectancy untouched. 144 rejections produced one net
trade, which is why counting drops alone would have given the opposite answer.

#### The conclusion, and the action

**Production is correct. The harness models a constraint the strategy does not
have**, and that constraint cost 2.31 points of return in this window for nothing.

Action is one line, in the **harness**, not production: `sector_cap = 0`, after
which `data/sectors.csv` and `strict_sector_map` become irrelevant. Record that it
makes future runs non-comparable to Rev 3's published numbers, which were produced
with the cap on; the gap is the 2.31 / 1.97 points above.

> **Caveat on the run itself.** It does not reproduce Rev 3: window
> 2015-01-02..2026-08-07 rather than 2018+, 160 trades against 200, expectancy
> +0.168 R against +0.330 R (1.05 SE apart). Rev 3's sweeps were clipped to 2018
> and this was not. The A/B/C comparison is unaffected — three runs over identical
> data differing only in the cap — but **"at the frozen set" here does not mean
> "reproduces Rev 3"**, and the reproduction gap is its own open question.

---

## 7. Still open from v1

- **Buying power is not modelled in the harness at all.** Unchanged.
- **sec.15 `regime_150` vs `regime_20`** — two split-sample drawdown runs still
  settle it. Two-place rule still applies.
- **The arithmetic errors — Rev 3 was read on 2026-08-23. Two of the three are
  CONFIRMED and one still needs sec.11.** See sec.10 below. **No parameter
  decision changes**; what is wrong is the prose around the numbers.
- **The vendored `screen_contract.py` — READ, and it is a strict SUBSET.
  CLOSED 2026-08-23.** The hashes do differ, which is what the 08-20 note saw:

  ```
  vendored   00801C50AAE5CA31759B82DE3394B3232BAAA2AA4BFE058C32C43F09F4D740FA   348 lines
  production 599CC4070610472A20FF7B90BAAFFB3A205A6FFB5B0E740A934E23A2BD739811   569 lines
  ```

  But the diff is **4 pure insertions and nothing else** — `SequenceMatcher`
  reports only `equal` and `insert` opcodes, zero replacements, zero deletions.
  Every one of the vendored file's 348 lines appears in production, in order,
  byte-identical: `SCHEMA_VERSION = 3`, the whole `FIELDS` list, the `Candidate`
  dataclass and its `problems()`, and both CSV/JSON round-trips.

  Production adds `import datetime as _dt`, `import os`, a 24-line block
  containing **`VCP_SCORE_THRESHOLD = 75`**, and a 195-line regime state machine
  (`read_regime` / `write_regime` / `regime_path_for`, `REGIME_SCHEMA_VERSION`).

  So "stale" is accurate but misleading: the vendored copy is production's file
  from **before** the threshold constant was centralised and the regime machine
  landed. **No schema has drifted, and no value disagrees** — the constant simply
  does not exist on the vendored side. It cannot matter either way, because
  nothing in `kis-backtest` imports `screen_contract` at all: the harness carries
  its own `BacktestConfig.vcp_threshold` (its own comment calls it *"parked
  parameter #1"*) and `06_sweep.py` passes it via `--threshold`.

  **One question this raised, still open.** That harness default and
  `06_sweep.py --threshold` are both **80.0**, while the frozen value is **75**.
  A sweep of `nmax` or `maxstop` therefore runs at threshold 80, not at the
  frozen set. Whether that is deliberate is a question for Rev 3 sec.1.

## 8. CLOSED from v1

- **sec.6 "`kis-backtest` has no git repository."** It does now: baseline
  `c8900f5`, 69 files, 2026-08-22. Three commits since.
- **sec.2's verification of the vendored engine** stands, and is now stronger: the
  stop geometry was byte-identical, and F8 additionally shows the two engines
  agree on the exit decision layer across 12,000 random scenarios.

---

## 9. NEW — pandas 3.x

The laptop runs **pandas 3.0.3 / numpy 2.4.6**, a major version. Rev 3 is dated
2026-08-11 and the packages are unpinned. `cloud_provisioning` sec.2's rule —
*"pin the two data packages to whatever the laptop runs"* — covers yfinance and
google-genai but was never extended to pandas.

**If a Rev 3 reproduction fails to match, suspect this before suspecting the
refactor.**

---

## 10. NEW — Rev 3 read at last; the arithmetic, settled

`PARAMETER_FREEZE_2026-08-11.md` was located on 2026-08-23 at two paths, both
hashing `B0CD9B83…`, so there is one document:

```
C:\Users\user\PyCharmMiscProject\kis-trader\docs\PARAMETER_FREEZE_2026-08-11.md
C:\Users\user\kis_release_2026-08-17_1921\PARAMETER_FREEZE_2026-08-11.md
```

**It is not in `kis-trader-clean`, the tree that is deployed.** The parameter
authority lives only in the repo with the corrupted git stat-cache and in a loose
release folder. That belongs on the production-update list on its own.

### 10.1 "The strategy edges passive on return" — FALSE

sec.0: *"+49.92% total return over 8.6 years … at only ~38% average deployment,
where a same-exposure passive blend returns 4.95%/yr. On a like-for-like exposure
basis the strategy edges passive on return and loses on drawdown."*

```
CAGR(+49.92%, 8.6 y)  =  4.821 %/yr
passive same-exposure =  4.95  %/yr
                         -------
strategy TRAILS by       0.129 pts/yr
```

sec.0's own "~4.8%/yr" is right. The conclusion drawn from it is not. **On a
like-for-like exposure basis the strategy loses on return AND on drawdown.**
v1's third arithmetic claim is confirmed exactly.

### 10.2 sec.2's comparison table — mixed populations, and it still does not reconcile

```
  strategy          5.09%/yr @ -21.64% drawdown, ~37.8% deployed
  passive same expo 4.95%/yr @ ~12.9%
```

Two defects in three numbers. `−21.64%` is the **`regime_off`** run; `~37.8%`
deployment is the **frozen** set — one row, two configurations. And taking
`regime_off`'s own return of +51.44%:

```
CAGR(+51.44%, 8.6 y)  =  4.944 %/yr        sec.2 says 5.09 %/yr
5.09 %/yr implies a window of 8.36 years, not 8.6
```

Even at the more favourable configuration and its own drawdown, **4.944 < 4.95**.
The sentence beneath the table — *"At the same exposure the strategy beats
passive on return"* — is false by a hair on the numbers as printed, and false by
a wider margin at the frozen set.

### 10.3 sec.4's SE table is the `regime_off` population, mislabelled

```
  n=225 (frozen set, full)   SE = 0.130 R      <- 225 = 103 + 122 = regime_OFF
  n=103 (H1)                 SE = 0.192 R
  n=122 (H2)                 SE = 0.177 R
```

sec.2 states the frozen set is **200 trades, H1 93 + H2 107**. Recomputed at
SD = 1.95 R:

```
  n=200  SE = 0.138 R      n=93  SE = 0.202 R      n=107  SE = 0.189 R
```

**The true noise floor is wider than the document's, not narrower** — about
±0.19–0.20 R rather than ±0.19 R. v1's second claim is confirmed.

**No verdict moves.** Every margin sec.4 calls "inside noise" — `stall_252` vs
`stall_126` 0.050, `maxpos_25` vs `maxpos_30` 0.033, `be_off` vs `be_2.0` 0.029,
`regime_20` vs `regime_off` 0.038 — stays inside the wider floor, and the
75-vs-70 argument is a paired band analysis explicitly exempt from it. **The
frozen set stands. Only the prose is wrong.**

### 10.4 sec.11 — read 2026-08-23. BOTH halves of v1's claim confirmed

```
expectancy up "5.7x"
    regime_off / start = 0.294 / 0.052 = 5.65x   <- this is the 5.7x
    FROZEN     / start = 0.330 / 0.052 = 6.35x   <- the set actually shipped

"21.6% maximum drawdown", in the honest-verdict paragraph
    regime_off  -21.64%        FROZEN  -19.50%
```

Both are `regime_off` figures standing in a paragraph describing the shipped
system. **Both understate it** — the frozen set is better on each. The errors do
not flatter, which is the one comfort here.

sec.11 also repeats sec.0's conclusion verbatim: *"and it edges a same-exposure
passive blend on return."* Same claim, same falsity (sec.10.1).

### 10.5 The one that matters — `5.09%/yr` is a threshold-70 number

sec.2 prints `strategy 5.09%/yr`, sec.11 prints `~5.1%/yr`, and R7 reasons
against *"a 5.1%/yr result."* It reconciles with **neither** configuration:

```
FROZEN      +49.92%  over 8.6 y  ->  4.821 %/yr
regime_off  +51.44%  over 8.6 y  ->  4.944 %/yr
thr_70      +53.25%  over 8.6 y  ->  5.089 %/yr     <-- this one
total return required for exactly 5.09%/yr        ->  +53.26%
sec.4's thr_70 total return                       ->  +53.25%
```

**The 5.09%/yr figure is `thr_70`'s**, matching to 0.01 points, carried into two
sections and a risk note about the frozen set.

Rev 3 sec.10, the discipline list, ends with: *"**Carry the configuration with
every number.** The 68.9% deployment figure in Rev 1 was a threshold-70
measurement quoted against a threshold-75 set."* **The `5.09%/yr` figure is a
threshold-70 measurement quoted against a threshold-75 set** — the same error, in
the same document, one section after the rule was written down.

And it is not cosmetic, because it is load-bearing for the passive comparison:

```
5.089  >  4.95  ->  "beats passive on return"      <- thr_70, not shipped
4.821  <  4.95  ->  trails passive by 0.129 pts/yr <- the frozen set
```

**The false conclusion in sec.10.1 and this mis-carried number are the same
error.** Fix the number and the conclusion inverts on its own.

### 10.6 sec.3's win-rate ladder — internally sound, baseline inconsistent

The ladder reproduces exactly under `E × 0.85% × (225/8.6 = 26.16 trades/yr)`:

```
  win 31.1%  E=0.239 ->  5.31 %/yr   (doc 5.3)
  win 35%    E=0.403 ->  8.96 %/yr   (doc 8.9)
  win 40%    E=0.613 -> 13.63 %/yr   (doc 13.6)
  win 48%    E=0.950 -> 21.13 %/yr   (doc 21.0)
```

But its baseline is `E = +0.239 R` at the measured 31.1% win rate, where sec.2
measures **+0.294 R** for that same configuration (`0.311 × 3.311 − 0.689 × 1.068
= +0.294`, exact). The ladder understates the measured book by 0.055 R, so its
"index parity needs a 40% win rate" is **conservative**, not optimistic. No
conclusion moves; worth knowing before anyone re-derives from it.

### 10.7 Two things Rev 3 says that bear directly on production

- **sec.1 points `VCP_SCORE_THRESHOLD` at `config.py`. It lives in
  `screen_contract.py`.** The document's own production-location column is stale.
  `param_snapshot` reads the right module, so the guard is correct and the map
  is wrong — which is the more dangerous way round for anyone following the doc.
- **sec.9(a), verbatim: "`rank_score` has zero test coverage in any suite. Add
  one."** That is `PRODUCTION_SUGGESTIONS` item 4 asked for by the freeze itself,
  eleven days before the rank work independently arrived at the same conclusion.

### 10.8 NEW FOOTGUN — a sweep's default threshold is a configuration Rev 3 rejected

`BacktestConfig.vcp_threshold` defaults to **80.0** and `06_sweep.py --threshold`
defaults to **80.0**. The frozen value is **75**. So a sweep of `nmax`, `maxstop`,
`atrfloor` or any other parameter, run without `--threshold`, silently runs at 80.

Rev 3 sec.4 measures exactly that configuration: *"Production currently runs 80,
which at the frozen config scores **+0.43 R in H1 and −0.05 to −0.11 R in H2** —
four negative cells."* 80 is not a neutral default; it is a setting the document
examined and rejected.

**This is the same shape as the `risk 0.0075 / cap 0.20` footgun closed on
08-22** — a pre-migration value surviving as a default, producing numbers that
look legitimate. That one is now guarded; this one is not. The guard already
exists and needs one more field: extend `harness_snapshot`'s
`--require-explicit-sizing` check to require `--threshold`, or default it to 75.


### 10.9 Two of Rev 3's own risks, re-measured against production

- **R3 — orphan exposure bug: FIXED, and the fix is visible in the code.** R3
  asks that `open_notional` be read from broker holdings rather than from local
  positions. `pipeline.py::_account_state()` now does exactly that, and says so:
  *"Exposure is measured from BROKER truth, the same source held_tickers uses --
  one source, not two."* It goes further than R3 asked — orphans are priced and
  counted, an unpriceable one fails closed with an `ARM BLOCKED` alert rather
  than measuring zero exposure, and a position we track that the broker has not
  reported yet is still counted. **Close R3.**
- **R6 — "four values across three files. No single source of truth. Print the
  active parameter set at boot": DONE.** `param_snapshot.boot_log()` runs in
  `cmd_run` before the broker is touched. See sec.6 for what it still does not
  cover.
