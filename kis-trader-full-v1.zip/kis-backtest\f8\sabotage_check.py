#!/usr/bin/env python3
"""
F8 -- sabotage proof. STANDING RULE 2: a test that passes must be shown to fail.

Builds throwaway copies of production's engine_v2.py with ONE deliberate defect
each, runs the fixture against each, and asserts the fixture goes red. Nothing
in the real repo is touched: each sabotage is written to a scratch tree and
deleted afterwards.

Every patch ASSERTS ITS ANCHOR MATCHED EXACTLY ONCE before replacing (standing
rule 4) -- a sabotage that silently no-ops would "prove" the fixture works when
it had nothing to catch.

    python sabotage_check.py --prod-root /path/to/kis-trader-clean
"""
from __future__ import annotations

import argparse
import os
import shutil
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from engine_side import EngineExitRunner, load_module   # noqa: E402
import cases as C                                       # noqa: E402


# (name, anchor, replacement, what it breaks, cases that MUST go red)
SABOTAGES = [
    ("elif -> if in on_close  (the R2 structural fact)",
     "            elif pos.state in (PositionState.TRAILING, PositionState.PARTIAL_TAKEN):",
     "            if pos.state in (PositionState.TRAILING, PositionState.PARTIAL_TAKEN):",
     "the EMA test would also run on the PROMOTION bar, so a promotion whose "
     "close is already under the EMA exits a whole bar early",
     ["5b"]),

    ("stop / +3R precedence flipped in _on_tick",
     """        if price <= pos.stop_loss_price:             # -1R / breakeven hard stop: act now
            self._begin_exit(pos, "STOP_HIT", bid, price)
            return
        if (not pos.partial_done and not pos.partial_pending
                and pos.r_multiple(price) >= R_PARTIAL_MULTIPLE):
            self._take_partial(pos, bid)""",
     """        if (not pos.partial_done and not pos.partial_pending
                and pos.r_multiple(price) >= R_PARTIAL_MULTIPLE):
            self._take_partial(pos, bid)
            return
        if price <= pos.stop_loss_price:             # -1R / breakeven hard stop: act now
            self._begin_exit(pos, "STOP_HIT", bid, price)
            return""",
     "the partial would outrank the hard stop on the same tick -- but see "
     "prove_precedence_unreachable(): NO tick can satisfy both conditions, so "
     "this reordering is not observable and the same-bar question is decided "
     "entirely by the backtest's tick-path convention",
     []),

    ("STALL_R_FLOOR comparison < -> <=",
     "                if pos.r_multiple(close_price) < STALL_R_FLOOR:",
     "                if pos.r_multiple(close_price) <= STALL_R_FLOOR:",
     "a trade sitting exactly ON the floor would be stalled out instead of "
     "promoted",
     ["7"]),

    ("queued exit executed at the CLOSE instead of the next open",
     """            if pos.state == PositionState.FILLED and pos.days_held >= STALL_DAY:
                if pos.r_multiple(close_price) < STALL_R_FLOOR:
                    pos.pending_exit = "STALL_EXIT\"""",
     """            if pos.state == PositionState.FILLED and pos.days_held >= STALL_DAY:
                if pos.r_multiple(close_price) < STALL_R_FLOOR:
                    self._begin_exit(pos, "STALL_EXIT", close_price, close_price)
                    return
                if False:
                    pos.pending_exit = "STALL_EXIT\"""",
     "stall exits would book the signal bar's close, not the next open -- the "
     "1.0R-per-trade error case 8 is built to catch",
     ["6", "8", "8b"]),

    ("partial fraction: int() truncation removed",
     "        want = int(pos.shares * PARTIAL_FRACTION)",
     "        want = round(pos.shares * PARTIAL_FRACTION)",
     "int() vs round() disagree whenever shares % 3 == 2 -- case 9 uses 32 "
     "shares precisely so they do",
     ["9"]),
]


def prove_precedence_unreachable(E):
    """engine_v2._on_tick checks the stop BEFORE the +3R partial and returns.
    That ordering can never actually bind, and this proves it rather than
    asserting it:

        stop branch    fires iff  price <= stop_loss_price
        partial branch fires iff  (price - entry)/risk >= 3  AND not partial_done

    Before the partial, stop = entry - risk, so price <= entry - risk gives
    r <= -1, never >= 3. After the partial, stop = entry (breakeven) but
    partial_done is True, so the partial branch is closed for good.

    CONSEQUENCE FOR F8: there is nothing on the production side to diff for the
    'both touched on one bar' question. It is decided ENTIRELY by the harness's
    ambiguity convention, and cases 3 vs 3b price that choice at 2.0R per
    ambiguous bar.
    """
    entry, risk = 100.0, 10.0
    hits = []
    for pre_partial in (True, False):
        stop = entry - risk if pre_partial else entry
        # sweep a fine grid across every price a tick could carry
        p = 0.0
        while p <= entry + 6 * risk:
            stop_fires = p <= stop
            r = (p - entry) / risk
            partial_fires = (r >= E.R_PARTIAL_MULTIPLE) and pre_partial
            if stop_fires and partial_fires:
                hits.append((pre_partial, p))
            p += 0.01
    return hits


def patch(src_text, anchor, replacement, label):
    n = src_text.count(anchor)
    if n != 1:
        raise AssertionError(f"[{label}] anchor matched {n} times, expected exactly 1 -- "
                             f"refusing to patch (standing rule 4)")
    return src_text.replace(anchor, replacement)


def run_all(E, tick_path="worst"):
    """Return {case_key: (reason, bar, price, R)}."""
    out = {}
    for case in C.ALL:
        try:
            r = EngineExitRunner(E, stall_day=case.stall_day,
                                 tick_path=case.tick_path or tick_path)
            t = r.run(case.bars, entry_price=C.ENTRY, stop_price=C.STOP,
                      shares=case.shares, emas=case.emas)
            out[case.key] = (t.exit_reason, t.exit_bar, t.exit_price, t.r_multiple)
        except Exception as ex:
            out[case.key] = ("<raised>", type(ex).__name__, None, None)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--prod-root", required=True)
    args = ap.parse_args()

    real_path = os.path.join(args.prod_root, "kistrader", "core", "engine_v2.py")
    with open(real_path, encoding="utf-8") as fh:
        original = fh.read()

    print("=" * 78)
    print("F8 SABOTAGE PROOF -- the fixture must go red for each planted defect")
    print("=" * 78)
    print(f"  reference engine: {real_path}")

    base_mod = load_module(real_path, "f8_sab_base")
    baseline = run_all(base_mod)
    print(f"  baseline captured for {len(baseline)} cases")

    hits = prove_precedence_unreachable(base_mod)
    print(f"  stop-vs-partial precedence: {len(hits)} price(s) satisfy BOTH branches "
          f"-> {'UNREACHABLE (the ordering cannot bind)' if not hits else 'REACHABLE: ' + str(hits[:5])}\n")

    failures = []
    for i, (name, anchor, repl, why, must_break) in enumerate(SABOTAGES):
        tmp = tempfile.mkdtemp(prefix="f8sab_")
        try:
            broken_path = os.path.join(tmp, "engine_v2.py")
            with open(broken_path, "w", encoding="utf-8") as fh:
                fh.write(patch(original, anchor, repl, name))
            mod = load_module(broken_path, f"f8_sab_{i}")
            got = run_all(mod)

            changed = sorted(k for k in baseline if baseline[k] != got[k])
            print(f"[{i + 1}] {name}")
            print(f"     effect: {why}")
            print(f"     cases that changed: {', '.join(changed) if changed else '(none)'}")
            for k in changed:
                print(f"        {k}: {baseline[k]}  ->  {got[k]}")

            if must_break:
                missed = [k for k in must_break if k not in changed]
                if missed:
                    print(f"     [FAIL] fixture did NOT catch this in case(s) {missed}")
                    failures.append(name)
                else:
                    print(f"     [PASS] caught by case(s) {', '.join(must_break)}")
            else:
                print("     [INFO] no case in the current set distinguishes this -- "
                      "documented, not asserted")
            print()
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    print("=" * 78)
    if failures:
        print(f"SABOTAGE PROOF FAILED for: {'; '.join(failures)}")
        print("The fixture cannot be trusted to detect a real disagreement.")
        return 1
    print("SABOTAGE PROOF PASSED -- every asserted defect was caught.")
    print("=" * 78)
    return 0


if __name__ == "__main__":
    sys.exit(main())
