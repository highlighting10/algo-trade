#!/usr/bin/env python3
"""
probe_provenance.py -- does every CLOSED trade carry a strategy ENTRY marker?

Tests the premise behind the proposed layer 2b allowlist:

    a close counts toward the loss streak only if its order_key also
    carries at least one ENTRY_% event

Strategy entries go through entry_manager, which writes ENTRY_ARMED /
ENTRY_ADOPT / ENTRY_LATE_FILL_ADOPTED / ENTRY_HELD_CONFIRMED / ENTRY_SETTLE_WAIT
/ ENTRY_CANCELLED under the position's own order_key. A hand-seeded position
writes SEEDED_ENTRY_ARMED and SEEDED_FILL instead -- neither starts with ENTRY_.

The pattern is ANCHORED and the underscore is ESCAPED on purpose:
  * '%ENTRY_ARMED%' would MATCH 'SEEDED_ENTRY_ARMED:manual' and reopen the hole
  * in SQLite LIKE, '_' is a single-character wildcard, so 'ENTRY_%' without
    ESCAPE also matches 'ENTRYX...'

Read-only, against a COPY of the event store.

    python probe_provenance.py probe.db
"""
from __future__ import annotations

import os
import sqlite3
import sys

LIVE_NAME = "kis_engine_state.db"
ENTRY_LIKE = "ENTRY!_%"          # anchored, '_' escaped
ESCAPE = "!"


def main(argv):
    db = argv[1] if len(argv) > 1 else "probe.db"
    if not os.path.isfile(db):
        raise SystemExit(f"no such database: {db}")
    if os.path.basename(db) == LIVE_NAME:
        raise SystemExit(f"REFUSING: {db} is the live database name. Use a copy.")
    con = sqlite3.connect(f"file:{db}?mode=ro", uri=True)

    closes = [r[0] for r in con.execute(
        "SELECT DISTINCT order_key FROM position_events "
        "WHERE event_type LIKE 'CLOSED:%' ORDER BY order_key")]
    if not closes:
        print("no CLOSED trades in this database -- premise untestable here")
        return 0

    print("=" * 88)
    print("PROVENANCE OF EVERY CLOSED TRADE")
    print("=" * 88)
    print(f"\n  {'order_key':<24} {'ENTRY_ events':>13}  verdict")
    print("  " + "-" * 82)
    kept = dropped = 0
    for key in closes:
        markers = [r[0] for r in con.execute(
            "SELECT DISTINCT event_type FROM position_events "
            "WHERE order_key = ? AND event_type LIKE ? ESCAPE ?",
            (key, ENTRY_LIKE, ESCAPE))]
        ok = len(markers) > 0
        kept += ok
        dropped += (not ok)
        print(f"  {key:<24} {len(markers):>13}  "
              f"{'COUNTS' if ok else 'SKIPPED (no strategy entry)'}")
        for m in sorted(markers):
            print(f"  {'':<24} {'':>13}    {m}")
        if not ok:
            others = [r[0] for r in con.execute(
                "SELECT DISTINCT event_type FROM position_events "
                "WHERE order_key = ? ORDER BY 1", (key,))]
            print(f"  {'':<24} {'':>13}    what it has instead:")
            for m in others:
                print(f"  {'':<24} {'':>13}      {m}")

    print("\n" + "-" * 88)
    print(f"  {kept} close(s) COUNT, {dropped} SKIPPED")

    # The trap, demonstrated rather than asserted.
    bad = [r[0] for r in con.execute(
        "SELECT DISTINCT event_type FROM position_events "
        "WHERE event_type LIKE '%ENTRY!_ARMED%' ESCAPE '!' "
        "AND event_type NOT LIKE ? ESCAPE ?", (ENTRY_LIKE, ESCAPE))]
    print("\n  TRAP CHECK -- event types an UNANCHORED '%ENTRY_ARMED%' would")
    print("  wrongly accept as strategy provenance:")
    for b in bad:
        print(f"      {b}")
    if not bad:
        print("      (none in this database -- the trap is still real in code)")

    print("\n  ENTRY_ namespace present in this store:")
    for et, n in con.execute(
            "SELECT event_type, COUNT(*) FROM position_events "
            "WHERE event_type LIKE ? ESCAPE ? GROUP BY 1 ORDER BY 2 DESC",
            (ENTRY_LIKE, ESCAPE)):
        print(f"      {n:>4}  {et}")
    print("=" * 88)
    con.close()
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
