#!/usr/bin/env python3
"""
Screener harness — the first tests these 5,700 lines have ever had
==================================================================

WHY NOW

`screeners/sp500_v21.py` (2,882 lines) and `screeners/us_small_v21.py` (2,832)
had zero coverage. Everything downstream of them is heavily tested; the two
files that decide WHAT gets traded were not tested at all. D3a modified both,
and D1/D2 are about to add a regime gate and a provenance writer to the same
files.

It found a production bug on the first run. See test_import_without_credentials.

WHAT IT COVERS, AND WHAT IT DELIBERATELY DOES NOT

Covered: module import under a bare environment, the D3a threshold loader, the
two screeners agreeing, and the pure math-floor scoring the source itself labels
"no I/O; fully unit-testable".

NOT covered: anything that fetches. Stage 1's parallel scan, the Gemini calls
and the VCP engine all need network, keys, and market data. Those belong to a
supervised `--limit N --dry-run` run, not to a unit suite, and pretending
otherwise would produce tests that mock so much they assert only the mock.

HOW THE IMPORT WORKS

yfinance, finnhub and google.genai are stubbed in sys.modules BEFORE import. The
screeners import all three at module scope, so without stubs nothing here is
reachable. Stubbing is honest for this suite: none of the functions under test
touch those modules. It is also what lets the import test run on a machine that
has never had credentials — which is the machine that finds the bugs.

Run:  python tests/test_screener_harness.py      (or via pytest)
"""
from __future__ import annotations

import os
import sys
import types

# Self-locating AND shadow-proof. Two separate problems, both measured:
#  1. `kistrader` and `screeners` are not installed packages (pyproject
#     packages.find includes only kistrader*), so a DIRECT run -- sys.path[0] is
#     tests/ -- cannot import either. pytest happens to work because pyproject
#     sets pythonpath = [".", "tests"].
#  2. kis-backtest ships a partial COPY of kistrader/. Run pytest from the parent
#     directory and it collects both projects; whichever imports first wins
#     sys.modules, and after that sys.path is irrelevant -- Python never
#     re-resolves an imported package. That produced five collection errors
#     naming the wrong repo.
import os as _os, sys as _sys
_ROOT = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))
for _p in (_os.path.join(_ROOT, "screeners"), _ROOT):
    while _p in _sys.path:
        _sys.path.remove(_p)                 # move to the FRONT, not merely present
    _sys.path.insert(0, _p)
_k = _sys.modules.get("kistrader")
_kf = _os.path.abspath(getattr(_k, "__file__", "") or "") if _k is not None else ""
if _k is not None and not _kf.startswith(_ROOT + _os.sep):
    print(f"[path] evicting a foreign kistrader loaded from {_kf!r}; "
          f"this suite tests {_ROOT!r}")
    for _m in [_m for _m in list(_sys.modules)
               if _m == "kistrader" or _m.startswith("kistrader.")]:
        del _sys.modules[_m]

PASS, FAIL = [], []


def check(name, cond, detail=""):
    (PASS if cond else FAIL).append(name)
    print(f"  [{'PASS' if cond else 'FAIL'}] {name}" + (f"  ({detail})" if detail and not cond else ""))


def _stub_heavy_deps():
    """Install do-nothing stand-ins for the three third-party modules the
    screeners import at module scope. Idempotent; only fills what is absent, so
    a machine that really has yfinance installed keeps the real one."""
    for name in ("yfinance", "finnhub"):
        sys.modules.setdefault(name, types.ModuleType(name))
    if "google.genai" not in sys.modules:
        g = types.ModuleType("google")
        gg = types.ModuleType("google.genai")
        gg.types = types.ModuleType("google.genai.types")
        gg.Client = object
        g.genai = gg
        sys.modules.setdefault("google", g)
        sys.modules["google.genai"] = gg
        sys.modules["google.genai.types"] = gg.types


def _import_screeners():
    """Import both screeners fresh, with the heavy deps stubbed."""
    _stub_heavy_deps()
    for m in ("screeners.sp500_v21", "screeners.us_small_v21"):
        sys.modules.pop(m, None)
    try:
        import screeners.sp500_v21 as sp
        import screeners.us_small_v21 as us
        return sp, us, None
    except Exception as e:
        return None, None, e


class _no_credentials:
    """Context manager that makes the no-API-key fall-through DETERMINISTIC.

    Stripping os.environ is NOT enough, and shipping a test that only did that
    was a real defect: _read_finnhub_key() calls kistrader.config.load_dotenv on
    the repo-root .env before reading the environment, so on any machine with a
    .env the key comes straight back and the fall-through is never evaluated.
    Measured: with the `return Nones` bug present AND a .env holding a Finnhub
    key, the env-stripping version of this test reported 35/35.

    So this also neutralises load_dotenv and repoints _repo_root at an empty
    temp directory, and chdir's there, so neither .env nor finnhub_key.txt can
    be found by any of the four paths the function tries."""

    def __init__(self, mod):
        self.mod = mod

    def __enter__(self):
        import tempfile
        self._tmp = tempfile.mkdtemp()
        self._cwd = os.getcwd()
        self._env = {k: os.environ.pop(k, None)
                     for k in ("FINNHUB_API_KEY", "GEMINI_API_KEY", "GOOGLE_API_KEY")}
        self._root = getattr(self.mod, "_repo_root", None)
        self.mod._repo_root = lambda: self._tmp
        self._dotenv = None
        try:
            import kistrader.config as _cfg
            self._cfg = _cfg
            self._dotenv = _cfg.load_dotenv
            _cfg.load_dotenv = lambda *a, **k: None
        except ImportError:
            self._cfg = None
        os.chdir(self._tmp)
        return self

    def __exit__(self, *exc):
        os.chdir(self._cwd)
        if self._root is not None:
            self.mod._repo_root = self._root
        if self._cfg is not None and self._dotenv is not None:
            self._cfg.load_dotenv = self._dotenv
        for k, v in self._env.items():
            if v is not None:
                os.environ[k] = v
        return False


# ---------------------------------------------------------------------------
def test_import_without_credentials():
    """A screener must load, and degrade gracefully, on a box with no API keys.

    This found `return Nones` in sp500_v21._read_finnhub_key() -- a typo on the
    no-key fall-through, reached at module scope via `DATA = DataProxy()`. With
    a key present the function returns early and the typo is never evaluated,
    which is why it survived every run on a developer machine while making
    `import screeners.sp500_v21` raise NameError on a freshly provisioned one.

    us_small_v21 has the correct `return None` on the same line of the same
    function, so the two files disagreed and nothing reported it. The comment
    above that line promises a graceful fallback; the typo made it a crash."""
    print("S1 no-credentials path: import, and the key fall-through")
    sp, us, err = _import_screeners()
    check("both screeners import", err is None,
          f"{type(err).__name__}: {err}" if err else "")
    if err:
        return
    for name, mod in (("sp500_v21", sp), ("us_small_v21", us)):
        fn = getattr(mod, "_read_finnhub_key", None)
        if fn is None:
            check(f"{name} exposes _read_finnhub_key", False)
            continue
        with _no_credentials(mod):
            try:
                got = fn()
                ok, detail = (got is None), f"returned {got!r}"
            except Exception as e:
                ok, detail = False, f"{type(e).__name__}: {e}"
        check(f"{name}: no key anywhere -> returns None, no exception", ok, detail)


def test_threshold_single_source():
    """D3a: one declaration, both screeners resolving to it."""
    print("S2 VCP_SCORE_THRESHOLD resolves through screen_contract in BOTH")
    sp, us, err = _import_screeners()
    if err:
        check("screeners importable", False, str(err))
        return
    from kistrader.entry.screen_contract import VCP_SCORE_THRESHOLD as shared
    check("sp500 resolves to the shared value", sp.VCP_SCORE_THRESHOLD == shared,
          f"{sp.VCP_SCORE_THRESHOLD} vs {shared}")
    check("us_small resolves to the shared value", us.VCP_SCORE_THRESHOLD == shared,
          f"{us.VCP_SCORE_THRESHOLD} vs {shared}")
    check("the two screeners agree with each other",
          sp.VCP_SCORE_THRESHOLD == us.VCP_SCORE_THRESHOLD)
    check("the loader is present in both (no literal crept back)",
          hasattr(sp, "_load_vcp_threshold") and hasattr(us, "_load_vcp_threshold"))


def test_yoy_growth():
    """_yoy_growth: series is most-recent-first; i vs i+4."""
    print("S3 _yoy_growth — the base of every acceleration score")
    sp, _, err = _import_screeners()
    if err:
        check("screeners importable", False, str(err)); return
    f = sp._yoy_growth
    s = [120.0, 115, 110, 105, 100, 95, 90, 85, 80]      # index 4 == 100.0
    check("growth vs the year-ago quarter", abs(f(s, 0) - 0.20) < 1e-12, f"{f(s, 0)}")
    check("too short -> None", f([1, 2, 3], 0) is None)
    check("None in the series -> None", f([None, 1, 1, 1, 1, 1, 1, 1, 1], 0) is None)
    check("zero base -> None (sign-ambiguous, not infinity)",
          f([50.0, 1, 1, 1, 0.0, 1, 1, 1, 1], 0) is None)
    check("negative base -> None (this is EPS's profitability guard)",
          f([50.0, 1, 1, 1, -10.0, 1, 1, 1, 1], 0) is None)
    check("a real decline is reported as negative, not dropped",
          abs(f([80.0, 1, 1, 1, 100.0, 1, 1, 1, 1], 0) + 0.20) < 1e-12)


def test_growth_and_accel_points():
    """Acceleration: full points for two consecutive rises, half for one."""
    print("S4 _growth_and_accel_points — acceleration is the SEPA criterion")
    sp, _, err = _import_screeners()
    if err:
        check("screeners importable", False, str(err)); return
    f = sp._growth_and_accel_points

    # bases 100 at every lag; numerators chosen so g0 > g1 > g2
    accel2 = [140.0, 125, 115, 110] + [100.0] * 8        # g0=.40 g1=.25 g2=.15
    _, ap, g0 = f(accel2, 0.25, 10.0, 6.0)
    check("two consecutive rises -> FULL acceleration points", abs(ap - 6.0) < 1e-12, f"{ap}")

    accel1 = [140.0, 125, 130, 110] + [100.0] * 8        # g0>g1 but g1<g2
    _, ap1, _ = f(accel1, 0.25, 10.0, 6.0)
    check("one rise only -> HALF acceleration points", abs(ap1 - 3.0) < 1e-12, f"{ap1}")

    decel = [110.0, 125, 130, 140] + [100.0] * 8         # g0 < g1
    _, ap0, _ = f(decel, 0.25, 10.0, 6.0)
    check("decelerating -> ZERO acceleration points", ap0 == 0.0, f"{ap0}")

    gp, _, _ = f([125.0] + [1] * 3 + [100.0] * 8, 0.25, 10.0, 6.0)
    check("growth at the full-credit threshold earns full growth points",
          abs(gp - 10.0) < 1e-12, f"{gp}")
    gp2, _, _ = f([200.0] + [1] * 3 + [100.0] * 8, 0.25, 10.0, 6.0)
    check("growth far above it is CLAMPED, not extrapolated",
          abs(gp2 - 10.0) < 1e-12, f"{gp2}")
    gpn, apn, gn = f(None, 0.25, 10.0, 6.0)
    check("no series -> zeros and no growth, never a crash",
          (gpn, apn, gn) == (0.0, 0.0, None), f"{(gpn, apn, gn)}")


def test_surprise_points():
    print("S5 _surprise_points — EPS beats, averaged over at most 4")
    sp, _, err = _import_screeners()
    if err:
        check("screeners importable", False, str(err)); return
    f = sp._surprise_points
    check("no surprises -> 0", f([], 0.10, 5.0) == 0.0)
    check("net-negative surprises earn nothing", f([-0.2, 0.1], 0.10, 5.0) == 0.0)
    check("at the full-credit average -> full points",
          abs(f([0.10, 0.10, 0.10, 0.10], 0.10, 5.0) - 5.0) < 1e-12)
    check("well above it is clamped", abs(f([1.0, 1.0], 0.10, 5.0) - 5.0) < 1e-12)
    check("only the most recent 4 count",
          f([0.10] * 4 + [-9.0] * 4, 0.10, 5.0) == f([0.10] * 4, 0.10, 5.0))


def test_compute_math_floor():
    """The 0-45 floor. Graceful degradation is the documented contract."""
    print("S6 compute_math_floor — caps, and the empty-fundamentals contract")
    sp, _, err = _import_screeners()
    if err:
        check("screeners importable", False, str(err)); return
    f = sp.compute_math_floor

    total, bd = f({})
    check("empty fund -> 0.0 and math_available False",
          total == 0.0 and bd["math_available"] is False, f"{total} {bd}")
    total, bd = f({"eps": [], "revenue": [], "source": "finnhub"})
    check("present-but-empty series -> still flagged unavailable",
          bd["math_available"] is False, f"{bd}")

    huge = [10.0 ** 6] + [1.0] * 3 + [1.0] * 8
    total, bd = f({"eps": huge, "revenue": huge, "eps_surprises": [9.0] * 4})
    check("earnings category capped at 25", bd["cat1_earnings"] <= 25.0, f"{bd['cat1_earnings']}")
    check("revenue category capped at 20", bd["cat2_revenue"] <= 20.0, f"{bd['cat2_revenue']}")
    check("the floor cannot exceed 45", total <= 45.0, f"{total}")
    check("source is carried through for provenance",
          f({"eps": huge, "source": "finnhub"})[1]["source"] == "finnhub")


def test_both_screeners_share_the_scoring():
    """us_small's header says it mirrors sp500's scoring. Verify, don't trust."""
    print("S7 the two screeners' pure scoring functions agree")
    sp, us, err = _import_screeners()
    if err:
        check("screeners importable", False, str(err)); return
    series = [140.0, 125, 115, 110] + [100.0] * 8
    for name in ("_yoy_growth", "_surprise_points", "compute_math_floor",
                 "_growth_and_accel_points"):
        check(f"us_small defines {name} too", hasattr(us, name))
    check("_yoy_growth agrees", sp._yoy_growth(series, 0) == us._yoy_growth(series, 0))
    fund = {"eps": series, "revenue": series, "eps_surprises": [0.05, 0.04, 0.03, 0.02]}
    check("compute_math_floor agrees on the same fundamentals",
          sp.compute_math_floor(fund)[0] == us.compute_math_floor(fund)[0],
          f"{sp.compute_math_floor(fund)[0]} vs {us.compute_math_floor(fund)[0]}")


# --- PATCH I2 -----------------------------------------------------------------
# The two screeners each carry an INLINED copy of the VCP engine. They write the
# SAME candidates.csv, so a fix applied to one and not the other screens half the
# universe on different logic -- and before this test, nothing reported it.
# Measured 2026-08-28: the region below is 49,804 bytes and identical in both.
ENGINE_START = "def safe_divide("
ENGINE_END = "VCPAnalyzerV3 = VCPAnalyzerV4"


def _engine_block(src, which):
    """The whole inlined engine: safe_divide .. the V3 alias. Returns None and
    reports if either boundary is missing or duplicated -- a moved boundary is
    itself a divergence, and silently comparing the wrong slice would be worse
    than not comparing at all."""
    for anchor in (ENGINE_START, ENGINE_END):
        n = src.count(anchor)
        if n != 1:
            check(f"{which}: engine boundary {anchor!r} occurs exactly once",
                  False, f"occurs {n}x")
            return None
    i = src.index(ENGINE_START)
    j = src.index(ENGINE_END) + len(ENGINE_END)
    if j <= i:
        check(f"{which}: engine boundaries are ordered", False, "end before start")
        return None
    return src[i:j]


def test_vcp_engines_are_identical():
    """S6 and every future P2 fix is a TWO-file patch. This is what catches
    landing it in one file only."""
    print("S13 the two inlined VCP engines must not drift apart")
    root = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))
    paths = {"sp500_v21": _os.path.join(root, "screeners", "sp500_v21.py"),
             "us_small_v21": _os.path.join(root, "screeners", "us_small_v21.py")}
    srcs = {}
    for name, p in paths.items():
        if not _os.path.isfile(p):
            check(f"{name} present at {p}", False)
            return
        with open(p, encoding="utf-8") as fh:
            srcs[name] = fh.read()

    blocks = {n: _engine_block(s, n) for n, s in srcs.items()}
    if any(b is None for b in blocks.values()):
        return
    a, b = blocks["sp500_v21"], blocks["us_small_v21"]
    same = a == b
    check(f"the inlined VCP engine is byte-identical in both screeners "
          f"({len(a)} vs {len(b)} bytes)", same)
    if not same:
        import difflib
        diff = [l for l in difflib.unified_diff(
            a.splitlines(), b.splitlines(), "sp500_v21", "us_small_v21",
            lineterm="", n=0) if l.startswith(("+", "-"))
            and not l.startswith(("+++", "---"))]
        print(f"      {len(diff)} differing line(s). First 12:")
        for line in diff[:12]:
            print("        " + line[:104])
        print("      A P2 fix must land in BOTH files. Apply it twice, "
              "then re-run this test.")

    # The scoring surface OUTSIDE the block has to agree as well.
    import re as _re
    for name in ("RESULTS_HEADER", "def result_outcome", "def format_result_row"):
        ln = {}
        for f, s in srcs.items():
            m = _re.search(rf"^{_re.escape(name)}.*$", s, _re.M)
            ln[f] = m.group(0) if m else None
        check(f"{name} agrees across both screeners",
              ln["sp500_v21"] is not None and ln["sp500_v21"] == ln["us_small_v21"],
              f"{ln}")

    # Constants compared by VALUE: both are "^GSPC" but their trailing comments
    # legitimately differ, and a test that fails on a comment gets weakened.
    sp, us, err = _import_screeners()
    if err:
        check("screeners importable for the constant check", False, str(err))
        return
    for const in ("VCP_LOOKBACK_PERIOD", "VCP_CONTRACTION_MODE", "VCP_BENCHMARK"):
        va, vb = getattr(sp, const, None), getattr(us, const, None)
        check(f"{const} has the same VALUE in both ({va!r})",
              va is not None and va == vb, f"{va!r} vs {vb!r}")

    # The loop above compares the screeners to EACH OTHER, so both being wrong
    # in the same way passes. VCP_CONTRACTION_MODE sits OUTSIDE the extracted
    # engine block and is handed to VCPAnalyzerV4, overriding VCPConfig's
    # default -- and engine_reference execs the block with a DEFAULT config, so
    # it can never see this constant. On 2026-09-10 that gap let the default
    # move to 'strict' with every verifier green while production still ran
    # 'general' (1.10). These two checks are the only thing that closes it.
    for _mod, _name in ((sp, "sp500_v21"), (us, "us_small_v21")):
        _cfg = _mod.VCPConfig()
        _mode = getattr(_mod, "VCP_CONTRACTION_MODE", None)
        # __init__ reverts an unknown mode to 'general' SILENTLY, so what must
        # be asserted is RESOLUTION, not the string.
        check(f"{_name}: VCP_CONTRACTION_MODE {_mode!r} resolves in the "
              f"engine's own contraction_modes",
              _mode in _cfg.contraction_modes,
              f"{_mode!r} not in {sorted(_cfg.contraction_modes)} "
              f"-> __init__ would fall back to 'general' silently")
        check(f"{_name}: the screener constant matches the engine default "
              f"({_cfg.contraction_mode!r})",
              _mode == _cfg.contraction_mode,
              f"constant {_mode!r} OVERRIDES default "
              f"{_cfg.contraction_mode!r} -- production and the backtest "
              f"would score differently")
# --- end PATCH I2 -------------------------------------------------------------


# ---------------------------------------------------------- regime gate (3b) --

def _bench_frame(closes, last_bar="2026-08-13"):
    """A synthetic ^GSPC frame. pandas is REAL here; only the fetch is faked, so
    what runs is the production probe against a production DataFrame."""
    import datetime as d
    import pandas as pd
    end = d.date.fromisoformat(last_bar)
    idx = pd.to_datetime([end - d.timedelta(days=i) for i in range(len(closes))][::-1])
    return pd.DataFrame({"Close": closes}, index=idx)


def _have_pandas():
    try:
        import pandas  # noqa: F401
        return True
    except ImportError:
        return False


def test_regime_params_come_from_one_place():
    print("S8 regime parameters resolve to their single sources")
    sp, us, err = _import_screeners()
    if err:
        check("screeners importable", False, str(err)); return
    from kistrader.entry.exposure_controller import ExposureConfig
    from kistrader.entry.screen_contract import REGIME_MAX_BAR_AGE_DAYS
    for name, mod in (("sp500_v21", sp), ("us_small_v21", us)):
        got = mod._load_regime_params()
        check(f"{name} reads (regime_ma, max_bar_age) from the shared modules",
              got == (ExposureConfig().regime_ma, REGIME_MAX_BAR_AGE_DAYS), f"{got}")


def test_regime_probe_decides():
    print("S9 _regime_probe: on / off / and every fail-closed path")
    if not _have_pandas():
        check("pandas available for the probe tests", False, "pandas not installed")
        return
    sp, us, err = _import_screeners()
    if err:
        check("screeners importable", False, str(err)); return

    def probe(mod, closes, last_bar="2026-08-13", session="2026-08-14"):
        mod._fetch_history = lambda *a, **k: _bench_frame(closes, last_bar)
        return mod._regime_probe(20, session, 5)

    flat = [100.0] * 29
    for name, mod in (("sp500_v21", sp), ("us_small_v21", us)):
        st, c, m, b, _df, _w = probe(mod, flat + [101.0])
        check(f"{name}: close above the MA -> risk_on",
              (st, c, b) == ("risk_on", 101.0, "2026-08-13"), f"{(st, c, b)}")
        st, c, m, _b, _df, _w = probe(mod, flat + [90.0])
        check(f"{name}: close below the MA -> risk_off", st == "risk_off", st)
        st, *_ = probe(mod, [100.0] * 30)
        check(f"{name}: close EQUAL to the MA -> risk_on (>=, not >)", st == "risk_on", st)

        # every unusable path must yield state unavailable AND no numbers, so an
        # unusable probe can never be written to the sidecar as a usable one
        for label, args in (
                ("too few bars", ([100.0] * 5, "2026-08-13")),
                ("bar older than the ceiling (a cached frame)", (flat + [101.0], "2026-08-01")),
                ("bar dated after the session", (flat + [101.0], "2026-08-20"))):
            st, c, m, _b, _df, why = probe(mod, args[0], args[1])
            check(f"{name}: {label} -> unavailable, no close/ma",
                  st == "unavailable" and c is None and m is None, f"{st} {c} {m} — {why}")

        # A bar dated ON the session date is a LIVE, unsettled row: the
        # provider publishes a provisional row for the current session and it
        # MOVES between fetches, so two screeners minutes apart disagree and the
        # regime would rest on an unfinished close. It must be ignored and the
        # decision taken on the last COMPLETED bar. Found live 2026-08-19.
        st, c, m, b, _df, why = probe(mod, flat + [101.0, 999.0],
                                      last_bar="2026-08-14", session="2026-08-14")
        check(f"{name}: live bar dated the session date is ignored",
              (st, c, b) == ("risk_on", 101.0, "2026-08-13"), f"{(st, c, b)} - {why}")
        mod._fetch_history = lambda *a, **k: None
        check(f"{name}: empty fetch -> unavailable",
              mod._regime_probe(20, "2026-08-14", 5)[0] == "unavailable")
        mod._fetch_history = lambda *a, **k: (_ for _ in ()).throw(RuntimeError("boom"))
        check(f"{name}: raising fetch -> unavailable, not a crash",
              mod._regime_probe(20, "2026-08-14", 5)[0] == "unavailable")


def test_regime_gate_skips_the_scan():
    """The point of gating BEFORE Stage 1: on a risk-off day main() must return
    without a single ticker fetch or Gemini call. Proven by making every other
    network entry point raise -- if the scan runs, the test blows up."""
    print("S10 risk-off short-circuits main() before any network work")
    if not _have_pandas():
        check("pandas available for the gate test", False, "pandas not installed")
        return
    import tempfile
    from kistrader.entry.screen_contract import (read_regime, regime_path_for,
                                                 read_candidates)
    cwd, saved_stdout = os.getcwd(), sys.stdout
    try:
        for name, closes, want in (("risk_off", [100.0] * 29 + [90.0], "risk_off"),
                                   ("risk_on", [100.0] * 29 + [110.0], "risk_on")):
            sp, _us, err = _import_screeners()
            if err:
                check("screeners importable", False, str(err)); return
            sp._fetch_history = lambda *a, **k: _bench_frame(closes)
            # PATCH G -- force the gate ON. This case tests the gate MECHANISM,
            # and since F3 the deployment DEFAULT is off, so reading the default
            # made the case stop exercising anything and die on meta["doc"].
            # The disabled-gate case below already pins it explicitly; this one
            # always should have. 20 is also what makes the asserted ma=99.5.
            # 5 is REGIME_MAX_BAR_AGE_DAYS, matching the case below.
            sp._load_regime_params = lambda: (20, 5)

            hit = []
            def _boom(*a, **k):
                hit.append(1)
                raise RuntimeError("scan reached")
            sp.run_parallel_scan = _boom
            sp.calculate_spy_6m_return = _boom

            work = tempfile.mkdtemp()
            os.chdir(work)
            csv_path = os.path.join(work, "candidates.csv")
            try:
                sp.main(emit_path=csv_path, session_date="2026-08-14")
            except RuntimeError:
                pass                      # risk_on legitimately proceeds to the scan
            os.chdir(cwd)

            if want == "risk_off":
                check("risk_off: the scan was never reached", not hit, f"hit={hit}")
                check("risk_off: candidates.csv still rewritten, with zero rows",
                      os.path.exists(csv_path) and read_candidates(csv_path) == [])
                close, ma, meta = read_regime(regime_path_for(csv_path), "2026-08-14")
                check("risk_off: sidecar says risk_off and is USABLE",
                      meta["usable"] and meta["doc"]["state"] == "risk_off",
                      f"{meta['reason']}")
                check("risk_off: the numbers behind the verdict are recorded",
                      (close, ma) == (90.0, 99.5), f"{(close, ma)}")
                check("risk_off: the applied threshold is recorded per screener",
                      meta["doc"]["screeners"]["sp500_v21"]["vcp_threshold"] is not None)
            else:
                check("risk_on: the gate does NOT block the scan", bool(hit), f"hit={hit}")
    finally:
        os.chdir(cwd)
        sys.stdout = saved_stdout      # main() installs a run-log tee; unwind it


def test_run_log_tee_cannot_kill_a_run():
    """The run-log tee is a convenience. It must never be able to end a run.

    Found by pytest on Windows: its fd-level capture redirects descriptors 1/2,
    leaving sys.__stdout__ pointing at a handle the process can no longer write
    to. _Tee called .flush() on it bare, so the screener died with
    `OSError: [WinError 6] The handle is invalid` -- and the except branch's own
    print went through the same half-installed tee and raised again.

    Same mechanism, portably: a stream whose write and flush raise."""
    print("S11 the run-log tee survives a dead stream")
    import io, tempfile
    sp, us, err = _import_screeners()
    if err:
        check("screeners importable", False, str(err)); return

    class _Dead(io.StringIO):
        def write(self, s): raise OSError(6, "The handle is invalid")
        def flush(self): raise OSError(6, "The handle is invalid")

    cwd, saved_out, saved_dunder = os.getcwd(), sys.stdout, sys.__stdout__
    try:
        for name, mod in (("sp500_v21", sp), ("us_small_v21", us)):
            # (a) a dead stream inside the tee is dropped, not raised
            live = io.StringIO()
            tee = mod._Tee(_Dead(), live)
            try:
                tee.write("hello")
                tee.flush()
                ok, detail = True, ""
            except Exception as e:
                ok, detail = False, f"{type(e).__name__}: {e}"
            check(f"{name}: a dead stream is dropped, not raised", ok, detail)
            check(f"{name}: the surviving stream still receives output",
                  live.getvalue() == "hello", repr(live.getvalue()))

            # (b) the whole setup path survives a dead console
            os.chdir(tempfile.mkdtemp())
            sys.__stdout__ = _Dead()
            try:
                mod._setup_run_log("harness")
                ok, detail = True, ""
            except Exception as e:
                ok, detail = False, f"{type(e).__name__}: {e}"
            finally:
                sys.stdout, sys.__stdout__ = saved_out, saved_dunder
            check(f"{name}: _setup_run_log survives a dead console stream", ok, detail)

            # (c) an unopenable log leaves stdout untouched and reports cleanly
            real_makedirs = mod.os.makedirs
            mod.os.makedirs = lambda *a, **k: (_ for _ in ()).throw(PermissionError("denied"))
            before = sys.stdout
            try:
                mod._setup_run_log("harness")
                ok, detail = (sys.stdout is before), "stdout was replaced anyway"
            except Exception as e:
                ok, detail = False, f"{type(e).__name__}: {e}"
            finally:
                mod.os.makedirs = real_makedirs
                sys.stdout = before
            check(f"{name}: unopenable log -> console-only, stdout untouched", ok, detail)
    finally:
        os.chdir(cwd)
        sys.stdout, sys.__stdout__ = saved_out, saved_dunder


def test_regime_gate_can_be_disabled():
    """regime_ma=None is the documented one-value rollback for the whole regime
    phase, and it must not be the thing that breaks.

    Before this fix the screener raised
        TypeError: '<' not supported between instances of 'int' and 'NoneType'
    inside main(), so flipping the switch stopped the screener running at all --
    the escape hatch, unusable at exactly the moment you would reach for it."""
    print("S12 regime_ma=None disables the gate instead of crashing")
    if not _have_pandas():
        check("pandas available", False, "pandas not installed"); return
    sp, us, err = _import_screeners()
    if err:
        check("screeners importable", False, str(err)); return

    for name, mod in (("sp500_v21", sp), ("us_small_v21", us)):
        mod._fetch_history = lambda *a, **k: _bench_frame([100.0] * 30)
        try:
            st, c, m, b, df, why = mod._regime_probe(None, "2026-08-14", 5)
            ok, detail = st == "disabled", f"state={st}"
        except Exception as e:
            ok, detail = False, f"{type(e).__name__}: {e}"
        check(f"{name}: regime_ma=None -> 'disabled', not a crash", ok, detail)
        if ok:
            check(f"{name}: hands the benchmark fetch back to Stage 3",
                  df is None and c is None and m is None, f"{(c, m, df is None)}")
            check(f"{name}: the reason says DISABLED", "DISABLED" in why, why)

    # and main() must SCAN rather than gate
    import tempfile
    cwd, saved_stdout = os.getcwd(), sys.stdout
    try:
        sp, _us, err = _import_screeners()
        if err:
            check("screeners importable", False, str(err)); return
        sp._fetch_history = lambda *a, **k: _bench_frame([100.0] * 30)
        sp._load_regime_params = lambda: (None, 5)
        hit = []

        def _boom(*a, **k):
            hit.append(1)
            raise RuntimeError("scan reached")
        sp.run_parallel_scan = _boom
        sp.calculate_spy_6m_return = _boom
        work = tempfile.mkdtemp()
        os.chdir(work)
        try:
            sp.main(emit_path=os.path.join(work, "candidates.csv"),
                    session_date="2026-08-14")
        except RuntimeError:
            pass
        except Exception as e:
            check("main() survives a disabled gate", False, f"{type(e).__name__}: {e}")
        os.chdir(cwd)
        check("disabled gate does NOT block the scan", bool(hit), f"hit={hit}")
        # PATCH G -- since F4 a disabled gate DOES write a receipt. There is
        # none HERE only because the scan raises before emit is reached, so the
        # old label credited the gate for an absence the boom caused. The
        # assertion is unchanged and still true; the reason was wrong.
        check("disabled gate: the scan aborts before emit, so no receipt here",
              not os.path.exists(os.path.join(work, "regime.json")))
    finally:
        os.chdir(cwd)
        sys.stdout = saved_stdout


def test_screener_harness():
    """Single pytest entry point."""
    main()


def test_zz_all_checks_passed():
    """D8 terminal guard — must be the LAST test_ function defined in the file,
    or pytest evaluates it before the checks have run."""
    assert not FAIL, f"{len(FAIL)} failed check(s): " + "; ".join(FAIL)


def main():
    print("=" * 62)
    print("SCREENER HARNESS")
    print("=" * 62)
    test_import_without_credentials()
    test_threshold_single_source()
    test_yoy_growth()
    test_growth_and_accel_points()
    test_surprise_points()
    test_compute_math_floor()
    test_both_screeners_share_the_scoring()
    test_vcp_engines_are_identical()          # PATCH I2
    test_regime_params_come_from_one_place()
    test_regime_probe_decides()
    test_regime_gate_skips_the_scan()
    test_run_log_tee_cannot_kill_a_run()
    test_regime_gate_can_be_disabled()
    print("=" * 62)
    print(f"PASSED {len(PASS)} / {len(PASS) + len(FAIL)}")
    if FAIL:
        print("FAILED:", ", ".join(FAIL))
    print("=" * 62)
    return 1 if FAIL else 0


if __name__ == "__main__":
    sys.exit(main())
