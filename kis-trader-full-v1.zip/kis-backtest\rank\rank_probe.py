#!/usr/bin/env python3
"""
RANK PROBE -- does `rank_mode` mean what its name says, right now, on this box?

PARAMETER_FREEZE Rev 3 sec.11's original bug was *"rank_mode had never taken
effect... every run in the project's history ranked on 2*RS"*. The fix added a
third weight to PRODUCTION's decision_engine. The BACKTEST harness never got it:
`minervini_backtest.run()` sets only `rs_weight` and `stage2_weight`, so
`vcp_weight` keeps whatever DEFAULT the imported decision_engine carries.

That makes the answer depend entirely on WHICH decision_engine gets imported --
which is exactly the thing nobody can see from the output. This probe makes it
visible, and it decides nothing: it prints what is true and exits.

WHAT IT DOES
  1. Imports `kistrader.entry.decision_engine` THE WAY A REAL SWEEP DOES --
     a plain import from the harness's own working directory. No path tricks.
  2. Prints the resolved file, all three weights, and the sizing defaults.
  3. Builds a CONFLICTING-ORDER candidate set: RS ranking and VCP ranking are
     exact reverses of each other. A mode that silently ranks on the wrong field
     produces perfectly plausible output on ordinary data; only a deliberately
     conflicting fixture exposes it.
  4. For each rank_mode, constructs the DecisionEngine EXACTLY as
     minervini_backtest.run() line 460 does, runs plan(), and reports the
     selection order against what the mode's NAME claims.

    python rank_probe.py                     # run from kis-backtest
    python rank_probe.py --prod-root <path>  # force a specific decision_engine

Exit 0 = every mode ranks on what it claims. Exit 1 = at least one does not.
"""
from __future__ import annotations

import argparse
import os
import sys
from dataclasses import replace

# The harness's own table, copied verbatim (minervini_backtest.py:430-433).
# Two weights, because the vendored engine it was written against had two.
HARNESS_RANK_WEIGHTS = {
    "rs_only":     (2.0, 0.0),
    "vcp_only":    (0.0, 1.0),
    "rs_plus_vcp": (2.0, 1.0),
}

# What each mode CLAIMS to rank on. This is the contract being tested.
CLAIMS = {
    "rs_only":     "RS only",
    "vcp_only":    "VCP only",
    "rs_plus_vcp": "2*RS + 1*VCP",
}


def _mk(SC, rows):
    """rows = [(ticker, rs, vcp)]. Geometry identical across all names and chosen
    to pass decision_engine cleanly (entry 100 / stop 90), so the ONLY thing that
    can order them is the ranking weights."""
    return [SC.Candidate(
        ticker=t, exchange="NAS", rs_rating=rs, stage2_score=0.0,
        vcp_score=float(vcp), pivot=99.5025, base_high=105.0,
        base_low=90.452261, contraction_low=90.452261, depth_pct=0.09,
        last_close=99.0, atr=0.5, trade_signal=True,
        session_date="2026-08-22", name=t, close_known=True) for t, rs, vcp in rows]


# Three fixtures, each aimed at a different way the contamination can hide.
FIXTURES = [
    ("A  wide RS spread",
     "RS varies 90->65 while VCP varies 60->85. 2*RS dominates, so the ORDER "
     "survives even though the SCORE is contaminated. This is why the bug went "
     "unnoticed: on data like this it looks fine.",
     [("AAA", 90, 60), ("BBB", 85, 65), ("CCC", 80, 70),
      ("DDD", 75, 75), ("EEE", 70, 80), ("FFF", 65, 85)]),

    ("B  tight RS spread  <-- THE REALISTIC ONE",
     "RS 92->87, VCP 60->85. This is what a real candidate set looks like AFTER "
     "Stage 1: it has already filtered to high RS, so the survivors cluster and "
     "the RS spread is small while VCP still varies widely. Here the stray "
     "vcp_weight term dominates and rs_only ranks in REVERSE RS order.",
     [("AAA", 92, 60), ("BBB", 91, 65), ("CCC", 90, 70),
      ("DDD", 89, 75), ("EEE", 88, 80), ("FFF", 87, 85)]),

    ("C  two names, ratio flip",
     "Built so 2*RS+1*VCP picks AAA and 2*RS+2*VCP picks BBB. Isolates the "
     "rs_plus_vcp ratio error with nothing else moving.",
     [("AAA", 95, 60), ("BBB", 87, 72)]),
]


def _wrap(text, width):
    out, line = [], ""
    for w in text.split():
        if len(line) + len(w) + 1 > width:
            out.append(line); line = w
        else:
            line = (line + " " + w).strip()
    if line:
        out.append(line)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--prod-root", default=None,
                    help="force this repo's decision_engine onto sys.path first")
    args = ap.parse_args()

    if args.prod_root:
        sys.path.insert(0, os.path.abspath(args.prod_root))

    try:
        from kistrader.entry import decision_engine as DE
        from kistrader.entry import screen_contract as SC
    except ImportError as e:
        print(f"FATAL: cannot import kistrader.entry.decision_engine ({e})")
        print("Run this from the kis-backtest directory, or pass --prod-root.")
        return 2

    cfg0 = DE.DecisionConfig()
    has_vcp = hasattr(cfg0, "vcp_weight")

    print("=" * 78)
    print("RANK PROBE -- what does rank_mode actually rank on?")
    print("=" * 78)
    print(f"  cwd                 : {os.getcwd()}")
    print(f"  decision_engine     : {os.path.abspath(DE.__file__)}")
    print(f"  screen_contract     : {os.path.abspath(SC.__file__)}")
    print(f"  rs_weight default   : {cfg0.rs_weight}")
    print(f"  stage2_weight       : {cfg0.stage2_weight}")
    print(f"  vcp_weight          : {cfg0.vcp_weight if has_vcp else 'MISSING (2-weight engine)'}")
    print(f"  risk_per_trade_pct  : {cfg0.risk_per_trade_pct}"
          f"{'   <-- PRE-MIGRATION, frozen is 0.0085' if abs(cfg0.risk_per_trade_pct - 0.0085) > 1e-9 else '   (matches frozen)'}")
    print(f"  max_position_pct    : {cfg0.max_position_pct}"
          f"{'   <-- PRE-MIGRATION, frozen is 0.25' if abs(cfg0.max_position_pct - 0.25) > 1e-9 else '   (matches frozen)'}")
    print("=" * 78)

    account = DE.AccountState(equity=1_000_000.0, cash=1_000_000.0)
    failures = []

    for fx_name, fx_why, rows in FIXTURES:
        cands = _mk(SC, rows)
        by_rs = [c.ticker for c in sorted(cands, key=lambda c: (-c.rs_rating, c.ticker))]
        by_vcp = [c.ticker for c in sorted(cands, key=lambda c: (-c.vcp_score, c.ticker))]
        # what a CORRECT 2*RS + 1*VCP would produce
        by_true_mix = [c.ticker for c in sorted(
            cands, key=lambda c: (-(2.0 * c.rs_rating + 1.0 * c.vcp_score), c.ticker))]

        print("\n" + "=" * 78)
        print(f"  FIXTURE {fx_name}")
        print("=" * 78)
        for line in _wrap(fx_why, 74):
            print(f"    {line}")
        print(f"\n    {'ticker':<8}{'RS':>5}{'VCP':>6}")
        for c in cands:
            print(f"    {c.ticker:<8}{c.rs_rating:>5}{c.vcp_score:>6.0f}")
        print(f"\n    pure-RS order        : {' > '.join(by_rs)}")
        print(f"    pure-VCP order       : {' > '.join(by_vcp)}")
        print(f"    true 2*RS+1*VCP      : {' > '.join(by_true_mix)}")

        for mode, (rs_w, s2_w) in HARNESS_RANK_WEIGHTS.items():
            # EXACTLY what minervini_backtest.run() line 460 does -- note it
            # never mentions vcp_weight, so the engine's default survives.
            eng_cfg = replace(DE.DecisionConfig(), rs_weight=rs_w, stage2_weight=s2_w)
            eng = DE.DecisionEngine(eng_cfg)
            # ... and line 861: stage2_score := vcp_score
            ordered_in = [replace(c, stage2_score=float(c.vcp_score)) for c in cands]
            got = [p.ticker for p in eng.plan(ordered_in, account)[0]]

            eff_vcp = eng_cfg.vcp_weight if has_vcp else 0.0
            net_rs = eng_cfg.rs_weight
            net_vcp = eng_cfg.stage2_weight + eff_vcp
            reduces = f"{net_rs}*RS + {net_vcp}*VCP"

            want = {"rs_only": by_rs, "vcp_only": by_vcp,
                    "rs_plus_vcp": by_true_mix}[mode]
            ok = got[:len(want)] == want
            print(f"\n    mode {mode:<12} claims {CLAIMS[mode]:<14} "
                  f"score reduces to {reduces}")
            print(f"      got    : {' > '.join(got)}")
            if ok:
                print(f"      [OK]     matches what the name claims")
            else:
                print(f"      [WRONG]  should be : {' > '.join(want)}")
                failures.append(f"{fx_name.split()[0]}/{mode}")

    print("\n" + "=" * 78)
    if failures:
        print(f"  {len(failures)} fixture/mode combination(s) DO NOT rank on what "
              f"the name claims:")
        for f in failures:
            print(f"     - {f}")
        print("  Any sweep result produced in this configuration and labelled with")
        print("  one of those mode names does not mean what its name says.")
        print("=" * 78)
        return 1
    print("  Every mode ranks on what it claims.")
    print("=" * 78)
    return 0


if __name__ == "__main__":
    sys.exit(main())
