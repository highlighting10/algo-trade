#!/usr/bin/env python3
"""
Exit state machine — deterministic fixture (D6 / freeze-doc Option A, risk R2)
=============================================================================

WHY THIS EXISTS

`STALL_DAY = 252` makes the promotion -> TRAILING -> EMA_BREAK path unreachable
inside a short soak: at 252 there is no promotion, STALL_EXIT never fires, and
the EMA trail is reachable ONLY through the +3R partial. A soak of a few weeks
will almost certainly never execute it, so the code path that manages every
winner would ship untested.

This drives `engine_v2.ExecutionMonitor` through the whole machine with a
synthetic bar sequence in milliseconds. No market, no broker, no network.

THE STRUCTURAL FACT THIS PINS (freeze doc R2, engine_v2.on_close):

    if   pos.state == FILLED and pos.days_held >= STALL_DAY:   -> stall or promote
    elif pos.state in (TRAILING, PARTIAL_TAKEN):               -> EMA break

A FILLED position below `STALL_DAY` never reaches the `elif`, so between the
fill and the +3R partial its ONLY exit is the original stop. At STALL_DAY = 252
that is nearly the whole life of nearly every trade. Case D asserts it directly:
if someone ever "fixes" that elif into an if, this test fails loudly rather than
silently changing the strategy that was backtested.

STALL_DAY IS SET PER CASE, never assumed. The fixture therefore passes both
before Phase 2 (STALL_DAY = 10) and after it (252) — it tests the machine, not
the parameter. Asserting the production VALUE is a separate Phase 2 test.

WHAT THIS DOES **NOT** CLOSE

F8 has two halves. This closes the first: engine_v2's exit machine is exercised
and pinned. The second — proving the BACKTEST HARNESS reimplementation produces
identical exits — needs `minervini_backtest.py` from the kis-backtest repo and
is still open. Every exit number in the freeze doc still comes from a
reimplementation that has never been compared against the code below.

Run:  python tests/test_exit_state_machine.py      (or via pytest)
"""
from __future__ import annotations

import contextlib
import os

# Self-locating AND shadow-proof. Two separate problems, both measured:
#  1. `kistrader` and `screeners` are not installed packages (pyproject
#     packages.find includes only kistrader*), so a DIRECT run -- sys.path[0] is
#     tests/ -- cannot import either. pytest happens to work because pyproject
#     sets pythonpath = [".", "tests"].
#  2. kis-backtest ships a partial COPY of kistrader/. Run pytest from the parent
#     directory and it collects both projects; whichever imports first wins
#     sys.modules, and after that sys.path is irrelevant -- Python never
#     re-resolves an imported package. That produced five collection errors
#     naming the wrong repo.
import os as _os, sys as _sys
_ROOT = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))
for _p in (_os.path.join(_ROOT, "screeners"), _ROOT):
    while _p in _sys.path:
        _sys.path.remove(_p)                 # move to the FRONT, not merely present
    _sys.path.insert(0, _p)
_k = _sys.modules.get("kistrader")
_kf = _os.path.abspath(getattr(_k, "__file__", "") or "") if _k is not None else ""
if _k is not None and not _kf.startswith(_ROOT + _os.sep):
    print(f"[path] evicting a foreign kistrader loaded from {_kf!r}; "
          f"this suite tests {_ROOT!r}")
    for _m in [_m for _m in list(_sys.modules)
               if _m == "kistrader" or _m.startswith("kistrader.")]:
        del _sys.modules[_m]

from kistrader.core import engine_v2 as E
from kistrader.core.engine_v2 import (ExecutionMonitor, PositionState, Position,
                                      HOLDING_STATES, GONE)
from test_entry_half import FakeBroker, FakeClock, _db


PASS, FAIL = [], []


def check(name, cond, detail=""):
    (PASS if cond else FAIL).append(name)
    print(f"  [{'PASS' if cond else 'FAIL'}] {name}" + (f"  ({detail})" if detail and not cond else ""))


@contextlib.contextmanager
def stall_day(n):
    """Set engine_v2.STALL_DAY for one case and always restore it. Every case
    states the value it exercises, so nothing here depends on the production
    default — which is exactly what Phase 2 changes."""
    old = E.STALL_DAY
    E.STALL_DAY = n
    try:
        yield n
    finally:
        E.STALL_DAY = old


def _mon():
    b = FakeBroker()
    db, path = _db()
    return b, db, path, ExecutionMonitor(b, db, alert=lambda m: None, clock=FakeClock())


def _pos(shares=30, entry=100.0, stop=90.0, days=0, state=PositionState.FILLED):
    """entry 100 / stop 90 -> risk 10/sh, so +1R = 110 and +3R = 130."""
    return Position(ticker="TST", state=state, shares=shares, entry_price=entry,
                    stop_loss_price=stop, initial_risk_per_share=entry - stop,
                    exchange="NAS", days_held=days, order_key="TST:2026-08-12")


def _events(db, key="TST:2026-08-12"):
    return [r[0] for r in db.conn.execute(
        "SELECT event_type FROM position_events WHERE order_key=? ORDER BY id", (key,))]


# ---------------------------------------------------------------- A ----------
def case_a_promotion():
    print("A  day >= STALL_DAY and R >= floor -> promoted to TRAILING")
    b, db, path, mon = _mon()
    with stall_day(10):
        p = _pos(days=10)
        mon.on_close(p, 115.0, 999.0)      # r = +1.5R, above STALL_R_FLOOR (1.0)
        check("promoted to TRAILING", p.state == PositionState.TRAILING, f"{p.state}")
        check("no exit queued on promotion", p.pending_exit is None, f"{p.pending_exit}")
        check("promotion is recorded in the event store",
              "DAY10_SURVIVOR" in _events(db), f"{_events(db)}")
        check("promotion did not touch the stop", p.stop_loss_price == 90.0,
              f"{p.stop_loss_price}")
        # one day short of the gate: nothing happens at all
        q = _pos(days=9)
        mon.on_close(q, 115.0, 999.0)
        check("day STALL_DAY-1 does NOT promote", q.state == PositionState.FILLED
              and q.pending_exit is None, f"{q.state}/{q.pending_exit}")
    db.conn.close(); os.unlink(path)


# ---------------------------------------------------------------- B ----------
def case_b_stall_exit():
    print("B  day >= STALL_DAY and R < floor -> STALL_EXIT, executed next open")
    b, db, path, mon = _mon()
    with stall_day(10):
        p = _pos(days=10)
        mon.on_close(p, 105.0, 999.0)      # r = +0.5R, below the 1.0 floor
        check("STALL_EXIT queued", p.pending_exit == "STALL_EXIT", f"{p.pending_exit}")
        check("still FILLED until the open (exits are queued, not fired at close)",
              p.state == PositionState.FILLED, f"{p.state}")
        check("stall flagged in the event store", "STALL_FLAGGED" in _events(db),
              f"{_events(db)}")
        b._holdings["TST"] = p.shares
        mon.on_session_open(p, 105.0, 104.9)
        check("next open begins the exit", p.state == PositionState.EXITING, f"{p.state}")
        check("exit reason carried through", p.exit_reason == "STALL_EXIT", f"{p.exit_reason}")
        check("a SELL was actually placed", b.place_calls == 1, f"{b.place_calls}")
        check("pending_exit consumed exactly once", p.pending_exit is None)
    db.conn.close(); os.unlink(path)


# ---------------------------------------------------------------- C ----------
def case_c_ema_break_from_trailing():
    print("C  TRAILING + close < EMA21 -> EMA_BREAK, executed next open")
    b, db, path, mon = _mon()
    with stall_day(10):
        p = _pos(days=12, state=PositionState.TRAILING)
        mon.on_close(p, 120.0, 112.0)      # close ABOVE the ema -> hold
        check("close above EMA does not flag", p.pending_exit is None, f"{p.pending_exit}")
        mon.on_close(p, 110.0, 112.0)      # close BELOW the ema -> break
        check("close below EMA queues EMA_BREAK", p.pending_exit == "EMA_BREAK",
              f"{p.pending_exit}")
        check("EMA flag recorded", "EMA_FLAGGED" in _events(db), f"{_events(db)}")
        b._holdings["TST"] = p.shares
        mon.on_session_open(p, 110.0, 109.9)
        check("next open begins the exit", p.state == PositionState.EXITING, f"{p.state}")
        check("exit reason is EMA_BREAK", p.exit_reason == "EMA_BREAK", f"{p.exit_reason}")
        check("a SELL was actually placed", b.place_calls == 1, f"{b.place_calls}")
    db.conn.close(); os.unlink(path)


# ---------------------------------------------------------------- D ----------
def case_d_elif_structure_at_252():
    print("D  THE R2 FACT: at STALL_DAY=252 a FILLED position gets NO trail")
    b, db, path, mon = _mon()
    with stall_day(252):
        p = _pos(days=30)
        # a catastrophic close, far under the EMA. The elif is unreachable while
        # the position is FILLED and short of day 252, so nothing may be queued.
        mon.on_close(p, 50.0, 200.0)
        check("FILLED below STALL_DAY is NOT evaluated against the EMA",
              p.pending_exit is None, f"{p.pending_exit}")
        check("state unchanged", p.state == PositionState.FILLED, f"{p.state}")
        check("nothing written to the event store", _events(db) == [], f"{_events(db)}")
        # ... and the same bar DOES act once the position has been promoted
        q = _pos(days=30, state=PositionState.TRAILING)
        mon.on_close(q, 50.0, 200.0)
        check("the identical bar DOES flag once TRAILING", q.pending_exit == "EMA_BREAK",
              f"{q.pending_exit}")
        # the only surviving exit for a FILLED position is its original stop
        b._holdings["TST"] = p.shares
        mon.on_tick(p, 89.0, 88.9)
        check("the fixed stop is still the one live exit",
              p.state == PositionState.EXITING and p.exit_reason == "STOP_HIT",
              f"{p.state}/{p.exit_reason}")
    db.conn.close(); os.unlink(path)


# ---------------------------------------------------------------- E ----------
def case_e_partial_then_trail():
    print("E  +3R partial -> PARTIAL_TAKEN -> EMA trail (the ONLY route at 252)")
    b, db, path, mon = _mon()
    with stall_day(252):
        p = _pos(shares=30, days=30)
        b._holdings["TST"] = 30
        mon.on_tick(p, 129.0, 128.9)                  # +2.9R: below the trigger
        check("below +3R sends no partial", b.place_calls == 0 and not p.partial_pending)

        mon.on_tick(p, 130.0, 129.9)                  # +3.0R: trigger
        check("+3R sends a partial SELL", b.place_calls == 1 and p.partial_pending,
              f"place={b.place_calls} pending={p.partial_pending}")
        check("partial is one third of the position", p.partial_qty == 10, f"{p.partial_qty}")
        check("breakeven NOT taken before the fill is confirmed",
              p.stop_loss_price == 90.0 and p.state == PositionState.FILLED,
              f"{p.stop_loss_price}/{p.state}")

        oid = p.partial_order_id
        b._fills[oid] = None                          # UNKNOWN read
        mon.on_tick(p, 131.0, 130.9)
        check("UNKNOWN fill does not move the stop", p.stop_loss_price == 90.0
              and p.state == PositionState.FILLED, f"{p.stop_loss_price}/{p.state}")

        b._fills[oid] = 10                            # CONFIRMED
        mon.on_tick(p, 131.0, 130.9)
        check("confirmed partial -> PARTIAL_TAKEN", p.state == PositionState.PARTIAL_TAKEN,
              f"{p.state}")
        check("stop moves to breakeven only now", p.stop_loss_price == p.entry_price,
              f"{p.stop_loss_price}")
        check("remaining share count reduced", p.shares == 20, f"{p.shares}")
        check("PARTIAL_TAKEN recorded", "PARTIAL_TAKEN" in _events(db), f"{_events(db)}")

        # the point of the whole case: the trail is now reachable at STALL_DAY=252
        mon.on_close(p, 120.0, 125.0)
        check("PARTIAL_TAKEN + close < EMA -> EMA_BREAK at STALL_DAY=252",
              p.pending_exit == "EMA_BREAK", f"{p.pending_exit}")
        b._holdings["TST"] = p.shares
        mon.on_session_open(p, 120.0, 119.9)
        check("the trail exit executes", p.state == PositionState.EXITING
              and p.exit_reason == "EMA_BREAK", f"{p.state}/{p.exit_reason}")
    db.conn.close(); os.unlink(path)


# ---------------------------------------------------------------- F ----------
def case_f_day_roll_idempotent():
    print("F  advance_trading_day is idempotent per session date")
    b, db, path, mon = _mon()
    p = _pos(days=0)
    mon.advance_trading_day([p], "2026-08-12")
    mon.advance_trading_day([p], "2026-08-12")        # same date again
    check("same date rolls exactly once", p.days_held == 1, f"{p.days_held}")
    mon.advance_trading_day([p], "2026-08-13")
    check("a new date rolls again", p.days_held == 2, f"{p.days_held}")
    p.state = PositionState.EXITING
    mon.advance_trading_day([p], "2026-08-14")
    check("a non-holding position does not roll", p.days_held == 2, f"{p.days_held}")
    db.conn.close(); os.unlink(path)


# ---------------------------------------------------------------- G ----------
def case_g_stop_precedence():
    print("G  the hard stop outranks every queued exit, in any holding state")
    for st in (PositionState.FILLED, PositionState.TRAILING, PositionState.PARTIAL_TAKEN):
        b, db, path, mon = _mon()
        p = _pos(days=5, state=st)
        b._holdings["TST"] = p.shares
        p.pending_exit = "EMA_BREAK"                  # queued from last close
        mon.on_tick(p, 90.0, 89.9)                    # price touches the stop NOW
        check(f"{st.value}: stop fires immediately as STOP_HIT",
              p.state == PositionState.EXITING and p.exit_reason == "STOP_HIT",
              f"{p.state}/{p.exit_reason}")
        db.conn.close(); os.unlink(path)


def test_exit_state_machine():
    """Single pytest entry point: the cases are ordered and share nothing, so
    running them as one test keeps the direct run and pytest identical."""
    main()


def test_zz_all_checks_passed():
    """D8 terminal guard. check() never raises, so without this pytest reports
    every function in this file as passed no matter how many checks failed.
    Defined last on purpose: pytest runs file order, so this sees the whole run.
    Harmless under the direct `python tests/...` run, which main() drives."""
    assert not FAIL, f"{len(FAIL)} failed check(s): " + "; ".join(FAIL)


# --- PATCH D --------------------------------------------------- H, I, J ----
def _mon_alerting():
    """A monitor whose alerts and clock the caller can reach."""
    b = FakeBroker()
    db, _path = _db()
    clk = FakeClock()
    seen = []
    return b, db, clk, seen, ExecutionMonitor(b, db, alert=seen.append, clock=clk)


def _count_holding_reads(b):
    calls = []
    orig = b.get_holding
    b.get_holding = lambda t, e="NAS": (calls.append(1), orig(t, e))[1]
    return calls


def case_h_partial_broker_says_flat():
    print("H  +3R with the broker reporting FLAT -> no partial, no breakeven")
    b, db, _clk, seen, mon = _mon_alerting()
    with stall_day(252):
        p = _pos(shares=30, days=30)
        b._holdings = {}                       # reports 0 while we believe we hold 30
        mon.on_tick(p, 130.0, 129.9)           # +3R
        check("no partial order sent", b.place_calls == 0, f"{b.place_calls}")
        check("stop NOT moved to breakeven", p.stop_loss_price == 90.0,
              f"{p.stop_loss_price}")
        check("state NOT flipped to PARTIAL_TAKEN", p.state == PositionState.FILLED,
              f"{p.state}")
        check("partial_done NOT set", not p.partial_done)
        check("shares untouched", p.shares == 30, f"{p.shares}")
        check("it alerts", any("reports 0 held" in m for m in seen), f"{seen}")
        check("NOT logged as SKIPPED_SMALL",
              "PARTIAL_SKIPPED_SMALL" not in _events(db), f"{_events(db)}")


def case_i_partial_read_throttled():
    print("I  a bad holdings read is throttled, then recovers")
    b, db, clk, seen, mon = _mon_alerting()
    calls = _count_holding_reads(b)
    with stall_day(252):
        p = _pos(shares=30, days=30)
        b._holdings_readable = False           # UNKNOWN
        mon.on_tick(p, 130.0, 129.9)
        check("the first +3R tick reads holdings once", len(calls) == 1, f"{calls}")
        mon.on_tick(p, 131.0, 130.9)
        mon.on_tick(p, 132.0, 131.9)
        check("further ticks inside the window do NOT re-read", len(calls) == 1,
              f"{len(calls)}")
        check("UNKNOWN does not alert (only a hard zero does)", seen == [], f"{seen}")
        clk.advance(E.PARTIAL_RETRY_SECS + 1.0)
        b._holdings_readable = True
        b._holdings["TST"] = 30
        mon.on_tick(p, 131.0, 130.9)
        check("after the window a good read partials normally",
              b.place_calls == 1 and p.partial_pending,
              f"place={b.place_calls} pending={p.partial_pending}")
        check("partial is still one third", p.partial_qty == 10, f"{p.partial_qty}")


def case_j_tiny_position_needs_no_broker():
    print("J  a 2-share position is a SIZE fact -- no holdings read at all")
    b, db, _clk, _seen, mon = _mon_alerting()
    calls = _count_holding_reads(b)
    with stall_day(252):
        p = _pos(shares=2, days=30)            # int(2/3) == 0
        mon.on_tick(p, 130.0, 129.9)
        check("no holdings read for a size decision", not calls, f"{calls}")
        check("no order sent", b.place_calls == 0, f"{b.place_calls}")
        check("breakeven armed anyway", p.stop_loss_price == p.entry_price,
              f"{p.stop_loss_price}")
        check("PARTIAL_TAKEN so the trail stays reachable",
              p.state == PositionState.PARTIAL_TAKEN, f"{p.state}")
        check("logged as SKIPPED_SMALL", "PARTIAL_SKIPPED_SMALL" in _events(db),
              f"{_events(db)}")


def case_k_second_position_alerts_again():
    print("K  a LATER position in the same ticker must alert again")
    b, db, _clk, seen, mon = _mon_alerting()
    with stall_day(252):
        b._holdings = {}
        p1 = _pos(shares=30, days=30)
        mon.on_tick(p1, 130.0, 129.9)
        check("first position alerts", len(seen) == 1, f"{seen}")
        p2 = _pos(shares=30, days=30)             # same ticker, NEW trade
        p2.order_key = "TST:2026-09-30"
        mon.on_tick(p2, 130.0, 129.9)
        check("the next position alerts too (not suppressed by a stale key)",
              len(seen) == 2, f"{len(seen)}: {seen}")


def main():
    print("=" * 62)
    print("EXIT STATE MACHINE — DETERMINISTIC FIXTURE (R2 / F8 first half)")
    print("=" * 62)
    case_a_promotion()
    case_b_stall_exit()
    case_c_ema_break_from_trailing()
    case_d_elif_structure_at_252()
    case_e_partial_then_trail()
    case_f_day_roll_idempotent()
    case_g_stop_precedence()
    case_h_partial_broker_says_flat()          # --- PATCH D ---
    case_i_partial_read_throttled()            # --- PATCH D ---
    case_j_tiny_position_needs_no_broker()     # --- PATCH D ---
    case_k_second_position_alerts_again()      # --- PATCH D ---
    print("=" * 62)
    print(f"PASSED {len(PASS)} / {len(PASS) + len(FAIL)}")
    if FAIL:
        print("FAILED:", ", ".join(FAIL))
    print(f"STALL_DAY restored to {E.STALL_DAY}")
    print("=" * 62)
    return 1 if FAIL else 0


if __name__ == "__main__":
    import sys
    sys.exit(main())
