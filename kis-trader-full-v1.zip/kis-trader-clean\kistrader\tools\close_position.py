#!/usr/bin/env python3
"""
close_position.py — terminally close a position record the engine still tracks.
==============================================================================

WHY THIS EXISTS
  Recovery rehydrates every NON-TERMINAL snapshot, forever. A record that can no
  longer resolve itself — a wrong-exchange seed that never quotes, a position
  closed by hand in the broker app, a row whose fills the API never confirmed —
  is therefore immortal: it reloads on every start, inflates the live count, and
  (as observed 2026-07-23) makes reconcile emit "broker=0 but no positive fill
  evidence — NOT closing" on every pass. That refusal is CORRECT: the engine must
  never infer a close it cannot prove. This command is the human supplying that
  proof deliberately, with a written audit trail.

THE SAFETY THAT MATTERS
  Closing a record whose shares the broker STILL HOLDS would strand a real
  position with no stop and no manager — strictly worse than the phantom. So the
  default REFUSES unless the broker confirms flat:
      * broker holds > 0 of that ticker  -> refuse (use --force only if you are
        deliberately handing the position back to manual management)
      * holdings unreadable              -> refuse (unknown is not flat)
      * broker holds 0                   -> proceed
  --force skips the check entirely and is meant for an offline box or a ticker
  the API can't price; it is logged in the event trail as a forced close.

USAGE
  python -m kistrader.cli close --order-key F:2026-07-22 --confirm
  python -m kistrader.cli close --order-key F:2026-07-22 --reason "wrong exchange" --confirm
"""
from __future__ import annotations

import argparse
import sys


def main(argv=None, broker_factory=None) -> int:
    ap = argparse.ArgumentParser(prog="kistrader close", description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--order-key", required=True,
                    help="exact trade id, e.g. F:2026-07-22 (see the event store)")
    ap.add_argument("--reason", default="manual",
                    help="free text recorded in the event (why this was closed)")
    ap.add_argument("--confirm", action="store_true",
                    help="required: acknowledges this permanently ends the record")
    ap.add_argument("--allow-live", action="store_true",
                    help="permit when KIS_MOCK=0 (otherwise mock-only)")
    ap.add_argument("--force", action="store_true",
                    help="skip the broker-holdings safety check (offline box, or "
                         "deliberately handing the position to manual management)")
    args = ap.parse_args(argv)

    from kistrader.config import Config
    from kistrader.core.engine_v2 import EventStore, PositionState

    cfg = Config.from_env()

    if not args.confirm:
        raise SystemExit("refusing without --confirm (this permanently closes the record)")
    if not cfg.is_mock and not args.allow_live:
        raise SystemExit("KIS_MOCK=0 (live) — refusing to close without --allow-live")

    db = EventStore(cfg.db_path)
    target = None
    for snap in db.load_open_snapshots():
        if snap.order_key == args.order_key:
            target = snap
            break
    if target is None:
        raise SystemExit(f"no live (non-terminal) record for order_key "
                         f"{args.order_key!r} — nothing to close. Check the key: "
                         f"SELECT DISTINCT order_key FROM position_events;")

    # --- broker safety gate (fail closed: only a CONFIRMED flat allows a close) ---
    if args.force:
        print("WARNING: --force — skipping the broker-holdings check")
    else:
        if broker_factory is None:
            from kistrader.entry.entry_manager import KISBrokerWithEntry
            def broker_factory():
                return KISBrokerWithEntry(cfg.app_key, cfg.app_secret, cfg.cano,
                                          is_mock=cfg.is_mock)
        try:
            held = broker_factory().get_all_holdings()
        except Exception as ex:                                   # noqa: BLE001
            raise SystemExit(f"holdings read raised ({ex}) — refusing to close on "
                             f"an unknown position. Retry, or --force deliberately.")
        if held is None:
            raise SystemExit("holdings UNREADABLE — refusing to close on an unknown "
                             "position (unknown is not flat). Retry, or --force.")
        qty = int(held.get(target.ticker, 0) or 0)
        if qty > 0:
            raise SystemExit(
                f"broker still holds {qty} {target.ticker}. Closing the record now "
                f"would strand a REAL position with no stop and no manager. Sell it "
                f"first, or pass --force if you are taking it over manually.")
        print(f"broker confirms flat for {target.ticker} (0 shares) — safe to close")

    was_shares, was_state = target.shares, target.state.value
    target.state = PositionState.CLOSED
    target.shares = 0
    tag = "MANUAL_CLOSED_FORCED" if args.force else "MANUAL_CLOSED"
    db.log(target, f"{tag}:{args.reason}", float(target.entry_price))

    print(f"closed {target.ticker} record {args.order_key} "
          f"(was {was_state}, {was_shares}sh) — reason: {args.reason}")
    print(f"  db={cfg.db_path}; recovery will no longer rehydrate it.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
