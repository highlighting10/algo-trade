"""
07_survivorship.py -- size the survivorship hole. Free, no paid data.

Runs the three free tools:
  C  universe_coverage()          how much of the historical population is invisible
  E  bias_gradient()              how much each ADDED survivorship layer inflates
  A' synthetic_delisting_stress() what delistings would have cost, at the base rate

None of these CORRECTS the bias. They bound it. Report the bounds beside the
results; never subtract them.

Optional input: data/removals.csv with columns  date,ticker,reason
(scraped from the Wikipedia "selected changes" tables). Without it, the coverage
step is skipped and only the gradient and stress run.
"""
import pathlib as _pl
import sys as _sys
_sys.path.insert(0, str(_pl.Path(__file__).resolve().parent.parent))
import pathlib
import pickle

import pandas as pd

from minervini_backtest import (BacktestConfig, DecisionConfig,
                                load_sector_map, run, survivorship_adjustment,
                                synthetic_delisting_stress, universe_coverage)

# Shumway & Warther (1999, J.Finance): performance-related delisting base rates.
RATE_NYSE_AMEX = 0.012
RATE_NASDAQ = 0.056
DELIST_RETURN = -0.55
# Match whatever threshold your sweep settled on; 80 is the production default but
# will produce zero trades in a window where nothing clears it.
THRESHOLD = float(__import__("os").environ.get("BT_THRESHOLD", 80.0))


def main():
    bars = {p.stem: pd.read_parquet(p)
            for p in pathlib.Path("data/bars").glob("*.parquet")}
    prices = {t: d for t, d in bars.items() if t != "^GSPC"}
    import os as _os2
    _sig_path = _os2.environ.get("BT_SIGNALS", "data/signals.pkl")
    print(f"[survivorship] signals: {_sig_path}")
    with open(_sig_path, "rb") as f:
        signals = pickle.load(f)["signals"]
    cfg = BacktestConfig(rank_mode="rs_only", equity_mode="compounding",
                         entry_mode="pivot_limit", ambiguity_mode="worst",
                         vcp_threshold=THRESHOLD, slippage_bps=5.0,
                         sector_map=load_sector_map("data/sectors.csv"),
                         decision=DecisionConfig())

    # ---------------- C: coverage -------------------------------------------
    print("=" * 66)
    print("C -- UNIVERSE COVERAGE (the blind spot)")
    print("=" * 66)
    rem_path = pathlib.Path("data/removals.csv")
    if not rem_path.exists():
        print("  data/removals.csv not found -- skipping.")
        print("  To enable: scrape the Wikipedia 'selected changes' tables into")
        print("  columns date,ticker,reason. Reinstate rows whose reason is a")
        print("  REBALANCE or market-cap decline: those names are still listed and")
        print("  still in yfinance, so they cost nothing to add back.")
    else:
        rem = pd.read_csv(rem_path, parse_dates=["date"])
        today = set(pd.read_csv("data/universe.csv")["ticker"].astype(str))
        constituents = {}
        for snap in pd.date_range(rem["date"].min(), pd.Timestamp.today(), freq="YS"):
            later = set(rem.loc[rem["date"] > snap, "ticker"].astype(str))
            constituents[snap] = sorted(today | later)
        cov = universe_coverage(constituents, priceable=set(prices))
        for r in cov["by_date"]:
            print(f"  {r['date'].date()}  {r['priceable']:5}/{r['constituents']:<5} "
                  f"priceable  {r['coverage_pct']:6.2f}%  {r['missing']} invisible")
        print(f"\n  worst coverage : {cov['worst_coverage_pct']}%   <-- PUT THIS IN "
              f"EVERY REPORTED RESULT")
        print(f"  mean coverage  : {cov['mean_coverage_pct']}%")
        print(f"  never seen     : {cov['distinct_missing_tickers']} ticker(s)")
        if "reason" in rem.columns:
            print("\n  removals by reason (they do NOT point the same way):")
            for k, v in rem["reason"].str.lower().value_counts().head(8).items():
                print(f"    {v:5}  {k[:60]}")

    # ---------------- E: bias gradient -- WITHDRAWN ------------------------
    print("\n" + "=" * 66)
    print("E -- BIAS GRADIENT: WITHDRAWN, IT DID NOT MEASURE WHAT IT CLAIMED")
    print("=" * 66)
    print("  The layers filtered tickers by TOTAL RETURN, assuming 'keep only")
    print("  winners' simulates an extra layer of survivorship. It does not.")
    print("  Real survivorship bias is about companies that VANISHED, not")
    print("  companies that underperformed.")
    print()
    print("  On live data it produced a NEGATIVE slope (0.113 -> 0.031 -> 0.017):")
    print("  filtering to high-total-return names LOWERED per-trade expectancy,")
    print("  because those names were already extended and the VCP entries on")
    print("  them were late. That is a real observation about entry timing, but")
    print("  it is not a survivorship bound in either direction.")
    print()
    print("  It cannot be repaired without the vanished names -- the very thing")
    print("  the free path lacks. Use C (coverage) to size the hole and A'")
    print("  (stress) to bound the damage. Do not report a gradient.")

    # ---------------- A': synthetic delisting stress --------------------------
    print("\n" + "=" * 66)
    print("A' -- SYNTHETIC DELISTING STRESS (no delisted-price source needed)")
    print("=" * 66)
    for label, rate in (("sp500  (NYSE/AMEX 1.2%/yr)", RATE_NYSE_AMEX),
                        ("us_small (Nasdaq 5.6%/yr)", RATE_NASDAQ)):
        s = synthetic_delisting_stress(prices, signals, cfg,
                                       delist_rate_per_year=rate,
                                       delist_return=DELIST_RETURN,
                                       n_draws=100, seed=1)
        print(f"  {label}")
        print(f"    baseline={s['baseline_expectancy_R']}  p50={s['p50']}  "
              f"p05={s['p05']}  WORST={s['worst_draw']}")
        print(f"    mean shift={s['mean_shift_vs_baseline']}  "
              f"avg {s['mean_events_per_draw']} event(s)/draw")
    print("  Report the WORST draw, per the standing worst-bound rule.")

    # ---------------- academic cross-check -----------------------------------
    print("\n" + "=" * 66)
    print("ACADEMIC CROSS-CHECK")
    print("=" * 66)
    _, trades, _, _, diag = run(prices, signals, cfg)
    measured = diag.get("stop_catches_frac_measured")
    print(f"  held_ticker_time_frac = {diag['held_ticker_time_frac']}  "
          f"<- a delisting can only hurt a name you were HOLDING")
    if not trades:
        print("  no trades in this run -- the academic estimator needs at least one")
        print("  (it scales by average holding period). Lower --threshold or widen")
        print("  the window and rerun.")
    else:
        for catches in (0.9, 0.7, 0.5):
            a = survivorship_adjustment(trades, delist_rate_per_year=RATE_NASDAQ,
                                        stop_catches_frac=catches)
            print(f"  stop_catches={catches:.0%} -> drag "
                  f"{a['expected_drag_per_trade_pct_equity']}% equity/trade, "
                  f"{a['expected_drag_over_run_pct_equity']}% over the run")
    print(f"  measured stop_catches_frac: {measured} "
          f"(None until real delisting_events are supplied)")
    print("\n  stop_catches_frac is an ASSUMPTION and dominates this figure.")
    print("  State whichever value you use in every report.")


if __name__ == "__main__":
    main()
