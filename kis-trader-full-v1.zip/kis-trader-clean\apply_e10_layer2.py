#!/usr/bin/env python3
"""
apply_e10_layer2.py -- E10 layer 2: wire progressive exposure to real trades.

Layer 1 (commit e174caf) built the MECHANISM inside exposure_controller.py:
ExposureConfig.loss_streak_ceilings, streak_ceiling(), loss_streak_from(), and
decide(loss_streak=...). It is pure, default OFF, and nothing calls it.

Layer 2 is the wiring, and only the wiring:

  1. engine_v2.EventStore.recent_closed_r()  -- the READ. Realized R of the
     most recent CLOSED trades, newest first, with float('nan') wherever R is
     not computable from what was actually logged.
  2. pipeline.PipelineLoop.arm_today()       -- the CALL SITE. Reads the
     streak, owns its failure path, passes a NUMBER to decide(), and reports
     the new LOSS_STREAK state instead of mislabelling it as a regime fault.
  3. param_snapshot.PINNED_EXPOSURE          -- the DRIFT GUARD. Without it a
     new ExposureConfig field can be switched on by an edit to the module
     default and nothing in the tree would say so.

DEFAULT IS STILL OFF. ExposureConfig.loss_streak_ceilings defaults to None and
build_pipeline never passes an ExposureConfig, so on this tree the read is not
even performed and behaviour is byte-for-byte what it was before.

USAGE
    python apply_e10_layer2.py --verify      # check only, no writes
    python apply_e10_layer2.py               # apply
    python apply_e10_layer2.py --revert      # byte-exact undo
    python apply_e10_layer2.py --force-branch  # skip the branch guard

Run from the repo root (kis-trader-clean).
"""
from __future__ import annotations

import argparse
import json
import math
import os
import subprocess
import sys
import tempfile

REPO_BRANCH = "e10-progressive-exposure"

F_ENGINE = os.path.join("kistrader", "core", "engine_v2.py")
F_PIPE = os.path.join("kistrader", "entry", "pipeline.py")
F_SNAP = os.path.join("kistrader", "tools", "param_snapshot.py")

SENTINEL_ENGINE = "def recent_closed_r"
SENTINEL_PIPE = "loss_streak=streak"
SENTINEL_SNAP = "PINNED_EXPOSURE"

# Probes used by the severity checks below. They are the plain-text shape of
# the two alert strings the patch inserts; the verify also asserts that the
# distinctive fragment of each really is in the patched file, so a reworded
# alert cannot pass this check by leaving the probe behind.
LOSS_STREAK_ALERT_PROBE = ("progressive exposure: progressive exposure: 3 "
                           "consecutive losing trade(s) -> ceiling 0.25 -- "
                           "ceiling 25%, new entries limited. Exits and "
                           "existing positions are unaffected.")
READ_ERROR_ALERT_PROBE = ("loss-streak read error: ValueError() -- the "
                          "progressive-exposure gate cannot evaluate")

# --------------------------------------------------------------------------
# 1. engine_v2.py -- the read
# --------------------------------------------------------------------------

ENGINE_OLD = '''        if not row or not row[0]:
            return None
        return Position.from_dict(json.loads(row[0])), float(row[1] or 0.0)
'''

ENGINE_NEW = '''        if not row or not row[0]:
            return None
        return Position.from_dict(json.loads(row[0])), float(row[1] or 0.0)

    # --- E10 layer 2 2026-09-19 --- progressive exposure reads OUR OWN trades.
    def recent_closed_r(self, limit: int = 20) -> list:
        """Realized R of the most recently CLOSED trades, NEWEST FIRST.

        CONFIRM, NEVER INFER. Every value comes from the CLOSED event's own
        price column and payload. Where R is not computable from what was
        actually logged, the entry is float('nan') -- never a filled-in guess:

          * partial_done=True   the +3R partial's FILL price is nowhere in the
                                log. _finalize_partial records the tick price,
                                and the KIS fills feed returns a QUANTITY, not
                                a price, so the blended R of a two-leg exit
                                cannot be reconstructed. Scoring the final leg
                                alone would call a +1R trade a loss.
          * initial_risk_per_share <= 0   R is undefined, not zero. Position.
                                r_multiple() returns 0.0 there, which would
                                read as a scratch; that is a different claim.
          * a payload that will not parse.

        RECONCILE_CLOSED is NOT included at all: that path logs at entry_price
        because the exit price is genuinely unknown, so it would enter as a
        fabricated 0.0.

        loss_streak_from() STOPS at a NaN, so an unknown trade ends a streak
        rather than extending it. That is the permissive direction, and it is
        deliberate: the failure mode is a ceiling left at 1.00, which is
        today's behaviour and the deployment control. Closing it requires the
        partial fill price to be recorded at _finalize_partial.
        """
        n = max(1, int(limit))
        rows = self.conn.execute(
            "SELECT order_key, price, payload FROM position_events "
            "WHERE event_type LIKE 'CLOSED:%' AND payload IS NOT NULL "
            "ORDER BY id DESC LIMIT ?", (n * 4,)).fetchall()
        out, seen = [], set()
        for order_key, price, payload in rows:
            if order_key in seen:
                continue          # one trade, one verdict; newest event wins.
            seen.add(order_key)   # a re-adopted key must not count twice --
            try:                  # two rows would fire the gate a rung early.
                d = json.loads(payload)
                risk = float(d.get("initial_risk_per_share") or 0.0)
                if d.get("partial_done") or risk <= 0 or price is None:
                    out.append(float("nan"))
                else:
                    out.append((float(price) - float(d["entry_price"])) / risk)
            except (ValueError, TypeError, KeyError):
                out.append(float("nan"))
            if len(out) >= n:
                break
        return out
'''

# --------------------------------------------------------------------------
# 2. pipeline.py -- the call site
# --------------------------------------------------------------------------

PIPE_IMPORT_OLD = '''from kistrader.entry.exposure_controller import (ExposureController,
                                                 ExposureState,
                                                 apply_to_decision_config)
'''

PIPE_IMPORT_NEW = '''from kistrader.entry.exposure_controller import (ExposureController,
                                                 ExposureState,
                                                 loss_streak_from,
                                                 apply_to_decision_config)
'''

PIPE_CALL_OLD = '''        regime = self.exposure.decide(
            bclose, bma, handshake_ok=rmeta.get("validated", False))
'''

PIPE_CALL_NEW = '''        # --- E10 layer 2 --- progressive exposure. The controller takes a
        # NUMBER by design, so the READ and its failure path are owned here.
        # Skipped entirely while the gate is off, so the default tree makes no
        # extra database call and its behaviour is unchanged.
        streak = None
        if self.exposure.cfg.loss_streak_ceilings is not None:
            try:
                streak = loss_streak_from(self.mon.db.recent_closed_r())
            except Exception as _e:            # noqa: BLE001 -- see below
                # " error:" is a notifier CRITICAL substring on purpose. The
                # streak stays None, decide() then fails closed at a 0%
                # ceiling, and a silent halt is worth a phone push.
                self.alert(f"loss-streak read error: {_e!r} -- the "
                           f"progressive-exposure gate cannot evaluate")
        regime = self.exposure.decide(
            bclose, bma, handshake_ok=rmeta.get("validated", False),
            loss_streak=streak)
'''

PIPE_BRANCH_OLD = '''                       f"Exits and existing positions are unaffected.")
        else:
'''

PIPE_BRANCH_NEW = '''                       f"Exits and existing positions are unaffected.")
        elif regime.state is ExposureState.LOSS_STREAK:
            # --- E10 layer 2 --- progressive exposure biting on our OWN closed
            # trades. NORMAL operation after a run of losses: logged, never
            # pushed. It does NOT block arming -- the ceiling is partial, so
            # plan() still fills up to it. Must never contain "ARM BLOCKED";
            # without this branch the decision fell through to the UNAVAILABLE
            # message below and a routine streak read as a regime FAULT.
            self.alert(f"progressive exposure: {regime.reason} -- ceiling "
                       f"{regime.max_portfolio_exposure_pct:.0%}, new entries "
                       f"limited. Exits and existing positions are unaffected.")
        else:
'''

# --------------------------------------------------------------------------
# 3. param_snapshot.py -- the drift guard
# --------------------------------------------------------------------------

SNAP_GROUP_OLD = '''    "TR_UNFILLED_LIVE": "TTTS3018R", "TR_UNFILLED_MOCK": "VTTS3018R",
}
'''

SNAP_GROUP_NEW = '''    "TR_UNFILLED_LIVE": "TTTS3018R", "TR_UNFILLED_MOCK": "VTTS3018R",
}

# --- E10 layer 2 --- PINNED_EXPOSURE. ExposureConfig fields, and NOT in FROZEN
# on purpose: no backtest chose either of them. regime_ma is settled on doctrine
# (PATCH F3) and appears in FROZEN only because PARAMETER_FREEZE Rev 3 names it;
# loss_streak_ceilings is settled on doctrine too (E10, after three measurement
# routes failed to separate the arms) and was never in the freeze doc at all.
#
# This row is the ONLY thing that can see the progressive-exposure gate being
# switched on, because build_pipeline never passes an ExposureConfig: the single
# way to enable it is editing the module default, which is exactly the drift
# this group exists to stop. Turning it on is therefore a two-line change --
# DEFAULT_LOSS_STREAK_CEILINGS there AND the same value here, together.
PINNED_EXPOSURE = {"loss_streak_ceilings": None}
'''

SNAP_READ_OLD = '''    try:
        from kistrader.core import engine_v2 as _E
        ev = {k: getattr(_E, k, MISSING) for k in PINNED_ENGINE}
        tr = {k: getattr(_E, k, MISSING) for k in IDENTITY_TR}
    except ImportError:
        ev, tr = {}, {}
    p_rows, p_bad = _read_group(PINNED_DECISION, dc)
    e_rows, e_bad = _read_group(PINNED_ENGINE, ev)
    i_rows, i_bad = _read_group(IDENTITY_TR, tr)
    return p_rows + e_rows, i_rows, p_bad + e_bad + i_bad
'''

SNAP_READ_NEW = '''    try:
        from kistrader.core import engine_v2 as _E
        ev = {k: getattr(_E, k, MISSING) for k in PINNED_ENGINE}
        tr = {k: getattr(_E, k, MISSING) for k in IDENTITY_TR}
    except ImportError:
        ev, tr = {}, {}
    try:
        from kistrader.entry.exposure_controller import ExposureConfig
        xc = {k: getattr(ExposureConfig(), k, MISSING) for k in PINNED_EXPOSURE}
    except ImportError:
        xc = {}
    p_rows, p_bad = _read_group(PINNED_DECISION, dc)
    e_rows, e_bad = _read_group(PINNED_ENGINE, ev)
    x_rows, x_bad = _read_group(PINNED_EXPOSURE, xc)
    i_rows, i_bad = _read_group(IDENTITY_TR, tr)
    return (p_rows + e_rows + x_rows, i_rows,
            p_bad + e_bad + x_bad + i_bad)
'''

EDITS = [
    (F_ENGINE, ENGINE_OLD, ENGINE_NEW),
    (F_PIPE, PIPE_IMPORT_OLD, PIPE_IMPORT_NEW),
    (F_PIPE, PIPE_CALL_OLD, PIPE_CALL_NEW),
    (F_PIPE, PIPE_BRANCH_OLD, PIPE_BRANCH_NEW),
    (F_SNAP, SNAP_GROUP_OLD, SNAP_GROUP_NEW),
    (F_SNAP, SNAP_READ_OLD, SNAP_READ_NEW),
]

SENTINELS = {F_ENGINE: SENTINEL_ENGINE, F_PIPE: SENTINEL_PIPE,
             F_SNAP: SENTINEL_SNAP}


# --------------------------------------------------------------------------
# machinery
# --------------------------------------------------------------------------

def _ascii_guard():
    for name, txt in (("ENGINE_NEW", ENGINE_NEW), ("PIPE_IMPORT_NEW", PIPE_IMPORT_NEW),
                      ("PIPE_CALL_NEW", PIPE_CALL_NEW), ("PIPE_BRANCH_NEW", PIPE_BRANCH_NEW),
                      ("SNAP_GROUP_NEW", SNAP_GROUP_NEW), ("SNAP_READ_NEW", SNAP_READ_NEW)):
        try:
            txt.encode("ascii")
        except UnicodeEncodeError as e:
            raise SystemExit(f"patch text {name} is not pure ASCII: {e}")


def _read(path):
    with open(path, encoding="utf-8") as fh:
        return fh.read()


def _write(path, text):
    """Compile first, then temp-file + os.replace. A tree is never left with a
    file that does not parse."""
    compile(text, path, "exec")
    d = os.path.dirname(os.path.abspath(path))
    fd, tmp = tempfile.mkstemp(dir=d, suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as fh:
            fh.write(text)
        os.replace(tmp, path)
    except BaseException:
        if os.path.exists(tmp):
            os.unlink(tmp)
        raise


def _branch():
    try:
        r = subprocess.run(["git", "rev-parse", "--abbrev-ref", "HEAD"],
                           capture_output=True, text=True, timeout=5)
        return r.stdout.strip() if r.returncode == 0 else ""
    except Exception:                      # noqa: BLE001
        return ""


def check_branch(force):
    b = _branch()
    if force or b == REPO_BRANCH:
        print(f"  branch = {b or '(unknown)'}")
        return
    raise SystemExit(
        f"REFUSING: on branch {b!r}, expected {REPO_BRANCH!r}. This patch is "
        f"E10 work and must not land on main. Re-run with --force-branch if "
        f"you really mean it.")


def applied_state():
    """(n_applied, n_total) over the six edits, judged by the NEW text."""
    hits = 0
    for path, _old, new in EDITS:
        if not os.path.isfile(path):
            raise SystemExit(f"missing file: {path} (run from the repo root)")
        hits += 1 if new in _read(path) else 0
    return hits, len(EDITS)


def apply(revert=False):
    for path in (F_ENGINE, F_PIPE, F_SNAP):
        if not os.path.isfile(path):
            raise SystemExit(f"missing file: {path} (run from the repo root)")
    hits, total = applied_state()
    if not revert and hits == total:
        raise SystemExit("already applied (all 6 edits present) -- nothing to do")
    if not revert and hits:
        raise SystemExit(f"PARTIAL state: {hits}/{total} edits present. Refusing "
                         f"to patch on top. Use --revert or fix by hand.")
    if revert and hits == 0:
        raise SystemExit("not applied (0/6 edits present) -- nothing to revert")
    if revert and hits != total:
        raise SystemExit(f"PARTIAL state: {hits}/{total} edits present. Refusing "
                         f"to revert half a patch.")

    by_file = {}
    for path, old, new in EDITS:
        by_file.setdefault(path, []).append((new, old) if revert else (old, new))

    for path, ops in by_file.items():
        text = _read(path)
        for src, dst in ops:
            n = text.count(src)
            if n != 1:
                raise SystemExit(f"anchor in {path} matched {n} times, expected "
                                 f"exactly 1:\n---\n{src[:160]}\n---")
            text = text.replace(src, dst, 1)
        _write(path, text)
        print(f"  {'reverted' if revert else 'patched '} {path}  ({len(ops)} edit(s))")
    print("REVERTED." if revert else "APPLIED.")


# --------------------------------------------------------------------------
# verify
# --------------------------------------------------------------------------

class V:
    def __init__(self):
        self.p = 0
        self.f = 0

    def check(self, label, cond, detail=""):
        ok = bool(cond)
        self.p += ok
        self.f += (not ok)
        print(f"  {'PASS' if ok else 'FAIL'}  {label}" + (f"   {detail}" if detail and not ok else ""))

    def done(self):
        print(f"\n  {self.p}/{self.p + self.f} checks passed")
        return 0 if self.f == 0 else 1


_OPEN_STORES = []


def _mkstore(tmpdir):
    """EventStore holds its sqlite connection open for life and has no close().
    On Windows an open file cannot be unlinked, so every store built here is
    registered and closed before the temp directory is torn down -- otherwise
    TemporaryDirectory.__exit__ raises WinError 32 AFTER the checks passed."""
    from kistrader.core.engine_v2 import EventStore
    st = EventStore(os.path.join(tmpdir, "verify.db"))
    _OPEN_STORES.append(st)
    return st


def _close_stores():
    while _OPEN_STORES:
        try:
            _OPEN_STORES.pop().conn.close()
        except Exception:                  # noqa: BLE001 -- teardown only
            pass


def _insert(store, order_key, event_type, price, payload):
    store.conn.execute(
        "INSERT INTO position_events (ticker, order_key, event_type, state_to, "
        "shares, price, broker_order_id, payload) VALUES (?,?,?,?,?,?,?,?)",
        (order_key.split(":")[0], order_key, event_type, "CLOSED", 0, price,
         None, json.dumps(payload) if payload is not None else None))
    store.conn.commit()


def _pay(entry=100.0, risk=10.0, partial=False):
    return {"entry_price": entry, "initial_risk_per_share": risk,
            "partial_done": partial}


def _close(store, key, exit_price, entry=100.0, risk=10.0, partial=False):
    _insert(store, key, "CLOSED:STOP_HIT", exit_price,
            _pay(entry, risk, partial))


def verify():
    _ascii_guard()
    v = V()

    # ---- static: every edit present, exactly once ----
    for i, (path, _old, new) in enumerate(EDITS, 1):
        src = _read(path)
        v.check(f"edit {i}/6 present exactly once in {os.path.basename(path)}",
                src.count(new) == 1, f"count={src.count(new)}")

    eng_src, pipe_src, snap_src = _read(F_ENGINE), _read(F_PIPE), _read(F_SNAP)
    v.check("engine_v2 sentinel", eng_src.count(SENTINEL_ENGINE) == 1)
    v.check("pipeline sentinel", pipe_src.count(SENTINEL_PIPE) == 1)
    v.check("param_snapshot sentinel", snap_src.count(SENTINEL_SNAP) >= 1)

    # No un-wired decide() call may survive: the whole point of layer 2.
    v.check("no decide() call left without loss_streak",
            pipe_src.count("self.exposure.decide(") == 1
            and "loss_streak=streak" in pipe_src)
    v.check("LOSS_STREAK branch wired",
            pipe_src.count("ExposureState.LOSS_STREAK") == 1)
    # The two alert strings really are the ones the probes describe.
    v.check("loss-streak alert fragment in source",
            'f"progressive exposure: {regime.reason} -- ceiling "' in pipe_src)
    v.check("read-error alert fragment in source",
            'f"loss-streak read error: {_e!r} -- the "' in pipe_src)

    for path in (F_ENGINE, F_PIPE, F_SNAP):
        try:
            compile(_read(path), path, "exec")
            v.check(f"compiles: {os.path.basename(path)}", True)
        except SyntaxError as e:
            v.check(f"compiles: {os.path.basename(path)}", False, str(e))

    # ---- runtime ----
    sys.path.insert(0, os.getcwd())
    from kistrader.notifier import classify
    from kistrader.entry.exposure_controller import (
        ExposureConfig, ExposureController, ExposureState,
        loss_streak_from, DEFAULT_LOSS_STREAK_CEILINGS)
    from kistrader.tools import param_snapshot as PS

    # severity contract of the two new alerts
    v.check("streak alert is WARN (no phone push)",
            classify(LOSS_STREAK_ALERT_PROBE) == "WARN",
            classify(LOSS_STREAK_ALERT_PROBE))
    v.check("read-error alert is CRITICAL (pushes)",
            classify(READ_ERROR_ALERT_PROBE) == "CRITICAL",
            classify(READ_ERROR_ALERT_PROBE))

    import tempfile as _tf
    # ignore_cleanup_errors is the belt; _close_stores() is the actual fix.
    with _tf.TemporaryDirectory(ignore_cleanup_errors=True) as td:
        st = _mkstore(td)
        v.check("empty store -> []", st.recent_closed_r() == [])

        # three losses, newest last inserted
        _close(st, "AAA:1", 90.0)     # -1.0 R
        _close(st, "BBB:1", 95.0)     # -0.5 R
        _close(st, "CCC:1", 90.0)     # -1.0 R
        got = st.recent_closed_r()
        v.check("newest first", len(got) == 3 and abs(got[0] + 1.0) < 1e-9, str(got))
        v.check("three losses -> streak 3", loss_streak_from(got) == 3, str(got))

        _close(st, "DDD:1", 130.0)    # +3.0 R winner, newest
        got = st.recent_closed_r()
        v.check("winner stops the streak", loss_streak_from(got) == 0, str(got))

        st2 = _mkstore(_mkdir(td, "b"))
        _close(st2, "E:1", 80.0)                      # -2.0 R
        _close(st2, "F:1", 100.0)                     # exactly 0 -> scratch
        _close(st2, "G:1", 90.0)                      # -1.0 R (newest)
        got = st2.recent_closed_r()
        v.check("scratch is skipped, not a reset",
                loss_streak_from(got) == 2, str(got))

        # POSITIVE CONTROL: a partial-taken trade must NOT be scored.
        st3 = _mkstore(_mkdir(td, "c"))
        _close(st3, "H:1", 100.5, partial=True)
        got = st3.recent_closed_r()
        v.check("POSITIVE CONTROL partial_done -> NaN",
                len(got) == 1 and math.isnan(got[0]), str(got))
        v.check("POSITIVE CONTROL NaN ends the streak",
                loss_streak_from(got) == 0, str(got))

        # RECONCILE_CLOSED is excluded entirely
        st4 = _mkstore(_mkdir(td, "d"))
        _insert(st4, "I:1", "RECONCILE_CLOSED:reconcile", 100.0, _pay())
        v.check("RECONCILE_CLOSED excluded", st4.recent_closed_r() == [])

        # zero risk -> NaN, not 0.0
        st5 = _mkstore(_mkdir(td, "e"))
        _close(st5, "J:1", 90.0, risk=0.0)
        got = st5.recent_closed_r()
        v.check("risk<=0 -> NaN not scratch",
                len(got) == 1 and math.isnan(got[0]), str(got))

        # malformed payload -> NaN
        st6 = _mkstore(_mkdir(td, "f"))
        _insert(st6, "K:1", "CLOSED:STOP_HIT", 90.0, {"entry_price": "x",
                                                      "initial_risk_per_share": 10.0})
        got = st6.recent_closed_r()
        v.check("malformed payload -> NaN",
                len(got) == 1 and math.isnan(got[0]), str(got))

        # dedup: one trade, one verdict
        st7 = _mkstore(_mkdir(td, "g"))
        _close(st7, "L:1", 90.0)
        _close(st7, "L:1", 90.0)
        v.check("duplicate order_key counted once",
                len(st7.recent_closed_r()) == 1)

        # limit honoured
        st8 = _mkstore(_mkdir(td, "h"))
        for i in range(30):
            _close(st8, f"M{i}:1", 90.0)
        v.check("limit honoured", len(st8.recent_closed_r(limit=5)) == 5)
        v.check("default limit is 20", len(st8.recent_closed_r()) == 20)

        # ---- composed: store -> streak -> ceiling ----
        on = ExposureController(ExposureConfig(
            loss_streak_ceilings=DEFAULT_LOSS_STREAK_CEILINGS))
        st9 = _mkstore(_mkdir(td, "i"))
        _close(st9, "N1:1", 90.0)
        d = on.decide(None, None, True, loss_streak=loss_streak_from(
            st9.recent_closed_r()))
        v.check("1 loss -> gate silent at 1.00",
                d.max_portfolio_exposure_pct == 1.00
                and d.state is ExposureState.RISK_ON, str(d))
        _close(st9, "N2:1", 90.0)
        d = on.decide(None, None, True, loss_streak=loss_streak_from(
            st9.recent_closed_r()))
        v.check("2 losses -> 0.50 LOSS_STREAK",
                d.max_portfolio_exposure_pct == 0.50
                and d.state is ExposureState.LOSS_STREAK, str(d))
        _close(st9, "N3:1", 90.0)
        d = on.decide(None, None, True, loss_streak=loss_streak_from(
            st9.recent_closed_r()))
        v.check("3 losses -> 0.25 LOSS_STREAK",
                d.max_portfolio_exposure_pct == 0.25
                and d.state is ExposureState.LOSS_STREAK, str(d))
        d = on.decide(None, None, True, loss_streak=None)
        v.check("gate ON but no streak -> fail closed 0.00 UNAVAILABLE",
                d.max_portfolio_exposure_pct == 0.00
                and d.state is ExposureState.UNAVAILABLE, str(d))

        # LAST statement in the block: sqlite must let go of the files before
        # TemporaryDirectory tries to unlink them (WinError 32 otherwise).
        _close_stores()

    # default (shipped) config: unchanged behaviour
    off = ExposureController()
    d = off.decide(None, None, True)
    v.check("SHIPPED default: gate OFF, ceiling 1.00, RISK_ON",
            d.max_portfolio_exposure_pct == 1.00
            and d.state is ExposureState.RISK_ON, str(d))
    v.check("SHIPPED default: loss_streak_ceilings is None",
            ExposureConfig().loss_streak_ceilings is None)

    # ---- param_snapshot ----
    v.check("PINNED_EXPOSURE names loss_streak_ceilings",
            list(PS.PINNED_EXPOSURE) == ["loss_streak_ceilings"])
    pin_rows, _id_rows, bad = PS.extra_drift()
    names = [r[0] for r in pin_rows]
    v.check("loss_streak_ceilings appears in the PINNED rows",
            names.count("loss_streak_ceilings") == 1, str(names[-3:]))
    v.check("no pinned/identity drift on this tree", bad == 0, f"bad={bad}")
    # POSITIVE CONTROL: the guard must actually fire when the value changes.
    _rows, _bad = PS._read_group(
        PS.PINNED_EXPOSURE,
        {"loss_streak_ceilings": DEFAULT_LOSS_STREAK_CEILINGS})
    v.check("POSITIVE CONTROL guard fires when the gate is switched on",
            _bad == 1, f"bad={_bad}")

    return v.done()


def _mkdir(root, name):
    p = os.path.join(root, name)
    os.makedirs(p, exist_ok=True)
    return p


def main(argv=None):
    ap = argparse.ArgumentParser(description="E10 layer 2 -- wire progressive exposure")
    ap.add_argument("--verify", action="store_true", help="check only, no writes")
    ap.add_argument("--revert", action="store_true", help="byte-exact undo")
    ap.add_argument("--force-branch", action="store_true",
                    help="skip the branch guard")
    a = ap.parse_args(argv)
    _ascii_guard()
    if a.verify:
        return verify()
    check_branch(a.force_branch)
    apply(revert=a.revert)
    return 0


if __name__ == "__main__":
    sys.exit(main())
